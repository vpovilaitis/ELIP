<?php
define ("PATH", "./");
define ("COMPONENT_FACTORY", NULL);
define ("SITE_SKIN", "default");

require_once (PATH.'inc/load.php');
$class = getNextDeploymentStep ($context);
$dir = "setup";

if (!$class) // already deployed
    {
    if ($context->getCurrentUser () <= 0)
        {
        $context->redirect (PATH."login.php?".Constants::PARAM_RETURN_TO."=". rawurlencode($_SERVER['REQUEST_URI']));
        exit ();
        }

    define ("DEFAULT_CLASS", "AdminHome");
    $class = isset ($context->request["c"]) ? $context->request["c"] : DEFAULT_CLASS;
    $dir = "admin";
    }

$includePath = PATH."$dir/".strtolower (trim ($class)).".php";

$ret = false;
if (file_exists ($includePath))
    $ret = include ($includePath);

if (false === $ret || !class_exists ($class))
    {
    $context->displayErrorPage ($context->formatText ("Display handler \"[_0]\" not found", $class));
    }

$instance = new $class ($context);
$instance->ensureTitle ($context, $context->request);

// include custom page load scripts (if any)
@include PATH.'inc/pageloaded.php';

$instance->process ($context->request);
?>

<?php

require_once (PATH.'inc/general.php');
require_once (PATH.'admin/metadatapreview.php');
require_once (PATH.'inc/urlicon.php');

class GroupsPreview extends Preview
    {
    public function __construct ($context)
        {
        parent::__construct ("groups", $context, new GroupsTable ($context));
        $this->defaultPageSize = SMALL_PAGESIZE;
        }

    protected function getDisplayTemplate ()
        {
        return array
            (
            new LabelFieldTemplate ("g", GroupsTable::COL_LABEL, $this->context->getText ('Title')),
            new LabelFieldTemplate ("g", GroupsTable::COL_NAME, $this->context->getText ('Group')),
            new LabelFieldTemplate ("g", GroupsTable::COL_DESCRIPTION, $this->context->getText ('Description')),
            );
        }

    public function getTitle ()
        {
        return $this->getText ("User groups");
        }

    public function getActionList ()
        {
        return array_merge
            (
            parent::getActionList (),
            array
                (
                new SingleRowURLIcon ($this, "access", $this->_("View permissions"),
                                      "admin.php"),
                )
            );
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if (empty ($editorLink))
            $editorLink = "admin/GroupEditor";
        if (empty ($title))
            $title = $new ? $this->getText ("Add a new group") : $this->getText ("Edit the group");
        return parent::getEditorAction ($new, $title, $editorLink, $params);
        }

    }

class UsersPreview extends Preview
    {
    public function __construct ($context)
        {
        parent::__construct ("users", $context, new UsersTable ($context));
        }

    protected function getDisplayColumnPairs ()
        {
        return array ("name" => $this->context->getText ('Name'),
                      "email" => $this->context->getText ('E-Mail'),
                      "description" => $this->context->getText ('Description')
                      );
        }

    public function getTitle ()
        {
        return $this->getText ("Site users");
        }

    protected function getDisplayTemplate ()
        {
        return array
            (
            new LabelFieldTemplate ("u", UsersTable::COL_NAME, $this->context->getText ('User')),
            new LabelFieldTemplate ("u", UsersTable::COL_EMAIL, $this->context->getText ('E-Mail')),
            new LabelFieldTemplate ("u", UsersTable::COL_DESCRIPTION, $this->context->getText ('Description')),
            );
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if (empty ($editorLink))
            $editorLink = "admin/UserEditor";
        if (empty ($title))
            $title = $new ? $this->getText ("Add a new user") : $this->getText ("Edit the user");
        return parent::getEditorAction ($new, $title, $editorLink, $params);
        }

    public function getActionList ()
        {
        return array_merge
            (
            parent::getActionList (),
            array
                (
                new SingleRowURLIcon ($this, "members", $this->_("View groups user belongs to"),
                                      "admin.php"),
                new SingleRowURLIcon ($this, "access", $this->_("View permissions"),
                                      "admin.php"),
                )
            );
        }

    }

?>

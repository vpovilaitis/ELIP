<?php

require_once (PATH.'inc/preview.php');
require_once (PATH.'inc/urlicon.php');

class MetaDataUIPreview extends Preview
    {
    public function __construct ($context)
        {
        parent::__construct ("metapages", $context, new FragmentsTable ($context));
        $this->defaultPageSize = SMALL_PAGESIZE;
        }

    public function getTitle ()
        {
        return $this->getText ("UI Pages");
        }

    protected function getDisplayTemplate ()
        {
        return array
            (
            new LabelFieldTemplate ("mp", FragmentsTable::COL_TITLE, $this->context->getText ('Title')),
            new LabelFieldTemplate ("mp", FragmentsTable::COL_DESCRIPTION, $this->context->getText ('Description')),
            );
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if (empty ($editorLink))
            $editorLink = "admin/PageEditor";
        if (empty ($title))
            $title = $new ? $this->getText ("Add new page") : $this->getText ("Edit page");
        return parent::getEditorAction ($new, $title, $editorLink, $params);
        }

    }

?>

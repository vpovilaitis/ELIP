<?php

require_once (PATH.'inc/preview.php');
require_once (PATH.'inc/urlicon.php');

class SettingsPreview extends Preview
    {
    public function __construct ($context)
        {
        parent::__construct ("sett", $context, new SiteSettings ($context));
        }

    public function getTitle ()
        {
        return $this->getText ("Site settings");
        }

    protected function getDisplayTemplate ()
        {
        return array
            (
            new LabelFieldTemplate ("s", SiteSettings::COL_NAME, $this->context->getText ('Setting')),
            new LabelFieldTemplate ("s", SiteSettings::COL_VALUE, $this->context->getText ('Value')),
            new LabelBoolFieldTemplate ("s", SiteSettings::COL_TRANSLATABLE, $this->context->getText ('Transl.')),
            );
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if (empty ($editorLink))
            $editorLink = "admin/SettingEditor";
        if (empty ($title))
            $title = $new ? $this->getText ("Add site setting") : $this->getText ("Edit site setting value");
        return parent::getEditorAction ($new, $title, $editorLink, $params);
        }

    }

?>

<?php
require_once (PATH.'inc/instanceeditor.php');
require_once (PATH.'inc/metatables.php');
require_once (PATH.'admin/pagecomponentspreview.php');

class PageEditor extends InstanceEditor
    {
    protected $nameField;
    protected $labelColumn;
    protected $descColumn;
    protected $homeColumn;
    protected $templateColumn;

    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new MetaDataPages ($context);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        if (!$this->initializeTemplateParts ($request, $isCreating))
            return NULL;

        return array ($this->labelColumn, $this->nameColumn, $this->templateColumn,
                      $this->descColumn, $this->homeColumn);
        }

    public function ensureChildren ($context, $request)
        {
        if (!$this->isCreating ())
            {
            foreach ($this->getIds () as $idCol => $idVal)
                {
                $id = $idVal;
                break;
                }
            $this->addComponent ($request, "components", new PageComponentsPreview ($this->context, $id));
            }
        return true;
        }

    protected function initializeTemplateParts ($request, $isCreating)
        {
        $prefix  = "mpg";
        $this->nameColumn = new TextFieldTemplate ($prefix, MetaDataPages::COL_NAME,
                                             $this->getText ("Code name:"),
                                             $this->getText ("An internal page name (non translatable)."),
                                             24);
        $this->labelColumn = new TextFieldTemplate ($prefix, MetaDataPages::COL_LABEL,
                                              $this->getText ("Title:"),
                                              $this->getText ("Page title."),
                                              32);
        $this->descColumn = new LongTextFieldTemplate ($prefix, MetaDataPages::COL_DESCRIPTION,
                                             $this->getText ("Description:"),
                                             $this->getText ("Brief page description."),
                                             48);
        $this->templateColumn = new TextFieldTemplate ($prefix, MetaDataPages::COL_TEMPLATE,
                                             $this->getText ("Page template:"),
                                             $this->getText ("Optional page template file if non-default template is used. File should reside in templates/pages directory, enter just file name (no path or extension)"),
                                             32);

        $this->homeColumn = new CheckBoxFieldTemplate ($prefix, MetaDataPages::COL_ISHOMEPAGE,
                                                     $this->getText ("Default:"), 
                                                     $this->getText ("Will this page be used as a home page?"));

        return true;
        }

    public function getPageTitle ($isCreating = false)
        {
        return $isCreating ? $this->getText ("Creating a new page") : $this->getText ("Editing the page");
        }
    }

?>

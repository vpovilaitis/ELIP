<?php
require_once (PATH.'inc/instanceeditor.php');

class GroupEditor extends InstanceEditor
    {
    protected $labelColumn;
    protected $nameColumn;
    protected $descColumn;

    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new GroupsTable ($context);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        $this->initializeTemplateParts ($request);
        $this->defaultNameColumn->readonly = !$isCreating;
        return array
            (
            $this->labelColumn,
            $this->nameColumn,
            $this->descColumn,
            );
        }

    protected function initializeTemplateParts ($request)
        {
        if (NULL != $this->nameColumn)
            return;

        $texts = $this->texts;
        $prefix = "g";

        $this->nameColumn = new TextFieldTemplate ($prefix, GroupsTable::COL_NAME, _("Group name:"), _("Non-translatable group name."), 32);
        $this->labelColumn = new TextFieldTemplate ($prefix, GroupsTable::COL_LABEL, _("Group title:"), _("User friendly (translatable) group title."), 32);
        $this->descColumn = new TextFieldTemplate ($prefix, GroupsTable::COL_DESCRIPTION, _("Group description:"), _("A group description."), 48);
        }

    public function getPageTitle ($isCreating = false)
        {
        return $isCreating ? $this->getText ("Adding a new group") : $this->getText ("Editing the group");
        }
    }

?>

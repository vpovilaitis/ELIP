<?php
require_once (PATH."inc/dropdownfieldtemplate.php");

class TypesDropDownFieldTemplate extends DropDownFieldTemplate
    {
    const RELATION_PREFIX = "->";

    public function __construct ($context, $prefix, $key)
        {
        $availableTypes = MetaDataColumns::getPredefinedTypes ($context);
        
        $tablesHandler = new MetaDataTables ($context);
        $cols = array (MetaDataTables::COL_TABLEID,
                       MetaDataTables::COL_NAME,
                       MetaDataTables::COL_LABEL);
        $tables = $tablesHandler->selectBy ($cols, NULL);
        if (!empty ($tables))
            {
            foreach ($tables as $tableRow)
                {
                $label = empty ($tableRow[MetaDataTables::COL_LABEL])
                            ? $tableRow[MetaDataTables::COL_NAME]
                            : $tableRow[MetaDataTables::COL_LABEL];
                $availableTypes[self::RELATION_PREFIX.$tableRow[MetaDataTables::COL_TABLEID]] = $label;
                }
            }

        parent::__construct ($prefix, $key,
                             $context->getText ("Data type or relation"),
                             $context->getText ("Type of the values stored in the column or the table from which values will be selected."),
                             $availableTypes);
        }

    public static function parseValue ($val)
        {
        if (0 === strpos ($val, self::RELATION_PREFIX))
            return array (true, substr ($val, strlen (self::RELATION_PREFIX)));
        return array (false, $val);
        }

    public static function formatValue ($column)
        {
        if ($column instanceof RelationColumn)
            return self::RELATION_PREFIX.$column->relatedTableId;

        $type = ColumnDefFactory::getTypeString ($column->columnDef);
        if ($column->columnDef->size > 0)
            $type .= "({$column->columnDef->size})";

        return $type;
        }
    }

class TablesDropDownFieldTemplate extends DropDownFieldTemplate
    {
    public function __construct ($context, $prefix, $key)
        {
        $tablesHandler = new MetaDataTables ($context);
        $cols = array (MetaDataTables::COL_TABLEID,
                       MetaDataTables::COL_NAME,
                       MetaDataTables::COL_LABEL);
        $tables = $tablesHandler->selectBy ($cols, NULL);
        if (false !== $tables)
            {
            $availableTypes[NULL] = $context->getText ("<none>");
            if (!empty ($tables))
                {
                foreach ($tables as $tableRow)
                    {
                    $label = empty ($tableRow[MetaDataTables::COL_LABEL])
                                ? $tableRow[MetaDataTables::COL_NAME]
                                : $tableRow[MetaDataTables::COL_LABEL];
                    $availableTypes[$tableRow[MetaDataTables::COL_TABLEID]] = $label;
                    }
                }
            }
        parent::__construct ($prefix, $key,
                             $context->getText ("Target table"),
                             $context->getText ("The table component will work on."),
                             $availableTypes);
        }

    public static function parseValue ($val)
        {
        if (0 === strpos ($val, self::RELATION_PREFIX))
            return array (true, substr ($val, strlen (self::RELATION_PREFIX)));
        return array (false, $val);
        }

    public static function formatValue ($column)
        {
        if ($column instanceof RelationColumn)
            return self::RELATION_PREFIX.$column->relatedTableId;

        $type = ColumnDefFactory::getTypeString ($column->columnDef);
        if ($column->columnDef->size > 0)
            $type .= "({$column->columnDef->size})";

        return $type;
        }
    }

class ZonesDropDownFieldTemplate extends CreatableDropDownFieldTemplate
    {
    public function __construct ($context, $prefix, $key)
        {
        $availableZones = MetaDataPageZones::getPickList ($context);

        parent::__construct ($context, $prefix, $key,
                             $context->getText ("Page zone"),
                             $context->getText ("The zone to put a page to."),
                             $availableZones);
        }

    protected function createItem ($context, $label)
        {
        $handler = new MetaDataPageZones ($context);

        $id = $handler->insertRecord (array (MetaDataPageZones::COL_NAME => $label));
        if (false === $id)
            {
            $context->addError ("Error while creating a new zone");
            return NULL;
            }

        return $id;
        }
    }

?>

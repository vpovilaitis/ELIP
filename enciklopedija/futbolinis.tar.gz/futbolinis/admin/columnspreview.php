<?php

require_once (PATH.'inc/preview.php');
require_once (PATH.'inc/urlicon.php');

class DeleteColumnIcon extends DeleteIcon
    {
    protected $tableId;
    protected $contentTable;

    public function __construct ($component, $dbtable, $tableId)
        {
        parent::__construct ($component, $dbtable);
        $this->tableId = $tableId;
        $this->contentTable = ContentTable::createInstanceById ($this->context, $this->tableId);
        }

    public function isVisible ($row = NULL)
        {
        if (empty ($this->contentTable))
            return false;

        return $this->dbtable->canDelete ();
        }

    public function getConfirmationString ($row)
        {
        if (!empty ($this->contentTable) && $this->contentTable->tableExists ())
            {
            if (NULL == $row)
                return $this->context->getForJS ("Do you realy wish to delete the selected columns?\nAll the data in the column will be lost permanently.");
            else
                return $this->context->getForJS ("Do you realy wish to delete this column?\nAll the data in the column will be lost permanently.");
            }

        return parent::getConfirmationString ($row);
        }

    protected function cleanupRelatedData ($ids)
        {
        if (!empty ($this->contentTable) && $this->contentTable->tableExists ())
            {
            foreach ($ids as $id)
                {
                if (false === $this->contentTable->removeColumnById ($id[1]))
                    {
                    $this->component->addError ("Unable to remove a column");
                    return false;
                    }
                }
            }

        return true;
        }
    }

class ChangeColumnOrderIcon extends ChangeOrderIcon
    {
    public function __construct ($component, $key, $up)
        {
        parent::__construct ($component, $key, $up);
        }

    public function execute ($request, $ids)
        {
        $handler = new MetaDataColumns ($this->context);
        list ($tableId, $columnId) = $ids[0];
        $ret = $handler->changeOrder ($tableId, $columnId, $this->up);
        if (false === $ret)
            $this->component->log ("Error changing column order");
        return true;
        }
    }

class ColumnsPreview extends Preview
    {
    protected $tableId;

    public function __construct ($context, $tableId)
        {
        parent::__construct ("columns", $context, new MetaDataColumns ($context));
        if (empty ($tableId))
            $this->log ("Table id not set for ColumnsPreview");
        $this->tableId = $tableId;
        }

    protected function getDisplayTemplate ()
        {
        return array
            (
            new LabelFieldTemplate ("col", MetaDataColumns::COL_LABEL, $this->context->getText ('Label')),
            new LabelFieldTemplate ("col", MetaDataColumns::COL_TYPE, $this->context->getText ('Type')),
            new LabelFieldTemplate ("col", MetaDataColumns::COL_NAME, $this->context->getText ('Column')),
            new LabelBoolFieldTemplate ("col", MetaDataColumns::COL_REQUIRED, $this->context->getText ('Required')),
            new LabelBoolFieldTemplate ("col", MetaDataColumns::COL_TRANSLATABLE, $this->context->getText ('Transl.')),
            new LabelFieldTemplate ("col", MetaDataColumns::COL_DESCRIPTION, $this->context->getText ('Description')),
            new SortOrderFieldTemplate ("col", MetaDataColumns::COL_SORTORDER, $this->context->getText ('Sort order')),
            new LabelFieldTemplate ("col", MetaDataColumns::COL_RELATIONNAME, $this->context->getText ('Relation label')),
            );
        }

    public function getTitle ()
        {
        return $this->getText ("Table columns");
        }

    public function processInput ($context, &$request)
        {
        if (!parent::processInput ($context, $request))
            return false;

        return true;
        }

    protected function getFilterCriteria ()
        {
        return array (new EqCriterion (MetaDataColumns::COL_TABLEID, $this->tableId));
        }

    public function select ($context, $criteria = NULL)
        {
        $columnList = $this->dbtable->selectColumns ($this->tableId);
        if (false === $columnList)
            return false;

        $rows = array ();
        foreach ($columnList as $column)
            {
            $row = array ();
            $row[MetaDataColumns::COL_TABLEID] = $this->tableId;
            $row[MetaDataColumns::COL_COLUMNID] = $column->id;
            $row[MetaDataColumns::COL_NAME] = $column->name;
            $row[MetaDataColumns::COL_LABEL] = $column->getLabel ();
            $row[MetaDataColumns::COL_TYPE] = $column->getTypeDescription ($context);
            $row[MetaDataColumns::COL_REQUIRED] = $column->required;
            $row[MetaDataColumns::COL_TRANSLATABLE] = $column->translatable;
            $row[MetaDataColumns::COL_DESCRIPTION] = $column->description;
            $row[MetaDataColumns::COL_SORTORDER] = $column->sortOrder;
            $row[MetaDataColumns::COL_SORTASC] = $column->sortAsc;

            if (!empty ($column->relationName))
                $row[MetaDataColumns::COL_RELATIONNAME] = $column->relationName;

            $rows[] = $row;
            }
        return $rows;
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if (empty ($editorLink))
            $editorLink = "admin/ColumnEditor";
        if (empty ($title))
            $title = $new ? $this->getText ("Add new metatable column") : $this->getText ("Modify metatable column");
        return parent::getEditorAction ($new, $title, $editorLink, $new ? "id={$this->tableId}" : NULL);
        }

    public function getActionList ()
        {
        return array_merge
            (
            parent::getActionList (true),
            array
                (
                new DeleteColumnIcon ($this, $this->dbtable, $this->tableId),
                new ChangeColumnOrderIcon ($this, "up", true),
                new ChangeColumnOrderIcon ($this, "down", false),
                )
            );
        }

    }

?>

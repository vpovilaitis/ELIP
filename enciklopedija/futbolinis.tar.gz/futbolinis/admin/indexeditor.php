<?php
require_once (PATH.'inc/instanceeditor.php');
require_once (PATH.'admin/dropdown.php');
require_once (PATH.'inc/multiroweditor.php');

class IndexEditor extends InstanceEditor
    {
    protected $nameField;
    protected $typeField;
    protected $columnNamesField;
    const KEY_COLUMNS= "cols";

    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new MetaDataIndexes ($context);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        if (!$this->initializeTemplateParts ($request, $isCreating))
            return NULL;
        $arr = array ($this->nameField, $this->typeField, $this->columnNamesField);
        return $arr;
        }

    protected function initializeTemplateParts ($request, $isCreating)
        {
        $prefix  = $this->getPrefix ();
        $this->nameField = new TextFieldTemplate ($prefix, MetaDataIndexes::COL_DESCRIPTION,
                                             $this->getText ("Index description:"),
                                             $this->getText ("Brief description of the index (purpose, etc.)."),
                                             48);
        $types = array
            (
            MetaDataIndexes::TYPE_UNIQUE => "Unique entries",
            MetaDataIndexes::TYPE_INDEX => "Allow duplicate entries"
            );
        $this->typeField = new DropDownFieldTemplate ($prefix, MetaDataIndexes::COL_TYPE,
                                              $this->getText ("Type:"),
                                              $this->getText ("Index type."),
                                              $types);

        if ($isCreating)
            {
            $tableId = $this->getParentId (true);
            $columnHandler = new MetaDataColumns ($this->context);
            $columnsInTable = $columnHandler->selectColumns ($tableId);
            
            if (empty ($columnsInTable))
                return true;

            $columnListWithNone = array (0 => $this->getText ("<do not use>"));
            $columnList = array ();
            foreach ($columnsInTable as $col)
                {
                $columnListWithNone[$col->id] = $col->getLabel ();
                $columnList[$col->id] = $col->getLabel ();
                }

            $columnTemplate = array ();
            $i = 0;
            $columnTemplate[] = new DropDownFieldTemplate ($prefix, ++$i,
                                           $this->getText ("First column"),
                                           $this->getText ("Select column to index."),
                                           $columnList);
            $columnTemplate[] = new DropDownFieldTemplate ($prefix, ++$i,
                                           $this->getText ("Second column"),
                                           $this->getText ("Select column if needed."),
                                           $columnListWithNone);
            $columnTemplate[] = new DropDownFieldTemplate ($prefix, ++$i,
                                           $this->getText ("Next column"),
                                           $this->getText ("Select column if needed."),
                                           $columnListWithNone);
            $this->columnNamesField = new MultiRowEditor ($this->context, $prefix,
                                                      self::KEY_COLUMNS,
                                                      $this->getText ("Index columns:"),
                                                      $columnTemplate, 1);
            }
        else
            {
            $this->columnNamesField = new TextFieldTemplate ($prefix, MetaDataIndexes::COL_COLUMNNAMES,
                                             $this->getText ("Index columns:"),
                                             $this->getText ("Columns used in this index."),
                                             48);
            $this->columnNamesField->readonly = true;
            $this->typeField->readonly = true;
            }

        return true;
        }

    protected function retrieveExisting ($request, $id)
        {
        $indexRow = parent::retrieveExisting ($request, $id);
        if (empty ($indexRow))
            return $indexRow;

        return $indexRow;
        }

    protected function createRecord (&$request, $values)
        {
        $columns = array ();
        foreach ($values[self::KEY_COLUMNS] as $indexColumns)
            {
            foreach ($indexColumns as $key => $col)
                {
                if (!empty ($col))
                    $columns[] = $col;
                }
            }

        $tableId = $this->getParentId (true);
        $id = $this->dbtable->addIndex ($tableId,
                                        $values[MetaDataIndexes::COL_TYPE],
                                        $values[MetaDataIndexes::COL_DESCRIPTION],
                                        $columns);
        if (empty ($id))
            return false;

        $this->setMode (false, $id);
        return true;
        }

    protected function modifyRecord ($request, $id, $values)
        {
        $values = array (MetaDataIndexes::COL_DESCRIPTION => $values[MetaDataIndexes::COL_DESCRIPTION]);
        return parent::modifyRecord ($request, $id, $values);
        }

    public function getPageTitle ($isCreating = false)
        {
        return $isCreating
                    ? $this->getText ("Adding a new metatable index")
                    : $this->getText ("Modifying the index");
        }
    }

?>

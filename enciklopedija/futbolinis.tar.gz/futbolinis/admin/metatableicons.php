<?php

require_once (PATH.'inc/preview.php');
require_once (PATH.'inc/urlicon.php');

class ExportIcon extends IconAction
    {
    public function __construct ($component)
        {
        parent::__construct ($component, "export", $component->getText ("Export structure"));
        }

    public function isVisible ($row = NULL)
        {
        return NULL == $row;
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function requiresId ()
        {
        return true;
        }

    public function execute ($request, $ids)
        {
        $context = $this->component->getContext ();
        $tables = new MetaDataTables ($context);

        $idCriteria = new InCriterion (MetaDataTables::COL_TABLEID, array());
        for ($i = 0; $i < count ($ids); $i++)
            {
            $idCriteria->value[] = $ids[$i][0];
            }
        $rows = $tables->selectBy (NULL, array ($idCriteria), NULL, array (new IncludeAllTranslations(), new OrderBy (array (MetaDataTables::COL_TABLEID))));
        if (!$rows)
            {
            $component->addError ("Nothing found to export");
            return true;
            }

        $tablesToExport = array ();
        $lastRow = NULL;
        $nonTranslatableTableColumns = array (MetaDataTables::COL_PARENTID, MetaDataTables::COL_HANDLER, MetaDataTables::COL_VERSION, MetaDataTables::COL_OPTIONS);
        $translatableTableColumns = array (DBTable::COL_LANG, MetaDataTables::COL_LABEL, MetaDataTables::COL_DESCRIPTION);

        for ($i = 0; $i < count ($rows); $i++)
            {
            $tableName = $rows[$i][MetaDataTables::COL_NAME];
            if (NULL == $lastRow || $lastRow->name != $tableName)
                {
                $lastRow = new ExportedRowV1 ();
                $lastRow->name = $tableName;

                $lastRow->table = array ();
                for ($c = 0; $c < count ($nonTranslatableTableColumns); $c++)
                    {
                    $lastRow->table[$nonTranslatableTableColumns[$c]] = $rows[$i][$nonTranslatableTableColumns[$c]];
                    }

                $lastRow->id = $rows[$i][MetaDataTables::COL_TABLEID];
                $lastRow->columns = $this->retrieveColumns ($lastRow->id);
                if (false === $lastRow->columns)
                    return true;

                $tablesToExport[] = $lastRow;
                if (!isset ($name))
                    $name = $tableName;
                }

            // additional translations
            if (!empty ($rows[$i][DBTable::COL_LANG]))
                {
                $thisTranslation = array ();
                for ($c = 0; $c < count ($translatableTableColumns); $c++)
                    {
                    $thisTranslation[$translatableTableColumns[$c]] = $rows[$i][$translatableTableColumns[$c]];
                    }

                if (!isset ($lastRow->table[DBTable::COL_LANG]))
                    $lastRow->table[DBTable::COL_LANG] = array ();
                $translations = &$lastRow->table[DBTable::COL_LANG];
                $translations[] = $thisTranslation;
                }
            }

        header ("Content-type: text/plain");
        header ("Content-Disposition: attachment; filename=\"$name.tbl\"");
        echo serialize($tablesToExport);

        $context->clearLog ();
        exit ();
        return false;
        }

    protected function retrieveColumns ($id)
        {
        $columnsTable = new MetaDataColumns ($this->context);
        $columns = $columnsTable->selectBy (NULL,
                                            array (new EqCriterion (MetaDataColumns::COL_TABLEID, $id)),
                                            NULL,
                                            array (new IncludeAllTranslations(), new OrderBy (array (MetaDataColumns::COL_TABLEID, MetaDataColumns::COL_COLUMNID))));
        if (false === $columns)
            {
            $component->addError ("Error selecting columns");
            return false;
            }

        $preparedColumns = array();
        $lastRow = NULL;
        $nonTranslatableColumns = array
            (
            MetaDataColumns::COL_NAME,
            MetaDataColumns::COL_ISRELATION,
            MetaDataColumns::COL_TYPE,
            MetaDataColumns::COL_SIZE,
            MetaDataColumns::COL_PRECISION,
            MetaDataColumns::COL_MODIFIERS,
            MetaDataColumns::COL_REQUIRED,
            MetaDataColumns::COL_TRANSLATABLE,
            MetaDataColumns::COL_CATEGORY,
            MetaDataColumns::COL_SORTORDER,
            MetaDataColumns::COL_SORTASC,
            MetaDataColumns::COL_DISPLAYTYPE,
            MetaDataColumns::COL_INPUTTYPE,
            );
        $translatableColumns = array (MetaDataColumns::COL_LANG,
                                      MetaDataColumns::COL_LABEL,
                                      MetaDataColumns::COL_DEFAULTVALUE,
                                      MetaDataColumns::COL_DESCRIPTION,
                                      MetaDataColumns::COL_RELATIONNAME);

        for ($i = 0; $i < count ($columns); $i++)
            {
            $name = $columns[$i][MetaDataColumns::COL_NAME];
            if (NULL == $lastRow || $lastRow[MetaDataColumns::COL_NAME] != $name)
                {
                if (NULL != $lastRow)
                    $preparedColumns[] = $lastRow;

                $lastRow = array ();

                for ($c = 0; $c < count ($nonTranslatableColumns); $c++)
                    {
                    $lastRow[$nonTranslatableColumns[$c]] = $columns[$i][$nonTranslatableColumns[$c]];
                    }
                }

            // additional translations
            if (!empty ($columns[$i][DBTable::COL_LANG]))
                {
                $thisTranslation = array ();
                for ($c = 0; $c < count ($translatableColumns); $c++)
                    {
                    $thisTranslation[$translatableColumns[$c]] = $columns[$i][$translatableColumns[$c]];
                    }

                if (!isset ($lastRow[DBTable::COL_LANG]))
                    $lastRow[DBTable::COL_LANG] = array ();
                $translations = &$lastRow[DBTable::COL_LANG];
                $translations[] = $thisTranslation;
                }
            }

        if (!empty ($lastRow))
            $preparedColumns[] = $lastRow;
        return $preparedColumns;
        }
    }

class ImportIcon extends URLIcon
    {
    protected $dbtable;

    public function __construct ($component, $dbtable)
        {
        parent::__construct ($component, "import", $component->getText ("Import structure"), "index.php?c=EditorPage&i=admin/MetaDataImport");
        $this->dbtable = $dbtable;
        }

    public function isVisible ($row = NULL)
        {
        return $this->dbtable->canCreate () && NULL == $row;
        }

    public function requiresId ()
        {
        return false;
        }

    }

class TruncateIcon extends RemoveIcon
    {
    public function __construct ($component)
        {
        parent::__construct ($component, "remove", $component->getText ("Remove all records"));
        }

    public function isVisible ($row = NULL)
        {
        if (NULL == $row)
            return false;
        $tableId = $row[MetaDataTables::COL_TABLEID];
        $contentTable = ContentTable::createInstanceById ($this->context, $tableId);
        if (empty ($contentTable))
            return false;
        return $contentTable->canDelete () && $contentTable->tableExists ();
        }

    public function execute ($request, $ids)
        {
        $tableId = $ids[0][0];
        $contentTable = ContentTable::createInstanceById ($this->context, $tableId);
        if (empty ($contentTable))
            {
            $this->component->addError ("Did not find a table.");
            return true;
            }

        if (false === $contentTable->deleteTable ())
            {
            $this->component->addError ("Truncating table failed.");
            return true;
            }

        $this->component->addMessage ("Table was successfully truncated - all records were removed.");
        return true;
        }
        
    public function getConfirmationString ($row)
        {
        if (NULL == $row)
            return $this->context->getForJS ("Do you realy wish to remove all the records in those tables?");
        else
            return $this->context->getForJS ("Do you realy wish to remove all the records in this table?");
        }
    }

?>

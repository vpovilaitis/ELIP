<?php
require_once (PATH.'inc/instanceeditor.php');
require_once (PATH.'admin/columnspreview.php');
require_once (PATH.'admin/indexespreview.php');
require_once (PATH.'admin/columneditor.php');
require_once (PATH.'admin/dropdown.php');
require_once (PATH.'inc/multiroweditor.php');

class MetaTableEditor extends InstanceEditor
    {
    protected $nameColumn;
    protected $descColumn;
    protected $colsEditor;
    protected $handlerColumn;
    protected $parentColumn;
    protected $revisionsColumn;
    protected $sourcesColumn;
    protected $ownerDeleteColumn;
    
    const DEFAULT_COLUMN_COUNT = 3;

    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new MetaDataTables ($context);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        if (!$this->initializeTemplateParts ($request, $isCreating))
            return NULL;

        $commonFields = array ($this->parentColumn, $this->labelColumn,
                               $this->nameColumn, $this->descColumn,
                               $this->handlerColumn, $this->revisionsColumn,
                               $this->sourcesColumn, $this->ownerDeleteColumn,
                               $this->integrColumn,
                               $this->parentSortColumn, $this->parentSortAscColumn,
                               );
        if ($isCreating)
            {
            $commonFields[] = $this->colsEditor;
            return $commonFields;
            }
        else
            {
            
            foreach ($this->getIds () as $idCol => $idVal)
                {
                $id = $idVal;
                break;
                }

            $this->addComponent ($request, "columns", new ColumnsPreview ($this->context, $id));
            $this->addComponent ($request, "indexes", new IndexesPreview ($this->context, $id));
            return $commonFields;
            }
        }

    protected function getPageTemplateDir ()
        {
        return "admin";
        }

    protected function initializeTemplateParts ($request, $isCreating)
        {
        if (NULL != $this->nameColumn)
            return false;

        $tableExists = false;
        $tableId = 0;
        if (!$this->isCreating ())
            {
            $tableId = $this->getIds ();
            $tableId = $tableId[0];

            $contentTable = ContentTable::createInstanceById ($this->context, $tableId);
            if (empty ($contentTable))
                {
                $this->addError ("Table not defined");
                }
            else
                $tableExists = $contentTable->tableExists ();

            if ($tableExists)
                $this->addMessage ("Content table already created, so name is no longer editable.");
            }

        $prefix = $this->getPrefix ();
        $columnTemplate = ColumnEditor::createTemplateFields ($this, $prefix, $isCreating, $tableExists, true);

        $availableTables = $this->getTableList ($tableId);
        $this->parentColumn = new DropDownFieldTemplate ($prefix, MetaDataTables::COL_PARENTID,
                                                         $this->getText ("Parent table:"),
                                                         $this->getText ("A name used to create a database table."),
                                                         $availableTables);

        $this->nameColumn = new TextFieldTemplate ($prefix, MetaDataTables::COL_NAME, $this->getText ("Table name:"), $this->getText ("A name used to create a database table."), 24);

        $this->labelColumn = new TextFieldTemplate ($prefix, MetaDataTables::COL_LABEL, $this->getText ("Title:"), $this->getText ("User friendly table label."), 24);
        $this->descColumn = new TextFieldTemplate ($prefix, MetaDataTables::COL_DESCRIPTION, $this->getText ("Description:"), $this->getText ("Brief table description."), 48);
        $this->handlerColumn = new TextFieldTemplate ($prefix, MetaDataTables::COL_HANDLER, $this->getText ("Custom handler:"), $this->getText ("Custom class handling all table related pages."), 48);
        $this->revisionsColumn = new CheckBoxFieldTemplate ($prefix, MetaDataTables::COL_REVISIONS, $this->getText ("Keep revisions:"), $this->getText ("Keep all the changes made to table's content as separate revisions."));
        $this->sourcesColumn = new CheckBoxFieldTemplate ($prefix, MetaDataTables::COL_SOURCES, $this->getText ("Track source:"), $this->getText ("Asks for source (coment) and date on every change."));
        $this->ownerDeleteColumn = new CheckBoxFieldTemplate ($prefix, MetaDataTables::COL_OWNERCANREMOVE, $this->getText ("Creator can delete:"), $this->getText ("If checked, the user which have created the record can delete this record even if delete permissions are not granted."));
        $this->integrColumn = new TextFieldTemplate ($prefix, MetaDataTables::COL_INTEGRATED,
                                                     $this->getText ("Section name:"),
                                                     $this->getText ("If instance is integrated into parent (show as part of parent in view mode), enter section template."), 48);
        $this->parentSortColumn = new IntFieldTemplate ($prefix, MetaDataTables::COL_PARENTSORTORDER, $this->getText ("Parent sort order:"), $this->getText ("If parent is included in sort columns, enter sort order."));
        $this->parentSortAscColumn = new CheckBoxFieldTemplate ($prefix, MetaDataTables::COL_PARENTSORTASC, $this->getText ("Parent sort ascending:"), $this->getText ("If parent is included in sort columns, choose if sorted by parent ascending  or descending."));

        if (!$isCreating && $tableExists)
            {
            $this->parentColumn->readonly = true;
            $this->nameColumn->readonly = true;
            $this->revisionsColumn->readonly = true;
            $this->sourcesColumn->readonly = true;
            }

        $colCount = isset ($request["colcount"]) ? $request["colcount"] : 0;
        if ($colCount <= 0)
            $colCount = self::DEFAULT_COLUMN_COUNT;

        $this->colsEditor = new MultiRowEditor ($this->context, $prefix, "cols", $this->getText ("Columns:"), $columnTemplate, $colCount);
        return true;
        }

    protected function getTableList ($tableId)
        {
        $result = array (0 => $this->getText ("<none>"));

        $columns = array (MetaDataTables::COL_TABLEID, MetaDataTables::COL_NAME,
                          MetaDataTables::COL_LABEL);
        $criteria = array ();
        if ($tableId > 0)
            $criteria[] = new NotEqCriterion (MetaDataTables::COL_TABLEID, $tableId);
        $rows = $this->dbtable->selectBy ($columns, $criteria);
        if (empty ($rows))
            return $result;

        foreach ($rows as $row)
            {
            $description = $row[MetaDataTables::COL_NAME];
            if (isset ($row[MetaDataTables::COL_LABEL]))
                $description = $this->getText ("[_1] (table \"[_0]\")", $description, $row[MetaDataTables::COL_LABEL]);
            $result[$row[MetaDataTables::COL_TABLEID]] = $description;
            }

        return $result;
        }

    protected function modifyRecord ($request, $id, $values)
        {
        $initialValues = $this->getInitialValues ();
        $values[MetaDataTables::COL_OPTIONS] = $options = 3;//$initialValues[MetaDataTables::COL_OPTIONS];
        $optionColumns = array (MetaDataTables::OPTION_REVISIONS => $this->revisionsColumn,
                                MetaDataTables::OPTION_SOURCES => $this->sourcesColumn,
                                MetaDataTables::OPTION_OWNERREMOVE => $this->ownerDeleteColumn,
                                );
        foreach ($optionColumns as $mask => $field)
            {
            if (!$field->readonly)
                continue;

            $values[$field->key] = $mask == ($options & $mask);
            }

        parent::modifyRecord ($request, $id, $values);
        }


    protected function createRecord (&$request, $values)
        {
        $this->initializeTemplateParts ($request, true);
        
        if (empty ($values[$this->nameColumn->key]))
            {
            $this->addError ("Table name is a required field");
            return false;
            }
        
        $columns = array ();
        foreach ($values[$this->colsEditor->key] as $columnRow)
            {
            $columns[] = ColumnEditor::prepareColumnFromEnteredValues ($this, $columnRow);
            }

        if (count ($columns) == 0)
            {
            $this->addError ("There should be at least one column defined for the table");
            return false;
            }

        $id = $this->dbtable->create ($values[$this->parentColumn->key],
                                      $values[$this->nameColumn->key],
                                      $values[$this->labelColumn->key],
                                      $values[$this->descColumn->key],
                                      $values[$this->handlerColumn->key],
                                      NULL,
                                      $values[$this->revisionsColumn->key],
                                      $values[$this->sourcesColumn->key],
                                      $values[$this->ownerDeleteColumn->key],
                                      $columns);
        if (false === $id)
            {
            $this->addError ("Error creating a meta table");
            return false;
            }

        $this->setMode (false, $id);
        return true;
        }

    public function getPageTitle ($isCreating = false)
        {
        return $isCreating ? $this->getText ("Creating a new metatable") : $this->getText ("Editing metatable");
        }

    protected function addSafeguardCriterion (&$criteria, $initialValues, $key)
        {
        if ($key == $this->revisionsColumn->key ||
            $key == $this->sourcesColumn->key ||
            $key == $this->ownerDeleteColumn->key)
            {
            return;
            }

        parent::addSafeguardCriterion ($criteria, $initialValues, $key);
        }

    protected function valueChanged ($initialValues, $key, $newValue)
        {
        if ($key == $this->revisionsColumn->key ||
            $key == $this->sourcesColumn->key ||
            $key == $this->ownerDeleteColumn->key)
            {
            return true;
            }

        return parent::valueChanged ($initialValues, $key, $newValue);
        }
    }


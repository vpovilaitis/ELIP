<?php

require_once (PATH.'inc/preview.php');
require_once (PATH.'inc/urlicon.php');
require_once (PATH.'admin/metatableicons.php');

class MetaDataPreview extends Preview
    {
    public function __construct ($context)
        {
        parent::__construct ("metadata", $context, new MetaDataTables ($context));
        }

    public function getTemplateName ()
        {
        return "metadatapreview";
        }

    public function getTitle ()
        {
        return $this->getText ("Meta tables");
        }

    protected function getDisplayTemplate ()
        {
        return array
            (
            new LabelFieldTemplate ("md", MetaDataTables::COL_LABEL, $this->context->getText ('Title')),
            new LabelFieldTemplate ("md", MetaDataTables::COL_NAME, $this->context->getText ('Table')),
            new LabelFieldTemplate ("md", MetaDataTables::COL_DESCRIPTION, $this->context->getText ('Description')),
            new LabelBoolFieldTemplate ("md", MetaDataTables::COL_REVISIONS, $this->context->getText ('Rev.')),
            new LabelBoolFieldTemplate ("md", MetaDataTables::COL_SOURCES, $this->context->getText ('Cite')),
            );
        }

    public function processInput ($context, &$request)
        {
        if (!parent::processInput ($context, $request))
            return false;

        if (isset ($request["add"]))
            {
            $this->context->redirect ($request["createlink"]."&action=new&colcount=".$request["colcount"]."&".$this->getPrefix ()."_page=".$this->getPage());
            return false;
            }

        return true;
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if ($new)
            return NULL;

        if (empty ($editorLink))
            $editorLink = "admin/MetaTableEditor";
        if (empty ($title))
            $title = $this->getText ("Edit metatable");
        return parent::getEditorAction ($new, $title, $editorLink, $params);
        }

    public function getActionList ()
        {
        return array_merge
            (
            parent::getActionList (),
            array
                (
                new SingleRowURLIcon ($this, "browse", $this->_("View all records"),
                                      "index.php?c=ContentPreviewPage&action=edit"),
                new ExportIcon ($this),
                new TruncateIcon ($this),
                )
            );
        }

    public function getAdditionalActions ()
        {
        $ret = parent::getAdditionalActions ();
        if ($this->dbtable->canCreate ())
            {
            $ret[] = new ImportIcon ($this, $this->dbtable);
            }

        return $ret;
        }

    }

?>

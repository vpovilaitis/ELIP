<?php

require_once (PATH.'inc/instanceeditor.php');

class MetaDataImport extends InstanceEditor
    {
    protected $fileField;
    const PARAM_FILE = "file";

    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->fileField = new FileFieldTemplate ("mi", self::PARAM_FILE,
                                   $this->getText ("File name:"),
                                   $this->getText ("Select a file to import structure from."));

        }

    public function isCreating ()
        {
        return true;
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        return array ($this->fileField);
        }

    protected function createRecord (&$request, $values)
        {
        $filepath = $this->fileField->getFilePath ($request);
        if (empty ($filepath))
            {
            $this->addMessage ("Please select a file to import structure from");
            return false;
            }
        return MetaExport::importFromFile ($this->context, $filepath);
        }

    public function processInput ($context, &$request)
        {
        if (!parent::processInput ($context, $request))
            return false;

        return true;
        }

    public function checkAccess ($request)
        {
        return $this->context->canCreate (Constants::TABLES_META, MetaDataTables::TABLE_NAME);
        }

    public function getPageTitle ($isCreating = false)
        {
        return $this->getText ("Import meta tables");
        }
    }

?>

<?php

class UserEditor extends InstanceEditor
    {
    protected $userNameColumn;
    protected $nameColumn;
    protected $descColumn;
    protected $passwordColumn;

    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new UsersTable ($context);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        $this->initializeTemplateParts ($request);
        if ($isCreating)
            {
            return array
                (
                $this->userNameColumn,
                $this->descColumn,
                $this->emailColumn,
                $this->passwordColumn,
                );
            }
        else
            {
            $this->userNameColumn->readonly = true;
            return array
                (
                $this->userNameColumn,
                $this->descColumn,
                $this->emailColumn,
                );
            }
        }

    protected function initializeTemplateParts ($request)
        {
        if (NULL != $this->nameColumn)
            return;

        $prefix = "g";

        $this->userNameColumn = new TextFieldTemplate ($prefix, UsersTable::COL_NAME, $this->getText ("User name:"), _("Non-translatable user name."), 32);
        $this->descColumn = new TextFieldTemplate ($prefix, UsersTable::COL_DESCRIPTION, _("User description:"), _("A short description of the user."), 64);
        $this->emailColumn = new TextFieldTemplate ($prefix, UsersTable::COL_EMAIL, _("E-mail:"), _("E-mail of the user."), 32);
        $this->passwordColumn = new PasswordFieldTemplate ($prefix, UsersTable::COL_PASSWORD, _("Password:"), _("Password used to login into a site."), 32);
        }

    protected function createRecord (&$request, $values)
        {
        $this->initializeTemplateParts ($request);
        $id = $this->dbtable->create ($values[$this->userNameColumn->key],
                                      $values[$this->descColumn->key],
                                      $values[$this->emailColumn->key],
                                      $values[$this->passwordColumn->key]);
        if (false === $id)
            {
            $this->addError ("Error creating a new user");
            return false;
            }

        $this->setMode (false, $id);
        return true;
        }

    public function getPageTitle ($isCreating = false)
        {
        return $isCreating ? $this->getText ("Adding a new user") : $this->getText ("Editing the user");
        }
    }

?>

<?php

require_once (PATH.'inc/preview.php');
require_once (PATH.'inc/urlicon.php');

class IndexesPreview extends Preview
    {
    protected $tableId;

    public function __construct ($context, $tableId)
        {
        parent::__construct ("idx", $context, new MetaDataIndexes ($context));
        if (empty ($tableId))
            $this->log ("Table id not set for IndexesPreview");
        $this->tableId = $tableId;
        }

    protected function getDisplayTemplate ()
        {
        return array
            (
            new LabelFieldTemplate ("idx", MetaDataIndexes::COL_DESCRIPTION, $this->context->getText ('Description')),
            new LabelFieldTemplate ("idx", MetaDataIndexes::COL_TYPE, $this->context->getText ('Type')),
            new LabelFieldTemplate ("idx", MetaDataIndexes::COL_COLUMNNAMES, $this->context->getText ('Index columns')),
            );
        }

    public function getTitle ()
        {
        return $this->getText ("Table indexes");
        }

    public function processInput ($context, &$request)
        {
        if (!parent::processInput ($context, $request))
            return false;

        return true;
        }

    protected function getFilterCriteria ()
        {
        return array (new EqCriterion (MetaDataColumns::COL_TABLEID, $this->tableId));
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if (empty ($editorLink))
            $editorLink = "admin/IndexEditor";
        if (empty ($title))
            $title = $new ? $this->getText ("Add new metatable index") : $this->getText ("Modify metatable index");
        return parent::getEditorAction ($new, $title, $editorLink, $new ? "id={$this->tableId}" : NULL);
        }

    }

?>

<?php

require_once (PATH.'inc/preview.php');
require_once (PATH.'inc/urlicon.php');

class ChangeComponentOrderIcon extends ChangeOrderIcon
    {
    public function __construct ($component, $key, $up)
        {
        parent::__construct ($component, $key, $up);
        }

    public function execute ($request, $ids)
        {
        $handler = new MetaDataComponents ($this->context);
        list ($pageId, $componentId) = $ids[0];
        $ret = $handler->changeOrder ($pageId, $componentId, $this->up);
        if (false === $ret)
            $this->component->log ("Error changing component order");
        return true;
        }
    }

class PageComponentsPreview extends Preview
    {
    protected $pageId;

    public function __construct ($context, $pageId)
        {
        parent::__construct ("pieces", $context, new MetaDataComponents ($context));
        $this->pageId = $pageId;
        }

    public function getTitle ()
        {
        return $this->getText ("Page components");
        }

    protected function getDisplayTemplate ()
        {
        return array
            (
            new LabelFieldTemplate ("pc", MetaDataComponents::COL_LABEL, $this->context->getText ('Title')),
            new LabelFieldTemplate ("pc", MetaDataComponents::COL_NAME, $this->context->getText ('Name')),
            new LabelFieldTemplate ("pc", MetaDataComponents::COL_TYPE, $this->context->getText ('Handler')),
            new LabelFieldTemplate ("pc", MetaDataComponents::COL_ZONEID, $this->context->getText ('Zone')),
            new LabelFieldTemplate ("pc", MetaDataComponents::COL_TABLEID, $this->context->getText ('Target table')),
            new LabelFieldTemplate ("pc", MetaDataComponents::COL_DESCRIPTION, $this->context->getText ('Description')),
            );
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if (empty ($editorLink))
            $editorLink = "admin/ComponentEditor";
        if (empty ($title))
            $title = $new ? $this->getText ("Add new page component") : $this->getText ("Modify page component");
        return parent::getEditorAction ($new, $title, $editorLink, $new ? "id=$this->pageId" : NULL);
        }

    protected function getFilterCriteria ()
        {
        return array (new EqCriterion (MetaDataComponents::COL_PAGEID, $this->pageId));
        }

    public function getActionList ()
        {
        return array_merge
            (
            parent::getActionList (),
            array
                (
                new ChangeComponentOrderIcon ($this, "up", true),
                new ChangeComponentOrderIcon ($this, "down", false),
                )
            );
        }

    }

?>

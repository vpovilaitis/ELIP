<?php
require_once (PATH.'inc/instanceeditor.php');

class SettingEditor extends InstanceEditor
    {
    protected $nameColumn;
    protected $translatableColumn;
    protected $valueColumn;
    
    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new SiteSettings ($context);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        if (!$this->initializeTemplateParts ($request, $isCreating))
            return NULL;

        $commonFields = array ($this->nameColumn,
                               $this->translatableColumn,
                               $this->valueColumn
                               );
        return $commonFields;
        }

    protected function getPageTemplateDir ()
        {
        return "admin";
        }

    protected function initializeTemplateParts ($request, $isCreating)
        {
        if (NULL != $this->nameColumn)
            return false;

        $prefix = "s";

        $this->nameColumn = new TextFieldTemplate ($prefix, SiteSettings::COL_NAME, $this->getText ("Setting:"), $this->getText ("A name of the site setting."), 24);
        $this->translatableColumn = new CheckBoxFieldTemplate ($prefix, SiteSettings::COL_TRANSLATABLE, $this->getText ("Translatable:"), $this->getText ("Does value depend on the language used?"));
        $this->valueColumn = new TextFieldTemplate ($prefix, SiteSettings::COL_VALUE, $this->getText ("Value:"), $this->getText ("Value of the named setting."), 24);

        if (!$isCreating)
            {
            $this->nameColumn->readonly = true;
            $this->translatableColumn->readonly = true;
            }

        return true;
        }

    public function getPageTitle ($isCreating = false)
        {
        return $isCreating ? $this->getText ("Adding a new site setting") : $this->getText ("Editing site setting value");
        }
    }

?>

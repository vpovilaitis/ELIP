<?php
require_once (PATH.'inc/general.php');
require_once (PATH.'inc/page.php');
require_once (PATH.'admin/userspreview.php');
require_once (PATH.'admin/metadatauipreview.php');
require_once (PATH.'admin/settingspreview.php');

class AdminHome extends ReaderPage
    {
    public function __construct ($context)
        {
        parent::__construct ($context, _("Administrate site"), "meta", Constants::ANY, "admin");
        $context->addStyleSheet ("admin");
        }

    protected function getDisplayParams ($request)
        {
        $params = array
            (
            "returnTo" => "&".Constants::PARAM_RETURN_TO."=".rawurlencode($_SERVER['REQUEST_URI']),
            );

        return array_merge (parent::getDisplayParams ($request), $params);
        }

    public function processInput ($context, &$request)
        {
        $this->addComponent ($request, "metatables", new MetaDataPreview ($context));
        $this->addComponent ($request, "settings", new SettingsPreview ($context));
        $this->addComponent ($request, "groups", new GroupsPreview ($context));
        $this->addComponent ($request, "users", new UsersPreview ($context));
        return true;
        }

    public function getPageTemplateDir ()
        {
        return "admin";
        }

    public function getTemplateName ()
        {
        return "admin";
        }
    }

?>

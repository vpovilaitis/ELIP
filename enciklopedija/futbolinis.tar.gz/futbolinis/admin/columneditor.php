<?php
require_once (PATH.'inc/instanceeditor.php');
require_once (PATH.'admin/dropdown.php');

class ColumnEditor extends InstanceEditor
    {
    protected $fields;

    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new MetaDataColumns ($context);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        if (!$this->initializeTemplateParts ($request, $isCreating))
            return NULL;
        return $this->fields;
        }

    public static function createTemplateFields ($component, $prefix, $isCreating, $tableExists, $compact = false)
        {
        $nameColumn = new TextFieldTemplate ($prefix, MetaDataColumns::COL_NAME,
                                             $component->getText ("Column name:"),
                                             $component->getText ("A name used to create a column in the database."),
                                             $compact ? 10 : 24);
        $labelColumn = new TextFieldTemplate ($prefix, MetaDataColumns::COL_LABEL,
                                              $component->getText ("Label:"),
                                              $component->getText ("User friendly label."),
                                              $compact ? 10 : 24);
        $descColumn = new TextFieldTemplate ($prefix, MetaDataColumns::COL_DESCRIPTION,
                                             $component->getText ("Description:"),
                                             $component->getText ("Brief column description."),
                                             $compact ? 10 : 48);

        $typesColumn = new TypesDropDownFieldTemplate ($component->getContext(), $prefix, MetaDataColumns::COL_TYPE);

        $categories = array
            (
            MetaDataColumns::CATEGORY_PRIMARY => $component->getText ("Primary"),
            MetaDataColumns::CATEGORY_DETAILS => $component->getText ("Details"),
            MetaDataColumns::CATEGORY_ADDITIONAL => $component->getText ("Additional"),
            MetaDataColumns::CATEGORY_GENERATED => $component->getText ("System (invisible)"),
            );
        $categoryColumn = new DropDownFieldTemplate ($prefix, MetaDataColumns::COL_CATEGORY,
                                                     $component->getText ("Category:"),
                                                     $component->getText ("Display category (primary columns displayed in preview, details displayed in view mode)"),
                                                     $categories);

        $requiredColumn = new CheckBoxFieldTemplate ($prefix, MetaDataColumns::COL_REQUIRED,
                                                     $component->getText ("Required"), 
                                                     $component->getText ("Is the value in the column required or optional."));

        $translatableColumn = new CheckBoxFieldTemplate ($prefix, MetaDataColumns::COL_TRANSLATABLE,
                                                         $component->getText ("Transl."), 
                                                         $component->getText ("Value of this column is not language-neutral (can be translated)."));

        $sortOrderColumn = new IntFieldTemplate ($prefix, MetaDataColumns::COL_SORTORDER,
                                                 $component->getText ("Sort order:"),
                                                 $component->getText ("If used as sort column, sort priority."));

        if (!$isCreating && $tableExists)
            {
            $nameColumn->readonly = true;
            $typesColumn->readonly = true;
            $translatableColumn->readonly = true;
            }
        if ($tableExists)
            {
            $requiredColumn->readonly = true; // values will not be filed to the existing rows, so not required
            }

        $arr = array ($labelColumn, $nameColumn, $typesColumn,
                      $categoryColumn, $requiredColumn, $translatableColumn,
                      $descColumn, $sortOrderColumn);

        $arr[] = new TextFieldTemplate ($prefix, MetaDataColumns::COL_DEFAULTVALUE,
                                        $component->getText ("Default value:"),
                                        $component->getText ("Default value or composite column display pattern."),
                                        $compact ? 10 : 48);

        if (!$compact)
            {
            $arr[] = new TextFieldTemplate ($prefix, MetaDataColumns::COL_RELATIONNAME,
                                            $component->getText ("Relation label:"),
                                            $component->getText ("Text to display in related value preview."),
                                            64);

            $types = array
                (
                MetaDataColumns::DISPLAY_NONE => $component->getText ("Do not show in related table"),
                MetaDataColumns::DISPLAY_PREVIEW => $component->getText ("Preview in related table"),
                MetaDataColumns::DISPLAY_SECTIONS => $component->getText ("Inject into related table as sections"),
                );
            $arr[] = new DropDownFieldTemplate ($prefix, MetaDataColumns::COL_DISPLAYTYPE,
                                                $component->getText ("Display type:"),
                                                $component->getText ("How to display in related table."),
                                                $types);
            $types = array
                (
                MetaDataColumns::INPUT_DROPDOWN => $component->getText ("Dropdown"),
                MetaDataColumns::INPUT_AUTOCOMPLETE => $component->getText ("Edit field with autosuggest (requires JavaScript)"),
                );
            $arr[] = new DropDownFieldTemplate ($prefix, MetaDataColumns::COL_INPUTTYPE,
                                                $component->getText ("Input type:"),
                                                $component->getText ("The way in which values are entered in the field."),
                                                $types);
            }

        return $arr;
        }

    protected function initializeTemplateParts ($request, $isCreating)
        {
        $tableId = $this->getParentId (true);
        $contentTable = ContentTable::createInstanceById ($this->context, $tableId);
        if (empty ($contentTable))
            {
            $this->addError ("Table not defined");
            return false;
            }

        $tableExists = $contentTable->tableExists ();
        if (!$isCreating && $tableExists)
            $this->addMessage ("Content table already created, so some of the column properties are not editable.");

        $prefix  = "col";
        $this->fields = self::createTemplateFields ($this, $prefix, $isCreating, $tableExists);

        return true;
        }

    protected function getDBTableColumns ()
        {
        $cols = parent::getDBTableColumns ();
        $cols[] = MetaDataColumns::COL_SIZE;
        return $cols;
        }

    protected function retrieveExisting ($request, $id)
        {
        $columnList = $this->dbtable->selectColumns ($id[0], $id[1]);
        if (empty ($columnList))
            return false;

        $tableId = $this->getParentId (true);

        foreach ($columnList as $column)
            {
            $row = array ();
            $row[MetaDataColumns::COL_TABLEID] = $tableId;
            $row[MetaDataColumns::COL_COLUMNID] = $column->id;
            $row[MetaDataColumns::COL_NAME] = $column->name;
            $row[MetaDataColumns::COL_LABEL] = $column->label;
            $row[MetaDataColumns::COL_DESCRIPTION] = $column->description;
            $row[MetaDataColumns::COL_TYPE] = TypesDropDownFieldTemplate::formatValue ($column);
            $row[MetaDataColumns::COL_REQUIRED] = $column->required;
            $row[MetaDataColumns::COL_TRANSLATABLE] = $column->translatable;
            $row[MetaDataColumns::COL_CATEGORY] = $column->category;
            $row[MetaDataColumns::COL_DISPLAYTYPE] = $column->displayType;
            $row[MetaDataColumns::COL_INPUTTYPE] = $column->inputType;
            $row[MetaDataColumns::COL_SORTORDER] = $column->sortOrder;
            $row[MetaDataColumns::COL_DEFAULTVALUE] = $column->defaultValue;
            if ($column->sortOrder > 0 && !$column->sortAsc)
                $row[MetaDataColumns::COL_SORTORDER] .= " DESC";
            $row[MetaDataColumns::COL_SORTASC] = $column->sortAsc;

            if (!empty ($column->relationName))
                $row[MetaDataColumns::COL_RELATIONNAME] = $column->relationName;
            else
                $row[MetaDataColumns::COL_RELATIONNAME] = NULL;

            return $row;
            }

        return false;
        }

    public static function prepareColumnFromEnteredValues ($component, $values)
        {
        if (empty ($values[MetaDataColumns::COL_NAME]))
            {
            $component->addError ("Column name is a required field");
            return false;
            }

        list ($isrelation, $val) = TypesDropDownFieldTemplate::parseValue ($values[MetaDataColumns::COL_TYPE]);
        if ($isrelation)
            {
            $column = new RelationColumn ($values[MetaDataColumns::COL_NAME],
                                          $values[MetaDataColumns::COL_LABEL],
                                          $values[MetaDataColumns::COL_DESCRIPTION],
                                          $values[MetaDataColumns::COL_REQUIRED]);
            $column->relatedTableId = $val;
            if (isset ($values[MetaDataColumns::COL_RELATIONNAME]))
                $column->relationName = $values[MetaDataColumns::COL_RELATIONNAME];
            }
        else
            {
            $column = new ValueColumn ($values[MetaDataColumns::COL_NAME],
                                       $values[MetaDataColumns::COL_LABEL],
                                       $values[MetaDataColumns::COL_DESCRIPTION],
                                       $values[MetaDataColumns::COL_REQUIRED]);
            $column->translatable = $values[MetaDataColumns::COL_TRANSLATABLE];
            $column->setType ($val);
            }

        $column->category = $values[MetaDataColumns::COL_CATEGORY];
        $sortOrder = $values[MetaDataColumns::COL_SORTORDER];

        if (isset ($values[MetaDataColumns::COL_DEFAULTVALUE]))
            $column->defaultValue = $values[MetaDataColumns::COL_DEFAULTVALUE];
        if (isset ($values[MetaDataColumns::COL_DISPLAYTYPE]))
            $column->displayType = $values[MetaDataColumns::COL_DISPLAYTYPE];
        if (isset ($values[MetaDataColumns::COL_INPUTTYPE]))
            $column->inputType = $values[MetaDataColumns::COL_INPUTTYPE];

        if (preg_match ("/([0-9]+) (asc|desc)/", strtolower ($sortOrder), $matches))
            {
            $column->sortOrder = $matches[1];
            $column->sortAsc = $matches[2] == "asc";
            }
        else if (is_numeric ($sortOrder))
            {
            $column->sortOrder = $sortOrder;
            $column->sortAsc = true;
            }

        return $column;
        }

    protected function createRecord (&$request, $values)
        {
        $column = self::prepareColumnFromEnteredValues ($this, $values);
        $tableId = $this->getParentId (true);

        $contentTable = ContentTable::createInstanceById ($this->context, $tableId);
        if (empty ($contentTable))
            {
            $this->addError ("Table not defined");
            return false;
            }

        $id = $contentTable->addColumn ($column);
        if (false === $id)
            {
            $this->addError ("Could not create a column");
            return false;
            }

        $this->setMode (false, $id);
        return true;
        }

    protected function modifyRecord ($request, $id, $values)
        {
        $adjustedValues = $values;
        if (isset ($values[MetaDataColumns::COL_TYPE]))
            {
            list ($isrelation, $val) = TypesDropDownFieldTemplate::parseValue ($values[MetaDataColumns::COL_TYPE]);
            $adjustedValues[MetaDataColumns::COL_ISRELATION] = $isrelation;

            if ($isrelation)
                {
                $adjustedValues[MetaDataColumns::COL_TYPE] = NULL;
                $adjustedValues[MetaDataColumns::COL_RELATEDTABLEID] = $val;
                }
            else if (strlen ($val) == ereg ("([^\(]+)\(([0-9]+)\)", $val, $regs))
                {
                $adjustedValues[MetaDataColumns::COL_TYPE] = $regs[1];
                $adjustedValues[MetaDataColumns::COL_SIZE] = $regs[2];
                }
            else
                {
                $adjustedValues[MetaDataColumns::COL_TYPE] = $val;
                $adjustedValues[MetaDataColumns::COL_SIZE] = 0;
                }
            }

        if (isset ($values[MetaDataColumns::COL_SORTORDER]))
            {
            $sortOrder = $values[MetaDataColumns::COL_SORTORDER];
    
            if (preg_match ("/([0-9]+) (asc|desc)/", strtolower ($sortOrder), $matches))
                {
                $adjustedValues[MetaDataColumns::COL_SORTORDER] = $matches[1];
                $adjustedValues[MetaDataColumns::COL_SORTASC] = $matches[2] == "asc";
                }
            else if (is_numeric ($sortOrder))
                {
                $adjustedValues[MetaDataColumns::COL_SORTORDER] = $sortOrder;
                $adjustedValues[MetaDataColumns::COL_SORTASC] = true;
                }
            }

        return parent::modifyRecord ($request, $id, $adjustedValues);
        }

    protected function addSafeguardCriterion (&$criteria, $initialValues, $key)
        {
        }

    public function getPageTitle ($isCreating = false)
        {
        return $isCreating ? $this->getText ("Adding a new metatable column") : $this->getText ("Modifying the column");
        }
    }

<?php
define ("PATH", "./");
define ("SHORT_CONTEXT", false);
require_once (PATH.'inc/load.php');
require_once (PATH.'h/facebookservice.php');

if (isset($context->request[Constants::PARAM_RETURN_TO]))
    $returnTo = $context->request[Constants::PARAM_RETURN_TO];
else if ($context->renderInline ())
    $returnTo = $context->getInlineContentUrl ("login.php");
else
    $returnTo = PATH."index.php";

$context->setTitle (_("Site Logout"));

// include custom page load scripts (if any)
@include PATH.'inc/pageloaded.php';

$fbApp = FacebookService::getInstance ();
$facebookId = $fbApp->getUser();
if ($context->logout () > 0)
    {
    session_destroy ();
    $context->redirect ($returnTo);
    exit();
    }

?>
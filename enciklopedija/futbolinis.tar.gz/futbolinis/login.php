<?php
define ("PATH", "./");
define ("SHORT_CONTEXT", false);
require_once (PATH.'inc/load.php');
require_once (PATH.'h/facebookservice.php');

define ('PARAM_USER', 'usr');
define ('PARAM_PASS', 'pwd');
define ('PARAM_PERSIST', 'persist');

class Login extends ReaderPage
    {
    private $uniqueId;
    private $facebookId;

    public function __construct ($context)
        {
        parent::__construct ($context, $context->getText("Site Login"), NULL);
        $this->uniqueId = uniqid();
        }

    public function getTemplateName ()
        {
        return "login";
        }

    public function getUniqueId ()
        {
        return $this->uniqueId;
        }

    public function isInline ()
        {
        return $this->context->renderInline ();
        }

    public function processInput ($context, &$request)
        {
        define ('PARAM_REDIRECT', Constants::PARAM_RETURN_TO);
        if ($this->isInline ())
            $returnTo = $context->processUrl ("index.php?c=CurrentUser", true);
        else if (!empty ($request[PARAM_REDIRECT]))
            $returnTo = $request[PARAM_REDIRECT];
        else
            $returnTo = PATH."index.php";
        
        $context->setErrorTarget ($this);
        $associate = !empty ($request["associate"]) ? $request["associate"] : false;

        if (!$associate && $context->getCurrentUser () > 0)
            {
            $context->redirect ($returnTo);
            return false;
            }

        $fbApp = FacebookService::getInstance ();
        $this->facebookId = $fbApp->getUser();
        if ($this->facebookId)
            {
            if ($this->ensureFacebookAccount ($fbApp, $associate))
                {
                $context->redirect ($returnTo);
                return false;
                }
            }

        if ($context->isBlocked ())
            {
            $context->displayNoAccessError ();
            }

        $user = isset($request[PARAM_USER]) ? $request[PARAM_USER] : "";
        $pass = isset($request[PARAM_PASS]) ? $request[PARAM_PASS] : "";
        $persist = isset($request[PARAM_PERSIST]) ? $request[PARAM_PERSIST] : 0;
        
        $registerUrl = $context->processUrl ("index.php?c=CreateUser", true);
        
        $params = array ('PARAM_USER' => $user,
                        'PARAM_PASS' => "",
                        'PARAM_PERSIST' => $persist,
                        'PARAM_REDIRECT' => $returnTo,
                        'textRegister' => $context->getText ("Not registered? Follow <a href='[_0]'>this link to register</a>.", $registerUrl)
                        );

        foreach ($params as $param => $val)
            {
            $request[$param] = $val;
            }

        if (isset($request[PARAM_USER]))
            {
            if (0 == strlen ($user))
                {
                $context->addError ("Please provide a valid user name.");
                return true;
                }
        
            if (!$context->login ($user, $pass, $persist))
                {
                $context->addError ("User name and password do not match.");
                return true;
                }
        
            $context->redirect ($returnTo);
            return false;
            }

        return true;
        }

    protected function ensureFacebookAccount ($fbApp, $associate)
        {
        try
            {
            if ($this->context->openIdLogin ("http://facebook.com", $this->facebookId))
                return true;

            $me = $fbApp->api('/me');//, array ("fields" => "name,link"));
            array ($me["name"], $me["link"]);
            if ($associate)
                $userId = $this->context->getCurrentUser ();
            else
                {
                $usersTable = new UsersTable ($this->context);
                $userId = $usersTable->create ($me["name"], $me["name"], !empty ($me["email"]) ? $me["email"] : NULL, false);
                if (!$userId)
                    {
                    $userId = $usersTable->create ($me["name"], $me["name"], NULL, false);
                    $index = 1;
                    while (!$userId)
                        {
                        $index++;
                        $userId = $usersTable->create ($me["name"]." ($index)", $me["name"], !empty ($me["email"]) && $index < 3 ? $me["email"] : NULL, false);
                        if ($index > 4)
                            break;
                        }
                    }
                }

            if (!$userId)
                {
                $this->context->addError ("Error creating user record. User with same name might already exist");
                return false;
                }

            $dbtable = new OpenIdTable ($this->context);
            if (false === $dbtable->createUserId ($userId, "http://facebook.com", $this->facebookId, $me["name"], $me["link"]))
                {
                $this->context->addError ("Error creating user record.");
                return false;
                }

            $fbPicture = "https://graph.facebook.com/{$this->facebookId}/picture";
            if (!empty ($fbPicture))
                {
                $subDir = realpath (USER_UPLOAD_DIR)."/openid";
                if (!is_dir ($subDir) && !mkdir ($subDir))
                    return true;

                $fname = "fb$userId.jpg";
                copy ($fbPicture, $subDir.'/'.$fname);
                }

            return true;
            }
        catch (FacebookApiException $e)
            {
            $result = $e->getResult();
            $this->context->addErrorPrepared ($e->getMessage ());
            $this->facebookId = NULL;
            return false;
            }
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function getEncourageFacebookText ()
        {
        return $this->context->getText ("Have a Facebook account?");
        }
    public function getFacebookLoginUrl ()
        {
        $fbApp = FacebookService::getInstance ();
        if (!$this->facebookId)
            {
            if (isset($this->request[PARAM_REDIRECT]))
                $returnTo = $this->request[PARAM_REDIRECT];
            else if ($this->context->renderInline ())
                $returnTo = $this->context->processUrl ("loginSuccess.html", true);
            else
                $returnTo = NULL;
            $params = "";
            $perm = NULL;
            if (!empty ($this->request["perm"]))
                {
                $perm = $this->request["perm"];
                $params .= "perm=$perm&";
                }

            return $fbApp->getLoginUrl(array ('scope' => $perm, 'display' => 'popup', 'redirect_uri' => $this->context->processUrl ("login.php?$params".Constants::PARAM_RETURN_TO."=".rawurlencode ($returnTo), true)));
            }
        return $fbApp->getLogoutUrl(array ('next' => $this->context->processUrl ("logout.php", true)));
        }
    public function getFacebookUser ()
        {
        $fbApp = FacebookService::getInstance ();
        return $this->facebookId;
        }
    public function getEncourageLoginText ()
        {
        return $this->context->getText ("Not the first time here?");
        }
    public function getLoginText ()
        {
        return $this->context->getText ("Login|dialog");
        }
    public function getLogoutText ()
        {
        return $this->context->getText ("Logout");
        }

    public function getRegistrationText ()
        {
        return $this->context->getText ("Not registered yet?");
        }
    public function getRegistrationLabel ()
        {
        return $this->context->getText ("Register Now");
        }
    public function getRegistrationUrl ()
        {
        $inline = $this->context->renderInline () ? "&".Constants::PARAM_RENDER_MODE."=".PageContext::RENDER_INLINE : "";
        return $this->context->processUrl ("index.php?c=CreateUser$inline", true);
        }
    }

$instance = new Login ($context, $context->request);

$instance->ensureTitle ($context, $context->request);

// include custom page load scripts (if any)
@include PATH.'inc/pageloaded.php';

$instance->process ($context->request);

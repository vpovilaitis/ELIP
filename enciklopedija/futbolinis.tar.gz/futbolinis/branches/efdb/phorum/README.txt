To add Phorum support:
    * get the Phorum version at http://www.phorum.org/ (5.2.9 should be ok)
    * extract the archive phorum-5.2.9.tar.gz
    * open file include/admin.install.php and navigate to following line
            $mods_initial = array (
      (it is line 282 in 5.2.9 version).
      After that line add the line 
                'futbolinis' => 1,
      and save the file.
    * copy contents of the phorum-5.2.9 (or whatever version) directory to
      the phorum subdirectory on website
    * make sure phorum/mods/futbolinis directory exists on the server.



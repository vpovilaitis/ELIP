<?php

if (!defined("PHORUM"))
    return;

require_once (PATH."inc/general.php");

function phorum_mod_futbolinis_user_list ($users)
    {
    $page = PageContext::getInstance ($_REQUEST);
    $page->log ("phorum_mod_futbolinis_user_list");
    return $users;
    }

function phorum_mod_futbolinis_user_authenticate ($auth)
    {
    $page = PageContext::getInstance ($_REQUEST);
    $page->log ("phorum_mod_futbolinis_user_authenticate");

    if (!$page->login ($auth["username"], $auth["password"]))
        {
        $auth["user_id"] = FALSE;
        return $auth;
        }

    $page->log ($auth["username"]." authenticated");
    if ($auth["type"] == PHORUM_ADMIN_SESSION)
        {
        /*
        $auth["user_id"] = FALSE;
        return $auth;
        */
        }

    $auth["user_id"] = $page->getCurrentUser();
    return $auth;
    }

function phorum_mod_futbolinis_user_session_create ($type)
    {
    $page = PageContext::getInstance ($_REQUEST);
    $page->log ("phorum_mod_futbolinis_user_session_create");
    if ($type == PHORUM_ADMIN_SESSION)
        return $type;

    if (!session_id())
        session_start();

    $phorum_user_id = $page->getCurrentUser();
    $_SESSION['phorum_user_id'] = $phorum_user_id;
    return NULL;
    }

function phorum_mod_futbolinis_user_session_restore ($sessions)
    {
    $page = PageContext::getInstance ($_REQUEST);
    $userId = $page->getCurrentUser();

    if ($userId > 0)
        {
        $page->log ("phorum_mod_futbolinis_user_session_restore $userId");
        $sessions[PHORUM_SESSION_LONG_TERM] = $userId;
        $sessions[PHORUM_SESSION_SHORT_TERM] = $userId;
        }
    else
        {
        $page->log ("phorum_mod_futbolinis_user_session_restore failed");
        $sessions[PHORUM_SESSION_LONG_TERM] = FALSE;
        $sessions[PHORUM_SESSION_SHORT_TERM] = FALSE;
        }

    return $sessions;
    }

function phorum_mod_futbolinis_user_session_destroy ($type)
    {
    $page = PageContext::getInstance ($_REQUEST);
    $page->log ("phorum_mod_futbolinis_user_session_destroy");
    if ($type == PHORUM_ADMIN_SESSION)
        return $type;

    if (!session_id())
        session_start();

    unset($_SESSION['phorum_user_id']);
    return NULL;
    }

?>

<?php
@include PATH."conf/dbconfig.php";

require_once (PATH."inc/languagelink.php");

$GLOBALS["Languages"] = array
    (
    new LanguageLink ("lt", "Lietuvių", NULL, "LT"),
    new LanguageLink ("en", "English", NULL, "EN"),
    );

$GLOBALS["PrimaryContentTables"] = array ();

$GLOBALS["ContentUrlTemplates"] = array ();

$GLOBALS["PersistedPages"] = array ("today", "editors", "toto", "home");

/*
    user.config.php (which is created only during deployment) contains site
    specific options (project title, footer, copyright, etc)
*/
@include PATH."conf/user.config.php";

$g_defaultValues = array
    (
    /*
        config.php file contains rarely changed generic configuration options
        (context size, etc).
    */
    "TEXTDOMAIN_CODESET" => "UTF-8",
    "PAGE_CHARSET" => "UTF-8",

    "PAGECONTEXTCLASS" => "PageContext",

    "PROJECT_NAME" => "-",
    
    "DEFAULT_DB_CLASS" => "MySqlConnection",
    "DEFAULT_DB_CLASS_INC" => "inc/mysqlconnection.php",

    /* uncomment following line if you want to override database default sort order */
    //  "DEFAULT_COLATE" => "utf8_lithuanian_ci",

    "SCRIPTS_VERSION" => "10.6.1",
    "CSS_VERSION" => "10.5.2",

    /* MySql table engine (recommended to use MyISAM which supports full text indexes) */
    "TABLE_ENGINE" => "MYISAM",

    /* Login cookie lifetime in minutes (default - 7 days) */
    "LOGIN_COOKIE_EXPIRATION" => 60*24*7,

    /* Page sizes */
    "DEFAULT_PAGESIZE" => 20,
    "SMALL_PAGESIZE" => 5, /* for compressed lists (metatables and groups in admin home page, etc) */
    "MATCHLIST_PAGESIZE" => 50,

    "DEBUG" => false,

    "COOKIE_PATH" => "",
    "COOKIE_DOMAIN" => "",

    /* If deployed on Apache and want to use search-engine friendly URLs, uncomment */
    //    "FRIENDLY_URL" => true,
    //    "BASE_URL" => "http://www.example.com/",

    "BASE_URL" => "",

    "SITE_SKIN" => "simple",
    "DEFAULT_SKIN_CSS" => true,
    "JQUERY_THEME" => NULL,

    "HOME_PAGE" => "home",

    "NAV_PAGES" => 3,

    'MIN_PASSWORD_LEN' => 8,

    "PRIMARY_COUNTRY" => NULL,
    "NATIONAL_TEAMS" => NULL,
    
    /*
    To override default component factory set
    "COMPONENT_FACTORY" => "DBMapFactory",
    */

    // Default group for newly registered users
    "DEFAULT_GROUP" => NULL,

    // when filtering Rss content by date, how many days should be included
    "RSS_MAX_DAYS" => 3,

    // site can access database by using the different perspective
    "SITE_PERSPECTIVE" => "*",

    "USER_UPLOAD_DIR" => PATH."userimg",
    "IMAGE_CACHE_DIR" => PATH."userimg/cache",
    "MAX_IMAGE_SIZE" => 2560*1920,

    "LOG_USAGE" => false,
    "SLOW_PAGE_TIME" => 2,
    "SLOW_QUERY_TIME" => 0.5,
    
    "MATCH_PREDICTOR_ENABLED" => false,
    "MATCH_REFEREE_RATINGS_ENABLED" => false,

    // RegEx to filter span posted in discussions (if span is suspected, captcha should be shown) 
    "BLACLIST_FILTER" => "#(http|://)#",
    
    "ALLOW_INVASIVE_ATP" => false,
    "FAVICON" => "/favicon.ico",

    "FACEBOOK_APP_ID" => NULL,
    "FACEBOOK_SECRET" => NULL,

    "COMPETITIONS_TO_EXCLUDE" => "",
    "UNSPECIFIED_COMPETITION_ID" => 0,

    "SIMPLIFIED_TEAM_LABELS" => false,
    );

foreach ($g_defaultValues as $param => $val)
    {
    if (!defined ($param))
        define ($param, $val);
    }

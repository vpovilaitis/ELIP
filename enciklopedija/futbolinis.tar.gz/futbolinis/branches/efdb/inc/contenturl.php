<?php

class ContentUrl
    {
    protected $dbtable = NULL;

    public static function createViewLink ($context, $dbtable, $ids, $params = NULL)
        {
        return self::createLink ($context, $dbtable, $dbtable->getId (), $ids, Constants::MODE_VIEW, $params);
        }

    public static function createLink ($context, $dbtable, $tableId, $ids, $mode = Constants::MODE_VIEW, $params = NULL)
        {
        if (empty ($ids))
            return NULL;

        if (is_array ($ids))
            $ids = implode ("_", $ids);

        if (is_array ($params))
            {
            $newParams = array ();
            foreach ($params as $key => $val)
                $newParams[] = "$key=$val";
            $params = implode ("&", $newParams);
            }

        if (Constants::MODE_VIEW == $mode)
            {
            $tableName = $dbtable->getName ();
            $overrides = $GLOBALS["ContentUrlTemplates"];
            if (!empty ($overrides[$tableName]))
                return formatText ($overrides[$tableName], $ids, $tableId, $context->getLanguage (), $params);
            }

        if (defined ("BASE_URL") && strlen (trim (BASE_URL, " /")) > 0)
            $basePath = trim (BASE_URL, " /")."/";
        else
            $basePath = PATH;

        if (Constants::MODE_EDIT != $mode && defined ("FRIENDLY_URL") && FRIENDLY_URL)
            {
            if (!empty ($dbtable))
                {
                $type = Constants::MODE_REVISIONS == $mode ? "rev" : "content";
                $url = $basePath."$type/".$dbtable->getName ()."/$ids/".$context->getLanguage ();
                if (!empty ($params))
                    $url .= "/$params";
                return $url;
                }
            }

        $url = $context->processUrl ($basePath."index.php?c=ContentPage&mode=$mode&tid=$tableId&id=$ids");
        if (!empty ($params))
            $url .= "&$params";
        return $url;
        }

    }

<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'inc/action.php');
require_once (PATH.'pages/fragmenteditortoolbar.php');
require_once (PATH.'pages/fragmenttemplate.php');

class PageFragment extends Page
    {
    protected $fragmentHierarchy;
    protected $subtitle;
    protected $editorMode;

    const EDITOR_MODE = "editorMode";
    const PARAM_PAGE = "page";

    public function __construct ($context, $fragmentHierarchy, $editorMode)
        {
        $this->editorMode = $editorMode;
        $this->fragmentHierarchy = $fragmentHierarchy;
        $row = $fragmentHierarchy->row;
        $title = $row[FragmentsTable::COL_TITLE];

        $this->subtitle = $desc = $row[FragmentsTable::COL_DESCRIPTION];
        if (!empty ($desc))
            {
            
            $context->setMetaParam ("Description", strip_tags ($desc));
            }

        $context->setPageScope (Constants::SCOPE_PAGE, $fragmentHierarchy->id);
        parent::__construct ($context, $title);
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function ensureChildren ($context, $request)
        {
        $component = self::createHierarchy ($context, $this->fragmentHierarchy, NULL);
        $this->addComponent ($request, "inner", $component, $this);
        return true;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function getActionList ()
        {
        $dbtable = new FragmentsTable ($this->context);
        $actions = array ();

        $pageName = $_REQUEST[self::PARAM_PAGE];
        if (empty ($pageName))
            $pageName = HOME_PAGE;

        if ($dbtable->canEdit ())
            {
            $isEditorMode = $this->isEditorMode ();
            $url = "index.php?".self::PARAM_PAGE."=$pageName";
            if (!$isEditorMode)
                {
                $url .= "&".self::EDITOR_MODE."=true";
                $title = $this->getText ("Edit layout");
                }
            else
                $title = $this->getText ("Exit editor");

            $actions[] = new SimpleLinkAction ($this, "edit", $title, $url);
            }

        $discussionstable = new DiscussionsTable ($this->context);
        if ($discussionstable->canRead ())
            {
            $url = $this->context->chooseUrl ("talk/pages/{$this->fragmentHierarchy->id}",
                                              "index.php?c=Discussions&sc=pages&id={$this->fragmentHierarchy->id}");
            $title = $this->getText ("Discussions");
            $actions[] = new SimpleLinkAction ($this, "discuss", $title, $url, true);
            }

        return $actions;
        }

    public function getTemplateName ()
        {
        return "page";
        }

    public function getSubTitle ()
        {
        return $this->subtitle;
        }

    /* Static class methods */

    public static function createHierarchy ($context, $hierarchy, $parentHierarchy)
        {
        $row = $hierarchy->row;
        $handlerClass = $row[FragmentsTable::COL_TYPE];
        $prefix = "p".$row[FragmentsTable::COL_ID];
        if ($handlerClass == FragmentsTable::TYPE_CONTAINER)
            {
            $instance = new ContainerFragment ($context, $hierarchy);
            if (!empty ($_REQUEST[PageFragment::EDITOR_MODE]))
                $instance = new FragmentEditorToolbar ($instance, $hierarchy, $parentHierarchy);
            return $instance;
            }

        $ret = findCustomHandlerFile ($context, "pages", $handlerClass);
        if (empty ($ret))
            {
            return new ErrorComponent ($prefix, $context,
                                       $context->getText ("Error loading component \"[_0]\" class [_1]", $prefix, $handlerClass));
            continue;
            }

        list ($className, $file) = $ret;
        require_once $file;

        $dbtable = NULL;
        if (!empty ($row[FragmentsTable::COL_TABLEID]))
            {
            $dbtable = ContentTable::createInstanceById ($context, $row[FragmentsTable::COL_TABLEID]);
            if (empty ($dbtable))
                {
                $result[] = new ErrorComponent ($prefix, $context,
                                                $context->getText ("Error loading component \"[_0]\" table", $prefix));
                continue;
                }
            }

        $instance = new $className ($context, $prefix, $dbtable,
                                    $row[FragmentsTable::COL_TITLE],
                                    $row[FragmentsTable::COL_DESCRIPTION],
                                    !empty ($row[FragmentsTable::COL_PARAMS]) ? $row[FragmentsTable::COL_PARAMS] : array ());

        if (!empty ($_REQUEST[PageFragment::EDITOR_MODE]))
            {
            $instance = new FragmentEditorToolbar ($instance, $hierarchy, $parentHierarchy);
            }

        return $instance;
        }

    public static function getHomePage ($context)
        {
        return self::getPage ($context, HOME_PAGE);
        }

    public function isEditorMode ()
        {
        return $this->editorMode;
        }

    public static function getPage ($context, $page)
        {
        $fragmentsTable = new FragmentsTable ($context);
        if (empty ($fragmentsTable))
            {
            $context->log ("Tables not created in the database");
            return NULL;
            }

        $editorMode = false;
        if ($fragmentsTable->canEdit ())
            $editorMode = !empty ($_REQUEST[self::EDITOR_MODE]);

        $fragmentHierarchy = $fragmentsTable->selectPageFragments ($page, $editorMode);
        if (empty ($fragmentHierarchy))
            {
            if (false !== $fragmentHierarchy && $editorMode && $fragmentsTable->canCreate ())
                {
                if (false !== $fragmentsTable->createPage ($page, NULL))
                    $fragmentHierarchy = $fragmentsTable->selectPageFragments ($page, $editorMode);

                if (empty ($fragmentHierarchy))
                    {
                    $context->log ("Unable to create the empty page");
                    return false;
                    }
                }
            else
                {
                $type = "SimpleText";

                $fragment = FragmentsTable::getPlaceholderFragment ($context);
                $fragment[FragmentsTable::COL_ID] = 0;
                $fragmentHierarchy = new PageFragmentNode ($fragment);
                }
            }

        return new PageFragment ($context, $fragmentHierarchy, $editorMode);
        }

    protected function getHintTargetGroup ()
        {
        $dbtable = new FragmentsTable ($this->context);
        if ($dbtable->canEdit ())
            return HintsTable::TARGET_EDITOR;
        return parent::getHintTargetGroup ();
        }

    protected function getHintScope ()
        {
        return HintsTable::SCOPE_PAGES;
        }

    protected function getHintContextMode ()
        {
        return !empty ($_REQUEST[self::EDITOR_MODE]) ? HintsTable::CONTEXT_EDIT : HintsTable::CONTEXT_VIEW;
        }

    protected function getHintContextId ()
        {
        return $this->fragmentHierarchy->id;
        }
    }

class ContainerFragment extends FragmentTemplate
    {
    protected $template;
    protected $title;
    protected $fragmentHierarchy;

    public function __construct ($context, $fragmentHierarchy)
        {
        $this->fragmentHierarchy = $fragmentHierarchy;
        $row = $fragmentHierarchy->row;
        $this->title = $row[FragmentsTable::COL_TITLE];
        $this->template = $row[FragmentsTable::COL_TEMPLATE];
        $prefix = "p".$row[FragmentsTable::COL_ID];
        parent::__construct ($context, $prefix, NULL, $row[FragmentsTable::COL_TITLE], $row[FragmentsTable::COL_DESCRIPTION],
                             !empty ($row[FragmentsTable::COL_PARAMS]) ? $row[FragmentsTable::COL_PARAMS] : array ());
        }

    public function ensureChildren ($context, $request)
        {
        $this->components = array ();
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if (empty ($this->fragmentHierarchy->children))
            return true;

        // add inner components
        foreach ($this->fragmentHierarchy->children as $child)
            {
            $component = PageFragment::createHierarchy ($context, $child, $this->fragmentHierarchy);

            $this->addComponent ($request, $component->prefix, $component, $this);
            }

        return true;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function getInnerTemplateName ()
        {
        return $this->template;
        }

    public function outline ()
        {
        $dbtable = new FragmentsTable ($this->context);
        if ($dbtable->canEdit ())
            return !empty ($_REQUEST[PageFragment::EDITOR_MODE]);
        return false;
        }

    public function getDisplayTemplateName ()
        {
        return $this->template;
        }

    public function getWidths ()
        {
        if (empty ($this->params["width"]))
            return NULL;
        $arr = preg_split ("#[,;]#", $this->params["width"]);
        return $arr;
        }

    protected function getAdditionalEditorFields ()
        {
        $arr = parent::getAdditionalEditorFields ();
        $arr[] = new FieldTemplate ("fld", "width", "text",
                                    $this->getText ("Children width:"),
                                    $this->getText ("Width in percentage of children objects (comma separated)"));

        return $arr;
        }

    }

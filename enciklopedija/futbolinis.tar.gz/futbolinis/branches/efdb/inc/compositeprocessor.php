<?php
require_once (PATH."inc/language.php");

class CompositeProcessor
    {
    protected $condition;
    protected $innerParts;
    
    public function __construct ($condition, $innerParts)
        {
        $this->condition = $condition;
        $this->innerParts = $innerParts;
        }

    public static function createInstance ($pattern, $dbtable, $tableAlias, &$columns, &$resultColumns, &$joins)
        {
        // if contains expressions, no need to process the pattern (child instances will handle everything)
        return self::preprocessInnerPatterns ($pattern, $dbtable, $tableAlias,
                                                  $columns, $resultColumns, $joins);
        }

    const OPEN_EXPRESSION = "(";
    const CLOSE_EXPRESSION = ")";
    const GROUP_SEPARATOR = "||";
    const CONDITION = "??";

    const OPEN = 1;
    const CLOSE = 2;
    const GROUP = 3;

    private static function preprocessInnerPatterns ($pattern, $dbtable, $tableAlias, &$columns, &$resultColumns, &$joins)
        {
        $openParentheses = 0;
        $pos = 0;
        $posEnd = -1;
        $lastSplit = 0;
        $splitParts = array ();
        $groups = false;

        while (true)
            {
            $posOpen = strpos ($pattern, self::OPEN_EXPRESSION, $pos);
            $posGroup = strpos ($pattern, self::GROUP_SEPARATOR, $pos);
            if (false === $posOpen && false === $posGroup && 0 === $openParentheses)
                break;

            $action = NULL;

            if ($openParentheses > 0)
                {
                if ($posEnd < $pos)
                    {
                    $posEnd = strpos ($pattern, self::CLOSE_EXPRESSION, $pos);
    
                    if (false === $posEnd)
                        break;
                    }

                if (false !== $posOpen && (false === $posEnd || $posEnd > $posOpen))
                    $action = self::OPEN;
                else
                    $action = self::CLOSE;
                }
            else if (false !== $posOpen && (false === $posGroup || $posGroup > $posOpen))
                $action = self::OPEN;
            else
                $action = self::GROUP;

            $curPos = -1;
            switch ($action)
                {
                case self::OPEN:
                    $curPos = $posOpen;
                    break;
                case self::CLOSE:
                    $curPos = $posEnd;
                    break;
                case self::GROUP:
                    $curPos = $posGroup;
                    break;
                }

            if ($curPos > 0)
                {
                $posEsc = strpos ($pattern, "\\", $pos);
                if (false !== $posEsc && $posEsc < $curPos)
                    {
                    $pos = $posEsc + 2;
                    continue;
                    }
                }

            switch ($action)
                {
                case self::OPEN:
                    {
                    $pos = $posOpen + strlen (self::OPEN_EXPRESSION);
    
                    if (0 === $openParentheses && !$groups)
                        {
                        $splitParts[] = substr ($pattern, $lastSplit, $posOpen - $lastSplit);
                        $lastSplit = $pos;
                        }
    
                    $openParentheses++;
                    continue;
                    }
                case self::CLOSE:
                    {
                    $pos = $posEnd + strlen (self::CLOSE_EXPRESSION);
                    $openParentheses--;
    
                    if (!$groups && 0 === $openParentheses)
                        {
                        if ($posEnd - $lastSplit > 0)
                            $splitParts[] = substr ($pattern, $lastSplit, $posEnd - $lastSplit);
                        $lastSplit = $pos;
                        }
                    continue;
                    }
                case self::GROUP:
                    {
                    if (!$groups)
                        {
                        $splitParts = array (substr ($pattern, 0, $posGroup));
                        $groups = true;
                        }
                    else
                        $splitParts[] = substr ($pattern, $lastSplit, $posGroup - $lastSplit);
                    $pos = $posGroup + strlen (self::GROUP_SEPARATOR);
                    $lastSplit = $pos;
                    continue;
                    }
                }
            }

        if ($lastSplit > 0 && $lastSplit < strlen ($pattern))
            {
            $splitParts[] = substr ($pattern, $lastSplit);
            }

        $innerParts = array ();

        if ($groups)
            {
            foreach ($splitParts as $part)
                {
                $processor = CompositeProcessor::createInstance ($part, $dbtable, $tableAlias, $columns, $resultColumns, $joins);
                $innerParts[] = $processor;
                }

            return new CompositeGroupProcessor ($innerParts);
            }

        if (0 == $lastSplit)
            $resultPattern =& $pattern;
        else
            $resultPattern =& $splitParts[0];

        $pos = strpos ($resultPattern, self::CONDITION);

        $condition = NULL;
        if (false !== $pos)
            {
            $condition = trim (substr ($resultPattern, 0, $pos));
            $resultPattern = substr ($resultPattern, $pos + 2);
            }

        if (!empty ($condition))
            $condition = self::preprocessColumn ($condition, $dbtable, $tableAlias, $columns, $resultColumns, $joins);

        if (0 == $lastSplit)
            return new PatternProcessor ($condition, $pattern, $dbtable, $tableAlias, $columns, $resultColumns, $joins);
        
        foreach ($splitParts as $part)
            {
            $processor = CompositeProcessor::createInstance ($part, $dbtable, $tableAlias, $columns, $resultColumns, $joins);
            $innerParts[] = $processor;
            }

        return new CompositeProcessor ($condition, $innerParts);
        }

    public static function preprocessColumn ($name, $dbtable, $tableAlias, &$columns, &$resultColumns, &$joins)
        {
        $parts = explode (".", $name, 2);
        if (2 == count ($parts))
            {
            $name = $parts[0];
            $relatedColumn = $parts[1];
            }

        $column = $dbtable->findColumn ($name);
        if ($column instanceof ValueColumn)
            {
            $columns[] = $column->columnDef->name;

            if (!empty ($tableAlias))
                $tablePrefix = $tableAlias.".";
            else
                $tablePrefix = "";

            $key = $tablePrefix.$column->columnDef->name;
            }
        else
            {
            $additional = NULL;
            if (!empty ($relatedColumn))
                $additional = $relatedColumn;
            else
                $relatedColumn = ContentTable::COL_DISPLAY_NAME;

            $key = $dbtable->createRelatedColumnQuery ($tableAlias,
                                                       "parent" == $name ? Constants::PARENT : $name,
                                                       $resultColumns,
                                                       $transformations, $additional, $joins);
            if (empty ($key))
                return NULL;
            }

        return $key;
        }

    public function getValue ($context, $transformations, $row)
        {
        if (!empty ($this->condition))
            {
            $val = $transformations[$this->condition]->getValue ($context, $transformations, $row);
            if (NULL === $val || false === $val)
                return NULL;
            }

        if (!empty ($this->innerParts))
            {
            $parts = array ();
            foreach ($this->innerParts as $part)
                {
                $parts[] = $part->getValue ($context, $transformations, $row);
                }
            return implode ("", $parts);
            }

        return NULL;
        }

    // for debuging purposes
    public function print_r ($return = false, $indent = "")
        {
        $str = "\n";
        $lines[] = $indent.get_class ($this);
        $lines[] = $indent."  Condition='$this->condition'";
        if (!empty ($this->pattern))
            $lines[] = $indent."  Pattern='$this->pattern'";

        $str .= implode ("\n", $lines);
        if (!empty ($this->innerParts))
            {
            $str .= "\n".$indent."  Inner patterns:";
            $str .= "\n".$indent."  {";

            foreach ($this->innerParts as $part)
                {
                $str .= $part->print_r (true, $indent."    ");
                }
            $str .= "\n".$indent."  }";
            }

        $str .+ "\n";
        if ($return)
            return $str;
        echo $str;
        }
    }

class CompositeGroupProcessor extends CompositeProcessor
    {
    public function __construct ($innerParts)
        {
        parent::__construct (NULL, $innerParts);
        }

    public function getValue ($context, $transformations, $row)
        {
        foreach ($this->innerParts as $part)
            {
            $val = $part->getValue ($context, $transformations, $row);
            if (NULL !== $val)
                return $val;
            }

        return NULL;
        }
    }

class PatternProcessor extends CompositeProcessor
    {
    protected $pattern;
    protected $replacements;
    protected $lng;
    
    public function __construct ($condition, $pattern, $dbtable, $tableAlias, &$columns, &$resultColumns, &$joins)
        {
        parent::__construct ($condition, NULL);
        $this->pattern = $pattern;

        if (preg_match_all ('@\{((?U).*)\}@', $pattern, $matches) <= 0)
            return;

        $this->replacements = array ();

        foreach (array_unique($matches[1]) as $col)
            {
            $name = $col;
            $parts = explode ("|", $col, 2);
            $modifier = NULL;
            if (2 == count ($parts))
                {
                $name = $parts[0];
                $modifier = $parts[1];
                }

            $key = self::preprocessColumn ($name, $dbtable, $tableAlias, $columns, $resultColumns, $joins);

            if (empty ($key))
                continue;

            $this->replacements['{'.$col.'}'] = array ($key, $modifier);
            }
        }

    public function getValue ($context, $transformations, $row)
        {
        if (!empty ($this->condition))
            {
            $val = $transformations[$this->condition]->getValue ($context, $transformations, $row);
            if (NULL === $val || false === $val)
                return NULL;
            }

        $pattern = $this->pattern;
        $search = array ();
        $replace = array ();
        if (!empty ($this->replacements))
            {
            foreach ($this->replacements as $key => $r)
                {
                list ($col, $modifier) = $r;
                $search[] = $key;

                if (!isset ($transformations[$col]))
                    {
                    $val = "<$col>";
                    }
                else
                    {
                    $val = $transformations[$col]->getValue ($context, $transformations, $row);

                    if (!empty ($transformations[$col]->column))
                        {
                        $column = $transformations[$col]->column;
                        if ($column instanceof NamedIntColumn)
                            $val = NamedIntColumn::getItem ($column, $val);
                        }

                    if (!empty ($modifier))
                        $val = $this->applyModifier ($context, $modifier, $val);
                    }
                $replace[] = $val;
                }
            }

        $search[]  = "\)";
        $replace[] = ")";

        $search[]  = "\(";
        $replace[] = "(";

        $pattern = str_replace ($search, $replace, $pattern);

        return $pattern;
        }

    protected function applyLanguageModifier ($context, $modifier, $value)
        {
        if (NULL === $this->lng)
            $this->lng = Language::getInstance ($context);

        $case = NULL;
        switch (strtolower (substr ($modifier, 0, 3)))
            {
            case "gen":
                $case = Language::CASE_GENITIVE;
                break;
            case "loc":
                $case = Language::CASE_LOCATIVE;
                break;
            case "acc":
                $case = Language::CASE_ACCUSATIVE;
                break;
            }

        return $this->lng->changeWordCase ($value, $case);
        }

    protected function applyDateTimeModifier ($context, $modifier, $value)
        {
        if (NULL === $this->lng)
            $this->lng = Language::getInstance ($context);

        $str = $this->lng->dateToString ($value, strtolower ($modifier));
        return $str;
        }

    protected function applyModifier ($context, $modifier, $value)
        {
        $parts = explode (":", $modifier, 2);

        $modifier = NULL;
        if (2 == count ($parts))
            $modifier = $parts[1];

        switch (strtolower ($parts[0]))
            {
            case "l":
                return $this->applyLanguageModifier ($context, $modifier, $value);
            case "d":
                return $this->applyDateTimeModifier ($context, $modifier, $value);
            }

        return $value;
        }

    }

?>
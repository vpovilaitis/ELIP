<?php

abstract class EditorTask extends BaseWithContext
    {
    const COMPLEXITY_SIMPLE = 3;
    const COMPLEXITY_MEDIUM = 5;
    const COMPLEXITY_COMPLEX = 7;

    const SORT_ASCENDING = 1;
    const SORT_DESCENDING = 2;
    const SORT_RANDOM = 3;

    public function __construct ($context, $className)
        {
        parent::__construct ($context);
        $this->baseName = $className;
        }

    public function getName ()
        {
        return get_class ($this);
        }

    public function getNameWithCount ()
        {
        return $this->getName (false)." - ".$this->getCountLabel();
        }

    public function getSortingSetting ()
        {
        return EditorTask::SORT_RANDOM;
        }

    public function getComplexityLabel ()
        {
        $complexity = $this->getComplexity ();
        switch ($complexity)
            {
            case self::COMPLEXITY_SIMPLE:
                return $this->getText ("Simple");
            case self::COMPLEXITY_MEDIUM:
                return $this->getText ("Average");
            case self::COMPLEXITY_COMPLEX:
                return $this->getText ("Complex");
            default:
                {
                if ($complexity > 0 && $complexity <= 10)
                    {
                    if ($complexity > self::COMPLEXITY_COMPLEX)
                        return $this->getText ("Extra complex");
                    else if ($complexity > self::COMPLEXITY_MEDIUM)
                        return $this->getText ("Tougher than average");
                    else if ($complexity > self::COMPLEXITY_SIMPLE)
                        return $this->getText ("Simplier than average");
                    else
                        return $this->getText ("Very simple");
                    }
                break;
                }
            }
        
        return $this->getText ("Unknown");
        }

    public function getComplexity ()
        {
        return self::COMPLEXITY_MEDIUM;
        }

    public function getTimeLabel ()
        {
        $time = $this->getTime ();
        if ($time > 0)
            return $this->getText ("[_0] min.", $time);
        return NULL;
        }
    public function getTime ()
        {
        return false;
        }

    public function getUrl ()
        {
        return $this->context->processUrl ("index.php?c=EditorTaskList&task=$this->baseName", true);
        }

    public function getImage ()
        {
        return $this->context->getResourcePath ("img", "metro-note.png");
        }

    public function getDescription ()
        {
        return NULL;
        }

    public function getInstructions ()
        {
        return NULL;
        }

    const LIMIT = 250;
    const LIMIT_SHOWN = 50;
    public function getCountLabel ()
        {
        $count = $this->getRemainingCount ();
        if (empty ($count))
            return $this->getText ("No tasks");
        if ($count >= self::LIMIT)
            return $this->ngettext ("More than [_0] task", "More than [_0] tasks", $count);
        return $this->ngettext ("[_0] task", "[_0] tasks", $count);
        }

    public function getList ($returnAll = false)
        {
        $cache = Cache::getInstance ($this->getCacheContext (), 6*60*60);
        $cacheKey = preg_replace ("#[/]#", "_", "tasks_{$this->baseName}");
        if (false === ($tasks = $cache->get ($cacheKey)))
            {
            $tasks = $this->selectTasks (self::LIMIT);
            $cache->save ($tasks, $cacheKey);
            }

        if ($returnAll || empty ($tasks))
            return $tasks;

        switch ($this->getSortingSetting ())
            {
            case EditorTask::SORT_RANDOM:
                shuffle ($tasks);
                break;
            case EditorTask::SORT_DESCENDING:
                $tasks = array_reverse ($tasks, true);
                break;
            }

        return array_slice ($tasks, 0, self::LIMIT_SHOWN);
        }

    public abstract function selectTasks ($limit);

    public function getCacheContext ()
        {
        return "tools";
        }

    public function getRemainingCount ()
        {
        $list = $this->getList (true);
        return count ($list);
        }

    public function createListComponent ($prefix, $context)
        {
        return new TaskList ($prefix, $context, $this);
        }
    }

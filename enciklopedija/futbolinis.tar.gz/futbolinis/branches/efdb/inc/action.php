<?php

/* Various action classes to be returned by getActionList (items in brackets are abstract):
    - [IconAction] (image with a post back, so the component needs to handle events)
        - [URLAction]
            - [URLIcon] (image which links to another page)
                - SingleRowURLIcon (requires an id)
                - AdditionalURLIcon (does not require an id)
            - PageIcon (navigate to some page)
            - PageSizeIcon (change size of a page in a list view)
            - PageSeparatorIcon
        - [ChangeOrderIcon] (requires an id)
        - ExportIcon
        - [RemoveIcon]
        - [NavigationIcon]
            - FirstPageIcon
            - PreviousPageIcon
            - NextPageIcon
            - LastPageIcon
    - [ButtonAction] (post back button)
    - [GenericButton] (post back button which does not need an id to work on)
    - [LinkAction] (a text link pointing to some URL, optionally has an image next to the link - use $icon property)
        - SingleRowURL (requires an id)
        - SimpleLinkAction (does not require an id)
        
*/
abstract class Action extends BaseWithContext
    {
    protected $component;
    protected $key;
    protected $tooltip;
    protected $disabled = false;

    public function __construct ($component, $key, $tooltip)
        {
        $context = $component->getContext ();
        parent::__construct ($context);

        $this->component = $component;
        $this->key = $key;
        $this->tooltip = $tooltip;
        }

    public function getParam ($row = NULL)
        {
        return $this->component->getActionParam ($this->key, $row);
        }

    public function getKey ()
        {
        return $this->key;
        }

    public function getTooltip ()
        {
        return $this->tooltip;
        }

    public function isDisabled ()
        {
        return $this->disabled;
        }

    public function disable ()
        {
        $this->disabled = true;
        }

    public abstract function canExecute ($request, $singleItemId = NULL);

    public abstract function isVisible ($row = NULL);

    public abstract function execute ($request, $ids);

    public abstract function getTemplateName ();

    public abstract function requiresId ();
    }

abstract class IconAction extends Action
    {
    protected $icon;

    public function __construct ($component, $key, $tooltip)
        {
        parent::__construct ($component, $key, $tooltip);
        $this->icon = $key;
        }

    public function getLabel ()
        {
        return $this->key;
        }

    public function getTemplateName ()
        {
        return "iconaction";
        }

    public function getIconPath ()
        {
        if ($this->disabled)
            return $this->context->getDisabledSmallIconPath ($this->icon);
        return $this->context->getSmallIconPath ($this->icon);
        }

    public function getClassName ()
        {
        return $this->disabled ? "actionbuttondisabled" : "actionbutton";
        }
    }

abstract class ButtonAction extends Action
    {
    protected $label;

    public function __construct ($component, $key, $label, $tooltip)
        {
        parent::__construct ($component, $key, $tooltip);
        $this->label = $label;
        }

    public function getLabel ()
        {
        return $this->label;
        }

    public function getClassName ()
        {
        return $this->disabled ? "actionbuttondisabled" : "actionbutton";
        }

    public function getTemplateName ()
        {
        return "buttonaction";
        }
    }

abstract class GenericButton extends ButtonAction
    {
    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function isVisible ($row = NULL)
        {
        return true;
        }

    public function requiresId ()
        {
        return false;
        }

    public function getClassName ()
        {
        return $this->disabled ? "buttondisabled" : "button";
        }
    }

<?php

require_once (PATH.'inc/usertables.php');
require_once (PATH.'inc/metatables.php');

function displayFromTemplate ($context, $class, $templateName, $params, $return = false)
    {
    require_once PATH.'smarty/Smarty.class.php';

    if (NULL != $class && strlen ($class) > 0)
        $class = "/$class";

    $smarty = new Smarty();
    $searchFor = explode (",", $context->getSkin ());
    if ("default" != $searchFor[count($searchFor)-1])
        $searchFor[] = "default";

    /* udocummented feature of Smarty:
       "If you assign an array of folders to $smarty->template_dir it will seach
        the folders in the order of the array until it finds the template"*/
    $smarty->template_dir = array ();
    foreach ($searchFor as $skin)
        {
        $skin = trim ($skin);
        $smarty->template_dir[] = PATH."templates/$skin$class";
        $smarty->template_dir[] = PATH."templates/$skin";
        }

    $smarty->compile_dir = PATH."smarty/templates_c/$skin$class";
    $smarty->cache_dir = PATH."smarty/cache/$skin$class";
    $smarty->config_dir = PATH."smarty/configs";
    $smarty->assign("context", $context);

    if (!file_exists ($smarty->compile_dir))
        mkdir ($smarty->compile_dir, 0777, true);
    if (!file_exists ($smarty->cache_dir))
        mkdir ($smarty->cache_dir, 0777, true);
    
    if (null != $params)
        {
        foreach ($params as $key => $val)
            $smarty->assign($key, $val);
        }

    if ($return)
        return $smarty->fetch("$templateName.tpl");
    else
        $smarty->display("$templateName.tpl");
    }

class ParamsHolder
    {
    protected $params;
    public function __construct ($params)
        {
        $this->params = $params;
        }

    protected function changeCase ($lng, $text, $modifier)
        {
        switch ($modifier)
            {
            case "loc":
                $text = $lng->changeWordCase ($text, Language::CASE_LOCATIVE);
                break;
            case "gen":
                $text = $lng->changeWordCase ($text, Language::CASE_GENITIVE);
                break;
            case "acc":
                $text = $lng->changeWordCase ($text, Language::CASE_ACCUSATIVE);
                break;
            }

        return $text;
        }

    public function replaceParam ($match)
        {
        if (!array_key_exists ($match[1], $this->params))
            return $match[0];

        if (!empty ($match[3]))
            {
            $lng = Language::getInstance (PageContext::getInstance ());
            $text = $this->params[$match[1]];
            // exception for links passed as parameters
            if (preg_match ("#^(<a .+>)(.*)(</a>)$#", $text, $linkMatch) > 0)
                return $linkMatch[1].$this->changeCase ($lng, $linkMatch[2], $match[3]).$linkMatch[3];

            return $this->changeCase ($lng, $text, $match[3]);
            }

        return $this->params[$match[1]];
        }
    }

function formatText ($translatedString)
    {
    $str = $translatedString;
    $numargs = func_num_args ();
    if (1 == $numargs)
        return $translatedString;

    if (is_array (func_get_arg (1)))
        $params = func_get_arg (1);
    else
        {
        $params = array ();
        for ($i = 0; $i < $numargs-1; $i++)
            $params[] = func_get_arg ($i+1);
        }

    if (NULL === $params[0])
        return $translatedString;

    $str = str_replace (array ("\\[", "\\]"), array ("ب", "ב"), $str);
    $str = preg_replace_callback ("/\[_([0-9])+(\|(gen|loc|acc))?\]/uU", array (new ParamsHolder ($params), "replaceParam"), $str);
    $str = str_replace (array ("ب", "ב"), array ("[", "]"), $str);

    return $str;
    }

function formatForHtml ($text)
    {
    return nl2br (htmlspecialchars ($text));
    }

function formatForJavaScript ($text)
    {
    $text = str_replace ("\n", "\\n", $text);
    $text = str_replace ("\r", "\\r", $text);
    $text = str_replace ("\"", "\\\"", $text);
    return "\"$text\"";
    }

function formatForAttr ($text)
    {
    $text = str_replace ("\"", "&quot;", $text);
    return $text;
    }

function findCustomHandlerFile ($context, $dir, $class)
    {
    if (empty ($class))
        {
        return NULL;
        }

    $strippedName = strrchr ($class, "/");
    if (false === $strippedName)
        $strippedName = $class;
    $className = trim ($strippedName, "/");
    $lng = strtoupper (substr ($context->getLanguage (), 0, 2));
    if (!empty ($dir))
        $dir = $dir."/";
    $file = PATH."$dir".trim (strtolower ($class))."$lng.php";
    if (!file_exists ($file))
        $file = PATH."$dir".trim (strtolower ($class)).".php";
    else
        $className .= $lng;

    if (!file_exists ($file))
        {
        $context->log ("Handler file ".PATH."$dir".trim (strtolower ($class)).".php"." not found");
        return NULL;
        }

    $context->log ("Custom handler $className from file $file");
    return array ($className, $file);
    }

function configurationStatus ($context)
    {
    if (!file_exists (PATH."conf/user.config.php"))
        return Constants::CONFIGSTATE_NOLANGUAGE;

    if (!file_exists (PATH."conf/dbconfig.php"))
        return Constants::CONFIGSTATE_NODB;

    $dbconn = $context->getConnection ();
    if (false === $dbconn)
        return Constants::CONFIGSTATE_BADCONNECTION;

    if (!UsersTable::isDeployed ($context, $dbconn))
        return Constants::CONFIGSTATE_NOUSER;

    if (!SiteSettings::isDeployed ($context))
        return Constants::CONFIGSTATE_NOSITESETTINGS;

    $status = Constants::CONFIGSTATE_READY;

    if (!MetaDataTables::isDeployed ($context, $dbconn))
        $status = Constants::CONFIGSTATE_NOMETADATA;

    // if administrator user is already created, but deployment not finished yet, go to login context
    if (Constants::CONFIGSTATE_READY != $status && $context->getCurrentUser() <= 0)
        $status = Constants::CONFIGSTATE_NEEDSLOGIN;
    return $status;
    }

function getConfigurationPageArray ()
    {
    return array (
                    Constants::CONFIGSTATE_NOLANGUAGE => "SelectLanguage",
                    Constants::CONFIGSTATE_NODB => "DBConfigStep",
                    Constants::CONFIGSTATE_NOUSER => "CreateAdminStep",
                    Constants::CONFIGSTATE_NOSITESETTINGS => "SiteSettingsPage",
                    Constants::CONFIGSTATE_NEEDSLOGIN => "LoginStep",
                    Constants::CONFIGSTATE_NOMETADATA => "ConfigureMetaData",
                 );
    }

function getConfigurationClassByStatus ($status)
    {
    $pages = getConfigurationPageArray ();
    foreach ($pages as $pageStatus => $className)
        {
        if ($pageStatus == $status)
            return $className;
        }

    return "";
    }

function getNextDeploymentStep ($context)
    {
    $status = Constants::CONFIGSTATE_READY;

    if (!defined ("NO_CHECK_STATUS"))
        $status = configurationStatus ($context);

    if (Constants::CONFIGSTATE_READY != $status)
        {
        if (Constants::CONFIGSTATE_BADCONNECTION == $status)
            {
            $context->displayErrorPage ($context->getText ("Failed to connect to the database"));
            }
        else
            return getConfigurationClassByStatus ($status);
        }

    return NULL;
    }

function getUtf8UpperToLowerMap ()
    { 
    global $UTF8_UPPER_TO_LOWER;
    if (empty ($UTF8_UPPER_TO_LOWER))
        {
        $UTF8_UPPER_TO_LOWER = array
            (
            /* Lithuanian */
            "Ž"=>"ž","Š"=>"š","Č"=>"č","Ū"=>"ū","Ų"=>"ų","Į"=>"į","Ė"=>"ė","Ę"=>"ę","Ą"=>"ą",
            /* Other */
            /*
            "ῼ"=>"ῳ","Ῥ"=>"ῥ","Ῡ"=>"ῡ","Ῑ"=>"ῑ","Ῐ"=>"ῐ","ῌ"=>"ῃ","Ι"=>"ι","ᾼ"=>"ᾳ","Ᾱ"=>"ᾱ",
            "Ᾰ"=>"ᾰ","ᾯ"=>"ᾧ","ᾮ"=>"ᾦ","ᾭ"=>"ᾥ","ᾬ"=>"ᾤ","ᾫ"=>"ᾣ","ᾪ"=>"ᾢ","ᾩ"=>"ᾡ","ᾟ"=>"ᾗ",
            "ᾞ"=>"ᾖ","ᾝ"=>"ᾕ","ᾜ"=>"ᾔ","ᾛ"=>"ᾓ","ᾚ"=>"ᾒ","ᾙ"=>"ᾑ","ᾘ"=>"ᾐ","ᾏ"=>"ᾇ","ᾎ"=>"ᾆ",
            "ᾍ"=>"ᾅ","ᾌ"=>"ᾄ","ᾋ"=>"ᾃ","ᾊ"=>"ᾂ","ᾉ"=>"ᾁ","ᾈ"=>"ᾀ","Ώ"=>"ώ",
            "Ὼ"=>"ὼ","Ύ"=>"ύ","Ὺ"=>"ὺ","Ό"=>"ό","Ὸ"=>"ὸ","Ί"=>"ί","Ὶ"=>"ὶ","Ή"=>"ή","Ὴ"=>"ὴ","Έ"=>"έ",
            "Ὲ"=>"ὲ","Ά"=>"ά","Ὰ"=>"ὰ","Ὧ"=>"ὧ","Ὦ"=>"ὦ","Ὥ"=>"ὥ","Ὤ"=>"ὤ","Ὣ"=>"ὣ","Ὢ"=>"ὢ","Ὡ"=>"ὡ",
            "Ὗ"=>"ὗ","Ὕ"=>"ὕ","Ὓ"=>"ὓ","Ὑ"=>"ὑ","Ὅ"=>"ὅ","Ὄ"=>"ὄ","Ὃ"=>"ὃ","Ὂ"=>"ὂ","Ὁ"=>"ὁ","Ὀ"=>"ὀ",
            "Ἷ"=>"ἷ","Ἶ"=>"ἶ","Ἵ"=>"ἵ","Ἴ"=>"ἴ","Ἳ"=>"ἳ","Ἲ"=>"ἲ","Ἱ"=>"ἱ","Ἰ"=>"ἰ","Ἧ"=>"ἧ","Ἦ"=>"ἦ",
            "Ἥ"=>"ἥ","Ἤ"=>"ἤ","Ἣ"=>"ἣ","Ἢ"=>"ἢ","Ἡ"=>"ἡ","Ἕ"=>"ἕ","Ἔ"=>"ἔ","Ἓ"=>"ἓ","Ἒ"=>"ἒ","Ἑ"=>"ἑ",
            "Ἐ"=>"ἐ","Ἇ"=>"ἇ","Ἆ"=>"ἆ","Ἅ"=>"ἅ","Ἄ"=>"ἄ","Ἃ"=>"ἃ","Ἂ"=>"ἂ","Ἁ"=>"ἁ","Ἀ"=>"ἀ","Ỹ"=>"ỹ",
            "Ỷ"=>"ỷ","Ỵ"=>"ỵ","Ỳ"=>"ỳ","Ự"=>"ự","Ữ"=>"ữ","Ử"=>"ử","Ừ"=>"ừ","Ứ"=>"ứ","Ủ"=>"ủ","Ụ"=>"ụ",
            "Ợ"=>"ợ","Ỡ"=>"ỡ","Ở"=>"ở","Ờ"=>"ờ","Ớ"=>"ớ","Ộ"=>"ộ","Ỗ"=>"ỗ","Ổ"=>"ổ","Ồ"=>"ồ","Ố"=>"ố",
            "Ỏ"=>"ỏ","Ọ"=>"ọ","Ị"=>"ị","Ỉ"=>"ỉ","Ệ"=>"ệ","Ễ"=>"ễ","Ể"=>"ể","Ề"=>"ề","Ế"=>"ế","Ẽ"=>"ẽ",
            "Ẻ"=>"ẻ","Ẹ"=>"ẹ","Ặ"=>"ặ","Ẵ"=>"ẵ","Ẳ"=>"ẳ","Ằ"=>"ằ","Ắ"=>"ắ","Ậ"=>"ậ","Ẫ"=>"ẫ","Ẩ"=>"ẩ",
            "Ầ"=>"ầ","Ấ"=>"ấ","Ả"=>"ả","Ạ"=>"ạ","Ṡ"=>"ẛ","Ẕ"=>"ẕ","Ẓ"=>"ẓ","Ẑ"=>"ẑ","Ẏ"=>"ẏ","Ẍ"=>"ẍ",
            "Ẋ"=>"ẋ","Ẉ"=>"ẉ","Ẇ"=>"ẇ","Ẅ"=>"ẅ","Ẃ"=>"ẃ","Ẁ"=>"ẁ","Ṿ"=>"ṿ","Ṽ"=>"ṽ","Ṻ"=>"ṻ","Ṹ"=>"ṹ",
            "Ṷ"=>"ṷ","Ṵ"=>"ṵ","Ṳ"=>"ṳ","Ṱ"=>"ṱ","Ṯ"=>"ṯ","Ṭ"=>"ṭ","Ṫ"=>"ṫ","Ṩ"=>"ṩ","Ṧ"=>"ṧ","Ṥ"=>"ṥ",
            "Ṣ"=>"ṣ","Ṡ"=>"ṡ","Ṟ"=>"ṟ","Ṝ"=>"ṝ","Ṛ"=>"ṛ","Ṙ"=>"ṙ","Ṗ"=>"ṗ","Ṕ"=>"ṕ","Ṓ"=>"ṓ","Ṑ"=>"ṑ",
            "Ṏ"=>"ṏ","Ṍ"=>"ṍ","Ṋ"=>"ṋ","Ṉ"=>"ṉ","Ṇ"=>"ṇ","Ṅ"=>"ṅ","Ṃ"=>"ṃ","Ṁ"=>"ṁ","Ḿ"=>"ḿ","Ḽ"=>"ḽ",
            "Ḻ"=>"ḻ","Ḹ"=>"ḹ","Ḷ"=>"ḷ","Ḵ"=>"ḵ","Ḳ"=>"ḳ","Ḱ"=>"ḱ","Ḯ"=>"ḯ","Ḭ"=>"ḭ","Ḫ"=>"ḫ","Ḩ"=>"ḩ",
            "Ḧ"=>"ḧ","Ḥ"=>"ḥ","Ḣ"=>"ḣ","Ḡ"=>"ḡ","Ḟ"=>"ḟ","Ḝ"=>"ḝ","Ḛ"=>"ḛ","Ḙ"=>"ḙ","Ḗ"=>"ḗ","Ḕ"=>"ḕ",
            "Ḓ"=>"ḓ","Ḑ"=>"ḑ","Ḏ"=>"ḏ","Ḍ"=>"ḍ","Ḋ"=>"ḋ","Ḉ"=>"ḉ","Ḇ"=>"ḇ","Ḅ"=>"ḅ","Ḃ"=>"ḃ","Ḁ"=>"ḁ",
            "Ֆ"=>"ֆ","Օ"=>"օ","Ք"=>"ք","Փ"=>"փ","Ւ"=>"ւ","Ց"=>"ց","Ր"=>"ր","Տ"=>"տ","Վ"=>"վ","Ս"=>"ս",
            "Ռ"=>"ռ","Ջ"=>"ջ","Պ"=>"պ","Չ"=>"չ","Ո"=>"ո","Շ"=>"շ","Ն"=>"ն","Յ"=>"յ","Մ"=>"մ","Ճ"=>"ճ",
            "Ղ"=>"ղ","Ձ"=>"ձ","Հ"=>"հ","Կ"=>"կ","Ծ"=>"ծ","Խ"=>"խ","Լ"=>"լ","Ի"=>"ի","Ժ"=>"ժ","Թ"=>"թ",
            "Ը"=>"ը","Է"=>"է","Զ"=>"զ","Ե"=>"ե","Դ"=>"դ","Գ"=>"գ","Բ"=>"բ","Ա"=>"ա","Ԏ"=>"ԏ","Ԍ"=>"ԍ",
            "Ԋ"=>"ԋ","Ԉ"=>"ԉ","Ԇ"=>"ԇ","Ԅ"=>"ԅ","Ԃ"=>"ԃ","Ԁ"=>"ԁ","Ӹ"=>"ӹ","Ӵ"=>"ӵ","Ӳ"=>"ӳ","Ӱ"=>"ӱ",
            "Ӯ"=>"ӯ","Ӭ"=>"ӭ","Ӫ"=>"ӫ","Ө"=>"ө","Ӧ"=>"ӧ","Ӥ"=>"ӥ","Ӣ"=>"ӣ","Ӡ"=>"ӡ","Ӟ"=>"ӟ","Ӝ"=>"ӝ",
            "Ӛ"=>"ӛ","Ә"=>"ә","Ӗ"=>"ӗ","Ӕ"=>"ӕ","Ӓ"=>"ӓ","Ӑ"=>"ӑ","Ӎ"=>"ӎ","Ӌ"=>"ӌ","Ӊ"=>"ӊ","Ӈ"=>"ӈ",
            "Ӆ"=>"ӆ","Ӄ"=>"ӄ","Ӂ"=>"ӂ","Ҿ"=>"ҿ","Ҽ"=>"ҽ","Һ"=>"һ","Ҹ"=>"ҹ","Ҷ"=>"ҷ","Ҵ"=>"ҵ","Ҳ"=>"ҳ",
            "Ұ"=>"ұ","Ү"=>"ү","Ҭ"=>"ҭ","Ҫ"=>"ҫ","Ҩ"=>"ҩ","Ҧ"=>"ҧ","Ҥ"=>"ҥ","Ң"=>"ң","Ҡ"=>"ҡ","Ҟ"=>"ҟ",
            "Ҝ"=>"ҝ","Қ"=>"қ","Ҙ"=>"ҙ","Җ"=>"җ","Ҕ"=>"ҕ","Ғ"=>"ғ","Ґ"=>"ґ","Ҏ"=>"ҏ","Ҍ"=>"ҍ","Ҋ"=>"ҋ",
            "Ҁ"=>"ҁ","Ѿ"=>"ѿ","Ѽ"=>"ѽ","Ѻ"=>"ѻ","Ѹ"=>"ѹ","Ѷ"=>"ѷ","Ѵ"=>"ѵ","Ѳ"=>"ѳ","Ѱ"=>"ѱ","Ѯ"=>"ѯ",
            "Ѭ"=>"ѭ","Ѫ"=>"ѫ","Ѩ"=>"ѩ","Ѧ"=>"ѧ","Ѥ"=>"ѥ","Ѣ"=>"ѣ","Ѡ"=>"ѡ","Џ"=>"џ","Ў"=>"ў","Ѝ"=>"ѝ",
            "Ќ"=>"ќ","Ћ"=>"ћ","Њ"=>"њ","Љ"=>"љ","Ј"=>"ј","Ї"=>"ї","І"=>"і","Ѕ"=>"ѕ","Є"=>"є","Ѓ"=>"ѓ",
            "Ђ"=>"ђ","Ё"=>"ё","Ѐ"=>"ѐ","Я"=>"я","Ю"=>"ю","Э"=>"э","Ь"=>"ь","Ы"=>"ы","Ъ"=>"ъ","Щ"=>"щ",
            "Ш"=>"ш","Ч"=>"ч","Ц"=>"ц","Х"=>"х","Ф"=>"ф","У"=>"у","Т"=>"т","С"=>"с","Р"=>"р","П"=>"п",
            "О"=>"о","Н"=>"н","М"=>"м","Л"=>"л","К"=>"к","Й"=>"й","И"=>"и","З"=>"з","Ж"=>"ж","Е"=>"е",
            "Д"=>"д","Г"=>"г","В"=>"в","Б"=>"б","А"=>"а","Ε"=>"ϵ","Σ"=>"ϲ","Ρ"=>"ϱ","Κ"=>"ϰ","Ϯ"=>"ϯ",
            "Ϭ"=>"ϭ","Ϫ"=>"ϫ","Ϩ"=>"ϩ","Ϧ"=>"ϧ","Ϥ"=>"ϥ","Ϣ"=>"ϣ","Ϡ"=>"ϡ","Ϟ"=>"ϟ","Ϝ"=>"ϝ","Ϛ"=>"ϛ",
            "Ϙ"=>"ϙ","Π"=>"ϖ","Φ"=>"ϕ","Θ"=>"ϑ","Β"=>"ϐ","Ώ"=>"ώ","Ύ"=>"ύ","Ό"=>"ό","Ϋ"=>"ϋ","Ϊ"=>"ϊ",
            "Ω"=>"ω","Ψ"=>"ψ","Χ"=>"χ","Φ"=>"φ","Υ"=>"υ","Τ"=>"τ","Σ"=>"σ","Σ"=>"ς","Ρ"=>"ρ","Π"=>"π",
            "Ο"=>"ο","Ξ"=>"ξ","Ν"=>"ν","Μ"=>"μ","Λ"=>"λ","Κ"=>"κ","Ι"=>"ι","Θ"=>"θ","Η"=>"η","Ζ"=>"ζ",
            "Ε"=>"ε","Δ"=>"δ","Γ"=>"γ","Β"=>"β","Α"=>"α","Ί"=>"ί","Ή"=>"ή","Έ"=>"έ","Ά"=>"ά","Ʒ"=>"ʒ",
            "Ʋ"=>"ʋ","Ʊ"=>"ʊ","Ʈ"=>"ʈ","Ʃ"=>"ʃ","Ʀ"=>"ʀ","Ɵ"=>"ɵ","Ɲ"=>"ɲ","Ɯ"=>"ɯ","Ɩ"=>"ɩ","Ɨ"=>"ɨ",
            "Ɣ"=>"ɣ","Ɛ"=>"ɛ","Ə"=>"ə","Ɗ"=>"ɗ","Ɖ"=>"ɖ","Ɔ"=>"ɔ","Ɓ"=>"ɓ","Ȳ"=>"ȳ","Ȱ"=>"ȱ","Ȯ"=>"ȯ",
            "Ȭ"=>"ȭ","Ȫ"=>"ȫ","Ȩ"=>"ȩ","Ȧ"=>"ȧ","Ȥ"=>"ȥ","Ȣ"=>"ȣ","Ȟ"=>"ȟ","Ȝ"=>"ȝ","Ț"=>"ț","Ș"=>"ș",
            "Ȗ"=>"ȗ","Ȕ"=>"ȕ","Ȓ"=>"ȓ","Ȑ"=>"ȑ","Ȏ"=>"ȏ","Ȍ"=>"ȍ","Ȋ"=>"ȋ","Ȉ"=>"ȉ","Ȇ"=>"ȇ","Ȅ"=>"ȅ",
            "Ȃ"=>"ȃ","Ȁ"=>"ȁ","Ǿ"=>"ǿ","Ǽ"=>"ǽ","Ǻ"=>"ǻ","Ǹ"=>"ǹ","Ǵ"=>"ǵ","ǲ"=>"ǳ","Ǯ"=>"ǯ","Ǭ"=>"ǭ",
            "Ǫ"=>"ǫ","Ǩ"=>"ǩ","Ǧ"=>"ǧ","Ǥ"=>"ǥ","Ǣ"=>"ǣ","Ǡ"=>"ǡ","Ǟ"=>"ǟ","Ǝ"=>"ǝ","Ǜ"=>"ǜ","Ǚ"=>"ǚ",
            "Ǘ"=>"ǘ","Ǖ"=>"ǖ","Ǔ"=>"ǔ","Ǒ"=>"ǒ","Ǐ"=>"ǐ","Ǎ"=>"ǎ","ǋ"=>"ǌ","ǈ"=>"ǉ","ǅ"=>"ǆ","Ƿ"=>"ƿ",
            "Ƽ"=>"ƽ","Ƹ"=>"ƹ","Ƶ"=>"ƶ","Ƴ"=>"ƴ","Ư"=>"ư","Ƭ"=>"ƭ","Ƨ"=>"ƨ","Ƥ"=>"ƥ","Ƣ"=>"ƣ","Ơ"=>"ơ",
            "Ƞ"=>"ƞ","Ƙ"=>"ƙ","Ƕ"=>"ƕ","Ƒ"=>"ƒ","Ƌ"=>"ƌ","Ƈ"=>"ƈ","Ƅ"=>"ƅ","Ƃ"=>"ƃ","S"=>"ſ",
            */
            "Ž"=>"ž",
            "Ż"=>"ż","Ź"=>"ź","Ŷ"=>"ŷ","Ŵ"=>"ŵ","Ų"=>"ų","Ű"=>"ű","Ů"=>"ů","Ŭ"=>"ŭ","Ū"=>"ū","Ũ"=>"ũ",
            "Ŧ"=>"ŧ","Ť"=>"ť","Ţ"=>"ţ","Š"=>"š","Ş"=>"ş","Ŝ"=>"ŝ","Ś"=>"ś","Ř"=>"ř","Ŗ"=>"ŗ","Ŕ"=>"ŕ",
            "Œ"=>"œ","Ő"=>"ő","Ŏ"=>"ŏ","Ō"=>"ō","Ŋ"=>"ŋ","Ň"=>"ň","Ņ"=>"ņ","Ń"=>"ń","Ł"=>"ł","Ŀ"=>"ŀ",
            "Ľ"=>"ľ","Ļ"=>"ļ","Ĺ"=>"ĺ","Ķ"=>"ķ","Ĵ"=>"ĵ","Ĳ"=>"ĳ","I"=>"ı","Į"=>"į","Ĭ"=>"ĭ","Ī"=>"ī",
            "Ĩ"=>"ĩ","Ħ"=>"ħ","Ĥ"=>"ĥ","Ģ"=>"ģ","Ġ"=>"ġ","Ğ"=>"ğ","Ĝ"=>"ĝ","Ě"=>"ě","Ę"=>"ę","Ė"=>"ė",
            "Ĕ"=>"ĕ","Ē"=>"ē","Đ"=>"đ","Ď"=>"ď","Č"=>"č","Ċ"=>"ċ","Ĉ"=>"ĉ","Ć"=>"ć","Ą"=>"ą","Ă"=>"ă",
            "Ā"=>"ā","Ÿ"=>"ÿ","Þ"=>"þ","Ý"=>"ý","Ü"=>"ü","Û"=>"û","Ú"=>"ú","Ù"=>"ù","Ø"=>"ø","Ö"=>"ö",
            "Õ"=>"õ","Ô"=>"ô","Ó"=>"ó","Ò"=>"ò","Ñ"=>"ñ","Ð"=>"ð","Ï"=>"ï","Î"=>"î","Í"=>"í","Ì"=>"ì",
            "Ë"=>"ë","Ê"=>"ê","É"=>"é","È"=>"è","Ç"=>"ç","Æ"=>"æ","Å"=>"å","Ä"=>"ä","Ã"=>"ã","Â"=>"â",
            "Á"=>"á","À"=>"à",
            /* ASCII */
            "Z"=>"z","Y"=>"y","X"=>"x","W"=>"w","V"=>"v","U"=>"u","T"=>"t",
            "S"=>"s","R"=>"r","Q"=>"q","P"=>"p","O"=>"o","N"=>"n","M"=>"m","L"=>"l","K"=>"k","J"=>"j",
            "I"=>"i","H"=>"h","G"=>"g","F"=>"f","E"=>"e","D"=>"d","C"=>"c","B"=>"b","A"=>"a"
            );
        }
    return $UTF8_UPPER_TO_LOWER;
    }

function getUtf8LowerToUpperMap ()
    {
    global $UTF8_LOWER_TO_UPPER;
    if (empty ($UTF8_LOWER_TO_UPPER))
        {
        $lowerToUpper = getUtf8UpperToLowerMap ();
        $UTF8_LOWER_TO_UPPER = array_combine (array_values ($lowerToUpper), array_keys ($lowerToUpper));
        }
    return $UTF8_LOWER_TO_UPPER;
    }

function utf8_strtolower ($string)
    { 
    $map = getUtf8UpperToLowerMap ();
    return preg_replace ("/([A-Z]|[\\xc0-\\xff][\\x80-\\xbf]*)/e", 
                         "strtr(\"\$1\" , \$map)", $string);
    }

function utf8_strtoupper ($string)
    { 
    $map = getUtf8LowerToUpperMap ();
    return strtr ($string, $map);
    }

function utf8_getchars ($string)
    {
    if (preg_match_all ("/(.)/uUm", $string, $matches) <= 0)
        return array ();
    return $matches[1];
    }

function utf8_substr ($string, $start, $length = NULL)
    {
    $string = str_replace ("~", "↑", $string);
    $string = str_replace ("\n", "~", $string);
    if ($start > 0)
        {
        preg_match ("/^.{{$start}}(.*)$/uU", $string, $match);
        if (empty ($match))
            return "";
        $string = $match[1];
        }

    if (NULL !== $length)
        {
        preg_match ("/^.{{$length}}/uU", $string, $match);
        if (!empty ($match))
            $string = $match[0];
        }

    $string = str_replace ("~", "\n", $string);
    $string = str_replace ("↑", "~", $string);
    return $string;
    }

function utf8_normalize ($string)
    {
    $string = utf8_strtolower (trim ($string));
    $search = explode(",", "ą,č,ę,ė,į,ı,š,ş,ų,ū,ż,ž,ç,ć,ł,ň,ţ,ğ,ý,á,ă,é,ē,í,ó,ú,à,è,ì,ò,ù,ä,ë,ï,ö,ü,ÿ,â,ê,î,ô,û,å,ā,e,i,ø,ã,õ,ð,ņ,ķ,ļ,þ,đ,æ,œ");
    $replace = explode(",","a,c,e,e,i,i,s,s,u,u,z,z,c,c,l,n,t,g,y,a,a,e,e,i,o,u,a,e,i,o,u,a,e,i,o,u,y,a,e,i,o,u,a,a,e,i,o,a,o,d,n,k,l,th,d,ae,oe");
    $string = str_replace ($search, $replace, $string);
    return $string;
    }
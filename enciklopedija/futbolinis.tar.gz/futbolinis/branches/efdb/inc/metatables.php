<?php
require_once (PATH.'inc/dbtable.php');
require_once (PATH.'inc/metadatacolumns.php');
require_once (PATH.'inc/metadataindexes.php');
require_once (PATH.'inc/metadatatables.php');

abstract class IExportedRow
    {
    public abstract function importTable ($context, $idMappings); // return created table id
    public abstract function getName ();
    public abstract function getId ();
    public abstract function getParentId ();
    }

class ExportedRowV1 extends IExportedRow
    {
    public $table;
    public $columns;
    public $name;
    public $id;
    
    public function importTable ($context, $idMappings)
        {
        $tablesHandler = new MetaDataTables ($context);
        $parentId = $this->getParentId ();
        if ($parentId > 0)
            $parentId = $idMappings[$parentId];

        $options = isset ($this->table[MetaDataTables::COL_OPTIONS]) ? $this->table[MetaDataTables::COL_OPTIONS] : 0;
        $id = $tablesHandler->create ($parentId, $this->name,
                                      NULL, NULL,
                                      $this->table[MetaDataTables::COL_HANDLER],
                                      $this->table[MetaDataTables::COL_VERSION],
                                      $options & MetaDataTables::OPTION_REVISIONS,
                                      $options & MetaDataTables::OPTION_SOURCES,
                                      array ());
        if (false === $id)
            {
            return false;
            }

        if (isset ($this->table[DBTable::COL_LANG]))
            {
            if (false === $this->importDescriptions ($tablesHandler, $id, $this->table[DBTable::COL_LANG]))
                return false;
            }

        return $id;
        }

    public function importColumns ($context, $idMappings)
        {
        $id = $idMappings[$this->id];
        $columnsHandler = new MetaDataColumns ($context);
        $addedColumns = array ();
        for ($i = 0; $i < count ($this->columns); $i++)
            {
            $col = $this->columns[$i];
            if (false !== array_search ($col[MetaDataColumns::COL_NAME], $addedColumns))
                {
                $context->addMessage ("Duplicate column name [_0]", $col[MetaDataColumns::COL_NAME]);
                continue;
                }

            if (!isset ($col[MetaDataColumns::COL_NAME]) || !isset ($col[MetaDataColumns::COL_TYPE]))
                {
                $context->addError ("Column name and type are required fields");
                return false;
                }

            $addedColumns[] = $col[MetaDataColumns::COL_NAME];

            if ($col[MetaDataColumns::COL_ISRELATION])
                {
                $column = new RelationColumn ($col[MetaDataColumns::COL_NAME],
                                              NULL,
                                              NULL,
                                              $col[MetaDataColumns::COL_REQUIRED]);
                $column->relatedTableId = $idMappings[$col[MetaDataColumns::COL_RELATEDTABLEID]];

                if (isset ($col[MetaDataColumns::COL_RELATIONNAME]))
                    $column->relationName = $col[MetaDataColumns::COL_RELATIONNAME];
                }
            else
                {
                $column = new ValueColumn ($col[MetaDataColumns::COL_NAME],
                                           NULL,
                                           NULL,
                                           $col[MetaDataColumns::COL_REQUIRED]);
                $column->translatable = $col[MetaDataColumns::COL_TRANSLATABLE];
                $column->columnDef = ColumnDefFactory::create ($col[MetaDataColumns::COL_TYPE],
                                                               $col[MetaDataColumns::COL_NAME],
                                                               $col[MetaDataColumns::COL_SIZE],
                                                               $col[MetaDataColumns::COL_PRECISION],
                                                               !$column->required,
                                                               $col[MetaDataColumns::COL_DEFAULTVALUE]);
                $column->columnDef->modifiers = $col[MetaDataColumns::COL_MODIFIERS];
                }

            if (isset ($col[MetaDataColumns::COL_CATEGORY]))
                $column->category = $col[MetaDataColumns::COL_CATEGORY];

            if (isset ($col[MetaDataColumns::COL_DISPLAYTYPE]))
                $column->displayType = $col[MetaDataColumns::COL_DISPLAYTYPE];

            if (isset ($col[MetaDataColumns::COL_INPUTTYPE]))
                $column->inputType = $col[MetaDataColumns::COL_INPUTTYPE];

            if (isset ($col[MetaDataColumns::COL_SORTORDER]))
                {
                $column->sortOrder = $col[MetaDataColumns::COL_SORTORDER];
                $column->sortAsc = $col[MetaDataColumns::COL_SORTASC];
                }

            $columnId = $i + 1;
            if (false === $columnsHandler->create ($id, $columnId, $column))
                return false;

            if (isset ($col[DBTable::COL_LANG]))
                {
                if (false === $this->importColumnDescriptions ($columnsHandler, $id, $columnId, $col[DBTable::COL_LANG]))
                    return false;
                }
            }

        return true;
        }

    public function importDescriptions ($tablesHandler, $id, $descriptions)
        {
        for ($i = 0; $i < count ($descriptions); $i++)
            {
            $row = $descriptions[$i];
            $tablesHandler->setLanguage ($row[DBTable::COL_LANG]);
            $values = array (MetaDataTables::COL_LABEL => $row[MetaDataTables::COL_LABEL],
                             MetaDataTables::COL_DESCRIPTION => $row[MetaDataTables::COL_DESCRIPTION]);
            if (false === $tablesHandler->updateTable ($id, $values))
                return false;
            }
        return true;
        }

    public function importColumnDescriptions ($columnsHandler, $tableId, $columnId, $descriptions)
        {
        for ($i = 0; $i < count ($descriptions); $i++)
            {
            $row = $descriptions[$i];
            $columnsHandler->setLanguage ($row[DBTable::COL_LANG]);
            $values = array (MetaDataColumns::COL_LABEL => $row[MetaDataColumns::COL_LABEL],
                             MetaDataColumns::COL_DESCRIPTION => $row[MetaDataColumns::COL_DESCRIPTION]);

            if (isset ($row[MetaDataColumns::COL_DEFAULTVALUE]))
                $values[MetaDataColumns::COL_DEFAULTVALUE] = $row[MetaDataColumns::COL_DEFAULTVALUE];
            if (isset ($row[MetaDataColumns::COL_RELATIONNAME]))
                $values[MetaDataColumns::COL_RELATIONNAME] = $row[MetaDataColumns::COL_RELATIONNAME];

            if (false === $columnsHandler->updateColumn ($tableId, $columnId, $values))
                return false;
            }
        return true;
        }

    public function getName ()
        {
        return $this->name;
        }

    public function getId ()
        {
        return $this->id;
        }

    public function getParentId ()
        {
        return isset ($this->table[MetaDataTables::COL_PARENTID]) ? $this->table[MetaDataTables::COL_PARENTID] : 0;
        }

    }

class MetaExport
    {
    protected $exportedStructure;
    protected $parentToChildren = array ();
    protected $idMap = array ();
    protected $importedTables = array ();

    public function __construct ($exportedStructure)
        {
        $this->exportedStructure = $exportedStructure;
        }

    public function importTablesRecursive ($context, $tablesInThisLevel)
        {
        foreach ($tablesInThisLevel as $table)
            {
            $id = $table->getId ();

            $newId = $table->importTable ($context, $this->idMap);
            if (false === $newId)
                {
                $context->addError ("Error importing table [_0]", $table->getName ());
                return false;
                }

            $this->idMap[$id] = $newId;
            $this->importedTables[] = $id;

            if (isset ($this->parentToChildren[$id]) &&
                false === $this->importTablesRecursive ($context, $this->parentToChildren[$id]))
                {
                return false;
                }
            }

        return true;
        }

    public function import ($context)
        {
        foreach ($this->exportedStructure as $table)
            {
            if (!$table instanceof IExportedRow)
                {
                $context->addMessage ("Incorrect contents of exported file found ([_0])", get_class ($table));
                return false;
                }

            $parentId = $table->getParentId ();
            $this->parentToChildren[$parentId][] = $table;
            }

        // now import hierarchy starting at tables without parents
        // NOTE: if table was exported without its parents, it will not be imported
        if (!isset ($this->parentToChildren[0]))
            {
            $context->addError ("Tables exported without their parents");
            return false;
            }

        if (false === $this->importTablesRecursive ($context, $this->parentToChildren[0]))
            return false;

        // import table columns (all the tables are already imported, so now it
        // is the right moment to recreate relations with correct ids
        foreach ($this->exportedStructure as $table)
            {
            if (false === array_search ($table->getId (), $this->importedTables))
                {
                $context->addError ("Table [_0] exported without parent", $table->getName ());
                return false;
                }

            if (false === $table->importColumns ($context, $this->idMap))
                {
                $context->addError ("Error creating table [_0]", $table->getName ());
                return false;
                }
            }
        }

    public static function importFromFile ($context, $filepath)
        {
        $h = fopen ($filepath, "r");
        $contents = fread ($h, filesize ($filepath));
        $exportedStructure = unserialize ($contents);
        if (!is_array ($exportedStructure))
            {
            $context->addMessage ("Incorrect contents of exported file");
            return false;
            }
        
        $instance = new MetaExport ($exportedStructure);

        $con = $context->getConnection ();
        $con->startTransaction ();

        if (false === $instance->import ($context))
            {
            $con->rollbackTransaction ();
            return false;
            }

        $con->commitTransaction ();
        return true;
        }
    }
?>

<?php

require_once (PATH."inc/constants.php");
require_once (PATH.'conf/config.php');

class Base
    {
    private static $log = "";
    private $loggedAnything = false;

    public function log ($msg)
        {
        if (!DEBUG && !defined ("LOGGING_ENABLED"))
            return;

        if (!is_string ($msg))
            $msg = print_r ($msg, true);
        self::$log[] = microtime (true).": ".$msg;
        $this->loggedAnything = true;
        }

    protected function flushLog ()
        {
        if (DEBUG && !empty (self::$log) && $this->loggedAnything)
            {
            echo "<pre>\n\n".implode ("\n<br>\n", self::$log)."\n\n</pre>";
            self::$log = array();
            }
        }

    public static function getLogText ()
        {
        if (!empty (self::$log))
            return implode ("\n", self::$log);
        return NULL;
        }

    public function clearLog ()
        {
        self::$log = "";
        }

    public function switchTextDomain ($textdomain, $language = NULL)
        {
        if (NULL === $language && defined ("DEFAULT_LANGUAGE"))
            $language = DEFAULT_LANGUAGE;

        return Translations::initialize (Constants::TEXTDOMAIN, $language);
        }

    public function getForHtml ($text, $param1 = NULL, $param2 = NULL, $param3 = NULL, $param4 = NULL)
        {
        return formatForHtml ($this->getText ($text, $param1, $param2, $param3, $param4));
        }

    public function _ ($text)
        {
        return $this->getForHtml ($text);
        }

    public function getForJS ($text, $param1 = NULL, $param2 = NULL, $param3 = NULL, $param4 = NULL)
        {
        return formatForJavaScript ($this->getText ($text, $param1, $param2, $param3, $param4));
        }

    public function getForAttr ($text, $param1 = NULL, $param2 = NULL, $param3 = NULL, $param4 = NULL)
        {
        return formatForAttr ($this->getText ($text, $param1, $param2, $param3, $param4));
        }

    public function getText ($msg, $param1 = NULL, $param2 = NULL, $param3 = NULL, $param4 = NULL)
        {
        $text = $this->formatText ($msg, $param1, $param2, $param3, $param4);
        return $text;
        }

    public function truncateFormated ($text)
        {
        if (preg_match ("/(.+)\|[^\]]+$/", $text, $match) > 0)
            return $match[1];
        return $text;
        }

    public function formatText ($msg, $param1 = NULL, $param2 = NULL, $param3 = NULL, $param4 = NULL)
        {
        $text = Translations::gettext ($msg);
        $text = $this->truncateFormated ($text);

        if (NULL === $param1)
            return $text;
        return formatText ($text, $param1, $param2, $param3, $param4);
        }

    public function ngettext ($msg1, $msg2, $count, $param1 = NULL, $param2 = NULL, $param3 = NULL)
        {
        $text = $this->truncateFormated (Translations::ngettext ($msg1, $msg2, $count));
        return formatText ($text, $count, $param1, $param2, $param3);
        }

    public function formatForAttr ($text)
        {
        return formatForAttr ($text);
        }

    public function trimSentence ($text, $approximateLength)
        {
        if (empty ($text))
            return $text;

        $text = str_replace ("\n", " ", $text);
        if ($approximateLength > 0 && strlen ($text) > $approximateLength)
            {
            preg_match ('/^(.{'.$approximateLength.'}.*?)\b/u', $text, $matches);
            if (count ($matches) < 2)
                {
                preg_match ('/^(.{0,'.$approximateLength.'})/u', $text, $matches);
                }

            if (count ($matches) < 2)
                return substr ($text, 0, $approximateLength);
            return rtrim ($matches[1])."...";
            }

        return $text;
        }

    public function formatForHtml ($text, $maxLength = -1)
        {
        return $this->trimSentence (formatForHtml ($text), $maxLength);
        }
        
    public function escapeHtmlChars ($text)
        {
        return htmlspecialchars ($text);
        }

    public function redirect ($url, $checkDebug = true)
        {
        if ($checkDebug && DEBUG && !empty (self::$log))
            {
            echo "<HTML>
<BODY>
DEBUG mode on, so automatic redirect is disabled<br/>
<a href=\"$url\">click here to proceed</a><br/><br/>
</BODY>
</HTML>";
    exit;
            }
        else
            {
            header($_SERVER['SERVER_PROTOCOL'] . ' 303 See Other'); //302 might not work for POST requests, 303 is ignored by obsolete clients
            header ("Location: ".$url);
            //another way for older browsers and already sent headers (eg trailing whitespace in config.php)
            echo "<meta http-equiv=\"refresh\" content=\"0; url=$url\" >";
            }
        }

    function displayNoAccessError ()
        {
        $this->displayErrorPage ($this->getText("You have no access to perform a requested operation"));
        }

    public function formatRichTextWithContext ($context, $text)
        {
        $parser = new Parser ($context, $text);
        return $parser->process ();
        }

    };

class BaseWithContext extends Base
    {
    protected $context;

    public function __construct ($context)
        {
        $this->context = $context;
        }

    public function getContext ()
        {
        return $this->context;
        }

    function displayErrorPage ($error)
        {
        $this->redirect ($this->context->processUrl ("index.php?c=Error&error=".rawurlencode ($error), true));
        exit;
        }

    function getProgressIconUrl ()
        {
        return $this->context->getResourcePath ("img", "progress.gif");
        }

    function getProgressText ()
        {
        return $this->getText ("Loading...");
        }

    public function formatRichText ($text)
        {
        return $this->formatRichTextWithContext ($this->context, $text);
        }

    }

class Translations
    {
    protected static $singleton = NULL;

    public static function initialize ($textDomain, $language)
        {
        if (NULL == self::$singleton)
            {
            if (class_exists ("Zend_Translate"))
                {
                if (class_exists ("Zend_Cache"))
                    {
                    $frontendOptions = array('cache_id_prefix' => 'futi', 'lifetime' => 86400,
                                             'automatic_serialization' => true); 
                    $backendOptions = array('cache_dir' => 'cache'); 
                    $cache = Zend_Cache::factory('Core', 'File', $frontendOptions, $backendOptions); 
                    if (!empty ($_REQUEST['_purge']))
                        $cache->clean (Zend_Cache::CLEANING_MODE_ALL);
 
                    Zend_Translate::setCache($cache);
                    }
                $file = PATH.'lang/'.$language.'/LC_MESSAGES/'.$textDomain.'.mo';

                try
                    {
                    self::$singleton = new Zend_Translate (
                        array(
                            'adapter' => 'gettext',
                            'content' => is_file ($file) ? $file : NULL,
                            'locale'  => $language
                            ));
                    }
                catch (Exception $e)
                    {
                    $file = PATH.'lang/'.DEFAULT_LANGUAGE.'/LC_MESSAGES/'.$textDomain.'.mo';
                    self::$singleton = new Zend_Translate (
                        array(
                            'adapter' => 'gettext',
                            'content' => is_file ($file) ? $file : NULL,
                            'locale'  => DEFAULT_LANGUAGE
                            ));
                    }

                return self::$singleton;
                }

            self::$singleton = new Translations ();

            $lng = $initialLanguage = $language;

            @putenv("LANGUAGE=$lng");
            @putenv("LANG=$lng");

            $languages = $GLOBALS["Languages"];
            if (!empty ($languages))
                {
                foreach ($languages as $language)
                    {
                    if ($language->code == $lng)
                        {
                        if (!empty ($language->countryCode))
                            $lng .= "_".$language->countryCode;
                        break;
                        }
                    }
                }

            if (defined ('LC_MESSAGES'))
                setlocale (LC_MESSAGES, $lng.'.UTF-8'); 
            setlocale (LC_ALL, $lng,
                              $initialLanguage . ".utf8", $initialLanguage . ".UTF8",
                              $initialLanguage . ".utf-8", $initialLanguage . ".UTF-8",
                              $initialLanguage,
                              "$lng.utf8",  "$lng.UTF8", "$lng.utf-8",  "$lng.UTF-8");

            if (!function_exists ("textdomain"))
                {
                echo "<pre>Please enable gettext module in PHP<pre>";
                return NULL;
                }

            $oldDomain = textdomain (NULL);
            if ($oldDomain != $textDomain)
                {
                bindtextdomain ($textDomain, PATH."lang");
                textdomain ($textDomain);
                bind_textdomain_codeset($textDomain, TEXTDOMAIN_CODESET);
                }
            }

        return self::$singleton;
        }

    public static function gettext ($msg)
        {
        return self::$singleton->translate ($msg);
        }

    public static function ngettext ($singular, $plural, $number)
        {
        $text = self::$singleton->plural ($singular, $plural, $number);
        return $text;
        }

    public function translate ($msg)
        {
        return dgettext (Constants::TEXTDOMAIN, $msg);
        }

    public function plural ($singular, $plural, $number)
        {
        return dngettext (Constants::TEXTDOMAIN, $singular, $plural, $number);
        }
    }

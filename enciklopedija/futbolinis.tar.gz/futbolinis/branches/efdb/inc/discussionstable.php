<?php
class DiscussionsTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "discussion";

    const COL_TOPICID = "topicid";
    const COL_ID = "entryid";
    const COL_TEXT = "text";
    const COL_USER = "user";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        $this->tracksRevisions = true;
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     new IntColumn (self::COL_TOPICID),
                     new TextColumn (self::COL_USER, 128, true),
                     new LongTextColumn (self::COL_TEXT, false),
                     );
        }
        
    protected function getIndexes ()
        {
        return array
            (
            new Index (self::COL_TOPICID),
            );
        }

    public function create ($topicId, $name, $text)
        {
        $values = array (self::COL_TOPICID => $topicId, self::COL_USER => $name,
                         self::COL_TEXT => $text);
        return $this->insertRecord ($values);
        }
    }

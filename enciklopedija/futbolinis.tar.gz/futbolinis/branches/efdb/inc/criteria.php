<?php

abstract class Criterion
    {
    public abstract function reset ();
    }

abstract class SingleTableCriterion extends Criterion
    {
    protected $adjusted = false;
    public $query;

    public abstract function formatForDB ($dbconnection, $tablealias, $translationsTableAlias = NULL);
    public abstract function adjustValue ($context, $nameToColumnMap, $namesToTextColumns);
    public abstract function getFields ();
    public abstract function needsAnyColumn ($namesToColumns);
    }

class SimpleCriterion extends SingleTableCriterion
    {
    public $field;
    protected $operator;
    public $value;
    public $initialValue;
    public $translatable = NULL;
    public $onlyTranslatable = NULL;
    protected $inverse = false;
    public $alias = false;

    public function __construct ($field, $operator, $value, $alias = false)
        {
        $this->field = $field;
        $this->operator = $operator;
        $this->initialValue = $this->value = $value;
        $this->alias = $alias;
        }

    public function formatForDB ($dbconnection, $tablealias, $translationsTableAlias = NULL)
        {
        if (!empty ($this->query))
            {
            $tablealias = $this->query->physicalAlias;
            $join = $this->query->getTranslatableColumnSubquery ();
            if (!empty ($join))
                $translationsTableAlias = $join->physicalAlias;
            }

        if ($this->translatable)
            {
            if ($this->onlyTranslatable)
                $tablealias = $translationsTableAlias;
            else
                {
                // for translatable columns need to search in translatable table and
                // fallback to default value stored in 
                $translCriteria = $this->formatForDatabase ($dbconnection, $translationsTableAlias,
                                                            $this->field, "$this->operator $this->value");
    
                $nonTranslatedCriteria = $this->formatForDatabase ($dbconnection,
                                                                   $translationsTableAlias,
                                                                   $this->field, "is null");
    
                $defaultCriteria = $this->formatForDatabase ($dbconnection,
                                                             $tablealias, DBTable::LNG_PREFIX.$this->field,
                                                             "$this->operator $this->value");
    
                return "($translCriteria or ($nonTranslatedCriteria and $defaultCriteria))";
                }
            }

        $value = NULL === $this->value ? "NULL" : $this->value;
        return $this->formatForDatabase ($dbconnection, false === strpos ($this->field, ".") ? $tablealias : NULL,
                                         $this->field, "$this->operator $value");
        }

    public function formatForDatabase ($dbconnection, $tablealias, $columnName, $criteria)
        {
        if (!$this->alias && NULL != $tablealias)
            $tablealias .= ".";
        else
            $tablealias = "";
        
        $prefix = $this->inverse ? "not " : "";
        $column = $tablealias.$dbconnection->prepareColumnName ($columnName);
        return "$prefix$column $criteria";
        }

    public function adjustValue ($context, $nameToColumnMap, $namesToTextColumns)
        {
        if ($this->adjusted)
            return;

        if (isset ($nameToColumnMap[$this->field]))
            {
            $col = $nameToColumnMap[$this->field];
            }
        else if (isset ($namesToTextColumns[$this->field]))
            {
            $col = $namesToTextColumns[$this->field];

            if (!$col instanceof LongTextColumn)
                $this->translatable = true;
            }

        if (!empty ($col))
            $this->value = $col->formatValueForDB ($context, $this->value);

        $this->adjusted = true;
        }

    public function reset ()
        {
        $this->value = $this->initialValue;
        $this->adjusted = false;
        $this->translatable = null;
        }

    public function getFields ()
        {
        return array ($this->field);
        }

    public function needsAnyColumn ($namesToColumns)
        {
        return isset ($namesToColumns[$this->field]);
        }
    }

class EqCriterion extends SimpleCriterion
    {
    public function __construct ($field, $value, $alias = false)
        {
        parent::__construct ($field, "=", $value, $alias);
        }
    }

class GtCriterion extends SimpleCriterion
    {
    public function __construct ($field, $value, $alias = false)
        {
        parent::__construct ($field, ">", $value, $alias);
        }
    }

class LtCriterion extends SimpleCriterion
    {
    public function __construct ($field, $value, $alias = false)
        {
        parent::__construct ($field, "<", $value, $alias);
        }
    }

class GtEqCriterion extends SimpleCriterion
    {
    public function __construct ($field, $value, $alias = false)
        {
        parent::__construct ($field, ">=", $value, $alias);
        }
    }

class LtEqCriterion extends SimpleCriterion
    {
    public function __construct ($field, $value, $alias = false)
        {
        parent::__construct ($field, "<=", $value, $alias);
        }
    }

class NotEqCriterion extends EqCriterion
    {
    public function __construct ($field, $value, $alias = false)
        {
        parent::__construct ($field, $value, $alias);
        $this->inverse = true;
        }
    }

class InCriterion extends SimpleCriterion
    {
    public function __construct ($field, $values, $alias = false)
        {
        parent::__construct ($field, "in", $values, $alias);
        }

    public function formatForDB ($dbconnection, $tablealias, $translationsTableAlias = NULL)
        {
        if (!empty ($this->query) && !$this->alias)
            $tablealias = $this->query->physicalAlias;
        else if ($this->alias)
            $tablealias = NULL;

        $column = (NULL != $tablealias ? ($tablealias.".") : "").$dbconnection->prepareColumnName ($this->field);
        return "$column $this->operator (".implode (", ", $this->value).")";
        }

    public function adjustValue ($context, $nameToColumnMap, $namesToTextColumns)
        {
        if ($this->adjusted)
            return;

        if (isset ($nameToColumnMap[$this->field]))
            {
            $col = $nameToColumnMap[$this->field];
            $values = $this->value;
            $this->value = array ();
            foreach ($values as $val)
                {
                $this->value[] = $col->formatValueForDB ($context, $val);
                }
            }

        $this->adjusted = true;
        }
    }

class NotInCriterion extends InCriterion
    {
    public function __construct ($field, $value)
        {
        parent::__construct ($field, $value);
        $this->inverse = true;
        }

    public function formatForDB ($dbconnection, $tablealias, $translationsTableAlias = NULL)
        {
        $text = parent::formatForDB ($dbconnection, $tablealias, $translationsTableAlias);
        return "not $text";
        }

    }

class LikeCriterion extends SimpleCriterion
    {
    public function __construct ($field, $value)
        {
        $value = str_replace("\\\\", "\\", $value);
        $value = str_replace("%", "\\%", $value);

        $newValue = $value;
        $newValue = str_replace("*", "%", $newValue);
        if ($value == $newValue) // no wildcard entered by user, so add at the end
            $newValue .= "%";

        parent::__construct ($field, "like", $newValue);
        }
    }

// Full text search criterion
class FTSCriterion extends SimpleCriterion
    {
    protected $fields;

    public function __construct ($fields, $value)
        {
        $this->fields = is_array ($fields) ? $fields : array ($fields);
        parent::__construct ($this->fields[0], "match", $value);
        }

    public function formatForDB ($dbconnection, $tablealias, $translationsTableAlias = NULL)
        {
        if (!empty ($this->query))
            {
            $tablealias = $this->query->physicalAlias;
            $join = $this->query->getTranslatableColumnSubquery ();
            if (!empty ($join))
                $translationsTableAlias = $join->physicalAlias;
            }

        $columns = array ();

        if ($this->translatable)
            {
            if ($this->onlyTranslatable)
                $tablealias = $translationsTableAlias;
            else
                {
                foreach ($this->fields as $field)
                    $columns[] =  $this->formatColumnName ($dbconnection, $translationsTableAlias, $field);

                // need to also search default values (if there is no translation), but it will not work until def_ column indexes are created
                /*
                foreach ($this->fields as $field)
                    $columns[] =  $this->formatColumnName ($dbconnection, $tablealias, DBTable::LNG_PREFIX.$field);
                */
                }
            }

        if (empty ($columns))
            {
            foreach ($this->fields as $field)
                $columns[] = $this->formatColumnName ($dbconnection, $tablealias, $field);
            }

        $searchModifier = false === strpbrk ($this->value, "+-*()") ? "WITH QUERY EXPANSION" : "IN BOOLEAN MODE";
        return "MATCH (".implode (", ", $columns).") AGAINST ($this->value $searchModifier)";
        }

    public function formatColumnName ($dbconnection, $tablealias, $columnName)
        {
        if (!$this->alias && NULL != $tablealias)
            $tablealias .= ".";
        else
            $tablealias = "";
        
        return $tablealias.$dbconnection->prepareColumnName ($columnName);
        }

    public function getFields ()
        {
        return $this->fields;
        }

    }

class IsNullCriterion extends SimpleCriterion
    {
    public function __construct ($field)
        {
        parent::__construct ($field, "is", NULL);
        }
    }

class DayIsEmptyCriteria extends SimpleCriterion
    {
    public function __construct ($field)
        {
        parent::__construct ($field, "", NULL);
        }

    public function formatForDatabase ($dbconnection, $tablealias, $columnName, $criteria)
        {
        if (!$this->alias && NULL != $tablealias)
            $tablealias .= ".";
        else
            $tablealias = "";
        
        $column = $tablealias.$dbconnection->prepareColumnName ($columnName);
        return "(DAY($column)=0 OR $column IS NULL)";
        }
    }

class FunctionCriteria extends SimpleCriterion
    {
    public function __construct ($field, $function, $value)
        {
        parent::__construct ($field, $function, $value);
        }

    public function formatForDatabase ($dbconnection, $tablealias, $columnName, $criteria)
        {
        if (!$this->alias && NULL != $tablealias)
            $tablealias .= ".";
        else
            $tablealias = "";
        
        $column = $tablealias.$dbconnection->prepareColumnName ($columnName);
        return "$this->operator($column)=$this->value";
        }
    }

class DayCriteria extends FunctionCriteria
    {
    public function __construct ($field, $value)
        {
        parent::__construct ($field, "DAY", $value);
        }
    }

class MonthCriteria extends FunctionCriteria
    {
    public function __construct ($field, $value)
        {
        parent::__construct ($field, "MONTH", $value);
        }
    }

class DayIsNotEmptyCriteria extends SimpleCriterion
    {
    public function __construct ($field)
        {
        parent::__construct ($field, "", NULL);
        }

    public function formatForDatabase ($dbconnection, $tablealias, $columnName, $criteria)
        {
        if (!$this->alias && NULL != $tablealias)
            $tablealias .= ".";
        else
            $tablealias = "";
        
        $column = $tablealias.$dbconnection->prepareColumnName ($columnName);
        return "(DAY($column)>0 AND $column IS NOT NULL)";
        }
    }

class InvalidCriteria extends SimpleCriterion
    {
    public function __construct ()
        {
        parent::__construct (NULL, "", NULL);
        }

    public function formatForDatabase ($dbconnection, $tablealias, $columnName, $criteria)
        {
        return "1=0";
        }
    }

class IsNotNullCriterion extends SimpleCriterion
    {
    public function __construct ($field)
        {
        parent::__construct ($field, "is", NULL);
        $this->inverse = true;
        }
    }

class LogicalOperator extends SingleTableCriterion
    {
    public $operator;
    public $parts;

    public function __construct ($operator, $parts)
        {
        $this->operator = $operator;
        $this->parts = $parts;
        }

    public function formatForDB ($dbconnection, $tablealias, $translationsTableAlias = NULL)
        {
        if (!empty ($this->query))
            $tablealias = $this->query->physicalAlias;

        $pieces = array();
        for ($i = 0; $i < count ($this->parts); $i++)
            {
            $pieces[] = $this->parts[$i]->formatForDB ($dbconnection, $tablealias, $translationsTableAlias);
            }
        
        return "(".implode (" ".$this->operator." ", $pieces).")";
        }

    public function adjustValue ($context, $nameToColumnMap, $namesToTextColumns)
        {
        if ($this->adjusted)
            return;

        for ($i = 0; $i < count ($this->parts); $i++)
            {
            $this->parts[$i]->adjustValue ($context, $nameToColumnMap, $namesToTextColumns);
            }

        $this->adjusted = true;
        }

    public function reset ()
        {
        for ($i = 0; $i < count ($this->parts); $i++)
            {
            $this->parts[$i]->reset ();
            }

        $this->adjusted = false;
        }

    public function getFields ()
        {
        $ret = array ();
        for ($i = 0; $i < count ($this->parts); $i++)
            {
            $ret = array_merge ($ret, $this->parts[$i]->getFields ());
            }

        return $ret;
        }

    public function needsAnyColumn ($namesToColumns)
        {
        for ($i = 0; $i < count ($this->parts); $i++)
            {
            if ($this->parts[$i]->needsAnyColumn ($namesToColumns))
                return true;
            }

        return false;
        }
    }

class LogicalOperatorAnd extends LogicalOperator
    {
    public function __construct ()
        {
        $parts = func_get_args ();
        parent::__construct ("and", 1 == count ($parts) ? $parts[0] : $parts);
        }
    }

class LogicalOperatorOr extends LogicalOperator
    {
    public function __construct ()
        {
        $parts = func_get_args ();
        parent::__construct ("or", 1 == count ($parts) ? $parts[0] : $parts);
        }
    }

class JoinCriterion extends Criterion
    {
    public function reset ()
        {
        }
    }

class JoinColumnsCriterion extends JoinCriterion
    {
    public $parentColumn;
    public $childColumn;

    public function __construct ($parentColumn, $childColumn)
        {
        $this->parentColumn = $parentColumn;
        $this->childColumn = $childColumn;
        }

    public function formatForDB ($dbconnection, $parentTableAlias, $childTableAlias)
        {
        if (NULL != $parentTableAlias)
            $parentTableAlias .= ".";
        if (NULL != $childTableAlias)
            $childTableAlias .= ".";
            
        $parentColumn = $parentTableAlias.$dbconnection->prepareColumnName ($this->parentColumn);
        $childColumn = $childTableAlias.$dbconnection->prepareColumnName ($this->childColumn);

        return "$parentColumn=$childColumn";
        }
    }

class JoinChildCriterion extends JoinCriterion
    {
    public $childColumn;
    public $value;
    public $operator;

    public function __construct ($childColumn, $value, $operator = '=')
        {
        $this->childColumn = $childColumn;
        $this->value = $value;
        $this->operator = $operator;
        }

    public function formatForDB ($dbconnection, $parentTableAlias, $childTableAlias)
        {
        if (NULL != $childTableAlias)
            $childTableAlias .= ".";
        $childColumn = $childTableAlias.$dbconnection->prepareColumnName ($this->childColumn);
        return "$childColumn{$this->operator}{$this->value}";
        }
    }

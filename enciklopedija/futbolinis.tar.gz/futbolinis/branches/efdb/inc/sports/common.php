<?php

class SportsHelper
    {
    public static function selectCompetitionHierarchyIds ($context, $competitionsTable, $ids)
        {
        return self::selectChildStageIds ($context, $competitionsTable, $ids, 0);
        }
        
    public static function colectLeaguePredecessors ($context, $id, $includeSuccessors = false)
        {
        $leagueIds = array ($id);

        if (SIMPLIFIED_TEAM_LABELS)
            {
            return $leagueIds;
            }

        $leaguesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_LEAGUE);
        if (empty ($leaguesTable))
            return $leagueIds;

        // collect league predecessors
        $currentId = $id;
        $predecessorColumn = ContentTable::generateForeignKeyColumn (Sports::COL_LEAGUE_PREDECESSOR, $leaguesTable->getIdColumn ());

        while (!empty ($currentId) && /* just in case cyclic reference is created */ count ($leagueIds) < 10)
            {
            $criteria = array (new EqCriterion ($leaguesTable->getIdColumn (), $currentId));
            $columns = array ($predecessorColumn);
            $row = $leaguesTable->selectSingleBy ($columns, $criteria);
            if (empty ($row) || empty ($row[$predecessorColumn]))
                break;

            $currentId = $row[$predecessorColumn];
            $leagueIds[] = $currentId;
            }

        if ($includeSuccessors)
            {
            $currentId = $id;
            while (!empty ($currentId) && /* just in case cyclic reference is created */ count ($leagueIds) < 10)
                {
                $criteria = array (new EqCriterion ($predecessorColumn, $currentId));
                $columns = array ($leaguesTable->getIdColumn ());
                $row = $leaguesTable->selectSingleBy ($columns, $criteria);
                if (empty ($row) || empty ($row[$leaguesTable->getIdColumn ()]))
                    break;

                $currentId = $row[$leaguesTable->getIdColumn ()];
                $leagueIds[] = $currentId;
                }
            }

        return $leagueIds;
        }

    protected static function selectChildStageIds ($context, $competitionsTable, $ids, $level = 0)
        {
        if ($level > 10)
            {
            $context->log ("Warning: cyclic competition stage inheritance?");
            return array ();
            }

        $parentColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_PARENT, Sports::TABLE_COMPETITIONSTAGE."_id");
        $criteria[] = new InCriterion ($parentColumn, $ids);
        $rows = $competitionsTable->selectBy (array ($competitionsTable->getIdColumn ()), $criteria);
        if (empty ($rows))
            return $ids;

        $childIds = array ();
        foreach ($rows as $row)
            $childIds[] = $row[$competitionsTable->getIdColumn ()];

        if (0 == $level)
            return array_merge ($ids, $childIds, self::selectChildStageIds ($context, $competitionsTable, $childIds, $level+1));

        return array_merge ($childIds, self::selectChildStageIds ($context, $competitionsTable, $childIds, $level+1));
        }

    public static function selectLeagueSeasonIds ($context, $competitionsTable, $leagueId)
        {
        if (SIMPLIFIED_TEAM_LABELS)
            return NULL;

        $parentColumn = "f_".Sports::COL_COMPETITION_LEAGUE."_".Sports::TABLE_LEAGUE."_id";
        $criteria[] = new InCriterion ($parentColumn, explode (",", $leagueId));
        $rows = $competitionsTable->selectBy (array ($competitionsTable->getIdColumn ()), $criteria);

        if (empty ($rows))
            return array ();
        $childIds = array ();
        foreach ($rows as $row)
            $childIds[] = $row[$competitionsTable->getIdColumn ()];

        return $childIds;
        }

    protected static $teamLabels = array ();
    public static function getDefaultTeamLabels ($teamsTable, $teamIds)
        {
        if (empty ($teamIds))
            return array ();

        $missingIds = array ();
        foreach ($teamIds as $id)
            {
            if (empty (self::$teamLabels[$id]))
                $missingIds[] = $id;
            }

        if (!empty ($missingIds))
            {
            $teamCriteria[] = new InCriterion ($teamsTable->getIdColumn (),$missingIds);
            $teamRows = $teamsTable->selectBy (array ($teamsTable->getIdColumn (), Sports::COL_TEAM_SHORTNAME), $teamCriteria);
            if (!empty ($teamRows))
                {
                foreach ($teamRows as $row)
                    self::$teamLabels[$row[$teamsTable->getIdColumn ()]] = $row["c_".Sports::COL_TEAM_SHORTNAME];
                }
            }

        return self::$teamLabels;
        }

    public static function getTeamLabels ($context, $teamIds, $date = NULL)
        {
        if (empty ($teamIds))
            return array ();

        if (empty ($date))
            {
            $dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
            return self::getDefaultTeamLabels ($dbtable, $teamIds);
            }

        $teamIdsToDates = array ();
        foreach ($teamIds as $id)
            $teamIdsToDates[] = array ($id, $date);

        $collected = self::getTeamLabelsByDates ($context, $teamIdsToDates);
        $result = array ();
        foreach ($collected as $id => $arr)
            $result[$id] = $arr[$date];
        return $result;
        }

    public static function cacheTeamLabel ($id, $label)
        {
        if (array_key_exists ($id, self::$teamLabels))
            return;
        self::$teamLabels[$id] = $label;
        }

    public static function extractTeamLabel ($context, $row, $includeDates = false)
        {
        $lng = Language::getInstance ($context);
        $label = $lng->getTeamLabel ($row);
        if ($includeDates)
            {
            $periodStart = substr ($row[TeamNamesTable::COL_DATEFROM], 0, 4);
            $periodEnd = substr ($row[TeamNamesTable::COL_DATETO], 0, 4);
            if ($periodStart == $periodEnd)
                {
                if (!empty ($periodStart))
                    $label = $context->getText ("[_0] ([_1])|team member from-to", $label, $periodStart);
                }
            else
                $label = $context->getText ("[_0] ([_1]-[_2])|team member from-to", $label, $periodStart, $periodEnd);
            $label;
            }
        return $label;
        }

    protected static $labelsByTeam = array ();
    public static function getTeamLabelsByDates ($context, $teamIdsToDates)
        {
        $missingIds = array ();
        foreach ($teamIdsToDates as $pair)
            {
            list ($id, $date) = $pair;
            if (empty (self::$labelsByTeam[$id]))
                {
                self::$labelsByTeam[$id] = array ();
                $missingIds[] = $id;
                }
            }

        if (!empty ($missingIds))
            {
            // retrieve labels for all teams not found in cache
            $dbtable = new TeamNamesTable ($context);
            
            $criteria[] = new InCriterion (TeamNamesTable::COL_TEAMID, $missingIds);
            $params[] = OrderBy::create (TeamNamesTable::COL_TEAMID, TeamNamesTable::COL_DATEFROM);
            $columns = array (TeamNamesTable::COL_TEAMID, TeamNamesTable::COL_PREFIX, TeamNamesTable::COL_NAME, TeamNamesTable::COL_CITY, TeamNamesTable::COL_DECLINE, TeamNamesTable::COL_SHOWPREFIX, TeamNamesTable::COL_POSTFIX, TeamNamesTable::COL_DATEFROM);
            $teamRows = $dbtable->selectBy ($columns, $criteria, null, $params);
            if (!empty ($teamRows))
                {
                foreach ($teamRows as $row)
                    {
                    $id = $row[TeamNamesTable::COL_TEAMID];
                    self::$labelsByTeam[$id][] = array ($row[TeamNamesTable::COL_DATEFROM], self::extractTeamLabel ($context, $row));
                    }
                }
            }

        $result = array();;
        $missingIds = array();
        $missingRows = array ();
        foreach ($teamIdsToDates as $pair)
            {
            list ($id, $date) = $pair;
            $label = NULL;
            foreach (self::$labelsByTeam[$id] as $p)
                {
                list ($dateFrom, $teamLabel) = $p;
                if ($dateFrom <= $date)
                    $label = $teamLabel;
                else
                    break;
                }

            if (empty ($result[$id]))
                $result[$id] = array ();

            if (empty ($label))
                {
                $missingIds[] = $id;
                $missingRows[] = $pair;
                continue;
                }

            $result[$id][$date] = $label;
            }

        // if some label is missing, we need to retrieve it from teams table
        if (!empty ($missingIds))
            {
            $dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
            $defaultLabels = self::getDefaultTeamLabels ($dbtable, $missingIds);
            foreach ($missingRows as $pair)
                {
                list ($id, $date) = $pair;
                if (!empty ($defaultLabels[$id]))
                    $result[$id][$date] = $defaultLabels[$id];
                else
                    $result[$id][$date] = "($id)";
                }
            }

        return $result;
        }

    protected static $teamLogos = array ();
    public static function getTeamLogosByDates ($context, $teamIdsToDates, $size = 64)
        {
        $collected = array ();
        $missingIds = array ();
        $teamIds = $allDates = array ();
        $firstDate = null;
        $duplicatesExpected = false;
        foreach ($teamIdsToDates as $id => $date)
            {
            if (is_array ($date))
                {
                $pair = $date;
                $duplicatesExpected = true;
                list ($id, $date) = $pair;
                }

            if (empty (self::$teamLogos[$date]))
                self::$teamLogos[$date] = array ();

            if (empty (self::$teamLogos[$date][$id]))
                {
                if (null === $firstDate)
                    $firstDate = $date;
                else if ($date != $firstDate)
                    $firstDate = false;

                $missingIds[] = array ($id, $date);
                $teamIds[] = $id;
                $allDates[] = $date;
                }
            else
                $collected[$id] = self::$teamLogos[$date][$id];
            }

        if (!empty ($missingIds))
            {
            $dbtable = new ImageUseTable ($context);
            
            if ($firstDate) // all dates are the same
                {
                $criteria[] = new InCriterion (ImageUseTable::COL_CONTEXTID, $teamIds);
                $criteria[] = new LtEqCriterion (ImageUseTable::COL_DATEFROM, $firstDate);
                }
            else
                {
                $orGroups = array ();
                foreach ($missingIds as $pair)
                    {
                    list ($id, $date) = $pair;
                    $orGroups[] = new LogicalOperatorAnd (new EqCriterion (ImageUseTable::COL_CONTEXTID, $id), new LtEqCriterion (ImageUseTable::COL_DATEFROM, $date));
                    }
                $criteria[] = new LogicalOperatorOr ($orGroups);
                }
            $criteria[] = new EqCriterion (ImageUseTable::COL_SCOPE, Constants::TABLES_USER."_".Sports::TABLE_TEAM);
            $criteria[] = new EqCriterion (ImageUseTable::COL_ZONE, ImageUseTable::ZONE_LOGO);
            $params[] = OrderBy::create (ImageUseTable::COL_ZONE, ImageUseTable::COL_SCOPE, ImageUseTable::COL_CONTEXTID, ImageUseTable::COL_DATEFROM);
            $teamRows = $dbtable->selectBy (array (ImageUseTable::COL_IMAGEID, ImageUseTable::COL_CONTEXTID, ImageUseTable::COL_DATEFROM), $criteria, null, $params);

            if (!empty ($teamRows))
                {
                foreach ($firstDate ? array ($firstDate) : array_unique ($allDates) as $date)
                    {
                    foreach ($teamRows as $row)
                        {
                        $imageId = $row[ImageUseTable::COL_IMAGEID];
                        $storedDate = $row[ImageUseTable::COL_DATEFROM];
                        if ($storedDate > $date)
                            continue;
                        $url = $context->chooseUrl ("image/$imageId/{$size}x{$size}",
                                                          "index.php?c=UserImage&id=$imageId&w=$size&h=$size");
                        self::$teamLogos[$date][$row[ImageUseTable::COL_CONTEXTID]] = $url;
                        if ($duplicatesExpected)
                            {
                            if (empty ($collected[$row[ImageUseTable::COL_CONTEXTID]]))
                                $collected[$row[ImageUseTable::COL_CONTEXTID]] = array ();
                            $collected[$row[ImageUseTable::COL_CONTEXTID]][$date] = $url;
                            }
                        else
                            $collected[$row[ImageUseTable::COL_CONTEXTID]] = $url;
                        }
                    }
                }
            }

        return $collected;
        }

    public static function getTeamImageIds ($context, $teamIds)
        {
        $dbtable = new ImageUseTable ($context);
        $criteria[] = new InCriterion (ImageUseTable::COL_CONTEXTID, $teamIds);
        $criteria[] = new EqCriterion (ImageUseTable::COL_SCOPE, Constants::TABLES_USER."_".Sports::TABLE_TEAM);
        $criteria[] = new EqCriterion (ImageUseTable::COL_ZONE, ImageUseTable::ZONE_LOGO);
        $params[] = OrderBy::create (ImageUseTable::COL_ZONE, ImageUseTable::COL_SCOPE, ImageUseTable::COL_CONTEXTID, ImageUseTable::COL_DATEFROM);
        $teamRows = $dbtable->selectBy (array (ImageUseTable::COL_IMAGEID, ImageUseTable::COL_CONTEXTID), $criteria, null, $params);
        if (empty ($teamRows))
            return array ();

        $imageIds = array ();
        foreach ($teamRows as $row)
            {
            $imageId = $row[ImageUseTable::COL_IMAGEID];
            $imageIds[$row[ImageUseTable::COL_CONTEXTID]] = $imageId;
            }
        return $imageIds;
        }

    public static function getTeamLogos ($context, $teamIds, $date, $size = 64)
        {
        if (empty ($date))
            return null;

        $teamIdsToDates = array ();
        foreach ($teamIds as $id)
            $teamIdsToDates[$id] = $date;

        return self::getTeamLogosByDates ($context, $teamIdsToDates, $size);
        }

    public static function getTeamTypesAndParents ($teamsTable, $teamIds)
        {
        $result = array ();
        if (!empty ($teamIds))
            {
            $clubColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAM_CLUB, Sports::TABLE_CLUB."_id");
            $typeColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAM_TYPE, "teamtype_id");
            $teamCriteria[] = new InCriterion ($teamsTable->getIdColumn (), $teamIds);
            $teamRows = $teamsTable->selectBy (array ($teamsTable->getIdColumn (), $clubColumn, $typeColumn), $teamCriteria);
            if (!empty ($teamRows))
                {
                foreach ($teamRows as $row)
                    $result[$row[$teamsTable->getIdColumn ()]] = array ($row[$typeColumn], $row[$clubColumn]);
                }
            }

        return $result;
        }

    protected static $playerLabels = array ();
    public static function getPlayerLabels ($playerTable, $playerIds)
        {
        $missingIds = array ();
        $playerLabels = array ();
        foreach ($playerIds as $id)
            {
            if (empty (self::$playerLabels[$id]))
                $missingIds[] = $id;
            else
                $playerLabels[$id] = self::$playerLabels[$id];
            }

        if (!empty ($missingIds))
            {
            $criteria[] = new InCriterion ($playerTable->getIdColumn (), $missingIds);
            $params[] = OrderBy::create ("c_".Sports::COL_PERSON_SURNAME, true, "c_".Sports::COL_PERSON_FIRST_NAME, true);
            $teamRows = $playerTable->selectBy (array ($playerTable->getIdColumn (), Sports::COL_PERSON_FIRST_NAME, Sports::COL_PERSON_SURNAME), $criteria, NULL, $params);
            if (!empty ($teamRows))
                {
                foreach ($teamRows as $row)
                    {
                    $playerLabels[$row[$playerTable->getIdColumn ()]] = trim ($row["c_".Sports::COL_PERSON_FIRST_NAME]." ".$row["c_".Sports::COL_PERSON_SURNAME]);
                    }
                }
            }

        foreach ($playerLabels as $id => $label)
            self::$playerLabels[$id] = $label;
        return $playerLabels;
        }

    public static function selectLeagueCompetitionSeasons ($context, $leagueIds, $stopAtCompetitionSeason, &$nextSeason = false)
        {
        $dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        if (empty ($dbtable))
            return false;

        if (SIMPLIFIED_TEAM_LABELS)
            {
            }
        else
            {
            $parentColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_LEAGUE, Sports::TABLE_LEAGUE."_id");
            $criteria[] = new InCriterion ($parentColumn, $leagueIds);
            }

        $partOfColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_PARENT, $dbtable->getIdColumn ());
        $seasonColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_SEASON, "seasons_id");
        $params[] = OrderBy::create (Sports::COL_COMPETITION_SEASON);
        $columns = array ($dbtable->getIdColumn (), $partOfColumn, Sports::COL_COMPETITION_FINALSTAGE, Sports::COL_COMPETITION_SEASON, Sports::COL_COMPETITION_NAME);
        $rows = $dbtable->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rows))
            return NULL;

        $seasons = array ();
        $lastSeasonId = NULL;
        $nextSeasonId = NULL;
        $seasonDescription = NULL;
        $stop = false;
        foreach ($rows as $row)
            {
            $currentSeasonId = $row[$seasonColumn];
            if ($lastSeasonId != $currentSeasonId)
                {
                if ($stop)
                    {
                    if (NULL !== $nextSeasonId)
                        break;
                    $nextSeasonId = $currentSeasonId;
                    }

                if (!empty ($seasonDescription))
                    $seasons[$lastSeasonId] = $seasonDescription;

                $seasonDescription = array ("season" => $row[Sports::COL_COMPETITION_SEASON.".".ContentTable::COL_DISPLAY_NAME],
                                            "name" => $row["c_".Sports::COL_COMPETITION_NAME],
                                            "id" => $row[$dbtable->getIdColumn ()],
                                            "ids" => array ());
                $lastSeasonId = $currentSeasonId;

                // everything should be ordered, but assert at this place
                if (!empty ($seasons[$lastSeasonId]))
                    $context->addError ("Unordered seasons. Please report site administrators.");
                }

            $leagueSeasonId = $row[$dbtable->getIdColumn ()];
            if ($leagueSeasonId == $stopAtCompetitionSeason)
                {
                if (false === $nextSeason)
                    {
                    // do not include last season
                    return $seasons;
                    }
                $stop = true;
                }

            $seasonDescription["ids"][$leagueSeasonId] = $row["c_".Sports::COL_COMPETITION_FINALSTAGE];
            if (empty ($row[$partOfColumn]))
                {
                $seasonDescription["id"] = $leagueSeasonId;
                $seasonDescription["name"] = $row["c_".Sports::COL_COMPETITION_NAME];
                }
            }

        if ($lastSeasonId && !empty ($seasonDescription))
            {
            if ($nextSeasonId == $lastSeasonId)
                {
                if (false !== $nextSeason)
                    $nextSeason = $seasonDescription;
                }
            else
                $seasons[$lastSeasonId] = $seasonDescription;
            }

        return $seasons;
        }

    public static function createMatchTableFilterCriterion ($context)
        {
        $arr[] = new InCriterion ("c_".Sports::COL_MATCH_OUTCOME,
                               array (MatchConstants::OUTCOME_NOT_STARTED, MatchConstants::OUTCOME_FULL_TIME,
                                      MatchConstants::OUTCOME_EXTRA_TIME, MatchConstants::OUTCOME_PENALTIES,
                                      MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                      MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $arr[] = new LogicalOperatorOr (new EqCriterion ("c_".Sports::COL_MATCH_EXCLUDED, 0), new IsNullCriterion ("c_".Sports::COL_MATCH_EXCLUDED));
        return $arr;
        }

    public static function createMatchTableCriterion ($context, $competitionIds, $teamId, $includeFilters = true, $from = NULL, $to = NULL)
        {
        $leagueIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        if (!empty ($competitionIds))
            {
            $arr[] = new InCriterion ($leagueIdColumn, $competitionIds);
            }

        if (!empty ($teamId))
            {
            $teamIds = self::getPredecessorTeamIds ($context, $teamId);
            $homeTeamColumn = "f_".Sports::COL_MATCH_HOMETEAM."_".Sports::TABLE_TEAM."_id";
            $awayTeamColumn = "f_".Sports::COL_MATCH_AWAYTEAM."_".Sports::TABLE_TEAM."_id";
            $arr[] = new LogicalOperatorOr (new InCriterion ($homeTeamColumn, $teamIds), new InCriterion ($awayTeamColumn, $teamIds));
            }

        if (!empty ($arr) && (!empty ($from) || !empty ($to)))
            {
            if (!empty ($from))
                $arr[] = new GtEqCriterion (ContentTable::PREFIX.Sports::COL_MATCH_DATE, $from);
            if (!empty ($to))
                $arr[] = new LtEqCriterion (ContentTable::PREFIX.Sports::COL_MATCH_DATE, $to);
            }

        if (empty ($arr) && empty ($teamId))
            $arr[] = new InvalidCriteria ();

        if ($includeFilters)
            {
            $arr = array_merge ($arr, self::createMatchTableFilterCriterion ($context));
            }

        return $arr;
        }

    static $cachedPredecessors = array ();
    public static function getPredecessorTeamIds ($context, $teamId)
        {
        if (!empty (self::$cachedPredecessors[$teamId]))
            return self::$cachedPredecessors[$teamId];

        $teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);

        // retrieve teams of the same club
        $rows = self::getPredecessorTeamList ($context, $teamId);
        if (empty ($rows))
            return array ($teamId);

        $ids = NULL;
        foreach ($rows as $row)
            $ids[] = $row[$teamsTable->getIdColumn ()];

        self::$cachedPredecessors[$teamId] = $ids;
        return $ids;
        }

    public static function getPredecessorTeamList ($context, $teamId)
        {
        $teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        $clubColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAM_CLUB, Sports::TABLE_CLUB."_id");
        $typeColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAM_TYPE, "teamtype_id");
        $columns = array ($clubColumn, $typeColumn);
        $criteria = array (new EqCriterion ($teamsTable->getIdColumn (), $teamId));
        $row = $teamsTable->selectSingleBy ($columns, $criteria);
        if (empty ($row))
            return false;
        $clubId = $row[$clubColumn];
        $type = $row[$typeColumn];

        $columns = array (Sports::COL_TEAM_SHORTNAME, $clubColumn, $teamsTable->getIdColumn (), "from", "to", $typeColumn);
        $criteria = array (new EqCriterion ($clubColumn, $clubId));
        if (!empty ($type))
            $criteria[] = new EqCriterion ($typeColumn, $type);

        $params = array (new OrderBy (array
                    (
                    new OrderByColumn (Sports::COL_TEAM_TYPE, true, 1),
                    new OrderByColumn ("c_from", true, 2),
                    )));
        $rows = $teamsTable->selectBy ($columns, $criteria, NULL, $params);
        return $rows;
        }

    public static $KnownSourceList = array ();
    }

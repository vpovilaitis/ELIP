<?php
require_once (PATH."inc/sports/teamresultsrow.php");

class LeagueTableRow extends TeamResultsRow
    {
    public $placeStored;
    public $place;
    public $win;
    public $winMod;
    public $winHome;
    public $winAway;
    public $draw;
    public $drawMod;
    public $drawHome;
    public $drawAway;
    public $lost;
    public $lostMod;
    public $lostHome;
    public $lostAway;
    public $scored;
    public $scoredMod;
    public $scoredHome;
    public $scoredAway;
    public $conceded;
    public $concededMod;
    public $concededHome;
    public $concededAway;
    public $pts;
    public $ptsMod;
    public $ptsHome;
    public $deduction;
    public $ptsAway;
    public $homeMatches = array ();
    public $resultsAgainst = array ();
    public $scoresAgainst = array ();
    public $totalInterGoals = array ();
    public $neighborPts = 0;
    public $neighborScores = 0;
    public $neighbourGoals = 0;
    
    protected function getDBTable ($context)
        {
        return ContentTable::createInstanceByName ($context, "teamleagueseasons");
        }

    private function getParameters ()
        {
        return array ("win", "draw", "lost", "scored", "conceded", "pts");
        }

    public static function getHeaderLabels ($context, $contestants, $includeMatches, $includeTools = true, $lightweight = false)
        {
        $arr = array
            (
            array (NULL, $lightweight ? "" : $context->getText (" |Place")),
            array (NULL, $context->getText ("Team")),
            );
        if ($includeMatches)
            {
            foreach ($contestants as $team)
                {
                if (NULL !== $team->placeStored && 0 == $team->placeStored) // disqualified
                    continue;
                $place = empty ($team->placeStored) ? $team->place : $team->placeStored;
                $arr[] = array ($team->getKey (), "$place.");
                }
            }

        array_push ($arr,
            array (NULL, $context->getText ("G|Games")));
        if (!$lightweight)
            array_push ($arr,
                array (NULL, $context->getText ("W|Win")),
                array (NULL, $context->getText ("D|Draw")),
                array (NULL, $context->getText ("L|Lost")),
                array (NULL, $context->getText ("+|Scored")),
                array (NULL, $context->getText ("-|Conceded")));
        array_push ($arr,
            array (NULL, $context->getText ("+/-|Scored-conceded")),
            array (NULL, $context->getText ("Pts|Points"))
            );

        if ($includeTools)
            {
            $src = $context->getSmallIconPath ("tools");
            $title = $context->getText ("Tools");
            $url = $context->getAdjustedUrl (array ("showerrors" => 1));
            $arr[] = array (NULL, "<a href='$url'><image src='$src' border='0' width='12' title='$title'></a>");
            }

        return $arr;
        }

    public function getHomeGames ()
        {
        if (NULL === $this->winHome && NULL === $this->drawHome && NULL === $this->lostHome)
            return NULL;

        return $this->winHome + $this->drawHome + $this->lostHome;
        }

    public function getAwayGames ()
        {
        if (NULL === $this->winAway && NULL === $this->drawAway && NULL === $this->lostAway)
            return NULL;
        return $this->winAway + $this->drawAway + $this->lostAway;
        }

    public function getTotalGames ()
        {
        $modifier = NULL;
        if (NULL !== $this->winMod)
            $modifier += $this->winMod;
        if (NULL !== $this->drawMod)
            $modifier += $this->drawMod;
        if (NULL !== $this->lostMod)
            $modifier += $this->lostMod;

        if (NULL !== $this->win && NULL !== $this->draw && NULL !== $this->lost)
            {
            $gamesTotal = $this->win + $this->draw + $this->lost;
            }

        $gamesHome = $this->getHomeGames ();
        $gamesAway = $this->getAwayGames ();
        $calculated = NULL;
        if (NULL !== $gamesHome || NULL != $gamesAway || (NULL === $gamesTotal && NULL != $modifier))
            $calculated = $gamesHome + $gamesAway + $modifier;

        return $this->getDisplayValue ($gamesTotal, $calculated);
        }

    public function getTotal ($objParams, $name, $forDisplay = true)
        {
        $calculated = $this->getCalculated ($objParams, $name);
        if ("pts" == $name && !empty ($objParams["deduction"]))
            $calculated -= $objParams["deduction"];
        $stored = $objParams[$name];

        return $this->getDisplayValue ($stored, $calculated, $forDisplay);
        }

    public function getCalculated ($objParams, $name)
        {
        $home = $objParams[$name."Home"];
        $away = $objParams[$name."Away"];
        $modifier = $objParams[$name."Mod"];

        return (NULL !== $home || NULL !== $away || (NULL === $objParams[$name] && NULL !== $modifier)) ? $home + $away + $modifier : NULL;
        }

    public function getDisplayValue ($fixed, $calculated, $forDisplay = true)
        {
        if (NULL !== $fixed)
            {
            if ($forDisplay && !empty ($_REQUEST["showerrors"]) && NULL !== $calculated && $calculated != $fixed)
                return "$fixed<div class=\"leagueTableError\" title=\"$calculated\">($calculated)</div>";
            return $fixed;
            }

        return $calculated;
        }

    public function getStoredScoringDiff ()
        {
        $diffTotal = NULL;
        if (NULL !== $this->scored && NULL !== $this->conceded)
            $diffTotal = $this->scored - $this->conceded;
        if ($diffTotal > 0)
            $diffTotal = "+$diffTotal";
        return $diffTotal;
        }

    public function getCalculatedScoringDiff ()
        {
        $diffHome = NULL;
        $diffAway = NULL;
        if (NULL !== $this->scoredHome || NULL !== $this->concededHome)
            $diffHome = $this->scoredHome - $this->concededHome;
        if (NULL !== $this->scoredAway || NULL !== $this->concededAway)
            $diffAway = $this->scoredAway - $this->concededAway;

        $diff = NULL;
        if (NULL !== $diffHome || NULL != $diffAway)
            $diff = $diffHome + $diffAway;

        $total = $this->getStoredScoringDiff ();
        if ((NULL === $total || NULL !== $diff) && (NULL !== $this->scoredMod || NULL !== $this->concededMod))
            $diff += $this->scoredMod - $this->concededMod;

        if ($diff > 0)
            $diff = "+$diff";
        return $diff;
        }

    public function getTotalScoringDiff ()
        {
        return $this->getDisplayValue ($this->getStoredScoringDiff (), $this->getCalculatedScoringDiff ());
        }

    public function hasInconsistencies ()
        {
        $this->checkDefaults ();
        $vars = get_object_vars ($this);
        foreach ($this->getParameters () as $name)
            {
            $home = $vars[$name."Home"];
            $away = $vars[$name."Away"];
            $calculated = (NULL !== $home || NULL != $away) ? $home + $away : NULL;
            $stored = $vars[$name];

            $modifier = $vars[$name."Mod"];
            if (NULL !== $modifier)
                $calculated += $modifier;

            if ($stored != $calculated && NULL !== $calculated)
                return true;
            }

        $calculated = $this->getCalculatedScoringDiff ();
        if ($this->getStoredScoringDiff () != $calculated && NULL !== $calculated)
            return true;

        if ($this->placeStored != $this->place)
            return true;

        return false;
        }

    public function checkDefaults ()
        {
        if (NULL === $this->winHome && NULL === $this->drawHome && NULL === $this->lostHome &&
            NULL === $this->winAway && NULL === $this->drawAway && NULL === $this->lostAway)
            {
            return;
            }

        // if team played some games, set empty values to 0
        if (NULL === $this->winHome)
            $this->winHome = 0;
        if (NULL === $this->drawHome)
            $this->drawHome = 0;
        if (NULL === $this->lostHome)
            $this->lostHome = 0;
        if (NULL === $this->winAway)
            $this->winAway = 0;
        if (NULL === $this->drawAway)
            $this->drawAway = 0;
        if (NULL === $this->lostAway)
            $this->lostAway = 0;
        }

    public function getKey ()
        {
        return $this->teamId;
        }

    public function toArray ($context, $contestants, $includeMatches, $tools, $canCreate, $lightweight = false)
        {
        $this->checkDefaults ();

        $matchesTable = ContentTable::createInstanceByName ($context, "match");
        $nameWithUrl = $this->getTeamUrl ($context, $lightweight);

        $placeStored = empty ($this->placeStored) ? NULL : $this->placeStored.".";
        if (NULL !== $this->placeStored && 0 == $this->placeStored) // disqualified
            $place = "";
        else
            $place = $this->getDisplayValue ($placeStored, $this->place.".", true);

        $arr = array
            (
            "place" => $place,
            "plc" => trim ($place, '.'),
            "team" => $nameWithUrl,
            "logo" => $this->logo,
            "team_name" => $this->getName (),
            "team_url" => $this->getUrl ($context),
            "teamId" => $this->getKey ()
            );

        $matches = array ();
        if ($includeMatches || $canCreate)
            {
            foreach ($contestants as $team)
                {
                if (NULL !== $team->placeStored && 0 == $team->placeStored) // disqualified
                    continue;

                if ($team == $this)
                    {
                    $matches[] = "x";
                    continue;
                    }
    
                $results = array();
                $teamIdString = $team->getKey ();
                if (isset ($this->homeMatches[$teamIdString]))
                    {
                    foreach ($this->homeMatches[$teamIdString] as $id => $result)
                        {
                        if (empty ($matchesTable))
                            $results[] = $this->teamName;
                        else
                            {
                            $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $matchesTable,
                                                                                         $matchesTable->getId (),
                                                                                         $id);
                            $results[] = "<a href=\"$url\">$result</a>";
                            }
                        }
                    }
    
                if (empty ($results))
                    $matches[] = "&nbsp;";
                else
                    $matches[] = implode ("<br>", $results);
                }
            }

        $arr["matches"] = $matches;
        $vars = get_object_vars ($this);

        if ($lightweight)
            {
            $arr["scores"] = array (
                $this->getTotalGames (),
                $this->getTotalScoringDiff (),
                $this->getTotal ($vars, "pts"),
                );
            }
        else
            {
            $arr["scores"] = array (
                /*
                $gamesHome,
                $this->winHome,
                $this->drawHome,
                $this->lostHome,
                $this->scoredHome,
                $this->concededHome,
                $diffHome,
                $this->ptsHome,
                */

                $this->getTotalGames (),
                $this->getTotal ($vars, "win"),
                $this->getTotal ($vars, "draw"),
                $this->getTotal ($vars, "lost"),
                $this->getTotal ($vars, "scored"),
                $this->getTotal ($vars, "conceded"),
                $this->getTotalScoringDiff (),
                $this->getTotal ($vars, "pts"),
                );
            }

        if (NULL !== $tools)
            $arr["tools"] = $tools;

        return $arr;
        }

    public function getValuesForDB ()
        {
        $this->checkDefaults ();
        $vars = get_object_vars ($this);
        return array
            (
            "c_place" => $this->place,
            "c_win" => $this->getCalculated ($vars, "win"),
            "c_draw" => $this->getCalculated ($vars, "draw"),
            "c_lost" => $this->getCalculated ($vars, "lost"),
            "c_conceded" => $this->getCalculated ($vars, "conceded"),
            "c_scored" => $this->getCalculated ($vars, "scored"),
            "c_pts" => $this->getCalculated ($vars, "pts"),
            );
        }

    public function setStored ()
        {
        $vars = get_object_vars ($this);
        $this->win = $this->getCalculated ($vars, "win");
        $this->draw = $this->getCalculated ($vars, "draw");
        $this->lost = $this->getCalculated ($vars, "lost");
        $this->conceded = $this->getCalculated ($vars, "conceded");
        $this->scored = $this->getCalculated ($vars, "scored");
        $this->pts = $this->getCalculated ($vars, "pts");
        }

    }





class CupResultsRow extends TeamResultsRow
    {
    public $achievement;
    public $enteredRound;

    protected function getDBTable ($context)
        {
        return ContentTable::createInstanceByName ($context, "teamcupseason");
        }

    }






class CupCompetitionMatch
    {
    public $id;
    public $date;
    public $result;
    public $homeTeam;
    public $awayTeam;
    public $homeWin = NULL;
    public $homeResult;
    public $awayResult;

    public function __construct ($id, $date, $result, &$homeTeam, &$awayTeam, $homeResult, $awayResult, $homeWin = NULL)
        {
        $this->id = $id;
        $this->date = $date;
        $this->result = $result;
        $this->homeTeam = $homeTeam;
        $this->awayTeam = $awayTeam;
        $this->homeResult = $homeResult;
        $this->awayResult = $awayResult;
        
        if (NULL !== $homeWin)
            $this->homeWin = $homeWin;
        else if ($this->homeResult > $this->awayResult)
            $this->homeWin = true;
        else if ($this->homeResult < $this->awayResult)
            $this->homeWin = false;
        }

    public function isHomeWin ()
        {
        return true === $this->homeWin;
        }

    public function isAwayWin ()
        {
        return false === $this->homeWin;
        }
    }







class CupRound
    {
    protected $roundName;
    protected $roundId;
    protected $context;
    protected $teams = array ();
    protected $matches = array ();
    protected $pairedTeams = array ();
    protected $winnerRound = false;
    protected $winners = array ();
    protected $logos = array ();

    public function __construct ($context, $name, $id, $winnerRound)
        {
        $this->context = $context;
        $this->roundName = $name;
        $this->roundId = $id;
        $this->winnerRound = $winnerRound;
        }

    public function getTitle ()
        {
        return $this->roundName;
        }

    public function setLogos ($teams)
        {
        $logos = array ();
        foreach ($teams as $team)
            {
            if (empty ($team->logo))
                continue;
            $logos[$team->getId ()] = $team->logo;
            }

        $this->logos = $logos;
        }

    public function addTeam ($team, $proceeded)
        {
        $this->winners[$team->getId ()] = $proceeded;
        if (array_key_exists ($team->getId (), $this->pairedTeams))
            return;
        $this->teams[] = $team;
        }

    protected function setTeamPair ($team, $pairIndex)
        {
        $id = $team->getId ();
        if (!isset ($this->pairedTeams[$id]))
            $this->pairedTeams[$id] = array ();
        $this->pairedTeams[$id][] = $pairIndex;
        }

    public function addMatch ($match)
        {
        $idx = count ($this->matches);
        $this->setTeamPair ($match->homeTeam, $idx);
        $this->setTeamPair ($match->awayTeam, $idx);

        $this->matches[$idx] = $match;
        }

    public function createMatchDisplayObject ($context, $matchesTable, $match)
        {
        if (isset ($match->processed))
            return NULL;

        $result = $match->result;

        if (!empty ($matchesTable))
            {
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $matchesTable,
                                                                         $matchesTable->getId (),
                                                                         $match->id);
            $result = "<a href=\"$url\">$result</a>";
            }

        $match->processed = true;
        $homeClass = "";
        $awayClass = "";

        $id = $match->homeTeam->getId ();
        if ($this->roundId == $match->homeTeam->achievement)
            $homeClass = "roundloser";
        else
            {
            if (!empty ($this->winners[$id]) && $this->winners[$id])
                $homeClass = "roundwinner";
            }

        $homeLogo = empty ($this->logos[$id]) ? null : $this->logos[$id];

        $id = $match->awayTeam->getId ();
        if ($this->roundId == $match->awayTeam->achievement)
            $awayClass = "roundloser";
        else
            {
            if (!empty ($this->winners[$id]) && $this->winners[$id])
                $awayClass = "roundwinner";
            }

        $awayLogo = empty ($this->logos[$id]) ? null : $this->logos[$id];

        if ($homeClass == $awayClass)
            {
            if ($match->isHomeWin ())
                {
                $homeClass = "roundwinner";
                $awayClass = "roundloser";
                }
            else if ($match->isAwayWin ())
                {
                $homeClass = "roundloser";
                $awayClass = "roundwinner";
                }
            }
        else if (empty ($homeClass))
            $homeClass = ("roundloser" == $awayClass) ? "roundwinner" : "roundloser";
        else
            $awayClass = ("roundloser" == $homeClass) ? "roundwinner" : "roundloser";

        return array
            (
            "home" => $match->homeTeam->getTeamUrl ($context, false, $match->date),
            "homelogo" => $homeLogo,
            "result" => $result,
            "away" => $match->awayTeam->getTeamUrl ($context, false, $match->date),
            "awaylogo" => $awayLogo,
            "homeClass" => $homeClass,
            "awayClass" => $awayClass,
            );
        }

    public function getPairs ($columns)
        {
        if (empty ($this->matches))
            return NULL;

        $groups = array ();        
        $rowsInColumn = count ($this->matches) / $columns;
        $matchesTable = ContentTable::createInstanceByName ($this->context, "match");

        for ($c = 0; $c < $columns; $c++)
            {
            $matches = array ();
            for ($i = ceil ($rowsInColumn * $c); $i < $rowsInColumn * ($c + 1) && $i < count ($this->matches); $i++)
                {
                $match = $this->matches[$i];
                $displayMatch = $this->createMatchDisplayObject ($this->context, $matchesTable, $match);
                if (empty ($displayMatch))
                    continue;

                $matches[] = $displayMatch;
                $iterateIn = array ("home" => $match->homeTeam->getId (), "away" => $match->awayTeam->getId ());
                foreach ($iterateIn as $key => $teamId)
                    {
                    if (!isset ($this->pairedTeams[$teamId]))
                        continue;

                    foreach ($this->pairedTeams[$teamId] as $idx)
                        {
                        $relatedMatch = $this->createMatchDisplayObject ($this->context, $matchesTable, $this->matches[$idx]);
                        if (empty ($relatedMatch))
                            continue;
                        $matches[] = $relatedMatch;
                        }
                    }
                }

            $groups[] = $matches;
            }

        return $groups;
        }

    public function isSingleTeam ()
        {
        return 1 === count ($this->teams) && $this->winnerRound;
        }
    public function getTeam ()
        {
        return $this->teams[0]->getTeamUrl ($this->context);
        }
    public function getTeamLogo ()
        {
        return $this->teams[0]->logo;
        }

    public function getTeamGroups ($columns, $pairGroups)
        {
        if (empty ($this->teams))
            return NULL;

        $groups = array ();
        if (empty ($this->pairedTeams))
            $allTeams = $this->teams;
        else
            {
            $allTeams = array ();
            foreach ($this->teams as $team)
                {
                $id = $team->getId ();
                if (array_key_exists ($id, $this->pairedTeams))
                    continue;
                $allTeams[] = $team;
                }
            }
            
        $teamsInColumn = count ($allTeams) / $columns;

        for ($c = 0; $c < $columns; $c++)
            {
            $teams = array ();
            for ($i = ceil ($teamsInColumn * $c); $i < $teamsInColumn * ($c + 1) && $i < count ($allTeams); $i++)
                {
                $class = "roundlooser";
                $id = $allTeams[$i]->getId ();
                if (!empty ($this->winners[$id]) && $this->winners[$id])
                    $class = "roundwinner";
                
                $teams[] = array ("url" => $allTeams[$i]->getTeamUrl ($this->context), "class" => $class);
                }
            $groups[] = $teams;
            }

        return $groups;
        }
    }

<?php

/* A database table which stores match predictor announcements */
class PredictorGameTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "predictorgame";

    const COL_ID = "predictorgame_id";
    const COL_SEASON_ID = "pred_season_id";
    const COL_MATCH_ID = "match_id";
    const COL_ANNOUNCEMENT_TEXT = "announcement";
    const COL_OUTCOME = "outcome";
    const COL_GOALS_HOME = "homegoals";
    const COL_GOALS_AWAY = "awaygoals";

    const OUTCOME_HOME_WIN = 1;
    const OUTCOME_DRAW     = 0;
    const OUTCOME_AWAY_WIN = -1;

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        $this->tracksRevisions = true;
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     new IntColumn (self::COL_SEASON_ID),
                     new IntColumn (self::COL_MATCH_ID),
                     new IntColumn (self::COL_OUTCOME, true),
                     new IntColumn (self::COL_GOALS_HOME, true),
                     new IntColumn (self::COL_GOALS_AWAY, true),
                     new LongTextColumn (self::COL_ANNOUNCEMENT_TEXT, true),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new UniqueIndex (self::COL_SEASON_ID, self::COL_MATCH_ID),
            );
        }

    public function insertRecord ($nameToValue)
        {
        if (empty ($nameToValue[self::COL_SEASON_ID]))
            {
            $this->context->addError ("Predictor season is not specified");
            return false;
            }

        $ret = parent::insertRecord ($nameToValue);
        $this->clearCache ();
        return $ret;
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = 1)
        {
        $ret = parent::updateRecord ($criteria, $nameToValue, $maxRows);
        $this->clearCache ();
        return $ret;
        }

    public function updateCachedOutcome ()
        {
        $cache = Cache::getInstance (Sports::TABLE_MATCH, 6*60*60);
        $cacheId = "updatepredictor";

        if (false !== ($result = $cache->get ($cacheId)))
            return;

        // currently it is more like a a hack which skips security and database encapsulation
        $db = $this->context->getConnection ();
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $tableName = $db->prepareTableName ($this->getTableName ());
        $matchesTableName = $db->prepareTableName ($matchesTable->getTableName ());
        $colMatchId = $db->prepareColumnName (self::COL_MATCH_ID);
        $colOutcome = $db->prepareColumnName (self::COL_OUTCOME);
        $colHome = $db->prepareColumnName (self::COL_GOALS_HOME);
        $colAway = $db->prepareColumnName (self::COL_GOALS_AWAY);
        $colSeason = $db->prepareColumnName (self::COL_SEASON_ID);
        $colResultHome = $db->prepareColumnName ("c_".Sports::COL_MATCH_HOMERESULT);
        $colResultAway = $db->prepareColumnName ("c_".Sports::COL_MATCH_AWAYRESULT);
        
        $sql = 
<<<EOT
UPDATE $tableName p, $matchesTableName m
   SET p.$colOutcome = CASE WHEN m.$colResultHome=m.$colResultAway THEN 0 WHEN m.$colResultHome>m.$colResultAway THEN 1 ELSE -1 END,
       p.$colHome = m.$colResultHome, p.$colAway = m.$colResultAway
  WHERE p.$colMatchId = m.{$matchesTable->getIdColumn()} AND m.$colResultHome IS NOT NULL AND m.$colResultAway IS NOT NULL
    AND (p.$colHome IS NULL OR m.$colResultHome != p.$colHome) AND (p.$colAway IS NULL OR m.$colResultAway != p.$colAway)
    AND p.$colSeason > 4
EOT;
        $affected = $db->executeCustomSQL ($sql, true);
        $cache->save ($affected, $cacheId);
        }

    protected function clearCache ()
        {
        $cache = Cache::getInstance (Sports::TABLE_MATCH, 6*60*60);
        $cache->clean ();
        }
        
    public function deleteById ($criteria)
        {
        $ret = parent::deleteById ($criteria);
        $this->clearCache ();
        return $ret;
        }

    }

/* A database table which stores match predictor guess for specific matches */
class PredictorGuessTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "predictorguess";

    const COL_GAME_ID = PredictorGameTable::COL_ID;
    const COL_USER_ID = "user_id";
    const COL_OUTCOME = "outcome";
    const COL_GOALS_HOME = "homegoals";
    const COL_GOALS_AWAY = "awaygoals";
    const COL_REQUEST_INFO = "requestinfo";
    const COL_VALID = "valid";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        $this->tracksRevisions = true;
        }

    protected function getColumns ()
        {
        return array (
                     new IntColumn (self::COL_GAME_ID),
                     new IntColumn (self::COL_USER_ID),
                     new IntColumn (self::COL_OUTCOME, true),
                     new IntColumn (self::COL_GOALS_HOME, true),
                     new IntColumn (self::COL_GOALS_AWAY, true),
                     new LongTextColumn (self::COL_REQUEST_INFO),
                     new BoolColumn (self::COL_VALID, false),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new UniqueIndex (self::COL_GAME_ID, self::COL_USER_ID),
            );
        }

    public function canCreateInstance ($nameToValue)
        {
        return ($nameToValue[PredictorGuessTable::COL_USER_ID] > 0 &&
               $this->context->getCurrentUser () == $nameToValue[PredictorGuessTable::COL_USER_ID]) ||
               parent::canCreateInstance ($nameToValue);
        }

    protected function prepareRecord (&$nameToValue)
        {
        $requestInfo = array ();
        $interestingKeys = array ("HTTP_USER_AGENT", "REMOTE_ADDR");
        foreach ($interestingKeys as $key)
            {
            if (!empty ($_SERVER[$key]))
                $requestInfo[] = $key."=".$_SERVER[$key];
            }

        $nameToValue[self::COL_OUTCOME] = $nameToValue[self::COL_GOALS_HOME] == $nameToValue[self::COL_GOALS_AWAY]
                                            ? PredictorGameTable::OUTCOME_DRAW
                                            : ($nameToValue[self::COL_GOALS_HOME] > $nameToValue[self::COL_GOALS_AWAY]
                                                ? PredictorGameTable::OUTCOME_HOME_WIN
                                                : PredictorGameTable::OUTCOME_AWAY_WIN);
        $nameToValue[self::COL_REQUEST_INFO] = implode ("\n", $requestInfo);
        }

    public function insertRecord ($nameToValue)
        {
        if (!array_key_exists (self::COL_GOALS_HOME, $nameToValue) || !array_key_exists (self::COL_GOALS_AWAY, $nameToValue))
            {
            $this->context->addError ("Invalid parameters passed.");
            return false;
            }

        $this->prepareRecord ($nameToValue);
        $nameToValue[self::COL_VALID] = true;
        return parent::insertRecord ($nameToValue);
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = 1)
        {
        if (2 != count ($nameToValue) ||
            !isset ($nameToValue[self::COL_GOALS_HOME]) || !is_numeric ($nameToValue[self::COL_GOALS_HOME]) ||
            !isset ($nameToValue[self::COL_GOALS_AWAY]) || !is_numeric ($nameToValue[self::COL_GOALS_AWAY]))
            {
            $this->context->addError ("Invalid parameters passed.");
            return false;
            }

        $this->prepareRecord ($nameToValue);

        foreach ($criteria as $c)
            {
            if ("EqCriterion" != get_class ($c) || (PredictorGuessTable::COL_GAME_ID != $c->field && PredictorGuessTable::COL_USER_ID != $c->field))
                {
                $this->context->addError ("Invalid parameters passed.");
                return false;
                }
            if (PredictorGuessTable::COL_USER_ID == $c->field && $this->context->getCurrentUser () != $c->value)
                {
                $this->context->addError ("Invalid parameters passed.");
                return false;
                }
            }

        return parent::updateRecord ($criteria, $nameToValue);
        }

    public function selectLeaders ($seasonId, $maxItems = 10, $hideExcluded = false)
        {
        $announcementJoins = NULL;
        if (empty ($seasonId))
            {
            $seasonTable = new PredictorSeasonTable ($this->context);
            $seasonsJoinCriteria = array (new JoinColumnsCriterion (PredictorGameTable::COL_SEASON_ID, PredictorSeasonTable::COL_ID));
            $seasonsJoinCriteria[] = new GtCriterion (PredictorSeasonTable::COL_END_DATE, date ("Y-m-d G:i:s", time() - 28 * 24 * 60 * 60));
            $announcementJoins[] = $seasonTable->createQuery (array (), $seasonsJoinCriteria);
            }
        else
            $joinCriteria[] = new EqCriterion (PredictorGameTable::COL_SEASON_ID, $seasonId);
    
        return $this->selectLeadersByCriteria ($joinCriteria, $announcementJoins, $maxItems, $hideExcluded);
        }

    public function selectLeadersByMatchList ($matches, $maxItems = 3, $hideExcluded = true)
        {
        $criteria[] = new InCriterion (PredictorGameTable::COL_MATCH_ID, $matches);
    
        return $this->selectLeadersByCriteria ($criteria, NULL, $maxItems, $hideExcluded);
        }

    public function selectLeadersByCriteria ($criteria, $announcementJoins, $maxItems = 10, $hideExcluded = false)
        {
        $announcementTable = new PredictorGameTable ($this->context);

        $announcementTable->updateCachedOutcome ();

        $columns = $joins = $params = array ();
        $excludedCriteria = array ();
        if ($hideExcluded)
            {
            $excluded = array ();
            if (defined ("MATCH_PREDICTOR_EXCLUDE"))
                {
                $usersToExclude = MATCH_PREDICTOR_EXCLUDE;
                if (!empty ($usersToExclude))
                    $excluded = preg_split ("/[,; |]/", $usersToExclude);
                }

            if (!empty ($excluded))
                $excludedCriteria[] = new NotInCriterion (self::COL_USER_ID, $excluded);
            }

        $criteria[] = new JoinColumnsCriterion (self::COL_GAME_ID, PredictorGameTable::COL_ID);

        $joins[] = $announcementTable->createQuery (array (new FunctionCount (PredictorGameTable::COL_OUTCOME, "cnt")), $criteria, $announcementJoins);
        
        $columns[] = new FunctionCount ("*", "totalcount");
        $columns[] = self::COL_USER_ID;
        $params[] = new GroupBy (array (self::COL_USER_ID));
        $params[] = OrderBy::createByAlias ("pts", false);
        if ($maxItems > 0)
            $params[] = new LimitResults (0, $maxItems);
        $maxPoints = defined ("MATCH_PREDICTOR_MAX_POINTS") ? MATCH_PREDICTOR_MAX_POINTS : 10;
        $expectedPredictorTable = "tbl2";
        $absVal = "$maxPoints - abs($expectedPredictorTable.".PredictorGameTable::COL_GOALS_HOME."-tbl1.".self::COL_GOALS_HOME.") - abs($expectedPredictorTable.".PredictorGameTable::COL_GOALS_AWAY."-tbl1.".self::COL_GOALS_AWAY.")";
        $outcomeEquals = "tbl1.".self::COL_OUTCOME."=$expectedPredictorTable.".PredictorGameTable::COL_OUTCOME;
        $columns[] = new ConditionalSumColumn ("pts", "$outcomeEquals and $absVal > 0", "$absVal", 0);
        $columns[] = new ConditionalSumColumn ("outc", "$outcomeEquals and $expectedPredictorTable.".self::COL_OUTCOME." IS NOT NULL", "1", 0);
        $columns[] = new ConditionalSumColumn ("outcTotal", "$expectedPredictorTable.".self::COL_OUTCOME." IS NOT NULL", "1", 0);
        $columns[] = new ConditionalSumColumn ("resG", "$expectedPredictorTable.".self::COL_OUTCOME." IS NOT NULL and $expectedPredictorTable.".PredictorGameTable::COL_GOALS_HOME."=tbl1.".self::COL_GOALS_HOME." and $expectedPredictorTable.".PredictorGameTable::COL_GOALS_AWAY."=tbl1.".self::COL_GOALS_AWAY, "1", 0);
        
        $rows = $this->selectBy ($columns, $excludedCriteria, $joins, $params);
        if (empty ($rows))
            return $rows;
        $userIds = array ();
        foreach ($rows as &$row)
            {
            $row["pct"] = $row["cnt"] > 0 ? ($row["pts"] / ($row["cnt"] * $maxPoints)) : NULL;
            $userIds[] = $row[self::COL_USER_ID];
            }

        $idToName = array ();
        if (!empty ($userIds))
            {
            $usersTable = new UsersTable ($this->context);
            $criteria = array (new InCriterion (UsersTable::COL_ID, $userIds));
            $users = $usersTable->selectBy (array (UsersTable::COL_ID, UsersTable::COL_NAME), $criteria);
            if (!empty ($users))
                {
                foreach ($users as $userRow)
                    $idToName[$userRow[UsersTable::COL_ID]] = $userRow[UsersTable::COL_NAME];
                }
            }

        foreach ($rows as &$row)
            {
            $userId = $row[self::COL_USER_ID];
            $userName = empty ($idToName[$userId]) ? "[$userId]" : $idToName[$userId];
            $row[UsersTable::COL_NAME] = $userName;
            $row["uid"] = $userId;
            }

        return $rows;
        }
    }

/* A database table which stores match predictor season labels */
class PredictorSeasonTable extends DBTableWithPerspective
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "predictorseason";

    const COL_ID = "pred_season_id";
    const COL_START_DATE = "started";
    const COL_END_DATE = "ended";
    const COL_SEASON = "season_id";
    const COL_LABEL = "label";
    const COL_DESCRIPTION = "description";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     $this->getPerspectiveColumn (),
                     new TextColumn (DBTable::COL_LANG, 5),
                     new TextColumn (self::COL_LABEL, 64),
                     new DateColumn (self::COL_START_DATE, true),
                     new DateColumn (self::COL_END_DATE, true),
                     new LongTextColumn (self::COL_DESCRIPTION, true),
                     new IntColumn (self::COL_SEASON),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new UniqueIndex (self::COL_PERSPECTIVE, DBTable::COL_LANG, self::COL_LABEL),
            );
        }

    public function insertRecord ($nameToValue)
        {
        if (empty ($nameToValue[DBTable::COL_LANG]))
            $nameToValue[DBTable::COL_LANG] = $this->context->getLanguage();

        $ret = parent::insertRecord ($nameToValue);
        return $ret;
        }

    }

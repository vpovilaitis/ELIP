<?php
require_once (PATH."inc/language.php");
require_once (PATH."inc/sports/leaguetablerow.php");

class LeagueTableCollector
    {
    const ADD_ALL = 0;
    const ADD_FOR_EXISTING_TEAMS = 1;
    const POINTS_FOR_EXISTING_TEAMS = 2;
    
    public static function retrieveSimpleTable ($context, $leagueId)
        {
        $leagueRow = self::getCompetitionRow ($context, $leagueId);
        $system = $leagueRow["c_system"];

        if (empty ($system) || ($system >= LeagueConstants::SYSTEM_LEAGUE_MIN && $system <= LeagueConstants::SYSTEM_LEAGUE_MAX))
            {
            $rounds = $leagueRow["c_rounds"];
            $hasLeagueResults = $additionalMatches = $dataInconsistencies = $hasMatches;
            return self::retrieveLeagueTable ($context, $leagueId, $system, $rounds, $hasLeagueResults, $additionalMatches, $dataInconsistencies, $hasMatches, $leagueRow["c_".Sports::COL_COMPETITION_STARTS]);
            }

        return false;
        }

    public static function retrieveLeagueTable ($context, $leagueId, $system, $rounds,
                                                &$hasLeagueResults, &$additionalMatches, &$dataInconsistencies, &$hasMatches, $date)
        {
        $teams = array ();
        $renamedTeamIds = array ();
        $minPlace = NULL;
        if (false === self::retrieveTeamsWithFixedStats ($context, $leagueId, $teams, $renamedTeamIds, $hasLeagueResults) ||
            false === self::recalculateByMatches ($context, $leagueId, $system, $rounds, $teams, $renamedTeamIds, $additionalMatches, $hasMatches, $dataInconsistencies))
            {
            return false;
            }

        $retrievedFixed = NULL;
        if (LeagueConstants::SYSTEM_LEAGUE_STAGE_RES == $system)
            {
            $retrievedFixed = self::retrievePreviousCompetitionResults ($context, $leagueId, $teams, $minPlace);
            if (false === $retrievedFixed)
                return false;
            }
        
        if (LeagueConstants::SYSTEM_LEAGUE_STAGE_INT == $system || (LeagueConstants::SYSTEM_LEAGUE_STAGE_RES == $system && 0 == $retrievedFixed))
            {
            if (false === self::retrievePreviousCompetitionMatches ($context, $leagueId, $system, $rounds, LeagueConstants::SYSTEM_LEAGUE_STAGE_INT == $system, $teams, $renamedTeamIds, $additionalMatches, $hasMatches, $dataInconsistencies))
                return false;
            }

        $i = 0;
        if (!empty ($minPlace))
            $i = $minPlace - 1;

        foreach ($teams as $team)
            $team->place = ++$i;
        uasort ($teams, array("LeagueTableCollector", "compareStored"));
        self::ensureTeamLabels ($context, $teams, $date);
        return $teams;
        }

    public static function retrieveTeamsWithFixedStats ($context, $leagueId, &$teams, &$renamedTeamIds, &$hasLeagueResults)
        {
        $doNotLoad = !empty ($_REQUEST["skipfixed"]) || !empty ($_REQUEST["filter"]);

        $resultsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMLEAGUESEASON);
        if (empty ($resultsTable))
            return false;

        $altNameColumn = ContentTable::generateForeignKeyColumn ("altname", Sports::TABLE_TEAM."_id");
        $compstageIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAMLEAGUESEASON_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $criteria = array (new EqCriterion ($compstageIdColumn, $leagueId));
        $columns = array ("team_id", "teamleagueseasons_id", "place", "win", "draw", "lost", "pts", "conceded", "scored", "deduction", $altNameColumn);
        $rows = $resultsTable->selectBy ($columns, $criteria);
        if (empty ($rows))
            return true;

        $criteria = array ();

        foreach ($rows as $row)
            {
            $hasLeagueResults = true;
            $teamId = $row["team_id"];

            if (!isset ($teams[$teamId]))
                $teams[$teamId] = new LeagueTableRow (array ($teamId), $row["teamleagueseasons_id"]);

            $team = &$teams[$teamId];
            if (!empty ($row[$altNameColumn]))
                $renamedTeamIds[$row[$altNameColumn]] = $teamId;
            if ($doNotLoad)
                continue;
            $team->win = $row["c_win"];
            $team->draw = $row["c_draw"];
            $team->lost = $row["c_lost"];
            $team->pts = $row["c_pts"];
            $team->conceded = $row["c_conceded"];
            $team->scored = $row["c_scored"];
            $team->placeStored = $row["c_place"];
            $team->deduction = $row["c_deduction"];
            }
        }

    public static function recalculateByMatches ($context, $leagueId, $system, $rounds, &$teams, &$renamedTeamIds, &$additionalMatches, &$hasMatches, &$dataInconsistencies)
        {
        $criteria = array (new EqCriterion ("cstage", $leagueId));
        return self::addCompetitionMatches ($context, $criteria, $system, self::ADD_ALL, $rounds, $teams, $renamedTeamIds, $additionalMatches, $hasMatches, $dataInconsistencies);
        }

    public static function addCompetitionMatches ($context, $criteria, $system, $mode, $rounds, &$teams, &$renamedTeamIds, &$additionalMatches, &$hasMatches, &$dataInconsistencies)
        {
        $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id");
        $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id");
        $filterHome = !empty ($_REQUEST["filter"]) ? 0 === strcasecmp ("home", $_REQUEST["filter"]) : NULL;
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        if (empty ($matchesTable))
            return false;

        if (!empty ($_REQUEST["todate"]))
            $criteria[] = new LtEqCriterion ("c_time", $_REQUEST["todate"]);
        $columns = array ("match_id", "time", $homeTeamColumn, $awayTeamColumn, "result", "outcome", "round", "exclude");
        $params[] = OrderBy::create ("c_".Sports::COL_MATCH_DATE, "c_".Sports::COL_MATCH_NUMBER, Sports::COL_MATCH_STAGE);

        $rows = $matchesTable->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rows))
            return true;

        $ptsForPenaltyWin = 3;
        $ptsForPenaltyLost = 0;
        switch ($system)
            {
            case LeagueConstants::SYSTEM_LEAGUE_PRE_1995:
                $ptsForWin = 2;
                $ptsForDraw = 1;
                $ptsForLost = 0;
                break;
            case LeagueConstants::SYSTEM_LEAGUE_9x9:
                $ptsForWin = 3;
                $ptsForLost = 0;
                $ptsForPenaltyWin = 2;
                $ptsForPenaltyLost = 1;
                $ptsForDraw = 1; // 2 or 1
                break;
            default:
                $ptsForWin = 3;
                $ptsForDraw = 1;
                $ptsForLost = 0;
                break;
            }

        foreach ($rows as $row)
            {
            if (false === self::processMatch ($context, $row, $teams, $renamedTeamIds, $additionalMatches, $hasMatches, $dataInconsistencies, $rounds, $ptsForWin, $ptsForDraw, $ptsForLost, $ptsForPenaltyWin, $ptsForPenaltyLost, $filterHome, $mode))
                return false;
            }

        uasort ($teams, array("LeagueTableCollector", "compare"));
        
        $lastPoints = -200;
        $currentGroup = NULL;

        foreach ($teams as $team)
            {
            $vars = get_object_vars ($team);
            
            if ($lastPoints != $team->getTotal ($vars, "pts"))
                {
                if (count ($currentGroup) > 1)
                    self::collectSubResults ($system, $currentGroup);
                $currentGroup = array ();
                $lastPoints = $team->getTotal ($vars, "pts");
                }

            $currentGroup[] = $team;
            }

        if (count ($currentGroup) > 1)
            self::collectSubResults ($system, $currentGroup);

        uasort ($teams, array("LeagueTableCollector", "compareNeighbors"));
        }

    public static function processMatch ($context, $row, &$teams, &$renamedTeamIds, &$additionalMatches, &$hasMatches, &$dataInconsistencies, $rounds, $ptsForWin, $ptsForDraw, $ptsForLost, $ptsForPenaltyWin, $ptsForPenaltyLost, $filterHome, $mode)
        {
        $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id");
        $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id");
        if (empty ($row[$homeTeamColumn]) || empty ($row[$awayTeamColumn]))
            return true;

        $calculateHome = NULL === $filterHome || true === $filterHome;
        $calculateAway = NULL === $filterHome || false === $filterHome;
        $matchIdString = $row["match_id"];

        if (!empty ($row["c_exclude"]))
            {
            if (self::ADD_ALL != $mode)
                return true;

            $hometeam = new CupResultsRow ($row[$homeTeamColumn]);
            $awayteam = new CupResultsRow ($row[$awayTeamColumn]);
            $hasResult = (NULL !== $row["c_homeresult"] && NULL !== $row["c_awayresult"]);
            $result = $hasResult ? $row["c_result"] : self::createMatchDateLabel ($context, $row["c_time"]);
            $match = new CupCompetitionMatch ($matchIdString, $row["c_time"], $result,
                                              $hometeam, $awayteam,
                                              $row["c_homeresult"], $row["c_awayresult"]);
            $round = $row["round.displayname"];
            if (!isset ($additionalMatches[$round]))
                $additionalMatches[$round] = array ($match);
            else
                $additionalMatches[$round][] = $match;

            $pairTeams = array ($hometeam, $awayteam);
            self::ensureTeamLabels ($context, $pairTeams, $row[Sports::COL_MATCH_DATE]);
            return true;
            }

        if (self::ADD_ALL == $mode)
            $hasMatches = true;

        $homeId = $row[$homeTeamColumn];
        $awayId = $row[$awayTeamColumn];
        if (array_key_exists ($homeId, $renamedTeamIds))
            $homeId = $renamedTeamIds[$homeId];
        if (array_key_exists ($awayId, $renamedTeamIds))
            $awayId = $renamedTeamIds[$awayId];

        if (self::ADD_ALL == $mode)
            {
            if (!isset ($teams[$homeId]))
                $teams[$homeId] = new LeagueTableRow ($homeId);
            if (!isset ($teams[$awayId]))
                $teams[$awayId] = new LeagueTableRow ($awayId);

            $homeTeam = &$teams[$homeId];
            $awayTeam = &$teams[$awayId];
            }
        else if (!isset ($teams[$homeId]) && !isset ($teams[$awayId]))
            return true;
        else
            {
            if (self::ADD_FOR_EXISTING_TEAMS == $mode && (!isset ($teams[$homeId]) || !isset ($teams[$awayId])))
                return true;

            if (isset ($teams[$homeId]))
                $homeTeam = &$teams[$homeId];
            else
                {
                $homeTeam = NULL;
                $calculateHome = false;
                }

            if (isset ($teams[$awayId]))
                $awayTeam = &$teams[$awayId];
            else
                {
                $awayTeam = NULL;
                $calculateAway = false;
                }
            }

        $outcome = $row["c_outcome"];
        $hasResult = (NULL !== $row["c_homeresult"] && NULL !== $row["c_awayresult"]);
        $result = NULL;
        $pointsCalculated = false;

        if (MatchConstants::OUTCOME_ANNULLED == $outcome)
            {
            $dataInconsistencies = $context->getText ("Result annulled ([_0])", self::createMatchDateLabel ($context, $row["c_time"]));
            return true;
            }

        switch ($outcome)
            {
            case MatchConstants::OUTCOME_NO_HOME_TEAM:
            case MatchConstants::OUTCOME_AWAY_WIN:
            case MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT:
                if (!$hasResult || MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT == $outcome)
                    {
                    if ($calculateHome)
                        {
                        $homeTeam->lostHome++;
                        $homeTeam->ptsHome += $ptsForLost;
                        }

                    if ($calculateAway)
                        {
                        $awayTeam->winAway++;
                        $awayTeam->ptsAway += $ptsForWin;
                        }

                    if (!$hasResult)
                        {
                        $result = "- : +";
                        if (MatchConstants::OUTCOME_AWAY_WIN == $outcome)
                            $result = "- ? +";
                        }
                    else
                        $pointsCalculated = true;
                    }
                else
                    $dataInconsistencies = $context->getText ("Result entered with no game played ([_0])", self::createMatchDateLabel ($context, $row["c_time"]));
                break;
            case MatchConstants::OUTCOME_NO_VISITORS:
            case MatchConstants::OUTCOME_HOME_WIN:
            case MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT:
                if (!$hasResult || MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT == $outcome)
                    {
                    if ($calculateHome)
                        {
                        $homeTeam->winHome++;
                        $homeTeam->ptsHome += $ptsForWin;
                        }

                    if ($calculateAway)
                        {
                        $awayTeam->lostAway++;
                        $awayTeam->ptsAway += $ptsForLost;
                        }

                    if (!$hasResult)
                        {
                        $result = "+ : -";
                        if (MatchConstants::OUTCOME_HOME_WIN == $outcome)
                            $result = "+ ? -";
                        }
                    else
                        $pointsCalculated = true;
                    }
                else
                    $dataInconsistencies = $context->getText ("Result entered with no game played ([_0])", self::createMatchDateLabel ($context, $row["c_time"]));
                break;
            case MatchConstants::OUTCOME_BOTH_LOOSE:
                if (!$hasResult)
                    {
                    if ($calculateHome)
                        {
                        $homeTeam->lostHome++;
                        $homeTeam->ptsHome += $ptsForLost;
                        }
                    if ($calculateAway)
                        {
                        $awayTeam->lostAway++;
                        $awayTeam->ptsAway += $ptsForLost;
                        }
                    $result = "- : -";
                    }
                else
                    $dataInconsistencies = $context->getText ("Result entered with no game played ([_0])", self::createMatchDateLabel ($context, $row["c_time"]));
                break;
            case MatchConstants::OUTCOME_PENALTIES_HOME:
                $result = $hasResult ? ($row["c_homeresult"]."* : ".$row["c_awayresult"]) : "+:-";
                break;
            case MatchConstants::OUTCOME_PENALTIES_AWAY:
                $result = $hasResult ? ($row["c_homeresult"]." : ".$row["c_awayresult"]."*") : "+:-";
                break;
            case MatchConstants::OUTCOME_NOT_STARTED:
            case MatchConstants::OUTCOME_CANCELLED:
                if ($hasResult)
                    $dataInconsistencies = $context->getText ("Result entered with no game played ([_0])", self::createMatchDateLabel ($context, $row["c_time"]));
                break;

            case MatchConstants::OUTCOME_TECHNICAL_WIN:
            case MatchConstants::OUTCOME_PENALTIES:
            default:
                break;
            }

        if (empty ($result))
            $result = $hasResult ? $row["c_result"] : self::createMatchDateLabel ($context, $row["c_time"]);

        $teamIdString = NULL !== $awayTeam ? $awayTeam->getKey () : NULL;
        $homeTeamIdString = NULL !== $homeTeam ? $homeTeam->getKey () : NULL;

        if (self::POINTS_FOR_EXISTING_TEAMS != $mode)
            {
            if ($calculateHome)
                {
                $homeResult = $pointsCalculated ? "$result *" : $result;
                if (!isset ($homeTeam->homeMatches[$teamIdString]))
                    $homeTeam->homeMatches[$teamIdString] = array ($matchIdString => $homeResult);
                else
                    $homeTeam->homeMatches[$teamIdString][$matchIdString] = $homeResult;
                }

            if ($calculateAway && empty ($_REQUEST["homeaway"]) && (!$calculateHome || 1 == $rounds || 2 == $rounds || 3 == $rounds))
                {
                $awayResult = self::invertResult ($result);
                if ($pointsCalculated)
                    $awayResult .= " *";
                if (!isset ($awayTeam->homeMatches[$homeTeamIdString]))
                    $awayTeam->homeMatches[$homeTeamIdString] = array ($matchIdString => $awayResult);
                else
                    $awayTeam->homeMatches[$homeTeamIdString][$matchIdString] = $awayResult;
                }
            }

        if (!$hasResult) // not played yet
            return true;

        if (!$pointsCalculated)
            {
            if ($row["c_homeresult"] > $row["c_awayresult"] || MatchConstants::OUTCOME_PENALTIES_HOME == $outcome)
                {
                if ($calculateHome)
                    {
                    $homeTeam->winHome++;
                    $homeTeam->ptsHome += (MatchConstants::OUTCOME_PENALTIES_HOME == $outcome) ? $ptsForPenaltyWin : $ptsForWin;
                    }
                if ($calculateAway)
                    {
                    $awayTeam->lostAway++;
                    $awayTeam->ptsAway += (MatchConstants::OUTCOME_PENALTIES_HOME == $outcome) ? $ptsForPenaltyLost : $ptsForLost;
                    }

                $interResult = $ptsForWin;
                }
            else if ($row["c_homeresult"] < $row["c_awayresult"] || MatchConstants::OUTCOME_PENALTIES_AWAY == $outcome)
                {
                if ($calculateHome)
                    {
                    $homeTeam->lostHome++;
                    $homeTeam->ptsHome += (MatchConstants::OUTCOME_PENALTIES_AWAY == $outcome) ? $ptsForPenaltyLost : $ptsForLost;
                    }
                if ($calculateAway)
                    {
                    $awayTeam->winAway++;
                    $awayTeam->ptsAway += (MatchConstants::OUTCOME_PENALTIES_AWAY == $outcome) ? $ptsForPenaltyWin : $ptsForWin;
                    }
                $interResult = -$ptsForWin;
                }
            else // if ($row["c_homeresult"] == $row["c_awayresult"])
                {
                if ($calculateHome)
                    {
                    $homeTeam->drawHome++;
                    $homeTeam->ptsHome += $ptsForDraw;
                    }
                if ($calculateAway)
                    {
                    $awayTeam->drawAway++;
                    $awayTeam->ptsAway += $ptsForDraw;
                    }
                $interResult = 0;
                }
            }

        if ($calculateHome)
            {
            $homeTeam->scoredHome += $row["c_homeresult"];
            $homeTeam->concededAway += $row["c_awayresult"];
            }
        if ($calculateAway)
            {
            $awayTeam->concededHome += $row["c_homeresult"];
            $awayTeam->scoredAway += $row["c_awayresult"];
            }
        
        if (self::POINTS_FOR_EXISTING_TEAMS == $mode && (NULL === $homeTeam || NULL === $awayTeam))
            return true;

        /*
            prepare for neighbor team point calculations -
                calculate count of wins agains each team
                and calculates score difference agains each team
                (will need that for sorting)
        */
        if (!isset ($homeTeam->resultsAgainst[$teamIdString]))
            $homeTeam->resultsAgainst[$teamIdString] = $interResult;
        else
            $homeTeam->resultsAgainst[$teamIdString] += $interResult;
        if (!isset ($awayTeam->resultsAgainst[$homeTeamIdString]))
            $awayTeam->resultsAgainst[$homeTeamIdString] = -$interResult;
        else
            $awayTeam->resultsAgainst[$homeTeamIdString] -= $interResult;

        $interScores = $row["c_homeresult"] - $row["c_awayresult"];
            
        if (!isset ($homeTeam->scoresAgainst[$teamIdString]))
            $homeTeam->scoresAgainst[$teamIdString] = $interScores;
        else
            $homeTeam->scoresAgainst[$teamIdString] += $interScores;
        if (!isset ($awayTeam->scoresAgainst[$homeTeamIdString]))
            $awayTeam->scoresAgainst[$homeTeamIdString] = -$interScores;
        else
            $awayTeam->scoresAgainst[$homeTeamIdString] -= $interScores;

        if (!isset ($homeTeam->totalInterGoals[$teamIdString]))
            $homeTeam->totalInterGoals[$teamIdString] = $row["c_homeresult"];
        else
            $homeTeam->totalInterGoals[$teamIdString] += $row["c_homeresult"];
        if (!isset ($awayTeam->totalInterGoals[$homeTeamIdString]))
            $awayTeam->totalInterGoals[$homeTeamIdString] = $row["c_awayresult"];
        else
            $awayTeam->totalInterGoals[$homeTeamIdString] += $row["c_awayresult"];
        }

    protected static function collectSubResults ($system, $teams)
        {
        for ($i = 0; $i < count ($teams); $i++)
            {
            for ($j = $i + 1; $j < count ($teams); $j++)
                {
                self::collectSubResultsFor2Teams ($system, $teams[$i], $teams[$j]);
                }
            }
        }

    protected static function collectSubResultsFor2Teams ($system, $team1, $team2)
        {
        if ($system == LeagueConstants::SYSTEM_LEAGUE_PRE_1995)
            return;

        $teamIdString = $team2->getKey ();
        if (isset ($team1->resultsAgainst[$teamIdString]))
            {
            $team1->neighborPts += $team1->resultsAgainst[$teamIdString];
            $team2->neighborPts -= $team1->resultsAgainst[$teamIdString];
            $team1->neighborScores += $team1->scoresAgainst[$teamIdString];
            $team2->neighborScores -= $team1->scoresAgainst[$teamIdString];
            $team1->neighbourGoals += $team1->totalInterGoals[$teamIdString];
            $team2->neighbourGoals += $team2->totalInterGoals[$team1->getKey ()];
            }
        }

    protected static function retrievePreviousCompetitionMatches ($context, $leagueId, $system, $rounds, $addMatches, &$teams, &$renamedTeamIds, &$additionalMatches, &$hasMatches, &$dataInconsistencies)
        {
        $competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        if (empty ($competitionsTable))
            return false;

        $competitionRow = self::getCompetitionRow ($context, $leagueId);
        if (empty ($competitionRow))
            return false;

        $parentColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_PARENT, Sports::TABLE_COMPETITIONSTAGE."_id");
        $parentId = $competitionRow[$parentColumn];
        if (empty ($parentId))
            return NULL;

        $date = $competitionRow["c_".Sports::COL_COMPETITION_STARTS];
        $priority = $competitionRow["c_".Sports::COL_COMPETITION_PRIORITY];
        $criteria = array ();
        if (!empty ($date))
            $criteria[] = new LtCriterion ("c_".Sports::COL_COMPETITION_ENDS, $date);
        else
            $criteria[] = new LtCriterion ("c_".Sports::COL_COMPETITION_PRIORITY, $priority);
        $criteria[] = new EqCriterion ($parentColumn, $parentId);
        $predecessors = $competitionsTable->selectBy (array ($competitionsTable->getIdColumn ()), $criteria);
        if (empty ($predecessors))
            return NULL;
        
        $ids = array ();
        foreach ($predecessors as $row)
            $ids[] = $row[$competitionsTable->getIdColumn ()];

        $criteria = array (new InCriterion (ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, $competitionsTable->getIdColumn ()), $ids));
        return self::addCompetitionMatches ($context, $criteria, $system, $addMatches ? self::ADD_FOR_EXISTING_TEAMS : self::POINTS_FOR_EXISTING_TEAMS,
                                            $rounds, $teams, $renamedTeamIds, $additionalMatches, $hasMatches, $dataInconsistencies);
        }

    protected static function createTeamsTableJoin ($context)
        {
        $teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        if (empty ($teamsTable))
            return false;

        $columns = array ("shortname");
        $criteria = array (new JoinColumnsCriterion ("team_id", "team_id"));
        $teamsQuery = $teamsTable->createQuery ($columns, $criteria);
        return $teamsQuery;
        }

    protected static function retrievePreviousCompetitionResults ($context, $leagueId, &$teams, &$minPlace)
        {
        $resultsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMLEAGUESEASON);
        $teamsQuery = self::createTeamsTableJoin ($context);
        $competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        if (empty ($resultsTable) || empty ($teamsQuery) || empty ($competitionsTable))
            return false;

        $criteria = array
            (
            new LogicalOperatorOr
                (
                new EqCriterion ("f_promoteto_competitionstage_id", $leagueId),
                new EqCriterion ("f_relegateto_competitionstage_id", $leagueId)
                ),
            new JoinColumnsCriterion (ContentTable::generateForeignKeyColumn (Sports::COL_TEAMLEAGUESEASON_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id"), Sports::TABLE_COMPETITIONSTAGE."_id"),
            );
        $competitionsQuery = $competitionsTable->createQuery (array (), $criteria);

        $columns = array ("team_id", "teamleagueseasons_id", "place", "win", "draw", "lost", "pts", "conceded", "scored");
        $criteria = null;
        $rows = $resultsTable->selectBy ($columns, $criteria, array ($teamsQuery, $competitionsQuery));
        if (empty ($rows))
            return NULL;

        $minPlace = NULL;
        $validCount = 0;
        foreach ($rows as $row)
            {
            $parentId = array ($row["team_id"]);
            $teamId = implode ("_", $parentId);

            if (!isset ($teams[$teamId]))
                continue;

            $validCount += NULL !== $row["c_pts"];
                
            $team = &$teams[$teamId];
            $team->winMod = $row["c_win"];
            $team->drawMod = $row["c_draw"];
            $team->lostMod = $row["c_lost"];
            $team->ptsMod = $row["c_pts"];
            $team->concededMod = $row["c_conceded"];
            $team->scoredMod = $row["c_scored"];
            if (NULL === $minPlace || $minPlace > $row["c_place"])
                $minPlace = $row["c_place"];
            }

        uasort ($teams, array("LeagueTableCollector", "compare"));
        return $validCount;
        }

    static function compare ($a, $b)
        {
        if ($b->placeStored != $a->placeStored)
            {
            if (0 === $a->placeStored)
                return 1;
            else if (0 === $b->placeStored)
                return -1;
            }

        $varsA = get_object_vars ($a);
        $varsB = get_object_vars ($b);
        $ptsA = $a->getTotal ($varsA, "pts", false);
        $ptsB = $b->getTotal ($varsB, "pts", false);
        if ($ptsA != $ptsB)
            return $ptsB - $ptsA;

        // if same amount of points, sort by games against neighbors (all with same point amount)
        if ($a->neighborPts != $b->neighborPts)
            return $b->neighborPts - $a->neighborPts;
        if ($a->neighborScores != $b->neighborScores)
            return $b->neighborScores - $a->neighborScores;
        if ($a->neighbourGoals != $b->neighbourGoals)
            return $b->neighbourGoals - $a->neighbourGoals;

        // if still equal, sort by score difference
        $scoredA = $a->getTotal ($varsA, "scored", false);
        $scoredB = $b->getTotal ($varsB, "scored", false);
        $diffA = $scoredA - $a->getTotal ($varsA, "conceded", false);
        $diffB = $scoredB - $b->getTotal ($varsB, "conceded", false);
        if ($diffA < $diffB)
            return 1;
        if ($diffA > $diffB)
            return -1;

        if ($scoredA < $scoredB)
            return 1;
        if ($scoredA > $scoredB)
            return -1;

        if (!empty ($a->place) && !empty ($b->place) && $a->place != $b->place)
            return $a->place - $b->place;

        return 0;
        }

    static function compareNeighbors ($a, $b)
        {
        return self::compare ($a, $b);
        }

    static function compareStored ($a, $b)
        {
        if (NULL !== $a->placeStored && NULL !== $b->placeStored && $a->placeStored != $b->placeStored)
            {
            if (0 == $a->placeStored) // team is disqualified, move to the end
                return 1;
            if (0 == $b->placeStored) // team is disqualified, move to the end
                return -1;
                
            return $a->placeStored - $b->placeStored;
            }

        return self::compareNeighbors ($a, $b);
        }

    protected static function invertResult ($result)
        {
        $parts = explode (":", $result);
        if (2 == count ($parts))
            return trim ($parts[1])." : ".trim ($parts[0]);
        $parts = explode ("?", $result);
        if (2 == count ($parts))
            return trim ($parts[1])." ? ".trim ($parts[0]);
        return $result;
        }

    public static function createMatchDateLabel ($context, $date)
        {
        $lng = Language::getInstance($context);
        $longString = $lng->dateToLongString ($date);
        if (empty ($longString))
            return "?";

        list ($year, $month, $day) = sscanf ($date, "%d-%d-%d");

        $show = "?";
        if (!empty ($month) && !empty ($day))
            $show = sprintf ("(%02d-%02d)", $month, $day);

        return "<span class=\"leaguetableDate ui-state-disabled\" title=\"$longString\">$show</span>";
        }

    public static function ensureTeamLabels ($context, &$teams, $date)
        {
        $ids = $allIds = array ();
        foreach ($teams as &$team)
            {
            $name = $team->getName ();
            if (empty ($name))
                $ids[] = $team->getExactTeamId ();
            $allIds[] = $team->getExactTeamId ();
            }

        $teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        if (!empty ($ids))
            {
            $labels = SportsHelper::getTeamLabels ($context, $ids, $date);
            foreach ($teams as &$team)
                {
                $name = $team->getName ();
                if (empty ($name))
                    $ids[] = $team->setName ($labels[$team->getExactTeamId ()]);
                }
            }

        $logos = SportsHelper::getTeamLogos ($context, $allIds, $date);
        foreach ($teams as &$team)
            {
            $logo = $logos[$team->getExactTeamId ()];
            if (!empty ($logo))
                $team->setLogo ($logo);
            }
        }

    protected static function getCompetitionRow ($context, $leagueId)
        {
        $cache = Cache::getInstance (Sports::TABLE_COMPETITIONSTAGE, 6*60*60);
        $key = "leaguerow_$leagueId";
        if (false === ($result = $cache->get ($key)))
            {
            $competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
            if (empty ($competitionsTable))
                return false;

            $criteria = array (new EqCriterion ($competitionsTable->getIdColumn (), $leagueId));
            $result = $competitionsTable->selectSingleBy (NULL, $criteria);

            $cache->save ($result, $key);
            }

        return $result;
        }
    }


<?php
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'inc/sports/common.php');

class CompetitionNamesTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "leaguenamechanges";

    const COL_ID = "id";
    const COL_LEAGUEID = "leagueid";
    const COL_DATEFROM = "datefrom";
    const COL_DATETO = "dateto";
    const COL_NAME = "name";
    const COL_DESCRIPTION = "description";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        $this->tracksRevisions = true;
        $this->tracksSources = true;
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID, false),
                     new IntColumn (self::COL_LEAGUEID, false),
                     new DateColumn (self::COL_DATEFROM, true),
                     new DateColumn (self::COL_DATETO, true),
                     new TextColumn (self::COL_NAME, 64, true),
                     new LongTextColumn (self::COL_DESCRIPTION, true),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new UniqueIndex (self::COL_LEAGUEID, self::COL_DATEFROM),
            new Index (self::COL_NAME),
            );
        }
    }

<?php

abstract class TeamResultsRow
    {
    public $name;
    public $logo;
    protected $teamId;
    protected $recordedTeamId;
    protected $id;

    public function __construct ($teamId, $id = NULL, $name = NULL)
        {
        if (is_array ($teamId))
            $teamId = $teamId[0];
        $this->name = $name;
        $this->teamId = $teamId;
        if (!empty ($id))
            {
            $this->id = array ($teamId, $id);
            }
        }

    public function setName ($name)
        {
        $this->name = $name;
        }

    public function getName ($context = NULL, $date = false)
        {
        if (!empty ($context) && false !== $date)
            {
            $labels = SportsHelper::getTeamLabels ($context, array ($this->teamId), $date);
            if (!empty ($labels))
                return $labels[$this->teamId];
            }
        return $this->name;
        }

    public function setLogo ($logo)
        {
        $this->logo = $logo;
        }

    public function setRecordedId ($id)
        {
        $this->recordedTeamId = $id;
        }

    public function getId ($team = true)
        {
        $id = $team ? (empty ($this->recordedTeamId) ? $this->teamId : $this->recordedTeamId) : $this->id;
        
        if (is_array ($id))
            return implode ("_", $id);
        return $id;
        }

    public function getExactTeamId ()
        {
        return $this->teamId;
        }

    public function hasDBEntry ()
        {
        return !empty ($this->id);
        }

    public function getUrl ($context)
        {
        $dbtable = ContentTable::createInstanceByName ($context, "team");
        if (empty ($dbtable))
            return NULL;
        else
            {
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $dbtable,
                                                                         $dbtable->getId (),
                                                                         $this->teamId);
            return $url;
            }
        }

    public function getTeamUrl ($context, $shortName = false, $date = false)
        {
        $url = $this->getUrl ($context);
        $name = $this->getName ($context, $date);
        if ($shortName)
            $name = Language::getInstance ($context)->beautifyTeamLabel ($name);

        if (empty ($url))
            return $name;
        else
            return '<a href="'.$url.'">'.$name.'</a>';
        }

    protected abstract function getDBTable ($context);

    public function getResultsRowUrl ($context, $edit)
        {
        if (empty ($this->id))
            return NULL;

        $dbtable = $this->getDBTable ($context);

        if (empty ($dbtable))
            return NULL;
        else
            {
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $dbtable,
                                                                         $dbtable->getId (),
                                                                         $this->id,
                                                                         $edit ? Constants::MODE_EDIT : Constants::MODE_VIEW);
            return $url;
            }
        }

    }

<?php
require_once (PATH."inc/sports/flot.php");

class CompetitionStatistics
    {
    public static function getGoalsAndCardsStatistics ($context, $leagueId, $groupBy = 5, $teamId = NULL)
        {
        $result = array ();
        $goals = self::getMatchStatisticsData ($context, $leagueId,
                                              Sports::TABLE_MATCHGOAL, $context->getText ("Goals"),
                                              Sports::COL_GOAL_TIME_MIN, Sports::COL_GOAL_TIME_EXTRA, NULL, $groupBy);
        if (!empty ($goals))
            $result[] = $goals;
        $goals = self::getMatchStatisticsData ($context, $leagueId,
                                              Sports::TABLE_MATCHEVENT, $context->getText ("Cards"),
                                              Sports::COL_EVENT_TIME_MIN, Sports::COL_EVENT_TIME_EXTRA,
                                              array (new InCriterion ("c_".Sports::COL_EVENT_TYPE,
                                              array (MatchConstants::EVENT_YELLOW, MatchConstants::EVENT_YELLOW_RED, MatchConstants::EVENT_RED))),
                                              $groupBy);
        if (!empty ($goals))
            $result[] = $goals;

        if (empty ($result))
            return NULL;

        return new FlotData ($result, self::getGoalStatisticsOptions ($result));
        }

    public static function getMatchStatisticsByRound ($context, $leagueId, $teamId)
        {
        $cache = Cache::getInstance (Sports::TABLE_MATCH, 6*60*60);
        $key = Sports::TABLE_MATCH.'-matchstats-r-graph-'.$leagueId."-".$teamId;
        if (false === ($result = $cache->get ($key)))
            {
            $result = self::getMatchStatisticsByRoundNoCache ($context, $leagueId, false, $teamId);
            $cache->save ($result, $key);
            }

        if (empty ($result))
            return NULL;

        return new FlotData ($result, self::getGoalByRoundStatisticsOptions ($result));
        }

    public static function getAttendanceStatisticsByRound ($context, $leagueId, $teamId)
        {
        $cache = Cache::getInstance (Sports::TABLE_MATCH, 6*60*60);
        $key = Sports::TABLE_MATCH.'-attendstats-r-graph-'.$leagueId."-".$teamId;
        if (false === ($result = $cache->get ($key)))
            {
            $result = self::getMatchStatisticsByRoundNoCache ($context, $leagueId, true, $teamId);
            $cache->save ($result, $key);
            }

        if (empty ($result))
            return NULL;

        return new FlotData ($result, self::getGoalByRoundStatisticsOptions ($result));
        }


    protected static function getMatchStatisticsData ($context, $leagueId, $eventsTableName, $label, $timeColumn, $extraTimeColumn, $additionalCriteria = NULL, $groupBy = 5)
        {
        $cache = Cache::getInstance ($eventsTableName, 6*60*60);
        $key = $eventsTableName.'-matchstats-graph'.$groupBy.'-'.$leagueId;
        if (false === ($result = $cache->get ($key)))
            {
            $result = self::getMatchStatisticsDataNoCache ($context, $leagueId, $eventsTableName, $label, $timeColumn, $extraTimeColumn, $additionalCriteria, $groupBy);
            $cache->save ($result, $key);
            }

        return $result;
        }

    protected static function getMatchStatisticsDataNoCache ($context, $leagueId, $eventsTableName, $label, $timeColumn, $extraTimeColumn, $additionalCriteria, $groupBy)
        {
        $goalsTable = ContentTable::createInstanceByName ($context, $eventsTableName);
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $competitionTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $competitionIds = SportsHelper::selectCompetitionHierarchyIds ($context, $competitionTable, array ($leagueId));
        $criteria = SportsHelper::createMatchTableCriterion ($context, $competitionIds, NULL, true);
        $criteria[] = new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ());
        $join = $matchesTable->createQuery (array (), $criteria);

        $columns = array ($timeColumn, $extraTimeColumn);
        $columns[] = new FunctionCount ("*", "cnt");
        $params[] = new GroupBy (array ("c_$timeColumn", "c_$extraTimeColumn"));

        $rows = $goalsTable->selectBy ($columns, $additionalCriteria, array ($join), $params);

        if (empty ($rows) || 1 == count ($rows))
            return null;

        $goalStats = array ();
        for ($i = 0; $i <= 90+$groupBy; $i += $groupBy)
            $goalStats[$i] = 0;
        foreach ($rows as $row)
            {
            if (NULL === $row["c_$timeColumn"])
                continue;

            if (!empty ($row["c_$extraTimeColumn"]) && 90 == $row["c_$timeColumn"])
                {
                $goalStats[90+$groupBy] += $row['cnt'];
                }
            else
                {
                $min = floor ($row["c_$timeColumn"] / $groupBy + 0.5) * $groupBy;
                if (empty ($goalStats[$min]))
                    $goalStats[$min] = $row['cnt'];
                else
                    $goalStats[$min] += $row['cnt'];
                }
            }

        return self::prepareStatsArray ($goalStats, $label, NULL == $additionalCriteria);
        }

    protected static function prepareStatsArray ($arr, $label, $fill = false)
        {
        $options = array ('fill' => ($fill ? true : false));
        return FlotHelper::preparePlotSeries ($arr, $label, $options);
        }

    protected static function getGoalStatisticsOptions ()
        {
        $options = array (
                    'series' => array (
                        'lines' => array ( 'show' => true, 'lineWidth' => 1, 'fill' => true ),
                        'points' => array ( 'show' => true, 'fill' => true )
                        ),
                    'legend' => array (
                        'position' => 'nw',
                        'backgroundOpacity' => 0,
                        ),
                    'yaxis' => array (
                        'min' => 0,
                        'tickSize' => 5,
                        'position' => 'right', 
                        ),
                    'xaxis' => array (
                        'min' => 0,
                        'max' => 95,
                        'tickSize' => 15,
                        'ticks' => array (array (0, "0'"), array (10, "10'"), array (20, "20'"), array (30, "30'"), array (40, "40'"), array (45, "45'"),
                                          array (55, "55'"), array (65, "65'"), array (75, "75'"), array (85, "85'"), array (90, "90'"))
                        ),
                    'grid' => array ( 'hoverable' => true )
                    );
        return $options;
        }

    protected static function getGoalByRoundStatisticsOptions ($result)
        {
        $maxHeight = 0;
        $maxRound = 0;
        foreach ($result as $data)
            {
            foreach ($data['data'] as $pair)
                {
                list ($key, $val) = $pair;
                if ($maxHeight < $val)
                    $maxHeight = $val;
                if ($maxRound < $key)
                    $maxRound = $key;
                }
            }

        $rounds = array ();
        for ($i = 1; $i <= $maxRound; $i++)
            $rounds[] = array ($i, "$i");

        $tickSize = 5;
        if ($maxHeight > 10000)
            $tickSize = 1000;
        else if ($maxHeight > 3000)
            $tickSize = 500;
        else if ($maxHeight > 1000)
            $tickSize = 100;
        else if ($maxHeight > 400)
            $tickSize = 50;
        else if ($maxHeight > 150)
            $tickSize = 20;
        else if ($maxHeight > 50)
            $tickSize = 10;
        
        $options = array (
                    'series' => array (
                        'lines' => array ( 'show' => true, 'lineWidth' => 1, 'fill' => true ),
                        'points' => array ( 'show' => true, 'fill' => true )
                        ),
                    'yaxis' => array (
                        'min' => 0,
                        'max' => $maxHeight + 20,
                        'tickSize' => $tickSize,
                        'position' => 'right', 
                        ),
                    'xaxis' => array (
                        'tickSize' => 1,
                        'ticks' => $rounds
                        ),
                    'legend' => array (
                        'backgroundOpacity' => 0,
                        'margin' => 0,
                        'noColumns' => 2,
                        ),
                    'grid' => array ( 'hoverable' => true )
                    );
        return $options;
        }
        
    protected static function getMatchStatisticsByRoundNoCache ($context, $leagueId, $attendance = false, $teamId = NULL)
        {
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $competitionTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $competitionIds = SportsHelper::selectCompetitionHierarchyIds ($context, $competitionTable, array ($leagueId));
        $criteria = SportsHelper::createMatchTableCriterion ($context, $competitionIds, $attendance ? NULL : $teamId, true);
        $criteria[] = new IsNotNullCriterion ("c_".Sports::COL_MATCH_HOMERESULT);
        $criteria[] = new IsNotNullCriterion ("c_".Sports::COL_MATCH_AWAYRESULT);

        $params[] = new GroupBy (array ("c_".Sports::COL_MATCH_MATCHDAY));
        $columns = array (Sports::COL_MATCH_MATCHDAY);
        $columns[] = new FunctionCount ("*", "cnt");
        if ($attendance)
            {
            $columns[] = new FunctionSum ("c_".Sports::COL_MATCH_SPECTATORS, 'attcnt');
            if (!empty ($teamId))
                {
                $teamIds = SportsHelper::getPredecessorTeamIds ($context, $teamId);
                $homeTeamColumn = "f_".Sports::COL_MATCH_HOMETEAM."_".Sports::TABLE_TEAM."_id";
                $criteria[] = new InCriterion ($homeTeamColumn, $teamIds);
                }
            }
        else
            {
            $columns[] = new FunctionSum ("c_".Sports::COL_MATCH_HOMERESULT, 'homecnt');
            $columns[] = new FunctionSum ("c_".Sports::COL_MATCH_AWAYRESULT, 'awaycnt');
            }
        $rows = $matchesTable->selectBy ($columns, $criteria, NULL, $params);

        $stats = array ();
        $statsHome = array ();
        $statsAway = array ();
        foreach ($rows ? $rows : array () as $row)
            {
            if (NULL === $row["c_".Sports::COL_MATCH_MATCHDAY])
                continue;

            if ($attendance)
                $stats[$row["c_".Sports::COL_MATCH_MATCHDAY]] = $row['attcnt'] / $row['cnt'];
            else
                {
                $statsHome[$row["c_".Sports::COL_MATCH_MATCHDAY]] = $row['homecnt'];
                $stats[$row["c_".Sports::COL_MATCH_MATCHDAY]] = $row['homecnt'] + $row['awaycnt'];
                }
            }
        if (empty ($stats) || count ($stats) < 3)
            return null;

        ksort ($stats);
        if (!$attendance)
            {
            ksort ($statsHome);

            return array (self::prepareStatsArray ($stats, $context->getText ("Round goals"), true), self::prepareStatsArray ($statsHome, $context->getText ("Home goals|stats"), false));
            }
        else
            return array (self::prepareStatsArray ($stats, $context->getText ("Average attendance"), true));
        }


    // Team statistics
    const COL_SEASONS = "seasons";
    const COL_FIRST_SEASON = "firstseason";
    const COL_SEASONS_STRAIGTH = "seasonsstraight";
    const COL_MAX_ACHIEVEMENT = "maxplace";
    const COL_SEASONS_1ST = "seasons1st";
    const COL_SEASONS_2ND = "seasons2nd";
    const COL_SEASONS_3RD = "seasons3rd";
    const COL_TEAM = "team";

    public static function getTeamGeneralStatistics ($context, $teamId, $leagueId)
        {
        $teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        $teamLabels = SportsHelper::getTeamLabels ($context, array ($teamId));
        if (empty ($teamLabels[$teamId]))
            return NULL;

        $teamIds = FilterByTeamCriterion::getPredecessorTeamIds ($context, $teamId);

        $result = self::getTeamStatisticsByLeague ($context, $teamsTable, $teamIds, $leagueId);
        if (empty ($result))
            return NULL;

        $result[self::COL_TEAM] = $teamLabels[$teamId];

        return $result;
        }

    public static function getTeamStatisticsByLeague ($context, $teamsTable, $teamIds, $leagueSeasonId)
        {
        if (empty ($leagueSeasonId))
            return NULL;

        $competitionTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $statisticsContainer = array ();
        $parentColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_LEAGUE, Sports::TABLE_LEAGUE."_id");
        if ("L" == $leagueSeasonId[0])
            {
            $leagueId = substr ($leagueSeasonId, 1);
            $leagueSeasonId = NULL;
            }
        else
            {
            // retrieve league id (to calculate consecutive seasons)
            $criteria[] = new EqCriterion ($competitionTable->getIdColumn (), $leagueSeasonId);
            $rows = $competitionTable->selectBy (array ($parentColumn), $criteria);
            if (empty ($rows))
                return NULL;

            $leagueId = $rows[0][$parentColumn];
            }

        
        $leagueIds = SportsHelper::colectLeaguePredecessors ($context, $leagueId);
       
        $statsCompetitionColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAMLEAGUESEASON_COMPETITION, $competitionTable->getIdColumn ());
        $seasonIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_SEASON, Sports::TABLE_SEASON."_id");

        $joins = array ();
        $criteria = array (new InCriterion ($parentColumn, $leagueIds));
        $criteria[] = new JoinColumnsCriterion ($statsCompetitionColumn, $competitionTable->getIdColumn ());
        $joins[] = $competitionTable->createQuery (array(), $criteria);

        $criteria = array (new InCriterion ($teamsTable->getIdColumn (), $teamIds));
        $columns = array ($statsCompetitionColumn, Sports::COL_TEAMLEAGUESEASON_COMPETITION.".$seasonIdColumn", Sports::COL_TEAMLEAGUESEASON_PLACE);
        $fixedSeasons = self::retrieveTeamsWithFixedStatsByCriteria ($context, Sports::TABLE_TEAMLEAGUESEASON, $criteria, $columns, $joins);

        $achievementColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAMCUPSEASON_ACHIEVEMENT, Sports::TABLE_ROUND."_id");
        $columns = array ($statsCompetitionColumn, Sports::COL_TEAMCUPSEASON_COMPETITION.".$seasonIdColumn", $achievementColumn);
        $cupSeasons = self::retrieveTeamsWithFixedStatsByCriteria ($context, Sports::TABLE_TEAMCUPSEASON, $criteria, $columns, $joins);

        $seasons = array ();
        $competitionPlaces = array ();
        if (!empty ($fixedSeasons))
            {
            foreach ($fixedSeasons as $row)
                {
                $seasonId = $row[Sports::COL_TEAMLEAGUESEASON_COMPETITION.".".$seasonIdColumn];
                if (false === array_search ($seasonId, $seasons))
                    $seasons[] = $seasonId;
                $competitionPlaces[$row[$statsCompetitionColumn]] = $row["c_".Sports::COL_TEAMLEAGUESEASON_PLACE];
                }
            }

        if (!empty ($cupSeasons))
            {
            foreach ($cupSeasons as $row)
                {
                $seasonId = $row[Sports::COL_TEAMCUPSEASON_COMPETITION.".".$seasonIdColumn];
                if (false === array_search ($seasonId, $seasons))
                    $seasons[] = $seasonId;
                $competitionPlaces[$row[$statsCompetitionColumn]] = self::parseCupAchievementAsPlace ($context, $row[$achievementColumn]);
                }
            }

        if (!empty ($leagueSeasonId) && false === array_search ($leagueSeasonId, $seasons))
            $seasons[] = $leagueSeasonId;

        $maxAchievements = array ("max" => NULL, "seasons" => array (), "s1" => array (), "s2" => array (), "s3" => array (), "description" => NULL);
        if (!empty ($seasons))
            {
            if (1 == count ($seasons))
                $statisticsContainer[self::COL_SEASONS] = $context->getText ("First season");
            else
                {
                // check if there are any gaps (relegations) by selecting all league seasons and comparing
                $allSeasons = SportsHelper::selectLeagueCompetitionSeasons ($context, $leagueIds, $leagueSeasonId);
                $allSeasons = array_reverse ($allSeasons, true);

                $countStreak = NULL;
                $count = 0;
                $firstSeason = NULL;
                $currentSpellFrom = NULL;
                $warningDisplayed = false;
                foreach ($allSeasons as $seasonId => $descriptor)
                    {
                    if (false !== array_search ($seasonId, $seasons))
                        {
                        $count++;
                        $firstSeason = $descriptor["season"];

                        $hasFinalStages = false;
                        foreach ($descriptor["ids"] as $id => $finalStage)
                            {
                            if ($finalStage)
                                {
                                $hasFinalStages = true;
                                if (!empty ($competitionPlaces[$id]))
                                    self::checkForMaxAchievement ($maxAchievements, $competitionPlaces[$id], $descriptor["season"]);
                                }
                            }

                        if (!$hasFinalStages && !$warningDisplayed)
                            {
                            $context->addMessage ("Final place in some seasons ([_0], ...) cannot be calculated.", $firstSeason);
                            $warningDisplayed = true;
                            }
                        }
                    else if (NULL === $countStreak)
                        {
                        $countStreak = $count;
                        $currentSpellFrom = $firstSeason;
                        }
                    }

                if (0 == $count)
                    {
                    $statisticsContainer[self::COL_SEASONS] = $context->getText ("First season");
                    return $statisticsContainer;
                    }

                if (NULL === $countStreak)
                    {
                    $countStreak = $count;
                    $currentSpellFrom = $firstSeason;
                    }

                if ($countStreak == $count)
                    $statisticsContainer[self::COL_SEASONS] = $context->ngettext ("[_0] season (not relegated once)", "[_0] seasons (not relegated once)", $count + 1);
                else
                    {
                    $statisticsContainer[self::COL_SEASONS] = $context->ngettext ("[_0] season", "[_0] seasons", $count + 1);
                    if (0 == $countStreak)
                        $statisticsContainer[self::COL_SEASONS_STRAIGTH] = $context->gettext ("Returned to the league");
                    else
                        $statisticsContainer[self::COL_SEASONS_STRAIGTH] = $context->ngettext ("[_0] season (since [_1])", "[_0] seasons (since [_1])", $countStreak + 1, $currentSpellFrom);
                    }

                $statisticsContainer[self::COL_FIRST_SEASON] = $firstSeason;

                if ($maxAchievements["max"] > 0)
                    {
                    $label = $context->getText ("[_0] place", $maxAchievements["max"])." (";
                    
                    if (!empty ($maxAchievements["description"]))
                        $label .= $maxAchievements["description"]."; ";
                    if (1 == count ($maxAchievements["seasons"]))
                        $label .= $maxAchievements["seasons"][0];
                    else
                        $label .= self::getAchievementsLine ($context, count ($maxAchievements["seasons"]), $maxAchievements["max"] > 3 ? $maxAchievements["seasons"] : NULL);
                    $label .= ")";
                    $statisticsContainer[self::COL_MAX_ACHIEVEMENT] = $label;
                    }
                $statisticsContainer[self::COL_SEASONS_1ST] = self::getAchievementsLine ($context, count ($maxAchievements["s1"]), $maxAchievements["s1"]);
                $statisticsContainer[self::COL_SEASONS_2ND] = self::getAchievementsLine ($context, count ($maxAchievements["s2"]), $maxAchievements["s2"]);
                $statisticsContainer[self::COL_SEASONS_3RD] = self::getAchievementsLine ($context, count ($maxAchievements["s3"]), $maxAchievements["s3"]);
                }
            }

        return $statisticsContainer;
        }

    protected static function getAchievementsLine ($context, $times, $seasons)
        {
        if ($times <= 0)
            return NULL;
        $times = $context->ngettext ("[_0] time", "[_0] times", $times);
        if (!empty ($seasons))
            $times .= " - ".implode (", ", array_reverse ($seasons));
        return $times;
        }

    protected static function checkForMaxAchievement (&$maxAchievements, $place, $season)
        {

        $achievedPlace = $place;
        if (is_array ($place))
            {
            $achievedPlace = $place[0];
            }

        if (NULL === $maxAchievements["max"] || $maxAchievements["max"] > $achievedPlace)
            {
            $maxAchievements["max"] = $achievedPlace;
            $maxAchievements["seasons"] = array ();
            }
        if ($maxAchievements["max"] == $achievedPlace)
            {
            $maxAchievements["seasons"][] = $season;
            
            if (is_array ($place))
                $maxAchievements["description"] = $place[1];
            }

        if ($achievedPlace <= 3)
            $maxAchievements["s$place"][] = $season;
        }

    protected static $achievementsCached = -1;

    protected static function parseCupAchievementAsPlace ($context, $achievement)
        {
        if (-1 == self::$achievementsCached)
            {
            $roundTable = ContentTable::createInstanceByName ($context, Sports::TABLE_ROUND);
            $columns = array ($roundTable->getIdColumn (), "name", "priority", "subpriority");
            self::$achievementsCached = $roundTable->selectBy ($columns, NULL);
            }

        if (empty (self::$achievementsCached))
            return NULL;
        foreach (self::$achievementsCached as $row)
            {
            if ($achievement != $row[Sports::TABLE_ROUND."_id"])
                continue;

            $place = $row["c_priority"];
            $teamsCompeting = $row["c_subpriority"];
            if ($place <= 3 || 1 == $teamsCompeting || 2 == $teamsCompeting)
                return $place;

            return array ($place, $row["c_name"]);
            }

        return NULL;
        }

    public static function retrieveTeamsWithFixedStatsByCriteria ($context, $tableName, $criteria, $columns = NULL, $joins = NULL, $returnTeamIds = false)
        {
        $resultsTable = ContentTable::createInstanceByName ($context, $tableName);
        if (empty ($resultsTable))
            return false;

        $altNameColumn = ContentTable::generateForeignKeyColumn ("altname", Sports::TABLE_TEAM."_id");
        if (!is_array ($criteria))
            $criteria = array ($criteria);
        $columns[] = "team_id";
        $columns[] = $resultsTable->getIdColumn ();
        $columns[] = $altNameColumn;

        $rows = $resultsTable->selectBy ($columns, $criteria, $joins);
        if (empty ($rows))
            return NULL;

        $teams = array ();
        foreach ($rows as $row)
            {
            /*if (0 === $row["c_place"])
                continue;*/
            $currentTeam = $row["team_id"];
            if ($returnTeamIds)
                $teams[] = $currentTeam;
            else
                $teams[] = $row;
            }

        return $teams;
        }

    public static function getTeamSimpleStatsColumnNames ($context)
        {
        $ret[] = new StatisticsColumn (CompetitionStatistics::COL_SEASONS, $context->getText ("Total seasons:"), "statsint");
        $ret[] = new StatisticsColumn (CompetitionStatistics::COL_SEASONS_STRAIGTH, $context->getText ("Current spell:"), "statsint");
        $ret[] = new StatisticsColumn (CompetitionStatistics::COL_FIRST_SEASON, $context->getText ("First season:"), "statsint");
        $ret[] = new StatisticsColumn (CompetitionStatistics::COL_MAX_ACHIEVEMENT, $context->getText ("Highest achievement:"), "statsint");
        $ret[] = new StatisticsColumn (CompetitionStatistics::COL_SEASONS_1ST, $context->getText ("Gold medal:"), "statsint");
        $ret[] = new StatisticsColumn (CompetitionStatistics::COL_SEASONS_2ND, $context->getText ("Silver medal:"), "statsint");
        $ret[] = new StatisticsColumn (CompetitionStatistics::COL_SEASONS_3RD, $context->getText ("Bronze medal:"), "statsint");
        return $ret;
        }
    }

class PlayerStatistics
    {
    public static function selectPlayerMatches ($playersTable, $matchesTable, $dbtable, $leagueIdColumn, $teamIdColumn,
                                                $homeTeamColumn, $additionalCriteria, $id, $playerColumn = "player",
                                                $additionalColumns = NULL, $joinCriteria = NULL, $groupByCompetition = true)
        {
        /*
        Select count of games and goals, grouped by team and competition season

        SELECT (case when p.c_hometeam = 1 THEN f_hometeam_team_id ELSE f_awayteam_team_id END) teamid,
               COUNT(*), SUM(p.c_left-p.c_entered), f_cstage_competitionstage_id, MIN(c_time), MAX(c_time)
          FROM `tx_matchplayers` p INNER JOIN tx_match m ON m.match_id = p.match_id
         WHERE `f_player_persons_id` = 236 AND (c_unused IS NULL OR c_unused = 0)
         GROUP BY teamid, f_cstage_competitionstage_id
        */
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn ("hometeam", Sports::TABLE_TEAM."_id");
        $awayTeamIdColumn = ContentTable::generateForeignKeyColumn ("awayteam", Sports::TABLE_TEAM."_id");
        $teamColumn = new ConditionalResultColumn($teamIdColumn, "$homeTeamColumn = 1", $homeTeamIdColumn, $awayTeamIdColumn);
        $columns = array ($teamColumn, new FunctionCount ("*", "cnt"),
                          new FunctionMin ("c_time", "mintime"),
                          new FunctionMax ("c_time", "maxtime"),
                          );
        if ($groupByCompetition)
            $columns[] = $leagueIdColumn;

        $criteria = $joinCriteria;
        $criteria[] = new EqCriterion ("c_unofficial", 0);
        $criteria[] = new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ());
        $criteria[] = new InCriterion (ContentTable::prepareUserColumnName (Sports::COL_MATCH_OUTCOME),
                                       array (MatchConstants::OUTCOME_FULL_TIME, MatchConstants::OUTCOME_EXTRA_TIME,
                                              MatchConstants::OUTCOME_PENALTIES, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                              MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_NOT_STARTED,
                                              MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));

        $groupBy = array ($teamIdColumn);
        if ($groupByCompetition)
            $groupBy[] =  $leagueIdColumn;
        $join = $matchesTable->createQuery ($columns, $criteria, NULL, array (new GroupBy ($groupBy)));

        $criteria = $additionalCriteria;

        if (is_array ($id))
            $criteria[] = new InCriterion ("f_{$playerColumn}_".$playersTable->getIdColumn (), $id);
        else
            $criteria[] = new EqCriterion ("f_{$playerColumn}_".$playersTable->getIdColumn (), $id);
        $params = NULL;
        if (empty ($additionalColumns))
            $additionalColumns = array ();
        else
            $params[] = new GroupBy ($additionalColumns);

        $rows = $dbtable->selectBy ($additionalColumns, $criteria, array ($join), $params);
        if (empty ($rows))
            $rows = array ();

        return $rows;
        }

    }

class FilterByTeamCriterion extends JoinCriterion
    {
    protected $teamId;
    protected $isHomeColumn;
    protected $invert;

    public function __construct ($teamId, $isHomeColumn, $invert = false)
        {
        $this->teamId = $teamId;
        $this->isHomeColumn = $isHomeColumn;
        $this->invert = $invert;
        }

    public static function getPredecessorTeamIds ($context, $teamId)
        {
        return SportsHelper::getPredecessorTeamIds ($context, $teamId);
        }

    public function formatForDB ($dbconnection, $parentTableAlias, $childTableAlias)
        {
        if (NULL != $parentTableAlias)
            $parentTableAlias .= ".";
        if (NULL != $childTableAlias)
            $childTableAlias .= ".";

        $isHomeColumn = $parentTableAlias.$this->isHomeColumn;
        $homeTeamColumn = $childTableAlias."f_".Sports::COL_MATCH_HOMETEAM."_".Sports::TABLE_TEAM."_id";
        $awayTeamColumn = $childTableAlias."f_".Sports::COL_MATCH_AWAYTEAM."_".Sports::TABLE_TEAM."_id";
        $one = 1;
        $zero = 0;
        if ($this->invert)
            list ($one, $zero) = array ($zero, $one);
        if (is_array ($this->teamId))
            $teamIds = $this->teamId;
        else
            $teamIds = self::getPredecessorTeamIds (PageContext::getInstance (NULL), $this->teamId);
        $teamIds = implode (",", $teamIds);
        return "(($isHomeColumn=$one and $homeTeamColumn IN ($teamIds)) or ($isHomeColumn=$zero and $awayTeamColumn IN ($teamIds)))";
        }

    }

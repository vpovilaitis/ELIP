<?php

abstract class MatchConstants
    {
    const OUTCOME_NOT_STARTED = 1;
    const OUTCOME_CANCELLED = 2;
    const OUTCOME_FULL_TIME = 4;
    const OUTCOME_EXTRA_TIME = 5;
    const OUTCOME_PENALTIES = 6;
    const OUTCOME_PENALTIES_HOME = 7;
    const OUTCOME_PENALTIES_AWAY = 8;
    const OUTCOME_TECHNICAL_WIN = 10;
    const OUTCOME_NO_HOME_TEAM = 11;
    const OUTCOME_NO_VISITORS = 12;
    const OUTCOME_ANNULLED = 20;
    const OUTCOME_BOTH_LOOSE = 30;
    const OUTCOME_HOME_WIN = 41;
    const OUTCOME_AWAY_WIN = 42;
    const OUTCOME_HOME_WIN_LEAVE_RESULT = 51;
    const OUTCOME_AWAY_WIN_LEAVE_RESULT = 52;

    const STAGE_HALF_TIME = 3;
    const STAGE_FULL_TIME = 4;
    const STAGE_EXTRA_TIME = 5;
    const STAGE_PENALTY_SCORE = 6;
    const STAGE_PENALTIES = 7;

    const REFEREE_PRIMARY = 1;
    const REFEREE_ASSISTANT1 = 2;
    const REFEREE_ASSISTANT2 = 3;
    const REFEREE_ASSISTANT_UNSPECIFIED = 6;
    const REFEREE_RESERVE = 4;
    const REFEREE_INSPECTOR = 7;
    const REFEREE_DELEGATE = 9;

    const EVENT_YELLOW = 1;
    const EVENT_YELLOW_RED = 2;
    const EVENT_RED = 4;
    const EVENT_MISS = 3;

    const ANNOUNCE_NORMALLY = 0;
    const ANNOUNCE_WITH_STADIUM = 1;
    const ANNOUNCE_SHORT = 5;
    const ANNOUNCE_WITH_PARENT = 10;
    const ANNOUNCE_HIDE = 100;

    const GOAL_TYPE_NORMAL = 30;
    const GOAL_TYPE_NORMAL_HEAD = 31;
    const GOAL_TYPE_COUNTER_ATACK = 45;
    }
    
abstract class SportsConstants
    {
    const REGISTRATION_A = 1;
    const REGISTRATION_B = 2;
    
    const REG_POSITION_GOALKEEPER = 1;
    const REG_POSITION_DEFENDER = 2;
    const REG_POSITION_MIDFIELD = 3;
    const REG_POSITION_SRIKER = 4;
    }

abstract class LeagueConstants
    {
    const SYSTEM_GROUP_MIN        = 1;
    const SYSTEM_STAGE_GROUP       = 1;
    const SYSTEM_STAGE_GROUP_WITH_FINALS = 2;
    const SYSTEM_GROUP_MAX        = 2;

    const SYSTEM_LEAGUE_MIN       = 101;
    const  SYSTEM_LEAGUE_PRE_1995  = 101; // 2 points for win
    const  SYSTEM_LEAGUE_POST_1995 = 102; // 3 points for win, 3:0 for technical win
    const  SYSTEM_LEAGUE_STAGE_RES = 103; // league stage with results from last stage
    const  SYSTEM_LEAGUE_STAGE_INT = 104; // league stage with interteam results from last stage
    const  SYSTEM_LEAGUE_9x9       = 125; // 3 points for win, if drawn, penalty shootout is played (2 pts for winning team, 1 pt for loosing) 
    const SYSTEM_LEAGUE_MAX       = 199;

    const SYSTEM_CUP_MIN          = 201;
    const  SYSTEM_CUP_2_MATCHES    = 201;
    const  SYSTEM_CUP_1_MATCH_OLD  = 202; // no extra time - replays on draw
    const  SYSTEM_CUP_1_MATCH_SEMI = 203; // 1 match in all stages except semi-finals
    const SYSTEM_CUP_MAX          = 299;
    }

abstract class Sports
    {
    const TABLE_PERSON = "persons";
    const TABLE_MATCH = "match";
    const TABLE_MATCHFLOW = "matchflow";
    const TABLE_MATCHREFEREE = "matchreferee";
    const TABLE_MATCHPLAYER = "matchplayers";
    const TABLE_MATCHEVENT = "matchevent";
    const TABLE_MATCHGOAL = "matchgoal";
    const TABLE_TEAM = "team";
    const TABLE_COMPETITIONSTAGE = "season";
    const TABLE_REFEREETYPE = "refereetype";
    const TABLE_STADIUM = "stadium";
    const TABLE_REFEREERATING = "refereerating";
    const TABLE_LEAGUE = "competition";
    const TABLE_CLUB = "club";
    const TABLE_SEASON = "seasons";
    const TABLE_ROUND = "round";
    const TABLE_REGISTRATIONS = "competitionplayer";
    const TABLE_TEAMCUPSEASON = "teamcupseason";
    const TABLE_TEAMLEAGUESEASON = "teamleagueseasons";
    const TABLE_TEAMPLAYER = "teamplayer";
    const TABLE_TEAMSTAFF = "teamstaff";
    const TABLE_COUNTRY = "country";

    const COL_STAGE_HOME = "home";
    const COL_STAGE_AWAY = "away";
    const COL_STAGE_OUTCOME = "stage";

    const COL_REFEREE_PERSON = "referee";
    const COL_REFEREE_TYPE = "type";
    const COL_REFEREE_FROM = "from";
    const COL_REFEREE_CATEGORY = "category";
    const COL_REFEREE_ORIGINAL_NAME = "original";
    const COL_REFEREE_RATED_BY_HOME = "rating_h";
    const COL_REFEREE_RATED_BY_AWAY = "rating_a";

    const COL_REFEREETYPE_TITLE = "type";

    const COL_PLAYER_NO = "number";
    const COL_PLAYER_PERSON = "player";
    const COL_PLAYER_POSITION = "position";
    const COL_PLAYER_FROM = "entered";
    const COL_PLAYER_TO = "left";
    const COL_PLAYER_EXTRA = "extra";
    const COL_PLAYER_ISHOME = "hometeam";
    const COL_PLAYER_CAPTAIN = "captain";
    const COL_PLAYER_SUBSTITUTED_BY = "substitute";
    const COL_PLAYER_UNUSED = "unused";
    const COL_PLAYER_PRIORITY = "priority";
    const COL_PLAYER_ORIGINAL_NAME = "original";

    const COL_EVENT_TIME_MIN = "min";
    const COL_EVENT_TIME_EXTRA = "extra";
    const COL_EVENT_TYPE = "event";
    const COL_EVENT_CAUSE = "type";
    const COL_EVENT_PLAYER = "player";
    const COL_EVENT_ISHOME = "ishome";
    const COL_EVENT_ORIGINAL_NAME = "original";

    const COL_GOAL_TIME_MIN = "min";
    const COL_GOAL_TIME_EXTRA = "extra";
    const COL_GOAL_TIME = "time"; // composite field ("90+3'")
    const COL_GOAL_SCORER = "player";
    const COL_GOAL_OWN = "own";
    const COL_GOAL_PENALTY = "penalty";
    const COL_GOAL_HOME = "ishome";
    const COL_GOAL_ASSIST = "assist";
    const COL_GOAL_TYPE = "type";
    const COL_GOAL_ORIGINAL_NAME = "original";

    const COL_TEAM_SHORTNAME = "shortname";
    const COL_TEAM_NATION = "country";
    const COL_TEAM_CLUB = "club";
    const COL_TEAM_TYPE = "type";
    const COL_TEAM_PREFIX = "prefix";
    const COL_TEAM_NAME = "name";
    const COL_TEAM_CITY = "city";
    const COL_TEAM_DECLINE = "decline";
    const COL_TEAM_SHOWPREFIX = "showprefix";
    const COL_TEAM_ICON = "logo";
    const COL_TEAM_POSTFIX = "postfix";
    const COL_TEAM_FROM = "from";
    const COL_TEAM_TO = "to";

    const COL_CLUB_PREFIX = "prefix";
    const COL_CLUB_NAME = "name";
    const COL_CLUB_CITY = "city";

    const COL_STADIUM_NAME = "name";
    const COL_STADIUM_CITY = "city";
    const COL_STADIUM_TYPE = "type";
    const COL_STADIUM_ACTUAL = "primary";

    const COL_COMPETITION_NAME = "name";
    const COL_COMPETITION_LEVEL = "level";
    const COL_COMPETITION_ANNOUNCEMENENT = "announcement";
    const COL_COMPETITION_PARENT = "partof";
    const COL_COMPETITION_PRIORITY = "priority";
    const COL_COMPETITION_LEAGUE = "competition";
    const COL_COMPETITION_STARTS = "startdate";
    const COL_COMPETITION_ENDS = "enddate";
    const COL_COMPETITION_TEAM_COUNT = "teamcount";
    const COL_COMPETITION_SYSTEM = "system";
    const COL_COMPETITION_SEASON = "season";
    const COL_COMPETITION_UNOFFICIAL = "unofficial";
    const COL_COMPETITION_FINALSTAGE = "finalstage";
    const COL_COMPETITION_REGION = "region";
    const COL_COMPETITION_ISCUP = "iscup";

    const COL_MATCH_HOMETEAM = "hometeam";
    const COL_MATCH_AWAYTEAM = "awayteam";
    const COL_MATCH_HOMERESULT = "homeresult";
    const COL_MATCH_AWAYRESULT = "awayresult";
    const COL_MATCH_DATE = "time";
    const COL_MATCH_RESULT = "result";
    const COL_MATCH_COMPETITION = "cstage";
    const COL_MATCH_UNOFFICIAL = "unofficial";
    const COL_MATCH_OUTCOME = "outcome";
    const COL_MATCH_EXCLUDED = "exclude";
    const COL_MATCH_STADIUM = "stadium";
    const COL_MATCH_MATCHDAY = "no";
    const COL_MATCH_STAGE = "round";
    const COL_MATCH_CITY = "city";
    const COL_MATCH_REFEREE = "referee";
    const COL_MATCH_HOMECOACH = "homecoach";
    const COL_MATCH_AWAYCOACH = "awaycoach";
    const COL_MATCH_SPECTATORS = "attendance";
    const COL_MATCH_UNOFFICIAL_ATTENDANCE = "attendance2";
    const COL_MATCH_RELIABILITY = "reliability";
    const COL_MATCH_NUMBER = "number";
    const COL_MATCH_WEATHER = "weather";

    const COL_PERSON_FULL_NAME = "full";
    const COL_PERSON_FIRST_NAME = "first";
    const COL_PERSON_SURNAME = "last";
    const COL_PERSON_BIRTHDATE = "birthday";
    const COL_PERSON_HEIGHT = "height";
    const COL_PERSON_WEIGHT = "weight";

    const COL_REFEREERATING_SEASON = "season";
    const COL_REFEREERATING_TYPE = "type";
    const COL_REFEREERATING_PLACE = "place";
    const COL_REFEREERATING_PERSON = "person";
    const COL_REFEREERATING_CITY = "city";
    const COL_REFEREERATING_CATEGORY = "category";
    const COL_REFEREERATING_RATING = "rating";

    const COL_LEAGUE_NAME = "name";
    const COL_LEAGUE_COUNTRY = "country";
    const COL_LEAGUE_TYPE = "type";
    const COL_LEAGUE_PREDECESSOR = "predecessor";

    const COL_SEASON_NAME = "displayname";
    const COL_SEASON_START = "start";
    const COL_SEASON_END = "end";

    const COL_REGISTRATION_COMPETITION = "competition";
    const COL_REGISTRATION_TEAM = "team";
    const COL_REGISTRATION_PLAYER = "person";
    const COL_REGISTRATION_NUMBER = "no";
    const COL_REGISTRATION_POSITION = "position";
    const COL_REGISTRATION_LIST = "list";
    const COL_REGISTRATION_DATE = "date";
    const COL_REGISTRATION_NUMBERFIXED = "fixedno";

    const COL_TEAMLEAGUESEASON_COMPETITION = "season";
    const COL_TEAMLEAGUESEASON_PLACE = "place";
    const COL_TEAMLEAGUESEASON_POINTS = "pts";
    const COL_TEAMLEAGUESEASON_GAMES_WON = "win";
    const COL_TEAMLEAGUESEASON_GAMES_DRAWN = "draw";
    const COL_TEAMLEAGUESEASON_GAMES_LOST = "lost";
    const COL_TEAMLEAGUESEASON_GOALS_SCORED = "scored";
    const COL_TEAMLEAGUESEASON_GOALS_CONCEDED = "conceded";

    const COL_TEAMCUPSEASON_COMPETITION = "season";
    const COL_TEAMCUPSEASON_ACHIEVEMENT = "achievement";
    const COL_TEAMCUPSEASON_ENTERED = "entered";

    const COL_TEAMPLAYER_TEAM = "team";
    const COL_TEAMPLAYER_PLAYER = "person";
    const COL_TEAMPLAYER_STARTED = "started";
    const COL_TEAMPLAYER_ENDED = "ended";
    const COL_TEAMPLAYER_POSITION = "position";
    const COL_TEAMPLAYER_EXPIRES = "expires";
    const COL_TEAMPLAYER_LOANED_FROM = "loanedfrom";

    const COL_TEAMSTAFF_TEAM = "team";
    const COL_TEAMSTAFF_PERSON = "empoyee";
    const COL_TEAMSTAFF_STARTED = "started";
    const COL_TEAMSTAFF_ENDED = "finished";
    const COL_TEAMSTAFF_ROLE = "role";

    const COL_COUNTRY_NAME = "name";
    }

class MatchEditorMode
    {
    const RESULT       = 0x0001;
    const HEADER       = 0x0002;
    const REFEREES     = 0x0004;
    const PLAYERS      = 0x0008;
    const DESCRIPTION  = 0x0010;
    const GOALS        = 0x0020;
    const EVENTS       = 0x0040;

    const FULL         = 0xffff;
    }

<?php
require_once (PATH."inc/language.php");

class ScoreCollector
    {
    protected $highestScore = NULL;
    protected $highestScoreMatches = array ();
    protected $biggestDefeat = NULL;
    protected $biggestDefeatMatches = array ();
    protected $mostGoalsAtHome = NULL;
    protected $mostGoalsAtHomeMatches = array ();
    protected $mostGoalsAway = NULL;
    protected $mostGoalsAwayMatches = array ();
    protected $groupByCompetition;
    protected $statsByCompetition = array ();
    protected $lng;
    private $homeResultColumn;
    private $awayResultColumn;
    private $dateColumn;
    protected $teamId;

    const COL_GOALS = "goals";
    const COL_GOALS_COUNT = "goalscnt";
    const COL_GOALS_HOME = "goalshome";
    const COL_GOALS_AWAY = "goalsaway";
    const COL_GAMES = "games";
    const COL_GAME_COUNT = "gamecnt";
    const COL_DRAWS = "draw";
    const COL_WINS_HOME = "winshome";
    const COL_WINS_AWAY = "winsaway";
    const COL_HIGHEST_SCORE = "highest";
    const COL_BIGGEST_DEFEAT = "biggestdef";
    const COL_MOST_HOME = "mosthome";
    const COL_MOST_AWAY = "mostaway";
    const COL_COMPETITION = "competition";
    const COL_WIN_SEQUENCE = "winsequence";
    const COL_DRAW_SEQUENCE = "drawsequence";
    const COL_LOST_SEQUENCE = "lostsequence";
    const COL_NOWIN_SEQUENCE = "nowinsequence";
    const COL_NODEFEAT_SEQUENCE = "nolostsequence";
    const COL_SCORING_SEQUENCE = "scoringsequence";
    const COL_SEQUENCE_WITHOUT_SCORING = "noscoringsequence";
    const COL_SEQUENCE_CONCEDED = "conceedsequence";
    const COL_SEQUENCE_NOT_CONCEDED = "noconceedsequence";
    
    const COL_OWN_GOALS = "cnt_own";
    const COL_PENALTIES = "cnt_pen";
    
    const PENALTY_COUNT = "penaltyCount";

    public function __construct ($groupByCompetition = false)
        {
        $this->homeResultColumn = ContentTable::prepareUserColumnName (Sports::COL_MATCH_HOMERESULT);
        $this->awayResultColumn = ContentTable::prepareUserColumnName (Sports::COL_MATCH_AWAYRESULT);
        $this->dateColumn = ContentTable::prepareUserColumnName (Sports::COL_MATCH_DATE);
        $this->groupByCompetition = $groupByCompetition;
        }

    public function setTeam ($teamId)
        {
        $this->teamId = $teamId;
        }

    public function addResult ($row)
        {
        $home = $row[$this->homeResultColumn];
        $away = $row[$this->awayResultColumn];

        if (NULL === $this->highestScore || ($this->highestScore <= $home + $away))
            {
            if ($this->highestScore < $home + $away)
                $this->highestScoreMatches = array ();

            $this->highestScore = $home + $away;
            $this->highestScoreMatches[] = $row;
            }

        if (NULL === $this->mostGoalsAtHome || ($this->mostGoalsAtHome <= $home))
            {
            if ($this->mostGoalsAtHome < $home)
                $this->mostGoalsAtHomeMatches = array ();

            $this->mostGoalsAtHome = $home;
            $this->mostGoalsAtHomeMatches[] = $row;
            }

        if (NULL === $this->mostGoalsAway || ($this->mostGoalsAway <= $away))
            {
            if ($this->mostGoalsAway < $away)
                $this->mostGoalsAwayMatches = array ();

            $this->mostGoalsAway = $away;
            $this->mostGoalsAwayMatches[] = $row;
            }

        if ($home < $away)
            list ($home, $away) = array ($away, $home);

        if (NULL === $this->biggestDefeat || $this->biggestDefeat <= $home - $away)
            {
            if ($this->biggestDefeat < $home - $away)
                $this->biggestDefeatMatches = array ();

            $this->biggestDefeat = $home - $away;
            $this->biggestDefeatMatches[] = $row;
            }
        }

    public function getHighestScore ($context)
        {
        if (NULL === $this->highestScore)
            return NULL;
        return $this->getMatchesResultLabel ($context, $this->highestScoreMatches);
        }

    public function getBiggestDefeat ($context)
        {
        if (NULL === $this->biggestDefeat)
            return NULL;
        return $this->getMatchesResultLabel ($context, $this->biggestDefeatMatches);
        }

    public function getMostGoalsHome ($context)
        {
        if (NULL === $this->mostGoalsAtHome)
            return NULL;
        return $this->getMatchesResultLabel ($context, $this->mostGoalsAtHomeMatches);
        }

    public function getMostGoalsAway ($context)
        {
        if (NULL === $this->mostGoalsAway)
            return NULL;
        return $this->getMatchesResultLabel ($context, $this->mostGoalsAwayMatches, false);
        }

    public function getMatchesResultLabel ($context, $matches, $canSwitch = true)
        {
        $usedScores = array ();
        $home = $away = 0;
        $count = 0;
        $label = NULL;
        $scoreLabels = array ();

        foreach ($matches as $row)
            {
            $home = $row[$this->homeResultColumn];
            $away = $row[$this->awayResultColumn];
            $time = $row[$this->dateColumn];
            $count++;

            if (!empty ($time))
                {
                $date = $this->lng->dateToLongString ($time, "day");
                $label = $context->getText ("[_0] vs. [_1] on [_2]", $row[Sports::COL_MATCH_HOMETEAM.".c_".Sports::COL_TEAM_SHORTNAME],
                                            $row[Sports::COL_MATCH_AWAYTEAM.".c_".Sports::COL_TEAM_SHORTNAME], $date);
                }
            else
                {
                $label = $context->getText ("[_0] vs. [_1]", $row[Sports::COL_MATCH_HOMETEAM.".c_".Sports::COL_TEAM_SHORTNAME],
                                            $row[Sports::COL_MATCH_AWAYTEAM.".c_".Sports::COL_TEAM_SHORTNAME]);
                }

            $score = $context->getText ("[_0] : [_1]", $home, $away);

            if (!isset ($scoreLabels[$score]))
                {
                $scoreLabels[$score] = $label;
                }
            else
                {
                $score = $context->getText ("[_0] : [_1]", $home, $away);

                if (empty ($scoreLabels[$score]) || !is_numeric ($scoreLabels[$score]))
                    $scoreLabels[$score] = 2;
                else
                    $scoreLabels[$score]++;
                }
            }

        $texts = array ();
        foreach ($scoreLabels as $score => $label)
            {
            if (false === $label)
                continue;
            if (is_numeric ($label))
                $texts[] = $context->ngettext ("[_1] ([_0] time)", "[_1] ([_0] times)", $label, $score);
            else
                $texts[] = $context->getText ("[_0] ([_1])", $score, $label);
            }

        return $this->beautifiedImplode ($context, $texts);
        }

    public function getCompetitionStatistics ($context)
        {
        $competitionIds = array_keys ($this->statsByCompetition);
        if (empty ($competitionIds))
            return NULL;

        $competitionTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        if (empty ($competitionTable))
            {
            $context->addError ("No tables");
            return false;
            }

        $criteria[] = new InCriterion ($competitionTable->getIdColumn (), $competitionIds);
        $rows = $competitionTable->selectWithDisplayName (array ($competitionTable->getIdColumn ()), $criteria);
        if (empty ($rows))
            return false;

        $competitionLabels = array ();
        foreach ($rows as $row)
            $competitionLabels[$row[$competitionTable->getIdColumn ()]] = $competitionTable->getDisplayName ($row);

        $result = array ();
        $goals = $games = $countedGames = $attendance = 0;
        $minAttendance = $maxAttendance = NULL;
        foreach ($competitionLabels as $id => $competition)
            {
            $statsRow = $this->statsByCompetition[$id];
            $avgAttendance = NULL;
            if ($statsRow["cnt"] > 0)
                $avgAttendance = round ($statsRow[Sports::COL_MATCH_SPECTATORS]/$statsRow["cnt"], 0);
            $row = array (self::COL_GAMES => $statsRow[self::COL_GAMES],
                          self::COL_GOALS => $statsRow[self::COL_GOALS],
                          Sports::COL_MATCH_SPECTATORS => $avgAttendance,
                          "maxatt" => $statsRow["maxatt"],
                          "minatt" => $statsRow["minatt"],
                          self::COL_COMPETITION => $competition);
            $result[] = $row;

            $goals += $statsRow[self::COL_GOALS];
            $games += $statsRow[self::COL_GAMES];
            $countedGames += $statsRow["cnt"];
            $attendance += $statsRow[Sports::COL_MATCH_SPECTATORS];
            if (NULL === $minAttendance || $minAttendance > $statsRow["minatt"])
                $minAttendance = $statsRow["minatt"];
            if (NULL === $maxAttendance || $maxAttendance < $statsRow["maxatt"])
                $maxAttendance = $statsRow["maxatt"];
            }

        $avgAttendance = NULL;
        if ($countedGames > 0)
            $avgAttendance = round ($attendance/$countedGames, 0);
        $totalsRow = array (StatisticsView::COL_LABEL => $context->getText ("Statistics by competition"),
                          self::COL_GAMES => $games,
                          self::COL_GOALS => $goals,
                          Sports::COL_MATCH_SPECTATORS => $avgAttendance,
                          "maxatt" => $maxAttendance,
                          "minatt" => $minAttendance,
                          self::COL_COMPETITION => $context->getText ("Total:"),
                          StatisticsView::COL_INNER => $result);
        return array ($totalsRow);
        }

    public function getStatistics ($context, $criteria)
        {
        $matchesTable = ContentTable::createInstanceByName ($context, "match");
        $competitionTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        if (empty ($matchesTable) || empty ($competitionTable))
            {
            $context->addError ("No tables");
            return false;
            }

        $competitionIdColumn =  ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $stadiumColumn = "f_stadium_stadium_id";
        $spectatorsColumn = ContentTable::prepareUserColumnName (Sports::COL_MATCH_SPECTATORS);
        $homeResultColumn = $this->homeResultColumn;
        $awayResultColumn = $this->awayResultColumn;

        $columns = array ($stadiumColumn);
        $columns[] = Sports::COL_MATCH_DATE;
        $columns[] = Sports::COL_MATCH_HOMERESULT;
        $columns[] = Sports::COL_MATCH_AWAYRESULT;
        $columns[] = Sports::COL_MATCH_HOMETEAM.".".Sports::COL_TEAM_SHORTNAME;
        $columns[] = Sports::COL_MATCH_AWAYTEAM.".".Sports::COL_TEAM_SHORTNAME;
        if ($this->groupByCompetition)
            {
            $columns[] = $competitionIdColumn;
            $columns[] = Sports::COL_MATCH_SPECTATORS;
            }

        $criteria[] = new LogicalOperatorOr (new EqCriterion (Sports::COL_MATCH_EXCLUDED, 0), new IsNullCriterion (Sports::COL_MATCH_EXCLUDED));
        $criteria[] = new InCriterion (ContentTable::prepareUserColumnName (Sports::COL_MATCH_OUTCOME),
                                       array (MatchConstants::OUTCOME_FULL_TIME, MatchConstants::OUTCOME_EXTRA_TIME,
                                              MatchConstants::OUTCOME_PENALTIES, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                              MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_NOT_STARTED,
                                              MatchConstants::OUTCOME_HOME_WIN, MatchConstants::OUTCOME_AWAY_WIN,
                                              MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $params = NULL;
        $rows = $matchesTable->selectBy ($columns, $criteria, NULL, $params);

        if (empty ($rows))
            return NULL;

        $goalsHome = $goalsAway = 0;
        $gameCount = 0;
        $winsHome = $winsAway = $draws = 0;
        $incomplete = false;
        $firstGame = $lastGame = NULL;
        $teamSequences = array ();
        $homeTeamSequences = array ();
        $awayTeamSequences = array ();
        $teamLabels = array ();

        foreach ($rows as $row)
            {
            $homeTeamId = $row[Sports::COL_MATCH_HOMETEAM][0];
            $awayTeamId = $row[Sports::COL_MATCH_AWAYTEAM][0];
            if (!array_key_exists ($homeTeamId, $teamLabels))
                $teamLabels[$homeTeamId] = $row[Sports::COL_MATCH_HOMETEAM.".c_".Sports::COL_TEAM_SHORTNAME];
            if (!array_key_exists ($awayTeamId, $teamLabels))
                $teamLabels[$awayTeamId] = $row[Sports::COL_MATCH_AWAYTEAM.".c_".Sports::COL_TEAM_SHORTNAME];

            if (!isset ($row[$homeResultColumn]) || !isset ($row[$awayResultColumn]))
                {
                $this->collectSequences ($teamSequences, $homeTeamId, NULL);
                $this->collectSequences ($teamSequences, $awayTeamId, NULL);
                $this->collectSequences ($homeTeamSequences, $homeTeamId, NULL);
                $this->collectSequences ($awayTeamSequences, $awayTeamId, NULL);
                continue;
                }

            $goalsHome += $row[$homeResultColumn];
            $goalsAway += $row[$awayResultColumn];
            $gameCount++;

            if ($row[$homeResultColumn] == $row[$awayResultColumn])
                $draws++;
            else if (!empty ($stadiumColumn))
                {
                if ($row[$homeResultColumn] > $row[$awayResultColumn])
                    $winsHome++;
                else
                    $winsAway++;
                }
            else
                $incomplete = true;

            $date = $row[$this->dateColumn];
            if (!empty ($date))
                {
                if (strlen ($date) > strlen ("2009-02-02"))
                    $date = substr ($date, 0, strlen ("2009-02-02"));
                if (NULL === $firstGame || $firstGame > $date)
                    $firstGame = $date;
                if (NULL === $lastGame || $lastGame < $date)
                    $lastGame = $date;
                }

            $this->collectSequences ($teamSequences, $homeTeamId, $date, $row[$homeResultColumn], $row[$awayResultColumn]);
            $this->collectSequences ($teamSequences, $awayTeamId, $date, $row[$awayResultColumn], $row[$homeResultColumn]);
            $this->collectSequences ($homeTeamSequences, $homeTeamId, $date, $row[$homeResultColumn], $row[$awayResultColumn]);
            $this->collectSequences ($awayTeamSequences, $awayTeamId, $date, $row[$awayResultColumn], $row[$homeResultColumn]);

            if (!empty ($row[$competitionIdColumn]))
                {
                $competitionId = $row[$competitionIdColumn];
                if (!array_key_exists ($competitionId, $this->statsByCompetition))
                    {
                    $this->statsByCompetition[$competitionId] = array (self::COL_GAMES => 0,
                                                                       self::COL_GOALS => 0,
                                                                       "cnt" => 0,
                                                                       Sports::COL_MATCH_SPECTATORS => 0);
                    }

                if (NULL !== $row[$spectatorsColumn])
                    {
                    $this->statsByCompetition[$competitionId]["cnt"]++;
                    $this->statsByCompetition[$competitionId][Sports::COL_MATCH_SPECTATORS] += $row[$spectatorsColumn];
                    if (empty ($this->statsByCompetition[$competitionId]["maxatt"]) || $row[$spectatorsColumn] > $this->statsByCompetition[$competitionId]["maxatt"])
                        $this->statsByCompetition[$competitionId]["maxatt"] = $row[$spectatorsColumn];
                    if (empty ($this->statsByCompetition[$competitionId]["minatt"]) || $row[$spectatorsColumn] < $this->statsByCompetition[$competitionId]["minatt"])
                        $this->statsByCompetition[$competitionId]["minatt"] = $row[$spectatorsColumn];
                    }
                $this->statsByCompetition[$competitionId][self::COL_GOALS] += $row[$homeResultColumn] + $row[$awayResultColumn];
                $this->statsByCompetition[$competitionId][self::COL_GAMES]++;
                }

            $this->addResult ($row);
            }

        if (empty ($gameCount))
            return NULL;

        $result = array ();
        $result[self::COL_GAMES] = $gameCount;
        $result[self::COL_GAME_COUNT] = $gameCount;
        if (!empty ($firstGame) && !empty ($lastGame))
            {
            $result[self::COL_GAMES] = $context->getText ("[_0] ([_1] - [_2])|game count with dates",
                                                          $gameCount,
                                                          $this->lng->dateToLongString ($firstGame, "day"),
                                                          $this->lng->dateToLongString ($lastGame, "day"));
            }

        $result[self::COL_GOALS] = $this->createValueDescription ($context, $goalsHome + $goalsAway, false, $gameCount);
        $result[self::COL_GOALS_COUNT] = $goalsHome + $goalsAway;
        $result[self::COL_GOALS_HOME] = $this->createValueDescription ($context, $goalsHome, $result[self::COL_GOALS], $gameCount);
        $result[self::COL_GOALS_AWAY] = $this->createValueDescription ($context, $goalsAway, $result[self::COL_GOALS], $gameCount);
        $result[self::COL_WINS_HOME] = $this->createValueDescription ($context, $winsHome, $gameCount, false, $incomplete);
        $result[self::COL_WINS_AWAY] = $this->createValueDescription ($context, $winsAway, $gameCount, false, $incomplete);
        $result[self::COL_DRAWS] = $this->createValueDescription ($context, $draws, $gameCount, false);
        $result[self::COL_HIGHEST_SCORE] = $this->getHighestScore ($context);
        $result[self::COL_BIGGEST_DEFEAT] = $this->getBiggestDefeat ($context);
        $result[self::COL_MOST_HOME] = $this->getMostGoalsHome ($context);
        $result[self::COL_MOST_AWAY] = $this->getMostGoalsAway ($context);

        $goalStats = $this->selectGoalStatistics ($context, $criteria);
        $result[self::COL_OWN_GOALS] = $this->createValueDescription ($context, $goalStats[self::COL_OWN_GOALS], $result[self::COL_GOALS], false);
        $result[self::COL_PENALTIES] = $this->createValueDescription ($context, $goalStats[self::COL_PENALTIES], $result[self::COL_GOALS], false);
        $result[self::PENALTY_COUNT] = $goalStats[self::COL_PENALTIES];

        $sequenceKeys = array ("maxWin" => self::COL_WIN_SEQUENCE, "maxDraw" => self::COL_DRAW_SEQUENCE, "maxDefeat" => self::COL_LOST_SEQUENCE,
                               "maxNoWin" => self::COL_NOWIN_SEQUENCE, "maxNoDefeat" => self::COL_NODEFEAT_SEQUENCE,
                               "maxScore" => self::COL_SCORING_SEQUENCE, "maxNoScore" => self::COL_SEQUENCE_WITHOUT_SCORING,
                               "maxConceeded" => self::COL_SEQUENCE_CONCEDED, "maxNotConceeded" => self::COL_SEQUENCE_NOT_CONCEDED);
        foreach (array ("" => $teamSequences, "home" => $homeTeamSequences, "away" => $awayTeamSequences) as $prefix => $sequences)
            {
            $longestSequences = array ();
            foreach ($sequenceKeys as $key => $targetKey)
                $longestSequences[$key] = array ("count" => -1, "teams" => NULL);

            foreach ($sequences as $teamId => $sequence)
                {
                foreach ($sequenceKeys as $key => $targetKey)
                    {
                    if ($sequence[$key]["count"] > $longestSequences[$key]["count"])
                        {
                        $longestSequences[$key]["count"] = $sequence[$key]["count"];
                        $longestSequences[$key]["teams"] = array ($teamId);
                        }
                    else if ($sequence[$key]["count"] == $longestSequences[$key]["count"])
                        {
                        $longestSequences[$key]["teams"][] = $teamId;
                        }
                    }
                }

            foreach ($sequenceKeys as $key => $targetKey)
                {
                if ($longestSequences[$key]["count"] < 2)
                    continue;
                $teamSequenceLabels = array ();
                $teamCount = 0;
                $sequenceCount = 0;
                foreach ($longestSequences[$key]["teams"] as $teamId)
                    {
                    $teamCount++;
                    $dates = array ();
                    $sequence = $sequences[$teamId][$key];

                    foreach ($sequence["sequences"] as $seq)
                        {
                        $dates[] = $context->getText ("[_0] - [_1]|date range",
                                                      $this->lng->dateToLongString ($seq["start"], "day"),
                                                      $this->lng->dateToLongString ($seq["end"], "day"));
                        $sequenceCount++;
                        }

                    if (!isset ($teamLabels[$teamId]))
                        continue;

                    $teamSequenceLabels[] = $context->getText ("[_0] [_1]|team sequence",
                                                               $teamLabels[$teamId],
                                                               $this->beautifiedImplode ($context, $dates));
                    }

                if ($teamCount > 2 || $sequenceCount > 4)
                    {
                    $teamsLabel = $context->ngettext ("[_0] team", "[_0] teams", $teamCount);
                    if ($sequenceCount > $teamCount)
                        $teamsLabel .= ", ".$context->ngettext ("[_0] occurence", "[_0] occurences", $sequenceCount);
                    }
                else
                    $teamsLabel = $this->beautifiedImplode ($context, $teamSequenceLabels);

                $result[$prefix.$targetKey] = $context->ngettext ("[_0] game ([_1])",
                                                          "[_0] games ([_1])",
                                                          $longestSequences[$key]["count"], $teamsLabel);
                }
            }
        return $result;
        }

    protected static function beautifiedImplode ($context, $arr)
        {
        if (count ($arr) == 1)
            return array_shift ($arr);

        $last = array_pop ($arr);
        return $context->getText ("[_0] and [_1]", implode (", ", $arr), $last);
        }

    public function selectGoalStatistics ($context, $criteria)
        {
        $matchTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $goalsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHGOAL);
        if (empty ($matchTable) || empty ($goalsTable))
            {
            $context->setError ("Table not found");
            return false;
            }

        $criteria[] = new InCriterion ("c_outcome", array (MatchConstants::OUTCOME_NOT_STARTED, MatchConstants::OUTCOME_FULL_TIME,
                                                           MatchConstants::OUTCOME_EXTRA_TIME, MatchConstants::OUTCOME_PENALTIES,
                                                           MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                                           MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $criteria[] = new LogicalOperatorOr (new EqCriterion ("c_".Sports::COL_MATCH_EXCLUDED, 0), new IsNullCriterion ("c_".Sports::COL_MATCH_EXCLUDED));
        $criteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $joins[] = $matchTable->createQuery (array (), $criteria);

        $columns = array ();
        $columns[] = new ConditionalSumColumn (self::COL_OWN_GOALS, "c_".Sports::COL_GOAL_OWN." = 1", 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_PENALTIES, "c_".Sports::COL_GOAL_PENALTY." = 1", 1, 0);
        $params = array ();
        $rows = $goalsTable->selectBy ($columns, NULL, $joins, $params);
        if (empty ($rows))
            return array (self::COL_OWN_GOALS => NULL, self::COL_PENALTIES => NULL);
        return $rows[0];
        }

    protected function collectSequences (&$teamSequences, $teamId, $date, $homeResult = NULL, $awayResult = NULL)
        {
        if (!empty ($this->teamId) && $this->teamId != $teamId)
            return;

        if (!array_key_exists ($teamId, $teamSequences))
            $teamSequences[$teamId] = array ("maxWin" => NULL, "maxDraw" => NULL, "maxDefeat" => NULL, "maxNoWin" => NULL, "maxNoDefeat" => NULL,
                                             "maxScore" => NULL, "maxNoScore" => NULL,
                                             "maxConceeded" => NULL, "maxNotConceeded" => NULL,
                                             "currentSequence" => NULL, "currentCount" => 0, "sequenceStart" => NULL,
                                             );

        $sequence = &$teamSequences[$teamId];
        if (NULL === $homeResult)
            {
            $sequence["currentSequence"] = NULL;
            $sequence["currentCount"] = 0;
                $sequence["prevDrawSequenceCount"] = 0;
                $sequence["prevDrawSequenceStart"] = $sequence["sequenceStart"];
            return;
            }

        $current = $homeResult > $awayResult ? "Win" : ($homeResult < $awayResult ? "Defeat" : "Draw");
        if ($sequence["currentSequence"] != $current)
            {
            if ("Draw" == $sequence["currentSequence"])
                {
                $sequence["prevDrawSequenceCount"] = $sequence["currentCount"];
                $sequence["prevDrawSequenceStart"] = $sequence["sequenceStart"];
                }
            else
                {
                $sequence["prevDrawSequenceCount"] = 0;
                $sequence["prevDrawSequenceStart"] = NULL;
                }

            $sequence["currentSequence"] = $current;
            $sequence["currentCount"] = 0;
            $sequence["sequenceStart"] = $date;
            }

        $sequence["currentCount"]++;
        if (empty ($sequence["max".$current]) || $sequence["max".$current]["count"] < $sequence["currentCount"])
            {
            $sequence["max".$current] = array ("count" => $sequence["currentCount"],
                                               "sequences" => array (array ("start" => $sequence["sequenceStart"], "end" => $date)));
            }
        else if ($sequence["max".$current]["count"] == $sequence["currentCount"])
            {
            $sequence["max".$current]["sequences"][] = array ("start" => $sequence["sequenceStart"], "end" => $date);
            }

        $this->collectSequencesPart ($sequence, $date, $current, "NoWin", "NoDefeat", true);
        $this->collectSequencesPart ($sequence, $date, $homeResult > 0 ? "Score" : "NoScore", "Score", "NoScore");
        $this->collectSequencesPart ($sequence, $date, $awayResult > 0 ? "Conceeded" : "NotConceeded", "Conceeded", "NotConceeded");
        }

    protected function collectSequencesPart (&$sequence, $date, $current, $key1, $key2, $negative = false)
        {
        foreach (array ($key1, $key2) as $key)
            {
            if (($negative && $key != "No".$current) || (!$negative && $key == $current))
                {
                if (empty ($sequence["first{$key}Date"]))
                    $sequence["first{$key}Date"] = $date;

                if (empty ($sequence["gamesSinceLast{$key}"]))
                    $sequence["gamesSinceLast{$key}"] = 0;
                $sequence["gamesSinceLast{$key}"]++;
                if (empty ($sequence["max{$key}"]) || $sequence["max{$key}"]["count"] < $sequence["gamesSinceLast{$key}"])
                    {
                    $sequence["max{$key}"] = array ("count" => $sequence["gamesSinceLast{$key}"],
                                                   "sequences" => array (array ("start" => $sequence["first{$key}Date"], "end" => $date)));
                    }
                else if ($sequence["max{$key}"]["count"] == $sequence["gamesSinceLast{$key}"])
                    {
                    $sequence["max{$key}"]["sequences"][] = array ("start" => $sequence["first{$key}Date"], "end" => $date);
                    }
                }
            else
                {
                $sequence["first{$key}Date"] = NULL;
                $sequence["gamesSinceLast{$key}"] = 0;
                }
            }
        }

    public static function createValueDescription ($context, $val, $total, $calculateAverageBy, $incomplete = false)
        {
        $parts = array ();
        if ($total > 0)
            {
            $perc = round (100 * $val / $total, 1);
            if ($incomplete)
                $perc = "? ".$perc;

            $parts[] = $context->getText ("[_0] %", $perc);
            }

        if (false !== $calculateAverageBy)
            {
            $avg = $val / $calculateAverageBy;
            if (2*$avg != round (2*$avg))
                $avg = round (5 * $avg) / 5;
            $parts[] = $context->getText ("average [_0] per game", $avg);
            }

        if (empty ($parts))
            return $val;

        $parts = self::beautifiedImplode ($context, $parts);
        return "$val ($parts)";
        }

    public static function getColumnNames ($context)
        {
        return array
            (
            new StatisticsColumn (self::COL_GAMES, $context->getText ("Total games"), "statsint"),
            new StatisticsColumn (self::COL_GOALS, $context->getText ("Goals:"), "statsint", "goal"),
            new StatisticsColumn (self::COL_GOALS_HOME, $context->getText ("Goals home:"), "statsint"),
            new StatisticsColumn (self::COL_GOALS_AWAY, $context->getText ("Goals away:"), "statsint"),
            new StatisticsColumn (self::COL_OWN_GOALS, $context->getText ("Own goals:"), "statsint"),
            new StatisticsColumn (self::COL_PENALTIES, $context->getText ("Penalties scored:"), "statsint"),
            new StatisticsColumn (self::COL_DRAWS, $context->getText ("Draws:"), "statsint"),
            new StatisticsColumn (self::COL_WINS_HOME, $context->getText ("Home team wins:"), "statsint"),
            new StatisticsColumn (self::COL_WINS_AWAY, $context->getText ("Away team wins:"), "statsint"),
            new StatisticsColumn (self::COL_HIGHEST_SCORE, $context->getText ("Biggest score:"), "statsint"),
            new StatisticsColumn (self::COL_BIGGEST_DEFEAT, $context->getText ("Biggest defeat:"), "statsint"),
            new StatisticsColumn (self::COL_MOST_HOME, $context->getText ("Most home goals:"), "statsint"),
            new StatisticsColumn (self::COL_MOST_AWAY, $context->getText ("Most away goals:"), "statsint"),

            new StatisticsColumn (self::COL_WIN_SEQUENCE, $context->getText ("Won in sequence:"), "statsint"),
            new StatisticsColumn (self::COL_DRAW_SEQUENCE, $context->getText ("Draw sequence:"), "statsint"),
            new StatisticsColumn (self::COL_LOST_SEQUENCE, $context->getText ("Lost in sequence:"), "statsint"),
            new StatisticsColumn (self::COL_NOWIN_SEQUENCE, $context->getText ("Games without winning:"), "statsint"),
            new StatisticsColumn (self::COL_NODEFEAT_SEQUENCE, $context->getText ("Games without loosing:"), "statsint"),
            new StatisticsColumn (self::COL_SCORING_SEQUENCE, $context->getText ("Scored in a row:"), "statsint"),
            new StatisticsColumn (self::COL_SEQUENCE_WITHOUT_SCORING, $context->getText ("Games without scoring:"), "statsint"),
            new StatisticsColumn (self::COL_SEQUENCE_CONCEDED, $context->getText ("Conceeded in a row:"), "statsint"),
            new StatisticsColumn (self::COL_SEQUENCE_NOT_CONCEDED, $context->getText ("Games without conceeding:"), "statsint"),

            new StatisticsColumn ("home".self::COL_WIN_SEQUENCE, $context->getText ("Home win sequence:"), "statsint"),
            new StatisticsColumn ("home".self::COL_DRAW_SEQUENCE, $context->getText ("Home draw sequence:"), "statsint"),
            new StatisticsColumn ("home".self::COL_LOST_SEQUENCE, $context->getText ("Home defeats sequence:"), "statsint"),
            new StatisticsColumn ("home".self::COL_NOWIN_SEQUENCE, $context->getText ("Home games without winning:"), "statsint"),
            new StatisticsColumn ("home".self::COL_NODEFEAT_SEQUENCE, $context->getText ("Home games without loosing:"), "statsint"),
            new StatisticsColumn ("home".self::COL_SCORING_SEQUENCE, $context->getText ("Scored in a row at home:"), "statsint"),
            new StatisticsColumn ("home".self::COL_SEQUENCE_WITHOUT_SCORING, $context->getText ("Games without scoring at home:"), "statsint"),
            new StatisticsColumn ("home".self::COL_SEQUENCE_CONCEDED, $context->getText ("Conceeded in a row at home:"), "statsint"),
            new StatisticsColumn ("home".self::COL_SEQUENCE_NOT_CONCEDED, $context->getText ("Games without conceeding at home:"), "statsint"),

            new StatisticsColumn ("away".self::COL_WIN_SEQUENCE, $context->getText ("Away win sequence:"), "statsint"),
            new StatisticsColumn ("away".self::COL_DRAW_SEQUENCE, $context->getText ("Away draw sequence:"), "statsint"),
            new StatisticsColumn ("away".self::COL_LOST_SEQUENCE, $context->getText ("Away defeats sequence:"), "statsint"),
            new StatisticsColumn ("away".self::COL_NOWIN_SEQUENCE, $context->getText ("Away games without winning:"), "statsint"),
            new StatisticsColumn ("away".self::COL_NODEFEAT_SEQUENCE, $context->getText ("Away games without loosing:"), "statsint"),
            new StatisticsColumn ("away".self::COL_SCORING_SEQUENCE, $context->getText ("Scored in a row away:"), "statsint"),
            new StatisticsColumn ("away".self::COL_SEQUENCE_WITHOUT_SCORING, $context->getText ("Games without scoring away:"), "statsint"),
            new StatisticsColumn ("away".self::COL_SEQUENCE_CONCEDED, $context->getText ("Conceeded in a row away:"), "statsint"),
            new StatisticsColumn ("away".self::COL_SEQUENCE_NOT_CONCEDED, $context->getText ("Games without conceeding away:"), "statsint"),
            );
        }

    public static function getColumnNamesByCompetition ($context)
        {
        return array
            (
            new StatisticsColumn (self::COL_COMPETITION, $context->getText ("Competition"), "row_label"),
            new StatisticsColumn (self::COL_GAMES, $context->getText ("Games"), "statsint"),
            new StatisticsColumn (self::COL_GOALS, $context->getText ("Goals"), "statsint", "goal"),
            new StatisticsColumn (Sports::COL_MATCH_SPECTATORS, $context->getText ("Spectators"), "statsint", "members"),
            new StatisticsColumn ("maxatt", $context->getText ("Max att."), "statsint", "members"),
            new StatisticsColumn ("minatt", $context->getText ("Min att."), "statsint", "members"),
            );
        }

    public function selectStatistics ($context, $request, $cachePrefix, $criteria, $cacheKey)
        {
        $this->lng = Language::getInstance ($context);
        $cache = Cache::getInstance (Sports::TABLE_MATCH, 6*60*60);
        $cacheId = md5 ($cachePrefix.$cacheKey);

        $startTime = microtime (true);
        if (false === ($result = $cache->get ($cacheId)))
            {
            $result = $this->getStatistics ($context, $criteria);
            if ($this->groupByCompetition)
                $result = array ($result, $this->getCompetitionStatistics ($context));

            $endTime = microtime (true);
            $context->log ("Cache miss. Selecting competition/stadium statistics took ".($endTime-$startTime)." s");

            $cache->save ($result, $cacheId);

            $endTime2 = microtime (true);
            $context->log ("Saving to the cache took ".($endTime2-$endTime)." s");
            }
        else
            {
            $endTime = microtime (true);
            $context->log ("Cache hit - ".($endTime-$startTime)." s");
            }

        return $result;
        }
    }


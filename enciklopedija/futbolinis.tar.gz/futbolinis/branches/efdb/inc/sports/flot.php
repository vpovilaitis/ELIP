<?php

class FlotHelper
    {
    public static function preparePlotSeries ($data, $label, $lineOptions = NULL)
        {
        // [ [0, 0], [0.5, 1], [1, 0.5]], [[0, 1], [0.5, 0.75], [1, 0.25] ]
        $dataPrepared = array ();
        foreach ($data as $key => $val)
            {
            $dataPrepared[] = array ($key,$val);
            }
            
        return array ('label' => $label, 'data' => $dataPrepared, 'lines' => $lineOptions);
        }

    }

class FlotData
    {
    public $series;
    public $options;
    
    public function __construct ($data, $options = NULL)
        {
        $this->series = $data;
        $this->options = $options;
        }

    public function getData ()
        {
        return json_encode ($this->series);
        }

    public function getOptions ()
        {
        return json_encode ($this->options);
        }
    }

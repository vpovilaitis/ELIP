<?php
require_once (PATH.'inc/language.php');
require_once (PATH.'inc/sports/constants.php');

class MatchCollector extends BaseWithContext
    {
    protected $matchesTable;
    protected $teamsTable;
    protected $competitionsTable;
    protected $lng;
    protected $useShortNames = false;
    protected $criteria = array ();

    public function __construct ($context, $useShortNames = false)
        {
        parent::__construct ($context);
        $this->matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $this->teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        $this->competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $this->lng = Language::getInstance ($context);
        $this->useShortNames = $useShortNames;
        }

    public function addCriterion ($criterion)
        {
        $this->criteria[] = $criterion;
        }

    public function selectMatchesGroupedByDay ($now, $matchRangeMin, $matchRangeMax, &$leagueIds, $additionalCriteria = NULL)
        {
        $params[] = new LimitResults (0, 300);
        $params[] = OrderBy::create ("c_".Sports::COL_MATCH_DATE, "c_".Sports::COL_MATCH_NUMBER);

        $today = date ("Y-m-d", $now);

        $startDate = date ("Y-m-d", $now+$matchRangeMin*24*60*60). " 00:00:00";
        $endDate = date ("Y-m-d", $now+$matchRangeMax*24*60*60). " 23:59:59";
        $criteria = empty ($additionalCriteria) ? $this->criteria : (empty ($this->criteria) ? $additionalCriteria : array_merge ($this->criteria, $additionalCriteria));
        $criteria[] = new GtEqCriterion ("c_time", $startDate);
        $criteria[] = new LtEqCriterion ("c_time", $endDate);

        $competitionIdColumn = "f_".Sports::COL_MATCH_COMPETITION."_".$this->competitionsTable->getIdColumn();
        $columns = array ();
        array_push ($columns, $this->matchesTable->getIdColumn (),
                    $competitionIdColumn, Sports::COL_MATCH_DATE,
                    Sports::COL_MATCH_HOMETEAM.".".Sports::COL_TEAM_SHORTNAME,
                    Sports::COL_MATCH_AWAYTEAM.".".Sports::COL_TEAM_SHORTNAME,
                    Sports::COL_MATCH_RESULT,
                    Sports::COL_MATCH_STADIUM, Sports::COL_MATCH_STAGE,
                    Sports::COL_MATCH_MATCHDAY, Sports::COL_MATCH_CITY
                    );
        $rows = $this->matchesTable->selectBy ($columns, $criteria, NULL, $params);
        
        if (empty ($rows))
            $rows = array ();

        for ($i = $matchRangeMin; $i <= $matchRangeMax; $i++)
             $matchesByDay[date ("Y-m-d", $now + $i*24*60*60)] = array ();

        $dateColumn = ContentTable::prepareUserColumnName (Sports::COL_MATCH_DATE);

        $pastMatches = array ();
        $matchesToday = array ();
        $futureMatches = array ();
        $leagueIds = array ();

        foreach ($rows as $row)
            {
            $matchDate = substr ($row[$dateColumn], 0, 10); // we need only day
            if (0 == substr ($matchDate, -2))
                continue;

            $matchesByDay[$matchDate][] = $row;
            $leagueId = $row[$competitionIdColumn];
            if (false === array_search ($leagueId, $leagueIds))
                $leagueIds[] = $leagueId;
            }

        return $matchesByDay;
        }

    public function selectMatches ($now, $pastDays, $futureDays, $maxLevel = -1, $criteria = NULL)
        {
        $matchRangeMin = -$pastDays;
        $matchRangeMax = $futureDays;
        $leagueIds = NULL;
        $matchesByDay = $this->selectMatchesGroupedByDay ($now, $matchRangeMin, $matchRangeMax, $leagueIds, $criteria);

        $collectedIds = array ();
        $competitions = $this->selectCompetitions ($leagueIds, $collectedIds);
        $parts = array ();
        $i = $matchRangeMin;
        foreach ($matchesByDay as $val)
            {
            $dayLabel = $this->lng->getRelativeDayName ($i++, $now);
            $row = array ('title' => $this->context->getText ("Matches [_0]", $dayLabel),
                          'matches' => $this->preprocessMatches ($val, $maxLevel, $competitions));
            $parts[$dayLabel] = $row;
            }

        return $parts;
        }

    public function selectCompetitionMatches ($now, $competitionId, $maxMatches = 10, $announcementsOnly = NULL)
        {
        if (empty ($this->criteria))
            {
            $competitionIdColumn = "f_".Sports::COL_MATCH_COMPETITION."_".$this->competitionsTable->getIdColumn();
            if (!is_array ($competitionId))
                $competitionId = array ($competitionId);
            $ids = SportsHelper::selectCompetitionHierarchyIds ($this->context, $this->competitionsTable, $competitionId);
            if (empty ($ids))
                return false;
            $this->addCriterion (new InCriterion ($competitionIdColumn, $ids));
            }

        return $this->selectPastAndFutureMatches ($now, $maxMatches, 30, $announcementsOnly, false, 4);
        }

    public function selectTeamMatches ($now, $teamId, $maxMatches = 10, $dateFrom = NULL, $dateTo = NULL)
        {
        if (empty ($this->criteria))
            {
            $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn());
            $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $this->teamsTable->getIdColumn());
            $this->addCriterion (new LogicalOperatorOr (new EqCriterion ($homeTeamIdColumn, $teamId),
                                                        new EqCriterion ($awayTeamIdColumn, $teamId)));

            $dateColumn = ContentTable::prepareUserColumnName (Sports::COL_MATCH_DATE);
            if (!empty ($dateFrom))
                $this->addCriterion (new GtCriterion ($dateColumn, $dateFrom));
            if (!empty ($dateTo))
                $this->addCriterion (new LtCriterion ($dateColumn, $dateTo));
            }

        return $this->selectPastAndFutureMatches ($now, $maxMatches, 90);
        }

    public function selectStadiumMatches ($now, $stadiumId, $maxMatches = 10)
        {
        if (empty ($this->criteria))
            {
            $stadiumsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_STADIUM);
            $stadiumArray = array ($stadiumId);
            
            $stadiumNameIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_STADIUM_ACTUAL, Sports::TABLE_STADIUM."_id");
            $stadiumCriteria[] = new LogicalOperatorOr (new EqCriterion ($stadiumsTable->getIdColumn (), $stadiumId),
                                                        new EqCriterion ($stadiumNameIdColumn, $stadiumId));
            $stadiumColumns = array ($stadiumNameIdColumn, $stadiumsTable->getIdColumn ());
            $rows = $stadiumsTable->selectBy ($stadiumColumns, $stadiumCriteria);
            if (!empty ($rows) && 1 == count ($rows) && !empty ($rows[0][$stadiumNameIdColumn]))
                {
                // we just found out the primary stadium id, lets requery
                $stadiumId = $rows[0][$stadiumNameIdColumn];
                $stadiumCriteria = NULL;
                $stadiumCriteria[] = new LogicalOperatorOr (new EqCriterion ($stadiumsTable->getIdColumn (), $stadiumId),
                                                            new EqCriterion ($stadiumNameIdColumn, $stadiumId));
                $rows = $stadiumsTable->selectBy ($stadiumColumns, $stadiumCriteria);
                }

            if (!empty ($rows))
                {
                $stadiumArray = array ();
                foreach ($rows as $row)
                    $stadiumArray[] = $row[$stadiumsTable->getIdColumn ()];
                }
            
            $stadiumIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STADIUM, Sports::TABLE_STADIUM."_id");
            $this->addCriterion (new InCriterion ($stadiumIdColumn, $stadiumArray));
            }

        return $this->selectPastAndFutureMatches ($now, $maxMatches, 90);
        }

    public function selectPastAndFutureMatches ($now, $maxMatches = 10, $matchRange = 30, $announcementsOnly = NULL, $separateGroupForToday = true, $discardAfterGap = NULL)
        {
        $leagueIds = NULL;

        $matchesByDay = $this->selectMatchesGroupedByDay ($now, true !== $announcementsOnly ? -$matchRange : 0,
                                                          false !== $announcementsOnly ? $matchRange : 0, $leagueIds);

        $parts = array ();
        $matchResults = array ();
        $matchAnnouncements = array ();
        $resultCount = $announcementCount = 0;
        $firstMatchIndex = NULL;
        $resultColumn = ContentTable::prepareUserColumnName (Sports::COL_MATCH_RESULT);

        for ($i = $separateGroupForToday ? 1 : 0; $i < $matchRange; $i++)
            {
            $dateFut = date ("Y-m-d", $now + $i*24*60*60);
            $rowsInFuture = $matchesByDay[$dateFut];
            if (empty ($rowsInFuture))
                continue;

            if ($discardAfterGap && $i > 0)
                {
                if (NULL === $firstMatchIndex)
                    $firstMatchIndex = $i;
                else if ($i - $firstMatchIndex > $discardAfterGap)
                    break;
                }

            if (0 == $i)
                {
                // for today matches we filter only upcomming ones
                $matches = array ();
                foreach ($rowsInFuture as $row)
                    {
                    if (empty ($row[$resultColumn]))
                        $matches[] = $row;
                    }
                $rowsInFuture = $matches;
                if (empty ($rowsInFuture))
                    continue;
                }

            if (count ($rowsInFuture) + $announcementCount <= $maxMatches)
                {
                $matchAnnouncements[$dateFut] = $rowsInFuture;
                $announcementCount += count ($rowsInFuture);
                }
            else
                {
                $matchAnnouncements[$dateFut] = array_slice ($rowsInFuture, 0, $maxMatches - $announcementCount);
                $announcementCount = $maxMatches;
                }

            if ($announcementCount >= $maxMatches)
                break;
            }

        $firstMatchIndex = NULL;

        for ($i = $separateGroupForToday ? 1 : 0; $i < $matchRange; $i++)
            {
            $datePast = date ("Y-m-d", $now - $i*24*60*60);
            $rowsInPast = $matchesByDay[$datePast];
            if (empty ($rowsInPast))
                continue;

            if ($discardAfterGap && $i > 0)
                {
                if (NULL === $firstMatchIndex)
                    $firstMatchIndex = $i;
                else if ($i - $firstMatchIndex > $discardAfterGap)
                    break;
                }

            if (0 == $i)
                {
                // for today matches we filter only completed ones
                $matches = array ();
                foreach ($rowsInPast as $row)
                    {
                    if (!empty ($row[$resultColumn]))
                        $matches[] = $row;
                    }
                $rowsInPast = $matches;
                if (empty ($rowsInPast))
                    continue;
                }

            if (count ($rowsInPast) + $resultCount <= $maxMatches)
                {
                $matchResults[$datePast] = $rowsInPast;
                $resultCount += count ($rowsInPast);
                }
            else
                {
                $matchResults[$datePast] = array_slice ($rowsInPast, 0, $maxMatches - $resultCount);
                $resultCount = $maxMatches;
                }

            if ($resultCount >= $maxMatches)
                break;
            }

        ksort ($matchResults);

        if ($resultCount > 0)
            {
            $row = array ('title' => $this->getText ("Match results"), 'matches' => $matchResults);
            $parts[$this->getText ("Results")] = $row;
            }

        if ($separateGroupForToday && NULL === $announcementsOnly)
            {
            $dateToday = date ("Y-m-d", $now);
            $rowsToday = $matchesByDay[$dateToday];
            if (count ($rowsToday) > 0)
                {
                $row = array ('title' => $this->getText ("Matches today"), 'matches' => array ($dateToday => $rowsToday));
                $parts[$this->getText ("Today")] = $row;
                }
            }
 
        if ($announcementCount > 0)
            {
            $row = array ('title' => $this->getText ("Match announcements"), 'matches' => $matchAnnouncements);
            $parts[$this->getText ("Announcements")] = $row;
            }

        $result = array ();
        foreach ($parts as $label => $group)
            {
            $processed = array ();
            foreach ($group['matches'] as $date => $rows)
                {
                $dateLabel = $this->lng->dateToLongString ($date);
                $matches = array ();
                foreach ($rows as $row)
                    {
                    $matches[] = $this->prepareMatch ($row);
                    }

                $descriptor = array ("label" => $dateLabel,
                                     "level" => NULL,
                                     "url" => NULL,
                                     "rows" => $matches,
                                     "type" => NULL);

                $processed[] = $descriptor;
                }
            
            $result[$label] = array ('title' => $group['title'], 'matches' => $processed);
            }

        return $result;
        }

    public function selectCompetitions ($ids, &$collectedIds)
        {
        if (empty ($ids))
            return array ();
        $collectedIds = array_merge ($collectedIds, $ids);
        $parentIdColumn ="f_".Sports::COL_COMPETITION_PARENT."_".$this->competitionsTable->getIdColumn();
        $criteria[] = new InCriterion ($this->competitionsTable->getIdColumn(), $ids);
        $columns = array (Sports::COL_COMPETITION_ANNOUNCEMENENT, Sports::COL_COMPETITION_NAME,
                          Sports::COL_COMPETITION_LEVEL, Sports::COL_COMPETITION_PRIORITY,
                          $parentIdColumn, $this->competitionsTable->getIdColumn());
        $rows = $this->competitionsTable->selectWithDisplayName ($columns, $criteria);
        if (empty ($rows))
            return array ();

        $parentIds = array ();
        foreach ($rows as $row)
            {
            $type = $row["c_".Sports::COL_COMPETITION_ANNOUNCEMENENT];
            $parentId = $row[$parentIdColumn];
            if ($type == MatchConstants::ANNOUNCE_WITH_PARENT &&
                false === array_search ($parentId, $collectedIds) &&
                false === array_search ($parentId, $parentIds))
                {
                $parentIds[] = $parentId;
                }

            $competitions[$row[$this->competitionsTable->getIdColumn()]] = $row;
            }

        $parents = $this->selectCompetitions ($parentIds, $collectedIds);
        if (!empty ($parents))
            {
            foreach ($parents as $id => $row)
                $competitions[$id] = $row;
            }

        return $competitions;
        }

    protected static function getRelatedRecordLabel ($context, $dbtable, $id, $label, $returnUrl = false, $title = NULL)
        {
        $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $dbtable,
                                                                     $dbtable->getId (), $id);

        if (!empty ($title))
            $title = " title=\"$title\"";
        $label = "<a href=\"$url\"$title>$label</a>";

        if ($returnUrl)
            return array ($url, $label);
        return $label;
        }

    protected function getTeamLabel ($row, $column)
        {
        $id = $row[$column][0];
        $title = $label = $row[$column.".".ContentTable::prepareUserColumnName (Sports::COL_TEAM_SHORTNAME)];
        if (!empty ($this->useShortNames))
            $label = $this->lng->beautifyTeamLabel ($label);
        return self::getRelatedRecordLabel ($this->context, $this->teamsTable, $id, $label, false, $label != $title ? $title : NULL);
        }

    protected function findMatchCompetition ($competitions, $id, &$type)
        {
        if (!isset ($competitions[$id]))
            {
            $this->context->addError ("Competition not found");
            return NULL;
            }

        $competitionRow = $competitions[$id];

        $type = $competitionRow["c_".Sports::COL_COMPETITION_ANNOUNCEMENENT];
        switch ($type)
            {
            case MatchConstants::ANNOUNCE_WITH_PARENT:
                $parentIdColumn ="f_".Sports::COL_COMPETITION_PARENT."_".$this->competitionsTable->getIdColumn();
                $parentId = $competitionRow[$parentIdColumn];
                $parent = $this->findMatchCompetition ($competitions, $parentId, $type);
                return $parent;
            }

        return $competitionRow;
        }

    protected function prepareMatch ($row)
        {
        $resultColumn = ContentTable::prepareUserColumnName (Sports::COL_MATCH_RESULT);
        $dateColumn = ContentTable::prepareUserColumnName (Sports::COL_MATCH_DATE);
        
        $date = $row[$dateColumn];
        $result = $row[$resultColumn];
        $matchId = $row[$this->matchesTable->getIdColumn ()];
        $homeTeam = $this->getTeamLabel ($row, Sports::COL_MATCH_HOMETEAM);
        $awayTeam = $this->getTeamLabel ($row, Sports::COL_MATCH_AWAYTEAM);

        if (!empty ($result))
            $matchLabel = $result;
        else
            {
            $time = $this->lng->extractTimeFromDate ($date);
            $matchLabel = !empty ($time) ? $time : $this->context->getText ("(...)|undefined time");
            }

        $addidionalInfo = array ();
        $title = NULL;
        if (!empty ($row[Sports::COL_MATCH_STADIUM.".".ContentTable::COL_DISPLAY_NAME]))
            $addidionalInfo[] = $row[Sports::COL_MATCH_STADIUM.".".ContentTable::COL_DISPLAY_NAME];
        if (!empty ($row[Sports::COL_MATCH_STAGE.".".ContentTable::COL_DISPLAY_NAME]))
            $addidionalInfo[] = $row[Sports::COL_MATCH_STAGE.".".ContentTable::COL_DISPLAY_NAME];
        if (!empty ($row["c_".Sports::COL_MATCH_MATCHDAY]))
            $addidionalInfo[] = $this->context->getText ("Day [_0]", $row["c_".Sports::COL_MATCH_MATCHDAY]);
        if (!empty ($addidionalInfo))
            $title = implode ("; ", $addidionalInfo);
        $matchLabel = self::getRelatedRecordLabel ($this->context, $this->matchesTable, $matchId, $matchLabel, false, $title);

        return array (
                "time" => $date,
                "result" => $matchLabel,
                "resultEntered" => !empty ($result),
                "home" => $homeTeam,
                "away" => $awayTeam,
                "stadium" => $row[Sports::COL_MATCH_STADIUM.".".ContentTable::COL_DISPLAY_NAME],
                );
        }
    
    protected function preprocessMatches ($rows, $maxLevel, $competitions)
        {
        $competitionIdColumn = "f_".Sports::COL_MATCH_COMPETITION."_".$this->competitionsTable->getIdColumn();
        $leagueColumn = ContentTable::prepareUserColumnName (Sports::COL_COMPETITION_NAME);
        $leagueLevelColumn = ContentTable::prepareUserColumnName (Sports::COL_COMPETITION_LEVEL);
        $leaguePriorityColumn = ContentTable::prepareUserColumnName (Sports::COL_COMPETITION_PRIORITY);
        $leagueMatches = array ();

        foreach ($rows as $row)
            {
            $leagueId = $row[$competitionIdColumn];
            $announcementType = MatchConstants::ANNOUNCE_NORMALLY;
            if (!empty ($leagueId))
                $competitionRow = $this->findMatchCompetition ($competitions, $leagueId, $announcementType);
            else
                $competitionRow = NULL;

            if (!empty ($competitionRow))
                {
                $leagueId = $competitionRow[$this->competitionsTable->getIdColumn ()];
                $league = $competitionRow[$leagueColumn];
                $level = $competitionRow[$leagueLevelColumn];
                $priority = sprintf ("%03d", $competitionRow[$leaguePriorityColumn]);
                }
            else
                {
                $league = $level = $priority = NULL;
                }

            if ($maxLevel > 0 && $level > $maxLevel)
                continue;

            list ($leagueUrl, $leagueLabel) = self::getRelatedRecordLabel ($this->context, $this->competitionsTable, $leagueId, $league, true);

            $key = ($level ? $level : "X")."$priority-".($league ? $league : "X");
            if (false === array_key_exists ($key, $leagueMatches))
                {
                $levelLabel = $level ? $this->context->getText ("[_0] level", $level) : NULL;
                $leagueMatches[$key] = array ("label" => empty ($league) ? $this->context->getText ("Friendly games") : $leagueLabel,
                                              "level" => $levelLabel,
                                              "url" => $leagueUrl,
                                              "rows" => array (),
                                              "type" => $announcementType);
                }

            $leagueMatches[$key]["rows"][] = $this->prepareMatch ($row);
            }

        ksort ($leagueMatches);

        if (empty ($leagueMatches))
            {
            $leagueMatches[] = array ("label" => $this->context->getText ("No matches"),
                                      "level" => 0, "rows" => array ());
            }

        return $leagueMatches;
        }

    public function getRssLink ($pastResults)
        {
        $feed = $pastResults ? "MatchResults" : "MatchAnnouncements";
        $rssUrl = $this->context->chooseUrl ("feed/$feed", "index.php?c=Rss&ch=$feed");
        return $rssUrl;
        }

    public function getRssLabel ($pastResults)
        {
        return $pastResults ? $this->context->getText ("Results") : $this->context->getText ("Announcements");
        }

    public function getNavigationLink ($next)
        {
        if (!empty ($_REQUEST["today"]))
            $now = strtotime ($_REQUEST["today"]);
        if (empty ($now))
            $now = time ();
        $now = $next ? ($now + 3*24*60*60) : ($now - 3*24*60*60);
        $today = date ("Y-m-d", $now);
        return $this->context->getAdjustedUrl (array ("today" => $today));
        }

    }

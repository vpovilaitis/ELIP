<?php

class CustomPageContext extends PageContext
    {
    public function getMetroLinks ()
        {
        $result = array ();
        foreach (array (
                    array ('metro-home.png',   $this->getText ("Home|menu"),       HOME_PAGE, $this->getText ("Return to starting page")),
                    )
                    as $params)
            {
            $page = $params[2];
            $result[] = array ('img' => $this->getResourcePath ("img", $params[0]),
                               'name' => $params[1],
                               'url' => $this->chooseUrl ("page/$page", "index.php?page=$page"),
                               'tooltip' => $params[3], );
            }

        $result[] = array ('img' => $this->getResourcePath ("img", 'metro-competitionstage.png'),
                           'name' => $this->getText ("Seasons"),
                           'url' => $this->chooseUrl ('list/season', 'index.php?c=ContentPreviewPage&tn=season'),
                           'tooltip' => $this->getText ("Historical competition seasons"));

        $result[] = array ('img' => $this->getResourcePath ("img", 'metro-team.png'),
                           'name' => $this->getText ("Teams"),
                           'url' => $this->chooseUrl ('list/team', 'index.php?c=ContentPreviewPage&tn=team'),
                           'tooltip' => $this->getText ("List of all teams"));
        $result[] = array ('img' => $this->getResourcePath ("img", 'metro-schedule.png'),
                           'name' => $this->getText ("Competitions"),
                           'url' => $this->chooseUrl ('list/competition', 'index.php?c=ContentPreviewPage&tn=competition'),
                           'tooltip' => $this->getText ("List of all competitions"));
        $result[] = array ('img' => $this->getResourcePath ("img", 'metro-note.png'),
                           'name' => $this->getText ("Edit|menu"),
                           'url' => $this->chooseUrl ('page/editors', 'index.php?page=editors'),
                           'tooltip' => $this->getText ("Join the editors and help collect and sort out the information"));
        return $result;
        }
    }
<?php
require_once (PATH.'inc/webservice.php');

abstract class PopupService extends WebService
    {
    protected $addSourceFields;
    const MODE_SHOW = "show";
    const MODE_SAVE = "save";

    public function __construct ($context, $addSourceFields = true)
        {
        parent::__construct ($context);
        $this->addSourceFields = $addSourceFields;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getData ($request)
        {
        $mode = isset ($request["mode"]) ? $request["mode"] : self::MODE_SHOW;

        switch ($mode)
            {
            case self::MODE_SHOW:
                return $this->getDisplayFieldsForXml ($request);
            case self::MODE_SAVE:
                return $this->save ($request, $this->prepareValues ($request));
            default:
                $ret = $this->executeCustomAction ($request, $mode);
                if (false !== $ret)
                    return $ret;
                break;
            }

        $this->context->addError ("Invalid arguments passed.");
        return NULL;
        }

    protected abstract function getFields ($request);

    protected abstract function save ($request, $values);

    protected function executeCustomAction ($request, $mode)
        {
        return false;
        }

    protected function getSaveButtonText ()
        {
        return $this->getText ("Save");
        }

    protected function getDisplayFields ($request)
        {
        $fields = $this->getFields ($request);
        if (empty ($fields))
            return NULL;

        if ($this->addSourceFields)
            {
            $fields[] = new TextFieldTemplate ("", DBTable::COL_SOURCE,
                                        $this->getText ("Source(s):"), $this->getText ("Source and comments"), 64);
            $fields[] = new DateFieldTemplate ("", DBTable::COL_SOURCEDATE,
                                        $this->getText ("Updated on:"), $this->getText ("Sources updated on"));
            }

        return $fields;
        }

    protected function getInitialValues ($request)
        {
        return array ();
        }

    protected function getDisplayFieldsForXml ($request)
        {
        $fields = $this->getDisplayFields ($request);
        if (empty ($fields))
            {
            $this->context->addError ("Invalid arguments passed.");
            return NULL;
            }

        $initialValues = $this->getInitialValues ($request);
        $result = array ();

        foreach ($fields as $field)
            {
            $type = "text";
            if ($field instanceof CheckBoxFieldTemplate)
                $type = "checkbox";
            else if ($field instanceof LongTextFieldTemplate)
                $type = "longtext";
            else if ($field instanceof FileFieldTemplate)
                $type = "file";
            else if ($field instanceof DropDownFieldTemplate)
                $type = "select";
            else if ($field instanceof ImageAutocompleteField)
                $type = "imgautocomplete";
            else if ($field instanceof PopupAutocompleteField)
                $type = "autocomplete";
            $entry = array ("type" => $type, "id" => $field->key, "label" => $field->getLabel (), "title" => $field->getTooltip ());
            $initialValue = NULL;
            if (!empty ($initialValues) && !empty ($initialValues[$field->key]))
                $initialValue = $initialValues[$field->key];
            else
                $initialValue = $field->getDefaultValue ();

            if (!empty ($initialValue))
                $entry["value"] = $initialValue;

            if ($field instanceof DropDownFieldTemplate)
                {
                $values = $field->getItems ($this->context, NULL);
                $valuesPrepared = array ();
                foreach ($values as $key => $val)
                    $valuesPrepared[] = "$key=$val";
                $entry["values"] = implode ("|", $valuesPrepared);
                }
            else if ($field instanceof ImageAutocompleteField || $field instanceof PopupAutocompleteField)
                $entry["service"] = $field->getServiceUrl ($this->context);

            $result[] = $entry;
            }

        foreach ($this->getButtons () as $key => $label)
            $result[] = array ("type" => "button", "id" => $key, "label" => $label);
        $result[] = array ("type" => "button", "id" => "close", "label" => $this->getText ("Close"));

        return $result;
        }

    protected function getButtons ()
        {
        return array ("save" => $this->getSaveButtonText ("Save"));
        }

    protected function prepareValues ($request)
        {
        $fields = $this->getDisplayFields ($request);
        if (empty ($fields))
            return array ();

        $result = array ();

        foreach ($fields as $field)
            {
            $result[$field->key] = $field->getValueForDB ($this->context, $request);
            }

        return $result;
        }

    }

<?php
require_once (PATH.'pages/contentinstanceeditor.php');
require_once (PATH.'pages/contentview.php');
require_once (PATH.'inc/defaulthintservice.php');

class ComponentFactory
    {
    static private $factory = NULL;
    static private $hintsService = NULL;

    private static function getFactory ($context)
        {
        if (NULL === self::$factory)
            {
            if (defined ("COMPONENT_FACTORY") && empty ($_REQUEST["nofactory"]))
                {
                $class = $context->parseCustomClass (COMPONENT_FACTORY, "h");
                if (!empty ($class))
                    self::$factory = new $class ();
                }
            if (empty (self::$factory))
                self::$factory = new DefaultFactory ();
            }

        return self::$factory;
        }

    public static function createEditor ($context, $prefix, $dbtable)
        {
        return self::getFactory ($context)->createEditor ($context, $prefix, $dbtable);
        }

    public static function createViewer ($context, $prefix, $dbtable)
        {
        return self::getFactory ($context)->createViewer ($context, $prefix, $dbtable);
        }

    public static function createPreview ($context, $prefix, $dbtable, $mode, $parentTable = NULL)
        {
        return self::getFactory ($context)->createPreview ($context, $prefix, $dbtable, $mode, $parentTable);
        }

    public static function createStatisticsView ($context, $prefix, $dbtable)
        {
        return self::getFactory ($context)->createStatisticsView ($context, $prefix, $dbtable);
        }

    public static function hasStatisticsView ($context, $dbtable)
        {
        return self::getFactory ($context)->hasStatisticsView ($context, $dbtable);
        }

    public static function getRegisteredComponents ($context)
        {
        return self::getFactory ($context)->getRegisteredComponents ($context);
        }

    public static function getEditorTaskHandlers ($context)
        {
        return self::getFactory ($context)->getEditorTaskHandlers ($context);
        }

    public static function getQuickLinkLists ($context)
        {
        return self::getFactory ($context)->getQuickLinkLists ($context);
        }

    public static function getRegisteredTools ($context)
        {
        return self::getFactory ($context)->getRegisteredTools ($context);
        }

    public static function getHintsService ($context)
        {
        if (NULL === self::$hintsService)
            {
            if (defined ("HINTS_SERVICE"))
                {
                $class = $context->parseCustomClass (HINTS_SERVICE, "h");
                if (!empty ($class))
                    self::$hintsService = new $class ($context);
                }
            if (empty (self::$hintsService))
                self::$hintsService = new DefaultHintService ($context);
            }

        return self::$hintsService;
        }
    }

// override this class and point to custom one in user.config.php
class DefaultFactory
    {
    protected $editorMappings = array ();
    protected $viewerMappings = array ();
    protected $previewMappings = array ();
    protected $listMappings = array ();
    protected $statisticsViewMappings = array ();

    const PREVIEW_ALL = "all";
    const PREVIEW_RELATED = "rel";
    const PREVIEW_CHILD = "ch";

    public function __construct ()
        {
        }

    protected function createComponent ($context, $prefix, $dbtable, $mapping, $defaultClass, $allowNull = false)
        {
        if (empty ($dbtable))
            return false;

        if (!empty ($mapping))
            {
            $table = $dbtable->getName ();
            if (array_key_exists ($table, $mapping))
                {
                if ($allowNull && empty ($mapping[$table]))
                    return NULL;

                $class = $context->parseCustomClass ($mapping[$table], "pages");
                }
            }

        if (empty ($class))
            $class = $defaultClass;

        if (empty ($class) && $allowNull)
            return NULL;

        return new $class ($context, $prefix, $dbtable);
        }

    protected function hasComponent ($context, $dbtable, $mapping)
        {
        if (empty ($dbtable))
            return false;

        $table = $dbtable->getName ();
        return isset ($mapping[$table]);
        }

    public function createEditor ($context, $prefix, $dbtable)
        {
        return $this->createComponent ($context, $prefix, $dbtable,
                                       $this->editorMappings, "ContentInstanceEditor");
        }

    public function createViewer ($context, $prefix, $dbtable)
        {
        return $this->createComponent ($context, $prefix, $dbtable,
                                       $this->viewerMappings, "ContentView");
        }

    public function createStatisticsView ($context, $prefix, $dbtable)
        {
        return $this->createComponent ($context, $prefix, $dbtable,
                                       $this->statisticsViewMappings, NULL, true);
        }

    public function hasStatisticsView ($context, $dbtable)
        {
        return $this->hasComponent ($context, $dbtable, $this->statisticsViewMappings);
        }

    public function createPreview ($context, $prefix, $dbtable, $mode, $parentTable = NULL)
        {
        if ($mode != DefaultFactory::PREVIEW_ALL)
            {
            $table = $parentTable->getName ();
            if (isset ($this->previewMappings[$table]))
                $mappings = $this->previewMappings[$table];
            }
        else
            $mappings = $this->listMappings;

        if (!empty ($mappings))
            {
            $component = $this->createComponent ($context, $prefix, $dbtable,
                                                 $mappings, "ContentPreview", true);
            if (empty ($component))
                return NULL;
            }
        if (empty ($component))
            $component = new ContentPreview ($context, $prefix, $dbtable);
        return $component;
        }

    public function getRegisteredComponents ($context)
        {
        $availableComponents = array ();

        $availableComponents["TextFragment"] = $context->getText ("Text section");
        $availableComponents["LightWeightTextFragment"] = $context->getText ("Lightweight text section");
        $availableComponents["CurrentUserFragment"] = $context->getText ("Login form and user info");
        $availableComponents["NewsFragment"] = $context->getText ("News section");
        $availableComponents["DiscussionsFragment"] = $context->getText ("Discussions");
        $availableComponents["SearchFragment"] = $context->getText ("Search field");
        $availableComponents["EditorTasksFragment"] = $context->getText ("Editor tasks");
        $availableComponents["CustomFragment"] = $context->getText ("Custom template");

        return $availableComponents;
        }

    public function getEditorTaskHandlers ($context)
        {
        return array ();
        }

    public function getRegisteredTools ($context)
        {
        return array ();
        }

    public function getQuickLinkLists ($context)
        {
        $ret = array ();
        return $ret;
        }
    }

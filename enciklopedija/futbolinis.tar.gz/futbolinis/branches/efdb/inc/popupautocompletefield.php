<?php

class PopupAutocompleteField extends FieldTemplate
    {
    protected $tableId;
    public function __construct ($prefix, $key, $label, $tooltip, $tableId = NULL)
        {
        parent::__construct ($prefix, $key, "text", $label, $tooltip);
        $this->tableId = empty ($tableId) ? "#DBTABLE#" : $tableId;
        }

    public function getServiceUrl ($context)
        {
        $url = $context->processUrl ("index.php?service=ContentService&id=$this->tableId", true);
        return $url;
        }
    }


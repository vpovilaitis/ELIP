<?php

/* MySql implementation of column def classes */

abstract class ColumnDef
    {
    const NULL_VALUE = 'null';

    public $name;
    public $type; // 'text', 'int', 'double'
    public $size = -1; // size of the text string (-1 - long text)
    public $precision = -1; // precision for double types
    public $modifiers = NULL;
    public $defaultValue = NULL;
    public $acceptNull = false;
    public $label = NULL;
    
    public function formatValueForDB ($context, $val)
        {
        if (NULL === $val)
            return ColumnDef::NULL_VALUE;

        return $val;
        }

    public function isValueValid ($context, $val)
        {
        if (!$this->acceptNull && NULL === $val)
            return $context->getText ("Please enter a value for a field [_0].", $this->getLabel ());
        return true;
        }

    public function getLabel ()
        {
        if (empty ($this->label))
            return $this->name;
        return $this->label;
        }

    public function getDefaultValue ()
        {
        return $this->defaultValue;
        }

    public function compare ($a, $b)
        {
        if ($a == $b)
            return 0;
        return $a > $b ? 1 : -1;
        }
    }

// a column which is not created in the database, but value is calculated at runtime
abstract class GhostColumn extends ColumnDef
    {
    public function __construct ($name)
        {
        $this->name = $name;
        }

    public function formatValueForDB ($context, $val)
        {
        return NULL;
        }

    public function prepareQuery ($dbtable, $tableAlias, &$resultColumns, &$criteria, &$joins, $namesToColumns)
        {
        if (empty  ($this->triggeredBy))
            return;

        $additionalColumns = $this->triggeredBy;
        $initialColumns = array ();

        foreach ($resultColumns as $col)
            {
            $colName = $col instanceof Column ? $col->name : $col;
            $initialColumns[] = $colName;
            }

        foreach ($additionalColumns as $col)
            {
            if (false === array_search ($col, $initialColumns))
                $resultColumns[] = $col;
            }
        }

    public function customizeQuery (&$query)
        {
        if (empty ($this->triggeredBy))
            $query->transformations[$this->name] = new GhostColumnValueTransformation ($this);
        else
            $query->transformations[$this->name] = new TriggeredFieldValueTransformation ($this);
        }

    public function adjustStoredValues (&$namesToValues, $columnValue)
        {
        }

    public abstract function calculateValue ($context, $transformations, $row, $columnPrefix = NULL);
    }

class IntColumn extends ColumnDef
    {
    const TYPE = 'integer';

    public function __construct ($name, $null = false)
        {
        $this->name = $name;
        $this->type = self::TYPE;
        $this->acceptNull = $null;
        }

    public function formatValueForDB ($context, $val)
        {
        if (!is_numeric ($val))
            return parent::formatValueForDB ($context, NULL);
        return $val;
        }

    public function isValueValid ($context, $val)
        {
        if (is_numeric ($val))
            return true;

        return parent::isValueValid ($context, NULL);
        }
    }

class NamedIntColumn extends IntColumn
    {
    public function __construct ($name, $null = false)
        {
        parent::__construct ($name, $null);
        }

    public static function getItems ($col)
        {
        $parts = explode (";", $col->defaultValue);
        $items = array ();
        $i = 1;
        foreach ($parts as $val)
            {
            $val = trim ($val);
            if (empty ($val))
                continue;

            $s = explode ("-", $val, 2);
            if (count ($s) == 2)
                {
                $i = $s[0];
                $items[$i] = $s[1];
                }
            else
                $items[$i] = $val;

            $i++;
            }
        return $items;
        }

    public static function getItem ($col, $val)
        {
        $items = self::getItems ($col);
        if (array_key_exists ($val, $items))
            return $items[$val];
        return $val;
        }

    public function getDefaultValue ()
        {
        return NULL;
        }
        
    }

class DecimalColumn extends IntColumn
    {
    const TYPE = 'decimal';

    public function __construct ($name, $null = false, $length = 7, $precission = 3)
        {
        parent::__construct ($name, $null);
        $this->type = self::TYPE;
        $this->size = "$length,$precission";
        }

    public function formatValueForDB ($context, $val)
        {
        $val = str_replace (",", ".", $val);
        if (!is_numeric ($val))
            return parent::formatValueForDB ($context, NULL);
        return $val;
        }
    }

class HeightColumn extends IntColumn
    {
    }

class WeightColumn extends IntColumn
    {
    }

class AutoincrementColumn extends IntColumn
    {
    public function __construct ($name)
        {
        parent::__construct ($name);
        $this->name = $name;
        $this->modifiers = "auto_increment";
        }
    }

class BoolColumn extends IntColumn
    {
    const TYPE = 'tinyint';

    public function __construct ($name, $null = false)
        {
        parent::__construct ($name, $null);
        $this->type = self::TYPE;
        }

    public function formatValueForDB ($context, $val)
        {
        if (NULL === $val)
            return parent::formatValueForDB ($context, $val);

        return $val ? "1" : "0";
        }

    public function isValueValid ($context, $val)
        {
        if (NULL === $val)
            return parent::isValueValid ($context, $val);

        return is_bool ($val) || is_numeric ($val);
        }

    public function getDefaultValue ()
        {
        return is_bool ($this->defaultValue) ? $this->defaultValue : 0;
        }
    }

class TextColumn extends ColumnDef
    {
    const TYPE = 'varchar';

    public function __construct ($name, $length, $null = false)
        {
        $this->name = $name;
        $this->type = self::TYPE;
        $this->size = $length;
        $this->acceptNull = $null;
        }

    public function formatValueForDB ($context, $val)
        {
        if (NULL == $val)
            return parent::formatValueForDB ($context, NULL);

        return "'".addslashes (trim ($val))."'";
        }

    public function isValueValid ($context, $val)
        {
        $val = trim ($val);

        if (!$this->acceptNull && empty ($val))
            return parent::isValueValid ($context, NULL);

        if ($this->size > 0 && strlen ($val) > $this->size)
            return $context->ngettext ("Field [_1] is too long (enter no more than [_0] character).",
                                       "Field [_1] is too long (enter no more than [_0] characters).",
                                       $this->size, $this->getLabel ());

        return true;
        }
    }

class LongTextColumn extends TextColumn
    {
    const TYPE = 'text';

    public function __construct ($name, $null = false)
        {
        parent::__construct ($name, -1, $null);
        $this->type = self::TYPE;
        }
    }

class PasswordColumn extends TextColumn
    {
    public function __construct ($name, $length, $null = false)
        {
        parent::__construct ($name, $length, $null);
        }

    public function formatValueForDB ($context, $val)
        {
        if (false === $val)
            return "'NO PASSWORD'";
        if (NULL == $val)
            return parent::formatValueForDB ($context, $val);

        return "PASSWORD('$val')";
        }
    }

class DateTimeColumn extends ColumnDef
    {
    const TYPE = 'datetime';

    public function __construct ($name, $null = false)
        {
        $this->name = $name;
        $this->type = self::TYPE;
        $this->acceptNull = $null;
        }

    public function formatValueForDB ($context, $val)
        {
        if (NULL == $val)
            return parent::formatValueForDB ($context, NULL);

        return "'$val'";
        }

    public function compare ($a, $b)
        {
        if ($a == $b)
            return 0;

        if (strlen ($a) > 0 && strlen ($b) > 0)
            {
            $defaultValue = "0000-00-00 00:00:00";
            if (strlen ($a) < strlen ($defaultValue))
                $a .= substr ($defaultValue, strlen ($a) - strlen ($defaultValue));
            if (strlen ($b) < strlen ($defaultValue))
                $b .= substr ($defaultValue, strlen ($b) - strlen ($defaultValue));
            }

        if ($a == $b)
            return 0;
        return $a > $b ? 1 : -1;
        }
    }

class TimestampColumn extends DateTimeColumn
    {
    const TYPE = 'timestamp';

    public function __construct ($name, $null = false)
        {
        $this->name = $name;
        $this->type = self::TYPE;
        $this->acceptNull = $null;
        }
    }

class CreatedOnColumn extends TimestampColumn
    {
    public function __construct ($name)
        {
        parent::__construct ($name, false);
        $this->defaultValue = "current_timestamp";
        }
    }

class UpdatedOnColumn extends TimestampColumn
    {
    public function __construct ($name)
        {
        parent::__construct ($name, true);
        // $this->modifiers = "on update current_timestamp";
        $this->defaultValue = "'0000-00-00 00:00:00'";
        }
    }

class DateColumn extends DateTimeColumn
    {
    const TYPE = 'date';

    public function __construct ($name, $null = false)
        {
        $this->name = $name;
        $this->type = self::TYPE;
        $this->acceptNull = $null;
        }

    }

class ColumnDefFactory
    {
    const TYPE_TEXT = "text";
    const TYPE_LONGTEXT = "longtext";
    const TYPE_INTEGER = "int";
    const TYPE_DECIMAL = "float";
    const TYPE_UNIQUEID = "uid";
    const TYPE_BOOLEAN = "bool";
    const TYPE_DATE = "date";
    const TYPE_DATETIME = "datetime";
    const TYPE_COMPOSITE = "composite";
    const TYPE_NAMEDINT = "namedint";

    const TYPE_HEIGHT = "height";
    const TYPE_WEIGHT = "weight";

    private static $nameToClass = array
        (
        ColumnDefFactory::TYPE_UNIQUEID => "AutoincrementColumn",
        ColumnDefFactory::TYPE_TEXT => "TextColumn",
        ColumnDefFactory::TYPE_INTEGER => "IntColumn",
        ColumnDefFactory::TYPE_DECIMAL => "DecimalColumn",
        ColumnDefFactory::TYPE_BOOLEAN => "BoolColumn",
        ColumnDefFactory::TYPE_DATE => "DateColumn",
        ColumnDefFactory::TYPE_DATETIME => "DateTimeColumn",
        ColumnDefFactory::TYPE_LONGTEXT => "LongTextColumn",
        ColumnDefFactory::TYPE_COMPOSITE => "CompositeColumn",
        ColumnDefFactory::TYPE_NAMEDINT => "NamedIntColumn",
        ColumnDefFactory::TYPE_HEIGHT => "HeightColumn",
        ColumnDefFactory::TYPE_WEIGHT => "WeightColumn",
        );

    public static function getTypeString ($instance)
        {
        return array_search (get_class ($instance), self::$nameToClass);
        }

    public static function create ($type, $name, $size, $precision, $acceptNull, $defaultValue)
        {
        if (!isset (self::$nameToClass[$type]))
            return NULL;

        $class = self::$nameToClass[$type];
        if (ColumnDefFactory::TYPE_TEXT == $type)
            return new $class ($name, $size, $acceptNull, $defaultValue);
        return new $class ($name, $acceptNull, $defaultValue);
        }
    }
?>
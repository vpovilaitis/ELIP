<?php

class LabelParentFieldTemplate extends LabelContentLinkFieldTemplate
    {
    protected $childTable;
    protected $transformations;

    public function __construct ($prefix, $dbtable, $label)
        {
        parent::__construct ($prefix, Constants::PARENT.".".ContentTable::COL_DISPLAY_NAME, $label);
        $this->childTable = $dbtable;
        $this->dbtable = $dbtable->getParentTable ();
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        $ret = $this->childTable->createRelatedColumnQuery (NULL, Constants::PARENT,
                                                          $resultColumns, $this->transformations,
                                                          NULL, $joins);
        if ($ret)
            {
            $parent = $this->dbtable;
            $index = $parent->getPrimaryIndexColumns ();

            $cols = array ();
            foreach ($index as $col)
                $cols[] = $col->name;
            if (empty ($resultColumns))
                $resultColumns = $cols;
            else
                $resultColumns = array_merge ($resultColumns, $cols);
            }

        }

    public function getUri ($context, $row)
        {
        $parent = $this->dbtable;
        $index = $parent->getPrimaryIndexColumns ();

        $id = array ();
        foreach ($index as $col)
            $id[] = $row[$col->name];

        return $this->createLink ($context, $parent->getId (), $id);
        }
    }

class LabelFixedParentFieldTemplate extends LabelParentFieldTemplate
    {
    protected $id;

    public function __construct ($prefix, $dbtable, $label, $parentId)
        {
        parent::__construct ($prefix, $dbtable, $label);
        $this->id = $parentId;
        }

    public function getUri ($context, $row)
        {
        $parent = $this->dbtable;
        return $this->createLink ($context, $parent->getId (), $this->id);
        }

    public function getValueForDisplay ($context, $row)
        {
        return $this->dbtable->getDisplayNameById ($this->id);
        }
    }

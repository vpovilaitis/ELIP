<?php

class DateFieldTemplate extends FieldTemplate
    {
    public function __construct ($prefix, $key, $label, $tooltip)
        {
        parent::__construct ($prefix, $key, "date", $label, $tooltip);
        $this->cssClass = "datefield";
        }

    public function getValueForDB ($context, $request, $index = NULL)
        {
        $val = parent::getValueForDB ($context, $request, $index);
        if (!empty ($val))
            return Language::getInstance($context)->parseDate ($val);
        return NULL;
        }

    public function getValueForDisplay ($context, $row)
        {
        return Language::getInstance($context)->dateToString ($val);
        }

    public function getValueForEditing ($context, $row)
        {
        $val = $this->getValueForDB ($context, $row);
        if (empty ($val))
            return NULL;
        return Language::getInstance($context)->dateToString ($val);
        }
    }

<?php
require_once (PATH."inc/dbtable.php");

class QuickLinksTable extends DBTableWithPerspective
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "quicklink";

    const COL_ID = "qlinkid";
    const COL_TYPE = "linktype";
    const COL_LABEL = "label";
    const COL_TOOLTIP = "tooltip";
    const COL_INDENT = "indent";
    const COL_HIDDEN = "hidden";
    const COL_URL = "url";
    const COL_PARAM_INT = "iparam";
    const COL_PARAM_STR = "sparam";
    const COL_TARGET_GROUP = "targetgrp";

    const TYPE_SEPARATOR = 0;
    const TYPE_PAGE = 1;
    const TYPE_CONTENT_LIST = 2;
    const TYPE_IMAGE = 3;
    const TYPE_EXTERNAL_URL = 4;
    const TYPE_LANGUAGE_LINK = 5;
    const TYPE_LABEL = 6;
    const TYPE_RELATIVE_URL = 7;
    const TYPE_NEWS_LIST = 8;

    const TYPE_LOGIN = 100;

    const GROUP_EVERYONE = 0;
    const GROUP_GUESTS = -1;
    const GROUP_SIGNED_IN = -10;
    const GROUP_META_ADMINS = -100;
    
    const MIN_INDENT = 0;
    const MAX_INDENT = 2;

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, true);
        $this->tracksRevisions = true;
        }

    protected function getColumns ()
        {
        $indentColumn = new IntColumn (self::COL_INDENT, false);
        $indentColumn->defaultValue = 1;
        $groupColumn = new IntColumn (self::COL_TARGET_GROUP, false);
        $groupColumn->defaultValue = self::GROUP_EVERYONE;

        return array (
                     new AutoincrementColumn (self::COL_ID),
                     $this->getPerspectiveColumn (),
                     new IntColumn (DBTable::COL_ORDER, false),
                     new BoolColumn (self::COL_HIDDEN, false),
                     new IntColumn (self::COL_TYPE, false),
                     $indentColumn,
                     $groupColumn,
                     new IntColumn (self::COL_PARAM_INT, true),
                     new TextColumn (self::COL_URL, 1024, true),
                     new TextColumn (self::COL_PARAM_STR, 256, true),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new Index (self::COL_PERSPECTIVE, self::COL_HIDDEN, DBTable::COL_ORDER),
            );
        }

    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (self::COL_LABEL, 32, true),
                     new TextColumn (self::COL_TOOLTIP, 1024, true),
                     );
        }

    public function insertRecord ($nameToValue)
        {
        if (empty ($nameToValue[DBTable::COL_ORDER]))
            {
            $order = $this->getNextColumnValue (DBTable::COL_ORDER, array ());
            if (false === $order)
                return false;

            $nameToValue[DBTable::COL_ORDER] = $order;
            }
        else
            {
            $criteria[] = new GtEqCriterion (DBTable::COL_ORDER, $nameToValue[DBTable::COL_ORDER]);
            if (false === $this->alterColumnValue ($criteria, self::COL_ORDER, "+1"))
                return false;
            }

        $ret = parent::insertRecord ($nameToValue);
        $this->clearCache ();
        return $ret;
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = 1)
        {
        $ret = parent::updateRecord ($criteria, $nameToValue, $maxRows);
        $this->clearCache ();
        return $ret;
        }

    protected function clearCache ()
        {
        $cache = Cache::getInstance (self::TABLE_NAME, 12*60*60);
        $cache->clean ();
        }
        
    public function deleteById ($criteria)
        {
        $ret = parent::deleteById ($criteria);
        $this->clearCache ();
        return $ret;
        }

    public static function getAllLinks ($context)
        {
        $cache = Cache::getInstance (self::TABLE_NAME, 12*60*60);
        $key = "quicklinks_".md5 ($context->getPerspective ()."_".$context->getCurrentUser ());
        if (!empty ($context->request["generatelinks"]) || false === ($rows = $cache->get ($key)))
            {
            $dbtable = new QuickLinksTable ($context);
            $rows = $dbtable->selectAllPreprocessed ($context, 1);
            $cache->save ($rows, $key);
            }

        self::adjustCachedRecords ($context, $rows);
        return $rows;
        }

    protected static function adjustCachedRecords ($context, &$rows)
        {
        foreach ($rows as &$item)
            {
            if (!empty ($item["adjust"]))
                {
                switch ($item["adjust"])
                    {
                    case QuickLinksTable::TYPE_LANGUAGE_LINK:
                        $languages = $GLOBALS["Languages"];
                        $url = NULL;
                        if (!empty ($languages))
                            {
                            $linkLanguageCode = $item["lng"];
                            foreach ($languages as $lang)
                                {
                                $code = $lang->code;
                                if ($code == $linkLanguageCode)
                                    {
                                    if (!empty ($lang->redirectHost))
                                        $url = $context->getAdjustedUrl (array (), $lang->redirectHost);
                                    break;
                                    }
                                }
                            }

                        if (empty ($url))
                            $url = $context->getAdjustedUrl (array (Constants::PARAM_LANGUAGE => $code));

                        $item["url"] = $url;
                        break;

                    case QuickLinksTable::TYPE_LOGIN:
                        if ($context->getCurrentUser () > 0)
                            $item["url"] = NULL;
                        else
                            $item["url"] = $context->processUrl ("login.php?".Constants::PARAM_RETURN_TO."=".rawurlencode ($context->getAdjustedUrl (array (Constants::PARAM_RETURN_TO => NULL))), true);
                        break;
                    }
                }

            if (!empty ($item["items"]))
                self::adjustCachedRecords ($context, $item["items"]);
            }
        }

    public function moveRecordUp ($id)
        {
        return parent::changeItemOrder (array (), self::COL_ID, $id, true);
        }
    public function moveRecordDown ($id)
        {
        return parent::changeItemOrder (array (), self::COL_ID, $id, false);
        }

    public function changeRecordIndent ($id, $promote)
        {
        $criteria[] = new EqCriterion (self::COL_ID, $id);
        if ($promote)
            $criteria[] = new GtCriterion (self::COL_INDENT, self::MIN_INDENT);
        else
            $criteria[] = new LtCriterion (self::COL_INDENT, self::MAX_INDENT);

        $ret = parent::alterColumnValue ($criteria, self::COL_INDENT, $promote ? "-1" : "+1");
        $this->clearCache ();
        return $ret;
        }
    public function indentRecordLess ($id)
        {
        return $this->changeRecordIndent ($id, true);
        }
    public function indentRecordMore ($id)
        {
        return $this->changeRecordIndent ($id, false);
        }

    public function insertRecordAt ($nameToValue, $id)
        {
        $nextSibling = NULL;
        $foundRow = NULL;

        if (!empty ($id))
            {
            $allLinks = $this->getAllLinks ($this->context);
            if (false === $allLinks)
                return false;
            $foundRow = $this->findWithNextSibling ($allLinks, $id, $nextSibling);
            }

        if (!empty ($foundRow))
            {
            $nameToValue[self::COL_INDENT] = $foundRow["indent"] >= self::MAX_INDENT ? self::MAX_INDENT : $foundRow["indent"] + 1;
            }
        else
            $nameToValue[self::COL_INDENT] = 0;

        if (!empty ($nextSibling))
            {
            $nameToValue[DBTable::COL_ORDER] = $nextSibling[DBTable::COL_ORDER];
            }

        return $this->insertRecord ($nameToValue);
        }

    public function insertSeparatorAt ($id)
        {
        $nameToValue = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_SEPARATOR);
        return $this->insertRecordAt ($nameToValue, $id);
        }

    protected function selectAllPreprocessed ($context, $attempt)
        {
        if ($attempt > 2)
            return NULL;

        $columns = array (QuickLinksTable::COL_ID,
                          QuickLinksTable::COL_TYPE, QuickLinksTable::COL_LABEL, DBTable::COL_ORDER,
                          QuickLinksTable::COL_TOOLTIP, QuickLinksTable::COL_INDENT,
                          QuickLinksTable::COL_HIDDEN, QuickLinksTable::COL_PARAM_INT,
                          QuickLinksTable::COL_PARAM_STR, QuickLinksTable::COL_PERSPECTIVE,
                          QuickLinksTable::COL_TARGET_GROUP, QuickLinksTable::COL_URL);
        $rows = $this->selectBy ($columns, NULL);
        if (false === $rows)
            {
            $context->log ("Warning: No site settings found");
            return false;
            }

        return $this->convertSelectedRowsToLinks ($context, $rows, $attempt);
        }

    protected function convertSelectedRowsToLinks ($context, $rows, $attempt)
        {
        if (empty ($rows))
            {
            if (!$this->canCreate ())
                {
                $rows = array ();
                $rows[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_LOGIN,
                                 QuickLinksTable::COL_LABEL => $this->getText ("Sign in"),
                                 QuickLinksTable::COL_INDENT => 2,
                                 QuickLinksTable::COL_TOOLTIP => $this->getText ("Log into the site to edit content"),
                                 QuickLinksTable::COL_TARGET_GROUP => self::GROUP_GUESTS);
                return $this->convertRowGroup ($context, $rows, 0);
                }

            $request = $context->request;
            if (!empty ($request["generatelinks"]))
                {
                $this->createDefaultLinkSet ();
                return $this->selectAllPreprocessed ($context, $attempt + 1);
                }

            $rows = array ();
            $rows[] = array ('indent' => '0',
                           "items" => array (
                                        array ("label" => $this->getText ("No links are currently created, use following link to generate default link set"),
                                               'indent' => '1',
                                               "items" =>
                                                    array (
                                                        array ("label" => $this->getText ("Create links"),
                                                               "url" => $context->getAdjustedUrl (array ("generatelinks" => 1)),
                                                              )
                                                          )
                                              )
                                            )
                          );
            }
        else
            {
            $rows = $this->convertRowGroup ($context, $rows, 0);
            }
        return $rows;
        }

    protected function convertRowGroup ($context, $rows, $indent, $hidden = false)
        {
        $groups = array ();
        $lastGroup = NULL;
        $lastHeader = NULL;

        foreach ($rows as $row)
            {
            if ($row[QuickLinksTable::COL_INDENT] <= $indent)
                {
                if (NULL !== $lastGroup || NULL !== $lastHeader)
                    {
                    $group = $this->createNewRowGroup ($context, $lastHeader, $lastGroup, $indent, $hidden);
                    if (!empty ($group))
                        $groups[] = $group;
                    }
                
                if (QuickLinksTable::TYPE_SEPARATOR == $row[QuickLinksTable::COL_TYPE])
                    {
                    // separators do not have children
                    $group = $this->createNewRowGroup ($context, $row, NULL, $indent, $hidden);
                    if (!empty ($group))
                        $groups[] = $group;

                    $lastHeader = NULL;
                    $lastGroup = NULL;
                    }
                else
                    {
                    $lastHeader = $row;
                    $lastGroup = NULL;
                    }
                }
            else
                $lastGroup[] = $row;
            }

        if (NULL !== $lastGroup || NULL !== $lastHeader)
            {
            $group = $this->createNewRowGroup ($context, $lastHeader, $lastGroup, $indent, $hidden);
            if (!empty ($group))
                $groups[] = $group;
            }

        return $groups;
        }

    protected function createNewRowGroup ($context, $headerRow, $childRows, $indent, $hidden)
        {
        $item = array ("indent" => $indent);

        if (!empty ($headerRow))
            {
            switch ($headerRow[QuickLinksTable::COL_TARGET_GROUP])
                {
                case self::GROUP_GUESTS:
                    if ($this->context->getCurrentUser () > 0)
                        $hidden = true;
                    break;
                case self::GROUP_SIGNED_IN:
                    if ($this->context->getCurrentUser () <= 0)
                        $hidden = true;
                    break;
                case self::GROUP_META_ADMINS:
                    if (!$this->context->canEdit (Constants::TABLES_META, Constants::ANY))
                        $hidden = true;
                    break;
                }

            if ($hidden && !$this->canEdit ())
                {
                // if user cannot edit the item, no need to show it
                return NULL;
                }

            $item["label"] = $headerRow[QuickLinksTable::COL_LABEL];
            $item["tooltip"] = $headerRow[QuickLinksTable::COL_TOOLTIP];

            switch ($headerRow[QuickLinksTable::COL_TYPE])
                {
                case QuickLinksTable::TYPE_LANGUAGE_LINK:
                    $lng = $this->getLanguage ();
                    $linkLanguageCode = $headerRow[QuickLinksTable::COL_PARAM_STR];
                    if ($lng == $linkLanguageCode)
                        break;

                    $item["adjust"] = QuickLinksTable::TYPE_LANGUAGE_LINK;
                    $item["lng"] = $linkLanguageCode;
                    break;

                case QuickLinksTable::TYPE_PAGE:
                    $page = $headerRow[QuickLinksTable::COL_PARAM_STR];
                    $item["url"] = $this->context->createContentPageUrl ($page);
                    break;

                case QuickLinksTable::TYPE_LOGIN:
                    $item["adjust"] = QuickLinksTable::TYPE_LOGIN;
                    break;

                case QuickLinksTable::TYPE_RELATIVE_URL:
                    $url = $headerRow[QuickLinksTable::COL_URL];
                    $item["url"] = $this->context->processUrl ($url, true);
                    break;

                case QuickLinksTable::TYPE_EXTERNAL_URL:
                    $url = $headerRow[QuickLinksTable::COL_URL];
                    $item["url"] = $url;
                    $item["target"] = "_blank";
                    break;

                case QuickLinksTable::TYPE_CONTENT_LIST:
                    $table = $headerRow[QuickLinksTable::COL_PARAM_STR];
                    $item["url"] = $context->chooseUrl ("list/$table", "index.php?c=ContentPreviewPage&tn=$table");
                    break;

                case QuickLinksTable::TYPE_NEWS_LIST:
                    $item["url"] = $context->chooseUrl ("sitenews", "index.php?c=NewsListPage");
                    break;

                case QuickLinksTable::TYPE_IMAGE:
                    $url = $headerRow[QuickLinksTable::COL_URL];
                    if (!empty ($url))
                        $item["url"] = $url;
                    $item["img"] = $headerRow[QuickLinksTable::COL_PARAM_STR];
                    $item["size"] = $headerRow[QuickLinksTable::COL_PARAM_INT];
                    break;
                case QuickLinksTable::TYPE_SEPARATOR:
                    $item["separator"] = true;
                    break;
                }
            }

        if ($hidden)
            unset ($item["url"]);

        $item["id"] = $headerRow[QuickLinksTable::COL_ID];
        $item[DBTable::COL_ORDER] = $headerRow[DBTable::COL_ORDER];

        if (!empty ($childRows))
            {
            $item["items"] = $this->convertRowGroup ($context, $childRows, $indent + 1, $hidden);
            }

        return $item;
        }

    public function createDefaultLinkSet ()
        {
        $linksToCreate = array ();

        if (defined ("SITE_IMAGE") && strlen (SITE_IMAGE) > 0)
            {
            $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_IMAGE,
                                      QuickLinksTable::COL_LABEL => NULL,
                                      QuickLinksTable::COL_INDENT => 0,
                                      QuickLinksTable::COL_TOOLTIP => $this->getText ("Navigate to the main page"),
                                      QuickLinksTable::COL_PARAM_STR => SITE_IMAGE,
                                      QuickLinksTable::COL_PARAM_INT => SITE_IMAGE_SIZE,
                                      QuickLinksTable::COL_URL => $this->context->createContentPageUrl (HOME_PAGE),
                                      );
            }

        $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_LABEL, QuickLinksTable::COL_LABEL => $this->getText ("Navigate:"));
        $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_PAGE,
                                  QuickLinksTable::COL_LABEL => $this->getText ("Home"),
                                  QuickLinksTable::COL_INDENT => 2,
                                  QuickLinksTable::COL_TOOLTIP => $this->getText ("Navigate to the main page"),
                                  QuickLinksTable::COL_PARAM_STR => HOME_PAGE,
                                  );
        $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_NEWS_LIST,
                                  QuickLinksTable::COL_LABEL => $this->getText ("News"),
                                  QuickLinksTable::COL_INDENT => 2,
                                  QuickLinksTable::COL_TOOLTIP => $this->getText ("News archive"),
                                  );

        $customLists = ComponentFactory::getQuickLinkLists ($this->context);
        foreach ($customLists as $table => $label)
            {
            $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_CONTENT_LIST,
                                      QuickLinksTable::COL_LABEL => $label,
                                      QuickLinksTable::COL_INDENT => 2,
                                      QuickLinksTable::COL_PARAM_STR => $table,
                                      );
            }

        $languages = $GLOBALS["Languages"];
        if (!empty ($languages) && count ($languages) > 1)
            {
            $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_SEPARATOR, QuickLinksTable::COL_INDENT => 0);
            $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_LABEL, QuickLinksTable::COL_LABEL => $this->getText ("Language:"));
            foreach ($languages as $lang)
                {
                $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_LANGUAGE_LINK,
                                          QuickLinksTable::COL_LABEL => $lang->label,
                                          QuickLinksTable::COL_PARAM_STR => $lang->code,
                                          QuickLinksTable::COL_INDENT => 2,
                                          );
                }
            }

        $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_SEPARATOR, QuickLinksTable::COL_INDENT => 0);
        $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_LABEL, QuickLinksTable::COL_LABEL => $this->getText ("Editing"));
        $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_RELATIVE_URL,
                                  QuickLinksTable::COL_LABEL => $this->getText ("Tools"),
                                  QuickLinksTable::COL_INDENT => 2,
                                  QuickLinksTable::COL_TOOLTIP => $this->getText ("Editor tools"),
                                  QuickLinksTable::COL_TARGET_GROUP => self::GROUP_SIGNED_IN,
                                  QuickLinksTable::COL_URL => "index.php?c=Tools",
                                  );
        $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_LOGIN,
                                  QuickLinksTable::COL_LABEL => $this->getText ("Sign in"),
                                  QuickLinksTable::COL_INDENT => 2,
                                  QuickLinksTable::COL_TOOLTIP => $this->getText ("Log into the site to edit content"),
                                  QuickLinksTable::COL_TARGET_GROUP => self::GROUP_GUESTS,
                                  );
        $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_RELATIVE_URL,
                                  QuickLinksTable::COL_LABEL => $this->getText ("Sign out"),
                                  QuickLinksTable::COL_INDENT => 2,
                                  QuickLinksTable::COL_TOOLTIP => $this->getText ("End editing session"),
                                  QuickLinksTable::COL_TARGET_GROUP => self::GROUP_SIGNED_IN,
                                  QuickLinksTable::COL_URL => "logout.php",
                                  );
        $linksToCreate[] = array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_RELATIVE_URL,
                                  QuickLinksTable::COL_LABEL => $this->getText ("Administrate"),
                                  QuickLinksTable::COL_INDENT => 2,
                                  QuickLinksTable::COL_TOOLTIP => $this->getText ("Advanced administrator tools"),
                                  QuickLinksTable::COL_TARGET_GROUP => self::GROUP_META_ADMINS,
                                  QuickLinksTable::COL_URL => "admin.php",
                                  );

        foreach ($linksToCreate as $link)
            {
            $ret = $this->insertRecord ($link);
            if (empty ($ret))
                return $ret;
            }

        return true;    
        }

    /* in a hierarchical link array searches for the specified item and returns
       found row and the id of the next item which is not under the specified item.
    */
    protected function findWithNextSibling ($tree, $id, &$nextSibling)
        {
        $foundRow = NULL;
        foreach ($tree as $entry)
            {
            if (NULL !== $foundRow)
                {
                $nextSibling = $entry;
                return $foundRow;
                }
            else if ($entry["id"] == $id)
                {
                $foundRow = $entry;
                }
            else if (!empty ($entry["items"]))
                {
                $foundRow = $this->findWithNextSibling ($entry["items"], $id, $nextSibling);
                if (!empty ($foundRow) && !empty ($nextSibling))
                    return $foundRow;
                }
            }

        return $foundRow;
        }

    }

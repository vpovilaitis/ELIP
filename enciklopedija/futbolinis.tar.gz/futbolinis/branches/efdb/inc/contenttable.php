<?php
require_once (PATH.'inc/metatables.php');
require_once (PATH.'inc/cache.php');

class ContentTable extends DBTable
    {
    protected $tableId;
    protected $description;
    protected $name;
    protected $isCreated;
    protected $languageNeutralColumns = NULL;
    protected $allColumns = NULL;
    protected $nameToDef = NULL;
    protected $translatableColumns = NULL;
    protected $relatedColumns = NULL;
    protected $relatedColumnToTableId = NULL;
    protected $parentTable = NULL;
    protected $displayNameColumn = NULL;
    protected $sortColumns = array ();
    protected $indexes = NULL;
    protected $integrate;
    protected $parentSort;
    protected $parentSortAsc;
    protected $filterColumn;
    
    protected static $cachedHandlers = array();
    protected static $cachedTablesById = NULL;
    protected static $cachedTablesByName = NULL;

    const COL_DISPLAY_NAME = "displayname";
    const COL_SECTION = "__section__";

    const STATE_HIDDEN = 0;
    const STATE_ACTIVE = 1;
    const STATE_LOCKED = 2;
    
    const PREFIX = "c_";

    /* should be private, but PHP does not allow this currently
       it should never be used directly, instances should be created
       by calling ContentTable::retrieveFromDB() */
    public function __construct ($context, $instanceRow)
        {
        $tableId = $instanceRow[MetaDataTables::COL_TABLEID];
        $this->name = $instanceRow[MetaDataTables::COL_NAME];
        $tableName = $this->name;
        $hasTranslatableStrings = $instanceRow["trans"];
        $this->tableId = $tableId;

        parent::__construct ($context, Constants::TABLES_USER, $tableName, $hasTranslatableStrings);

        $this->label = $instanceRow[MetaDataTables::COL_LABEL];
        $this->description = $instanceRow[MetaDataTables::COL_DESCRIPTION];
        $this->isCreated = $instanceRow[MetaDataTables::COL_ISCREATED];
        $this->tracksRevisions = $instanceRow[MetaDataTables::COL_REVISIONS];
        $this->tracksSources = $instanceRow[MetaDataTables::COL_SOURCES];
        $this->ownerDeleteAllowed = $instanceRow[MetaDataTables::COL_OWNERCANREMOVE];
        $this->sectionName = $instanceRow[MetaDataTables::COL_INTEGRATED];
        $this->parentSort = $instanceRow[MetaDataTables::COL_PARENTSORTORDER];
        if ($this->parentSort > 0)
            $this->parentSortAsc = $instanceRow[MetaDataTables::COL_PARENTSORTASC];
        
        if (!empty ($instanceRow[MetaDataTables::COL_PARENTID]))
            {
            $this->parentTable = ContentTable::createInstanceById ($context, $instanceRow[MetaDataTables::COL_PARENTID]);
            if (empty ($this->parentTable))
                $context->addError ("Parent table not found");
            }
        }

    public function getRevisionTableName ()
        {
        $name = parent::getRevisionTableName ();
        if (empty ($name))
            return $name;
        return "{$name}_$this->tableId";
        }

    private static function selectMetatables ($context, $criterion)
        {
        $metatables = new MetaDataTables ($context);
        $metacolumns = new MetaDataColumns ($context);

        $resultColumns = array
            (
            MetaDataTables::COL_TABLEID, MetaDataTables::COL_NAME, MetaDataTables::COL_LABEL,
            MetaDataTables::COL_DESCRIPTION, MetaDataTables::COL_PARENTID,
            MetaDataTables::COL_ISCREATED, MetaDataTables::COL_HANDLER,
            MetaDataTables::COL_REVISIONS, MetaDataTables::COL_SOURCES,
            MetaDataTables::COL_PARENTSORTORDER, MetaDataTables::COL_PARENTSORTASC,
            MetaDataTables::COL_INTEGRATED, MetaDataTables::COL_OWNERCANREMOVE,
            );
        $subquery = $metacolumns->createQuery (array (new ConditionalSumColumn ("trans", "1 = ".MetaDataColumns::COL_TRANSLATABLE, 1, 0)),
                                               array (new JoinColumnsCriterion (MetaDataTables::COL_TABLEID, MetaDataColumns::COL_TABLEID)));
        $rows = $metatables->selectBy ($resultColumns,
                                       array ($criterion),
                                       array ($subquery),
                                       array (new GroupBy ($resultColumns))
                                       );

        return $rows;
        }

    private static function createHandler ($context, $row)
        {
        $tableId = $row[MetaDataTables::COL_TABLEID];
        if (array_key_exists ($tableId, self::$cachedHandlers))
            return self::$cachedHandlers[$tableId];

        if (!empty ($row[MetaDataTables::COL_HANDLER]))
            {
            $ret = findCustomHandlerFile ($context, "h", $row[MetaDataTables::COL_HANDLER]);
            if (!empty ($ret))
                {
                list ($className, $file) = $ret;
                require_once $file;
                }
            }

        if (empty ($className))
            $className = "ContentTable";

        self::$cachedHandlers[$tableId] = new $className ($context, $row);
        return self::$cachedHandlers[$tableId];
        }

    protected static function ensureCached ($context)
        {
        if (NULL === self::$cachedTablesByName || NULL === self::$cachedTablesById)
            {
            self::$cachedTablesByName = array ();
            self::$cachedTablesById = array ();

            $cache = Cache::getInstance ("metatables", 12*60*60);
    
            if (false === ($rows = $cache->get ("tables")))
                {
                $rows = self::selectMetatables ($context, NULL);
                $cache->save ($rows, "tables");
                }

            if (empty ($rows))
                return false;

            foreach ($rows as $row)
                {
                self::$cachedTablesById[$row[MetaDataTables::COL_TABLEID]] = $row;
                self::$cachedTablesByName[strtolower ($row[MetaDataTables::COL_NAME])] = $row;
                }
            }
        }

    public static function createInstanceByName ($context, $tableName)
        {
        $tableName = strtolower (trim ($tableName));

        self::ensureCached ($context);
        if (empty (self::$cachedTablesByName[$tableName]))
            return false;

        return self::createHandler ($context, self::$cachedTablesByName[$tableName]);
        }

    public static function createInstanceById ($context, $tableId)
        {
        self::ensureCached ($context);
        if (empty (self::$cachedTablesById[$tableId]))
            return false;

        return self::createHandler ($context, self::$cachedTablesById[$tableId]);
        }

    protected function getColumns ()
        {
        if (false === $this->selectColumns ())
            return false;

        $arr = $this->languageNeutralColumns;

        $sectionTemplate = $this->sectionName;
        if (empty ($this->sectionName) && !empty ($this->displayNameColumn))
            $sectionTemplate = '{'.$this->displayNameColumn->name.'}';

        $arr[] = new CompositeColumn (self::COL_SECTION, true, $sectionTemplate);
        return $arr;
        }

    public function getIdColumn ()
        {
        return $this->name."_id";
        }

    public function getPrimaryIndexColumns ($useAnyUniqueIndex = false)
        {
        if (NULL == $this->parentTable)
            $index = array ();
        else
            $index = $this->parentTable->getPrimaryIndexColumns ();

        $index[] = new IntColumn ($this->getIdColumn ());
        return $index;
        }

    public function getAdditionalColumns ()
        {
        return array ();
        }

    public function canCreateFromLabel ()
        {
        return false;
        }

    public function createFromLabel ($label)
        {
        return false;
        }

    public function integrateIntoParent ()
        {
        return !empty ($this->sectionName);
        }

    public function initializeColumns ()
        {
        if (false === $this->selectColumns ())
            return false;
        return true;
        }

    public function selectDisplayableColumns ()
        {
        $columns = $this->selectColumns ();
        $exclude = array ();
        foreach ($columns as $key => $column)
            {
            if (MetaDataColumns::CATEGORY_GENERATED == $column->category)
                $exclude[] = $key;
            }
        foreach ($exclude as $key)
            unset ($columns[$key]);

        if ($this->tracksSources)
            {
            $sourceColumns = $this->addSystemColumns (array (), false, false, true);
            $labels = array
                (
                self::COL_SOURCE => $this->getText ("Source(s)"),
                self::COL_SOURCEDATE => $this->getText ("Updated on"),
                );
            $tooltips = array
                (
                self::COL_SOURCE => $this->getText ("Source and comments"),
                self::COL_SOURCEDATE => $this->getText ("Sources updated on"),
                );

            foreach ($sourceColumns as $columnDef)
                {
                
                $sourceColumn = new ValueColumn ($columnDef, $labels[$columnDef->name], $tooltips[$columnDef->name]);

                $sourceColumn->category = (self::COL_SOURCEDATE == $columnDef->name)
                                            ? MetaDataColumns::CATEGORY_DETAILS
                                            : MetaDataColumns::CATEGORY_ADDITIONAL;
                $columns[] = $sourceColumn;
                }
            }

        return $columns;
        }

    public function findColumn ($name)
        {
        if (NULL === $this->nameToDef)
            {
            $this->nameToDef = array ();
            foreach ($this->selectColumns () as $col)
                {
                $this->nameToDef[$col->name] = $col;
                if ($col instanceof ValueColumn)
                    $this->nameToDef[$col->columnDef->name] = $col;
                }
            }

        if (isset ($this->nameToDef[$name]))
            return $this->nameToDef[$name];

        return false;
        }

    public function selectColumns ()
        {
        if (NULL !== $this->allColumns)
            return $this->allColumns;

        $metacolumns = new MetaDataColumns ($this->context);
        $this->allColumns = $metacolumns->selectColumns ($this->tableId);
        if (empty ($this->allColumns))
            return $this->allColumns;

        $this->translatableColumns = array ();
        $this->relatedColumns = array ();
        $this->relatedColumnToTableId = array ();

        $this->languageNeutralColumns = array ();
        if (NULL == $this->parentTable)
            $this->languageNeutralColumns[] = new AutoincrementColumn($this->getIdColumn ());
        else
            $this->languageNeutralColumns = $this->getPrimaryIndexColumns ();

        foreach ($this->allColumns as $col)
            {
            if ($col instanceof ValueColumn)
                {
                $columnDef = $col->columnDef;
                $columnDef->name = self::prepareUserColumnName ($columnDef->name);
                }
            }

        $this->allColumns = array_merge ($this->allColumns, $this->getAdditionalColumns ());
        $nameColumn = NULL;
        $sortColumns = array ();

        foreach ($this->allColumns as $col)
            {
            $colName = $col->name;
            if ($col instanceof ValueColumn)
                {
                if (self::COL_DISPLAY_NAME == $col->name)
                    $this->displayNameColumn = $col;

                $columnDef = $col->columnDef;
                $colName = $columnDef->name;

                if ($col->translatable)
                    $this->translatableColumns[] = $columnDef;
                else
                    $this->languageNeutralColumns[] = $columnDef;

                if ($columnDef instanceof TextColumn && !$columnDef instanceof LongTextColumn)
                    {
                    if (NULL == $nameColumn && false !== stripos ($col->name, "name"))
                        $nameColumn = $col;
                    }
                }
            else
                {
                // column defined a relation, so add id columns
                $relatedTableId = $col->relatedTableId;
                $idColumns = $this->getForeignKeyColumns ($col->name, $col->required, $relatedTableId);
                $this->languageNeutralColumns = array_merge ($this->languageNeutralColumns, $idColumns);
                
                $this->relatedColumns[$col->name] = $idColumns;
                $this->relatedColumnToTableId[$col->name] = $relatedTableId;
                }

            if ($col->sortOrder > 0)
                {
                $this->sortColumns[] = new OrderByColumn ($colName, $col->sortAsc, $col->sortOrder);
                $sortColumns[$col->sortOrder] = $col;
                }
            }

        /* if there is no column named "displayname", try guessing display name
           column - use any column containing "name", or just first text column */
        if (NULL == $this->displayNameColumn && !empty ($nameColumn))
            $this->displayNameColumn = $nameColumn;

        if ($this->parentSort > 0)
            $this->sortColumns[] = new OrderByColumn (Constants::PARENT, $this->parentSortAsc, $this->parentSort);

        $this->filterColumn = $this->createFilterColumn ($sortColumns);

        return $this->allColumns;
        }

    protected function createFilterColumn ($sortColumns)
        {
        return new FilterColumn ($this, $this->displayNameColumn, $sortColumns);
        }

    protected function getTranslatableColumns ()
        {
        if (false === $this->initializeColumns ())
            return false;
        return $this->translatableColumns;
        }

    protected function getIndexes ()
        {
        if (NULL === $this->indexes)
            {
            $this->indexes = array ();
            if (NULL != $this->parentTable)
                {
                $indexColumns = $this->getPrimaryIndexColumns ();
                $names = array ();
                foreach ($indexColumns as $def)
                    $names[] = $def->name;
                $arr[] = array (new PrimaryIndex ($names));
                }
    
            $handler = new MetaDataIndexes ($this->context);
            $this->indexes = $handler->selectIndexes ($this->tableId);
            }    

        if (empty ($this->indexes))
            return $this->indexes;

        $indexes = array ();
        foreach ($this->indexes as $index)
            {
            $idx = $this->preprocessIndex ($index);
            if (false === $idx)
                {
                $this->indexes = false;
                break;
                }

            $indexes[] = $idx;
            }

        return $indexes;
        }

    protected function findIndex ($indexName)
        {
        if (NULL === $this->indexes)
            $this->getIndexes ();

        if (empty ($this->indexes))
            return false;

        foreach ($this->indexes as $index)
            {
            if ($index->name == $indexName)
                return $index;
            }

        return false;
        }

    public static function generateForeignKeyColumn ($relationName, $idColumnName)
        {
        return "f_".$relationName."_".$idColumnName;
        }

    public function getForeignKeyColumns ($relationName, $required, $relatedTableId)
        {
        $relatedTable = $this->tableId == $relatedTableId ? $this : ContentTable::createInstanceById ($this->context, $relatedTableId);
        if (empty ($relatedTable))
            {
            $this->context->addError ("Related table not found");
            return false;
            }

        $index = $relatedTable->getPrimaryIndexColumns ();
        $result = array ();
        foreach ($index as $col)
            {
            $column = clone $col;
            $column->name = self::generateForeignKeyColumn ($relationName, $column->name);
            $column->acceptNull = !$required;
            $result[] = $column;
            }
        
        return $result;
        }

    public function getDisplayName ($row, $idIfNotFound = false)
        {
        if (!empty ($this->displayNameColumn))
            {
            $colName = $this->displayNameColumn->columnDef->name;
            if (!empty ($row[$colName]))
                return $row[$colName];
            }

        if (!$idIfNotFound)
            return NULL;

        $indexColumns = $this->getPrimaryIndexColumns ();
        $id = array ();
        foreach ($indexColumns as $col)
            $id[] = $row[$col->name];
        return "(".implode (", ", $id).")";
        }

    public function getRowIds ($row)
        {
        $indexColumns = $this->getPrimaryIndexColumns ();
        $id = array ();
        foreach ($indexColumns as $col)
            $id[] = $row[$col->name];
        return $id;
        }

    public function getDisplayNameById ($id, $idIfNotFound = false)
        {
        if (empty ($id))
            return NULL;

        if (is_numeric ($id))
            $id = array ($id);

        $indexColumns = $this->getPrimaryIndexColumns ();
        $criteria = array ();
        for ($i = 0; $i < count ($indexColumns) && $i < count ($id); $i++)
            $criteria[] = new EqCriterion ($indexColumns[$i]->name, $id[$i]);

        $list = $this->getPickList ($criteria, -1, NULL, NULL, $idIfNotFound);
        if (!empty ($list))
            {
            foreach ($list as $key => $label)
                return $label;
            }

        if (!$idIfNotFound)
            return NULL;
        return implode (",", $id);
        }

    public function getContentLink ($id)
        {
        if (is_array ($id))
            $id = implode ("_", $id);

        return $this->context->chooseUrl ("content/{$this->getName()}/$id",
                                          "index.php?c=ContentPage&mode=".Constants::MODE_VIEW."&tid={$this->getId()}&id=$id");
        }

    public function getPickList ($criteria = NULL, $limit = -1, $joins = NULL, $params = NULL, $idIfNotFound = true, $includeDescription = false)
        {
        $cacheKey = NULL;
        if (NULL === $criteria && NULL === $joins && NULL === $params)
            $cacheKey = "picklist{$limit}_{$idIfNotFound}_{$includeDescription}";

        $cache = Cache::getInstance ($this->getName (), 6*60*60);
    
        if (empty ($cacheKey) || false === ($ret = $cache->get ($cacheKey)))
            {
            $ret = $this->getPickListNoCache ($criteria, $limit, $joins, $params, $idIfNotFound, $includeDescription);

            if (!empty ($cacheKey))
                $cache->save ($ret, $cacheKey);
            }

        return $ret;
        }

    protected function getPickListNoCache ($criteria = NULL, $limit = -1, $joins = NULL, $params = NULL, $idIfNotFound = true, $includeDescription = false)
        {
        $this->initializeColumns();
        $displayNameColumn = empty ($this->displayNameColumn) ? NULL : $this->displayNameColumn->columnDef;

        $indexColumns = $this->getPrimaryIndexColumns ();
        $resultColumn = array ();
        foreach ($indexColumns as $col)
            $resultColumns[] = $col->name;

        $displayNameColumns = $this->getDisplayNameColumns ($displayNameColumn);
        if (!empty ($displayNameColumns))
           $resultColumns = array_merge ($resultColumns, $displayNameColumns);

        $column = $this->findColumn ("description");
        if (!empty ($column))
           $resultColumns[] = "description";
           
        if ($limit > 0)
            $params[] = new LimitResults (0, $limit);
        $query = $this->createDisplayNameQuery (NULL, $resultColumns, $criteria, $displayNameColumn, $joins, $params);

        $rows = $this->executeQuery ($query, $params);
        if (empty ($rows))
            return $rows;

        $result = array ();
        foreach ($rows as $row)
            {
            $id = array();
            foreach ($indexColumns as $indexColumn)
                {
                $id[] = $row[$indexColumn->name];
                }

            $label = NULL;
            if (isset ($row[self::COL_DISPLAY_NAME]))
                $label = $row[self::COL_DISPLAY_NAME];
            if (empty ($label) && $idIfNotFound)
                $label = "(".implode (", ", $id).")";
                
            if ($includeDescription)
                $result[implode ("_", $id)] = array ($label, $this->getInstanceDescription ($row, false));
            else
                $result[implode ("_", $id)] = $label;
            }

        return $result;
        }

    public function getLabel ()
        {
        return empty ($this->label) ? $this->name : $this->label;
        }

    public function getDescription ()
        {
        return empty ($this->description) ? $this->getLabel () : $this->description;
        }

    public function getName ()
        {
        return $this->name;
        }

    public function getId ()
        {
        return $this->tableId;
        }

    /*
        First check if column "meta" is in the table. If there is such column,
        use its value as description.
        Otherwise try composing description from display name and "description" column
    */
    public function getInstanceDescription ($row, $includeLabel = true)
        {
        $column = $this->findColumn ("meta");
        if (!empty ($column) && $column instanceof ValueColumn && isset ($row[$column->columnDef->name]))
            {
            return $row[$column->columnDef->name];
            }

        $column = $this->findColumn ("description");
        if (empty ($column) || !$column instanceof ValueColumn)
            return NULL;
        if (isset ($row[$column->columnDef->name]))
            {
            $name = $this->getDisplayName ($row, false);
            if ($includeLabel && !empty ($name))
                return $this->getText ("[_0]. [_1]|meta description", $name, htmlspecialchars ($row[$column->columnDef->name]));
            return $row[$column->columnDef->name];
            }
        return NULL;
        }

    public function getParentTable ()
        {
        return $this->parentTable;
        }

    public function getChildTables ()
        {
        $criterion = new EqCriterion (MetaDataTables::COL_PARENTID, $this->tableId);
        $rows = self::selectMetatables ($this->context, $criterion);

        if (!$rows)
            return false;

        $result = array ();
        foreach ($rows as $row)
            $result[] = self::createHandler ($this->context, $row);
        
        return $result;
        }

    public static function prepareUserColumnName ($col)
        {
        return self::PREFIX.$col;
        }

    protected function getDisplayNameColumns ($displayNameColumn)
        {
        if (empty ($displayNameColumn))
            return array ();
        return array ($displayNameColumn->name);
        }

    public function createDisplayNameSubQuery ($name, $idColumns, $columns = NULL)
        {
        $this->initializeColumns ();

        if (!$this->isCreated)
            return NULL; // if no display name, do not bother with joins

        $displayNameColumn = NULL;
        if (!empty ($this->displayNameColumn))
            $displayNameColumn = $this->displayNameColumn->columnDef;

        $joinCriteria = array ();
        $primaryIndex = $this->getPrimaryIndexColumns ();
        if (count ($primaryIndex) != count ($idColumns))
            {
            $this->context->addError ("Incorrect related value criteria formed");
            return false;
            }
        for ($i = 0; $i < count ($primaryIndex) && $i < count ($idColumns); $i++)
            $joinCriteria[] = new JoinColumnsCriterion ($idColumns[$i]->name, $primaryIndex[$i]->name);

        $resultColumns = $this->getDisplayNameColumns ($displayNameColumn);
        if (!empty ($columns))
            {
            $resultColumns = array_merge ($resultColumns, $columns);
            }

        return $this->createDisplayNameQuery ($name, $resultColumns, $joinCriteria, $displayNameColumn);
        }

    public function createQueryWithDisplayName ($resultColumns, $criteria, $joins = NULL, $params = NULL)
        {
        if (NULL === $resultColumns)
            $resultColumns = $this->getAllResultColumns ();

        $this->initializeColumns ();

        if (!$this->isCreated)
            return NULL; // if no display name, do not bother with joins

        $displayNameColumn = NULL;
        if (!empty ($this->displayNameColumn))
            $displayNameColumn = $this->displayNameColumn->columnDef;

        $resultColumns = array_merge ($resultColumns, $this->getDisplayNameColumns ($displayNameColumn));
        return $this->createDisplayNameQuery ("", $resultColumns, $criteria, $displayNameColumn, $joins, $params);
        }

    public function selectWithDisplayName ($resultColumns, $criteria, $joins = NULL, $params = NULL)
        {
        $query = $this->createQueryWithDisplayName ($resultColumns, $criteria, $joins, $params);
        if (empty ($query))
            return false;
        
        return $this->executeQuery ($query, $params);
        }

    public function createDisplayNameQuery ($name, $resultColumns, $criteria, $displayNameColumn, $joins = NULL, $params = NULL)
        {
        if (empty ($this->sortColumns) && !empty ($displayNameColumn) && !$displayNameColumn instanceof GhostColumn)
            $params[] = new OrderBy (array ($displayNameColumn->name));

        $join = $this->createQuery ($resultColumns, $criteria, $joins, $params, $name);
        if (empty ($join))
            return $join;

        $join->joinType = Constants::JOIN_LEFT_OUTER;
        if (NULL != $displayNameColumn && self::COL_DISPLAY_NAME != $displayNameColumn->name)
            {
            if (isset ($join->transformations[$displayNameColumn->name]))
                $transform = $join->transformations[$displayNameColumn->name];
            else
                {
                $lngJoin = $join->getTranslatableColumnSubquery ();
                if (!empty ($lngJoin) && isset ($lngJoin->transformations[$displayNameColumn->name]))
                    $transform = $lngJoin->transformations[$displayNameColumn->name];
                else
                    $transform = new ValueTransformation ($displayNameColumn->name);
                }
            $join->transformations[self::COL_DISPLAY_NAME] = $transform;
            }

        return $join;
        }

    public function createQuery ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL, $tableAlias = NULL)
        {
        if (!$this->isCreated)
            {
            $this->log ("Creating table $this->name");
            if (false === $this->createTable())
                return false;
            }

        if (NULL === $resultColumns)
            $resultColumns = $this->getAllResultColumns ();
        $resultColumns = $this->preprocessResultColumns ($tableAlias, $resultColumns, $transformations, $joinedQueries);
        $this->preprocessCriteria ($criteria, $joinedQueries, $queryParams);
        $query = parent::createQuery ($resultColumns, $criteria, $joinedQueries, $queryParams, $tableAlias);
        if (!empty ($transformations))
            $query->transformations = array_merge ($query->transformations, $transformations);

        return $query;
        }

    protected function preprocessQuery ($tableAlias, &$resultColumns, &$criteria, &$joins, &$queryParams, $namesToColumns)
        {
        parent::preprocessQuery ($tableAlias, $resultColumns, $criteria, $joins, $queryParams, $namesToColumns);
        $this->preprocessQueryParams ($tableAlias, $resultColumns, $criteria, $joins, $queryParams, $namesToColumns);
        }

    public function createRelatedColumnQuery ($tableAlias, $name, &$resultColumns, &$transformations, $columnToSelect, &$joinedQueries)
        {
        $this->selectColumns ();
        if (!isset ($this->relatedColumns[$name]) && Constants::PARENT != $name)
            return false;

        if (!empty ($tableAlias))
            $tablePrefix = $tableAlias.".".$name;
        else
            $tablePrefix = $name;

        if (Constants::PARENT == $name)
            {
            $name = Constants::PARENT;
            $relatedTable = $this->getParentTable ();
            if (empty ($relatedTable))
                {
                $this->context->addMessage ("Table parent not found");
                return false;
                }
            $idColumns = $relatedTable->getPrimaryIndexColumns ();
            }
        else
            {
            $relatedTableId = $this->relatedColumnToTableId[$name];
            $relatedTable = ContentTable::createInstanceById ($this->context, $relatedTableId);
            $idColumns = $this->relatedColumns[$name];
            }

        if (empty ($relatedTable))
            {
            $this->context->addMessage ("Related table not found (for column [_0])", $name);
            return false;
            }

        $subquery = NULL;

        if (!empty ($joinedQueries))
            {
            foreach ($joinedQueries as $join)
                {
                if (!empty ($join->displayNameSubqueryFor) && $join->displayNameSubqueryFor == $name)
                    {
                    $subquery = $join;
                    break;
                    }
                }
            }

        if (empty ($subquery))
            {
            // remove related column values, replacing with foreign key column values
            for ($i = 0; $i < count ($idColumns); $i++)
                $resultColumns[] = $idColumns[$i]->name;
            $transformations[$name] = new RelatedColumnValueTransformation ($name, $idColumns);

            $additional = NULL;
            if (!empty ($columnToSelect))
                $additional = array ($columnToSelect);
            $subquery = $relatedTable->createDisplayNameSubQuery ($tablePrefix, $idColumns, $additional);
            if (!empty ($subquery))
                $joinedQueries[] = $subquery;
            $subquery->displayNameSubqueryFor = $name;
            }

        if (!empty ($tableAlias))
            $tablePrefix = $tableAlias.".";
        else
            $tablePrefix = "";

        if (empty ($columnToSelect))
            return $tablePrefix.$name.".".self::COL_DISPLAY_NAME;

        $key = $relatedTable->createRelatedColumnQuery ($tablePrefix.$name, $columnToSelect,
                                                        $columns, $subquery->transformations,
                                                        NULL, $subquery->joinedQueries);
        if (false !== $key)
            return $key;

        $column = $relatedTable->findColumn ($columnToSelect);
        if (empty ($column))
            return $tablePrefix.$name;

        $colName = $columnToSelect;
        if ($column instanceof ValueColumn)
            $colName = $column->columnDef->name;

        return $tablePrefix.$name.".".$colName;
        }

    protected function preprocessResultColumns ($tableAlias, $resultColumns, &$transformations, &$joinedQueries)
        {
        if (empty ($resultColumns))
            return array ();

        if (empty ($transformations))
            $transformations = array ();

        $preprocessedResultColumns = array ();

        foreach ($resultColumns as $col)
            {
            $name = ($col instanceof Column) ? $col->name : $col;

            $parts = explode (".", $name, 2);
            if (2 == count ($parts))
                {
                $name = $parts[0];
                $relatedColumn = $parts[1];
                }
            else
                $relatedColumn = NULL;

            if ($this->createRelatedColumnQuery ($tableAlias, $name,
                                                 $preprocessedResultColumns,
                                                 $transformations, $relatedColumn, $joinedQueries))
                {
                continue;
                }

            $foundColumn = $this->findColumn ($name);
            if (!empty ($foundColumn))
                {
                if ($col instanceof Column)
                    {
                    $col = clone $col;
                    $col->name = $foundColumn->columnDef->name;
                    }
                else
                    $col = $foundColumn->columnDef->name;
                }

            $preprocessedResultColumns[] = $col;
            }

        return $preprocessedResultColumns;
        }

    protected function preprocessCriteria (&$criteria, &$joins, &$queryParams)
        {
        if (!empty ($queryParams))
            {
            foreach ($queryParams as $key => $param)
                {
                if ($param instanceof FilterCriterion)
                    {
                    if (false === $this->filterColumn->prepareQuery ($param, $criteria, $joins, $queryParams))
                        $criteria[] = new InvalidCriteria ();
                    }
                }
            }

        if (empty ($criteria))
            return ;

        $preprocessedCriteria = array ();
        foreach ($criteria as $criterion)
            {
            // replacing id arrays with correct columns
            $processed = $this->preprocessSingleCriterion ($criterion);
            $preprocessedCriteria[] = $processed;
            }

        $criteria = $preprocessedCriteria;
        }

    protected function preprocessQueryParams ($tableAlias, &$resultColumns, &$criteria, &$joinedQueries, &$queryParams, $namesToColumns)
        {
        $initialParams = $queryParams;
        $columns = array ();

        // collect explicitly set order by columns, if any
        if (!empty ($initialParams))
            {
            foreach ($initialParams as $key => $param)
                {
                if ($param instanceof OrderBy)
                    {
                    $columns = array_merge ($columns, $param->columns);
                    unset ($queryParams[$key]);
                    }
                }
            }

        // use default sort order if no explicit order
        if (empty ($columns))
            $columns = $this->sortColumns;

        if (empty ($columns))
            return;

        // collect all related column subqueries - if query is meant to be used
        // in sorting, its orderBy column priorities should be altered, otherwise
        // default subquery ordering should be cleared
        $relatedColumnQueries = array ();
        if (!empty ($joinedQueries))
            {
            foreach ($joinedQueries as $subquery)
                {
                if (!empty ($subquery->displayNameSubqueryFor))
                    $relatedColumnQueries[$subquery->displayNameSubqueryFor] = $subquery;
                }
            }

        $orderedColumns = array ();
        foreach ($columns as $orderColumn)
            $orderedColumns[$orderColumn->priority] = $orderColumn;

        ksort ($orderedColumns);
        $currentPriority = 1;
        $directColumns = array ();
        $sortedJoins = array ();

        // alter order recursively
        foreach ($orderedColumns as $priority => $orderColumn)
            {
            if (isset ($this->relatedColumns[$orderColumn->name]) || Constants::PARENT == $orderColumn->name)
                {
                if (!isset ($relatedColumnQueries[$orderColumn->name]))
                    continue;

                $this->log ("Transforming sort column $orderColumn->name into sorted join");
                // order by related column
                $subquery = $relatedColumnQueries[$orderColumn->name];
                unset ($relatedColumnQueries[$orderColumn->name]);
                $sortedJoins[] = $orderColumn->name;

                $orderBy = $subquery->getOrderByColumns (true);
                $ordered = array ();
                foreach ($orderBy as $col)
                    $ordered[$col->priority] = $col;

                ksort ($ordered);
                foreach ($ordered as $p => $col)
                    $col->priority = $currentPriority++;
                }
            else
                {
                $orderColumn = clone $orderColumn;
                $orderColumn->priority = $currentPriority++;
                $directColumns[] = $orderColumn;
                }
            }

        // if related columns were not mentioned in sort order, remove subquery ordering
        if (!empty ($joinedQueries))
            {
            foreach ($joinedQueries as $subquery)
                {
                if (!empty ($subquery->displayNameSubqueryFor) &&
                    false !== array_search ($subquery->displayNameSubqueryFor, $sortedJoins))
                    {
                    continue;
                    }

                if (!method_exists ($subquery, "clearOrderBy"))
                    continue;

                $this->log ("Clearing sort order for inner join ($subquery->table $subquery->tableAlias)");
                $subquery->clearOrderBy (true);
                }
            }

        $queryParams[] = new OrderBy ($directColumns);
        }

    protected function preprocessSingleCriterion ($criterion)
        {
        if ($criterion instanceof EqCriterion || $criterion instanceof IsNullCriterion)
            {
            if (!isset ($this->relatedColumns[$criterion->field]))
                {
                $col = $this->findColumn ($criterion->field);
                if (!empty ($col) && isset ($col->columnDef))
                    {
                    $c = clone $criterion;
                    $c->field = $col->columnDef->name;
                    return $c;
                    }

                return $criterion;
                }

            $idColumns = $this->relatedColumns[$criterion->field];
            $criteria = array();
            if ($criterion instanceof IsNullCriterion)
                {
                for ($i = 0; $i < count ($idColumns); $i++)
                    $criteria[] = new IsNullCriterion ($idColumns[$i]->name);
                }
            else if (empty ($criterion->value))
                {
                for ($i = 0; $i < count ($idColumns); $i++)
                    $criteria[] = new EqCriterion ($idColumns[$i]->name, 0);
                }
            else
                {
                if (is_numeric ($criterion->value))
                    $criterion->value = array ($criterion->value);

                for ($i = 0; $i < count ($idColumns) && $i < count ($criterion->value); $i++)
                    $criteria[] = new EqCriterion ($idColumns[$i]->name, $criterion->value[$i]);
                }

            if (count ($criteria) > 0)
                return new LogicalOperatorAnd ($criteria);
            return $criteria;
            }
        else if ($criterion instanceof LogicalOperator)
            {
            $parts = array ();
            foreach ($criterion->parts as $part)
                $parts[] = $this->preprocessSingleCriterion ($part);
            $criterion->parts = $parts;
            return $criterion;
            }

        if ($criterion instanceof SimpleCriterion && isset ($this->relatedColumns[$criterion->field]))
            $this->log ("Related criteria of type ".get_class ($criterion)." not supported yet");

        return $criterion;
        }

    public function getTriggeredColumns ($namesToValues)
        {
        $updatedColumns = array_keys ($namesToValues);
        $allColumns = $this->getColumns ();
        $translatableColumns = $this->getTranslatableColumns ();
        if (!empty ($translatableColumns))
            {
            $allColumns = array_merge ($allColumns, $translatableColumns);
            }

        $triggeredFields = array ();
        for ($i = 0; $i < count ($allColumns); $i++)
            {
            $col = $allColumns[$i];
            if (isset ($col->triggeredBy) && !empty ($col->triggeredBy))
                {
                foreach ($col->triggeredBy as $trigger)
                    {
                    if (false !== array_search ($trigger, $updatedColumns))
                        {
                        $triggeredFields[] = $col;
                        break;
                        }
                    }
                }
            }
        return $triggeredFields;
        }

    public function preprocessModifiedValues ($nameToValue)
        {
        $preprocessedValues = array ();
        foreach ($nameToValue as $name => $value)
            {
            if (isset ($this->relatedColumns[$name]))
                {
                // remove related column values, replacing with foreign key column values
                $idColumns = $this->relatedColumns[$name];
                if (NULL === $value)
                    {
                    for ($i = 0; $i < count ($idColumns); $i++)
                        $preprocessedValues[$idColumns[$i]->name] = NULL;
                    }

                if (!is_array ($value))
                    $value = explode ("_", $value);

                for ($i = 0; $i < count ($idColumns) && $i < count ($value); $i++)
                    $preprocessedValues[$idColumns[$i]->name] = $value[$i];
                }
            else
                {
                $col = $this->findColumn ($name);
                if (!empty ($col))
                    $name = $col->columnDef->name;
                    
                $preprocessedValues[$name] = $value;
                }
            }

        return $preprocessedValues;
        }

    public function moveRecord ($id, $newParent)
        {
        if (NULL == $this->parentTable)
            return false;

        $filterBy = array ();
        $oldCriteria = NULL;
        $parentId = $newParent;
        $oldId = $id;
        foreach ($this->parentTable->getPrimaryIndexColumns () as $idColumn)
            {
            $filterBy[$idColumn->name] = array_shift ($parentId);
            $oldCriteria[] = new EqCriterion ($idColumn->name, array_shift ($oldId));
            }

        $oldCriteria[] = new EqCriterion ($this->getIdColumn (), array_shift ($oldId));

        $val = $this->getNextColumnValue ($this->getIdColumn (), $filterBy);
        $nameToValue[$this->getIdColumn ()] = $val;
 
        $currentValues = $this->selectSingleBy (NULL, $oldCriteria);
        $newValues = array_merge ($currentValues, $filterBy);
        $newValues[$this->getIdColumn ()] = $val;
        
        foreach (array (DBTable::COL_UPDATEDON, DBTable::COL_UPDATEDBY, DBTable::COL_CREATEDON, DBTable::COL_CREATEDBY,
                        DBTable::COL_SOURCE, DBTable::COL_SOURCEDATE, ContentTable::COL_DISPLAY_NAME, ContentTable::COL_SECTION) as $colName)
            {
            unset ($newValues[$colName]);
            }

        if ($this->tracksSources)
            $newValues[DBTable::COL_SOURCE] = $this->getText ("Record moved");

        $newId = $this->insertRecord ($newValues);
        if (false === $newId)
            return false;

        if ($this->tracksRevisions)
            {
            $updatedValues = array ();
            $newIdCopy = $newId;
            foreach ($this->getPrimaryIndexColumns () as $idColumn)
                {
                $updatedValues[$idColumn->name] = array_shift ($newIdCopy);
                }

            $dbconnection = $this->context->getConnection ();
            if (false === $dbconnection->updateRecord ($this->getRevisionTableName (), $oldCriteria, $updatedValues))
                return false;
            }

        if (!$this->deleteBy ($oldCriteria, true))
            return false;

        return $newId;
        }

    public function insertRecord ($nameToValue)
        {
        if (!$this->isCreated && false === $this->createTable())
            return false;

        $triggeredColumns = $this->getTriggeredColumns ($nameToValue);
        for ($i = 0; $i < count ($triggeredColumns); $i++)
            {
            $nameToValue[$triggeredColumns[$i]->name] = $triggeredColumns[$i]->calculateValue ($this->context, NULL, $nameToValue);
            }

        $id = NULL;
        if (NULL != $this->parentTable)
            {
            $filterBy = array ();
            $id = array ();
            foreach ($this->parentTable->getPrimaryIndexColumns () as $idColumn)
                {
                $filterBy[$idColumn->name] = $nameToValue[$idColumn->name];
                $id[] = $nameToValue[$idColumn->name];
                }

            $val = $this->getNextColumnValue ($this->getIdColumn (), $filterBy);
            $nameToValue[$this->getIdColumn ()] = $val;
            $id[] = $val;
            }

        // find related columns as ids should be mapped to physical columns
        $values = $this->preprocessModifiedValues ($nameToValue);
        $ret = parent::insertRecord ($values);
        $this->cleanCache ();

        $this->rememberLastSource ($nameToValue);

        if (false === $ret || empty ($id))
            return $ret;

        return $id;
        }

    protected function rememberLastSource ($nameToValue)
        {
        $cookieName = "lastsrc_".$this->getName ();

        if (!empty ($nameToValue[DBTable::COL_SOURCE]))
            {
            // if non url was provided as source, suggest it for succeeding edits
            $sources = $nameToValue[DBTable::COL_SOURCE];
            $this->context->setCookie ($cookieName, $sources, 60*60*24*10);
            }
        else
            $this->context->deleteCookie ($cookieName);
        }

    public function cleanCache ()
        {
        $cache = Cache::getInstance ($this->getName (), 6*60*60);
        $cache->clean ();
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = 1)
        {
        $this->cleanCache ();

        $triggeredColumns = $this->getTriggeredColumns ($nameToValue);
        foreach ($triggeredColumns as $col)
            {
            if ($col instanceof GhostColumn)
                continue;
            $nameToValue[$col->name] = $col->calculateValue (NULL, $nameToValue);
            }

        $this->rememberLastSource ($nameToValue);

        $joins = NULL;
        $params = NULL;
        $this->preprocessCriteria ($criteria, $joins, $params);
        return parent::updateRecord ($criteria, $this->preprocessModifiedValues ($nameToValue), $maxRows);
        }

    protected function deleteBy ($criteria, $deleteTranslatable = false)
        {
        $this->cleanCache ();
        $joins = NULL;
        $params = NULL;
        $this->preprocessCriteria ($criteria, $joins, $params);
        return parent::deleteBy ($criteria, $deleteTranslatable);
        }

    public function removeEntry ($criteria)
        {
        if ($this->ownerDeleteAllowed)
            return $this->deleteBy ($criteria, false);
        else
            return false;
        }

    public function tableExists ()
        {
        return $this->isCreated;
        }

    public function createTable ()
        {
        if (!parent::tableExists ())
            {
            $this->log ("Creating content table \"$this->tablename\"");
            if (false === parent::forceCreateTable ())
                return false;
            }

        $meta = new MetaDataTables ($this->context);
        if (false === $meta->updateTableIsCreated ($this->tableId, true))
            return false;

        $this->isCreated = true;
        return true;
        }

    public function deleteTable ($doNotUpdateMeta = false)
        {
        if (parent::tableExists ())
            {
            $this->log ("Deleting content table \"$this->tablename\"");
            if (false === $this->removeRelatedValues () ||
                false === parent::dropTable (Constants::TABLES_META, MetaDataTables::TABLE_NAME))
                {
                return false;
                }
            }

        if ($doNotUpdateMeta)
            return true;

        $meta = new MetaDataTables ($this->context);
        if (false === $meta->updateTableIsCreated ($this->tableId, false))
            return false;

        $this->isCreated = false;
        $this->allColumns = NULL;
        return true;
        }

    public function deleteById ($criteria)
        {
        if (is_numeric ($criteria))
            $ids = array ($criteria);
        else
            {
            $ids = array ();
            foreach ($criteria as $criterion)
                {
                if (is_numeric ($criterion))
                    $ids[] = $criterion;
                else
                    $ids[] = $criterion->value;
                }
            }

        // ensure that there are no existing child records left
        $childTablesToClean = array ();
        $childtables = $this->getChildTables ();
        if (!empty ($childtables))
            {
            $parentCriteria = array ();
            $cols = $this->getPrimaryIndexColumns ();

            for ($c = 0; $c < count ($cols) && $c < count ($ids); $c++)
                $parentCriteria[] = new EqCriterion ($cols[$c]->name, $ids[$c]);
            
            foreach ($childtables as $childTable)
                {
                $rows = $childTable->selectBy (array (), $parentCriteria);
                if (!empty ($rows))
                    {
                    $childTablesToClean[] = $childTable;
                    if (!$childTable->canDelete ())
                        {
                        $this->context->addError ("Cannot remove the record which contains child records. Please remove child records first. ([_0])", $childTable->getName ());
                        return false;
                        }
                    }
                }
            }

        if (false === $this->canRemoveRelatedValues ($ids))
            {
            $this->context->addError ("Cannot remove the record as it is used in the related record and value can only be changed manually.");
            return false;
            }
            
        if (false === $this->removeRelatedValues ($ids))
            return false;

        foreach ($childTablesToClean as $childTable)
            {
            if (false === $childTable->deleteBy ($criteria))
                return false;
            }

        if (false === parent::deleteById ($criteria))
            return false;

        return true;
        }

    protected function findRelatedColumns ($resultColumns, $joins)
        {
        $metaColumnsHandler = new MetaDataColumns ($this->context);
        $criteria = array ();
        $criteria[] = new EqCriterion (MetaDataColumns::COL_ISRELATION, true);
        $criteria[] = new EqCriterion (MetaDataColumns::COL_RELATEDTABLEID, $this->tableId);
        return $metaColumnsHandler->selectBy ($resultColumns, $criteria, $joins);
        }

    public function getRelatedTables ()
        {
        $columnProperties = array
            (
            MetaDataColumns::COL_TABLEID,
            MetaDataColumns::COL_COLUMNID,
            );

        $relatedColumns = $this->findRelatedColumns ($columnProperties, NULL);

        if (false === $relatedColumns)
            return false;

        if (empty ($relatedColumns))
            return NULL;

        $tableIds = array ();
        foreach ($relatedColumns as $column)
            $tableIds[] = $column[MetaDataColumns::COL_TABLEID];

        $tableIds = array_unique ($tableIds);
        $criterion = new InCriterion (MetaDataTables::COL_TABLEID, $tableIds);
        $rows = self::selectMetatables ($this->context, $criterion);

        if (!$rows)
            return false;

        $result = array ();
        foreach ($rows as $row)
            {
            $table = self::createHandler ($this->context, $row);
            $cols = array ();

            foreach ($table->selectColumns () as $column)
                {
                if (!$column instanceof RelationColumn ||
                    $this->tableId != $column->relatedTableId)
                    {
                    continue;
                    }

                $cols[] = $column;
                }

            $result[] = array ($table, $cols);
            }
        
        return $result;
        }

    protected function canRemoveRelatedValues ($valueIds = NULL)
        {
        $relatedColumns = $this->getRelatedTables ();
        if (false === $relatedColumns)
            return false;

        if (empty ($relatedColumns))
            return true;

        $ret = true;
        foreach ($relatedColumns as $pair)
            {
            list ($table, $columns) = $pair;

            foreach ($columns as $col)
                {
                if (!$col->required)
                    continue;

                $criteria = array (new EqCriterion ($col->name, $valueIds));
                $affected = $table->selectBy (array (), $criteria);
                if (false === $affected || $affected > 0)
                    return false;
                }
            }

        return $ret;
        }

    protected function removeRelatedValues ($valueIds = NULL)
        {
        $relatedColumns = $this->getRelatedTables ();

        if (false === $relatedColumns)
            return false;

        if (empty ($relatedColumns))
            return true;

        $ret = true;
        foreach ($relatedColumns as $pair)
            {
            list ($table, $columns) = $pair;
            
            $criteria = array ();
            foreach ($columns as $col)
                {
                $criteria = array (new EqCriterion ($col->name, $valueIds));
                $nameToValue = array ($col->name => NULL);
                $nameToValue[DBTable::COL_SOURCE] = $this->getText ("Related record removed");
                $nameToValue[DBTable::COL_SOURCEDATE] = NULL;
                $affected = $table->updateRecord ($criteria, $nameToValue, NULL);
                if (false === $affected)
                    {
                    $this->context->addError ("Error updating related records");
                    $ret = false;
                    }
                }
            }

        return $ret;
        }

    public function selectBy ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL, $tableAlias = NULL)
        {
        if (!$this->isCreated)
            return NULL;
        return parent::selectBy ($resultColumns, $criteria, $joinedQueries, $queryParams, $tableAlias);
        }
 
    public function selectSingleBy ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL)
        {
        if (!$this->isCreated)
            return NULL;
        return parent::selectSingleBy ($resultColumns, $criteria, $joinedQueries, $queryParams);
        }

    public function removeColumnById ($columnId)
        {
        $columns = $this->selectColumns ();
        $namesToRemove = NULL;
        foreach ($columns as $col)
            {
            if ($col->id == $columnId)
                {
                if ($col instanceof ValueColumn)
                    {
                    $namesToRemove[] = $col->columnDef->name;
                    if ($col->columnDef instanceof CompositeColumn)
                        {
                        $this->allColumns = NULL;
                        return true;
                        }
                    break;
                    }

                $relatedTableId = $col->relatedTableId;
                $idColumns = $this->getForeignKeyColumns ($col->name, $col->required, $relatedTableId);
                foreach ($idColumns as $coldef)
                    $namesToRemove[] = $coldef->name;
                break;
                }
            }
        if (!empty ($namesToRemove))
            {
            $success = true;
            foreach ($namesToRemove as $name)
                $success = $success && parent::dropColumn ($name);

            $this->allColumns = NULL;
            return $success;
            }

        $this->log ("Column not found in the table");
        return false;
        }

    public function addColumn ($column)
        {
        $metacolumns = new MetaDataColumns ($this->context);
        $row = $metacolumns->selectSingleBy (array (new FunctionMax (MetaDataColumns::COL_COLUMNID, "maxCol")),
                                             array (new EqCriterion (MetaDataColumns::COL_TABLEID, $this->tableId)) );
        if (false === $row)
            return false;

        $id = array ($this->tableId, $row["maxCol"]+1);
        if (false === $metacolumns->create ($this->tableId, $row["maxCol"]+1, $column))
            return false;

        $tableExists = $this->tableExists ();
        if (!$tableExists)
            return $id;

        $translatable = $column->translatable ? true : false;
        $this->allColumns = NULL; // cached list no longer valid

        if ($column instanceof ValueColumn)
            {
            $coldef = $column->columnDef;
            if (!$coldef instanceof CompositeColumn)
                {
                $coldef->name = self::prepareUserColumnName ($coldef->name);
                if (false === parent::addColumnToTable ($coldef, $translatable))
                    return false;
                }

            return $id;
            }

        // create id columns for related table
        $relatedTableId = $column->relatedTableId;
        $idColumns = $this->getForeignKeyColumns ($column->name, $column->required, $relatedTableId);
        foreach ($idColumns as $coldef)
            {
            if (false === parent::addColumnToTable ($coldef, false))
                return false;
            }

        return $id;
        }

    public function preprocessIndex ($initialIndex)
        {
        $index = clone $initialIndex;
        $index->columns = array ();
        $hasTranslatable = false;
        $hasNonTranslatable = false;

        foreach ($initialIndex->columns as $col)
            {
            if (isset ($this->relatedColumns[$col]))
                {
                // add id columns
                $idColumns = $this->relatedColumns[$col];
                foreach ($idColumns as $idcolumn)
                    $index->columns[] = $idcolumn->name;
                continue;
                }

            $column = $this->findColumn ($col);
            if (empty ($column))
                {
                $this->context->addError ("Index column [_0] does not exist in the table.", $col);
                return false;
                }

            if ($column->translatable)
                $hasTranslatable = true;
            else
                $hasNonTranslatable = true;

            $index->columns[] = self::prepareUserColumnName ($col);
            }

        if ($hasTranslatable && $hasNonTranslatable)
            {
            $this->context->addError ("Translatable columns cannot be mixed with non translatable columns in the index.");
            return false;
            }

        $index->translatableTable = $hasTranslatable;
        return $index;
        }

    public function isIndexValid ($index)
        {
        $index = $this->preprocessIndex ($index);
        return false !== $index;
        }

    public function addIndex ($index)
        {
        $index = $this->preprocessIndex ($index);
        if (false === $index)
            return false;

        if (!$this->isCreated)
            return true; // will be created with the table

        return $this->addTableIndex ($index);
        }

    public function removeIndex ($indexName)
        {
        if (!$this->isCreated)
            return true; // will be created with the table

        $index = $this->findIndex ($indexName);
        if (false === $index)
            {
            $this->context->addError ("Index does not exist in the table");
            return false;
            }

        return $this->dropTableIndex ($this->preprocessIndex ($index));
        }

    public function getDisplayNameColumnName ()
        {
        if (empty ($this->displayNameColumn))
            return NULL;
        return $this->displayNameColumn->columnDef->name;
        }

    protected function selectForIndexing ($columns, $ids)
        {
        $criteria[] = new InCriterion ($this->getIdColumn (), $ids);
        return $this->selectWithDisplayName ($columns, $criteria);
        }

    public function selectChangedRowsForIndexing ($dateFrom, $selectFromIndex, $limit)
        {
        $params[] = new LimitResults ($selectFromIndex, $selectFromIndex + $limit);
        $params[] = new SelectRevisions ();
        $params[] = OrderBy::create (DBTable::COL_UPDATEDON, DBTable::COL_REVISIONID);
        $criteria = array ();
        $indexColumns = $this->getPrimaryIndexColumns ();
        $columns = array (DBTable::COL_UPDATEDON, DBTable::COL_REVISIONID);
        foreach ($indexColumns as $col)
            $columns[] = $col->name;

        if (!empty ($dateFrom))
            {
            $criteria[] = new GtEqCriterion (DBTable::COL_UPDATEDON, $dateFrom);
            }

        return $this->selectBy ($columns, $criteria, NULL, $params);
        }

    public function extractTextsForIndex ($ids)
        {
        if (NULL != $this->parentTable)
            {
            $this->context->addError ("Child table indexing is not supported yet");
            return false;
            }

        $allRows = $this->selectForIndexing (NULL, $ids);
        if (empty ($allRows))
            return $allRows;

        $extracted = array ();
        foreach ($allRows as $row)
            {
            $id = $row[$this->getIdColumn ()];
            $indexedRow = $this->indexSingleRow ($row);
            if (empty ($indexedRow))
                continue;

            $extracted[$id] = $indexedRow;  
            }

        $this->postprocessIndexedData ($extracted);
        return $extracted;
        }

    protected function postprocessIndexedData (&$extracted)
        {
        }

    protected function indexSingleRow ($row)
        {
        $texts = array ();
        $label = NULL;
        foreach ($row as $key => $val)
            {
            if (empty ($val) || self::COL_SECTION == $key || "f_" == substr ($key, 0, 2) || is_array ($val))
                continue;
            $pos = strpos ($key, ".");
            if (false !== $pos)
                {
                if (ContentTable::COL_DISPLAY_NAME != substr ($key, ++$pos))
                    continue;
                }
            else if ("c_".ContentTable::COL_DISPLAY_NAME == $key)
                $label = $val;
            $texts[] = $val;
            }

        $description = $this->getInstanceDescription ($row, true);
        $lastUpdated = empty ($row[DBTable::COL_UPDATEDON]) || '0' == $row[DBTable::COL_UPDATEDON][0] ? $row[DBTable::COL_CREATEDON] : $row[DBTable::COL_UPDATEDON];
        return array ("label" => $label, "date" => $lastUpdated, "chunks" => $texts, "description" => $description);
        }
    }

<?php

class FileFieldTemplate extends FieldTemplate
    {
    public function __construct ($prefix, $key, $label, $tooltip)
        {
        parent::__construct ($prefix, $key, "file", $label, $tooltip);
        }

    public function getValueForDB ($context, $request, $index = NULL)
        {
        $key = $this->key;
        if (isset ($_FILES[$key]))
            return $_FILES[$key]['name'];
        return $request[$key];
        }

    public function getFilePath ($request, $index = NULL)
        {
        $key = $this->key;
        if (isset ($_FILES[$key]))
            return $_FILES[$key]['tmp_name'];
        return NULL;
        }

    public function getUploadError ($context, $request)
        {
        $key = $this->key;
        if (!isset ($_FILES[$key]) || UPLOAD_ERR_OK == $_FILES[$key]['error'])
            return false;

            
        switch ($_FILES[$key]['error'])
            {
            case UPLOAD_ERR_INI_SIZE:
                return $context->getText ("File exceeds the maximum size defined.");
            }

        return $context->getText ("Upload error");
        }

    }

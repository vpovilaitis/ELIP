<?php

abstract class CreatableDropDownFieldTemplate extends CompositeTemplate
    {
    const NEW_ITEM = "***NEW***";

    public function __construct ($context, $prefix, $key, $label, $tooltip, $picklist)
        {
        $newPicklist = array (self::NEW_ITEM => $context->getText ("Create new"));
        if (!empty ($picklist))
            {
            foreach ($picklist as $name => $val)
                $newPicklist[$name] = $val;
            }

        $subitems = array ();
        $subitems[] = $this->createDropDown ($prefix, $key, $tooltip, $newPicklist);
        $subitems[] = $this->createEditBox ($prefix, $key."_new",
                                            $context->getText ("If creating a new intance, enter a label here."));
        parent::__construct ($prefix, $key, "", $label, $subitems);
        }

    protected function createDropDown ($prefix, $key, $tooltip, $picklist)
        {
        return new DropDownFieldTemplate ($prefix, $key, "", $tooltip, $picklist);
        }

    protected function createEditBox ($prefix, $key, $tooltip)
        {
        $field = new TextFieldTemplate ($prefix, $key, "", $tooltip, 18);
        $field->cssClass = "newentry";
        return $field;
        }

    public function preprocessLoadedValue (&$request, $existingRecord, $index = NULL)
        {
        $dropdown = $this->items[0];
        $dropdown->preprocessLoadedValue ($request, $existingRecord, $index);
        }

    public function processInput ($context, &$request)
        {
        $dropdown = $this->items[0];
        $text = $this->items[1];

        $val = $dropdown->getValueForDB ($context, $request);
        $label = $text->getValueForDB ($context, $request);
        if (self::NEW_ITEM == $val)
            {
            // create new and return an id
            if (empty ($label))
                {
                $context->addError ("Please enter a value for a field [_0]", $this->label);
                return false;
                }

            $id = $this->createItem ($context, $label);
            if (!empty ($id))
                {
                if (is_array ($id))
                    list ($id, $val) = $id;
                else
                    $val = $id;
                $dropdown->addItem ($id, $label);
                $request[$dropdown->key] = $id;
                unset ($request[$text->key]);
                }
            }
        else if (!empty ($label))
            {
            $context->addError ("Value selected and new label entered into the field [_0]", $this->label);
            return false;
            }

        return true;
        }

    public function getValueForDB ($context, $request, $index = NULL)
        {
        $dropdown = $this->items[0];
        $val = $dropdown->getValueForDB ($context, $request, $index);
        return $val;
        }

    public function setPrefix ($prefix)
        {
        parent::setPrefix ($prefix);

        for ($i = 0; $i < count ($this->items); $i++)
            $this->items[$i]->setPrefix ($prefix);
        }

    protected abstract function createItem ($context, $label);
    }

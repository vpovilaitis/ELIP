<?php
require_once (PATH."inc/dbtable.php");

class HintsTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "hint";

    const COL_ID = "hintid";
    const COL_SCOPE = "scope"; // 'pages', 'x_persons', etc
    const COL_CONTEXT = "context"; // view/edit/history/etc
    const COL_CONTEXTID = "contextid";
    const COL_TITLE = "title";
    const COL_DETAILS = "description";
    const COL_TARGETAUDIENCE = "audience"; // target audience

    const CONTEXT_ANY = 0;
    const CONTEXT_VIEW = 1;
    const CONTEXT_PREVIEW = 2;
    const CONTEXT_EDIT = 3;
    const CONTEXT_HISTORY = 4;
    const CONTEXT_DISCUSSION = 5;

    const TARGET_ANY = 0;
    const TARGET_VIEWER = 1;
    const TARGET_EDITOR = 2;

    const SCOPE_PAGES = "pages";
    const SCOPE_CONTENTTABLE = "x_";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        $this->tracksRevisions = true;
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     new TextColumn (self::COL_SCOPE, 128),
                     new IntColumn (self::COL_CONTEXT),
                     new IntColumn (self::COL_TARGETAUDIENCE),
                     new TextColumn (self::COL_CONTEXTID, 32),
                     new TextColumn (DBTable::COL_LANG, 5),
                     new TextColumn (self::COL_TITLE, 256),
                     new LongTextColumn (self::COL_DETAILS, 256, true),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new Index (self::COL_SCOPE, self::COL_CONTEXT, self::COL_CONTEXTID, DBTable::COL_LANG),
            );
        }

    public function insertRecord ($nameToValue)
        {
        $nameToValue[DBTable::COL_LANG] = $this->context->getLanguage ();
        return parent::insertRecord ($nameToValue);
        }

    public function selectHints ($scope, $contextMode, $targetGroup, $contextId)
        {
        $criteria = array (new EqCriterion (self::COL_SCOPE, $scope),
                           new LikeCriterion (DBTable::COL_LANG, $this->context->getLanguage ()));

        if (!empty ($contextMode))
            $criteria[] = new LogicalOperatorOr (new EqCriterion (HintsTable::COL_CONTEXT, $contextMode),
                                                 new EqCriterion (HintsTable::COL_CONTEXT, HintsTable::CONTEXT_ANY));
        else
            $criteria[] = new EqCriterion (HintsTable::COL_CONTEXT, HintsTable::CONTEXT_ANY);

        if (!empty ($targetGroup))
            $criteria[] = new LogicalOperatorOr (new EqCriterion (HintsTable::COL_TARGETAUDIENCE, $targetGroup),
                                                 new EqCriterion (HintsTable::COL_TARGETAUDIENCE, HintsTable::TARGET_ANY));
        else
            $criteria[] = new EqCriterion (HintsTable::COL_TARGETAUDIENCE, HintsTable::TARGET_ANY);

        if (!empty ($contextId))
            $criteria[] = new LogicalOperatorOr (new EqCriterion (HintsTable::COL_CONTEXTID, $contextId),
                                                 new EqCriterion (HintsTable::COL_CONTEXTID, Constants::ANY));
        else
            $criteria[] = new EqCriterion (HintsTable::COL_CONTEXTID, Constants::ANY);
        
        $rows = $this->selectBy (array (self::COL_TITLE, self::COL_DETAILS), $criteria);
        if (empty ($rows))
            return NULL;

        $res = array ();
        foreach ($rows as $row)
            {
            $res[] = array ("title" => $row[self::COL_TITLE], "description" => $row[self::COL_DETAILS]);
            }
        return $res;
        }
    }

class HintContext
    {
    public $elementId;
    public $serviceUrl;
    public $initialText;
    public $loadingText;
    public $alwaysVisible;
    public $listUrlLabel;
    public $listUrl;

    static protected $nextId = 100;

    public function __construct ($context, $serviceUrl, $listUrl)
        {
        $this->elementId = "hint_".self::$nextId++;
        $this->serviceUrl = $serviceUrl;
        $this->initialText = $context->getText ("Hints are currently disabled");
        $this->loadingText = $context->getText ("Preparing a random hint");
        $table = new HintsTable ($context);
        $this->alwaysVisible = $table->canEdit ();
        $this->listUrlLabel = $context->getText ("View all hints");
        $this->listUrl = $listUrl;
        }
    }

<?php

class OpenIdTable extends SecurityTable
    {
    const TABLE_NAME = "openid";

    const USER_ID_COLUMN = "user_id";
    const PROVIDER_COLUMN = "provider";
    const USERNAME_COLUMN = "username";
    const USER_ADDR_COLUMN = "user_addr";
    const USER_AGENT_COLUMN = "user_agent";
    const DISPLAY_NAME_COLUMN = "displayname";
    const LINK_VISIBLE_COLUMN = "link_p";
    const LINK_COLUMN = "link";
    
    private $skipUpdateCheck = false;

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_NAME, false);
        $this->skipAccessChecks = true;
        }

    protected function getColumns ()
        {
        return array (
                     new IntColumn (self::USER_ID_COLUMN, false),
                     new TextColumn (self::PROVIDER_COLUMN, 128, true),
                     new TextColumn (self::USERNAME_COLUMN, 128),
                     new TextColumn (self::DISPLAY_NAME_COLUMN, 128, true),
                     new TextColumn (self::LINK_COLUMN, 256, true),
                     new BoolColumn (self::LINK_VISIBLE_COLUMN, true),
                     new TextColumn (self::USER_ADDR_COLUMN, 128, true),
                     new TextColumn (self::USER_AGENT_COLUMN, 512, true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new UniqueIndex (self::PROVIDER_COLUMN, self::USERNAME_COLUMN));
        }

    public static function getUserId ($context, $provider, $id)
        {
        $provider = strtolower (trim ($provider));
        $id = trim ($id);
        if (empty ($id))
            return false;

        $table = new OpenIdTable ($context);
        $criteria[] = new EqCriterion (self::PROVIDER_COLUMN, $provider);
        $criteria[] = new EqCriterion (self::USERNAME_COLUMN, $id);
        $row = $table->selectSingleBy (array (self::USER_ID_COLUMN, self::DISPLAY_NAME_COLUMN), $criteria);
        if (!empty ($row))
            return $row[self::USER_ID_COLUMN];

        return false;
        }

    public function createUserId ($userId, $provider, $id, $name, $link)
        {
        $context = $this->context;
        $provider = strtolower (trim ($provider));
        $id = trim ($id);
        if (empty ($id) || $userId <= 0)
            return false;

        $values = array (self::USER_ID_COLUMN => $userId, self::PROVIDER_COLUMN => $provider, self::USERNAME_COLUMN => $id);

        if (!empty ($name))
            $values[self::DISPLAY_NAME_COLUMN] = $name;
        if (!empty ($link))
            {
            $values[self::LINK_COLUMN] = $link;
            $values[self::LINK_VISIBLE_COLUMN] = 1;
            }

        if (!empty ($_SERVER["HTTP_USER_AGENT"]))
            $values[self::USER_AGENT_COLUMN] = $_SERVER["HTTP_USER_AGENT"];
        if (!empty ($_SERVER["REMOTE_ADDR"]))
            $values[self::USER_ADDR_COLUMN] = $_SERVER["REMOTE_ADDR"];

        $id = $this->insertRecord ($values);
        return $id;
        }

    public function optout ($userId, $optout)
        {
        $criteria[] = new EqCriterion (OpenIdTable::USER_ID_COLUMN, $userId);
        $this->skipUpdateCheck = true;
        $ret = $this->updateRecord ($criteria, array (OpenIdTable::LINK_VISIBLE_COLUMN => $optout ? 0 : 1));
        $this->skipUpdateCheck = false;
        return $ret;
        }

    public function canEdit ()
        {
        return $this->skipUpdateCheck || parent::canEdit ();
        }

    public function insertRecord ($nameToValue)
        {
        return parent::insertRecord ($nameToValue);
        }

    }
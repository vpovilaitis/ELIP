<?php

class MoreLinkFieldTemplate extends ViewUriFieldTemplate
    {
    protected $text;

    public function __construct ($context, $tableId, $idColumns, $hiddenFields, $prefix)
        {
        parent::__construct ($tableId, $idColumns, $prefix, NULL, $context->getText ("More"));
        $this->text = $context->getText ("more...");
        }

    public function getValueForDisplay ($context, $row)
        {
        return $this->text;
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        return;
        }
    }

class TinyMoreLinkFieldTemplate extends MoreLinkFieldTemplate
    {
    public function getValueForDisplay ($context, $row)
        {
        return "..";
        }
    }

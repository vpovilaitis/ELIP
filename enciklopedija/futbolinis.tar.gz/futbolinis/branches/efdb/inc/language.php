<?php
require_once (PATH.'inc/base.php');

class Language extends BaseWithContext
    {
    protected static $singleton = NULL;

    const CASE_NOMINATIVE = 0;
    const CASE_GENITIVE = 1;
    const CASE_LOCATIVE = 2;
    const CASE_ACCUSATIVE = 3;
    
    public function __construct ($context)
        {
        parent::__construct ($context);
        }

    public static function getInstance ($context)
        {
        if (NULL !== self::$singleton)
            return self::$singleton;

        $lng = $context->getLanguage ();
        $path = PATH."lang/language";
        $ext = ".php";
        if (file_exists ($path.$lng.$ext))
            $file = $path.$lng.$ext;
        else if (file_exists ($path.strtoupper ($context->getLanguageCode ()).$ext))
            $file = $path.strtoupper ($context->getLanguageCode ()).$ext;
        else
            $file = NULL;

        if (NULL != $file)
            {
            require_once ($file);
            $className = "Language".strtoupper ($context->getLanguageCode ());
            if (!class_exists ($className))
                {
                $context->log ("Language handler $className not found in file $file");
                $className = NULL;
                }
            else
                $context->log ("Language handler $className loaded from file $file");
            }
        else
            $context->log ("Language handler not found at $path.$lng.$ext or ".$path.strtoupper ($context->getLanguageCode ()).$ext);

        if (empty ($className))
            $className = "Language";

        self::$singleton = new $className ($context);
        return self::$singleton;
        }

    public function changeWordCase ($word, $case)
        {
        // no declension in default implementation
        return $word;
        }

    public function calculateYearDecade ($year)
        {
        return $year - $year % 10;
        }

    public function getDecadeLabel ($decade)
        {
        return $decade."s";
        }

    public function parseDate ($str)
        {
        $this->log ("Parsing date '$str'");
        if (is_numeric ($str))
            return $str."-00-00";

        $str = trim ($str);
        $parts = preg_split ("/\s+/", $str);

        $time = "";
        if (count ($parts) >= 2 && 1 == preg_match ('/^([0-9]{1,2})[:.]([0-9]{2})([:.][0-9]{2})?$/u', $parts[count ($parts) - 1], $matches))
            {
            $time = " ".$matches[1].":".$matches[2];
            array_pop ($parts);
            $str = implode ("-", $parts);
            }

        $formats = array ("%d-%d-%d", "%d/%d/%d");
        $maxParsedCount = 0;
        $bestFormat = NULL;
        foreach ($formats as $format)
            {
            list ($year, $month, $day) = sscanf ($str, $format);
            $cnt = (isset ($year) ? 1 : 0) + (isset ($month) ? 1 : 0) + (isset ($day) ? 1 : 0);
            if ($cnt > $maxParsedCount)
                {
                $bestFormat = $format;
                $maxParsedCount = $cnt;
                }
            }

        if (NULL === $bestFormat)
            {
            $timestamp = strtotime ($str);
            if (FALSE === $timestamp)
                return NULL;
            return strftime ("%Y-%m-%d", $timestamp);
            }

        list ($year, $month, $day) = sscanf ($str, $bestFormat);

        $result = sprintf ("%d-%02d-%02d", $year, isset ($month) ? $month : 0, isset ($day) ? $day : 0);
        $this->log ("Matched format '$bestFormat', result - '$result$time'");
        return $result.$time;
        }

    public function extractTimeFromDate ($date)
        {
        list ($year, $month, $day, $hour, $minute) = sscanf ($date, "%d-%d-%d %d:%d");
        if (0 == $hour && 0 == $minute)
            return false;

        return sprintf ("%02d:%02d", $hour,$minute);
        }

    public function dateToString ($date, $modifier = NULL)
        {
        if (empty ($date))
            return "";

        if ("long" == $modifier)
            return $this->dateToLongString ($date);

        list ($year, $month, $day) = sscanf ($date, "%d-%d-%d");

        if (empty ($year))
            return "";

        $str = $year;
        if ("year" == $modifier)
            return $str;

        if (isset ($month) && $month > 0)
            $str .= sprintf ("/%02d", $month);

        if (0 === strcmp ("month", $modifier))
            return $str;

        if (isset ($day) && $day > 0)
            $str .= sprintf ("/%02d", $day);

        return $str;
        }

    public function dateToLongString ($date)
        {
        return $this->dateToString ($date);
        }

    public function parseDateTime ($str)
        {
        $timestamp = strtotime ($str);
        if (FALSE === $timestamp)
            return NULL;
        return strftime ("%Y-%m-%d %T", $timestamp);
        }

    protected function getRelativeDayLabel ($relativeDayFromToday)
        {
        switch ($relativeDayFromToday)
            {
            case 1:
                return $this->context->getText ("tomorow");
            case 0:
                return $this->context->getText ("today");
            case -1:
                return $this->context->getText ("yesterday");
            }

        return NULL;
        }

    public function getRelativeDayName ($relativeDays, $now)
        {
        $givenDay = strtotime (date ("Y-m-d 00:00:00", $now + 24*60*60 * $relativeDays));
        $today = strtotime (date ("Y-m-d 00:00:00"));
        $str = $this->getRelativeDayLabel (($givenDay - $today) / (24*60*60));

        if (empty ($str))
            $str = date ("Y-m-d", $now + 24*60*60 * $relativeDays);
        return $str;
        }
    
    public function decimalToString ($dec, $decimalPlaces)
        {
        return sprintf ("%.{$decimalPlaces}f", $dec);
        }

    // Sports specialization - to be moved to some separate file 
    public function getTeamLabel ($row)
        {
        $postfix = empty ($row[TeamNamesTable::COL_POSTFIX]) ? "" : "-".$row[TeamNamesTable::COL_POSTFIX];
        $parts = array ();
        if (!empty ($row[TeamNamesTable::COL_PREFIX]))
            $parts[] = $row[TeamNamesTable::COL_PREFIX];
        if (!empty ($row[TeamNamesTable::COL_NAME]))
            $parts[] = $row[TeamNamesTable::COL_NAME].$postfix;
        if (!empty ($row[TeamNamesTable::COL_CITY]))
            $parts[] = $row[TeamNamesTable::COL_CITY].(empty ($row[TeamNamesTable::COL_NAME]) ? $postfix : "");
        return implode (" ", $parts);
        }
    public function beautifyTeamLabel ($label)
        {
        return $label;
        }

    public function makePlural ($word)
        {
        $word = trim ($word);
        if (empty ($word))
            return NULL;
        return $word."s";
        }
    }

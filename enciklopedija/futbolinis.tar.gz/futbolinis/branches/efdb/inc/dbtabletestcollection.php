<?php

require_once (PATH."inc/testcollection.php");

abstract class DbTableTestCollection extends TestCollection
    {
    protected $createdRecords = array ();
    protected $createdInstanceTracker;

    protected function isTableValid ($dbtable)
        {
        if (empty ($dbtable))
            {
            echo '<pre>Please set $this->dbtable variable for generic functions to work'.PHP_EOL.'</pre>';
            return false;
            }

        return true;
        }

    public function selectAllRecords ($context, $input)
        {
        if (!$this->isTableValid ($this->dbtable))
            return false;

        $rows = $this->dbtable->selectBy ($input, NULL);
        if (empty ($rows))
            return $rows;

        return $rows;
        }

    public function validateSelectedRecords ($context, $actualOutput, $expectedOutput)
        {
        if (false === $actualOutput)
            return false;

        return $actualOutput == $expectedOutput;
        }

    public function insertRecord ($context, $input)
        {
        list ($label, $nameToValue) = $input;
        if (!$this->isTableValid ($this->dbtable))
            return false;

        $replace = array ();
        foreach ($nameToValue as $name => &$value)
            {
            if ($value instanceof InstanceIdPlaceholder)
                {
                $id = $this->createdInstanceTracker->getId ($value->label);
                if (false === $id)
                    {
                    $context->addError ("Instance $label was not created");
                    return false;
                    }

                $nameToValue[$name] = $id;
                }
            }

        if (ALLOW_INVASIVE_ATP && $this->dbtable->canDelete ())
            $ret = $this->dbtable->insertRecord ($nameToValue);
        else
            $ret = false;

        if (empty ($ret))
            return $ret;

        if (!empty ($this->createdInstanceTracker))
            $this->createdInstanceTracker->addId ($label, $ret);

        $this->createdRecords[] = $ret;
        return $ret;
        }

    protected function deleteAllRecords ($recordIds)
        {
        $ret = true;
        $count = 0;
        foreach ($recordIds as $id)
            {
            $affected = $this->dbtable->deleteById ($id);
            if (false === $affected)
                {
                echo "<h1 class=\"error\">Delete failed</h1>".
                $ret = false;
                }
            else
                $count += $affected;
            }

        return $ret ? $count : $ret;
        }

    public function deleteRecord ($context, $index)
        {
        if (!$this->isTableValid ($this->dbtable) || !array_key_exists ($index, $this->createdRecords))
            return false;

        $id = $this->createdRecords[$index];
        $affected = $this->dbtable->deleteById ($id);
        if (false === $affected)
            $ret = false;
        else if (1 == $affected)
            {
            unset ($this->createdRecords[$index]);
            return true;
            }

        return $affected;
        }

    public function deleteCreatedRecords ($context)
        {
        $affected = 0;

        if (!empty ($this->createdRecords))
            {
            $affected = $this->deleteAllRecords ($this->createdRecords);
            $this->createdRecords = array ();
            }

        return $affected;
        }

    public function validateId ($context, $actualOutput, $expectedOutput)
        {
        return $actualOutput > 0;
        }

    protected function createSelectAllTest ($expectedRecords, $fields)
        {
        return parent::createTest ("selectAllRecords", $fields, array ($this, "selectAllRecords"), $expectedRecords, array ($this, "validateSelectedRecords"));
        }

    protected function createInsertTest ($label, $nameToValue, $defaultValues, &$expectedRecords)
        {
        $expectedResult = $nameToValue;
        foreach (empty ($defaultValues) ? array () : $defaultValues as $key => $value)
            {
            if (!array_key_exists ($key, $expectedResult))
                $expectedResult[$key] = $value;
            }
        $expectedRecords[] = $expectedResult;

        return parent::createTest ("insertRecord '$label'", array ($label, $nameToValue), array ($this, "insertRecord"), 0, array ($this, "validateId"));
        }

    protected function createDeleteAllTest (&$expectedRecords)
        {
        $test = parent::createTest ("deleting createrecords", NULL, array ($this, "deleteCreatedRecords"), count ($expectedRecords));
        $expectedRecords = array ();
        return $test;
        }

    protected function createDeleteItemTest ($index, $expectedResult)
        {
        return parent::createTest ("delete single record", $index, array ($this, "deleteRecord"), $expectedResult);
        }

    public function cleanup ($context)
        {
        $this->deleteCreatedRecords ($context);
        }

    public function run ($context, $diagnoseTest = NULL, $atomic = false)
        {
        return parent::run ($context, $diagnoseTest, true);
        }

    public function getActionList ()
        {
        $actions = parent::getActionList ();

        if ($this->isTableValid ($this->dbtable))
            {
            if (!$this->dbtable->tableExists ())
                array_unshift ($actions, new SimpleLinkAction ($this, "create", $this->getText ("Create table"), $this->parentComponent->getTestActionUrl (get_class ($this), "create"), true));
            else if (defined ("DELETE_TABLE_ALLOWED") && DELETE_TABLE_ALLOWED)
                array_unshift ($actions, new SimpleLinkAction ($this, "drop", $this->getText ("Drop table"), $this->parentComponent->getTestActionUrl (get_class ($this), "drop"), true));
            }

        return $actions;
        }

    public function executeAction ($context, $action)
        {
        if ("drop" == $action)
            return $this->dropTable ($context);
        if ("create" == $action)
            return $this->createTable ($context);

        return parent::executeAction ($context, $action);
        }

    protected function dropTable ($context)
        {
        if (!$this->isTableValid ($this->dbtable))
            return false;

        if (false === $this->dbtable->deleteTable ())
            $this->context->addError ("Failed to drop the table");
        else
            $this->context->addMessage ("Table was dropped successfully");
        }

    protected function createTable ($context)
        {
        if (!$this->isTableValid ($this->dbtable))
            return false;

        if (false === $this->dbtable->createTable ())
            $this->context->addError ("Failed to create the table");
        else
            {
            $this->context->addMessage ("Table was created successfully");
            }
        }
    }

class InstanceIdPlaceholder
    {
    public $label;

    public function __construct ($label)
        {
        $this->label = $label;
        }
    }

class CreatedTestInstances
    {
    protected $arr = array ();

    public function getId ($label)
        {
        if (!array_key_exists ($label, $this->arr))
            return false;
        return $this->arr[$label];
        }

    public function addId ($label, $id)
        {
        $this->arr[$label] = $id;
        }

    public function getCollected ()
        {
        return array_flip ($this->arr);
        }
    }

<?php

/* A database table which stores indexed contents */
class ExtractedContentTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "extractedcontent";

    const COL_SCOPE = "scope";
    const COL_ENTRYID = "entryid";
    const COL_LABEL = "label";
    const COL_DESCRIPTION = "description";
    const COL_INDEXED_LABEL = "indexedlabel";
    const COL_INDEXED_TEXT = "compiledtext";
    const COL_MODIFIER = "modifier"; // to rise entry importance
    const COL_DATE = "lastUpdated";
    const COL_IMAGEID = "imageid";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        }

    protected function getColumns ()
        {
        return array (
                     new TextColumn (DBTable::COL_LANG, 5, false),
                     new TextColumn (self::COL_SCOPE, 128, false),
                     new TextColumn (self::COL_ENTRYID, 32, false),
                     new TextColumn (self::COL_LABEL, 512, false),
                     new IntColumn (self::COL_MODIFIER, false),
                     new LongTextColumn (self::COL_DESCRIPTION, true),
                     new LongTextColumn (self::COL_INDEXED_LABEL, true),
                     new LongTextColumn (self::COL_INDEXED_TEXT, true),
                     new DateTimeColumn (self::COL_DATE, true),
                     new IntColumn (self::COL_IMAGEID, true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new PrimaryIndex (DBTable::COL_LANG, new TextColumn (self::COL_SCOPE, 32, false), self::COL_ENTRYID),
                      new FullTextIndex (self::COL_INDEXED_LABEL),
                      new FullTextIndex (self::COL_INDEXED_TEXT),
                      new Index (self::COL_LABEL));
        }

    public function updateEntry ($scope, $id, $label, $description, $lastUpdated, $indexedLabel, $extractedText, $imageid)
        {
        $textColumn = new TextColumn (self::COL_LANG, 5);
        $nameToValue = array ();
        $nameToValue[DBTable::COL_LANG] = $this->getLanguage ();
        $nameToValue[ExtractedContentTable::COL_SCOPE] = $scope;
        $nameToValue[ExtractedContentTable::COL_ENTRYID] = $id;
        $nameToValue[ExtractedContentTable::COL_LABEL] = $label;
        $nameToValue[ExtractedContentTable::COL_DESCRIPTION] = utf8_substr (strip_tags ($this->context->applyFormat ($description)), 0, 250);
        $nameToValue[ExtractedContentTable::COL_DATE] = $lastUpdated;
        $nameToValue[ExtractedContentTable::COL_INDEXED_LABEL] = empty ($indexedLabel) ? $label : $indexedLabel;
        $nameToValue[ExtractedContentTable::COL_INDEXED_TEXT] = $extractedText;
        $nameToValue[ExtractedContentTable::COL_IMAGEID] = $imageid;
        $ret = $this->insertOrUpdateRecord ($nameToValue);
        if (false === $ret && !$this->tableExists ())
            {
            if (!$this->createTable ())
                return false;

            $ret = $this->insertOrUpdateRecord ($nameToValue);
            }
        return $ret > 0;
        }

    public function deleteEntry ($scope, $id)
        {
        $textColumn = new TextColumn (self::COL_LANG, 5);
        $criteria[] = new EqCriterion (DBTable::COL_LANG, $textColumn->formatValueForDB ($this->context, $this->context->getLanguage ()));
        $criteria[] = new EqCriterion (self::COL_SCOPE, $scope);
        $criteria[] = new EqCriterion (self::COL_ENTRYID, $id);
        return $this->deleteBy ($criteria);
        }

    public static function executeSearch ($context, $searchString, $limit = 20, $scope = NULL)
        {
        $textColumn = new TextColumn (self::COL_LANG, 5);

        $columns = array (self::COL_SCOPE, self::COL_ENTRYID, self::COL_LABEL, self::COL_DESCRIPTION, self::COL_IMAGEID);
        $columns[] = new FullTextMatchFunction (array (self::COL_INDEXED_LABEL), $searchString, "labelMatch");
        $columns[] = new FullTextMatchFunction (array (self::COL_INDEXED_TEXT), $searchString, "textMatch");

        if (!empty ($scope))
            $criteria[] = new EqCriterion (self::COL_SCOPE, $scope);

        $criteria[] = new EqCriterion (DBTable::COL_LANG, $context->getLanguage ());
        $criteria[] = new LogicalOperatorOr (new FTSCriterion (array (self::COL_INDEXED_LABEL), $searchString),
                                             new FTSCriterion (array (self::COL_INDEXED_TEXT), $searchString));
        $params = array ();
        if ($limit > 0)
            $params[] = new LimitResults (0, $limit);
        $params[] = OrderBy::createByAlias ("labelMatch*10+textMatch", false);
        $dbtable = new ExtractedContentTable ($context);
        return $dbtable->selectBy ($columns, $criteria, NULL, $params);
        }

    public static function executeSearchByPrefix ($context, $searchString, $limit = 20)
        {
        $textColumn = new TextColumn (self::COL_LANG, 5);

        $columns = array (self::COL_SCOPE, self::COL_ENTRYID, self::COL_LABEL, self::COL_DESCRIPTION, self::COL_IMAGEID);
        $criteria[] = new EqCriterion (DBTable::COL_LANG, $textColumn->formatValueForDB ($context, $context->getLanguage ()));
        $criteria[] = new LikeCriterion (self::COL_INDEXED_LABEL, $searchString);
        $params = array ();
        if ($limit > 0)
            $params[] = new LimitResults (0, $limit);
        $dbtable = new ExtractedContentTable ($context);
        return $dbtable->selectBy ($columns, $criteria, NULL, $params);
        }
    }

class ExtractionStatusTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "extractionstatus";

    const COL_SCOPE = "scope";
    const COL_LAST_SYNC = "lastsynctime";
    const COL_LAST_CHUNK_SIZE = "lastchunksize";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        }

    protected function getColumns ()
        {
        return array (
                     new TextColumn (DBTable::COL_LANG, 5, false),
                     new TextColumn (self::COL_SCOPE, 128, false),
                     new DateTimeColumn (self::COL_LAST_SYNC, false),
                     new IntColumn (self::COL_LAST_CHUNK_SIZE, false),
                     );
        }

    protected function getIndexes ()
        {
        return array (new PrimaryIndex (DBTable::COL_LANG, self::COL_SCOPE));
        }

    public function selectLastSyncTime ($scope)
        {
        $textColumn = new TextColumn (self::COL_LANG, 5);

        $criteria = array (new EqCriterion (ExtractionStatusTable::COL_SCOPE, $scope));
        $criteria[] = new EqCriterion (DBTable::COL_LANG, $textColumn->formatValueForDB ($this->context, $this->getLanguage ()));
        $resultColumns = array (ExtractionStatusTable::COL_LAST_SYNC, ExtractionStatusTable::COL_LAST_CHUNK_SIZE);
        $res = $this->selectBy ($resultColumns, $criteria);
        if (false === $res && !$this->tableExists ())
            {
            if (!$this->createTable ())
                return false;

            $res = $this->selectBy ($resultColumns, $criteria);
            }

        if (false === $res)
            return false;
        if (empty ($res))
            return NULL;
        return array ($res[0][ExtractionStatusTable::COL_LAST_SYNC], $res[0][ExtractionStatusTable::COL_LAST_CHUNK_SIZE]);
        }

    public function updateLastSyncTime ($scope, $dateTime, $nextChunkFrom)
        {
        $textColumn = new TextColumn (self::COL_LANG, 5);
        $nameToValue = array ();
        $nameToValue[ExtractionStatusTable::COL_SCOPE] = $scope;
        $nameToValue[DBTable::COL_LANG] = $textColumn->formatValueForDB ($this->context, $this->getLanguage ());
        $nameToValue[ExtractionStatusTable::COL_LAST_SYNC] = $dateTime;
        $nameToValue[ExtractionStatusTable::COL_LAST_CHUNK_SIZE] = $nextChunkFrom;
        $ret = $this->insertOrUpdateRecord ($nameToValue);
        return $ret > 0;
        }
    }

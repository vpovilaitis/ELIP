<?php

abstract class LinkAction extends Action
    {
    protected $url;
    public $icon;

    public function __construct ($component, $key, $tooltip, $url)
        {
        parent::__construct ($component, $key, $tooltip);
        $this->url = $url;
        }

    public abstract function getUrl ($request, $ids);

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function execute ($request, $ids)
        {
        return true;
        }

    public function getClassName ()
        {
        return "linkaction";
        }

    public function getIconPath ()
        {
        if (empty ($this->icon))
            return NULL;
        return $this->context->getSmallIconPath ($this->icon);
        }
    }

<?php

class LabelFieldTemplate extends FieldTemplate
    {
    public $multiline;
    public $align;

    public function __construct ($prefix, $key, $label, $multiline = false)
        {
        parent::__construct ($prefix, $key, "label", $label, NULL);
        $this->multiline = $multiline;
        }

    public function getUri ($context, $row)
        {
        return NULL;
        }

    public function showValue ($fieldValue)
        {
        return !empty ($fieldValue);
        }

    public function isRichText ()
        {
        return false;
        }

    public function getTemplateName ()
        {
        return "labelfield";
        }
    }


class LabelTemplate extends LabelFieldTemplate
    {
    protected $text;

    public function __construct ($label, $title = NULL, $multiline = false)
        {
        if (NULL === $title)
            $title = $label;
        parent::__construct (NULL, NULL, $title, $multiline);
        $this->text = $label;
        }

    public function getValueForDisplay ($context, $row)
        {
        return $this->text;
        }

    }

class FormattedFieldLabelTemplate extends LabelFieldTemplate
    {
    protected $parser = NULL;

    public function __construct ($prefix, $key, $label, $multiline = true)
        {
        parent::__construct ($prefix, $key, $label, $multiline);
        }

    public function isRichText ()
        {
        return true;
        }

    public function getValueForDisplay ($context, $row)
        {
        if (NULL === $this->parser)
            $this->parser = new Parser ($context, parent::getValueForDisplay ($context, $row));

        return $this->parser->process ();
        }

    }

class LabelDateFieldTemplate extends LabelFieldTemplate
    {
    public function __construct ($prefix, $key, $label)
        {
        parent::__construct ($prefix, $key, $label);
        }

    public function getValueForDisplay ($context, $row)
        {
        return Language::getInstance($context)->dateToLongString ($row[$this->key]);
        }

    }

class LabelCompactFieldTemplate extends LabelFieldTemplate
    {
    public $compact = true;
    }

class LabelIntFieldTemplate extends LabelCompactFieldTemplate
    {
    public function __construct ($prefix, $key, $label)
        {
        parent::__construct ($prefix, $key, $label);
        $this->align = "right";
        }

    public function showValue ($fieldValue)
        {
        return NULL !== $fieldValue;
        }
    }

class LabelNamedIntFieldTemplate extends LabelFieldTemplate
    {
    protected $list;
    public function __construct ($prefix, $key, $col)
        {
        parent::__construct ($prefix, $key, $col->getLabel ());
        $this->list = NamedIntColumn::getItems ($col);
        }

    public function getValueForDisplay ($context, $row)
        {
        if (NULL === $row[$this->key])
            return "";
        $val = $row[$this->key];
        if (array_key_exists ($val, $this->list))
            return $this->list[$val];
        return $val;
        }
    }

class LabelWeightFieldTemplate extends LabelFieldTemplate
    {
    public function __construct ($prefix, $key, $label)
        {
        parent::__construct ($prefix, $key, $label);
        $this->align = "right";
        }

    public function showValue ($fieldValue)
        {
        return !empty ($fieldValue);
        }

    public function getValueForDisplay ($context, $row)
        {
        if (NULL === $row[$this->key])
            return "";
        return sprintf ("%d kg", $row[$this->key]);
        }
    }

class LabelDecimalFieldTemplate extends LabelFieldTemplate
    {
    public function getValueForDisplay ($context, $row)
        {
        if (NULL === $row[$this->key])
            return "";
        $lng = Language::getInstance ($context);
        return $lng->decimalToString ($row[$this->key], 2);
        }
    }

class LabelHeightFieldTemplate extends LabelDecimalFieldTemplate
    {
    public function getValueForDisplay ($context, $row)
        {
        if (NULL === $row[$this->key])
            return "";
        $lng = Language::getInstance ($context);
        return $lng->decimalToString ($row[$this->key] / 100, 2);
        }
    }

class LabelBoolFieldTemplate extends LabelCompactFieldTemplate
    {
    public function __construct ($prefix, $key, $label)
        {
        parent::__construct ($prefix, $key, $label);
        $this->align = "center";
        }

    public function getValueForDisplay ($context, $row)
        {
        if (NULL === $row[$this->key])
            return "";
        return $row[$this->key] ? $context->getText ("Yes") : $context->getText ("No");
        }
    }

class SortOrderFieldTemplate extends LabelFieldTemplate
    {
    public function __construct ($prefix, $key, $label)
        {
        parent::__construct ($prefix, $key, $label);
        }

    public function getValueForDisplay ($context, $row)
        {
        $order = $row[MetaDataColumns::COL_SORTORDER];
        if ($order > 0)
            {
            if (!$row[MetaDataColumns::COL_SORTASC])
                return "$order ¬";
            return $order;
            }

        return NULL;
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        $resultColumns[] = MetaDataColumns::COL_SORTORDER;
        $resultColumns[] = MetaDataColumns::COL_SORTASC;
        }
    }
?>
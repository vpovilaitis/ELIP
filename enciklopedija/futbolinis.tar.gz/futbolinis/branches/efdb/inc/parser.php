<?php

require_once (PATH."inc/base.php");

class Parser extends BaseWithContext
    {
    protected $text;
    protected $processed = NULL;

    public function __construct ($context, $text)
        {
        parent::__construct ($context);
        $this->text = $text;
        }

    public function getUrlFromLink ($link, &$label, &$img)
        {
        $parts = explode (":", $link, 2);
        if (count ($parts) == 2)
            {
            $namespace = $parts[0];
            $link = $parts[1];
            }
        else
            $namespace = NULL;

        if (empty ($namespace))
            {
            $url = $this->context->chooseUrl ("page/$link",
                                              "index.php?page=$link");
            }
        else if ("*" == trim ($link))
            {
            $url = $this->context->chooseUrl ("list/$namespace",
                                              "index.php?c=ContentPreviewPage&tn=$namespace");
            if ($label == $link)
                $label = $this->getText ("List");
            }
        else if (is_numeric ($link))
            {
            $url = $this->context->chooseUrl ("content/$namespace/$link",
                                              "index.php?c=ContentPage&mode=".Constants::MODE_VIEW."&tn=$namespace&id=$link");
            }
        else if (!empty ($namespace) && "#" == $namespace[0])
            {
            $img = substr ($namespace, 1);
            if (!empty ($img))
                $img = $this->context->getResourcePath ("img", "metro-$img.png");

            if (empty ($img))
                $img = $this->context->getResourcePath ("img", "metro-note.png");

            if (false === strpos ($link, ':'))
                {
                if (0 === strpos ($link, '/'))
                    $url = $link;
                else
                    $url = $this->context->processUrl ($link, true);
                }
            else
                {
                $url = $this->getUrlFromLink ($link, $label, $img);
                }

            return $url;
            }
        else
            {
            // TODO: find id by table name and criteria
            $url = $this->context->chooseUrl ("locate/$namespace/$link",
                                              "index.php?c=ContentPage&mode=".Constants::MODE_LOCATE."&tn=$namespace&cri=$link");
            }
        return $url;
        }

    public function replaceLink ($match)
        {
        $link = $match[1];

        if (count ($match) > 2)
            $label = $match[3];
        else
            $label = $link;

        $img = NULL;
        $url = $this->getUrlFromLink ($link, $label, $img);

        if (!empty ($img))
            return "<a class=\"ui-helper-reset linkbutton\" href=\"$url\"><img class=\"sectionimg\" src=\"$img\" alt=\"*\"><span class=\"ui-helper-reset\"> $label</span></a>";
        return "<a href=\"$url\">$label</a>";
        }

    public function getPlainText ($limit = NULL)
        {
        if (empty ($this->text))
            return $this->text;

        $text = strip_tags ($this->text);
        $text = preg_replace ("/\[\[([^]|]+)(\|(.+))?\]\]/U", "\\3", $text);
        $text = preg_replace ("/[\n\r]+/U", " ", $text);
        $text = preg_replace ("/\s+/", " ", $text);
        if ($limit > 0)
            return $this->trimSentence ($text, $limit);
        return $text;
        }

    public function process ($encloseInParagraph = true)
        {
        if (NULL !== $this->processed)
            return $this->processed;

        if (empty ($this->text))
            return $this->text;

        $text = $this->text;
        $text = strip_tags ($text, '<br><b><i><table><caption><a><tr><th><td><span><p><div><img><ul><ol><li>');// leave only '<br><b><i>'

        $text = preg_replace_callback ("/\[\[([^]|]+)(\|(.+))?\]\]/U",
                                       array ($this, "replaceLink"), $text);

        $lines = explode ("\n", $text);

        $needBreak = NULL;
        $indendLevel = 0;
        $result = array ();
        $closeTag = "";
        if ($encloseInParagraph)
            {
            $result[] = "<p>";
            $closeTag = "</p>";
            }

        foreach ($lines as $line)
            {
            $line = trim ($line);
            if (empty ($line))
                {
                if (NULL !== $needBreak)
                    $needBreak = true;
                continue;
                }

            $needToClose = false;
            $newIndent = 0;
            while ($line[$newIndent] == "*")
                $newIndent++;

            if ($newIndent > 0)
                {
                if ($closeTag != "</ul>")
                    {
                    $result[] = $closeTag;
                    
                    for ($i = 0; $i < $newIndent; $i++)
                        $result[] = "<ul>";
                    $closeTag = "</ul>";
                    }
                else if ($indendLevel > $newIndent)
                    {
                    for ($i = $newIndent; $i < $indendLevel; $i++)
                        $result[] = $closeTag;
                    }
                else if ($indendLevel < $newIndent)
                    {
                    for ($i = $indendLevel; $i < $newIndent; $i++)
                        $result[] = "<ul>";
                    }

                $line = "<li>".substr ($line, $newIndent)."</li>";
                $needBreak = false;
                $indendLevel = $newIndent;
                }
            else if ($closeTag != "</p>" && $closeTag != "")
                {
                $needToClose = true;
                }

            if ($needBreak)
                $needToClose = true;

            if ($needToClose)
                {
                if ($indendLevel > 1)
                    {
                    for ($i = 1; $i < $indendLevel; $i++)
                        $result[] = $closeTag;
                    }

                $result[] = $closeTag;
                $result[] = "<p>";
                $closeTag = "</p>";
                $indendLevel = 0;
                }

            $result[] = $line;
            $needBreak = false;
            }

        $result[] = $closeTag;
        $this->processed = implode ("\n", $result);
        return $this->processed;
        }
    }

<?php

class DiscussionTopicTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "discussiontopic";

    const COL_ID = "topicid";
    const COL_SCOPE = "scope"; // 'm_fragments', 'x_persons', etc
    const COL_CONTEXTID = "contextid";
    const COL_TITLE = "title";
    const COL_OPEN = "open";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        $this->tracksRevisions = true;
        }

    protected function getColumns ()
        {
        $isTopicOpenColumn = new BoolColumn (self::COL_OPEN);
        $isTopicOpenColumn->defaultValue = true;

        return array (
                     new AutoincrementColumn (self::COL_ID),
                     new TextColumn (self::COL_SCOPE, 128),
                     new TextColumn (self::COL_CONTEXTID, 32),
                     new TextColumn (DBTable::COL_LANG, 5),
                     new TextColumn (self::COL_TITLE, 256, true),
                     $isTopicOpenColumn,
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new Index (self::COL_SCOPE, self::COL_CONTEXTID, DBTable::COL_LANG, self::COL_OPEN),
            );
        }

    public function create ($scope, $contextId, $topic)
        {
        $values = array (self::COL_SCOPE => $scope, self::COL_CONTEXTID => $contextId,
                         DBTable::COL_LANG => $this->context->getLanguage (), self::COL_TITLE => $topic);
        return $this->insertRecord ($values);
        }

    }

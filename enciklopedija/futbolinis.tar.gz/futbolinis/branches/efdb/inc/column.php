<?php

class NamedItem
    {
    public $name;
    }

class Column extends NamedItem
    {
    public $alias;

    public function __construct ($name, $alias = NULL)
        {
        $this->name = $name;
        $this->alias = $alias;
        }

    public function toString ($tableAlias, $dbtable, $query)
        {
        $str = "";
        if (NULL == $tableAlias)
            $str = $dbtable->prepareColumnName ($this->name);
        else
            $str = $tableAlias.".".$dbtable->prepareColumnName ($this->name);

        if (NULL != $this->alias)
            $str .= " ".$dbtable->prepareColumnName ($this->alias);

        return $str;
        }
    }

class ConstantColumn extends Column
    {
    public function toString ($tableAlias, $dbtable, $query)
        {
        $str = $this->name;
        if (NULL != $this->alias)
            $str .= " ".$dbtable->prepareColumnName ($this->alias);

        return $str;
        }
    }

class AggregateFunction extends Column
    {
    protected $function;
    protected $modifier;

    public function __construct ($function, $column, $alias = NULL)
        {
        parent::__construct ($column, (NULL == $alias) ? $column : $alias);
        $this->function = $function;
        }

    public function toString ($tableAlias, $dbtable, $query)
        {
        $str = $this->function."(";
        if (!empty ($this->modifier))
            $str .= "$this->modifier ";

        if (false !== strpos ($this->name, "("))
            $str .= $this->name;
        else if (NULL == $tableAlias)
            {
            if ("*" == $this->name)
                $str .= $this->name;
            else
                $str .= $dbtable->prepareColumnName ($this->name);
            }
        else
            $str .= $tableAlias.".".$dbtable->prepareColumnName ($this->name);

        $str .= ")";

        if (NULL != $this->alias)
            $str .= " ".$dbtable->prepareColumnName ($this->alias);

        return $str;
        }
    }

class FunctionSum extends AggregateFunction
    {
    public function __construct ($column, $alias = NULL)
        {
        parent::__construct ("sum", $column, $alias);
        }
    }

class FunctionMax extends AggregateFunction
    {
    public function __construct ($column, $alias = NULL)
        {
        parent::__construct ("max", $column, $alias);
        }
    }

class FunctionMin extends AggregateFunction
    {
    public function __construct ($column, $alias = NULL)
        {
        parent::__construct ("min", $column, $alias);
        }
    }

class FunctionAvg extends AggregateFunction
    {
    public function __construct ($column, $alias = NULL)
        {
        parent::__construct ("avg", $column, $alias);
        }
    }

class FunctionCount extends AggregateFunction
    {
    public function __construct ($column, $alias = NULL)
        {
        parent::__construct ("count", $column, $alias);
        }

    public function toString ($tableAlias, $dbtable, $query)
        {
        if ($this->name == "*")
            return parent::toString (NULL, $dbtable, $query);
        return parent::toString ($tableAlias, $dbtable, $query);
        }
    }

class FunctionDistinctCount extends AggregateFunction
    {
    public function __construct ($column, $alias = NULL)
        {
        parent::__construct ("count", $column, $alias);
        $this->modifier = "distinct";
        }
    }

class LastUpdatedColumn extends Column
    {
    const COLUMN_NAME = "lastupdated";

    public function __construct ()
        {
        parent::__construct (self::COLUMN_NAME, self::COLUMN_NAME);
        }

    public function toString ($tableAlias, $dbtable, $query)
        {
        $translatable = $query->getTranslatableColumnSubquery ();
        $alias = empty ($tableAlias) ? "" : ($tableAlias.".");
        $updatedOn = $alias.DBTable::COL_UPDATEDON;
        $createdOn = $alias.DBTable::COL_CREATEDON;
        if (empty ($translatable))
            $str = "(case WHEN $updatedOn<$createdOn THEN $createdOn ELSE $updatedOn END) $this->alias";
        else
            {
            $updatedTranslations = $translatable->physicalAlias.".".DBTable::COL_UPDATEDON;
            $str = "(case WHEN $updatedTranslations<$updatedOn THEN $updatedOn ELSE $updatedTranslations END) $this->alias";
            }

        return $str;
        }
    }

class TranslatableResultColumn extends Column
    {
    public $primaryQuery;
    public $tableAlias;

    public function __construct ($name, $tableAlias)
        {
        parent::__construct ($name, $name);
        $this->tableAlias = $tableAlias;
        }

    public function toString ($tableAlias, $dbtable, $query)
        {
        $translatable = $query->getTranslatableColumnSubquery ();
        $alias = empty ($tableAlias) ? "" : ($tableAlias.".");
        $pAlias = empty ($this->primaryQuery) ? "" : $this->primaryQuery->physicalAlias.".";
        $columnName = (empty ($this->tableAlias) ? "" : ($this->tableAlias."_")).$this->alias;
        /*
        CASE WHEN `tbl2`.`c_from` IS NULL
             THEN `tbl1`.`def_c_from`
             ELSE `tbl2`.`c_from`
         END
        */
        $str = "(case WHEN $alias$this->name IS NULL THEN $pAlias".DBTable::LNG_PREFIX."$this->name ELSE $alias$this->name END) ".$dbtable->prepareColumnName ($columnName);
        return $str;
        }
    }

class ConditionalResultColumn extends Column
    {
    protected $condition;
    protected $column1;
    protected $column2;

    public function __construct ($alias, $condition, $column1, $column2)
        {
        parent::__construct ($alias, $alias);
        $this->condition = $condition;
        $this->column1 = $column1;
        $this->column2 = $column2;
        }

    public function toString ($tableAlias, $dbtable, $query)
        {
        $alias = empty ($tableAlias) ? "" : ($tableAlias.".");
        $str = "(case WHEN $this->condition THEN $this->column1 ELSE $this->column2 END) ".$dbtable->prepareColumnName ($this->name);
        return $str;
        }
    }

class ConditionalMaxColumn extends ConditionalResultColumn
    {
    public function toString ($tableAlias, $dbtable, $query)
        {
        return "MAX".parent::toString ($tableAlias, $dbtable, $query);
        }
    }

class ConditionalMinColumn extends ConditionalResultColumn
    {
    public function toString ($tableAlias, $dbtable, $query)
        {
        return "MIN".parent::toString ($tableAlias, $dbtable, $query);
        }
    }

class ConditionalSumColumn extends ConditionalResultColumn
    {
    public function toString ($tableAlias, $dbtable, $query)
        {
        return "SUM".parent::toString ($tableAlias, $dbtable, $query);
        }
    }

class ConditionalDistinctCountColumn extends ConditionalResultColumn
    {
    public function toString ($tableAlias, $dbtable, $query)
        {
        $alias = empty ($tableAlias) ? "" : ($tableAlias.".");
        $str = "COUNT(DISTINCT (case WHEN $this->condition THEN $this->column1 ELSE $this->column2 END)) ".$dbtable->prepareColumnName ($this->name);
        return $str;
        }
    }

class FullTextMatchFunction extends Column
    {
    protected $value;
    protected $fields;

    public function __construct ($columns, $value, $alias)
        {
        parent::__construct (NULL, $alias);
        $this->value = $value;
        $this->fields = is_array ($columns) ? $columns : array ($columns);
        }

    public function toString ($tableAlias, $dbtable, $query)
        {
        if (!empty ($query))
            {
            $tableAlias = $query->physicalAlias;
            $join = $query->getTranslatableColumnSubquery ();
            if (!empty ($join))
                $tableAlias = $join->physicalAlias;
            }

        $columns = array ();
        foreach ($this->fields as $field)
            $columns[] = $tableAlias.".".$dbtable->prepareColumnName ($field);

        $searchModifier = false === strpbrk ($this->value, "+-*()") ? "WITH QUERY EXPANSION" : "IN BOOLEAN MODE";
        return "MATCH (".implode (", ", $columns).") AGAINST ('$this->value' $searchModifier) ".$dbtable->prepareColumnName ($this->alias);
        }
    }


<?php

class FragmentsTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_META;
    const TABLE_NAME = "fragment";

    const COL_ID = "fragmentid";
    const COL_PARENTID = "parentid";
    const COL_PATH = "path";
    const COL_TYPE = "type";
    const COL_PUBLISHED = "show";
    const COL_PARAMS = "params";

    // styles
    const COL_TEMPLATE = "template";
    const COL_CSSCLASS = "cssclass";
    const COL_STYLE = "style"; // custom width, height, etc

    // for controls contained in the table layout
    const COL_ROWSPAN = "rowspan";
    const COL_COLSPAN = "colspan";

    // for non container controls
    const COL_ICON = "icon"; // title icon
    const COL_TITLE = "title";
    const COL_DESCRIPTION = "description";
    const COL_TABLEID = "table";

    const TYPE_CONTAINER = "Container";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, true);
        $this->tracksRevisions = true;
        $this->tracksSources = true;
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     new IntColumn (self::COL_PARENTID, true),
                     new TextColumn (self::COL_PATH, 512, true),
                     new IntColumn (DBTable::COL_ORDER),
                     new TextColumn (self::COL_TYPE, 128),
                     new TextColumn (self::COL_TEMPLATE, 64, true),
                     new TextColumn (self::COL_CSSCLASS, 64, true),
                     new TextColumn (self::COL_STYLE, 512, true),
                     new IntColumn (self::COL_ROWSPAN, true),
                     new IntColumn (self::COL_COLSPAN, true),
                     new TextColumn (self::COL_ICON, 128, true),
                     new IntColumn (self::COL_TABLEID, true),
                     new BoolColumn (self::COL_PUBLISHED, true),
                     new LongTextColumn (self::COL_PARAMS, true),
                     );
        }

    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (self::COL_TITLE, 256, true),
                     new LongTextColumn (self::COL_DESCRIPTION, true),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new Index (self::COL_PATH),
            );
        }

    public function createTable ()
        {
        $ret = parent::createTable ();
        if (!$ret)
            return $ret;

        // automatically create an empty home page
        $id = $this->createPage (HOME_PAGE, NULL);
        if (false !== $id)
            return true;
        return false;
        }

    public static function getPlaceholderFragment ($context)
        {
        $nameToValue = array
                            (
                            self::COL_TYPE => "TextFragment",
                            self::COL_TITLE => $context->getText ("Under construction"),
                            self::COL_DESCRIPTION => $context->getText ("Page is under construction."),
                            self::COL_PUBLISHED => true,
                            );
        return $nameToValue;
        }

    public function createPage ($name, $nameToValue)
        {
        // check for duplicate names
        $namesTable = new PageNamesTable ($this->context);
        $criteria = array (new EqCriterion (PageNamesTable::COL_NAME, $name));
        $cols = array (new FunctionCount (PageNamesTable::COL_NAME, "cnt"));
        $row = $namesTable->selectSingleBy ($cols, $criteria);
        if (empty ($row) || $row['cnt'] > 0)
            {
            $this->context->addError ("The page with the same name already exists.");
            return false;
            }

        // set default values
        if (empty ($nameToValue))
            {
            $nameToValue = self::getPlaceholderFragment ($this->context);
            $nameToValue[self::COL_PATH] = "";
            $nameToValue[DBTable::COL_ORDER] = 1;
            }

        // insert page record
        $id = $this->insertRecord ($nameToValue);
        if (false === $id)
            return false;

        // insert page name
        $vals = array (PageNamesTable::COL_NAME => $name, PageNamesTable::COL_FRAGMENTID => $id);
        if (false === $namesTable->insertRecord ($vals))
            return false;

        return $id;
        }

    public function selectPageFragments ($pageName, $editorMode = false)
        {
        $namesTable = new PageNamesTable ($this->context);
        if (empty ($namesTable))
            {
            $this->context->log ("Tables not created in the database");
            return false;
            }

        $joinCriteria = array (new JoinColumnsCriterion (PageNamesTable::COL_FRAGMENTID, self::COL_ID));
        $join = $this->createQuery (array (self::COL_PATH), $joinCriteria);
        $criteria = array (new EqCriterion (PageNamesTable::COL_NAME, $pageName));
        $rows = $namesTable->selectBy (array (PageNamesTable::COL_FRAGMENTID), $criteria, array ($join));
        if (empty ($rows))
            {
            $this->context->addError ("Page not found in database");
            return (false === $rows) ? false : NULL;
            }

        $row = $rows[0];
        $pageId = $row[FragmentsTable::COL_ID];
        $path = "";
        if (!empty ($row[self::COL_PATH]))
            $path = $row[self::COL_PATH];
        $path .= "{$pageId}_";
        return $this->selectFragmentHierarchyByPath ($pageId, $path, $editorMode);
        }

    public function selectFragmentHierarchyByPath ($pageId, $path, $editorMode = false)
        {
        $pageCriterion[] = new LogicalOperatorOr (
                                new EqCriterion (self::COL_ID, $pageId),
                                new LikeCriterion (self::COL_PATH, $path)
                                );

        if (!$editorMode)
            $pageCriterion[] = new EqCriterion (self::COL_PUBLISHED, true);

        $params = array
                    (
                    new OrderBy
                        (
                        array
                            (
                            new OrderByColumn (self::COL_PATH, true, 1),
                            new OrderByColumn (DBTable::COL_ORDER, true, 2),
                            )
                        )
                    );
        $components = $this->selectBy (NULL, $pageCriterion, NULL, $params);
        if (empty ($components))
            {
            $this->context->addError ("Page components not found in database");
            return false;
            }

        $idToFragment = array ();
        $rootNode = NULL;

        foreach ($components as $component)
            {
            $fragment = new PageFragmentNode ($component);
            $idToFragment[$fragment->id] = $fragment;

            if (NULL === $rootNode)
                {
                $rootNode = $fragment;
                continue;
                }

            if (!empty ($idToFragment[$component[self::COL_PARENTID]]))
                {
                $parent = $idToFragment[$component[self::COL_PARENTID]];
                $parent->children[] = $fragment;
                }
            }

        return $rootNode;
        }

    public function changeOrder ($parentId, $id, $up)
        {
        $criteria = array (new EqCriterion (self::COL_PARENTID, $parentId));
        return parent::changeItemOrder ($criteria, self::COL_ID, $id, $up);
        }

    public function createGroup ($fragmentId, $vertical = true)
        {
        $criteria = array (new EqCriterion (self::COL_ID, $fragmentId));
        $cols = array (self::COL_PATH, self::COL_PARENTID, self::COL_TITLE, self::COL_DESCRIPTION,
                       DBTable::COL_ORDER, self::COL_PUBLISHED);
        $row = $this->selectSingleBy ($cols, $criteria);
        if (empty ($row) )
            {
            $this->context->addError ("Group member fragment not found.");
            return false;
            }

        $nameToValue = array
                            (
                            self::COL_PARENTID => $row[self::COL_PARENTID],
                            self::COL_PATH => $row[self::COL_PATH],
                            self::COL_TYPE => self::TYPE_CONTAINER,
                            self::COL_TEMPLATE => $vertical ? "vertical" : "horizontal",
                            self::COL_TITLE => $row[self::COL_TITLE],
                            self::COL_DESCRIPTION => $row[self::COL_DESCRIPTION],
                            DBTable::COL_ORDER => $row[DBTable::COL_ORDER],
                            self::COL_PUBLISHED => $row[self::COL_PUBLISHED]
                            );
        // insert page record
        $id = $this->insertRecord ($nameToValue);
        if (false === $id)
            return false;

        $idCriteria[] = new EqCriterion (self::COL_ID, $fragmentId);
        $nameToValue = array (self::COL_PATH => $row[self::COL_PATH].$id."_", self::COL_PARENTID => $id);
        $affected = $this->updateById ($idCriteria, $idCriteria, $nameToValue);
        if (1 !== $affected)
            $this->context->addError ("Unable to finish grouping operation.");

        if (false === $affected)
            {
            // try to delete just created item
            $idCriteria[] = new EqCriterion (self::COL_ID, $id);
            $this->deleteById ($idCriteria);
            return false;
            }

        $namesTable = new PageNamesTable ($this->context);
        if (empty ($namesTable))
            $this->context->log ("Tables not created in the database");
        else
            {
            $criteria = array (new EqCriterion (PageNamesTable::COL_FRAGMENTID, $fragmentId));
            $nameToValue = array (PageNamesTable::COL_FRAGMENTID => $id);
            if (false === $namesTable->updateRecord ($criteria, $nameToValue))
                $this->context->log ("Error while updating page name mappings");
            }

        return $id;
        }

    public function addNewFragment ($parentId, $last)
        {
        $order = 0;
        if ($last)
            {
            $filterBy = array (self::COL_PARENTID => $parentId);
            $order = $this->getNextColumnValue (DBTable::COL_ORDER, $filterBy);
            }

        $criteria = array (new EqCriterion (self::COL_ID, $parentId));
        $cols = array (self::COL_PATH);
        $row = $this->selectSingleBy ($cols, $criteria);
        if (empty ($row) )
            {
            $this->context->addError ("Parent fragment not found.");
            return false;
            }

        $nameToValue = array
                            (
                            self::COL_PARENTID => $parentId,
                            self::COL_PATH => $row[self::COL_PATH].$parentId."_",
                            self::COL_TYPE => "TextFragment",
                            self::COL_TITLE => $this->getText ("Under construction"),
                            self::COL_DESCRIPTION => $this->getText ("Fragment is under construction."),
                            DBTable::COL_ORDER => $order,
                            self::COL_PUBLISHED => false
                            );

        // insert page record
        $id = $this->insertRecord ($nameToValue);
        if (false === $id)
            return false;

        $row = $this->selectSingleBy ($cols, $criteria);
        if (empty ($row) )
            {
            $this->context->addError ("Parent fragment not found.");
            return false;
            }

        $filterBy = array (new EqCriterion (self::COL_PARENTID, $parentId));
        if (!$last && false === $this->alterColumnValue ($filterBy, DBTable::COL_ORDER, "+1"))
            return false;

        return $id;
        }

    public function publishFragment ($id, $publish)
        {
        $criteria[] = new EqCriterion (self::COL_ID, $id);
        $criteria[] = new EqCriterion (self::COL_PUBLISHED, !$publish);
        $idCriteria[] = new EqCriterion (self::COL_ID, $id);
        $nameToValue = array (self::COL_PUBLISHED => $publish);
        return $this->updateById ($idCriteria, $criteria, $nameToValue);
        }

    public function wrapFragment ($id)
        {
        $criteria[] = new EqCriterion (self::COL_ID, $id);
        $fragment = $this->selectSingleBy (array (self::COL_PARENTID, self::COL_PATH, DBTable::COL_ORDER, self::COL_PUBLISHED), $criteria);
        
        if (empty ($fragment) || empty ($fragment[self::COL_PARENTID]))
            {
            $this->context->addError ("Parent fragment not found.");
            return false;
            }

        $criteria = array (new EqCriterion (self::COL_ID, $fragment[self::COL_PARENTID]));
        $parent = $this->selectSingleBy (array (self::COL_TEMPLATE), $criteria);
        
        if (empty ($fragment) || empty ($fragment[self::COL_PARENTID]))
            {
            $this->context->addError ("Parent fragment not found.");
            return false;
            }

        $nameToValue = array
                            (
                            self::COL_PARENTID => $fragment[self::COL_PARENTID],
                            self::COL_PATH => $fragment[self::COL_PATH],
                            self::COL_TYPE => self::TYPE_CONTAINER,
                            self::COL_TEMPLATE => "horizontal" == $parent[self::COL_TEMPLATE] ? "vertical" : "horizontal",
                            self::COL_TITLE => $this->getText ("Container"),
                            self::COL_DESCRIPTION => NULL,
                            DBTable::COL_ORDER => $fragment[DBTable::COL_ORDER],
                            self::COL_PUBLISHED => $fragment[self::COL_PUBLISHED]
                            );

        // insert page record
        $newParentId = $this->insertRecord ($nameToValue);
        if (false === $newParentId)
            {
            $this->context->addError ("Wrapping failed.");
            return false;
            }

        $nameToValue = array
                            (
                            self::COL_PARENTID => $newParentId,
                            self::COL_PATH => $fragment[self::COL_PATH].$newParentId."_",
                            DBTable::COL_ORDER => 1,
                            );

        $criteria = array (new EqCriterion (self::COL_ID, $id));
        return $this->updateById ($criteria, $criteria, $nameToValue);
        }

    public function deleteById ($criteria)
        {
        $id = $this->extractSingleIdFromCriteria ($criteria);

        $queryCriteria[] = new EqCriterion (self::COL_ID, $id);
        $fragment = $this->selectSingleBy (array (self::COL_PARENTID, self::COL_PATH, DBTable::COL_ORDER, self::COL_PUBLISHED), $queryCriteria);
        
        if (empty ($fragment))
            {
            $this->context->addError ("Fragment not found.");
            return false;
            }

        $queryCriteria = array (new EqCriterion (self::COL_PARENTID, self::COL_ID));
        $children = $this->selectSingleBy (array (new FunctionCount ("*", self::COL_ID)), $queryCriteria);
        if (!empty ($children) && $children[self::COL_ID] > 0)
            {
            $this->context->addError ("Fragment has children. Cannot delete it");
            return false;
            }

        // fix order and delete element
        $queryCriteria = array (new EqCriterion (self::COL_PARENTID, $fragment[self::COL_PARENTID]),
                                new GtCriterion (DBTable::COL_ORDER, $fragment[DBTable::COL_ORDER]));
        if (false === $this->deleteBy ($criteria) || false === $this->alterColumnValue ($queryCriteria, self::COL_ORDER, "-1"))
            return false;
        
        return true;
        }

    public function executeQuery ($query, $queryParams = NULL)
        {
        $rows = parent::executeQuery ($query, $queryParams);
        if (empty ($rows))
            return $rows;

        // transform serialized params into an array
        foreach ($rows as &$row)
            {
            if (!empty ($row[self::COL_PARAMS]))
                $row[self::COL_PARAMS] = unserialize ($row[self::COL_PARAMS]);
            else
                $row[self::COL_PARAMS] = NULL;
            }

        return $rows;
        }

    public function insertRecord ($nameToValue)
        {
        // serialize params array into a string
        if (array_key_exists (self::COL_PARAMS, $nameToValue))
            {
            if (is_array ($nameToValue[self::COL_PARAMS]))
                $nameToValue[self::COL_PARAMS] = serialize ($nameToValue[self::COL_PARAMS]);
            else
                $nameToValue[self::COL_PARAMS] = NULL;
            }
        return parent::insertRecord ($nameToValue);
        }

    protected function updateById ($idCriteria, $criteria, $nameToValue, $tracksRevisions = NULL)
        {
        // serialize params array into a string
        if (array_key_exists (self::COL_PARAMS, $nameToValue))
            {
            if (is_array ($nameToValue[self::COL_PARAMS]))
                $nameToValue[self::COL_PARAMS] = serialize ($nameToValue[self::COL_PARAMS]);
            else
                $nameToValue[self::COL_PARAMS] = NULL;
            }
        return parent::updateById ($idCriteria, $criteria, $nameToValue, $tracksRevisions);
        }

    }

class PageFragmentNode
    {
    public $id;
    public $row;
    public $children;

    public function __construct ($row)
        {
        $this->id = $row[FragmentsTable::COL_ID];
        $this->row = $row;
        }
    }

<?php

class Constants
    {
    const CONFIGSTATE_NOLANGUAGE       = 1;
    const CONFIGSTATE_NODB             = 2;
    const CONFIGSTATE_NOUSER           = 3;
    const CONFIGSTATE_NOSITESETTINGS   = 4;
    const CONFIGSTATE_NOMETADATA       = 5;
    const CONFIGSTATE_VERSIONMISMATCH  = 6;

    const CONFIGSTATE_BADCONNECTION    = 15;
    const CONFIGSTATE_NEEDSLOGIN       = 16;
    const CONFIGSTATE_READY            = 100;

    const PARAM_LANGUAGE = "lng";
    const PARAM_RETURN_TO = "return";
    const PARAM_PURGE = "_purge";
    const PARAM_RENDER_MODE = "render";
    const COOKIE_LANGUAGE = "lang";

    const ANY = "*";
    const TABLES_META = "m";
    const TABLES_SECURITY = "s";
    const TABLES_USER = "x";
    const TABLES_PREDEFINED = "c";

    const GUEST = 0;

    const JOIN_INNER = 1;
    const JOIN_LEFT_OUTER = 2;

    const SCOPE_PAGE = "page";

    const TEXTDOMAIN = "main";

    const PARENT = "__parent__";

    const MODE_VIEW = "view";
    const MODE_EDIT = "edit";
    const MODE_REVISIONS = "history";
    const MODE_SECTION_REVISIONS = "srev";
    const MODE_LOCATE = "find";
    const MODE_STATISTICS = "stats";
    };

// needed for smarty templates
define ("PARAM_LANGUAGE", Constants::PARAM_LANGUAGE);

?>

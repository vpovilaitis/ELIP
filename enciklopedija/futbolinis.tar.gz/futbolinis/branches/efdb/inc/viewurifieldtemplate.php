<?php

class ViewUriFieldTemplate extends LabelContentLinkFieldTemplate
    {
    protected $idColumns;
    protected $tableId;

    public function __construct ($tableId, $idColumns, $prefix, $key, $label)
        {
        parent::__construct ($prefix, $key, $label);
        $this->idColumns = $idColumns;
        $this->tableId = $tableId;
        }

    public function getUri ($context, $row)
        {
        $id = array ();
        foreach ($this->idColumns as $colname)
            $id[] = $row[$colname];

        return $this->createLink ($context, $this->tableId, $id);
        }
    }

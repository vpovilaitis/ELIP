<?php

class ValueTransformation
    {
    public $columnPrefix = "";
    public $columnName;

    public function __construct ($columnName)
        {
        $this->columnName = $columnName;
        }

    public function getValue ($context, $transformations, $row)
        {
        $key = $this->columnPrefix.$this->columnName;
        return isset ($row[$key]) ? $row[$key] : NULL;
        }

    public function adjust ($columnPrefix)
        {
        $this->columnPrefix = $columnPrefix;
        }
    }

class ColumnValueTransformation extends ValueTransformation
    {
    public $column;

    public function __construct ($columnName, $column)
        {
        parent::__construct ($columnName);
        $this->column = $column;
        }
    }

class BoolValueTransformation  extends ValueTransformation
    {
    public function getValue ($context, $transformations, $row)
        {
        $val = parent::getValue ($context, $transformations, $row);
        if ($val)
            return true;
        else if (NULL === $val)
            return $val;
        return false;
        }
    }

class TriggeredFieldValueTransformation extends ValueTransformation
    {
    public $columnDef;

    public function __construct ($columnDef)
        {
        parent::__construct ($columnDef->name);
        $this->columnDef = clone $columnDef;
        }

    public function getValue ($context, $transformations, $row)
        {
        $val = parent::getValue ($context, $transformations, $row);
        if (!empty ($val))
            return $val;
        $namesToColumns = array ();
        foreach ($this->columnDef->triggeredBy as $col)
            {
            if (empty ($row[$this->columnPrefix.$col]))
                $namesToColumns[$col] = NULL;
            else
                $namesToColumns[$col] = $row[$this->columnPrefix.$col];
            }

        return $this->columnDef->calculateValue ($context, $transformations, $namesToColumns);
        }
    }

class GhostColumnValueTransformation extends ValueTransformation
    {
    public $columnDef;

    public function __construct ($columnDef)
        {
        parent::__construct ($columnDef->name);
        $this->columnDef = clone $columnDef;
        }

    public function getValue ($context, $transformations, $row)
        {
        return $this->columnDef->calculateValue ($context, $transformations, $row, $this->columnPrefix);
        }
    }

class RelatedColumnValueTransformation extends ValueTransformation
    {
    public $idColumns;

    public function __construct ($name, $idColumns)
        {
        parent::__construct ($name);
        $this->idColumns = $idColumns;
        }

    public function getValue ($context, $transformations, $row)
        {
        $id = array ();
        foreach ($this->idColumns as $col)
            {
            if (empty ($row[$this->columnPrefix.$col->name]))
                $id[] = NULL;
            else
                $id[] = $row[$this->columnPrefix.$col->name];
            }
        if (array_sum ($id) == 0)
            return NULL;

        return $id;
        }

    }

?>

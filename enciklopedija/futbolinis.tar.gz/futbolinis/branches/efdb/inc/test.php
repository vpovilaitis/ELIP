<?php

abstract class Test
    {
    public $key;
    public $label;
    public $url;
    protected $input;
    protected $output;
    
    protected $errors = array ();

    public $message;
    public $messageClass;
    public $diagnosticMessage;

    const ID_PLACEHOLDER = "::id::";

    public function __construct ($key, $url, $label, $input, $expectedOutput)
        {
        $this->key = $key;
        $this->url = $url;
        $this->label = $label;
        $this->input = $input;
        $this->output = $expectedOutput;
        }

    protected abstract function processInput ($context, $input);

    protected function validateOutput ($context, $actualOutput, $expectedOutput)
        {
        if (is_array ($expectedOutput))
            {
            $error = $this->arrayDiff ($actualOutput, $expectedOutput);
            return true === $error;
            }

        return $actualOutput == $expectedOutput;
        }

    protected function validateNegativeOutput ($context, $actualOutput, $expectedOutput)
        {
        return $actualOutput != $expectedOutput;
        }

    protected function prepareOutputForDisplayIn ($output)
        {
        if (is_array ($output))
            {
            $out = array ();
            foreach ($output as $key => $val)
                {
                $out[$key] = $this->prepareOutputForDisplayIn ($val);
                }

            ksort ($out);
            return $out;
            }
        else if (is_object ($output))
            return $this->prepareOutputForDisplayIn (get_object_vars ($output));

        return $output;
        }
    protected function prepareOutputForDisplay ($context, $output)
        {
        return var_export ($this->prepareOutputForDisplayIn ($output), true);
        }

    protected function generateDiagnosticsMessage ($context, $input, $actualOutput, $expectedOutput)
        {
        if (!empty ($this->errors))
            {
            $this->diagnosticMessage .= "<b>Errors</b>:\n";

            foreach ($this->errors as $error)
                {
                $this->diagnosticMessage .= "$error\n";
                }

            $this->diagnosticMessage .= "\n\n";
            }

        $this->diagnosticMessage .= "<b>Input</b>:\n";
        $this->diagnosticMessage .= var_export ($input, true);
        $this->diagnosticMessage .= "\n\n";
        
        if ($actualOutput != $expectedOutput && is_array ($actualOutput))
            {
            $error = $this->arrayDiff ($actualOutput, $expectedOutput);
            if ($error)
                {
                $this->diagnosticMessage .= $error;
                $this->diagnosticMessage .= "\n\n";
                }
            }

        $expectedOutput = $this->prepareOutputForDisplay ($context, $expectedOutput);
        $actualOutput = $this->prepareOutputForDisplay ($context, $actualOutput);

        $this->diagnosticMessage .= '<table class="diff"><tr>';
        $this->diagnosticMessage .= "<td>Expected results:</td>";
        $this->diagnosticMessage .= "<td>Actual results:</td>";
        $this->diagnosticMessage .= '</tr><tr>';
        $this->diagnosticMessage .= '<td class="diff"><div>';
        $this->diagnosticMessage .= $expectedOutput;
        $this->diagnosticMessage .= "</div></td>";
        $this->diagnosticMessage .= '<td class="diff"><div>';
        $this->diagnosticMessage .= $actualOutput;
        $this->diagnosticMessage .= "</div></td>";
        $this->diagnosticMessage .= "</tr></table>";
        if (is_string ($expectedOutput) && is_string ($actualOutput))
            {
            for ($i = 0; $i < strlen($expectedOutput) && $i < strlen($actualOutput); $i++)
                {
                if ($expectedOutput[$i] != $actualOutput[$i])
                    {
                    $this->diagnosticMessage .= "\n\n";
                    $this->diagnosticMessage .= "Mismatch at pos. $i (...".substr ($expectedOutput, $i, 50)."...)";
                    break;
                    }
                }
            }
        }

    public function run ($context, $diagnose)
        {
        $oldErrorTarget = $context->setErrorTarget ($this);
        $output = $this->processInput ($context, $this->input);
        $context->setErrorTarget ($oldErrorTarget);
        $results = $this->validateOutput ($context, $output, $this->output);

        if ($diagnose)
            $this->generateDiagnosticsMessage ($context, $this->input, $output, $this->output);

        if (true === $results)
            {
            $this->message = $context->getText ("Test [_0] passed", $this->label);
            $this->messageClass = "testpass ui-state-highlight";
            return true;
            }
        else
            {
            $this->messageClass = "testfail ui-state-error";
            $this->message = (false === $results) ? $context->ngettext ("Test [_1] failed, [_0] error reported", "Test [_1] failed, [_0] errors reported", count ($this->errors), $this->label) : $results;
            return false;
            }
        }

    protected function arrayDiff ($actual, $expected, $prefix = NULL, $indent = "")
        {
        if (!is_array ($actual))
            {
            return "$indent - \"$prefix\" is not an array in parser result.\n";
            }
        if (!is_array ($expected))
            {
            return "$indent - \"$prefix\" is not an array in expected result.\n";
            }

        $result = "";

        foreach ($expected as $key => $val)
            {
            if (is_object ($val))
                $val = get_object_vars ($val);
            if (!array_key_exists ($key, $actual))
                $result .= "$indent - Key \"$prefix$key\" was not found in parser result.\n";
            else if (Test::ID_PLACEHOLDER === $val)
                {
                if ($actual[$key] <= 0)
                    $result .= "$indent - incorrect identifier value in \"$prefix$key\" was found.\n";
                }
            else if ($actual[$key] != $val)
                {
                if (is_array ($val))
                    {
                    $childErrors = $this->arrayDiff ($actual[$key], $val, $prefix.$key.".", "  ".$indent);
                    if (true !== $childErrors)
                        {
                        $result .= "$indent - Key \"$prefix$key\" value incorrect";
                        $result .= ":\n";
                        $result .= $childErrors;
                        }
                    }
                else
                    {
                    $expectedVal = $val;
                    $actualVal = $actual[$key];
                    $expectedChars = utf8_getchars ($expectedVal);
                    if (is_array ($actualVal))
                        $actualVal = json_encode ($actualVal);
                    $actualChars = utf8_getchars ($actualVal);
                    $maxLength = min (count ($expectedChars), count ($actualChars));
                    for ($i = 0; $i < $maxLength; $i++)
                        {
                        if ($expectedChars[$i] != $actualChars[$i])
                            break;
                        }

                    if ($i < count ($expectedChars))
                        $expectedVal = utf8_substr ($expectedVal, 0, $i)."<span class=\"diffhighlight\">".utf8_substr ($expectedVal, $i)."</span>";
                    if ($i < count ($actualChars))
                        $actualVal = utf8_substr ($actualVal, 0, $i)."<span class=\"diffhighlight\">".utf8_substr ($actualVal, $i)."</span>";
                    $result .= " <table width=\"100%\" style=\"table-layout:fixed\">".
                                "<tr><th width=\"50%\">expected</th><th width=\"1%\">!=</th><th width=\"50%\">'<pre>parsed</th></tr>".
                                "<tr><td>{$expectedVal}</pre></td><td>!=</td><td><pre>{$actualVal}</pre></td></tr>";
                    if ($i < count ($expectedChars) && $i < count ($actualChars))
                        $result .= "<tr><td align=\"center\">'{$expectedChars[$i]}' (".ord ($expectedChars[$i]).")</pre></td><td>!=</td><td align=\"center\"><pre>'{$actualChars[$i]}' (".ord ($actualChars[$i]).")</pre></td></tr>";
                    
                    $result .= "</table>";
                    }
                }
            }

        foreach ($actual as $key => $val)
            {
            if (!array_key_exists ($key, $expected))
                $result .= "$indent - Key \"$prefix$key\" was unexpected.\n";
            }

        return empty ($result) ? true : $result;
        }

    public function addError ($msg, $param1 = NULL, $param2 = NULL)
        {
        $this->addErrorPrepared (formatText ($msg, $param1, $param2));
        }

    public function addErrorPrepared ($error)
        {
        $this->errors[] = $error;
        }

    public function addMessage ($msg, $param1 = NULL, $param2 = NULL)
        {
        }

    }

class CallbackTest extends Test
    {
    protected $processor;
    protected $validator;

    public function __construct ($key, $url, $label, $input, $processorMethod, $expectedOutput, $validatorMethod = NULL)
        {
        parent::__construct ($key, $url, $label, $input, $expectedOutput);
        $this->processor = $processorMethod;
        $this->validator = $validatorMethod;
        }

    protected function processInput ($context, $input)
        {
        return call_user_func ($this->processor, $context, $input);
        }

    protected function validateOutput ($context, $actualOutput, $expectedOutput)
        {
        if (!empty ($this->validator))
            return call_user_func ($this->validator, $context, $actualOutput, $expectedOutput);

        return parent::validateOutput ($context, $actualOutput, $expectedOutput);
        }

    protected function generateDiagnosticsMessage ($context, $input, $actualOutput, $expectedOutput)
        {
        $this->diagnosticMessage .= "Executing callback ".(is_array ($this->processor) ? $this->processor[1] : $this->processor)."\n";
        parent::generateDiagnosticsMessage ($context, $input, $actualOutput, $expectedOutput);
        }
    }

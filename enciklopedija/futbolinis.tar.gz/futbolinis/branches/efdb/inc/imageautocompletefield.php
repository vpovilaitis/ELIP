<?php

class ImageAutocompleteField extends FieldTemplate
    {
    public function __construct ($prefix, $key, $label, $tooltip)
        {
        parent::__construct ($prefix, $key, "text", $label, $tooltip);
        }

    public function getServiceUrl ($context)
        {
        $url = $context->processUrl ("index.php?service=ImageSearchService", true);
        return $url;
        }
    }


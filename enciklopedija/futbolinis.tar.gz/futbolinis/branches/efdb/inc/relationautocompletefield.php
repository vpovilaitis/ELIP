<?php

class HiddenIdField extends HiddenFieldTemplate
    {
    public function getValueForDisplay ($context, $row)
        {
        $id = parent::getValueForDisplay ($context, $row);
        if (!empty ($id) && is_array ($id))
            return implode ("_", $id);
        return $id;
        }
    }

class RelationAutocompleteField extends FieldTemplate
    {
    protected $dbtable;
    protected $required;
    public $creatable;
    protected $idField;
    protected $initialLabelField;
    protected $createField;
    protected $serviceName;

    protected static $cachedLabels = array ();
    public $error;
    const LABEL_POSTFIX = "_label";
    const OLDVALUE_POSTFIX = "_c";

    public function __construct ($prefix, $dbtable, $key, $label, $tooltip, $required)
        {
        $context = $dbtable->getContext ();
        $this->idField = new HiddenIdField ($prefix, $key);
        $this->idField->renderId = true;
        $this->idField->cssClass = "autocomplete-id";
        $this->initialLabelField = new HiddenFieldTemplate ($prefix, $key.self::OLDVALUE_POSTFIX);
        $this->initialLabelField->renderId = true;
        $this->initialLabelField->cssClass = "";

        $this->creatable = $dbtable->canCreateFromLabel ();
        if ($this->creatable)
            {
            $this->createField = new CheckBoxFieldTemplate ($prefix, $key."_new",
                                            $context->getText ("Create"),
                                            $context->getText ("Create new instance"));
            $this->createField->renderId = true;
            }

        parent::__construct ($prefix, $key, NULL, $label, $tooltip);
        $this->dbtable = $dbtable;
        $this->required = $required;
        $this->cssClass = "autosuggest";
        $context->addScriptFile ("autosuggest");
        }

    protected function createItem ($label)
        {
        $context = $this->dbtable->getContext ();
        $id = $this->dbtable->createFromLabel ($label);
        if (false === $id)
            {
            $context->addError ("Error while creating a new record for field $this->label");
            return NULL;
            }

        if (is_numeric ($id))
            $id = array ($id);
        return $id;
        }

    public function processInput ($context, &$request)
        {
        $initialValue = $this->initialLabelField->getValueForDB ($context, $request);
        $newValue = isset ($request[$this->key.self::LABEL_POSTFIX]) ? $request[$this->key.self::LABEL_POSTFIX] : NULL;
        if ($initialValue == $newValue) // nothing changed
            return true;

        $request[$this->idField->key] = NULL;
        if (empty ($newValue))
            return true;

        if ($this->creatable && isset ($request[$this->createField->key]))
            {
            $createNew = $request[$this->createField->key];
            if ($createNew)
                {
                $id = $this->createItem ($newValue);
                if (empty ($id))
                    return false;

                $request[$this->idField->key] = $id;
                $request[$this->initialLabelField->key] = $newValue;
                $request[$this->key.self::LABEL_POSTFIX] = $newValue;
                $request[$this->createField->key] = false;
                return true;
                }
            }

        $params[] = new FilterCriterion ($newValue);
        $list = $this->dbtable->getPickList (NULL, 2, NULL, $params);

        if (empty ($list))
            {
            $this->error = $context->getText ("No matches found");
            return false;
            }

        if (count ($list) > 1)
            {
            $this->error = $context->getText ("More than one match found");
            return false;
            }

        foreach ($list as $id => $label)
            {
            $request[$this->idField->key] = $id;
            $request[$this->initialLabelField->key] = $label;
            $request[$this->key.self::LABEL_POSTFIX] = $label;
            break;
            }

        return true;
        }

    public function getValueForDB ($context, $request, $index = NULL)
        {
        $id = $this->idField->getValueForDB ($context, $request);

        if (empty ($id))
            return NULL;

        if (!is_array ($id))
            return explode ("_", $id);

        return $id;
        }

    public function getValueForDisplay ($context, $row)
        {
        if (!empty ($row[$this->key.self::LABEL_POSTFIX]))
            return $row[$this->key.self::LABEL_POSTFIX];

        return NULL;
        }

    public function forceValue (&$request, $id, $label)
        {
        $request[$this->key.self::LABEL_POSTFIX] = $label;
        $request[$this->idField->key] = $id;
        if (!empty ($id))
            $request[$this->initialLabelField->key] = $label;
        }

    public static function cacheLabel ($id, $label)
        {
        if (is_array ($id))
            $id = implode ("_", $id);
        self::$cachedLabels[$id] = $label;
        }

    public static function getCachedDisplayName ($request, $key, $dbtable, $id)
        {
        if (is_array ($id))
            $strId = implode ("_", $id);
        else
            $strId = $id;

        if (isset (self::$cachedLabels[$strId]))
            return self::$cachedLabels[$strId];

        if (!empty ($request[$key.".".ContentTable::COL_DISPLAY_NAME]))
            return $request[$key.".".ContentTable::COL_DISPLAY_NAME];

        return $dbtable->getDisplayNameById ($id, true);
        }

    public function preprocessLoadedValue (&$request, $existingRecord, $index = NULL)
        {
        $id = $this->getIdValue ($this->dbtable->getContext (), $request);

        if (empty ($id))
            return;

        $request[$this->idField->key] = $id;

        if (!is_array ($id))
            $id = explode ("_", $id);

        $initialValue = self::getCachedDisplayName ($request, $this->key, $this->dbtable, $id);

        $request[$this->key.self::LABEL_POSTFIX] = $initialValue;
        $request[$this->initialLabelField->key] = $initialValue;
        }

    public function getTemplateName ()
        {
        return "autosuggest";
        }
        
    public function getInitializeScript ($fieldId)
        {
        if ($this->canCreate())
            $notFound = $this->dbtable->getContext()->getText ("If no match fits, select this to <b>create new</b> record");
        else
            $notFound = $this->dbtable->getContext()->getText ("No matches found");
        return "suggest_attach (\"{$fieldId}\", \"{$this->getServiceUrl()}\", ".($this->canCreate()?"true":"false").", ".($this->canContainNumber() ? "true" : "false").", '$notFound');";
        }

    public function setPrefix ($prefix)
        {
        parent::setPrefix ($prefix);
        $this->initialLabelField->setPrefix ($prefix);
        $this->idField->setPrefix ($prefix);
        if (!empty ($this->createField))
            $this->createField->setPrefix ($prefix);
        }

    public function getIdValue ($context, $row)
        {
        $id = $this->idField->getValueForDisplay ($context, $row);
        if (empty ($id))
            return NULL;

        return is_array ($id) ? implode ("_", $id) : $id;
        }

    public function setServiceName ($service)
        {
        $this->serviceName = $service;
        }

    public function getServiceUrl ()
        {
        if (empty ($this->serviceName))
            $this->serviceName = "ContentService";
        $url = "index.php?service=$this->serviceName&id=".$this->dbtable->getId ();
        $context = $this->dbtable->getContext ();
        $url = $context->processUrl ($url, true);
        return $url;
        }

    public function getContentUrl ()
        {
        $context = $this->dbtable->getContext ();
        $mode = Constants::MODE_VIEW;
        $tableId = $this->dbtable->getId ();
        return $context->processUrl ("index.php?c=ContentPage&mode=$mode&tid=$tableId")."&id=";
        }

    public function getFields ()
        {
        $arr = array ($this->idField, $this->initialLabelField);

        if ($this->creatable)
            $arr[] = $this->createField;
        return $arr;
        }

    public function canContainNumber ()
        {
        return false;
        }

    public function canCreate ()
        {
        return $this->creatable;
        }
    }

<?php

class RelationDropDownFieldTemplate extends DropDownFieldTemplate
    {
    protected static $cached = array ();

    public function __construct ($prefix, $key, $label, $tooltip, $picklist)
        {
        parent::__construct ($prefix, $key, $label, $tooltip, $picklist);
        }

    public static function createInstance ($context, $prefix, $relationColumn)
        {
        $relatedTable = ContentTable::createInstanceById ($context, $relationColumn->relatedTableId);

        if (MetaDataColumns::INPUT_AUTOCOMPLETE == $relationColumn->inputType)
            {
            return new RelationAutocompleteField ($prefix, $relatedTable,
                                                  $relationColumn->name,
                                                  $relationColumn->label,
                                                  $relationColumn->description,
                                                  $relationColumn->required);
            }

        $key = $relationColumn->relatedTableId."|".$relationColumn->required;
        if (!array_key_exists ($key, self::$cached))
            {
            $values = empty ($relatedTable) ? array () : $relatedTable->getPickList ();
            if (!$relationColumn->required)
                {
                $noneItem = $relationColumn->getNoneItem ($context);
                if (empty ($values))
                    $values = array ($noneItem);
                else
                    {
                    $allValues = array (NULL => $noneItem);
                    foreach ($values as $key => $val)
                        $allValues[$key] = $val;
                    $values = $allValues;
                    }
                }

            self::$cached[$key] = $values;
            }
        else
            $values = self::$cached[$key];

        if (!empty ($relatedTable) && $relatedTable->canCreateFromLabel ())
            return new CreatableRelationDropDownFieldTemplate ($context, $relatedTable, $prefix, $relationColumn, $values);
        return new RelationDropDownFieldTemplate ($prefix, $relationColumn->name,
                                                  $relationColumn->label,
                                                  $relationColumn->description, $values);
        }

    public function getValueForDB ($context, $request, $index = NULL)
        {
        $val = parent::getValueForDB ($context, $request, $index);
        if (empty ($val))
            return NULL;

        if (CreatableDropDownFieldTemplate::NEW_ITEM == $val)
            return $val;

        return explode ("_", $val);
        }

    public function getValueForDisplay ($context, $row)
        {
        if (empty ($row[$this->key]))
            return NULL;

        if (is_array ($row[$this->key]))
            return implode ("_", $row[$this->key]);
        else
            return $row[$this->key];
        }

    }

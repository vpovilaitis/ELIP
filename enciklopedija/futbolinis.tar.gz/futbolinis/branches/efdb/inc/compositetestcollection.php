<?php

abstract class CompositeTestCollection extends  TestCollection
    {
    protected $dependencies = NULL;

    public function enumerateTests ($context)
        {
        $this->ensureDependencies ();
        $tests = array ();
        foreach ($this->dependencies as $dep)
            {
            $tests = array_merge ($tests, $dep->getTests ());
            }

        return $tests;
        }

    protected function ensureDependencies ()
        {
        if (NULL === $this->dependencies)
            $this->dependencies = $this->enumerateDependencies ($this->context, $this->parentComponent);
        }

    public function cleanup ($context)
        {
        if (empty ($this->dependencies))
            return;

        foreach (array_reverse ($this->dependencies) as $dep)
            $dep->cleanup ($context);
        }
    }

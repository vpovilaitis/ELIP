<?php

class RelatedUrlTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "relatedurl";

    const COL_ID = "id";
    const COL_SCOPE = "scope"; // 'm_fragments', 'x_persons', etc
    const COL_CONTEXTID = "contextid";
    const COL_LABEL = "label";
    const COL_URL = "url";
    const COL_PRIORITY = "priority";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        $this->tracksRevisions = true;
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID, false),
                     new TextColumn (self::COL_SCOPE, 128, false),
                     new TextColumn (self::COL_CONTEXTID, 32, false),
                     new TextColumn (self::COL_LABEL, 128, false),
                     new TextColumn (self::COL_URL, 1024, false),
                     new IntColumn (self::COL_PRIORITY, false),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new Index (self::COL_SCOPE, self::COL_CONTEXTID, self::COL_PRIORITY),
            );
        }

    const PRIORITY_AUTO = 0;
    const PRIORITY_OFFICIAL = 10;
    const PRIORITY_UEFA = 20;
    const PRIORITY_SOCCERWAY = 30;
    const PRIORITY_FUTBOLINIS = 40;
    const PRIORITY_FOOT_DK = 50;
    const PRIORITY_WELTFUSS = 60;
    const PRIORITY_OTHER = 1000;

    public static function getDefaultSelection ($context)
        {
        $types = array (self::PRIORITY_AUTO => $context->getText ("defined by url"),
                        self::PRIORITY_OFFICIAL => $context->getText ("Official site"),
                        self::PRIORITY_UEFA => "UEFA.com",
                        self::PRIORITY_SOCCERWAY => "Soccerway.com",
                        self::PRIORITY_FOOT_DK => "Foot.dk",
                        self::PRIORITY_WELTFUSS => "Weltfussballarchiv.com",
                        self::PRIORITY_FUTBOLINIS => "Futbolinis",
                        self::PRIORITY_OTHER => "Other",
                        );
        return $types;
        }

    public static function adjustPriority ($priority, $url)
        {
        if (self::PRIORITY_AUTO != $priority)
            return $priority;

        if (preg_match ("#uefa\.com/#u", $url, $matches) > 0)
            return self::PRIORITY_UEFA;
        else if (preg_match ("#soccerway\.com/#u", $url, $matches) > 0)
            return self::PRIORITY_SOCCERWAY;
        else if (preg_match ("#foot\.dk/#u", $url, $matches) > 0)
            return self::PRIORITY_FOOT_DK;
        else if (preg_match ("#weltfussballarchiv\.com/#u", $url, $matches) > 0)
            return self::PRIORITY_WELTFUSS;
        else if (preg_match ("#futbol(inis|oenciklopedija)\.lt/#u", $url, $matches) > 0)
            return self::PRIORITY_FUTBOLINIS;
        else
            return self::PRIORITY_OTHER;

        return $priority;
        }

    public static function getLabel ($context, $priority, $url)
        {
        $label = NULL;
        switch ($priority)
            {
            case self::PRIORITY_OFFICIAL:
                $label = $this->getText ("Official site");
                break;
            case self::PRIORITY_UEFA:
                $label = "UEFA.com";
                break;
            case self::PRIORITY_SOCCERWAY:
                $label = "soccerinfo.com";
                break;
            case self::PRIORITY_FUTBOLINIS:
                $label = "FutboloEnciklopedija.lt";
                break;
            case self::PRIORITY_OTHER:
            default:
                if (preg_match ("#^(ftp|https?)://([^/]+)(/.+)?$#", $url, $matches) > 0)
                    $label = $matches[2];
                else
                    $label = $context->getText ("Other");
                break;
            }
        return $label;
        }

    public function removeEntry ($criteria)
        {
        return $this->deleteBy ($criteria, false);
        }
    }

<?php
class OptionColumn extends GhostColumn
    {
    protected $mask;

    public function __construct ($name, $optionsColumn, $mask)
        {
        parent::__construct ($name);
        $this->triggeredBy = array ($optionsColumn);
        $this->mask = $mask;
        }

    public function calculateValue ($context, $transformations, $row, $columnPrefix = NULL)
        {
        if (NULL == $columnPrefix)
            $columnPrefix = "";
        $val = $row[$columnPrefix.$this->triggeredBy[0]];
        if ($this->mask == ($val & $this->mask))
            return true;
        return false;
        }

    public function adjustStoredValues (&$namesToValues, $columnValue)
        {
        parent::adjustStoredValues ($namesToValues, $columnValue);
        $val = 0;
        if (isset ($namesToValues[$this->triggeredBy[0]]))
            $val = $namesToValues[$this->triggeredBy[0]];

        $val = $columnValue ? ($val | $this->mask) : ($val & (0xffffffff - $this->mask));
        $namesToValues[$this->triggeredBy[0]] = $val;
        }
    }

class MetaDataTables extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_META;
    const TABLE_NAME = "tables";

    const COL_TABLEID = "tableid";
    const COL_NAME = "name";
    const COL_PARENTID = "parentid"; // for the child tables (for example, "tablecolumns" is child of "tables")
    const COL_VERSION = "version";
    const COL_ISCREATED = "iscreated";
    const COL_LABEL = "label";
    const COL_DESCRIPTION = "description";
    const COL_OPTIONS = "options";
    const COL_REVISIONS = "revisions"; // every change is persisted in revision table
    const COL_OWNERCANREMOVE = "ownerremove";
    const COL_SOURCES = "sources";
    const COL_INTEGRATED = "integrated";
    const COL_PARENTSORTORDER = "psortorder";
    const COL_PARENTSORTASC = "psortasc";

    /* custom handler class (for example, if handler is "sports/ClubsTable",
       file ./sports/clubstable.php will be included and ClubsTable instance created */
    const COL_HANDLER = "handler";

    const OPTION_REVISIONS = 0x0001;
    const OPTION_SOURCES = 0x0002;
    const OPTION_OWNERREMOVE = 0x0004;

    private $skipAccessChecks = NULL;

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, true);
        $this->defaultOrderBy = array (new OrderByColumn (self::COL_LABEL));
        }

    protected function getColumns ()
        {
        $version = new IntColumn (self::COL_VERSION);
        $version->defaultValue = 1;
        $isCreated = new BoolColumn (self::COL_ISCREATED);
        $isCreated->defaultValue = false;

        return array (
                     new AutoincrementColumn (self::COL_TABLEID),
                     new TextColumn (self::COL_NAME, 64),
                     new IntColumn (self::COL_PARENTID, true),
                     new TextColumn (self::COL_HANDLER, 128, true),
                     $version,
                     $isCreated,
                     new IntColumn (self::COL_OPTIONS),
                     new IntColumn (self::COL_PARENTSORTORDER, true),
                     new BoolColumn (self::COL_PARENTSORTASC, true),
                     new OptionColumn (self::COL_REVISIONS, self::COL_OPTIONS, self::OPTION_REVISIONS),
                     new OptionColumn (self::COL_SOURCES, self::COL_OPTIONS, self::OPTION_SOURCES),
                     new OptionColumn (self::COL_OWNERCANREMOVE, self::COL_OPTIONS, self::OPTION_OWNERREMOVE),
                     );
        }
        
    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (self::COL_LABEL, 64, true),
                     new TextColumn (self::COL_DESCRIPTION, 255, true),
                     new TextColumn (self::COL_INTEGRATED, 255, true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new UniqueIndex (self::COL_NAME));
        }

    public function create ($parentId, $name, $label, $description, $handler, $version, $trackRevisions, $trackSources, $ownerCanRemove, $columns)
        {
        $values = array (self::COL_NAME => $name, self::COL_PARENTID => $parentId,
                         self::COL_REVISIONS => $trackRevisions, self::COL_SOURCES => $trackSources,
                         self::COL_OWNERCANREMOVE => $ownerDelete, self::COL_ISCREATED => false);

        if (!empty ($label))
            $values[self::COL_LABEL] = $label;
        if (!empty ($description))
            $values[self::COL_DESCRIPTION] = $description;
        if (!empty ($version))
            $values[self::COL_VERSION] = $version;
        if (!empty ($handler))
            $values[self::COL_HANDLER] = $handler;

        $tableId = parent::insertRecord ($values);
        if (false === $tableId)
            return false;

        $cache = Cache::getInstance ("metatables", 12*60*60);
        $cache->clean ();

        $columnsTable = new MetaDataColumns ($this->context);
        $i = 0;

        foreach ($columns as $col)
            {
            if (!$col instanceof TableColumn)
                {
                $this->context->addError ("Incorrect column argument passed");
                return false;
                }

            if (false === $columnsTable->create ($tableId, ++$i, $col))
                {
                return false;
                }
            }

        return $tableId;
        }

    public function deleteById ($criteria)
        {
        $id = $this->extractSingleIdFromCriteria ($criteria);

        $indexTable = new MetaDataIndexes ($this->context);
        $columnsTable = new MetaDataColumns ($this->context);
        $contentTable = ContentTable::createInstanceById ($this->context, $id);

        if (!parent::deleteById ($criteria))
            return false;

        $cache = Cache::getInstance ("metatables", 12*60*60);
        $cache->clean ();

        if (empty ($contentTable))
            {
            $this->context->addMessage ("Content table instance does not exist ([_0])", $id);
            return true;
            }

        if (false === $contentTable->deleteTable (true) ||
            false === $indexTable->deleteByTable ($id) ||
            false === $columnsTable->deleteByTable ($id))
            {
            return false;
            }

        return true;
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = 1)
        {
        $ret = parent::updateRecord ($criteria, $nameToValue, $maxRows);
        $cache = Cache::getInstance ("metatables", 12*60*60);
        $cache->clean ();
        return $ret;
        }

    public function updateTable ($tableId, $updateValues)
        {
        return $this->updateRecord (array (new EqCriterion (self::COL_TABLEID, $tableId)), $updateValues);
        }

    public function updateTableIsCreated ($tableId, $isCreated)
        {
        $this->skipAccessChecks = true;
        $ret = $this->updateTable ($tableId, array (MetaDataTables::COL_ISCREATED => $isCreated));
        $this->skipAccessChecks = false;
        return $ret;
        }

    public function canEdit ()
        {
        if (true === $this->skipAccessChecks)
            return true;
        return parent::canCreate ();
        }


    public static function getMetaClassNames ($context)
        {
        $classes = array ("MetaDataTables", "MetaDataColumns",
                          "MetaDataIndexes", "MetaDataIndexColumns",
                          "PageNamesTable", "FragmentsTable",
                          "DiscussionTopicTable", "DiscussionsTable",
                          "HintsTable", "QuickLinksTable");
        return $classes;
        }

    public static function isDeployed ($context, $dbconn)
        {
        $classes = self::getMetaClassNames ($context);
        $tables = array();
        for ($i = 0; $i < count ($classes); $i++)
            {
            $class = $classes[$i];
            $instance = new $class ($context);
            $table = $instance->getTableName ();
            $tables[] = $table;
            $table = $instance->getStringTableName ();
            if (NULL != $table)
                $tables[] = $table;
            }

        return $dbconn->tablesExists ($tables);
        }
    }

?>

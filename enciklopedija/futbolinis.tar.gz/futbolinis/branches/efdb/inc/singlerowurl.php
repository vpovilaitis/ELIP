<?php

class SingleRowURL extends LinkAction
    {
    protected $url;
    protected $preprocessed;
    public function __construct ($component, $key, $tooltip, $url, $preprocessed = false)
        {
        parent::__construct ($component, $key, $tooltip, $url);
        $this->preprocessed = $preprocessed;
        }

    public function isVisible ($row = NULL)
        {
        return NULL != $row;
        }

    public function getUrl ($request, $id)
        {
        $url = $this->url;
        if (false === strstr ($url, "?"))
            $url .= "?";
        else
            $url .= "&";

        $url = $url."id=$id";
        if (!$this->preprocessed)
            $url = $this->context->processUrl ($url, true);
        return $url;
        }

    public function requiresId ()
        {
        return true;
        }

    public function getLabel ()
        {
        return $this->tooltip;
        }

    public function getTemplateName ()
        {
        return "linkaction";
        }
    }

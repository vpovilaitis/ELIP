<?php
require_once (PATH."inc/fragmentstable.php");

class PageNamesTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_META;
    const TABLE_NAME = "pagenames";

    const COL_NAME = "name";
    const COL_FRAGMENTID = "fragmentid";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        }

    protected function getColumns ()
        {
        return array (
                     new TextColumn (self::COL_NAME, 64),
                     new IntColumn (self::COL_FRAGMENTID, true),
                     );
        }
        
    protected function getTranslatableColumns ()
        {
        return NULL;
        }

    protected function getIndexes ()
        {
        return array
            (
            new UniqueIndex (self::COL_NAME),
            new Index (self::COL_FRAGMENTID),
            );
        }

    public function getDisplayNameById ($id)
        {
        if (empty ($id))
            return NULL;

        $fragmentsTable = new FragmentsTable ($this->context);
        if (empty ($fragmentsTable))
            {
            $this->context->log ("Tables not created in the database");
            return NULL;
            }

        $criteria = array (new EqCriterion (FragmentsTable::COL_ID, $id));
        $rows = $fragmentsTable->selectBy (array (FragmentsTable::COL_TITLE), $criteria);
        if (empty ($rows))
            return $this->getText ("Unknown page");

        $row = $rows[0];
        return $row[FragmentsTable::COL_TITLE];
        }

    public function getContentLink ($id)
        {
        $criteria = array (new EqCriterion (self::COL_FRAGMENTID, $id));
        $rows = $this->selectBy (array (self::COL_NAME), $criteria);
        if (empty ($rows))
            return $this->getText ("Unknown page");

        $row = $rows[0];
        $pageName = $row[self::COL_NAME];
        return $this->context->chooseUrl ("page/$pageName",
                                          "index.php?page=$pageName");
        }
    }

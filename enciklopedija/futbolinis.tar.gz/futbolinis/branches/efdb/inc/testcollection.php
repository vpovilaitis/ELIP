<?php

require_once (PATH."inc/component.php");
require_once (PATH."inc/test.php");

abstract class TestCollection extends BaseWithContext
    {
    protected $prefix;
    protected $rootTest;
    protected $parentComponent;
    protected $tests = NULL;
    protected $id = 0;
    protected $passCount;
    protected $failCount;

    public function __construct ($prefix, $context, $parent, $rootTest = NULL)
        {
        parent::__construct ($context);
        $this->parentComponent = $parent;
        $this->prefix = $prefix;
        $this->rootTest = NULL === $rootTest ? get_class ($this) : $rootTest;
        }

    public function getLabel ()
        {
        return get_class ($this);
        }

    public function getActionList ()
        {
        $actions = array ();
        if (method_exists ($this, 'prepareTest'))
            $actions[] = new SimpleLinkAction ($this, "prepare", $this->getText ("Prepare"), $this->parentComponent->getTestActionUrl (get_class ($this), "prepare"), true);

        $actions[] = new SimpleLinkAction ($this, "run", $this->getText ("Run"), $this->parentComponent->getExecuteTestUrl (get_class ($this)), true);

        return $actions;
        }

    public function run ($context, $diagnoseTest = NULL, $atomic = false)
        {
        // should only work in test perspective scope
        $perspective = $context->setPerspective ("tests");

        $this->ensureTests ();
        $this->passCount = $this->failCount = 0;

        foreach ($this->tests as &$test)
            {
            if (!$atomic && !empty ($diagnoseTest) && $diagnoseTest != $test->key)
                continue;

            $pass = $test->run ($context, $diagnoseTest == $test->key);
            if ($pass)
                $this->passCount++;
            else
                $this->failCount++;
            }

        $context->setPerspective ($perspective);
        $this->cleanup ($context);
        }

    public function diagnose ($context, $testToDiagnose)
        {
        $this->run ($context, $testToDiagnose);
        }

    public function cleanup ($context)
        {
        }

    public function executeAction ($context, $action)
        {
        if ("prepare" == $action && method_exists ($this, 'prepareTest'))
            $this->prepareTest ($context);
        }

    protected function getNextKey ()
        {
        return "{$this->prefix}_".(++$this->id);
        }

    protected function getDiagnoseUrl ($key)
        {
        return $this->parentComponent->getDiagnoseTestUrl ($this->rootTest, $key);
        }

    protected function createTest ($label, $input, $processorMethod, $expectedOutput, $validatorMethod = NULL, $testClass = "CallbackTest")
        {
        $key = $this->getNextKey ();
        $url = $this->getDiagnoseUrl ($key);
        $test = new $testClass ($key, $url, $label, $input, $processorMethod, $expectedOutput, $validatorMethod);
        return $test;
        }

    public abstract function enumerateTests ($context);

    public function areTestsDisplayed ()
        {
        return $this->passCount + $this->failCount > 0;
        }

    public function getSummaryText ()
        {
        return $this->context->getText ("Passed: [_0], failed: [_1]", $this->passCount, $this->failCount);
        }

    public function getSummaryClass ()
        {
        return $this->failCount > 0 ? "testfail" : ($this->passCount > 0 ? "testpass" : "");
        }

    public function getTests ()
        {
        $this->ensureTests ();
        return $this->tests;
        }

    protected function ensureTests ()
        {
        if (NULL === $this->tests)
            $this->tests = $this->enumerateTests ($this->context);
        }
    }

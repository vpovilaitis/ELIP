<?php

class Cache
    {
    protected static $useCacheLite = NULL;
    protected static $cacheInstances = array ();

    protected $wrappedInstance;
    protected $purge;
    protected $context;
    protected $lastId;
    protected $cacheOutput;
    protected $group;

    private function __construct ($context, $wrappedInstance, $group, $cacheOutput)
        {
        $this->context = $context;
        $this->wrappedInstance = $wrappedInstance;
        $this->purge = !empty ($context->request[Constants::PARAM_PURGE]);
        $this->group = $group;
        $this->cacheOutput = $cacheOutput;
        }

    public static function getInstance ($group, $lifetime, $outputCaching = false)
        {
        $lifetime = (NULL === $lifetime) ? 6 * 60 * 60 /* 6 hours */ : $lifetime;
        $instanceKey = $group."#".$lifetime."#".($outputCaching ? "1" : "0");

        if (!array_key_exists ($instanceKey, self::$cacheInstances))
            {
            $context = PageContext::getInstance ();
            $className = $outputCaching ? "Cache_Lite_Output" : "Cache_Lite";

            if (NULL === self::$useCacheLite)
                {
                $includePath = $outputCaching ? PATH.'cache-lite/Lite/Output.php' : PATH.'cache-lite/Lite.php';
                if (file_exists ($includePath))
                    self::$useCacheLite = include_once ($includePath);
                else
                    self::$useCacheLite = false;

                $context->log (self::$useCacheLite ? "Cache enabled using $className" : "$className not found. Caching disabled.");
                }

            $wrapped = NULL;
            if (self::$useCacheLite)
                {
                $dir = dirname(__FILE__).'/../cache/'.$context->getLanguage ().'/';
                if (!is_dir ($dir))
                    @mkdir ($dir);
                $dir .= $group.'/';
                if (!is_dir ($dir))
                    @mkdir ($dir);
                $options = array ('cacheDir' => $dir,
                                  'lifeTime' => $lifetime,
                                  'automaticSerialization' => true, 'hashedDirectoryLevel' => 0, 'fileNameProtection' => false,
                                  'automaticCleaningFactor' => 0
                                  );
                if (DEBUG)
                    $options["pearErrorMode"] = CACHE_LITE_ERROR_DIE;
                $wrapped = new $className ($options);
                }

            self::$cacheInstances[$instanceKey] = new Cache ($context, $wrapped, $group, $outputCaching);
            }

        return self::$cacheInstances[$instanceKey];
        }

    /* fake functions to simulate cache (cache is never hit) */
    public function setOption ($name, $value) 
        {
        if (NULL === $this->wrappedInstance)
            return;

        $this->wrappedInstance->setOption ($name, $value);
        }

    public function get ($id)
        {
        if (NULL === $this->wrappedInstance)
            return false;

        if ($this->purge)
            $this->wrappedInstance->clean ($this->group);
        $this->lastId = $id;
        $newId = $this->context->getLanguageCode()."_".$id;
        $ret = $this->wrappedInstance->get ($newId, $this->group);
        if (false === $ret)
            $this->context->log ("Cache miss ($id)");

        return $ret;
        }

    public function save ($data, $id = NULL)
        {
        if (NULL === $this->wrappedInstance)
            return true;

        if (NULL !== $id)
            $id = $this->context->getLanguageCode()."_".$id;

        $this->context->log ("Storing $this->lastId to cache");
        return $this->wrappedInstance->save ($data, $id, $this->group);
        }

    public function remove ($id, $checkbeforeunlink = false)
        {
        if (NULL === $this->wrappedInstance)
            return;

        $id = $this->context->getLanguageCode()."_".$id;
        return $this->wrappedInstance->remove ($id, $this->group, $checkbeforeunlink);
        }

    function clean ($mode = 'ingroup')
        {
        if (NULL === $this->wrappedInstance)
            return;

        $this->context->log ("Cleaning $this->group cache");
        return $this->wrappedInstance->clean ($this->group, $mode);
        }

    public function start ($id, $doNotTestCacheValidity = false)
        {
        if (NULL === $this->wrappedInstance || !$this->cacheOutput)
            return false;

        if ($this->purge)
            $this->wrappedInstance->clean ($this->group);
        return $this->wrappedInstance->start ($id, $this->group, $doNotTestCacheValidity);
        }

    public function end ()
        {
        if (NULL === $this->wrappedInstance || !$this->cacheOutput)
            return false;

        return $this->wrappedInstance->end ();
        }
    }

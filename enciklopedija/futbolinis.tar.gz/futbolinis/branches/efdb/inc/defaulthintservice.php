<?php
require_once (PATH.'inc/hintstable.php');

class DefaultHintService extends BaseWithContext
    {
    public function getHint ($scope, $contextMode, $targetGroup, $contextId)
        {
        if (HintsTable::SCOPE_PAGES == $scope) 
            $hints = $this->getPredefinedPageHint ($contextMode, $targetGroup);
        else if (0 === strncasecmp ($scope, HintsTable::SCOPE_CONTENTTABLE, strlen (HintsTable::SCOPE_CONTENTTABLE)))
            $hints = $this->getPredefinedContentHint (substr ($scope, strlen (HintsTable::SCOPE_CONTENTTABLE)), $contextMode, $targetGroup, $contextId);

        if (empty ($hints))
            $hints = array ();

        $dbtable = new HintsTable ($this->context); 
        $rows = $dbtable->selectHints ($scope, $contextMode, $targetGroup, $contextId);
        if (!empty ($rows))
            $hints = array_merge ($hints, $rows);

        if (empty ($hints))
            return NULL;
        $idx = 0;
        if (count ($hints) > 1)
            $idx = mt_rand (0, count ($hints)-1); 
        return $hints[$idx];
        }

    protected function getPredefinedPageHint ($contextMode, $targetGroup)
        {
        $isEditor = $targetGroup == HintsTable::TARGET_EDITOR;
        $ret = array ();
        if ($isEditor)
            $ret[] = self::composeHint ($this->getText ("Spotted a gramatical error?"),
                                        $this->getText ("If you have found some small error in the text of this page, just click the \"Edit Layout\" link, select a page fragment you want to edit and click the \"Edit\" button just above the fragment. Remember, every change is recorded, so there is a way to recover previous state if you make some mistake."));
        return $ret;
        }

    protected function getPredefinedEditProposal ($table, $contextId)
        {
        return array (
                   self::composeHint ($this->getText ("Interested in contributing?"),
                                      $this->getText ("Register a user name in a few clicks and you will be able to edit this instance. No need to enter any personal information and no confirmations needed to begin editing. Just click on the \"Login\" link on the right side of the page."))
                     );
        }

    protected function getPredefinedViewHint ($table, $isEditor, $contextId)
        {
        if (!$isEditor)
            {
            $access = UsersTable::getDefaultGroupAccess ($this->context, Constants::TABLES_USER, $table);
            if (!empty ($access) && !empty ($access["canedit"]))
                return $this->getPredefinedEditProposal ($table, $contextId);
            }
        else
            return $this->getPredefinedEditorViewHint ($table, $contextId);
        return NULL;
        }
    
    protected function getPredefinedEditorViewHint ($table, $contextId)
        {
        return NULL;
        }

    protected function getPredefinedPreviewHint ($table, $isEditor)
        {
        return array (
                   self::composeHint ($this->getText ("Searching for something?"),
                                      $this->getText ("If you are searching for some specific record, you do not need to browse all the pages. Just locate the search field above top-right corner of the list, enter the criteria and click the \"Go\" button.")),
                     );
        }
    
    protected function getPredefinedEditHint ($table, $isEditor)
        {
        return NULL;
        }
    
    protected function getPredefinedHistoryHint ($table, $isEditor, $contextId)
        {
        return NULL;
        }
    
    protected function getPredefinedDiscussionHint ($table, $isEditor, $contextId)
        {
        return array (
                   self::composeHint ($this->getText ("Want to start a discussion?"),
                                      $this->getText ("To start a new discussion just scroll to the bottom of the page, enter a descriptive discussion topic, your name (or nick name) and a starting discussion entry.")),
                   self::composeHint ($this->getText ("Want to joins a discussion?"),
                                      $this->getText ("To add a reply in the discussion which is already started, scroll to the bottom of the page, enter the discussion topic (exactly the same as the one you are replying to), your name (or nick name) and a response or comment.")),
                      );
        }
    
    protected function getPredefinedContentHint ($table, $contextMode, $targetGroup, $contextId)
        {
        $isEditor = $targetGroup == HintsTable::TARGET_EDITOR;
        $hints = NULL;
        switch ($contextMode)
            {
            case HintsTable::CONTEXT_VIEW:
                $hints = $this->getPredefinedViewHint ($table, $isEditor, $contextId);
                break;
            case HintsTable::CONTEXT_PREVIEW:
                $hints = $this->getPredefinedPreviewHint ($table, $isEditor);
                break;
            case HintsTable::CONTEXT_EDIT:
                $hints = $this->getPredefinedEditHint ($table, $isEditor, $contextId);
                break;
            case HintsTable::CONTEXT_HISTORY:
                $hints = $this->getPredefinedHistoryHint ($table, $isEditor, $contextId);
                break;
            case HintsTable::CONTEXT_DISCUSSION:
                $hints = $this->getPredefinedDiscussionHint ($table, $isEditor, $contextId);
                break;
            }

        return $hints;
        }

    protected static function composeHint ($title, $description)
        {
        return array ("title" => $title, "description" => $description);
        }

    }

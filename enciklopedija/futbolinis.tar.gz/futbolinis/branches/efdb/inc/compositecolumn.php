<?php
require_once (PATH."inc/compositeprocessor.php");
require_once (PATH."inc/valuetransformation.php");

// a column which is not created in the database, but value is calculated at runtime
class CompositeColumn extends GhostColumn
    {
    protected $pattern;
    protected $preprocessedPatterns = array ();
    protected $lng = NULL;

    public function __construct ($name, $acceptNull, $defaultValue)
        {
        parent::__construct ($name);
        $this->pattern = $defaultValue;
        }

    public function preprocessPattern ($pattern, $dbtable, $tableAlias, &$columns, &$resultColumns, &$joins)
        {
        $preprocessed = new CompositeColumnPattern ($pattern);
        return $preprocessed;
        }

    public function prepareQuery ($dbtable, $tableAlias, &$resultColumns, &$criteria, &$joins, $namesToColumns)
        {
        $columns = array ();
        if (count ($this->preprocessedPatterns) > 3)
            {
            $dbtable->log ("Potential infinite loop found, stopping processing at 5th level depth");
            return;
            }

        $preprocessed = CompositeProcessor::createInstance ($this->pattern, $dbtable,
                                                    $tableAlias, $columns,
                                                    $resultColumns, $joins);

        array_push ($this->preprocessedPatterns, $preprocessed);
        foreach ($columns as $col)
            {
            if (false === array_search ($col, $resultColumns))
                $resultColumns[] = $col;
            }
        }

    public function customizeQuery (&$query)
        {
        $preprocessed = array_pop ($this->preprocessedPatterns);
        $query->transformations[$this->name] = new CompositeTransformation ($this->name, $preprocessed);
        }

    public function calculateValue ($context, $transformations, $row, $columnPrefix = NULL)
        {
        return "";
        }
    }

class CompositeTransformation extends ValueTransformation
    {
    public $columnDef;
    static $depth = 0;

    public function __construct ($name, $preprocessedPattern)
        {
        parent::__construct ($name);
        $this->preprocessedPattern = $preprocessedPattern;
        }

    public function getValue ($context, $transformations, $row)
        {
        if (empty ($this->preprocessedPattern))
            {
            return NULL;
            }

        self::$depth++;
        if (self::$depth > 500)
            return "";

        $pattern = $this->preprocessedPattern->getValue ($context, $transformations, $row);
        self::$depth--;
        return $pattern;
        }
    }

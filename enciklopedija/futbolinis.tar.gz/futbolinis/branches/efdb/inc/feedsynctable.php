<?php

/* A database table which stores ids of the retrieved RSS entries */
class FeedSyncTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "feedsync";

    const COL_FEED = "feed";
    const COL_GUID = "link";
    const COL_DATE = "feeddate";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        }

    protected function getColumns ()
        {
        return array (
                     new TextColumn (self::COL_FEED, 256, false),
                     new TextColumn (self::COL_GUID, 512, false),
                     new DateTimeColumn (self::COL_DATE, true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new UniqueIndex (new TextColumn (self::COL_FEED, 96, false), new TextColumn (self::COL_GUID, 128, false)));
        }

    }

<?php
class MetaDataIndexColumns extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_META;
    const TABLE_NAME = "indexcolumns";

    const COL_TABLEID = "tableid";
    const COL_INDEXID = "indexid";
    const COL_COLUMNID = "columnid";
    const COL_ORDERNO = "orderno";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        $this->defaultOrderBy = array (new OrderByColumn (self::COL_ORDERNO));
        }

    protected function getColumns ()
        {
        return array (
                     new IntColumn (self::COL_TABLEID),
                     new IntColumn (self::COL_INDEXID),
                     new IntColumn (self::COL_COLUMNID),
                     new IntColumn (self::COL_ORDERNO),
                     );
        }
        
    protected function getIndexes ()
        {
        return array (new PrimaryIndex (self::COL_TABLEID, self::COL_INDEXID, self::COL_COLUMNID));
        }

    public function deleteByTable ($tableId)
        {
        return $this->deleteBy (array (new EqCriterion (self::COL_TABLEID, $tableId)));
        }
    }

class IndexColumnNames extends GhostColumn
    {
    public function __construct ($context, $name)
        {
        parent::__construct ($name);
        }

    public function prepareQuery ($dbtable, $tableAlias, &$resultColumns, &$criteria, &$joins, $namesToColumns)
        {
        $resultColumns[] = MetaDataIndexes::COL_TABLEID;
        $resultColumns[] = MetaDataIndexes::COL_INDEXID;
        }

    public static function createIndexColumnQuery ($context, $criteria)
        {
        $handler = new MetaDataColumns ($context);
        $resultColumns = array (MetaDataColumns::COL_NAME, MetaDataColumns::COL_LABEL);
        $joinCriteria = array
            (
            new JoinColumnsCriterion (MetaDataIndexColumns::COL_TABLEID, MetaDataColumns::COL_TABLEID),
            new JoinColumnsCriterion (MetaDataIndexColumns::COL_COLUMNID, MetaDataColumns::COL_COLUMNID),
            );
        $columnNamesQuery = $handler->createQuery ($resultColumns, $joinCriteria);
        if (empty ($columnNamesQuery))
            return NULL;

        $columnNamesQuery->clearOrderBy (true);
        $handler = new MetaDataIndexColumns ($context);
        $resultColumns = array (MetaDataIndexColumns::COL_COLUMNID);

        $query = $handler->createQuery ($resultColumns, $criteria,
                                        array ($columnNamesQuery));
        return $query;
        }

    public function calculateValue ($context, $transformations, $row, $columnPrefix = NULL)
        {
        $criteria = array
            (
            new EqCriterion (MetaDataIndexColumns::COL_TABLEID, $row[$columnPrefix.MetaDataIndexes::COL_TABLEID]),
            new EqCriterion (MetaDataIndexColumns::COL_INDEXID, $row[$columnPrefix.MetaDataIndexes::COL_INDEXID]),
            );

        $query = self::createIndexColumnQuery ($context, $criteria);
        if (empty ($query))
            {
            return NULL;
            }

        $handler = new MetaDataIndexColumns ($context);
        $rows = $handler->executeQuery ($query);
        if (empty ($rows))
            return NULL;

        $names = array ();

        foreach ($rows as $row)
            {
            if (empty ($row[MetaDataColumns::COL_LABEL]))
                $names[$row[MetaDataColumns::COL_COLUMNID]] = $row[MetaDataColumns::COL_NAME];
            else
                $names[$row[MetaDataColumns::COL_COLUMNID]] = $row[MetaDataColumns::COL_LABEL];
            }

        return implode (", ", $names);
        }
    }

class MetaDataIndexes extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_META;
    const TABLE_NAME = "indexes";

    const COL_TABLEID = "tableid";
    const COL_INDEXID = "indexid";
    const COL_TYPE = "type";
    const COL_DESCRIPTION = "description";

    const COL_COLUMNNAMES = "columns";

    const INDEX_NAME_PREFIX = "idx";

    const TYPE_UNIQUE = "unique";
    const TYPE_INDEX = "index";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, true);
        }

    protected function getColumns ()
        {
        return array (
                     new IntColumn (self::COL_TABLEID),
                     new IntColumn (self::COL_INDEXID),
                     new TextColumn (self::COL_TYPE, 64),
                     new IndexColumnNames ($this->context, self::COL_COLUMNNAMES),
                     );
        }
        
    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (self::COL_DESCRIPTION, 256, true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new PrimaryIndex (self::COL_TABLEID, self::COL_INDEXID));
        }

    public function deleteByTable ($tableId)
        {
        if (false === $this->deleteBy (array (new EqCriterion (self::COL_TABLEID, $tableId)), true))
            return false;

        $columnsTable = new MetaDataIndexColumns ($this->context);
        if (false === $columnsTable->deleteByTable ($tableId))
            return false;
        return true;
        }

    public function selectIndexes ($tableId)
        {
        $criteria = array
            (
            new JoinColumnsCriterion (self::COL_TABLEID, MetaDataIndexColumns::COL_TABLEID),
            new JoinColumnsCriterion (self::COL_INDEXID, MetaDataIndexColumns::COL_INDEXID),
            );

        $subquery = IndexColumnNames::createIndexColumnQuery ($this->context, $criteria);
        if (empty  ($subquery))
            return NULL;

        $subquery->clearOrderBy (true);
        $subquery->setOrderBy (array (new OrderByColumn (MetaDataIndexColumns::COL_ORDERNO, true, 2)));

        $criteria = array (
            new EqCriterion (MetaDataIndexColumns::COL_TABLEID, $tableId),
            );
        $resultColumns = array (self::COL_INDEXID, self::COL_TYPE);
        $orderBy = array (new OrderByColumn (MetaDataIndexes::COL_INDEXID, true, 1));

        $params = array (new OrderBy ($orderBy));
        $query = $this->createQuery ($resultColumns, $criteria,
                                     array ($subquery),
                                     $params);

        $rows = $this->executeQuery ($query, $params);

        if (empty ($rows))
            return NULL;

        $indexes = array ();
        $currentIndexId = -1;
        $currentIndex = NULL;
        foreach ($rows as $row)
            {
            $indexId = $row[MetaDataIndexes::COL_INDEXID];
            if ($indexId != $currentIndexId)
                {
                if ($row[MetaDataIndexes::COL_TYPE] == self::TYPE_UNIQUE)
                    $currentIndex = new UniqueIndex (array ());
                else if ($row[MetaDataIndexes::COL_TYPE] == self::TYPE_INDEX)
                    $currentIndex = new Index (array ());
                else
                    {
                    $this->context->addMessage ("Invalid arguments passed.");
                    continue;
                    }

                $indexes[] = $currentIndex;
                $currentIndex->name = $this->getIndexName ($tableId, $indexId);
                $currentIndexId = $indexId;
                }

            $currentIndex->columns[] = $row[MetaDataColumns::COL_NAME];
            }

        return $indexes;
        }

    public function getIndexName ($tableId, $indexId)
        {
        return self::INDEX_NAME_PREFIX."_{$tableId}_{$indexId}";
        }

    public function deleteById ($criteria)
        {
        foreach ($criteria as $criterion)
            {
            if ($criterion->field == self::COL_TABLEID)
                $tableId = $criterion->value;
            else if ($criterion->field == self::COL_INDEXID)
                $indexId = $criterion->value;
            }

        if (empty ($tableId) || empty ($indexId))
            return false;

        $contentTable = ContentTable::createInstanceById ($this->context, $tableId);
        if (empty ($contentTable))
            return false;

        $indexName = $this->getIndexName ($tableId, $indexId);
        if (false === $contentTable->removeIndex ($indexName) ||
            false === parent::deleteById ($criteria))
            {
            return false;
            }

        return true;
        }

    public function addIndex ($tableId, $type, $description, $columns)
        {
        if ((self::TYPE_UNIQUE != $type && self::TYPE_INDEX != $type) ||
            empty ($tableId) || empty ($columns))
            {
            $this->context->addError ("Invalid arguments passed.");
            return false;
            }

        $contentTable = ContentTable::createInstanceById ($this->context, $tableId);
        if (empty ($contentTable))
            return false;

        $nameToValue = array (self::COL_TABLEID => $tableId, self::COL_TYPE => $type);
        if (!empty ($description))
            $nameToValue[self::COL_DESCRIPTION] = $description;

        $maxCol = array (new FunctionMax (self::COL_INDEXID, "maxId"));
        $criteria = array (new EqCriterion (self::COL_TABLEID, $tableId));
        $row = $this->selectSingleBy ($maxCol, $criteria, NULL, array (new GroupBy (array (self::COL_TABLEID))));
        if (false === $row)
            {
            $this->context->addError ("Error selecting parent table.");
            return false;
            }

        $indexId = $row["maxId"] + 1;
        $nameToValue[self::COL_INDEXID] = $indexId;

        $columns = array_unique ($columns);

        // retrieve column names by ids
        $handler = new MetaDataColumns ($this->context);
        $resultColumns = array (MetaDataColumns::COL_NAME);
        $criteria = array
            (
            new EqCriterion (MetaDataColumns::COL_TABLEID, $tableId),
            new InCriterion (MetaDataColumns::COL_COLUMNID, $columns),
            );
        $rows = $handler->selectBy ($resultColumns, $criteria);
        if (empty ($rows))
            {
            $this->context->addError ("Error selecting column names.");
            return false;
            }

        $columnNames = array ();
        foreach ($rows as $row)
            $columnNames[] = $row[MetaDataColumns::COL_NAME];

        if ($type == self::TYPE_UNIQUE)
            $index = new UniqueIndex ($columnNames);
        else if ($type == self::TYPE_INDEX)
            $index = new Index ($columnNames);

        $index->name = $this->getIndexName ($tableId, $indexId);

        if (!$contentTable->isIndexValid ($index))
            return false;

        // insert index record
        $id = $this->insertRecord ($nameToValue);
        if (false === $id)
            return false;

        // create content table index (if table exists)
        if (false === $contentTable->addIndex ($index))
            {
            // try to remove that was already created
            $this->deleteBy (array (new EqCriterion (self::COL_TABLEID, $tableId),
                                    new EqCriterion (self::COL_INDEXID, $indexId)),
                             true);
            return false;
            }

        $handler = new MetaDataIndexColumns ($this->context);
        $count = 0;
        foreach ($columns as $colId)
            {
            $indexCol = array
                (
                MetaDataIndexColumns::COL_TABLEID => $tableId,
                MetaDataIndexColumns::COL_INDEXID => $indexId,
                MetaDataIndexColumns::COL_COLUMNID => $colId,
                MetaDataIndexColumns::COL_ORDERNO => ++$count,
                );
            if (false === $handler->insertRecord ($indexCol))
                {
                $this->context->addError ("Error adding index column.");
                return false;
                }
            }

        return array ($tableId, $indexId);
        }
    }

?>

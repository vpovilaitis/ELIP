<?php

class SectionsTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "sections";

    const COL_ID = "sectionid";
    const COL_CONTEXTID = "contextid";
    const COL_SCOPE = "scope";
    const COL_COMPONENT_NAME = "Component";
    const COL_NAME = "name";
    const COL_TITLE = "title";
    const COL_DESCRIPTION = "description";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, true);
        $this->tracksRevisions = true;
        $this->tracksSources = true;
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     new TextColumn (self::COL_SCOPE, 32),
                     new IntColumn (self::COL_CONTEXTID, false),
                     new TextColumn (self::COL_COMPONENT_NAME, 32),
                     new TextColumn (self::COL_NAME, 128),
                     );
        }
        
    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (self::COL_TITLE, 256, true),
                     new LongTextColumn (self::COL_DESCRIPTION, true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new UniqueIndex (self::COL_SCOPE, self::COL_CONTEXTID, self::COL_COMPONENT_NAME, self::COL_NAME));
        }

    public function insertRecord ($nameToValue)
        {
        $result = parent::insertRecord ($nameToValue);
        if (false === $result && !$this->tableExists ())
            {
            if (false === $this->createTable ())
                return false;

            $result = parent::insertRecord ($nameToValue);
            }

        return $result;
        }

    public function deleteByPageId ($pageId)
        {
        $criteria[] = new EqCriterion (self::COL_SCOPE, Constants::SCOPE_PAGE);
        $criteria[] = new EqCriterion (self::COL_CONTEXTID, $pageId);
        $rows = $this->selectBy (array (self::COL_ID), $criteria); 
        if (false === $rows)
            return false;

        if (empty ($rows))
            return true;

        $ids = array ();
        foreach ($rows as $row)
            $ids[] = $row[self::COL_ID];

        $criteria = array (new InCriterion ($ids));
        if (!parent::deleteById ($criteria))
            return false;

        return true;
        }

    public function getDisplayNameById ($id, $idIfNotFound = false)
        {
        if (is_array ($id))
            $id = $id[0];

        $criteria = array ();
        $criteria[] = new EqCriterion (self::COL_ID, $id);
        $rows = $this->selectBy (array (self::COL_TITLE), $criteria); 
        if (empty ($rows))
            return NULL;

        return $rows[0][self::COL_TITLE];
        }

    public function getContainerLink ($id)
        {
        $pagesTable = new MetaDataPages ($this->context);
        $columns = array (MetaDataPages::COL_NAME);
        $criteria = array (new JoinColumnsCriterion (SectionsTable::COL_CONTEXTID, MetaDataPages::COL_ID));
        $pagesQuery = $pagesTable->createQuery ($columns, $criteria);

        $criteria = array ();
        $criteria[] = new EqCriterion (SectionsTable::COL_SCOPE, Constants::SCOPE_PAGE);
        $criteria[] = new EqCriterion (SectionsTable::COL_ID, $id);
        $rows = $this->selectBy (array (), $criteria, array ($pagesQuery));
        if (!empty ($rows))
            {
            $url = $this->context->createContentPageUrl ($rows[0][MetaDataPages::COL_NAME]);
            return $url;
            }

        return NULL;
        }
    }

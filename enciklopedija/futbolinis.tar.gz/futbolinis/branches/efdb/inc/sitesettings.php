<?php
require_once (PATH.'inc/dbtable.php');

class SiteSettings extends DBTableWithPerspective
    {
    const TABLE_NAME = "settings";
    const COL_ID = "id";
    const COL_NAME = "name";
    const COL_VALUE = "value";
    const COL_TRANSLATABLE = "translatable";

    const SITE_TITLE = "title";
    const SITE_DESCRIPTION = "description";
    const SITE_KEYWORDS = "keywords";
    const SITE_FOOTER = "footer";
    const SITE_AUTHOR = "author";
    const SITE_AUTHOR_EMAIL = "authorEmail";
    const SITE_WELCOME = "welcome";
    const SITE_SUBTITLE = "subheader";

    public function __construct ($context)
        {
        parent::__construct ($context, Constants::TABLES_META, self::TABLE_NAME, true);
        }

    protected function getColumns ()
        {
        return array
            (
            new AutoincrementColumn (self::COL_ID),
            $this->getPerspectiveColumn (),
            new TextColumn (self::COL_NAME, 64),
            new BoolColumn (self::COL_TRANSLATABLE),
            );
        }

    protected function getTranslatableColumns ()
        {
        return array (new TextColumn (self::COL_VALUE, 1024, true));
        }

    protected function getIndexes ()
        {
        return array (new UniqueIndex (self::COL_PERSPECTIVE, self::COL_NAME));
        }
        
    public function canRead ()
        {
        return true;
        }

    public function set ($name, $translatable, $val)
        {
        $namesToValues = array (
            self::COL_NAME => $name,
            self::COL_TRANSLATABLE => $translatable,
            self::COL_VALUE => $val
            );
        if (false !== $this->insertRecord ($namesToValues))
            return true;

        // try updating
        $row = $this->selectSingleBy (array (self::COL_ID), array (new EqCriterion (self::COL_NAME, $name)));
        if (empty ($row))
            return false;
        $idCriteria = array (new EqCriterion (self::COL_ID, $row[self::COL_ID]));
        $namesToValues = array (self::COL_VALUE => $val);
        if (false === $this->updateById ($idCriteria, $idCriteria, $namesToValues))
            return false;

        $cache = Cache::getInstance (self::TABLE_NAME, 24*60*60);
        $cache->clean ();

        return true;
        }

    public static function isDeployed ($context)
        {
        $handler = new SiteSettings ($context);
        if (!$handler->tableExists ())
            return false;
        return true;
        }

    public static function get ($context)
        {
        $cache = Cache::getInstance (self::TABLE_NAME, 24*60*60);
    
        if (false === ($result = $cache->get ("sitesettings".md5 ($context->getPerspective ()))))
            {
            $handler = new SiteSettings ($context);
            $rows = $handler->selectBy (array (self::COL_NAME, self::COL_TRANSLATABLE, self::COL_VALUE), NULL);
            $result = array ();

            if (empty ($rows))
                {
                $context->log ("Warning: No site settings found");
                return $result;
                }

            foreach ($rows as $row)
                {
                $val = $row[self::COL_VALUE];
                $result[$row[self::COL_NAME]] = $val;
                }

            $cache->save ($result, "sitesettings".md5 ($context->getPerspective ()));
            }

        return $result;
        }
    }

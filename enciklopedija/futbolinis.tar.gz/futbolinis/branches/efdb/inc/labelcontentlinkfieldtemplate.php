<?php

class LabelContentLinkFieldTemplate extends LabelFieldTemplate
    {
    protected $dbtable = NULL;

    public function __construct ($prefix, $key, $label)
        {
        parent::__construct ($prefix, $key, $label);
        }

    public static function createContentViewLink ($context, $dbtable, $tableId, $ids, $mode = Constants::MODE_VIEW, $params = NULL)
        {
        return ContentUrl::createLink ($context, $dbtable, $tableId, $ids, $mode, $params);
        }

    public function createLink ($context, $tableId, $ids)
        {
        if (defined ("FRIENDLY_URL") && FRIENDLY_URL)
            {
            if (NULL === $this->dbtable)
                $this->dbtable = ContentTable::createInstanceById ($context, $tableId);
            }

        return self::createContentViewLink ($context, $this->dbtable, $tableId, $ids);
        }

    }

<?php

class FilterCriterion
    {
    public $criterion;

    public function __construct ($criterion)
        {
        $this->criterion = $criterion;
        }
    }

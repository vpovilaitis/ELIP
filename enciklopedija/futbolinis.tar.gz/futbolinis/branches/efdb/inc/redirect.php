<?php
/*
Use this file to create search engine friendly language links:
  - create a subdirectory under site root for each language (en, lt, etc)
  - create a file redirect.php in each directory with simple contents:
        define ("PATH", "../");
        require_once (PATH."/inc/redirect.php");
  - create .htaccess file in each subdirectory:
        RewriteEngine On
        RewriteRule ^(.*) redirect.php?lng=en_US
*/
$path = $_SERVER ["REQUEST_URI"];
if ("res" == substr (trim ($path, "/"), 0, 3))
    {
    $pathinfo = pathinfo ($path);
    $path = "..".$path;
    header ("content-Disposition: atachment; filename=".$pathinfo["basename"]);
    header ("content-Type: application/octet-stream");
    header ("content-Length: ".filesize ($path));
    $fp = fopen ($path,"r");
    print fread ($fp, filesize ($path));
    fclose($fp);
    exit ();
    }

$parts = parse_url ($_SERVER["REQUEST_URI"]);
parse_str ($parts["query"], $request);

$_REQUEST = $request;

if (!empty ($_GET["lng"]))
    $_REQUEST["lng"] = $_GET["lng"];

$file = $_SERVER["REDIRECT_URL"];
$fname = strrchr ($file, "/");
if (false !== $fname)
    $file = substr ($fname, 1);
else
    $file = trim ($file, "/");

if (!empty ($file))
    require (PATH.$file);
else
    require (PATH."index.php");
?>
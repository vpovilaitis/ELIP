<?php

class CreatableRelationDropDownFieldTemplate extends CreatableDropDownFieldTemplate
    {
    protected $relatedTable;

    public function __construct ($context, $relatedTable, $prefix, $relationColumn, $values)
        {
        parent::__construct ($context, $prefix, $relationColumn->name,
                             $relationColumn->label,
                             $relationColumn->description, $values);
        $this->relatedTable = $relatedTable;
        }

    protected function createItem ($context, $label)
        {
        $id = $this->relatedTable->createFromLabel ($label);
        if (false === $id)
            {
            $context->addError ("Error while creating a new record for field $this->label");
            return NULL;
            }

        if (is_numeric ($id))
            $id = array ($id);
        return array (implode ("_", $id), $id);
        }

    protected function createDropDown ($prefix, $key, $tooltip, $picklist)
        {
        return new RelationDropDownFieldTemplate ($prefix, $key, "", $tooltip, $picklist);
        }
    }

class LabelRelationFieldTemplate extends LabelContentLinkFieldTemplate
    {
    protected $tableId;
    protected $dbtable = NULL;
    protected $column = NULL;

    public function __construct ($context, $prefix, $relationColumn, $key = NULL)
        {
        if (NULL === $key)
            $key = $relationColumn->name;

        $parts = explode (".", $key, 2);
        if (2 == count ($parts))
            {
            $key = $parts[0];
            $this->column = $parts[1];
            }

        parent::__construct ($prefix, $key,
                             $relationColumn->label);
        $this->tableId = $relationColumn->relatedTableId;
        }

    public function getValueForDisplay ($context, $row, $key = NULL)
        {
        if (NULL === $key)
            $key = $this->key;

        if (NULL === $this->column)
            $displaynameColumn = $key.".".ContentTable::COL_DISPLAY_NAME;
        else
            $displaynameColumn = $key.".c_".$this->column;

        if (!empty ($row[$displaynameColumn]))
            {
            $displayName = trim ($row[$displaynameColumn]);
            if (!empty ($displayName))
                return $displayName;
            }

        if (empty ($row[$key]))
            return NULL;
        return implode ("_", $row[$key]);
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        if (NULL === $this->column)
            return parent::prepareQuery ($resultColumns, $criteria, $joins, $params);

        $resultColumns[] = $this->key.".".$this->column;
        }

    public function getUri ($context, $row)
        {
        if (empty ($row[$this->key]))
            return NULL;

        $id = $row[$this->key];
        return $this->createLink ($context, $this->tableId, $id);
        }

    public function showValue ($fieldValue)
        {
        return !empty ($fieldValue);
        }

    }

class EditableParentFieldTemplate extends RelationAutocompleteField
    {
    protected $parentId;

    public function __construct ($prefix, $dbtable, $label, $tooltip, $parentId)
        {
        $this->parentId = $parentId;

        parent::__construct ($prefix, $dbtable->getParentTable (), Constants::PARENT, $label, $tooltip, true);
        }

    public function preprocessLoadedValue (&$request, $existingRecord, $index = NULL)
        {
        if (!$existingRecord && !empty ($this->parentId))
            $request[$this->key] = $this->parentId;

        parent::preprocessLoadedValue ($request, $existingRecord);
        }
    }

?>

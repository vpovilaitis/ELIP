<?php
require_once (PATH.'inc/instanceview.php');

abstract class InstanceEditor extends InstanceView
    {
    protected $createNew = NULL;
    protected $texts = NULL;
    protected $template = NULL;
    protected $parentId = NULL;
    protected $ticket = NULL;
    protected $readonly = false;

    public $isCancelled = false;
    public $inline = false;

    const COMPONENT_HIDDEN = "cphidden";
    const CACHE_OLD_VALUES = "oldval";

    public function checkAccess ()
        {
        if (!empty ($this->dbtable))
            return $this->isCreating ()
                                ? $this->dbtable->canCreate ()
                                : $this->dbtable->canEdit ();

        return NULL;
        }

    public function setMode ($creating, $id)
        {
        $this->createNew = $creating;
        $this->setIds ($id);
        }

    public function isCreating ()
        {
        if (NULL === $this->createNew)
            $this->log ("Warning: editor mode not set");

        return $this->createNew;
        }

    public function getTicket ($request, $updatedOn, $renew = false)
        {
        if (NULL === $this->ticket || $renew)
            {
            if (!empty ($request["inform"]))
                $this->ticket = $request["inform"];
            else
                {
                if (!$updatedOn)
                    $updatedOn = uniqid();
                $ids = $this->getIds();
                $this->ticket = $this->dbtable->getTableName ()."_".implode (".", $ids ? $ids : array ('-'))."_".str_replace(':', '-', $updatedOn);
                }
            }

        return $this->ticket;
        }
        
    public function processInput ($context, &$request)
        {
        if (false === parent::processInput ($context, $request))
            return false;

        if (isset ($request[InstanceEditor::COMPONENT_HIDDEN]) && $request[InstanceEditor::COMPONENT_HIDDEN])
            {
            $this->visible = false;
            return true;
            }

        $this->hiddenFields["action"] = $this->isCreating () ? "new" : "edit";
        $this->hiddenFields["inform"] = $this->getTicket ($request, !empty ($request["updatedon"]) ? $request["updatedon"] : uniqid());
        if (!empty ($request["updatedon"]))
            $this->hiddenFields["updatedon"] = $request["updatedon"];

        if (isset ($request["cancel"]))
            {
            $this->showSuccessPage ($request);
            return false;
            }

        $errorTarget = $this->context->setErrorTarget ($this);

        $ret = $this->processInputFields ($context, $request);

        $this->context->setErrorTarget ($errorTarget);
        return $ret;
        }

    public function processInputFields ($context, &$request)
        {
        $this->log("InstanceEditor::processInputFields");
        $template = $this->collectTemplateFields ($request, $this->isCreating ());

        if (isset ($request["inform"]))
            {
            $continue = true;

            foreach ($template as $field)
                {
                if (false === $field->processInput ($context, $request))
                    $continue = false;
                }

            if (!$continue)
                {
                $this->isCancelled = true;
                return true;
                }

            if (isset ($request["save"]))
                {
                $ret = $this->saveItem ($request);
                if (NULL !== $ret)
                    return $ret;
                }
            }
        else
            {
            $values = $this->loadDefaultOrInitialValues ($request, $template);
            }

        $this->log("InstanceEditor - fields processed (processInputFields)");
        return true;
        }

    protected function loadDefaultOrInitialValues (&$request, $template)
        {
        if (!$this->isCreating ())
            {
            // retrieve values from database
            $this->retrieveCached ($request, $this->getIds ());
            $values = &$this->instance;
            }
        else
            {
            $values = &$request;
            }

        foreach ($template as $field)
            {
            $field->preprocessLoadedValue ($values, !$this->isCreating ());
            }

        return $values;
        }

    public function saveItem (&$request, $additionalValues = NULL)
        {
        if (!$this->visible)
            return true;

        $template = $this->collectTemplateFields ($request, $this->isCreating ());
        $values = array ();

        foreach ($template as $field)
            {
            if ($field instanceof LabelFieldTemplate)
                continue;

            $val = $field->getValueForDB ($this->context, $request);

            if ($this->isCreating () || !$field->readonly)
                $values[$field->key] = $val;
            }

        if ($this->containsErrors ())
            return true;

        $dbcon = $this->context->getConnection ();
        $dbcon->startTransaction ();

        if ($this->isCreating ())
            {
            if (!empty ($additionalValues))
                $values = array_merge ($values, $additionalValues);

            $ret = $this->createRecord ($request, $values);
            }
        else
            {
            if (!empty ($additionalValues))
                $values = array_merge ($values, $additionalValues);

            $ret = $this->modifyRecord ($request, $this->getIds (), $values);
            }

        if (true !== $ret)
            {
            $dbcon->rollbackTransaction ();
            }
        else
            {
            $dbcon->commitTransaction ();
            return $this->showSuccessPage ($request);
            }

        return NULL;
        }

    protected function showSuccessPage ($request)
        {
        $id = $this->getIds();
        if (is_array ($id))
            $id = implode ("_", $id);
        $adjust = array ("action" => "edit", "id" => $id);
        $url = $this->context->getAdjustedUrl ($adjust);
        $this->context->redirect ($url);
        return false;
        }

    public function setIds ($ids)
        {
        $ids = $this->parseIds ($ids);

        if ($this->isCreating ())
            $this->parentId = $ids;
        else
            $this->ids = $ids;
        }

    protected function getParentId ($returnNumeric = false)
        {
        $arr = $this->getParentIdArray ();
        return $returnNumeric ? $arr[0] : $arr;
        }

    protected function getParentIdArray ()
        {
        if (NULL !== $this->parentId)
            return $this->parentId;

        $id = $this->getIds ();

        $parentId = array ();
        for ($i = 0; $i < count ($id) - 1; $i++)
            $parentId[] = $id[$i];
        return $parentId;
        }

    protected function retrieveCached ($request, $id)
        {
        if (isset ($this->instance))
            return $this->instance;

        $this->collectTemplateFields ($request, $this->isCreating ());
        $this->instance = $this->retrieveExisting ($request, $id);

        if (!$this->readonly)
            {
            $ticket = $this->getTicket ($request, !empty ($this->instance[DBTable::COL_UPDATEDON]) ? $this->instance[DBTable::COL_UPDATEDON] : NULL);

            $cache = Cache::getInstance (self::CACHE_OLD_VALUES, 60*60);
            // store initial values
            if (false === ($result = $cache->get ($ticket)))
                $cache->save ($this->instance, $ticket);

            if (!empty ($this->instance[DBTable::COL_UPDATEDON]))
                $this->hiddenFields["updatedon"] = $this->instance[DBTable::COL_UPDATEDON];
            }
        
        return $this->instance;
        }

    protected function retrieveExisting ($request, $id)
        {
        $criteria = array();

        if (NULL == $this->dbtable)
            {
            echo "retrieveExisting() method should be overiden in ".get_class ($this)."class if dbtable member is not set<br>";
            exit();
            }

        $idColumns = $this->dbtable->getPrimaryIndexColumns ();

        if (count ($id) != count ($idColumns))
            {
            $this->log ($id);
            $this->log ($idColumns);
            $this->addError ("Incorrect ids were provided for the action.");
            return NULL;
            }

        $resultColumns = array ();
        for ($i = 0; $i < count ($idColumns); $i++)
            {
            $criteria[] = new EqCriterion ($idColumns[$i]->name, $id[$i]);
            $resultColumns[] = $idColumns[$i]->name;
            }

        $joins = NULL;
        $params = NULL;
        $this->prepareQuery ($resultColumns, $criteria, $joins, $params);

        $resultColumns[] = DBTable::COL_UPDATEDON;
        $rows = $this->dbtable->selectBy ($resultColumns, $criteria, $joins, $params);
        if (false === $rows || count ($rows) < 1)
            {
            $this->addError ("Edited item not found");
            return NULL;
            }

        return $rows[0];
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        for ($i = 0; $i < count ($this->template); $i++)
            {
            $this->template[$i]->prepareQuery ($resultColumns, $criteria, $joins, $params);
            }
        }

    protected abstract function getTemplateFields ($request, $isCreating);

    protected function collectTemplateFields ($request, $isCreating)
        {
        if (empty ($this->template))
            {
            $this->template = $this->getTemplateFields ($request, $isCreating);
            if (!empty ($this->template))
                {
                foreach ($this->template as $field)
                    {
                    $field->setPrefix ($this->getPrefix ());
                    }
                }
            }

        return $this->template;
        }

    public function getTitle ()
        {
        return $this->getPageTitle ($this->isCreating ());
        }

    public function getFields ()
        {
        $ret = $this->collectTemplateFields (NULL, $this->isCreating ());
        return $ret;
        }

    public function filterFields ($fields, $fieldNames)
        {
        $newList = array ();
        foreach ($fields as $field)
            {
            if (false === array_search ($field->key, $fieldNames))
                continue;
            $newList[$field->key] = $field;
            }

        $fields = array ();
        foreach ($fieldNames as $key)
            {
            if (!empty ($newList[$key]))
                $fields[] = $newList[$key];
            }
        return $fields;
        }

    public function showCancel ()
        {
        return isset ($this->context->request[Constants::PARAM_RETURN_TO]);
        }

    protected function createRecord (&$request, $values)
        {
        if (NULL == $this->dbtable)
            {
            echo "createRecord() method should be overiden in ".class_name ($this)."class if dbtable member is not set or points to a child table<br>";
            exit();
            }
        $id = $this->dbtable->insertRecord ($values);
        if (false === $id)
            {
            $this->addError ("Error creating a new record");
            return $id;
            }

        $this->setMode (false, $id);
        return true;
        }

    protected function getInitialValues ()
        {
        $cache = Cache::getInstance (self::CACHE_OLD_VALUES, 60*60);
        if (false !== ($result = $cache->get ($this->ticket)))
            return $result;
        return NULL;
        }

    protected function partiallyUpdateInitialValues ($valuesToUpdate)
        {
        $cache = Cache::getInstance (self::CACHE_OLD_VALUES, 60*60);
        if (!empty ($valuesToUpdate) && false !== ($initialValues = $cache->get ($this->ticket)))
            {
            foreach ($valuesToUpdate as $key => $val)
                $initialValues[$key] = $val;

            $cache->save ($initialValues, $this->ticket);
            }

        return;
        }

    protected function tryGetInitialValues ($request)
        {
        $ticket = $this->getTicket ($request, $this->hiddenFields["updatedon"]);
        $cache = Cache::getInstance (self::CACHE_OLD_VALUES, 60*60);
        if (false !== ($initialValues = $cache->get ($ticket)))
            return $initialValues;

        // session expired?
        $id = $this->getIds ();
        $currentValues = $this->retrieveExisting ($request, $id);
        if ($currentValues[DBTable::COL_UPDATEDON] == $this->hiddenFields["updatedon"])
            {
            $cache->save ($currentValues, $ticket);
            return $currentValues;
            }

        $this->addError ("Your editing session has expired and some changes were already done by other user. Please merge changes manually.");
        return false;
        }

    protected function modifyRecord ($request, $id, $values)
        {
        $criteria = array();

        if (NULL == $this->dbtable)
            {
            echo "modifyRecord() method should be overiden in ".class_name ($this)."class if dbtable member is not set<br>";
            exit();
            }

        $idColumns = $this->dbtable->getPrimaryIndexColumns ();

        if (count ($id) != count ($idColumns))
            {
            $this->addError ("Incorect ids were provided for the action");
            return false;
            }

        for ($i = 0; $i < count ($idColumns); $i++)
            {
            $criteria[] = new EqCriterion ($idColumns[$i]->name, $id[$i]);
            }

        $initialValues = $this->tryGetInitialValues ($request);
        if (false === $initialValues)
            return false;

        $changedValues = array ();
        $changedCount = 0;
        foreach ($values as $key => $val)
            {
            if (DBTable::COL_SOURCE == $key || DBTable::COL_SOURCEDATE == $key)
                {
                $changedValues[$key] = $val;
                continue;
                }

            $changed = $this->valueChanged ($initialValues, $key, $val);
            if (NULL === $changed)
                return false;
            if (!$changed)
                continue;

            $changedValues[$key] = $val;
            $this->addSafeguardCriterion ($criteria, $initialValues, $key);
            $changedCount++;
            }

        if (0 == $changedCount)
            {
            $this->log ("Nothing changed, skipping.");
            return true;
            }

        $affected = $this->dbtable->updateRecord ($criteria, $changedValues);
        if (1 != $affected)
            {
            $this->addError ("Error modifying record.");
            return false;
            }

        return true;
        }

    protected function addSafeguardCriterion (&$criteria, $initialValues, $key)
        {
        // ensure that no one changed this field yet
        if (NULL === $initialValues[$key])
            $criteria[] = new LogicalOperatorOr (new IsNullCriterion ($key), new EqCriterion ($key, ""));
        else
            $criteria[] = new EqCriterion ($key, $initialValues[$key]);
        }

    protected function valueChanged ($initialValues, $key, $newValue)
        {
        if (!array_key_exists ($key, $initialValues))
            {
            $this->addError ("Field [_0] is out of date", $key);
            return false;
            }

        $initialValue = $initialValues[$key];
        return ($initialValue != $newValue);
        }

    public function getTemplateName ()
        {
        return "instanceeditor";
        }

    public function canSave ()
        {
        return !$this->containsErrors () && !$this->isCancelled;
        }

    public function getActionList ()
        {
        return NULL;
        }

    }

?>

<?php

class TextComponent extends Component
    {
    protected $text;
    protected $cssClass;

    public function __construct ($prefix, $context, $text, $cssClass = NULL)
        {
        parent::__construct ($prefix, $context);
        $this->text = $text;
        $this->cssClass = $cssClass;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getTemplateName ()
        {
        return "simpletext";
        }

    public function getTitle ()
        {
        return NULL;
        }

    public function getDisplayedText()
        {
        return $this->text;
        }

    public function getCssClass()
        {
        return $this->cssClass;
        }

    public function getMoreInformationUrl ()
        {
        return NULL;
        }
    }

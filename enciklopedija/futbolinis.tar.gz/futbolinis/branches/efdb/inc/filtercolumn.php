<?php

// a column which will be used as generic search criteria
class FilterColumn
    {
    protected $displayNameColumn;
    protected $sortColumns = array ();

    public function __construct ($dbtable, $displayNameColumn, $sortColumns)
        {
        $this->displayNameColumn = $displayNameColumn;

        if (!empty ($sortColumns))
            {
            ksort ($sortColumns);

            foreach ($sortColumns as $col)
                {
                if (!$col instanceof ValueColumn)
                    continue;

                $this->sortColumns[] = $col->columnDef;
                }
            }
        }

    public function prepareQuery ($filterCriterion, &$criteria, &$joins, &$params = NULL)
        {
        $filterBy = $filterCriterion->criterion;
        $columns = array ();

        if (!empty ($this->displayNameColumn))
            {
            $col = $this->displayNameColumn;

            if ($col instanceof ValueColumn)
                $col = $col->columnDef;

            if ($col instanceof TextColumn)
                $columns[$col->name] = $col;
            }

        foreach ($this->sortColumns as $col)
            {
            if ($col instanceof TextColumn)
                $columns[$col->name] = $col;
            }

        $likeCriteria = array ();
        foreach ($columns as $col)
            {
            $likeCriteria[] = new LikeCriterion ($col->name, $filterBy);
            }

        if (count ($columns) > 1)
            {
            $parts = explode (" ", $filterBy, 2);
            if (2 == count ($parts))
                {
                foreach ($columns as $col)
                    $cols[] = $col->name;

                $likeCriteria[] = new LogicalOperatorAnd
                    (
                    new LikeCriterion ($cols[0], trim ($parts[0], " .,")),
                    new LikeCriterion ($cols[1], trim ($parts[1], " .,"))
                    );
                $likeCriteria[] = new LogicalOperatorAnd
                    (
                    new LikeCriterion ($cols[0], trim ($parts[1], " .,")),
                    new LikeCriterion ($cols[1], trim ($parts[0], " .,"))
                    );
                }
            }

        if (empty ($likeCriteria))
            return;

        if (count ($likeCriteria) == 1)
            $criteria[] = $likeCriteria[0];
        else
            $criteria[] = new LogicalOperatorOr ($likeCriteria);
        }

    public function customizeQuery (&$query)
        {
        }

    public function calculateValue ($context, $transformations, $row, $columnPrefix = NULL)
        {
        return "";
        }
    }

?>
<?php
require_once (PATH.'inc/page.php');

abstract class WebService extends Page
    {
    public function __construct ($context)
        {
        parent::__construct ($context, NULL);
        $context->setErrorTarget ($this);
        }

    protected function getPageTemplateDir ()
        {
        return ".";
        }

    protected function getTemplateName ()
        {
        return "serviceresults";
        }

    protected abstract function getData ($request);

    protected function getDisplayParams ($request)
        {
        header ('Content-type: text/xml; charset=utf-8');

        return array ("this" => $this,
                      "data" => $this->getData ($request));
        }

    protected function getReturnedHtml ($request, $templateName, $thisObj = NULL, $params = NULL)
        {
        if (empty ($thisObj))
            $thisObj = $this;
        $data = array ();
        if (empty ($params))
            $params = array();
        $params["this"] = $thisObj;
        $params["inlineLinks"] = true;
        $html = displayFromTemplate ($this->context, "", $templateName, $params, true);

        $chunkSize = 200; // split into chunks to work around Mozzila bug
        while (strlen ($html) > 0)
            {
            $data[] =  array ("html" => utf8_substr ($html, 0, $chunkSize));
            $html = utf8_substr ($html, $chunkSize);
            }
        return $data;
        }

    }

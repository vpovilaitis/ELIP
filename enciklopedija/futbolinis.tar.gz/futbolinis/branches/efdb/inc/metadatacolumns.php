<?php

abstract class TableColumn
    {
    public $id;
    public $name;
    public $description;
    public $label;
    public $required;
    public $defaultValue;
    public $translatable;
    public $category = MetaDataColumns::CATEGORY_PRIMARY;
    public $sortOrder;
    public $sortAsc;
    public $inputType;
    public $displayType;

    public function __construct ($name, $label, $description, $required)
        {
        $this->name = $name;
        $this->label = $label;
        $this->description = $description;
        $this->required = $required;
        }

    public abstract function getTypeDescription ($context);

    public function getLabel ()
        {
        return empty ($this->label) ? $this->name : $this->label;
        }

    public function getDescription ()
        {
        return empty ($this->description) ? $this->getLabel () : $this->description;
        }

    public function compare ($a, $b)
        {
        if ($a == $b)
            return NULL;
        return $a > $b ? 1 : -1;
        }
    }

class ValueColumn extends TableColumn
    {
    public $columnDef;

    /*
        if column def is available, construct using
            new ValueColumn ($columnDef, $label, $description)
        otherwise construct using
            new ValueColumn ($name, $label, $description, $required)
    */
    public function __construct ()
        {
        $funcArgs = func_get_args ();
        if (count ($funcArgs) < 3)
            {
            echo "ValueColumn constructor called with too little arguments";
            exit ();
            }

        $label = $funcArgs[1];
        $description = $funcArgs[2];
        if ($funcArgs[0] instanceof ColumnDef)
            {
            $this->columnDef = $funcArgs[0];
            parent::__construct ($this->columnDef->name, $label, $description, !$this->columnDef->acceptNull);
            }
        else
            parent::__construct ($funcArgs[0], $label, $description, $funcArgs[3]);
        }

    public function getTypeDescription ($context)
        {
        if (NULL == $this->columnDef)
            return $context->getText ("undefined");

        if ($this->columnDef instanceof LongTextColumn)
            return $context->getText ("String of unlimited length");

        if ($this->columnDef instanceof TextColumn)
            return $context->ngettext ("String (max [_0] character)",
                                       "String (max [_0] characters)",
                                       $this->columnDef->size);

        if ($this->columnDef instanceof BoolColumn)
            return $context->getText ("Boolean");

        if ($this->columnDef instanceof NamedIntColumn)
            return $context->getText ("Fixed list");

        if ($this->columnDef instanceof HeightColumn)
            return $context->getText ("Height (cm)");

        if ($this->columnDef instanceof WeightColumn)
            return $context->getText ("Weight (kg)");

        if ($this->columnDef instanceof DecimalColumn)
            return $context->getText ("Decimal");

        if ($this->columnDef instanceof IntColumn)
            return $context->getText ("Integer");

        if ($this->columnDef instanceof DateColumn)
            return $context->getText ("Date");

        if ($this->columnDef instanceof DateTimeColumn)
            return $context->getText ("Date and Time");

        if ($this->columnDef instanceof CompositeColumn)
            return $context->getText ("Composite value");

        return $context->getText ("undefined");
        }

    public function setType ($typeString)
        {
        if (1 == sscanf ($typeString, ColumnDefFactory::TYPE_TEXT."(%d)", $size))
            {
            $typeString = ColumnDefFactory::TYPE_TEXT;
            }
        else
            $size = 0;

        $this->columnDef = ColumnDefFactory::create ($typeString, $this->name,
                                                     $size, 0, !$this->required,
                                                     $this->defaultValue);
        }

    public function compare ($a, $b)
        {
        return $this->columnDef->compare ($a, $b);
        }
    }

class RelationColumn extends TableColumn
    {
    public $relatedTableId;
    public $relationName;

    public function __construct ($name, $label, $description, $required)
        {
        parent::__construct ($name, $label, $description, $required);
        $this->translatable = NULL;
        }

    public function getTypeDescription ($context)
        {
        $dbtable = ContentTable::createInstanceById ($context, $this->relatedTableId);
        if (empty ($dbtable))
            return $context->getText ("undefined");
        return $dbtable->getLabel ();
        }

    public function getNoneItem ($context)
        {
        return $context->getText ("<none>");
        }

    public function getRelationName ()
        {
        return empty ($this->relationName) ? $this->getDescription () : $this->relationName;
        }
    }

class MetaDataColumns extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_META;
    const TABLE_NAME = "columns";

    const COL_TABLEID = "tableid";
    const COL_COLUMNID = "columnid";
    const COL_NAME = "name";
    const COL_ISRELATION = "isrelation";
    const COL_TYPE = "coltype";
    const COL_SIZE_OR_ID = "size_or_id";
    const COL_RELATEDTABLEID = self::COL_SIZE_OR_ID;
    const COL_SIZE = self::COL_SIZE_OR_ID;
    const COL_PRECISION = "prec";
    const COL_MODIFIERS = "modifiers";
    const COL_REQUIRED = "required";
    const COL_TRANSLATABLE = "translatable";
    const COL_LABEL = "label";
    const COL_DESCRIPTION = "description";
    const COL_CATEGORY = "category";
    const COL_SORTORDER = "sortorder";
    const COL_SORTASC = "sortasc";
    // default value or composite field pattern
    const COL_DEFAULTVALUE = "defaultvalue";
    // display type in related instance (none, preview, compact in 2 columns, etc)
    const COL_DISPLAYTYPE = "displaytype";
    // value editing type (dropdown, creatable dropdown or searchable edit box with browse button)
    const COL_INPUTTYPE = "inputtype";
    // the label displayed while reviewing related values by this column
    const COL_RELATIONNAME = "relationname";

    const CATEGORY_PRIMARY = 1; // displayed in preview and view mode
    const CATEGORY_DETAILS = 2; // displayed in view mode
    const CATEGORY_ADDITIONAL = 10; // not displayed in preview or view mode
    const CATEGORY_GENERATED = 20; // not displayed in UI (used for some internal logic)

    const DISPLAY_NONE = "";
    const DISPLAY_PREVIEW = "preview";
    const DISPLAY_SECTIONS = "extend";

    const INPUT_DROPDOWN = "";
    const INPUT_AUTOCOMPLETE = "autocomplete";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, true);
        $this->defaultOrderBy = array (new OrderByColumn (DBTable::COL_ORDER));
        }

    protected function getColumns ()
        {
        return array (
                     new IntColumn (self::COL_TABLEID),
                     new IntColumn (self::COL_COLUMNID),
                     new TextColumn (self::COL_NAME, 64),
                     new BoolColumn (self::COL_ISRELATION),
                     new TextColumn (self::COL_TYPE, 64, true),
                     new IntColumn (self::COL_SIZE_OR_ID, true),
                     new IntColumn (self::COL_PRECISION, true),
                     new TextColumn (self::COL_MODIFIERS, 255, true),
                     new BoolColumn (self::COL_REQUIRED),
                     new BoolColumn (self::COL_TRANSLATABLE),
                     new IntColumn (DBTable::COL_ORDER),
                     new IntColumn (self::COL_CATEGORY),
                     new IntColumn (self::COL_SORTORDER, true),
                     new BoolColumn (self::COL_SORTASC, true),
                     new TextColumn (self::COL_DISPLAYTYPE, 128, true), // for related columns
                     new TextColumn (self::COL_INPUTTYPE, 128, true),
                     );
        }

    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (self::COL_LABEL, 64, true),
                     new TextColumn (self::COL_DEFAULTVALUE, 1024, true),
                     new TextColumn (self::COL_RELATIONNAME, 255, true),
                     new TextColumn (self::COL_DESCRIPTION, 255, true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new PrimaryIndex (self::COL_TABLEID, self::COL_COLUMNID),
                      new UniqueIndex (self::COL_TABLEID, self::COL_NAME));
        }

    public function create ($tableId, $columnId, $column)
        {
        if (empty ($column->name))
            {
            $this->context->addError ("Column name is a required field");
            return false;
            }

        $values = array
            (
            self::COL_TABLEID => $tableId,
            self::COL_COLUMNID => $columnId,
            self::COL_NAME => $column->name,
            self::COL_REQUIRED => $column->required ? true : false,
            self::COL_TRANSLATABLE => $column->translatable ? true : false,
            DBTable::COL_ORDER => $columnId,
            self::COL_CATEGORY => $column->category,
            );

        if (!empty ($column->description))
            $values[self::COL_DESCRIPTION] = $column->description;

        if (!empty ($column->label))
            $values[self::COL_LABEL] = $column->label;

        if (!empty ($column->defaultValue))
            $values[self::COL_DEFAULTVALUE] = $column->defaultValue;

        if (!empty ($column->inputType))
            $values[self::COL_INPUTTYPE] = $column->inputType;

        if (!empty ($column->displayType))
            $values[self::COL_DISPLAYTYPE] = $column->displayType;

        if (!empty ($column->sortOrder))
            {
            $values[self::COL_SORTORDER] = $column->sortOrder;
            $values[self::COL_SORTASC] = NULL === $column->sortAsc || $column->sortAsc;
            }

        if ($column instanceof ValueColumn)
            {
            $values[self::COL_ISRELATION] = false;
            $values[self::COL_TYPE] = ColumnDefFactory::getTypeString ($column->columnDef);
            $values[self::COL_SIZE] = $column->columnDef->size;
            $values[self::COL_PRECISION] = $column->columnDef->precision;

            if (!empty ($column->modifiers))
                $values[self::COL_MODIFIERS] = $column->modifiers;
            }
        else if ($column instanceof RelationColumn)
            {
            $values[self::COL_ISRELATION] = true;
            $values[self::COL_RELATEDTABLEID] = $column->relatedTableId;

            if (!empty ($column->relationName))
                $values[self::COL_RELATIONNAME] = $column->relationName;
            }
        else
            return false;

        $cache = Cache::getInstance (self::TABLE_NAME, 12*60*60);
        $cache->clean ();
        return parent::insertRecord ($values);
        }

    public function insertRecord ($values)
        {
        return false; // use "create" method
        }

    protected function deleteBy ($criteria, $deleteTranslatable = false)
        {
        $ret = parent::deleteBy ($criteria, $deleteTranslatable);
        $cache = Cache::getInstance (self::TABLE_NAME, 12*60*60);
        $cache->clean ();
        return $ret;
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = NULL)
        {
        $ret = parent::updateRecord ($criteria, $nameToValue, $maxRows);
        $cache = Cache::getInstance (self::TABLE_NAME, 12*60*60);
        $cache->clean ();
        return $ret;
        }

    public function deleteByTable ($tableId)
        {
        $cache = Cache::getInstance (self::TABLE_NAME, 12*60*60);
        $cache->clean ();
        return $this->deleteBy (array (new EqCriterion (self::COL_TABLEID, $tableId)), true);
        }

    public function updateColumn ($tableId, $columnId, $updateValues)
        {
        $cache = Cache::getInstance (self::TABLE_NAME, 12*60*60);
        $cache->clean ();
        return $this->updateRecord (array (new EqCriterion (self::COL_TABLEID, $tableId),
                                           new EqCriterion (self::COL_COLUMNID, $columnId)),
                                    $updateValues);
        }

    public function selectColumns ($tableId, $columnId = NULL)
        {
        $cache = Cache::getInstance (self::TABLE_NAME, 12*60*60);
        $cacheId = "tablecolumns".$tableId;

        $startTime = microtime (true);
        $rows = $cache->get ($cacheId);
        if (empty ($rows))
            {
            if (false !== $rows)
                $this->log ("Invalid data in the cache");
            $criteria = array (new EqCriterion (self::COL_TABLEID, $tableId));

            $rows = $this->selectBy (NULL, $criteria);
            $endTime = microtime (true);
            $this->log ("Cache miss. Selecting columns took ".($endTime-$startTime)." s");

            $cache->save ($rows, $cacheId);

            $endTime2 = microtime (true);
            $this->log ("Saving to the cache took ".($endTime2-$endTime)." s");
            }
        else
            {
            $endTime = microtime (true);
            $this->log ("Retrieved columns from cache - ".($endTime-$startTime)." s");
            }

        if (!empty ($columnId))
            {
            $allColumns = $rows;
            $rows = NULL;

            foreach ($allColumns as $row)
                {
                if ($row[self::COL_COLUMNID] == $columnId)
                    {
                    $rows = array ($row);
                    break;
                    }
                }
            }

        if (empty ($rows))
            return $rows;

        $columns = array();
        foreach ($rows as $row)
            {
            if ($row[self::COL_ISRELATION])
                {
                $column = new RelationColumn ($row[self::COL_NAME],
                                              $row[self::COL_LABEL],
                                              $row[self::COL_DESCRIPTION],
                                              $row[self::COL_REQUIRED]);
                $column->relatedTableId = $row[self::COL_SIZE];
                $column->relationName = $row[self::COL_RELATIONNAME];
                }
            else
                {
                $columnDef = ColumnDefFactory::create ($row[self::COL_TYPE],
                                                       $row[self::COL_NAME],
                                                       $row[self::COL_SIZE],
                                                       $row[self::COL_PRECISION],
                                                       !$row[self::COL_REQUIRED],
                                                       $row[self::COL_DEFAULTVALUE]);
                $columnDef->modifiers = $row[self::COL_MODIFIERS];
                $columnDef->label = $row[self::COL_LABEL];
                $columnDef->defaultValue = $row[self::COL_DEFAULTVALUE];

                $column = new ValueColumn ($columnDef,
                                           $row[self::COL_LABEL],
                                           $row[self::COL_DESCRIPTION]);
                $column->translatable = $row[self::COL_TRANSLATABLE];
                }

            $column->required = $row[self::COL_REQUIRED];
            $column->sortOrder = $row[self::COL_SORTORDER];
            $column->sortAsc = $row[self::COL_SORTASC];
            $column->defaultValue = $row[self::COL_DEFAULTVALUE];
            $column->inputType = $row[self::COL_INPUTTYPE];
            $column->displayType = $row[self::COL_DISPLAYTYPE];
            $column->category = $row[self::COL_CATEGORY];

            $column->id = $row[self::COL_COLUMNID];
            $columns[] = $column;
            }

        return $columns;
        }

    public function changeOrder ($tableId, $id, $up)
        {
        $cache = Cache::getInstance (self::TABLE_NAME, 12*60*60);
        $cache->clean ();
        $criteria = array (new EqCriterion (self::COL_TABLEID, $tableId));
        return parent::changeItemOrder ($criteria, self::COL_COLUMNID, $id, $up);
        }

    public static function getPredefinedTypes ($context)
        {
        $textFieldSizes = array (10, 50, 100, 250);
        $fieldTypes = array
            (
            ColumnDefFactory::TYPE_TEXT."(64)" => $context->ngettext ("String (max [_0] character)", "String (max [_0] characters)", 64),
            ColumnDefFactory::TYPE_INTEGER => $context->getText ('Integer'),
            ColumnDefFactory::TYPE_DECIMAL => $context->getText ('Decimal'),
            ColumnDefFactory::TYPE_DATE => $context->getText ('Date'),
            ColumnDefFactory::TYPE_DATETIME => $context->getText ('Date and Time'),
            ColumnDefFactory::TYPE_BOOLEAN => $context->getText ('Boolean'),
            ColumnDefFactory::TYPE_LONGTEXT => $context->getText ('String of unlimited length'),
            ColumnDefFactory::TYPE_COMPOSITE => $context->getText ('Composite value'),
            ColumnDefFactory::TYPE_NAMEDINT => $context->getText ('Integer with label'),
            ColumnDefFactory::TYPE_HEIGHT => $context->getText ('Height'),
            ColumnDefFactory::TYPE_WEIGHT => $context->getText ('Weight'),
            );

        foreach ($textFieldSizes as $size)
            {
            $fieldTypes[ColumnDefFactory::TYPE_TEXT."($size)"] = $context->ngettext ("String (max [_0] character)", "String (max [_0] characters)", $size);
            }

        return $fieldTypes;
        }

    }

?>

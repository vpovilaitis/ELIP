<?php
function __autoload ($class_name)
    {
    $path = PATH."inc/".strtolower ($class_name).'.php';
    if (is_file ($path))
        {
        require_once $path;
        return;
        }

    if ("LabelFixedParentFieldTemplate" == $class_name)
        require_once PATH."inc/labelparentfieldtemplate.php";
    else if ("LongTextFieldTemplate" == $class_name)
        require_once PATH."inc/textfieldtemplate.php";
    else if (preg_match ("/Label.*Template/", $class_name))
        require_once PATH."inc/labelfieldtemplate.php";
    else if (preg_match ("/.*FieldTemplate/", $class_name))
        require_once PATH."inc/fieldtemplate.php";
    }

if (!empty($_REQUEST["_debug"]))
    define ("DEBUG", true);

require_once (PATH.'inc/general.php');

$usageLogger = new UsageLogger ();

$context = PageContext::getInstance ($_REQUEST);

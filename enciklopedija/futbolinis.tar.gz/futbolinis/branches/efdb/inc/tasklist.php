<?php

class TaskList extends Component
    {
    protected $descriptor;

    public function __construct ($prefix, $context, $descriptor)
        {
        parent::__construct ($prefix, $context);
        $this->descriptor = $descriptor;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getTemplateName ()
        {
        return "pages/tasklist";
        }

    public function getTitle ()
        {
        return $this->descriptor->getName ();
        }

    public function getDescriptor ()
        {
        return $this->descriptor;
        }
    }

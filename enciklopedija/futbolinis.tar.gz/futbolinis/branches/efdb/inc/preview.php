<?php
require_once (PATH.'inc/action.php');
require_once (PATH.'inc/deleteicon.php');
require_once (PATH.'inc/navigationicon.php');

abstract class Preview extends InteractiveComponent
    {
    public $lastUnconfirmedId = 0;
    protected $defaultPageSize = DEFAULT_PAGESIZE;
    protected $pagesize = NULL;
    protected $pageno = 0;
    protected $pageCount = NULL;
    protected $totalCount = NULL;

    protected $dbtable;

    protected $template;

    public function __construct ($prefix, $context, $dbtable)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = $dbtable;
        $this->messagesDisplayedInline = true;
        }

    public function processInput ($context, &$request)
        {
        if (isset ($request["page"]))
            $this->pageno = $request["page"];

        return parent::processInput ($context, $request);
        }

    protected function parseActionString ($request, $actionStr)
        {
        $parts = explode ("_", $actionStr);
        $action = $parts[0];

        if (count ($parts) > 1)
            {
            $id = substr ($actionStr, strlen ($action) + 1);
            $ids = array ($id);
            }
        else // if action was executed on multiple items, need to collect selected item list
            {
            $ids = isset ($request["previewitems"]) ? $request["previewitems"] : NULL;
            }

        $idColumns = $this->getIndexColumns ();

        $preparedIds = array();
        for ($i = 0; $i < count ($ids); $i++)
            {
            $id = explode ("_", $ids[$i]);
            if (count ($id) != count ($idColumns))
                {
                $this->log ("Incorrect ids were provided for the action.");
                $this->log ($id);
                $this->log ($idColumns);
                $this->addError ("Incorrect ids were provided for the action.");
                return false;
                }

            $preparedIds[] = $id;
            }

        return array ($action, $preparedIds);
        }

    public function getTemplateName ()
        {
        return "preview";
        }

    public function getTitle ()
        {
        return NULL;
        }

    public function getPageSize ()
        {
        if (NULL === $this->pagesize)
            {
            if (!empty ($_REQUEST[$this->prefix."_pagesize"]))
                $this->pagesize = $_REQUEST[$this->prefix."_pagesize"];

            if (empty ($this->pagesize))
                $this->pagesize = $this->defaultPageSize;
            }
        return $this->pagesize;
        }

    public function gotoPreviousPage ()
        {
        $this->pageno--;
        }

    public function gotoNextPage ()
        {
        $this->pageno++;
        }

    public function gotoFirstPage ()
        {
        $this->pageno = 0;
        }

    public function gotoLastPage ()
        {
        $this->pageno = -100;
        }

    public function getPage ()
        {
        if (-100 == $this->pageno || $this->pageno >= $this->getPageCount ())
            $this->pageno = $this->getPageCount () - 1;
        return $this->pageno;
        }

    public function setPage ($pageno)
        {
        $this->pageno = $pageno;
        }

    protected function getFilterCriteria ()
        {
        return NULL;
        }

    public function onFilterCriteriaChanged ()
        {
        $this->totalCount = NULL;
        $this->pageCount = NULL;
        }

    public function getTotalCount ()
        {
        if (NULL === $this->totalCount)
            {
            $this->prepareRowCountQuery ($cols, $criteria, $joins, $params);

            $rows = $this->dbtable->selectBy (array (new FunctionCount ("*", "cnt")), $criteria, $joins, $params);
            if (NULL != $rows)
                $this->totalCount = $rows[0]["cnt"];
            else
                $this->totalCount = 0;
            }

        return $this->totalCount;
        }

    public function getCountLabel ()
        {
        $totalCount = $this->getTotalCount ();
        if ($totalCount > 1)
            return $this->ngettext ("([_0] record)", "([_0] records)", $totalCount, $totalCount);
        else
            return NULL;
        }

    public function getPageCount ()
        {
        if (NULL === $this->pageCount)
            {
            if (NULL == $this->dbtable)
                return 1;

            $totalCount = $this->getTotalCount ();
            $this->pageCount = ceil (($totalCount - 0.5) / $this->getPageSize ());

            if ($this->pageCount < 1)
                $this->pageCount = 1;
            }

        return $this->pageCount;
        }

    protected abstract function getDisplayTemplate ();

    public function getTemplate ($fields = NULL)
        {
        if (empty ($fields) && NULL !== $this->template)
            return $this->template;

        /* default implementation */
        $availableFields = $this->getDisplayTemplate ();
        if (NULL == $fields)
            {
            $this->template = $availableFields;
            return $this->template;
            }
        else
            {
            $this->template = array ();
            for ($i = 0; $i < count ($fields); $i++)
                {
                for ($f = 0; $f < count ($availableFields); $f++)
                    {
                    if ($fields[$i] == $availableFields[$f]->key)
                        {
                        $this->template[] = $availableFields[$f];
                        }
                    }
                }
            }

        return $this->template;
        }

    public function getId ($row)
        {
        $idColumns = $this->getIdColumns ();
        if (!is_array ($idColumns))
            $idColumns = array ($idColumns);

        $ids = array();
        for ($i = 0; $i < count ($idColumns); $i++)
            {
            $ids[] = $row[$idColumns[$i]];
            }

        return implode ("_", $ids);
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if (empty ($editorLink))
            return NULL;
        $action = $new ? "new" : "edit";
        $class = $new ? "AdditionalURLIcon" : "SingleRowURLIcon";
        $url = "index.php?c=EditorPage&i=$editorLink&action=$action";
        if (!empty ($params))
            $url .= "&$params";
        $url = $this->context->processUrl ($url, true);

        return new $class ($this, $action, $title, $url);
        }

    public function getActionList ($excludeDelete = false)
        {
        if (NULL == $this->dbtable)
            return array();
        $ret = $this->getNavigationIcons();
        if (!$excludeDelete)
            $ret[] = new DeleteIcon ($this, $this->dbtable);

        $editor = $this->getEditorAction (false);
        if (!empty ($editor))
            $ret[] = $editor;

        return $ret;
        }

    public function getAdditionalActions ()
        {
        $ret = array();
        if (NULL != $this->dbtable && $this->dbtable->canCreate ())
            {
            $editor = $this->getEditorAction (true);
            if (!empty ($editor))
                $ret[] = $editor;
            }
        return $ret;
        }

    public function getSpecificPageUrl ($pageNo)
        {
        return $this->context->getAdjustedUrl (array ($this->getParam ("page") => $pageNo));
        }

    public function getNavigationIcons ()
        {
        $icons = array ();
        $icons[] = new FirstPageIcon ($this);
        $icons[] = new PreviousPageIcon ($this);

        $pageCount = $this->getPageCount ();
        $thisPage = $this->getPage ();
        $elipsisAdded = false;
        for ($i = 0; $i < $pageCount; $i++)
            {
            if (($i - $thisPage < NAV_PAGES && $thisPage - $i < NAV_PAGES) ||
                0 == $i || $pageCount-1 == $i)
                {
                $icons[] = new PageIcon ($this, $i);
                $elipsisAdded = false;
                }
            else if (!$elipsisAdded)
                {
                $icons[] = new PageSeparatorIcon ($this);
                $elipsisAdded = true;
                }
            }

        $icons[] = new NextPageIcon ($this);
        $icons[] = new LastPageIcon ($this);

        $pageSize = $this->getPageSize ();
        if (100 != $pageSize && $pageCount > 1)
            $icons[] = new PageSizeIcon ($this, 100);
        if (20 != $pageSize)
            $icons[] = new PageSizeIcon ($this, 20);

        return $icons;
        }

    public function select ($context, $criteria = NULL)
        {
        if (NULL == $this->dbtable)
            return false;

        $itemsPerPage = $this->getPageSize ();

        /* default implementation */
        $cols = array();

        $idColumns = $this->getIdColumns ();
        if (!is_array ($idColumns))
            $idColumns = array ($idColumns);

        for ($i = 0; $i < count ($idColumns); $i++)
            {
            $cols[] = $idColumns[$i];
            }

        if ($itemsPerPage > 0)
            $params[] = new LimitByPage ($this->getPage (), $itemsPerPage);

        $joins = NULL;

        $errorTarget = $this->context->setErrorTarget ($this);

        $this->prepareQuery ($cols, $criteria, $joins, $params);

        $ret = $this->dbtable->selectBy ($cols, $criteria, $joins, $params);

        $this->context->setErrorTarget ($errorTarget);
        return $ret;
        }

    protected function prepareRowCountQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        $filterBy = $this->getFilterCriteria ();
        if (!empty ($filterBy))
            {
            if (empty ($criteria))
                $criteria = $filterBy;
            else
                $criteria = array_merge ($criteria, $filterBy);
            }
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        $this->prepareRowCountQuery ($resultColumns, $criteria, $joins, $params);

        foreach ($this->getTemplate () as $field)
            {
            $field->prepareQuery ($resultColumns, $criteria, $joins, $params);
            }
        }

    public function getSearchFields ()
        {
        // override in child classes supporting filtering/search
        return NULL;
        }

    }

?>

<?php
require_once (PATH.'inc/component.php');

abstract class Page extends Component
    {
    protected $initialTitle;
    public function __construct ($context, $title, $textdomain = NULL)
        {
        parent::__construct (NULL, $context, $textdomain);
        $this->initialTitle = $title;
        }

    public function process ($request)
        {
        $this->request = $request;

        if (!$this->ensureChildren ($this->context, $this->request))
            {
            return false;
            }

        if (!$this->checkAccess ($this->request))
            {
            $this->log ("No access - ".get_class ($this));
            $this->addError ("You have no access to perform a requested operation");
            $this->context->suggestLogin ();

            $this->components = array ();
            $this->renderComponent ($this->context, $request);
            return true;
            }

        if (false === $this->processInput ($this->context, $this->request))
            {
            $this->log ("processInput Failed - ".get_class ($this));
            return false;
            }

        return $this->renderComponent ($this->context, $this->request);
        }

    protected function renderComponent ($context, $request)
        {
        /* show the context */
        displayFromTemplate ($context,
                             $this->getPageTemplateDir (),
                             $this->getTemplateName (),
                             $this->getDisplayParams ($request));
        }

    protected function getPageTemplateDir ()
        {
        return ".";
        }

    protected function showError ($error)
        {
        $this->displayErrorPage ($error);
        return false;
        }

    protected abstract function checkAccess ($request);

    protected function getDisplayParams ($request)
        {
        return array ("components" => $this->components, "page" => $this, "this" => $this);
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setErrorTarget ($this);

        if ($this->initialTitle)
            $context->setTitle ($this->initialTitle);
        return true;
        }
    }

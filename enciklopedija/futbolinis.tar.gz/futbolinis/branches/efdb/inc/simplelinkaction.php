<?php

// very similar to AdditionalURLIcon - should be merged
class SimpleLinkAction extends SingleRowURL
    {
    public function isVisible ($row = NULL)
        {
        return true;
        }

    public function getUrl ($request, $id)
        {
        if (!$this->preprocessed)
            return $this->context->processUrl ($this->url, true);
        return $this->url;
        }

    public function requiresId ()
        {
        return false;
        }
    }

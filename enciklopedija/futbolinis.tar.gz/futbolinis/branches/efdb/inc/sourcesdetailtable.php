<?php

class SourcesDetailTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "sourcesdetail";

    const COL_ID = "sd_id";
    const COL_SCOPE = "scope"; // 'm_fragments', 'x_persons', etc
    const COL_CONTEXTID = "contextid";
    const COL_DETAILS = "details";
    const COL_STATE = "state";
    const COL_CUSTOM = "customdata";

    const STATE_PENDING = 0;
    const STATE_PROCESSED = 1;
    const STATE_OUTDATED = 100;

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        $this->tracksRevisions = true;
        $this->tracksSources = true;
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID, false),
                     new TextColumn (self::COL_SCOPE, 128, false),
                     new TextColumn (self::COL_CONTEXTID, 32, false),
                     new LongTextColumn (self::COL_DETAILS, false),
                     new IntColumn (self::COL_STATE, false),
                     new LongTextColumn (self::COL_CUSTOM, true),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new Index (self::COL_SCOPE, self::COL_CONTEXTID),
            new Index (self::COL_SCOPE, self::COL_STATE),
            );
        }

    public static function selectExistingDetails ($context, $table, $id)
        {
        $dbtable = new SourcesDetailTable ($context);
        $tableName = $table->getTableName ();
        $criteria[] = new EqCriterion (self::COL_SCOPE, $tableName);
        $criteria[] = new EqCriterion (self::COL_CONTEXTID, $id);
        return $dbtable->selectBy (array (self::COL_ID, self::COL_DETAILS, self::COL_STATE, self::COL_CUSTOM, DBTable::COL_SOURCE), $criteria);
        }

    public static function storeDetails ($context, $table, $id, $details, $source, $sourceDate, $isPending = true, $customObject = NULL)
        {
        $dbtable = new SourcesDetailTable ($context);
        $tableName = $table->getTableName ();

        return $dbtable->insertRecord (array (self::COL_SCOPE => $tableName, self::COL_CONTEXTID => $id,
                                              self::COL_DETAILS => $details, self::COL_STATE => $isPending ? self::STATE_PENDING : self::STATE_PROCESSED,
                                              self::COL_CUSTOM => !empty ($customObject) ? json_encode ($customObject) : NULL,
                                              DBTable::COL_SOURCE => $source,
                                              DBTable::COL_SOURCEDATE => $sourceDate
                                              ));
        }

    }

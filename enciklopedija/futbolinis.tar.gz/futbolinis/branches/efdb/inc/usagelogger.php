<?php
require_once (PATH.'inc/base.php');
require_once (PATH.'inc/dbconnection.php');

class UsageLogger
    {
    protected $startedAt;

    const COL_ID = "id";
    const COL_REQUEST_URI = "requesturi";
    const COL_SCRIPT_NAME = "scriptname";
    const COL_QUERY_STRING = "querystring";
    const COL_USER_IP = "ip";
    const COL_USER_ID = "userid";
    const COL_STARTED_AT = "start";
    const COL_FINISHED_AT = "end";
    const COL_STATUS = "status";
    const COL_REFERER = "referer";
    const COL_USER_AGENT = "useragent";
    const COL_DETAILS = "details";

    public function __construct ()
        {
        $this->startedAt = microtime (true);
        }

    public function __destruct ()
        {
        if (NULL !== $this->startedAt)
            $this->logFinish (0);
        }

    public function logFinish ($httpStatus)
        {
        $startedAt = $this->startedAt;
        $this->startedAt = NULL;

        $context = PageContext::getInstance ($_REQUEST);
        if (!empty ($context))
            {
            $finishedAt = microtime (true);
            $needToLog = LOG_USAGE;
            if ("slow" == LOG_USAGE)
                {
                $duration = $finishedAt-$startedAt;
                $needToLog = ($finishedAt-$startedAt >= SLOW_PAGE_TIME || MySqlConnection::totalQueryDuration () >= SLOW_QUERY_TIME);
                }

            if ($needToLog)
                {
                $db = $context->getConnection ();
                if (!empty ($db) && $db->connected ())
                    {
                    if (false !== $this->insertRecord ($db, $_REQUEST, $httpStatus, $startedAt, $finishedAt, $context->getCurrentUser ()))
                        {
                        if (isset ($_REQUEST["verbose"]))
                            echo "<H1>Served in ".($finishedAt-$startedAt)." s </H1>";
                        else
                            echo "<!-- ".($finishedAt-$startedAt)." s -->";
                        return true;
                        }
                    }
                }
            else
                {
                if (isset ($_REQUEST["verbose"]))
                    echo "<H1>Served in ".($finishedAt-$startedAt)." s </H1>";
                else
                    echo "<!-- ".($finishedAt-$startedAt)." s -->";
                return true;
                }
            }
        echo "<!-- ERROR! Usage was not logged -->";
        }

    public function insertRecord ($db, $request, $httpStatus, $startedAt, $finishedAt, $userId)
        {
        $startedAt = str_replace (",", ".", sprintf ("%f", $startedAt));
        $finishedAt = str_replace (",", ".", sprintf ("%f", $finishedAt));
        $nameToValue = array (self::COL_USER_ID => $userId, self::COL_STATUS => $httpStatus, 
                              self::COL_STARTED_AT => $startedAt, self::COL_FINISHED_AT => $finishedAt, );

        if (!empty ($_SERVER["QUERY_STRING"]))
            $nameToValue[self::COL_QUERY_STRING] = $_SERVER["QUERY_STRING"];
        if (!empty ($_SERVER["SCRIPT_NAME"]))
            $nameToValue[self::COL_SCRIPT_NAME] = ("*" != SITE_PERSPECTIVE ? SITE_PERSPECTIVE.":" : "").$_SERVER["SCRIPT_NAME"];
        if (!empty ($_SERVER["REMOTE_ADDR"]))
            $nameToValue[self::COL_USER_IP] = $_SERVER["REMOTE_ADDR"];
        if (!empty ($_SERVER["REQUEST_URI"]))
            $nameToValue[self::COL_REQUEST_URI] = $_SERVER["REQUEST_URI"];
        if (!empty ($_SERVER["HTTP_REFERER"]))
            $nameToValue[self::COL_REFERER] = $_SERVER["HTTP_REFERER"];
        if (!empty ($_SERVER["HTTP_USER_AGENT"]))
            $nameToValue[self::COL_USER_AGENT] = $_SERVER["HTTP_USER_AGENT"];
        $nameToValue[self::COL_DETAILS] = Base::getLogText ();

        foreach ($nameToValue as $key => &$val)
            {
            if (self::COL_USER_ID == $key || self::COL_STARTED_AT == $key || self::COL_FINISHED_AT == $key || self::COL_STATUS == $key)
                continue;
            $val = "'".addslashes (trim ($val))."'";
            }

        $tableName = "u_usage";
        if (false !== $db->insertRecord ($tableName, $nameToValue))
            return true;

        $columns = array 
            (
            new AutoincrementColumn (self::COL_ID),
            new IntColumn (self::COL_USER_ID, false),
            new TextColumn (self::COL_USER_IP, 64, true),
            new TextColumn (self::COL_REQUEST_URI, 512, true),
            new TextColumn (self::COL_SCRIPT_NAME, 512, true),
            new TextColumn (self::COL_QUERY_STRING, 1024, true),
            new IntColumn (self::COL_STATUS, false),
            new DecimalColumn (self::COL_STARTED_AT, false, 16, 4),
            new DecimalColumn (self::COL_FINISHED_AT, false, 16, 4),
            new TextColumn (self::COL_REFERER, 1024, true),
            new TextColumn (self::COL_USER_AGENT, 512, true),
            new LongTextColumn (self::COL_DETAILS, true),
            );
        if (!$db->createTable ($tableName, $columns))
            return false;

        if (false !== $db->insertRecord ($tableName, $nameToValue))
            return true;
        return false;
        }
    }

<?php

class Image
    {
    protected $filePath;
    protected $useImagick;
    protected $image;
    protected $imagesize = NULL;
    protected $backgroundColor = NULL;

    public function __construct ()
        {
        $this->useImagick = false;
        }

    function __destruct ()
        {
        if (NULL !== $this->backgroundColor)
            {
            imagecolordeallocate ($this->image, $this->backgroundColor);
            $this->backgroundColor = NULL;
            }
        if (!$this->useImagick && $this->image)
            imagedestroy ($this->image);
        }

    protected function getSize ($context)
        {
        if (NULL !== $this->imagesize)
            return $this->imagesize;
        $this->imagesize = @getimagesize ($this->filePath);
        return $this->imagesize;
        }

    public function isMultiPage ()
        {
        if ($this->useImagick)
            {
            switch ($this->image->getImageFormat ())
                {
                case "TIF":
                case "TIFF":
                case "PDF":
                    return true;
                }
            }

        return false;
        }

    public function getMimeType ($context)
        {
        if ($this->useImagick)
            {
            switch ($this->image->getImageFormat ())
                {
                case "JPEG":
                case "JPG":
                    return 'image/jpeg';
                case "PNG":
                    return 'image/png';
                case "GIF":
                    return 'image/gif';
                case "TIF":
                case "TIFF":
                    return 'image/jpeg';
                }
            return 'text/plain';
            }

        $size = $this->getSize ($context);
        return $size['mime'];
        }

    protected function savePage ($image, $name)
        {
        $image->setImageFormat ("GIF");
        /* make grayscale
        $image->modulateImage (100, 0, 50);
        $image->setImageColorSpace (Imagick::COLORSPACE_GRAY);
        */

        /* trim borders
        $image->trimImage($range * 0.5);
        $image->setImagePage(0, 0, 0, 0);
        */

        $image->setImageFileName ($name);
        $image->writeImage ();
        return $name;
        }

    public function splitPages ($basePath, $fileName)
        {
        if (!$this->useImagick)
            return array ();
        $result = array ();
        @set_time_limit (60*10);
        foreach ($this->image as $i => $image)
            {
            $initialWidth = $image->getImageWidth ();
            $initialHeight = $image->getImageHeight ();
            $ratio = $initialHeight/$initialWidth;
            if ($ratio >= 1.5)
                {
                $img = $image->getImage ();
                $image->cropImage ($initialWidth, $initialWidth * 1.33, 0, 0);
                $image->setImagePage(0, 0, 0, 0); 
                $result["{$i}.1"] = $this->savePage ($image, $basePath."$fileName-{$i}.1.gif");

                if ($ratio >= 2.5)
                    {
                    $img->cropImage ($initialWidth, min ($initialHeight - $initialWidth * 1.33, $initialWidth * 1.4), 0, $initialWidth * 1.35);
                    $img->setImagePage(0, 0, 0, 0); 
                    $result["{$i}.2"] = $this->savePage ($img, $basePath."$fileName-{$i}.2.gif");
                    }
                }
            else
                {
                $result[$i] = $this->savePage ($image, $basePath."$fileName-$i.gif");
                }
            }

        return $result;
        }

    public function readFile ($context, $filePath)
        {
        $this->filePath = $filePath;
        $mime = $this->getMimeType ($context);

        if (('image/tiff' == $mime || empty ($mime)) && class_exists ("Imagick", false))
            {
            $this->useImagick = true;
            try
                {
                $this->image = new Imagick ();
                if (true !== $this->image->readImage ($this->filePath))
                    {
                    $context->addError ("Incorrect image was uploaded.");
                    return false;
                    }
                }
            catch(Exception $e)
                {
                $context->addError ($e->getMessage());
                return false;
                }
            }
        else
            {
            $this->image = self::openImage ($context, $filePath, $mime);
            if (false === $this->image)
                return false;
            }

        return true;
        }

    protected static function openImage ($context, $filePath, $mimeType)
        {
        ini_set ("memory_limit", "128M");
        switch ($mimeType)
            {
            case 'image/gif':
                if (imagetypes() & IMG_GIF)
                    $image = imagecreatefromgif ($filePath);
                break;
            case 'image/jpeg':
                if (imagetypes() & IMG_JPG)
                    $image = imagecreatefromjpeg ($filePath);
                break;
            case 'image/png':
                if (imagetypes() & IMG_PNG)
                    $image = imagecreatefrompng ($filePath);
                break;
            case 'image/wbmp':
                if (imagetypes() & IMG_WBMP)
                    $image = imagecreatefromwbmp ($filePath);
                break;
            }
        
        if (empty ($image))
            {
            $context->addError ("Image type [_0] not supported", $mimeType ? $mimeType : "-");
            return false;
            }

        return $image;
        }

    public function outputImage ($context, $filePath)
        {
        if ($this->useImagick)
            {
            header('Content-Length: '.$this->image->getImageLength ());
            $this->image->setImageFormat ("jpeg");

            echo $this->image->getImageBLOB();
            }
        else
            {
            header('Content-Length: '.filesize ($filePath));
            readfile ($filePath);
            }
        }
        
    public function writeFile ($context, $filePath)
        {
        if ($this->useImagick)
            {
            $this->image->setImageFileName ($filePath);
            //$this->image->raiseImage (3, 3, 0, 0, false);
            $this->image->writeImage ();
            return true;
            }
        else
            {
            $extension = pathinfo ($filePath, PATHINFO_EXTENSION);

            if (0 === strcasecmp ($extension, "png"))
                imagepng ($this->image, $filePath);
            else
                imagejpeg ($this->image, $filePath);

            if (NULL !== $this->backgroundColor)
                {
                imagecolordeallocate ($this->image, $this->backgroundColor);
                $this->backgroundColor = NULL;
                }
            imagedestroy ($this->image);
            $this->image = NULL;
            return true;
            }

        return true;
        }

    public function resizeImage ($context, $maxWidth, $maxHeight, $savePng = false)
        {
        if (!$this->image)
            return false;

        if ($this->useImagick)
            {
            $this->image->thumbnailImage ($maxWidth, $maxHeight);
            $this->image->setImageFormat ("JPEG");
            return true;
            }
            
        $sourceWidth = imagesx ($this->image);
        $sourceHeight = imagesy ($this->image);

        if (empty ($maxHeight))
            $maxHeight = round ($sourceHeight * $maxWidth / $sourceWidth, 0);
        else if (empty ($maxWidth))
            $maxWidth = round ($sourceWidth * $maxHeight / $sourceHeight, 0);

        // lets check if borders need to be left on top/bottom or on the left/right sides
        $coefX = $maxWidth / $sourceWidth;
        $coefY = $maxHeight / $sourceHeight;
        $coef = min ($coefX, $coefY, 1);
        $startX = round (($maxWidth - $coef * $sourceWidth) / 2);
        $startY = round (($maxHeight - $coef * $sourceHeight) / 2);
        
        // now lets resize
        if (imageistruecolor ($this->image))
            $targetImage = imagecreatetruecolor ($maxWidth, $maxHeight);
        else
            $targetImage = imagecreate ($maxWidth, $maxHeight);

        if ($savePng)
            {
            imagealphablending ($targetImage, false);
            imagesavealpha ($targetImage, true);
            $this->backgroundColor = imagecolorallocatealpha ($targetImage, 255, 255, 255, 127);
            imagefilledrectangle ($targetImage, 0, 0, $maxWidth - 1, $maxHeight - 1, $this->backgroundColor);
            }
        else
            {
            list ($r, $g, $b) = $context->getBackgroundColor ();
            $this->backgroundColor = imagecolorallocate ($targetImage, $r, $g, $b);
            imagefilledrectangle ($targetImage, 0, 0, $maxWidth - 1, $maxHeight - 1, $this->backgroundColor);
            }

        imagecopyresampled ($targetImage, $this->image,
                          $startX, $startY, // destination upper-left
                          0, 0, // source upper-left
                          $coef * $sourceWidth, $coef * $sourceHeight, // destination dimensions
                          $sourceWidth, $sourceHeight   // source dimensions
                          );
        imagedestroy ($this->image);

        // save the resized image
        imageinterlace ($targetImage, 1);
        $this->image = $targetImage;
        return true;
        }

    }

<?php
require_once (PATH."inc/urlicon.php");

class NewsLinkDescriptor extends BaseWithContext
    {
    protected $dbtable;
    protected $uniqueId;

    public function __construct ($context, $dbtable, $uniqueId)
        {
        parent::__construct ($context);
        $this->dbtable = $dbtable;
        $this->uniqueId = $uniqueId;
        }

    public function getNewsItemLink ($entry)
        {
        return NewsLinkDescriptor::getItemLink ($this->dbtable, $entry);
        }

    public function getId ($entry)
        {
        return $entry[NewsTable::COL_ID];
        }

    public static function getItemLink ($dbtable, $entry)
        {
        $context = $dbtable->getContext ();
        $id = !empty ($entry) ? $entry[NewsTable::COL_ID] : "#ID#";
        $scope = $dbtable->getPerspective ();
        if ($scope == $context->getPerspective ())
            $url = $context->chooseUrl ("newsitem/$id", "index.php?c=NewsListPage&id=$id");
        else
            $url = $context->chooseUrl ("newsitem/$scope/$id", "index.php?c=NewsListPage&id=$id&sp=$scope");
        return $url;
        }

    public function getRssLink ()
        {
        $scope = $this->dbtable->getPerspective ();
        if ($scope != $this->context->getPerspective ())
            return $this->context->processUrl ("index.php?c=Rss&ch=NewsFeed&sp=$scope");

        $rssUrl = $this->context->chooseUrl ("feed/NewsFeed/", "index.php?c=Rss&ch=NewsFeed&sp=");
        return $rssUrl;
        }

    public function getActionList ($includeMoreAction = true)
        {
        $actions = array ();
        if ($includeMoreAction)
            $actions[] = new NewsLinkIcon ($this, "more", $this->context->getText ("More..."), $this->getNewsItemLink (NULL));
        $scope = $this->dbtable->getPerspective () == $this->context->getPerspective () ? "" : $this->dbtable->getPerspective ();
        if ($this->dbtable->canEdit())
            $actions[] = new EditNewsIcon ($this, "edit", $this->context->getText ("Edit"), "index.php?c=EditorPage&i=pages/NewsEditor&action=edit&sp=$scope");
        return $actions;
        }

    public function getMoreLabel ($entry)
        {
        if (empty ($entry[NewsTable::RESULTCOL_HAS_DETAILS]))
            return NULL;
        return $this->context->getText ("More...|news");
        }

    public function getDiscussionLink ($entry, $new = false)
        {
        $id = $this->getId ($entry);
        $scope = Constants::TABLES_PREDEFINED."_".NewsTable::TABLE_NAME;
        if ($new)
            return $this->context->processUrl ("index.php?service=EditDiscussionItemPopup&action=new&sc=$scope&cid=$id&ctn=d{$scope}$id", true);
        return $this->context->processUrl ("index.php?service=EditDiscussionItemPopup&action=show&mode=save&sc=$scope&cid=$id&ctn=d{$scope}$id", true);
        }

    public function canCreate ()
        {
        return $this->dbtable->canCreate ();
        }

    public function canEdit ()
        {
        return $this->dbtable->canEdit ();
        }

    public function getCreateRecordLabel ()
        {
        return $this->context->getText ("Add new");
        }

    public function getRssLabel ()
        {
        return $this->context->getText ("RSS feed");
        }

    public function getNewsPreviewLink ()
        {
        $scope = $this->dbtable->getPerspective ();
        if ($scope != $this->context->getPerspective ())
            return $this->context->chooseUrl ("sitenews/$scope", "index.php?c=NewsListPage&sp=$scope");
        $url = $this->context->chooseUrl ("sitenews", "index.php?c=NewsListPage");
        return $url;
        }

    public function getNewsPreviewLabel ()
        {
        return $this->context->getText ("News archive");
        }

    public function getPublishNewsLabel ()
        {
        return $this->context->getText ("Publish");
        }

    public function getCloseButtonLabel ()
        {
        return $this->context->getText ("Close");
        }

    public function getCreateNewsItemLink ()
        {
        $scope = $this->dbtable->getPerspective () == $this->context->getPerspective () ? "" : $this->dbtable->getPerspective ();
        $url = $this->context->processUrl ("index.php?c=EditorPage&i=pages/NewsEditor&sp=$scope&action=new", true);
        return $url;
        }

    public function getCreateNewsPopupLink ()
        {
        $scope = $this->dbtable->getPerspective () == $this->context->getPerspective () ? "" : $this->dbtable->getPerspective ();
        $url = $this->context->processUrl ("index.php?service=EditNewsItemPopup&action=new&sp=$scope&uniqueId=".$this->uniqueId, true);
        return $url;
        }

    public function getPublishNewsPopupLink ()
        {
        $scope = $this->dbtable->getPerspective () == $this->context->getPerspective () ? "" : $this->dbtable->getPerspective ();
        $url = $this->context->processUrl ("index.php?service=EditNewsItemPopup&action=publish&mode=save&sp=$scope&uniqueId=".$this->uniqueId, true);
        return $url;
        }

    public function getEditNewsPopupLink ()
        {
        $scope = $this->dbtable->getPerspective () == $this->context->getPerspective () ? "" : $this->dbtable->getPerspective ();
        $url = $this->context->processUrl ("index.php?service=EditNewsItemPopup&action=edit&sp=$scope&uniqueId=".$this->uniqueId, true);
        return $url;
        }

    public function retrieveImageContext ()
        {
        return NULL;
        }
    }

class NewsLinkIcon extends SingleRowURLIcon
    {
    public function isVisible ($row = NULL)
        {
        if (empty ($row))
            return false;

        if (array_key_exists (NewsTable::RESULTCOL_HAS_DETAILS, $row))
            return $row[NewsTable::RESULTCOL_HAS_DETAILS];
        if (array_key_exists (NewsTable::COL_DETAILS, $row))
            return !empty ($row[NewsTable::COL_DETAILS]);

        return true;
        }

    public function getUrl ($request, $row)
        {
        $id = $this->component->getId ($row);
        $url = str_replace ("#ID#", $id, $this->url);
        return $url;
        }
    }

class EditNewsIcon extends SingleRowURLIcon
    {
    public function getAdditionalAttributes ($row)
        {
        $pairs = parent::getAdditionalAttributes ($row);
        $pairs["action"] = $this->key;
        $pairs["itemid"] = $this->component->getId ($row);
        if (!empty ($row[NewsTable::COL_HIDDEN]))
            $pairs["unpublished"] = "true";
        return $pairs;
        }

    }
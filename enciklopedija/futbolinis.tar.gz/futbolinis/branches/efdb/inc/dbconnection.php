<?php

require_once (PATH."inc/columndef.php");
require_once (PATH."inc/criteria.php");
require_once (PATH.'inc/query.php');

abstract class DBConnection extends Base
    {
    protected $context;

    public function __construct ($context)
        {
        $this->context = $context;
        }
    
    public function __destruct ()
        {
        }

    /* must override (see example in MySqlConnection class source) */ 
    public abstract function connect ($host, $db, $user, $pass);
    public abstract function connected ();
    protected abstract function executeSQL ($sqlStatement, $returnAffected = false);
    protected abstract function executeInsert ($sqlStatement, $canUpdate = false); /* return id of the inserted column (if any) or -1 */
    protected abstract function executeSelect ($sqlStatement);
    public abstract function dropTable ($tableName);
    public abstract function dropColumn ($tableName, $columnName);
    public abstract function addColumn ($table, $coldef);
    public abstract function startTransaction ();
    public abstract function commitTransaction ();
    public abstract function rollbackTransaction ();
    public abstract function tableExists ($tableName);
    public abstract function tablesExists ($tableNames);
        
    public function prepareTableName ($tablename)
        {
        return DB_PREF.$tablename;
        }

    public function prepareColumnName ($name)
        {
        return $name;
        }

    public function lockTables ($tables)
        {
        return false;
        }

    public function unlockTables ($tables)
        {
        return false;
        }

    public function getRowCount ($tablename)
        {
        $tablename = $this->prepareTableName ($tablename);
        $row = $this->executeSelect ("select count(*) cnt from $tablename");
        if (NULL == $row)
            return -1;
        return $row[0]["cnt"];
        }

    protected function getTypeString ($columnDef)
        {
        /* override to map default data types and modifiers to DB-engine specific strings */
        
        $str = $columnDef->type;
        if ($columnDef->size > 0)
            $str .= "(".$columnDef->size.")";
        if (!$columnDef->acceptNull)
            $str .= " not null";
        if (NULL != $columnDef->modifiers)
            $str .= " ".$columnDef->modifiers;
        $defaultVal = $columnDef->getDefaultValue ();
        if (isset ($defaultVal) && NULL !== $defaultVal)
            $str .= " default ".(false === $defaultVal ? 0 : $defaultVal);

        return $str;
        }

    protected function getTableModifiers ()
        {
        /* override to add any modifiers for created table just after the create table statement */
        return "";
        }

    public function createTable ($tablename, $columnDefinitions)
        {
        $tablename = $this->prepareTableName ($tablename);
        $sql = "create table $tablename (";
        $count = 0;
        $primaryKey = NULL;
        for ($i = 0; $i < count ($columnDefinitions); $i++)
            {
            if ($columnDefinitions[$i] instanceof GhostColumn)
                continue;

            if ($count > 0)
                $sql .= ", ";

            $def = $columnDefinitions[$i];
            $sql .= $this->prepareColumnName ($def->name)." ".$this->getTypeString ($def);
            $count++;
            
            if ($def instanceof AutoincrementColumn)
                $primaryKey = $this->prepareColumnName ($def->name);
            }

        if (NULL != $primaryKey)
            $sql .= ", PRIMARY KEY ($primaryKey)";

        $sql .= ")".$this->getTableModifiers ();
        
        return $this->executeSQL ($sql);
        }
        
    public function addIndex ($tablename, $order, $index)
        {
        /* override to implement DB specific functionality*/
        return true;
        }

    public function dropIndex ($tablename, $indexName)
        {
        /* override to implement DB specific functionality*/
        return true;
        }

    public function insertRecord ($tablename, $initialValues)
        {
        return $this->insertOrUpdateRecord ($tablename, $initialValues, NULL);
        }

    public function insertOrUpdateRecord ($tablename, $initialValues, $updateValues)
        {
        $tablename = $this->prepareTableName ($tablename);
        $columnNames = array ();
        foreach ($initialValues as $col => $val)
            $columnNames[] = $this->prepareColumnName ($col);

        $columns = implode (", ", $columnNames);
        $values = implode (", ", array_values ($initialValues));

        $sql = "insert into $tablename ($columns) values ($values)";

        if (!empty ($updateValues))
            {
            $valueParts = array ();
            foreach ($updateValues as $col => $val)
                $valueParts[] = "{$this->prepareColumnName ($col)}=$val";

            $sql .= " ON DUPLICATE KEY UPDATE ".implode (", ", $valueParts);
            }

        return $this->executeInsert ($sql, !empty ($updateValues));
        }

    public function insertFromQuery ($tablename, $insertColumns, $query)
        {
        $tablename = $this->prepareTableName ($tablename);
        $columnNames = array ();
        foreach ($insertColumns as $col)
            $columnNames[] = $this->prepareColumnName ($col);

        $columns = implode (", ", $columnNames);

        $selectSql = $this->createSelectStatement ($query, NULL);
        $sql = "insert into $tablename ($columns) $selectSql";
        return $this->executeInsert ($sql);
        }

    protected function prepareSelectStatement ($statement, $tablename, $tablealias, $criteria)
        {
        $tablename = $this->prepareTableName ($tablename);

        $sql = "$statement from $tablename";
        if (NULL != $tablealias)
            $sql .= " $tablealias";
        $criteriaCount = 0;
        
        for ($i = 0; $i < count ($criteria); $i++)
            {
            if (0 == $i)
                $sql .= " where ";
            else
                $sql .= " and ";

            $sql .= $criteria[$i]->formatForDB ($this, $tablealias);
            }

        return $sql;
        }

    public function selectBy ($tablename, $resultColumns, $criteria)
        {
        return $this->select (new Query ($tablename, $resultColumns, $criteria));
        }

    public function deleteBy ($tablename, $criteria)
        {
        $sql = $this->prepareSelectStatement ("delete", $tablename, NULL, $criteria);
        return $this->executeSql ($sql, true);
        }

    protected function createAlias (&$index)
        {
        $index++;
        return "`tbl{$index}`";
        }

    protected function extractResultColumns ($query)
        {
        $tableAlias = $query->physicalAlias;
        $columns = array();
        $queryColumns = $query->getColumns ();
        if (!empty ($queryColumns))
            {
            foreach ($queryColumns as $col)
                {
                $columns[] = $col->toString ($tableAlias, $this, $query);
                }
            }

        $joinedQueries = $query->getJoinedQueries ();
        if (NULL == $joinedQueries)
            return $columns;

        for ($i = 0; $i < count ($joinedQueries); $i++)
            {
            $columns = array_merge ($columns,
                                    $this->extractResultColumns ($joinedQueries[$i]));
            }

        return $columns;
        }

    protected function extractGroupByColumns ($query)
        {
        $tableAlias = $query->physicalAlias;
        $columns = array();
        foreach ($query->groupBy as $gr)
            {
            if (false !== strpos ($gr, "("))
                $columns[] = $gr;
            else if (false === strpos ($gr, "."))
                $columns[] = $tableAlias.".".$this->prepareColumnName ($gr);
            else
                $columns[] = $this->prepareColumnName ($gr);
            }

        $joinedQueries = $query->getJoinedQueries ();
        if (NULL == $joinedQueries)
            return $columns;

        for ($i = 0; $i < count ($joinedQueries); $i++)
            {
            $columns = array_merge ($columns,
                                    $this->extractGroupByColumns ($joinedQueries[$i]));
            }

        return $columns;
        }

    protected function extractOrderByColumns ($query)
        {
        $tableAlias = $query->physicalAlias;
        $columns = array();
        $columnsWithoutPriority = array();
        $unprioritizedCount = 0;

        if (!empty ($query->orderBy))
            {
            foreach ($query->orderBy as $item)
                {
                $desc = "";
                if (!$item->ascending)
                    $desc = " desc";
                $prefix = "";
                if (!$item->isAlias)
                    $prefix = $tableAlias.".";

                if (NULL === $item->priority)
                    $columnsWithoutPriority["$tableAlias".++$unprioritizedCount] = $prefix.$item->name.$desc;
                else
                    $columns["a".$item->priority] = $prefix.$item->name.$desc;
                }
            }

        $joinedQueries = $query->getJoinedQueries ();
        if (!empty ($joinedQueries))
            {
            for ($i = 0; $i < count ($joinedQueries); $i++)
                {
                $subQueryColumns = $this->extractOrderByColumns ($joinedQueries[$i]);
                foreach ($subQueryColumns as $priority => $col)
                    $columns[$priority] = $col;
                }
            }

        ksort ($columns);

        if (!empty ($columnsWithoutPriority))
            {
            foreach ($columnsWithoutPriority as $key => $col)
                $columns[$key] = $col;
            }

        return $columns;
        }

    protected function extractTablesToSelect ($query, $parentAlias, $level, &$index)
        {
        if (0 == $level)
            $index = 0;

        $tableAlias = $this->createAlias ($index);
        $tableName = $this->prepareTableName ($query->table);
        $query->physicalAlias = $tableAlias;

        if ($level > 0)
            {
            switch ($query->joinType)
                {
                case Constants::JOIN_INNER:
                    $str = " inner join ";
                    break;
                case Constants::JOIN_LEFT_OUTER:
                    $str = " left outer join ";
                    break;
                default:
                    echo ("Unrecognized table join type '".$query->joinType."'");
                    exit();
                }

            $str .= "$tableName $tableAlias ON ";
            $joinedCriteria = array();
            $queryCriteria = $query->getJoinCriteria ();        
            for ($i = 0; $i < count ($queryCriteria); $i++)
                {
                $joinedCriteria[] = $queryCriteria[$i]->formatForDB ($this, $parentAlias, $tableAlias);
                }

            if (count ($joinedCriteria) == 0)
                $this->log ("Join criteria is missing - please add <code>new JoinColumnsCriterion (&lt;parent table id>, &lt;child table id>)</code> to the createQuery (table '$tableName')");
            $str .= implode (" and ", $joinedCriteria);
            }
        else
            $str = "$tableName $tableAlias";

        $joinedQueries = $query->getJoinedQueries ();
        if (NULL == $joinedQueries)
            return $str;

        for ($i = 0; $i < count ($joinedQueries); $i++)
            $str .= $this->extractTablesToSelect ($joinedQueries[$i], $tableAlias, $level+1, $index);

        return $str;
        }

    protected function extractCriteria ($query)
        {
        $tableAlias = $query->physicalAlias;
        $translationsTableAlias = NULL;

        $translQuery = $query->getTranslatableColumnSubquery ();
        if (!empty ($translQuery))
            $translationsTableAlias = $translQuery->physicalAlias;

        $criteria = array();
        $queryCriteria = $query->getCriteria ();
        for ($i = 0; $i < count ($queryCriteria); $i++)
            {
            $criteria[] = $queryCriteria[$i]->formatForDB ($this, $tableAlias, $translationsTableAlias);
            }

        $joinedQueries = $query->getJoinedQueries ();
        if (NULL == $joinedQueries)
            return $criteria;

        for ($i = 0; $i < count ($joinedQueries); $i++)
            {
            $criteria = array_merge ($criteria,
                                     $this->extractCriteria ($joinedQueries[$i]));
            }

        return $criteria;
        }

    protected function createSelectStatement ($query, $executionParams = NULL)
        {
        $distinct = "";
        $having = array ();
        if (!empty ($executionParams))
            {
            foreach ($executionParams as $param)
                {
                if ($param instanceof Distinct)
                    $distinct = "distinct ";
                else if ($param instanceof HavingCriteria)
                    $having[] = $param->toString ($query); // TODO: move to query and add table aliases (if needed)
                }
            }

        $tables = $this->extractTablesToSelect ($query, NULL, 0, $idx);
        $columns = implode (", ", $this->extractResultColumns ($query));
        $criteria = $this->extractCriteria ($query);

        if (strlen ($columns) == 0)
            $columns = "*";

        $sql = "select $distinct$columns\n FROM $tables";

        if (NULL != $criteria && count ($criteria) > 0)
            $sql .= "\n WHERE ".implode ("\n  and ", $criteria);

        $groupBy = $this->extractGroupByColumns ($query);

        if (!empty ($groupBy))
            $sql .= "\n GROUP BY ".implode (", ", $groupBy);

        if (!empty ($having))
            $sql .= "\n HAVING ".implode ("\n  AND ", $having);

        $orderBy = $this->extractOrderByColumns ($query);

        if (!empty ($orderBy))
            $sql .= "\n ORDER BY ".implode (", ", $orderBy);

        return $sql;
        }

    public function select ($query, $executionParams = NULL)
        {
        $sql = $this->createSelectStatement ($query, $executionParams);
        $rows = $this->executeSelect ($sql);
        if (empty ($rows))
            return $rows;

        $transformations = $query->getTransformations (true);
        $result = array ();

        foreach ($rows as $row)
            {
            $preparedRow = array ();
            foreach ($transformations as $col => $transform)
                {
                $preparedRow[$col] = $transform->getValue ($this->context, $transformations, $row);
                }
            $result[] = $preparedRow;
            }

        return $result;
        }

    protected function update ($tablename, $criteria, $setValues)
        {
        $tablename = $this->prepareTableName ($tablename);
        $sql = "update $tablename SET $setValues";
        $criteriaCount = 0;
        for ($i = 0; $i < count ($criteria); $i++)
            {
            if (0 == $i)
                $sql .= " where ";
            else
                $sql .= " and ";

            $sql .= $criteria[$i]->formatForDB ($this, NULL);
            }

        return $this->executeSql ($sql, true);
        }

    public function updateRecord ($tablename, $criteria, $values)
        {
        $valueParts = array();
        
        foreach ($values as $col => $val)
            {
            $valueParts[] = "{$this->prepareColumnName ($col)}=$val";
            }

        return $this->update ($tablename, $criteria, implode (", ", $valueParts));
        }

    public function alterColumnValue ($tablename, $column, $criteria, $alterBy)
        {
        $column = $this->prepareColumnName ($column);
        $setValues = "$column=$column$alterBy";
        return $this->update ($tablename, $criteria, $setValues);
        }

    /* for internal use only */
    public function executeCustomSQL ($sqlStatement, $returnAffected = false)
        {
        return $this->executeSQL ($sqlStatement, $returnAffected);
        }
    public function executeCustomSelect ($sqlStatement)
        {
        return $this->executeSelect ($sqlStatement);
        }

    }

abstract class IndexBase
    {
    public $name;
    public $columns;
    public $translatableTable;

    public function initialize ($args)
        {
        if (count ($args) == 1 && is_array ($args[0]))
            $this->columns = $args[0];
        else
            $this->columns = $args;
        }
    }

class Index extends IndexBase
    {
    public function __construct ()
        {
        $cols = func_get_args ();
        $this->initialize ($cols);
        }
    }

class UniqueIndex extends IndexBase
    {
    public function __construct ()
        {
        $cols = func_get_args ();
        $this->initialize ($cols);
        }
    }

class PrimaryIndex extends IndexBase
    {
    public function __construct ()
        {
        $cols = func_get_args ();
        $this->initialize ($cols);
        }
    }

class FullTextIndex extends IndexBase
    {
    public function __construct ()
        {
        $cols = func_get_args ();
        $this->initialize ($cols);
        }
    }

<?php
require_once (PATH."inc/dbconnection.php");

if (!defined ("DEBUG_VERBOSE"))
    define ("DEBUG_VERBOSE", false);

class MySqlConnection extends DBConnection
    {
    private $handle;
    private static $totalTime = 0;
    private static $startTime = NULL;

    public function __construct ($context)
        {
        parent::__construct($context);
        $this->handle = 0;
        }
    
    public function __destruct ()
        {
        $this->disconnect ();
        parent::__destruct();
        }

    public static function totalQueryDuration ()
        {
        return self::$totalTime;
        }

    protected function logDuration ($startTime, $endTime)
        {
        if (NULL === self::$startTime)
            self::$startTime = $startTime;

        self::$totalTime += $endTime-$startTime;
        $this->log ("Operation took ".($endTime-$startTime)." s. Total time: ".self::$totalTime." s (".($endTime-self::$startTime).")");        
        }

    public function disconnect ()
        {
        if (0 != $this->handle)
            {
            @mysql_close ($this->handle);
            }
        }

    public function connect ($host, $db, $user, $pass)
        {
        $this->disconnect ();
        
        if (DEBUG_VERBOSE)
            {
            $this->log ("mysql_connect ('$host', '$db', '$user', '******')");
            $startTime = microtime (true);
            }

        if (($this->handle = mysql_connect ($host, $user, $pass)))
            {
            if (@mysql_select_db ($db, $this->handle))
                {
                @mysql_query("SET NAMES 'utf8'");

                if (DEBUG_VERBOSE)
                    $this->logDuration ($startTime, microtime (true));
                return true;
                }
            }

        $this->logError ();
        return false;
        }

    public function connected ()
        {
        return (0 != $this->handle);
        }

    protected function executeSQL ($sqlStatement, $returnAffected = false)
        {
        $this->log ("mysql_query ('$sqlStatement')");
        $startTime = microtime (true);

        if (@mysql_query ($sqlStatement, $this->handle))
            {
            $this->logDuration ($startTime, microtime (true));

            if ($returnAffected)
                return mysql_affected_rows ();
            return true;
            }

        $this->logError ($sqlStatement);
        return false;
        }
    
    protected function logError ($sqlStatement = NULL)
        {
        if (0 == mysql_errno ())
            return true;

        $this->log (mysql_errno().": ".mysql_error());
        switch (mysql_errno())
            {
            case 1062:
                $this->context->addError ("Duplicate entry");
                break;

            default:
                $this->context->addError ("MySql error. Please contact site administrators if error persists. ([_0])", mysql_errno().": ".$sqlStatement);
                break;
            }

        return false;
        }

    protected function executeInsert ($sqlStatement, $canUpdate = false)
        {
        if (!$this->executeSQL ($sqlStatement))
            return false;

        $affectedRows = @mysql_affected_rows ($this->handle);
        if ($affectedRows <= 0)
            return -1;

        return $canUpdate ? $affectedRows : @mysql_insert_id ($this->handle);
        }
    
    protected function executeSelect ($sqlStatement)
        {
        $this->log ("mysql_query ('$sqlStatement')");
        $startTime = microtime (true);

        $hResult = @mysql_query ($sqlStatement, $this->handle);

        $this->logDuration ($startTime, microtime (true));
        $startTime = microtime (true);

        // if error occured, we still need to free resources, but set result to "false"
        $resultSet = $this->logError () ? null : false;

        if ($hResult && @mysql_num_rows ($hResult) > 0)
            {
            while ($row = @mysql_fetch_array ($hResult, MYSQL_ASSOC))
                {
                $resultSet[] = $row;
                }
            }

        @mysql_free_result ($hResult);
        if (DEBUG_VERBOSE)
            $this->logDuration ($startTime, microtime (true));
        return $resultSet;
        }

    public function dropTable ($tableName)
        {
        $tablename = $this->prepareTableName ($tableName);
        return $this->executeSQL ("DROP TABLE $tablename");
        }

    public function dropColumn ($tableName, $columnName)
        {
        $tableName = $this->prepareTableName ($tableName);
        $columnName = $this->prepareColumnName ($columnName);
        return $this->executeSQL ("ALTER TABLE $tableName DROP $columnName");
        }

    public function addColumn ($tableName, $coldef)
        {
        $tableName = $this->prepareTableName ($tableName);
        $columnName = $this->prepareColumnName ($coldef->name);
        $sql = "ALTER TABLE $tableName ADD $columnName {$this->getTypeString ($coldef)}";
        return $this->executeSQL ($sql);
        }

    public function startTransaction ()
        {
        if (@mysql_query ("begin"))
            {
            return $this->disableAutocomit ();
            }

        return false;
        }

    public function commitTransaction ()
        {
        if (@mysql_query ("commit"))
            {
            return $this->enableAutocomit ();
            }

        return false;
        }

    public function rollbackTransaction ()
        {
        if (@mysql_query ("rollback"))
            {
            return $this->enableAutocomit ();
            }

        return false;
        }

    protected function disableAutocomit ()
        {
        if (@mysql_query ("set autocommit = 0"))
            {
            return true;
            }
        return false;
        }

    protected function enableAutocomit ()
        {
        if (@mysql_query ("set autocommit = 1"))
            {
            return true;
            }
        return false;
        }

    public function prepareTableName ($tablename)
        {
        return "`".parent::prepareTableName ($tablename)."`";
        }

    public function prepareColumnName ($name)
        {
        return "`".parent::prepareColumnName ($name)."`";
        }

    public function tablesExists ($tableNames)
        {
        $preparedNames = array ();
        for ($i = 0; $i < count ($tableNames); $i++)
            {
            $preparedNames[] = "'".trim ($this->prepareTableName ($tableNames[$i]), "`")."'";
            }
 
        $sql = "show table status where Name in (".implode (",", $preparedNames).")";
        if (DEBUG_VERBOSE) $this->log ($sql);
        $res = @mysql_query($sql);

        $this->logError ();

        return (@mysql_num_rows($res) == count ($tableNames));
        }

    public function tableExists ($tablename)
        {
        $tablename = $this->prepareTableName ($tablename);
        $tablename = trim ($tablename, "`");

        if (DEBUG_VERBOSE) $this->log ("show table status like '$tablename'");

        $res = @mysql_query("show table status like '$tablename'");

        $this->logError ();

        return (@mysql_num_rows($res) == 1);
        }
    
    protected function getTableModifiers ()
        {
        $str = "";
        if (defined ("TABLE_ENGINE"))
            $str .= " ENGINE = ".TABLE_ENGINE;
        $str .= " DEFAULT CHARACTER SET utf8";
        if (defined ("DEFAULT_COLATE"))
            $str .= " COLLATE ".DEFAULT_COLATE;
        return $str;
        }

    public function addIndex ($tablename, $i, $index)
        {
        /* override to implement DB specific functionality*/
        $realTablename = $this->prepareTableName ($tablename);
        $indexType = NULL;
        $indexName = $index->name;
        if (empty ($indexName))
            $indexName = "{$tablename}_$i";

        if ($index instanceof PrimaryIndex) 
            $indexType = "PRIMARY KEY";
        else if ($index instanceof UniqueIndex) 
            $indexType = "UNIQUE $indexName";
        else if ($index instanceof Index)
            $indexType = "INDEX $indexName";
        else if ($index instanceof FullTextIndex)
            $indexType = "FULLTEXT INDEX $indexName";

        $columns = array ();
        foreach ($index->columns as $col)
            {
            if (is_object ($col))
                $columns[] = $this->prepareColumnName ($col->name)." (".$col->size.")";
            else
                $columns[] = $this->prepareColumnName ($col);
            }

        $columnList = implode (",", $columns);
        $sql = "ALTER TABLE $realTablename ADD $indexType ($columnList)"; 
        if (false === $this->executeSql ($sql))
            {
            $this->logError ();
            return false;
            }

        return true;
        }

    public function dropIndex ($tablename, $indexName)
        {
        /* override to implement DB specific functionality*/
        $realTablename = $this->prepareTableName ($tablename);
        $sql = "ALTER TABLE $realTablename DROP INDEX `$indexName`"; 
        if (false === $this->executeSql ($sql))
            {
            $this->logError ();
            return false;
            }

        return true;
        }

    protected function createSelectStatement ($query, $executionParams = NULL)
        {
        $sql = parent::createSelectStatement ($query, $executionParams);
        if (!empty ($executionParams))
            {
            foreach ($executionParams as $param)
                {
                if ($param instanceof LimitResults)
                    $sql .= " limit ".$param->lowerBound.", ".($param->upperBound-$param->lowerBound);
                }
            }

        return $sql;
        }

    public function lockTables ($tables)
        {
        return false;
        /* Not supported yet as tables should be locked
            by using same alias as in select statement */
        $preparedNames = array ();
        for ($i = 0; $i < count ($tableNames); $i++)
            {
            $preparedNames[] = "'".trim ($this->prepareTableName ($tableNames[$i]), "`")." write";
            }
 
        $sql = "lock table ".implode (",", $preparedNames);
        if (DEBUG_VERBOSE) $this->log ($sql);
        $res = @mysql_query($sql);

        $this->logError ();
        return $res;
        }

    public function unlockTables ($tables)
        {
        return false;
        /* Not supported yet - see lockTables method */
        $sql = "unlock tables";
        if (DEBUG_VERBOSE) $this->log ($sql);
        $res = @mysql_query($sql);

        $this->logError ();
        return $res;
        }
    }

?>

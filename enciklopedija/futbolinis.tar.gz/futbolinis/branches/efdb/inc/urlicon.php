<?php
require_once (PATH.'inc/action.php');

abstract class URLAction extends IconAction
    {
    protected $url;
    public $image = false;

    public function __construct ($component, $key, $tooltip, $url)
        {
        parent::__construct ($component, $key, $tooltip);
        $this->url = $url;
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function getUrl ($request, $row)
        {
        if (0 !== strpos ($this->url, "/") && false === strchr ($this->url, "://"))
            {
            // add base path if needed
            if (defined ("BASE_URL") && strlen (trim (BASE_URL, " /")) > 0)
                $basePath = trim (BASE_URL, " /")."/";
            else
                $basePath = PATH;

            return $basePath.$this->url;
            }

        return $this->url;
        }

    public function getTemplateName ()
        {
        return "urlaction";
        }

    public function getAdditionalAttributes ($row)
        {
        return array ();
        }

    public function execute ($request, $ids)
        {
        if (defined ("BASE_URL") && strlen (trim (BASE_URL, " /")) > 0)
            $basePath = trim (BASE_URL, " /")."/";
        else
            $basePath = PATH;
        $this->context->redirect ($basePath.$this->getUrl ($request, $ids));
        return false;
        }

    public function getClassName ()
        {
        return $this->disabled ? "urlactiondisabled" : "urlaction";
        }
    }

abstract class URLIcon extends URLAction
    {
    public function __construct ($component, $key, $tooltip, $url)
        {
        parent::__construct ($component, $key, $tooltip, $url);
        $this->image = true;
        }
    }

class SingleRowURLIcon extends URLIcon
    {
    public function __construct ($component, $key, $tooltip, $url)
        {
        parent::__construct ($component, $key, $tooltip, $url);
        }

    public function isVisible ($row = NULL)
        {
        return NULL != $row;
        }

    public function getUrl ($request, $row)
        {
        $id = $this->component->getId ($row);
        $url = parent::getUrl ($request, $row);
        return $this->context->processUrl ("$url&id=$id");
        }

    public function requiresId ()
        {
        return true;
        }
    }

// very similar to SimpleLinkAction - should be merged
class AdditionalURLIcon extends URLIcon
    {
    public function __construct ($component, $key, $tooltip, $url)
        {
        parent::__construct ($component, $key, $tooltip, $url);
        }

    public function isVisible ($row = NULL)
        {
        return true;
        }

    public function requiresId ()
        {
        return false;
        }
        
    }

abstract class ChangeOrderIcon extends IconAction
    {
    protected $up;

    public function __construct ($component, $key, $up)
        {
        $tooltip = $up ? $component->getText ("Move up") : $component->getText ("Move down");
        parent::__construct ($component, $key, $tooltip);
        $this->up = $up;
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function isVisible ($row = NULL)
        {
        if (empty ($row))
            return false;
        if ($this->up && isset ($row[DBTable::COL_ORDER]) && $row[DBTable::COL_ORDER] <= 1)
            return false;

        return true;
        }

    public function requiresId ()
        {
        return true;
        }
    }

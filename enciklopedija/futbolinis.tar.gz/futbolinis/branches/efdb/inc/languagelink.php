<?php

/* use $redirectHost if you want to have a separate subdomains for different
   languages. For example, in user.config.php set
   
$GLOBALS["Languages"] = array
    (
    new LanguageLink ("en", "English", "http://en.example.com"),
    new LanguageLink ("lt", "Lietuvių", "http://lt.example.com"),
    );
*/

class LanguageLink
    {
    public $code;
    public $label;
    public $redirectHost;
    public $countryCode;
    public function __construct ($code, $label, $redirectHost = NULL, $countryCode = NULL)
        {
        $this->code = $code;
        $this->label = $label;
        $this->redirectHost = $redirectHost;
        $this->countryCode = $countryCode;
        }
    }

?>
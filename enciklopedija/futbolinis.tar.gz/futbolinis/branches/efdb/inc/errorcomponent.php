<?php

class ErrorComponent extends TextComponent
    {
    public function __construct ($prefix, $context, $text)
        {
        parent::__construct ($prefix, $context, $text, "error");
        }
    }

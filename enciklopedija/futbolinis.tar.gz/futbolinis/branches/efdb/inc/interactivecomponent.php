<?php
require_once (PATH.'inc/component.php');

abstract class InteractiveComponent extends Component
    {
    public function getActionParam ($action, $row = NULL)
        {
        $prefix = $this->getPrefix ();
        if (!empty ($prefix))
            $prefix .= "_";
        $str = "{$prefix}action_$action";
        if (NULL != $row)
            $str .= "_".$this->getId ($row);
        return $str;
        }

    protected function getAvailableActions ()
        {
        return array_merge ($this->getActionList (), $this->getAdditionalActions ());
        }

    public abstract function getActionList ();

    public function hasAdditionalActions ()
        {
        return count ($this->getAdditionalActions ()) > 0;
        }

    public function getAdditionalActions ()
        {
        return array ();
        }

    public function getConfirmField ()
        {
        $prefix = $this->getPrefix ();
        if (!empty ($prefix))
            $prefix .= "_";
        return "{$prefix}confirmed";
        }

    protected function getExecutedAction ($context, $request)
        {
        $actionPrefix = "action_";
        foreach ($request as $key => $val)
            {
            // search for <input type=image> generated names - "action_delete_5_x"
            if (strpos ($key, $actionPrefix) === 0)
                {
                if ($key[strlen ($key) - 2] == "_" && ($key[strlen ($key) - 1] == "x" || $key[strlen ($key) - 1] == "y"))
                    $actionStr = substr ($key, strlen ($actionPrefix), -2);
                else
                    $actionStr = substr ($key, strlen ($actionPrefix));
                break;
                }
            }

        if (!isset ($actionStr)) // no actions performed in this component
            return NULL;

        return $actionStr;
        }

    public function processInput ($context, &$request)
        {
        $actionStr = $this->getExecutedAction ($context, $request);
        if (empty ($actionStr)) // no actions performed in this component
            return true;

        $actionList = $this->getAvailableActions ();
        $ret = $this->parseActionString ($request, $actionStr);
        if (false === $ret)
            return true;

        list ($action, $ids) = $ret;
        if (false === $ids)
            return true;

        for ($a = 0; $a < count ($actionList); $a++)
            {
            if ($actionList[$a]->getKey() == $action)
                {
                $targetAction = $actionList[$a];
                break;
                }
            }

        if (!isset ($targetAction))
            {
            $this->addError ("Unrecognized action.");
            return true;
            }

        if ((NULL == $ids || count ($ids) == 0) && $targetAction->requiresId ())
            {
            $this->addError ("No items selected for an action.");
            return true;
            }

        if (count ($ids) == 1 && !$targetAction->canExecute ($request, $ids[0]))
            return true;

        $ret = $targetAction->execute ($request, $ids);
        return $ret;
        }

    protected function parseActionString ($request, $actionStr)
        {
        $parts = explode ("_", $actionStr, 2);
        return array ($parts[0], array (explode ("_", $parts[1])));
        }

    public function getIndexColumns ()
        {
        $idColumns = $this->getIdColumns ();
        if (!is_array ($idColumns))
            $idColumns = array ($idColumns);
        return $idColumns;
        }

    protected function getIdColumns ()
        {
        if (empty ($this->dbtable))
            return false;

        $cols = $this->dbtable->getPrimaryIndexColumns ();
        $names = array ();
        for ($c = 0; $c < count ($cols); $c++)
            {
            $names[] = $cols[$c]->name;
            }
        return $names;
        }
    }


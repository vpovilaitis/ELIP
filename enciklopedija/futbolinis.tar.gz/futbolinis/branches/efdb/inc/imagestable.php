<?php

/* A database table which stores uploaded image paths */
class ImagesTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "images";

    const COL_ID = "imageid";
    const COL_FILENAME = "filename";
    const COL_LABEL = "label";
    const COL_DESCRIPTION = "description";
    const COL_KEYWORDS = "keywords";
    const COL_LICENSE_ID = "licenseid";
    const COL_AUTHOR = "author";
    const COL_WIDTH = "width";
    const COL_HEIGHT = "height";

    const COL_FILEPATH = "filepath";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, true);
        $this->tracksRevisions = true;
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     new TextColumn (self::COL_FILENAME, 256, false),
                     new IntColumn (self::COL_LICENSE_ID, false),
                     new TextColumn (self::COL_AUTHOR, 256, true),
                     new IntColumn (self::COL_WIDTH, false),
                     new IntColumn (self::COL_HEIGHT, false),
                     );
        }

    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (DBTable::COL_SOURCE, 512, false),
                     new TextColumn (self::COL_LABEL, 128, false),
                     new TextColumn (self::COL_KEYWORDS, 1024, true),
                     new LongTextColumn (self::COL_DESCRIPTION, true),
                     );
        }

    protected function getIndexes ()
        {
        $labelIndex = new FullTextIndex (self::COL_LABEL, self::COL_KEYWORDS);
        $labelIndex->translatableTable = true;
        return array ($labelIndex, new UniqueIndex (self::COL_FILENAME));
        }

    protected function forceCreateTable ()
        {
        $ret = parent::forceCreateTable ();
        if ($ret)
            {
            $licenseTable = new ImageLicenseTable ($this->context);
            $imageUseTable = new ImageUseTable ($this->context);
            if ((!$licenseTable->tableExists () && false === $licenseTable->createTable ()) ||
                (!$imageUseTable->tableExists () && false === $imageUseTable->createTable ()))
                {
                $ret = false;
                }
            }

        return $ret;
        }

    public function insertRecord ($nameToValue)
        {
        if (empty ($nameToValue[self::COL_FILEPATH]) || !defined ("USER_UPLOAD_DIR") || !is_file ($nameToValue[self::COL_FILEPATH]))
            {
            $this->context->addError ("Image path was not provided.");
            return false;
            }

        $filePath = $nameToValue[self::COL_FILEPATH];
        if (empty ($nameToValue[self::COL_FILENAME]))
            $nameToValue[self::COL_FILENAME] = time().".".pathinfo ($filePath, PATHINFO_BASENAME);
        else
            $nameToValue[self::COL_FILENAME] = time().".".$nameToValue[self::COL_FILENAME];

        unset ($nameToValue[self::COL_FILEPATH]);
        
        if (empty ($nameToValue[self::COL_WIDTH]) || empty ($nameToValue[self::COL_HEIGHT]))
            {
            $size = @getimagesize ($filePath);
            if (!$size)
                {
                $this->context->addError ("Incorrect image was uploaded.");
                return false;
                }

            if (defined ("MAX_IMAGE_SIZE") && $size[0] * $size[1] > MAX_IMAGE_SIZE)
                {
                $this->context->addError ("Image uploaded is too big.");
                return false;
                }

            list ($width, $height, $type) = $size;
            $nameToValue[self::COL_WIDTH] = $width;
            $nameToValue[self::COL_HEIGHT] = $height;
            }

        $id = parent::insertRecord ($nameToValue);
        if (false === $id)
            return $id;

        // record is created, so just copy the file to the expected location
        if (is_uploaded_file ($filePath))
            $ret = move_uploaded_file ($filePath, realpath (USER_UPLOAD_DIR)."/".$nameToValue[self::COL_FILENAME]);
        else
            $ret = copy ($filePath, realpath (USER_UPLOAD_DIR)."/".$nameToValue[self::COL_FILENAME]);

        if (!$ret)
            {
            $this->context->addError ("Failed to copy the image.");
            $this->deleteById ($id);
            return false;
            }

        return $id;
        }

    public function deleteBy ($criteria, $deleteTranslatable = false)
        {
        $records = $this->selectBy (array (self::COL_FILENAME), $criteria);
        if (empty ($records))
            return false;

        $ret = parent::deleteBy ($criteria, $deleteTranslatable);
        if (false === $ret)
            return $ret;

        $deletedFileDir = realpath (USER_UPLOAD_DIR)."/deleted";
        if (!is_dir ($deletedFileDir))
            {
            if (!mkdir ($deletedFileDir))
                {
                $this->context->addError ("Failed to move the deleted image to recycle bin.");
                return false;
                }
            }

        foreach ($records as $record)
            {
            $currentPath = USER_UPLOAD_DIR."/".$record[self::COL_FILENAME];
            if (!rename ($currentPath, $deletedFileDir."/".$record[self::COL_FILENAME]))
                $this->context->addError ("Failed to move the deleted image to recycle bin.");
            }

        return $ret;
        }

    public function findImages ($keyword, $columns = NULL, $limit = -1)
        {
        $columns[] = new FullTextMatchFunction (array (self::COL_LABEL, self::COL_KEYWORDS), $keyword, "fts");
        $criteria[] = new FTSCriterion (array (self::COL_LABEL, self::COL_KEYWORDS), $keyword);
        $params = array ();
        if ($limit > 0)
            $params[] = new LimitResults (0, $limit);
        $params[] = OrderBy::createByAlias ("fts", false);
        return $this->selectBy ($columns, $criteria, NULL, $params);
        }

    protected static function explodeFileName ($fileName, &$extension)
        {
        // lets create a unique file name (to be used for saved file)
        $parts = explode (".", $fileName);
        if (count ($parts) > 2)
            $timestamp = array_shift ($parts);
        if (count ($parts) > 1)
            $extension = array_pop ($parts);
        if (!empty ($timestamp))
            $parts[] = $timestamp;
        return $parts;
        }

    public static function clearImageCache ($fileName)
        {
        // lets create a unique file name (to be used for saved file)
        $extension = NULL;
        $parts = self::explodeFileName ($fileName, $extension);
        $targetFileNames = implode (".", $parts)."*";
        $cacheFileDir = realpath (IMAGE_CACHE_DIR);
        $finalPath = rtrim ($cacheFileDir, "/")."/".$targetFileNames;
        array_map ("unlink", glob($finalPath));
        }

    public function resizeImage ($fileName, $maxWidth, $maxHeight, $purge = false)
        {
        // lets create a unique file name (to be used for saved file)
        $extension = NULL;
        $parts = $this->explodeFileName ($fileName, $extension);

        $parts[] = $maxWidth;
        $parts[] = $maxHeight;
        if (!empty ($extension))
            $parts[] = $extension;

        $targetFileName = implode (".", $parts);

        // check if the cache directory is prepared
        $cacheFileDir = realpath (IMAGE_CACHE_DIR);
        $finalPath = rtrim ($cacheFileDir, "/")."/".$targetFileName;
        $sourcePath = USER_UPLOAD_DIR."/".$fileName;
        $image = new Image ();
        if (!$image->readFile ($this->context, $sourcePath))
            {
            $this->context->addError ("Incorrect image was uploaded.");
            return false;
            }
        
        $savePng = false;
        $newExtension = "";
        // save everything as png or jpeg
        switch ($image->getMimeType ($this->context))
            {
            case 'image/gif':
                $newExtension = ".png";
            case 'image/png':
                $savePng = true;
                break;
            case 'image/jpeg':
                break;
            default:
                $newExtension = ".jpg";
                $savePng = false;
                break;
            }

        $finalPath .= $newExtension;

        if (!is_dir ($cacheFileDir))
            {
            if (!mkdir ($cacheFileDir))
                {
                $this->context->addError ("Failed to cache the resized image (no permissions to create cache directory?).");
                return false;
                }
            }
        else
            {
            // check if the file already exists in the cache
            $cachedFilePath = $finalPath;
            if (!$purge && is_file ($cachedFilePath))
                return $finalPath;
            }

        if (!$image->resizeImage ($this->context, $maxWidth, $maxHeight, $savePng))
            return false;

        if (!$image->writeFile ($this->context, $finalPath))
            return false;

        return $finalPath;
        }

    }

/* A database table which stores various image licenses */
class ImageLicenseTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "imagelicense";

    const COL_ID = "licenseid";
    const COL_NAME = "name";
    const COL_DESCRIPTION = "description";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, true);
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     new TextColumn (self::COL_NAME, 64, false),
                     );
        }

    protected function getTranslatableColumns ()
        {
        return array (
                     new LongTextColumn (self::COL_DESCRIPTION, true),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new UniqueIndex (self::COL_NAME),
            );
        }

    protected function forceCreateTable ()
        {
        $ret = parent::forceCreateTable ();
        if ($ret)
            {
            $defaultSet = array
                            (
                            "cc-by-3.0" => $this->getText ("Creative Commons Attribution (Licensees may copy, distribute, display and perform the work and make derivative works based on it only if they give the author or licensor the credits in the manner specified by these)."),
                            "cc-by-sa-3.0" => $this->getText ("Creative Commons Attribution + ShareAlike (Licensees may copy, distribute, display and perform the work and make derivative works based on it only under a license identical to the license that governs the original work and only if they give the author or licensor the credits in the manner specified by these)."),
                            "GFDL" => $this->getText ("GNU Free Documentation License (rights to copy, redistribute, and modify a work, requires all copies and derivatives to be available under the same license)."),
                            "GFDL-self" => $this->getText ("Released per the GNU Free Documentation License by their creators"),
                            "PD-self" => $this->getText ("Released into the public domain by the creator who is also the uploader"),
                            "PD-author" => $this->getText ("Released into the public domain by the creator (please specify in the author field)"),
                            "PD-old" => $this->getText ("Public domain as copyright has expired. This applies to the European Union, the United States and those countries with a copyright term of life of the author plus 70 years."),
                            "anonymous-EU" => $this->getText ("anonymous work more than 70 years old (European Union)."),
                            ImageUseTable::ZONE_LOGO => $this->getText ("A logo (graphic mark or emblem commonly used by commercial enterprises, organizations) - under fairuse terms."),
                            ImageUseTable::ZONE_REPORT => $this->getText ("Official match report."),
                            );
            foreach ($defaultSet as $license => $description)
                {
                if (!$this->insertRecord (array (self::COL_NAME => $license, self::COL_DESCRIPTION => $description)))
                    return false;
                }
            }

        return $ret;
        }

    public function insertRecord ($nameToValue)
        {
        $ret = parent::insertRecord ($nameToValue);
        $this->clearCache ();
        return $ret;
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = 1)
        {
        $ret = parent::updateRecord ($criteria, $nameToValue, $maxRows);
        $this->clearCache ();
        return $ret;
        }

    protected function clearCache ()
        {
        $cache = Cache::getInstance (self::TABLE_NAME, 24*60*60);
        $cache->clean ();
        }
        
    public function deleteById ($criteria)
        {
        $ret = parent::deleteById ($criteria);
        $this->clearCache ();
        return $ret;
        }

    public function selectLicenses ()
        {
        $cache = Cache::getInstance (self::TABLE_NAME, 24*60*60);
        $key = "licenses";
        if (false === ($licenses = $cache->get ($key)))
            {
            $licenses = $this->selectBy (NULL, NULL);
            if (false !== $licenses)
                {
                $cache->save ($licenses, $key);
                }
            }
        return $licenses;
        }

    public static function getLicenseId ($context, $name)
        {
        $instance = new ImageLicenseTable ($context);
        $allLicenses = $instance->selectLicenses();
        foreach ($allLicenses as $row)
            {
            if ($row[self::COL_NAME] == $name)
                return $row[self::COL_ID];
            }
        
        return false;
        }

    }

<?php

class LeftOuterJoin extends Query
    {
    public function __construct ($table, $columns, $criteria, $joinedQueries = NULL)
        {
        parent::__construct ($table, $columns, $criteria, $joinedQueries);
        $this->joinType = Constants::JOIN_LEFT_OUTER;
        }
    }

class LimitResults
    {
    public $lowerBound;
    public $upperBound;
    public function __construct ($lowerBound, $upperBound)
        {
        $this->lowerBound = $lowerBound;
        $this->upperBound = $upperBound;
        }
    }

class LimitByPage extends LimitResults
    {
    public function __construct ($page, $pageSize)
        {
        parent::__construct ($page * $pageSize, ($page + 1) * $pageSize);
        }
    }

class GroupBy
    {
    public $columns;
    
    public function __construct ($columns)
        {
        $this->columns = $columns;
        }
    }

class GroupByAll
    {
    public function __construct ()
        {
        }
    }

class Distinct
    {
    public function __construct ()
        {
        }
    }

class HavingCriteria
    {
    public $criteria;
    
    public function __construct ($criteria)
        {
        $this->criteria = $criteria;
        }

    public function toString ($query = NULL)
        {
        return $this->criteria;
        }
    }

class OrderByColumn extends NamedItem
    {
    public $ascending;
    public $priority; // 1 - highest, ..., 1000 - low
    public $isAlias = false;

    public function __construct ($name, $ascending = true, $priority = NULL, $alias = false)
        {
        $this->name = $name;
        $this->ascending = $ascending;
        $this->priority = $priority;
        $this->isAlias = $alias;
        }
    }

class OrderBy
    {
    public $columns;
    
    public function __construct ($columns)
        {
        $this->columns = array ();
        foreach ($columns as $column)
            {
            if ($column instanceof OrderByColumn)
                $this->columns[] = $column;
            else
                $this->columns[] = new OrderByColumn ($column);
            }
        }

    protected static function createInternal ($alias, $args)
        {
        $columns = array ();
        $priority = 1;
        $asc = true;
        $lastName = NULL;
        foreach ($args as $column)
            {
            if (is_bool ($column))
                $asc = $column;
            else if (is_numeric ($column))
                $priority = $column;
            else
                {
                if (!empty ($lastName))
                    $columns[] = new OrderByColumn ($lastName, $asc, $priority, $alias);
                $asc = true;
                $lastName = $column;
                $priority++;
                }
            }

        if (!empty ($lastName))
            $columns[] = new OrderByColumn ($lastName, $asc, $priority, $alias);

        return new OrderBy ($columns);
        }

    // usage:
    //  OrderBy::create ("thirdcolumn", true, "fourthcolumn", false, "tenthcolumn")
    public static function create ()
        {
        $args = func_get_args ();
        return self::createInternal (false, $args);
        }

    // usage:
    //  OrderBy::createByAlias ("thirdcolumn", true, "fourthcolumn", false, "tenthcolumn")
    public static function createByAlias ()
        {
        $args = func_get_args ();
        return self::createInternal (true, $args);
        }
    }

class IncludeAllTranslations
    {
    }

class ExcludeDefaultTranslations
    {
    }

class SelectRevisions
    {
    }

?>

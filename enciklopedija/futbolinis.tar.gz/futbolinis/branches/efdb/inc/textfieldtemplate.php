<?php

class TextFieldTemplate extends FieldTemplate
    {
    public $size;

    public function __construct ($prefix, $key, $label, $tooltip, $size)
        {
        parent::__construct ($prefix, $key, "text", $label, $tooltip);
        $this->size = $size;
        }
    }

class LongTextFieldTemplate extends FieldTemplate
    {
    static protected $isRichText = NULL;

    public function __construct ($prefix, $key, $label, $tooltip)
        {
        parent::__construct ($prefix, $key, "multiline", $label, $tooltip);
        }

    public static function isRichTextEditorRegistered ()
        {
        if (NULL === self::$isRichText)
            {
            self::$isRichText = is_file (PATH."spaw2/spaw.inc.php");
            if (self::$isRichText)
                {
                require_once (PATH."spaw2/spaw.inc.php");
                $pageContext = PageContext::getInstance ();
                SpawConfig::setStaticConfigItem ('default_lang', $pageContext->getLanguage ());
                SpawConfig::setStaticConfigItem ('default_output_charset', PAGE_CHARSET);
                }
            }
        return self::$isRichText;
        }

    public function getTemplateName ()
        {
        if ($this->readonly)
            return parent::getTemplateName ();
        return self::isRichTextEditorRegistered () ? "spaweditor" : "richtext";
        }

    public function getInitializeScript ($fieldId)
        {
        return "toolbar_attach (\"{$fieldId}\");";
        }

    public function getToolbarActions ($context)
        {
        $linkPopupSvc = $context->processUrl ("index.php?service=LinkPopup", true);
        return array ("bold"   => array ("prefix" => "<b>", "postfix" =>"</b>", "title" => $context->getText ("Bold selection")),
                      "italic" => array ("prefix" => "<i>", "postfix" =>"</i>", "title" => $context->getText ("Italic selection")),
                      "link"   => array ("svc" => $linkPopupSvc, "title" => $context->getText ("Internal link")),
                      );
        }

    public function getEditor ($content)
        {
        $key = $this->getParamName();
        $spaw = new SpawEditor ($key, $content);
        return $spaw;
        }

    }

class CommentsFieldTemplate extends TextFieldTemplate
    {
    public function getValueForDisplay ($context, $row)
        {
        // do not show value stored in the database, as new comment should be enterred each time
        return $this->getValueForDB ($context, $context->request);
        }
    }

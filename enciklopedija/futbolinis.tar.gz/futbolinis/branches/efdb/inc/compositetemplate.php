<?php

class CompositeTemplate extends FieldTemplate
    {
    public $items;

    public function __construct ($prefix, $key, $type, $label, $subitems)
        {
        $this->items = $subitems;
        parent::__construct ($prefix, $key, $type, $label, NULL);
        }

    public function setPrefix ($prefix)
        {
        parent::setPrefix ($prefix);

        for ($i = 0; $i < count ($this->items); $i++)
            {
            $this->items[$i]->setPrefix ($this->getParamName ());
            }
        }

    public function getTemplateName ()
        {
        return "compositefield";
        }

    public function preprocessLoadedValue (&$request, $existingRecord, $index = NULL)
        {
        for ($i = 0; $i < count ($this->items); $i++)
            {
            $this->items[$i]->preprocessLoadedValue ($request, $existingRecord, $index);
            }
        }

    public function getValueForDB ($context, $request, $index = NULL)
        {
        $vals = array ();
        for ($i = 0; $i < count ($this->items); $i++)
            {
            $vals[$this->items[$i]->key] = $this->items[$i]->getValueForDB ($context, $request, $index);
            }
        return $vals;
        }
    }

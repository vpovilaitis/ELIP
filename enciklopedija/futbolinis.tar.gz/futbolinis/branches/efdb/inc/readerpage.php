<?php

abstract class ReaderPage extends Page
    {
    protected $scope;
    protected $tableName;

    public function __construct ($context, $title, $scope, $table = Constants::ANY)
        {
        parent::__construct ($context, $title);
        $this->scope = $scope;
        $this->tableName = $table;
        }

    public function canRead ()
        {
        return $this->context->canRead ($this->scope, $this->tableName);
        }

    public function canCreate ()
        {
        return $this->context->canCreate ($this->scope, $this->tableName);
        }

    public function canEdit ()
        {
        return $this->context->canEdit ($this->scope, $this->tableName);
        }

    public function canDelete ()
        {
        return $this->context->canDelete ($this->scope, $this->tableName);
        }

    protected function checkAccess ($request)
        {
        return $this->context->canRead ($this->scope, $this->tableName);
        }

    public function processInput ($context, &$request)
        {
        return true;
        }
    }

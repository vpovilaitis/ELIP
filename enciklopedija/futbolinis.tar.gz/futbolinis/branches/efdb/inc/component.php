<?php
require_once (PATH.'inc/base.php');
require_once (PATH.'inc/general.php');

abstract class Component extends BaseWithContext
    {
    public $prefix;

    protected $dbtable;
    protected $textdomain;
    protected $parent = NULL;
    protected $components = array();

    protected $messages = array();
    protected $errors = array();
    protected $messagesDisplayedInline = false;
    
    protected $hiddenFields = array ();
    protected $request; // inner request

    protected $isInitialized = false;

    const PARAM_ACTION = "action";

    public function __construct ($prefix, $context, $textdomain = NULL)
        {
        parent::__construct ($context);
        $this->prefix = $prefix;

        $context->addScriptFile ("common");
        $context->addScriptFile ("hint");
        $context->addScriptFile ("editor");

        if ($context->getConnection ())
            {
            $imageUseTable = new ImageUseTable ($this->context);
            if ($imageUseTable->canCreate ())
                $this->context->addScriptFile ("autosuggest");
            }
        }

    public function getPrefix ()
        {
        $str = $this->prefix;
        $parentPrefix = NULL;
        if (NULL != $this->parent && !($this->parent instanceof Page))
            $parentPrefix = $this->parent->getPrefix();

        if (!empty ($parentPrefix))
            $str = $parentPrefix."_".$str;

        return $str;
        }

    public function containsErrors()
        {
        return count ($this->errors) > 0;
        }

    public function containsMessages ($fromParent = false)
        {
        if (($fromParent && $this->messagesDisplayedInline) ||
            (!$fromParent && NULL != $this->parent && !$this->messagesDisplayedInline))
            {
            return false;
            }

        if (count ($this->messages) > 0 || count ($this->errors) > 0)
            return true;

        foreach ($this->components as $key => $component)
            {
            if ($component->containsMessages (true))
                return true;
            }

        return false;
        }

    public function getMessages($level = 0)
        {
        if (0 == $level && NULL != $this->parent && !$this->messagesDisplayedInline)
            return array();
        if ($level > 0 && $this->messagesDisplayedInline)
            return array ();

        $messages = $this->messages;
        foreach ($this->components as $key => $component)
            {
            $messages = array_merge ($messages, $component->getMessages ($level+1));
            }

        return $messages;
        }

    public function addMessage ($message, $param1 = NULL, $param2 = NULL)
        {
        $this->messages[] = $this->formatText ($message, $param1, $param2);
        }

    public function addMessagePrepared ($message)
        {
        $this->messages[] = $message;
        }

    public function getErrors ($level = 0)
        {
        if (0 == $level && NULL != $this->parent && !$this->messagesDisplayedInline)
            return array();
        if ($level > 0 && $this->messagesDisplayedInline)
            return array ();

        $messages = $this->errors;
        foreach ($this->components as $key => $component)
            {
            $messages = array_merge ($messages, $component->getErrors ($level+1));
            }

        return $messages;
        }

    public function addError ($error, $param1 = NULL, $param2 = NULL)
        {
        $msg = $this->formatText ($error, $param1, $param2);
        $this->errors[] = $msg;

        if (DEBUG)
            $this->log ($msg);
        }

    public function addErrorPrepared ($error)
        {
        $this->errors[] = $error;

        if (DEBUG)
            $this->log ($error);
        }

    public function getParent ()
        {
        return $this->parent;
        }

    public function getTargetRequest ($request)
        {
        if (empty ($this->prefix))
            $innerRequest = $request;
        else
            $innerRequest = self::getInnerRequest ($request, $this->prefix."_");

        return $innerRequest;
        }

    public static function getInnerRequest ($request, $prefix)
        {
        $innerRequest = array();
        if (empty ($request))
            return $innerRequest;

        foreach ($request as $key => $val)
            {
            // only pass the parameters of this component (prefixed)
            if (strpos ($key, $prefix) === 0)
                {
                $innerRequest[substr ($key, strlen ($prefix))] = $val;
                }
            }

        return $innerRequest;
        }

    public function initialize ($request, $parent)
        {
        if ($this->isInitialized)
            return true;

        $this->isInitialized = true;
        $this->parent = $parent;

        $this->request = $this->getTargetRequest ($request);
        if (false === $this->ensureChildren ($this->context, $this->request))
            return false;

        if (false === $this->processInput ($this->context, $this->request))
            return false;

        return true;
        }

    public function getRequest ()
        {
        return $this->request;
        }

    public abstract function processInput ($context, &$request);

    protected abstract function getTemplateName ();

    public function addComponent ($request, $name, $component)
        {
        if (empty ($component))
            return;
        $this->components[$name] = $component;
        if (!$this->components[$name]->initialize ($request, $this))
            exit ();
        }

    public function getComponents ()
        {
        return $this->components;
        }

    public function ensureChildren ($context, $request)
        {
        return true;
        }

    public function isVisible ()
        {
        return true;
        }

    public function getParam ($param = self::PARAM_ACTION)
        {
        $prefix = $this->getPrefix ();
        if (empty ($prefix))
            return $param;
        return $prefix."_".$param;
        }

    public function getHiddenFields ()
        {
        $processed = array ();
        foreach ($this->hiddenFields as $field => $val)
            {
            $key = $this->getParam ($field);
            $processed[$key] = $val;
            }
        return $processed;
        }

    protected function getHintTargetGroup ()
        {
        return HintsTable::TARGET_VIEWER;
        }

    protected function getHintScope ()
        {
        return NULL;
        }

    protected function getHintContextMode ()
        {
        return NULL;
        }

    protected function getHintContextId ()
        {
        return NULL;
        }

    public function getHintContext ()
        {
        if (defined ("NOHINTS") && NOHINTS)
            return NULL;

        $scope = $this->getHintScope ();
        if (empty ($scope))
            {
            if (!empty ($this->components))
                {
                foreach ($this->components as $child)
                    {
                    $hint = $child->getHintContext ();
                    if (!empty ($hint))
                        return $hint;
                    }
                }
            return NULL;
            }

        $contextmode = $this->getHintContextMode ();
        $group = $this->getHintTargetGroup ();
        $id = $this->getHintContextId ();

        $params = "";
        if (!empty ($scope))
            $params .= "&sc=$scope";
        if (!empty ($contextmode))
            $params .= "&cmode=$contextmode";
        if (!empty ($group))
            $params .= "&grp=$group";
        if (!empty ($id))
            $params .= "&id=$id";

        $url = $this->context->processUrl ("index.php?service=HintService$params", true);
        $listUrl = $this->context->processUrl ("index.php?c=HintList$params", true);
        return new HintContext ($this->context, $url, $listUrl);
        }

    public function alterImageContext ($imagesTable, $imageUseTable, $scope, $contextId, $zone, $imageId, &$descr, $showUpload = true)
        {
        if ($imagesTable->canCreate () || $imageUseTable->canCreate ())
            $descr["id"] = "img_".$zone."_".$contextId;

        if ($showUpload && $imagesTable->canCreate () && $imageUseTable->canCreate ())
            {
            $descr["uploadPopup"] = $this->context->processUrl ("index.php?service=ImageUploadPopup&action=new&sc=$scope&cid=$contextId&zone=$zone", true);
            $descr["uploadText"] = $this->getText ("Upload image...");
            }

        if ($showUpload && $imageUseTable->canCreate ())
            {
            $descr["attachPopup"] = $this->context->processUrl ("index.php?service=ImageUploadPopup&action=connect&sc=$scope&cid=$contextId&zone=$zone", true);
            $descr["attachText"] = $this->getText ("Connect existing...");
            }

        if ($imageUseTable->canDelete ())
            {
            $descr["deleteUrl"] = $this->context->processUrl ("index.php?service=ImageUploadPopup&mode=remove&sc=$scope&cid=$contextId&zone=$zone&id=$imageId", true);
            $descr["deleteText"] = $this->getText ("Delete|image");
            $descr["deleteConfirm"] = $this->getText ("Are you sure you wish to remove this image from a page?");
            }

        if ($imageId > 0 && $imageUseTable->canEdit ())
            {
            $descr["editPopup"] = $this->context->processUrl ("index.php?service=ImageUploadPopup&action=edit&sc=$scope&cid=$contextId&id=$imageId&zone=$zone", true);
            $descr["editText"] = $this->getText ("Edit...");

            if (ImageUseTable::ZONE_REPORT == $zone && class_exists ("Imagick", false))
                {
                $descr["rotateUrl"] = $this->context->processUrl ("index.php?service=ImageUploadPopup&mode=rotate&id=$imageId", true);
                $descr["rotateText"] = $this->getText ("Rotate");
                }
            }
        }

    protected function selectAttachedImages ($imagesTable, $imageUseTable, $scope, $id, $zone)
        {
        $columns = array (ImagesTable::COL_WIDTH, ImagesTable::COL_HEIGHT, DBTable::COL_UPDATEDON);
        $criteria[] = new JoinColumnsCriterion (ImageUseTable::COL_IMAGEID, ImagesTable::COL_ID);
        $imagesJoin = $imagesTable->createQuery ($columns, $criteria);

        $columns = array (ImageUseTable::COL_IMAGEID, ImageUseTable::COL_TITLE);
        $criteria = array ();
        $criteria[] = new EqCriterion (ImageUseTable::COL_SCOPE, $scope);
        $criteria[] = new EqCriterion (ImageUseTable::COL_CONTEXTID, $id);
        $criteria[] = new EqCriterion (ImageUseTable::COL_ZONE, $zone);
        return $imageUseTable->selectBy ($columns, $criteria, array ($imagesJoin));
        }

    public function getAllImages ($scope, $id, $zone, $width, $height)
        {
        $imagesTable = new ImagesTable ($this->context);
        $imageUseTable = new ImageUseTable ($this->context);
        $rows = $this->selectAttachedImages ($imagesTable, $imageUseTable, $scope, $id, $zone);
        if (empty ($rows))
            return NULL;

        $result = array ();
        foreach ($rows as $row)
            {
            $imageId = $row[ImageUseTable::COL_IMAGEID];
            $title = $row[ImageUseTable::COL_TITLE];
            if (empty ($width) != empty ($height))
                {
                // only one of the dimensions is given, try to calculate another
                if (empty ($width))
                    $width = round ($row[ImagesTable::COL_WIDTH] * $height / $row[ImagesTable::COL_HEIGHT]);
                else
                    $height = round ($row[ImagesTable::COL_HEIGHT] * $width / $row[ImagesTable::COL_WIDTH]);
                }

            $timestamp = strtotime ($row[DBTable::COL_UPDATEDON]);
            $url = $this->context->chooseUrl ("image/$imageId/{$width}x{$height}t{$timestamp}",
                                              "index.php?c=UserImage&id=$imageId&w=$width&h=$height&t=$timestamp");
            $galeryUrl = NULL;

            $descr = array ("url" => $url, "title" => $title, "galeryUrl" => $galeryUrl);
            $result[] = $descr;
            }

        return $result;
        }

    public function getImageContext ($scope, $id, $zone, $width, $height, $canRotateBox = false)
        {
        $imageId = 0;
        $title = NULL;
        $timestamp = 0;
        $imagesTable = new ImagesTable ($this->context);
        $imageUseTable = new ImageUseTable ($this->context);
        $rows = $this->selectAttachedImages ($imagesTable, $imageUseTable, $scope, $id, $zone);

        if (!empty ($rows))
            {
            $row = $rows[rand (0, count($rows)-1)];
            $imageId = $row[ImageUseTable::COL_IMAGEID];
            $title = $row[ImageUseTable::COL_TITLE];
            $timestamp = strtotime ($row[DBTable::COL_UPDATEDON]);
            if ($canRotateBox && $width != $height && ($row[ImagesTable::COL_WIDTH] > $row[ImagesTable::COL_HEIGHT]) != $width > $height)
                {
                // rotate the expected dimensions as image proportions are totally different
                list ($width, $height) = array ($height, $width);
                }
            if (empty ($width) != empty ($height))
                {
                // only one of the dimensions is given, try to calculate another
                if (empty ($width))
                    $width = round ($row[ImagesTable::COL_WIDTH] * $height / $row[ImagesTable::COL_HEIGHT]);
                else
                    $height = round ($row[ImagesTable::COL_HEIGHT] * $width / $row[ImagesTable::COL_WIDTH]);
                }
            }
        else if (!$imagesTable->canCreate () || !$imageUseTable->canCreate ())
            return NULL;

        $url = $this->context->chooseUrl ("image/$imageId/{$width}x{$height}t{$timestamp}",
                                          "index.php?c=UserImage&id=$imageId&w=$width&h=$height&t=$timestamp");
        if ($imageId > 0)
            $galeryUrl = $this->context->chooseUrl ("galery/$scope/$id/$imageId",
                                                    "index.php?c=ImageGalery&sc=$scope&id=$id&highlight=$imageId");
        else
            $galeryUrl = NULL;

        $descr = array ("url" => $url, "width" => $width, "height" => $height, "title" => $title, "galeryUrl" => $galeryUrl);

        $this->alterImageContext ($imagesTable, $imageUseTable, $scope, $id, $zone, $imageId, $descr);

        if (count ($rows) > 1)
            $descr["moreText"] = $this->getText ("More images...");

        return $descr;
        }

    public function getHintInitializeScript ($hint)
        {
        return "hint_attach (\"{$hint->elementId}\", \"{$hint->serviceUrl}\", \"{$hint->loadingText}\", \"{$hint->listUrl}\", \"{$hint->listUrlLabel}\", ".($hint->alwaysVisible ? "true" : "false").");";
        }
    }

class StartupScript extends Component
    {
    protected $script;
    
    public function __construct ($context, $script)
        {
        parent::__construct ("startup", $context);
        $this->script = $script;
        }

    public function getTemplateName ()
        {
        return "startupscript";
        }

    public function getScript ()
        {
        return $this->script;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }
    }

abstract class AsyncComponent extends Component
    {
    public function __construct ($context, $prefix)
        {
        parent::__construct ($prefix, $context);
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getTemplateName ()
        {
        return "pages/asynccomponent";
        }

    public function getElementId ()
        {
        return $this->prefix;
        }

    public function getStartupScript ()
        {
        return $this->generateStartupScript ("panel_fillPanelAsynchronously", $this->getElementId(), $this->getUrl());
        }

    public function generateStartupScript ($function, $elementId, $url)
        {
        return "$function (\$('#$elementId'), '$url');";
        }

    protected abstract function getUrl ();

    public function getNoScriptText ()
        {
        return $this->getText ("You need to enable scripts in your browser.");
        }
    }

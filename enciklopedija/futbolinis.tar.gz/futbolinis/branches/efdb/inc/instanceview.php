<?php

abstract class InstanceView extends InteractiveComponent
    {
    protected $instance;
    protected $ids = NULL;
    protected $dbtable = NULL;
    protected $visible = true;

    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->messagesDisplayedInline = true;
        }

    public function checkAccess ()
        {
        if (!empty ($this->dbtable))
            return $this->dbtable->canRead ();

        return NULL;
        }

    public function getButtonPrefix ()
        {
        $prefix = $this->getPrefix();
        if (empty ($prefix))
            return "";
        return $prefix."_";
        }

    public function processInput ($context, &$request)
        {
        return parent::processInput ($context, $request);
        }

    public function parseIds ($ids)
        {
        if (is_numeric ($ids))
            $ids = array ($ids);
        else if (is_string ($ids))
            $ids = explode ("_", $ids);

        return $ids;
        }

    public function setIds ($ids)
        {
        $this->ids = $this->parseIds ($ids);
        }

    protected function getIds ()
        {
        if (NULL === $this->ids)
            $this->log ("Warning: editor id not set");

        return $this->ids;
        }

    public abstract function getPageTitle ();

    public function getTitle ()
        {
        return $this->getPageTitle ();
        }

    public function getInstance ()
        {
        if (isset ($this->instance))
            return $this->instance;
        return $this->getRequest ();
        }

    }

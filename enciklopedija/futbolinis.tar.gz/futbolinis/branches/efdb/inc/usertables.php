<?php
require_once (PATH.'inc/dbtable.php');

abstract class SecurityTable extends DBTable
    {
    public $skipAccessChecks = false;

    public function __construct ($context, $tablename, $hasStringTable)
        {
        parent::__construct ($context, Constants::TABLES_SECURITY, $tablename, $hasStringTable);
        }

    public function canRead ()
        {
        return true;
        }

    public function canCreate ()
        {
        if ($this->skipAccessChecks)
            return true;
        return parent::canCreate ();
        }
    }

class UserLoginsTable extends SecurityTable
    {
    const TABLE_NAME = "userlogins";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_NAME, false);
        $this->skipAccessChecks = true;
        }

    protected function getColumns ()
        {
        return array (
                     new IntColumn ("uid"),
                     new TextColumn ("ip", 64, true),
                     new TextColumn (DBTableWithPerspective::COL_PERSPECTIVE, 24, true),
                     new TextColumn ("loginHash", 256)
                     );
        }

    protected function addSystemColumns ($columns, $addcreated = true, $addupdated = true, $addsource = NULL)
        {
        // no need for updated on/by columns
        return parent::addSystemColumns ($columns, $addcreated, false);
        }
        
    protected function getIndexes ()
        {
        return array (new UniqueIndex ("uid", "ip", DBTableWithPerspective::COL_PERSPECTIVE));
        }

    public function update ($uid, $ip)
        {
        if (false === $this->delete ($uid, $ip))
            {
            return false;
            }

        $hashCode = md5(uniqid(rand(),1));
        
        if (false === parent::insertRecord (array ("uid" => $uid, "ip" => $ip, "loginHash" => $hashCode,
                                                   DBTableWithPerspective::COL_PERSPECTIVE => $this->context->getPerspective ())))
            return false;

        return $hashCode;
        }

    public function delete ($uid, $ip)
        {
        return $this->deleteBy (array (new EqCriterion ("uid", $uid),
                                       new EqCriterion ("ip", $ip),
                                       new EqCriterion (DBTableWithPerspective::COL_PERSPECTIVE, $this->context->getPerspective ())));
        }

    public function selectUser ($hashCode, $ip)
        {
        $row = parent::selectSingleBy (array ("uid"),
                                       array (new EqCriterion ("ip", $ip),
                                              new EqCriterion ("loginHash", $hashCode),
                                              new EqCriterion (DBTableWithPerspective::COL_PERSPECTIVE, $this->context->getPerspective ())));
        if (empty ($row))
            return -1;
        return $row["uid"];
        }

    public function canDelete ()
        {
        return true;
        }

    }

class LoggedInUser
    {
    public $id;
    public $sessionId;
    public function __construct ($userId, $loginSessionId)
        {
        $this->id = $userId;
        $this->sessionId = $loginSessionId;
        }
    }

class GroupMembersTable extends SecurityTable
    {
    const TABLE_NAME = "groupmembers";

    const COL_GROUPID = "groupid";
    const COL_USERID = "userid";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_NAME, false);
        }

    protected function getColumns ()
        {
        return array (
                     new IntColumn (self::COL_GROUPID),
                     new IntColumn (self::COL_USERID),
                     );
        }

    protected function getIndexes ()
        {
        return array (new PrimaryIndex (self::COL_GROUPID, self::COL_USERID));
        }

    public function add ($groupId, $userId)
        {
        return false !== parent::insertRecord (array (self::COL_GROUPID => $groupId,
                                                      self::COL_USERID => $userId));
        }

    public function deleteByGroup ($groupId)
        {
        return $this->deleteBy (array (new EqCriterion (self::COL_GROUPID, $groupId)));
        }

    public function deleteByUser ($userId)
        {
        return $this->deleteBy (array (new EqCriterion (self::COL_USERID, $userId)));
        }
    }

class GroupAccessTable extends SecurityTable
    {
    const TABLE_NAME = "groupaccess";

    const COL_GROUPID = "groupid";
    const COL_SCOPE = "scope";
    const COL_TABLE = "tablename";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_NAME, false);
        }

    protected function getColumns ()
        {
        return array (
                     new IntColumn (self::COL_GROUPID),
                     new TextColumn (self::COL_SCOPE, 32), // "*", "meta", "sec", "x", ...
                     new TextColumn (self::COL_TABLE, 64, true),
                     new BoolColumn ("canread"),
                     new BoolColumn ("cancreate"),
                     new BoolColumn ("canedit"),
                     new BoolColumn ("candelete"),
                     new IntColumn ("custom", true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new PrimaryIndex (self::COL_GROUPID, self::COL_SCOPE, self::COL_TABLE));
        }

    public function set ($groupId, $scope, $table, $read, $create = false, $edit = false, $delete = false)
        {
        return false !== parent::insertRecord (array (self::COL_GROUPID => $groupId,
                                                      self::COL_SCOPE => $scope,
                                                      self::COL_TABLE => $table,
                                                      "canread" => $read,
                                                      "cancreate" => $create,
                                                      "canedit" => $edit,
                                                      "candelete" => $delete));
        }

    public function deleteByGroup ($groupId)
        {
        return $this->deleteBy (array (new EqCriterion (self::COL_GROUPID, $groupId)));
        }

    public function canRead ()
        {
        return true;
        }
    }

class GroupsTable extends SecurityTable
    {
    const TABLE_NAME = "groups";

    const COL_ID = "groupid";
    const COL_NAME = "name";
    const COL_LABEL = "label";
    const COL_DESCRIPTION = "description";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_NAME, true);
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     new TextColumn (self::COL_NAME, 64), /* default non translated name */
                     // new IntColumn ("parentgroupid"), // not yet supported
                     );
        }

    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (self::COL_LABEL, 256, true),
                     new TextColumn (self::COL_DESCRIPTION, 256, true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new UniqueIndex (self::COL_NAME));
        }

    public function create ($defaultName, $name, $description)
        {
        return parent::insertRecord (array (self::COL_LABEL => $name,
                                            self::COL_DESCRIPTION => $description,
                                            self::COL_NAME => $defaultName));
        }

    public function deleteById ($criteria)
        {
        if (!parent::deleteById ($criteria))
            return false;

        $id = $this->extractSingleIdFromCriteria ($criteria);

        $membersTable = new GroupMembersTable ($this->context);
        $accessTable = new GroupAccessTable ($this->context);
        if (false === $membersTable->deleteByGroup ($id) || false === $accessTable->deleteByGroup ($id))
            return false;
        return true;
        }

    public function canRead ()
        {
        return true;
        }
    }

class UsersTable extends SecurityTable
    {
    const TABLE_NAME = "users";

    const COL_ID = "uid";
    const COL_NAME = "name";
    const COL_DESCRIPTION = "description";
    const COL_EMAIL = "email";
    const COL_PASSWORD = "pwd";
    const COL_OPTIN = "isactive";
    private $canEdit = false;

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_NAME, true);
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     new TextColumn (self::COL_NAME, 32),
                     new TextColumn (self::COL_EMAIL, 128, true),
                     new PasswordColumn (self::COL_PASSWORD, 128, true),
                     new BoolColumn (self::COL_OPTIN),
                     );
        }

    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (self::COL_DESCRIPTION, 256, true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new UniqueIndex (self::COL_NAME), new UniqueIndex (self::COL_EMAIL));
        }

    public function canEdit ()
        {
        // user can edit his own info
        return parent::canEdit () || $this->canEdit;
        }

    public function editOptInStatus ($optin)
        {
        $this->canEdit = true;
        $criteria = array (new EqCriterion (UsersTable::COL_ID, $this->context->getCurrentUser()));
        $namesToValues = array (UsersTable::COL_OPTIN => $optin);
        $ret = $this->updateRecord ($criteria, $namesToValues);
        $this->canEdit = false;
        return $ret;
        }

    public function create ($name, $description, $email, $pwd)
        {
        $values = array (self::COL_NAME => $name,
                         self::COL_PASSWORD => $pwd,
                         self::COL_OPTIN => true);
        if (NULL != $description)
            $values[self::COL_DESCRIPTION] = $description;
        if (NULL != $email)
            $values[self::COL_EMAIL] = $email;

        $skipChecksOldValue = $this->skipAccessChecks;
        $this->skipAccessChecks = true;

        $id = parent::insertRecord ($values);

        $this->skipAccessChecks = $skipChecksOldValue;

        // if there is no default user defined for registered user, just return
        $group = defined ("DEFAULT_GROUP") ? DEFAULT_GROUP : NULL;
        if (empty ($id) || empty ($group))
            return $id;

        // create default membership
        $groupsTable = new GroupsTable ($this->context);
        $row = $groupsTable->selectSingleBy (array (GroupsTable::COL_ID), array (new EqCriterion (GroupsTable::COL_NAME, DEFAULT_GROUP)));
        if (empty ($row))
            {
            $this->log ("Default user group ".DEFAULT_GROUP." not found");
            return $id;
            }

        $membersTable = new GroupMembersTable ($this->context);
        $membersTable->skipAccessChecks = true;
        if (false === $membersTable->add ($row[GroupsTable::COL_ID], $id))
            $this->log ("Unable to add a user to a group");

        return $id;
        }

    public function selectUser ($name, $password)
        {
        return parent::selectSingleBy (NULL, array (new EqCriterion (self::COL_NAME, $name), new EqCriterion (self::COL_PASSWORD, $password)));
        }

    public function deleteById ($criteria)
        {
        if (!parent::deleteById ($criteria))
            return false;

        $id = $this->extractSingleIdFromCriteria ($criteria);

        $membersTable = new GroupMembersTable ($this->context);
        if (false === $membersTable->deleteByUser ($id))
            return false;
        return true;
        }

    public function openIdLogin ($ip, $userId)
        {
        return $this->onLogin ($ip, $userId);
        }

    public function login ($ip, $user, $password)
        {
        $userRow = $this->selectUser ($user, $password);
        
        if (NULL == $userRow)
            return false;
        return $this->onLogin ($ip, $userRow[self::COL_ID]);
        }

    private function onLogin ($ip, $id)
        {
        $loginsTable = new UserLoginsTable ($this->context);
        $dbconn = $this->context->getConnection ();
        $dbconn->startTransaction ();
        $loginSessionId = $loginsTable->update ($id, $ip);

        if (false === $loginSessionId)
            {
            $dbconn->rollbackTransaction ();
            return false;
            }

        $dbconn->commitTransaction ();
        
        return new LoggedInUser ($id, $loginSessionId);
        }

    public function logout ($userId, $ip)
        {
        $userLoginsTable = new UserLoginsTable ($this->context);
        return $userLoginsTable->delete ($userId, $ip);
        }

    /* static functions */
    public static function isDeployed ($context, $dbconn)
        {
        $classes = array ("UsersTable", "UserLoginsTable", "GroupsTable", "GroupMembersTable", "GroupAccessTable");
        $tables = array();
        for ($i = 0; $i < count ($classes); $i++)
            {
            $class = $classes[$i];
            $instance = new $class ($context);
            $table = $instance->getTableName ();
            $tables[] = $table;
            $table = $instance->getStringTableName ();
            if (NULL != $table)
                $tables[] = $table;
            }

        return $dbconn->tablesExists ($tables);
        }

    public function canRead ()
        {
        return true;
        }


    private static $cachedUserId = NULL;
    private static $cachedAccessRows = array ();
    private static $cachedAccess;
    private static $cachedDefaultAccess = NULL;

    public static function getAccess ($context, $userId, $scope, $table = Constants::ANY)
        {
        if (self::$cachedUserId !== $userId)
            {
            $membersTable = new GroupMembersTable ($context);
            $accessTable = new GroupAccessTable ($context);
            if ($userId != Constants::GUEST)
                $userCriteria = new LogicalOperatorOr (new EqCriterion (GroupMembersTable::COL_USERID, $userId),
                                                       new EqCriterion (GroupMembersTable::COL_USERID, Constants::GUEST));
            else
                $userCriteria = new EqCriterion (GroupMembersTable::COL_USERID, $userId);
    
            $subquery = $membersTable->createQuery (array (),
                                                    array ($userCriteria,
                                                           new JoinColumnsCriterion (GroupAccessTable::COL_GROUPID, GroupMembersTable::COL_GROUPID)));
    
            $rows = $accessTable->selectBy (array (GroupAccessTable::COL_SCOPE,
                                                   GroupAccessTable::COL_TABLE,
                                                   new FunctionMax ("canread"),
                                                   new FunctionMax ("cancreate"),
                                                   new FunctionMax ("canedit"),
                                                   new FunctionMax ("candelete")
                                                  ),
                                            NULL,
                                            $subquery,
                                            array (new GroupByAll()));

            self::$cachedUserId = $userId;
            self::$cachedAccessRows = $rows;
            self::$cachedAccess = array ();
            }

        $tableScope = $scope."|".$table;
        if (array_key_exists ($tableScope, self::$cachedAccess))
            return self::$cachedAccess[$tableScope];

        $rows = self::$cachedAccessRows;
        if (empty ($rows))
            return false;

        $calculated = array ("canread" => false, "cancreate" => false, "canedit" => false, "candelete" => false);
        foreach ($rows as $row)
            {
            if (Constants::ANY != $row[GroupAccessTable::COL_TABLE] && $table != $row[GroupAccessTable::COL_TABLE])
                continue;
            if (Constants::ANY != $row[GroupAccessTable::COL_SCOPE] && $scope != $row[GroupAccessTable::COL_SCOPE])
                continue;

            foreach (array_keys ($calculated) as $key)
                {
                if (!$calculated[$key] && $row[$key])
                    $calculated[$key] = $row[$key];
                }
            }

        self::$cachedAccess[$tableScope] = $calculated;
        return $calculated;
        }

    public static function getDefaultGroupAccess ($context, $scope, $table = Constants::ANY)
        {
        $noAccess = array ("canread" => false, "cancreate" => false, "canedit" => false, "candelete" => false);
        $group = defined ("DEFAULT_GROUP") ? DEFAULT_GROUP : NULL;

        if (empty ($group))
            return $noAccess;

        if (NULL === self::$cachedDefaultAccess)
            {
            $groupsTable = new GroupsTable ($context);
            $accessTable = new GroupAccessTable ($context);
    
            $subquery = $groupsTable->createQuery (array (),
                             array (new EqCriterion (GroupsTable::COL_NAME, $group),
                                    new JoinColumnsCriterion (GroupAccessTable::COL_GROUPID, GroupsTable::COL_ID)));
    
            $rows = $accessTable->selectBy (array (GroupAccessTable::COL_SCOPE,
                                                   GroupAccessTable::COL_TABLE,
                                                   new FunctionMax ("canread"),
                                                   new FunctionMax ("cancreate"),
                                                   new FunctionMax ("canedit"),
                                                   new FunctionMax ("candelete")
                                                  ),
                                            NULL,
                                            $subquery,
                                            array (new GroupByAll()));
            if (empty ($rows))
                $rows = array ();
    
            self::$cachedDefaultAccess = $rows;
            }

        $rows = self::$cachedDefaultAccess;
        $calculated = array ("canread" => false, "cancreate" => false, "canedit" => false, "candelete" => false);
        foreach ($rows as $row)
            {
            if (Constants::ANY != $row[GroupAccessTable::COL_TABLE] && $table != $row[GroupAccessTable::COL_TABLE])
                continue;
            if (Constants::ANY != $row[GroupAccessTable::COL_SCOPE] && $scope != $row[GroupAccessTable::COL_SCOPE])
                continue;

            foreach (array_keys ($calculated) as $key)
                {
                if (!$calculated[$key] && $row[$key])
                    $calculated[$key] = $row[$key];
                }
            }

        return $calculated;
        }
    }

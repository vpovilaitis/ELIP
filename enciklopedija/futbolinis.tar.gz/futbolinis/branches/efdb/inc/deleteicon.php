<?php
require_once (PATH.'inc/action.php');

abstract class RemoveIcon extends IconAction
    {
    public function __construct ($component, $key, $tooltip)
        {
        parent::__construct ($component, $key, $tooltip);
        }

    public function getTemplateName ()
        {
        return "deleteicon";
        }

    public function getConfirmField ()
        {
        return $this->component->getConfirmField ();
        }

    public function requiresId ()
        {
        return true;
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        $confirmedId = NULL;
        if (!empty ($request["confirmed"]))
            $confirmedId = explode ("_", $request["confirmed"]);

        if ((NULL !== $singleItemId && $confirmedId != $singleItemId) ||
            (NULL === $singleItemId && "x" != $confirmedId))
            {
            $this->context->addMessage ("Action was not confirmed, probably scripts are turned off. Please repeat action to confirm it.");
            $this->component->lastUnconfirmedId = (NULL !== $singleItemId) ? $singleItemId : "x";
            return false;
            }

        return true;
        }

    protected function getCriteria ($idColumns, $ids)
        {
        $criteria = array();
        for ($i = 0; $i < count ($ids); $i++)
            {
            $id = $ids[$i];
            $criterion = array();
            for ($c = 0; $c < count ($idColumns) && $c < count ($id); $c++)
                {
                $criterion[] = new EqCriterion ($idColumns[$c], $id[$c]);
                }

            $criteria[] = $criterion;
            }

        return $criteria;
        }

    public abstract function getConfirmationString ($row);
    }

class DeleteIcon extends RemoveIcon
    {
    protected $dbtable;
    protected $forceVisible;

    public function __construct ($component, $dbtable, $forceVisible = false)
        {
        parent::__construct ($component, "delete", $this->_("Delete"));
        $this->dbtable = $dbtable;
        $this->forceVisible = $forceVisible;

        $this->context->addScriptFile ("editor");
        }

    public function isVisible ($row = NULL)
        {
        return $this->forceVisible || $this->dbtable->canDelete ();
        }

    protected function cleanupRelatedData ($ids)
        {
        return true;
        }

    public function execute ($request, $ids)
        {
        $idCriteriaArray = $this->getCriteria ($this->component->getIndexColumns (), $ids);
        $con = $this->context->getConnection ();
        $con->startTransaction ();

        if (!$this->cleanupRelatedData ($ids))
            {
            $con->rollbackTransaction ();
            return true;
            }

        for ($i = 0; $i < count ($idCriteriaArray); $i++)
            {
            if (false === $this->dbtable->deleteById ($idCriteriaArray[$i]))
                {
                $con->rollbackTransaction ();
                $this->component->addError ("Delete failed.");
                return true;
                }
            }

        $con->commitTransaction ();
        $this->component->addMessagePrepared ($this->ngettext ("Item was successfully deleted.", "[_0] items were successfully deleted", count ($idCriteriaArray)));
        return true;
        }

    public function getConfirmationString ($row)
        {
        if (NULL == $row)
            return $this->context->getForJS ("Do you realy wish to delete the selected items?");
        else
            return $this->context->getForJS ("Do you realy wish to delete this item?");
        }
    }

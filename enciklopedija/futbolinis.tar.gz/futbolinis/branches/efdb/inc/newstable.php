<?php

/* A database table which stores news and announcements */
class NewsTable extends DBTableWithPerspective
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "news";

    const COL_ID = "newsid";
    const COL_ENTRY_DATE = "entrydate";
    const COL_TITLE = "title";
    const COL_OVERVIEW = "overview";
    const COL_DETAILS = "details";
    const COL_HIDDEN = "hidden";

    const COL_UPDATE_ENTRY_DATE = "update_date";

    const RESULTCOL_DATE = "date";
    const RESULTCOL_HAS_DETAILS = "hasDetails";

    const DEFAULT_ITEMS = 10;
    const DEFAULT_ITEMS_WITH_OVERVIEW = 3;

    public function __construct ($context, $perspective = false)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, false);
        $this->tracksRevisions = true;
        $this->tracksSources = true;
        $this->setPerspective ($perspective);
        }

    protected function getColumns ()
        {
        return array (
                     new AutoincrementColumn (self::COL_ID),
                     $this->getPerspectiveColumn (),
                     new TextColumn (DBTable::COL_LANG, 5),
                     new DateTimeColumn (self::COL_ENTRY_DATE, true),
                     new BoolColumn (self::COL_HIDDEN, false),
                     new TextColumn (self::COL_TITLE, 512, false),
                     new LongTextColumn (self::COL_OVERVIEW, true),
                     new LongTextColumn (self::COL_DETAILS, true),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new Index (self::COL_PERSPECTIVE, DBTable::COL_LANG, self::COL_HIDDEN, self::COL_ENTRY_DATE),
            );
        }

    public function insertRecord ($nameToValue)
        {
        if (empty ($nameToValue[DBTable::COL_LANG]))
            {
            $nameToValue[DBTable::COL_LANG] = $this->context->getLanguage();
            }

        $ret = parent::insertRecord ($nameToValue);
        $this->clearCache ();
        return $ret;
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = 1)
        {
       if (!empty ($nameToValue[self::COL_UPDATE_ENTRY_DATE]))
            $nameToValue[self::COL_ENTRY_DATE] = date ("Y-m-d H:i:00", time ());

        if (array_key_exists (self::COL_UPDATE_ENTRY_DATE, $nameToValue))
            unset ($nameToValue[self::COL_UPDATE_ENTRY_DATE]);

        $ret = parent::updateRecord ($criteria, $nameToValue, $maxRows);
        $this->clearCache ();
        return $ret;
        }

    protected function clearCache ()
        {
        $cache = Cache::getInstance (self::TABLE_NAME, 6*60*60);
        $cache->clean ();
        }
        
    public function deleteById ($criteria)
        {
        $ret = parent::deleteById ($criteria);
        $this->clearCache ();
        return $ret;
        }

    public function selectNews ($maxItems, $defaultWithOverview = NULL, $showHidden = false)
        {
        if (NULL === $defaultWithOverview)
            $defaultWithOverview = self::DEFAULT_ITEMS_WITH_OVERVIEW;
        
        $cache = Cache::getInstance (self::TABLE_NAME, 6*60*60);
        $key = "news-$maxItems-$defaultWithOverview-$showHidden-".md5 ($this->getPerspective ());
        if (false === ($rows = $cache->get ($key)))
            {
            $rows = $this->selectNewsNoCache ($maxItems, $defaultWithOverview, $showHidden);
            if (false !== $rows)
                $cache->save ($rows, $key);
            }
        return $rows;
        }

    protected function selectNewsNoCache ($maxItems, $defaultWithOverview, $showHidden)
        {
        $columns = array (NewsTable::COL_HIDDEN, DBTable::COL_CREATEDON, NewsTable::COL_ID, NewsTable::COL_TITLE, NewsTable::COL_OVERVIEW, NewsTable::COL_DETAILS);
        $columns[] = new ConditionalResultColumn ("dt", NewsTable::COL_ENTRY_DATE." IS NULL", DBTable::COL_CREATEDON, NewsTable::COL_ENTRY_DATE);
        $criteria = array ();
        if (!$showHidden)
            $criteria[] = new EqCriterion (NewsTable::COL_HIDDEN, 0);
        $params[] = new LimitResults (0, $maxItems);
        $params[] = OrderBy::createByAlias ("dt", false);
        $rows = $this->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rows))
            $rows = array ();

        $cnt = 0;
        $ret = array ();
        $lng = Language::getInstance ($this->context);
        
        foreach ($rows as $row)
            {
            $cnt++;
            $entry = array ();
            $entry[NewsTable::COL_ID] = $row[NewsTable::COL_ID];
            $entry[NewsTable::RESULTCOL_DATE] = $lng->dateToLongString ($row["dt"]);
            $entry[NewsTable::COL_ENTRY_DATE] = $row["dt"];
            $entry[NewsTable::COL_OVERVIEW] = $cnt <= $defaultWithOverview ? $row[NewsTable::COL_OVERVIEW] : NULL;
            $entry[NewsTable::RESULTCOL_HAS_DETAILS] = $cnt <= $defaultWithOverview ? !empty ($row[NewsTable::COL_DETAILS]) : true;
            $entry[NewsTable::COL_DETAILS] = $row[NewsTable::COL_DETAILS];
            $entry[NewsTable::COL_HIDDEN] = !empty ($row[NewsTable::COL_HIDDEN]);

            $entry[NewsTable::COL_TITLE] = self::getEntryTitle ($this->context, $lng, $row, "dt");

            $ret[] = $entry;
            }

        return $ret;
        }

    public static function getEntryTitle ($context, $lng, $row, $conditionalDateColumn)
        {
        $title = $row[NewsTable::COL_TITLE];
        if (!empty ($row[NewsTable::COL_HIDDEN]))
            $title = $context->getText ("[_0] (unpublished)", $title);
        else if ($row[DBTable::COL_CREATEDON] != $row[$conditionalDateColumn])
            {
            $updatedOn = $row[$conditionalDateColumn];
            $now = time ();
            $timestamp = strtotime ($updatedOn);
            $dateOrTime = (false === $timestamp || $timestamp < $now - 8*60*60) ? $lng->dateToString ($updatedOn) : $lng->extractTimeFromDate ($updatedOn);
            $title = $context->getText ("[_0] (updated on [_1])", $title, $dateOrTime);
            }

        return $title;
        }
    
    public function getContentLink ($id)
        {
        return $this->context->chooseUrl ("newsitem/$id", "index.php?c=NewsListPage&id=$id");
        }

    public function getDisplayNameById ($id)
        {
        return $this->getText ("news item");
        }
    }

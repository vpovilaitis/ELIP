<?php

/* A database table which stores image usage - pages, which might show the image */
class ImageUseTable extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_PREDEFINED;
    const TABLE_NAME = "imageuse";

    const COL_IMAGEID = "imageid";
    const COL_SCOPE = "scope"; // 'm_fragments', 'x_persons', etc
    const COL_CONTEXTID = "contextid";
    const COL_TITLE = "title";
    const COL_ZONE = "zone";
    const COL_PRIORITY = "priority";
    const COL_DATEFROM = "datefrom";
    const COL_DATETO = "dateto";

    const ZONE_LOGO = "logo";
    const ZONE_REPORT = "report";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, true);
        $this->tracksRevisions = true;
        }

    protected function getColumns ()
        {
        return array (
                     new IntColumn (self::COL_IMAGEID, false),
                     new TextColumn (self::COL_SCOPE, 128, false),
                     new TextColumn (self::COL_CONTEXTID, 32, false),
                     new TextColumn (self::COL_ZONE, 32, true),
                     new IntColumn (self::COL_PRIORITY, true),
                     new DateColumn (self::COL_DATEFROM, true),
                     new DateColumn (self::COL_DATETO, true),
                     );
        }

    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (self::COL_TITLE, 256, true),
                     );
        }

    protected function getIndexes ()
        {
        return array
            (
            new Index (self::COL_IMAGEID),
            new PrimaryIndex (self::COL_SCOPE, self::COL_CONTEXTID, self::COL_ZONE, self::COL_IMAGEID),
            );
        }

    public function deleteRecord ($scope, $contextId, $zone, $id)
        {
        $criteria[] = new EqCriterion (ImageUseTable::COL_SCOPE, $scope);
        $criteria[] = new EqCriterion (ImageUseTable::COL_CONTEXTID, $contextId);
        $criteria[] = new EqCriterion (ImageUseTable::COL_ZONE, $zone);
        $criteria[] = new EqCriterion (ImageUseTable::COL_IMAGEID, $id);
        
        return $this->deleteBy ($criteria, true);
        }

    }

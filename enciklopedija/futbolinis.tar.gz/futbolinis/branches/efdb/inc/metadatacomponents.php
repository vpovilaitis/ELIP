<?php
class MetaDataComponents extends DBTable
    {
    const TABLE_SCOPE = Constants::TABLES_META;
    const TABLE_NAME = "components";

    const COL_PAGEID = "pageid";
    const COL_COMPONENTID = "cid";
    const COL_NAME = "name";
    const COL_TYPE = "type";
    const COL_TEMPLATE = "template";
    const COL_ZONEID = "zoneid";
    const COL_TABLEID = "tableid"; // target table id
    const COL_LABEL = "label";
    const COL_DESCRIPTION = "description";

    public function __construct ($context)
        {
        parent::__construct ($context, self::TABLE_SCOPE, self::TABLE_NAME, true);
        $this->defaultOrderBy = array (new OrderByColumn (DBTable::COL_ORDER));
        }

    protected function getColumns ()
        {

        return array (
                     new IntColumn (self::COL_PAGEID),
                     new IntColumn (self::COL_COMPONENTID),
                     new TextColumn (self::COL_NAME, 64),
                     new TextColumn (self::COL_TYPE, 64),
                     new TextColumn (self::COL_TEMPLATE, 128, true),
                     new IntColumn (self::COL_ZONEID),
                     new IntColumn (self::COL_TABLEID, true),
                     new IntColumn (DBTable::COL_ORDER),
                     );
        }
        
    protected function getTranslatableColumns ()
        {
        return array (
                     new TextColumn (self::COL_LABEL, 64, true),
                     new LongTextColumn (self::COL_DESCRIPTION, true),
                     );
        }

    protected function getIndexes ()
        {
        return array (new PrimaryIndex (self::COL_PAGEID, self::COL_COMPONENTID),
                      new UniqueIndex (self::COL_PAGEID, self::COL_NAME));
        }

    public function deleteByPage ($pageId)
        {
        return $this->deleteBy (array (new EqCriterion (self::COL_PAGEID, $pageId)), true);
        }

    public function insertRecord ($nameToValue)
        {
        // TODO: need to implement table locking
        $maxCol = array (new FunctionMax (self::COL_COMPONENTID, "maxId"));
        $criteria = array ();
        $criteria[] = new EqCriterion (self::COL_PAGEID, $nameToValue[self::COL_PAGEID]);

        $row = $this->selectSingleBy ($maxCol, $criteria);
        if (false === $row)
            $result = false;
        else
            {
            $nameToValue[DBTable::COL_ORDER] = $nameToValue[self::COL_COMPONENTID] = $row["maxId"]+1;

            $result = parent::insertRecord ($nameToValue);
            }

        if (false === $result)
            return false;

        return array ($nameToValue[self::COL_PAGEID], $row["maxId"]+1);
        }

    public function changeOrder ($pageId, $id, $up)
        {
        $criteria = array (new EqCriterion (self::COL_PAGEID, $pageId));
        return parent::changeItemOrder ($criteria, self::COL_COMPONENTID, $id, $up);
        }

    }

?>

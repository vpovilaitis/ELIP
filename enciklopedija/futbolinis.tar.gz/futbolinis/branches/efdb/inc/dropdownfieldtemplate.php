<?php

class DropDownFieldTemplate extends FieldTemplate
    {
    protected $items;

    public function __construct ($prefix, $key, $label, $tooltip, $items)
        {
        parent::__construct ($prefix, $key, "select", $label, $tooltip);
        $this->items = $items;
        }

    public function getItems ($context, $currentValue)
        {
        if (is_bool ($currentValue))
            $currentValue = $currentValue ? 1 : 0;
        if (empty ($currentValue) || array_key_exists ($currentValue, $this->items))
            return $this->items;
        $items[$currentValue] = $context->getText ("Do not change the value (\"[_0]\")", $currentValue);
        $items = array_merge ($items, $this->items);
        return $items;
        }

    public function addItem ($id, $label)
        {
        $this->items[$id] = $label;
        }

    }

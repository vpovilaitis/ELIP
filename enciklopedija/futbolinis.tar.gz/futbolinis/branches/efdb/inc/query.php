<?php
require_once (PATH."inc/column.php");
require_once (PATH."inc/valuetransformation.php");
require_once (PATH."inc/queryparams.php");

class Query
    {
    public $table;
    public $tableAlias;
    public $joinType;

    protected $columns;
    protected $columnsPrepared = false;
    protected $criteria;
    public $joinedQueries;

    public $groupBy = array (); // GROUP BY columns
    public $orderBy = array (); // ORDER BY columns

    public $translationsJoin;
    public $transformations = array (); // column value transformations

    protected $simpleCriteria = array();
    protected $joinCriteria = array();
    protected $isCriteriaSplit = false;

    protected $namesToColumns = false;

    public function __construct 
        (
        $table,
        $columns,
        $criteria,
        $joinedQueries = NULL,
        $namesToColumns = NULL
        )
        {
        $this->table = $table;
        $this->joinType = Constants::JOIN_INNER;
        $this->columns = $columns;
        $this->criteria = $criteria;
        $this->joinedQueries = $joinedQueries;
        $this->namesToColumns = $namesToColumns;
        }

    public function &getTranslatableColumnSubquery ()
        {
        return $this->translationsJoin;
        }

    public function columnFromName ($name)
        {
        $alias = NULL;
        $colname = $name;
        if (!empty ($this->tableAlias))
            {
            $alias = $this->tableAlias."_".$colname;
            }

        $col = new Column ($colname, $alias);
        $col->temporaryAlias = true;
        return $col;
        }

    public function initializeColumns ()
        {
        if ($this->columnsPrepared)
            return;

        $preparedColumns = array ();
        foreach ($this->columns as $col)
            {
            if (!$col instanceof Column)
                {
                $col = $this->columnFromName ($col);
                }
            $preparedColumns[] = $col;
            }
        $this->columns = $preparedColumns;
        $this->columnsPrepared = true;
        }

    public function getColumns ()
        {
        $this->initializeColumns ();
        return $this->columns;
        }

    public function ensureColumn ($columnName)
        {
        $this->initializeColumns ();
        foreach ($this->columns as $col)
            {
            if ($col->name == $columnName)
                return;
            }

        $this->columns[] = $this->columnFromName ($columnName);
        }

    public function getTransformations ($recursive = true)
        {
        $tableAlias = empty ($this->tableAlias) ? "" : $this->tableAlias.".";
        $columnPrefix = empty ($this->tableAlias) ? "" : $this->tableAlias."_";
        $definedTransformations = $this->transformations;
        $transformations = array ();
        foreach ($this->columns as $col)
            {
            $columnAlias = empty ($col->alias) ? $col->name : $col->alias;
            $colName = empty ($col->temporaryAlias) ? $columnAlias : $col->name;
            if (array_key_exists ($col->name, $definedTransformations))
                {
                $transform = clone $definedTransformations[$col->name];
                $transform->adjust ($columnPrefix);
                unset ($definedTransformations[$col->name]);
                }
            else
                {
                $transform = NULL;

                if (!empty ($this->namesToColumns) &&
                    isset ($this->namesToColumns[$col->name]))
                    {
                    $columnDef = $this->namesToColumns[$col->name];
                    if ($columnDef instanceof BoolColumn)
                        $transform = new BoolValueTransformation ($columnAlias);
                    else
                        $transform = new ColumnValueTransformation ($columnAlias, $columnDef);
                    }

                if (empty ($transform))
                    {
                    $transform = new ValueTransformation ($columnAlias);
                    $transform->adjust ($columnPrefix);
                    }
                }

            $transformations[$tableAlias.$colName] = $transform;
            }

        foreach ($definedTransformations as $name => $transformation)
            {
            $transform = clone $transformation;
            $transform->adjust ($columnPrefix);

            $transformations[$tableAlias.$name] = $transform;
            }

        if ($recursive)
            {
            $joinedQueries = $this->getJoinedQueries ();
            if (NULL == $joinedQueries)
                return $transformations;

            foreach ($joinedQueries as $joinedQuery)
                {
                $transformations = array_merge ($transformations, $joinedQuery->getTransformations (true));
                }
            }

        return $transformations;
        }

    protected function splitCriteria ()
        {
        if ($this->isCriteriaSplit)
            return;

        $this->isCriteriaSplit = true;

        if (NULL == $this->criteria)
            return;

        if (!is_array ($this->criteria))
            $this->criteria = array ($this->criteria);

        for ($i = 0; $i < count ($this->criteria); $i++)
            {
            if ($this->criteria[$i] instanceof JoinCriterion)
                $this->joinCriteria[] = $this->criteria[$i];
            else if ($this->criteria[$i] instanceof SingleTableCriterion)
                $this->simpleCriteria[] = $this->criteria[$i];
            }
        }

    public function getCriteria ()
        {
        $this->splitCriteria ();
        return $this->simpleCriteria;
        }

    public function getJoinCriteria ()
        {
        $this->splitCriteria ();
        return $this->joinCriteria;
        }

    public function getJoinedQueries ()
        {
        $joins = NULL;
        if (NULL == $this->joinedQueries)
            $joins = array ();
        else if (!is_array ($this->joinedQueries))
            $joins = array ($this->joinedQueries);
        else
            $joins = $this->joinedQueries;

        if (!empty ($this->translationsJoin))
            $joins[] = $this->translationsJoin;
        return $joins;
        }

    public function addJoinedQueries ($queries)
        {
        $this->joinedQueries = array_merge ($this->getJoinedQueries (),
                                            !is_array ($queries) ? array ($queries) : $queries);
        }

    public function setOrderBy ($orderBy)
        {
        if (empty ($orderBy))
            return;

        $this->orderBy = array ();
        foreach ($orderBy as $col)
            $this->orderBy[] = clone $col;
        }

    public function getOrderByColumns ($recursive)
        {
        $arr = $this->orderBy;
        if ($recursive)
            {
            $joins = $this->getJoinedQueries ();
            if (!empty ($joins))
                {
                foreach ($joins as $join)
                    $arr = array_merge ($arr, $join->getOrderByColumns (true));
                }
            }

        return $arr;
        }

    public function clearOrderBy ($recursive)
        {
        $this->orderBy = array ();

        if ($recursive)
            {
            $joins = $this->getJoinedQueries ();
            if (!empty ($joins))
                {
                foreach ($joins as $join)
                    $join->clearOrderBy (true);
                }
            }
        }
    }

?>

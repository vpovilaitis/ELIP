<?php
require_once (PATH.'inc/base.php');
require_once (PATH.'inc/dbconnection.php');

abstract class DBTable extends BaseWithContext
    {
    private $db;
    protected $tablename;
    protected $scope;
    protected $hasStringTable;
    private static $cachedAccess = array();
    protected $language = NULL;
    protected $tracksRevisions = false;
    protected $tracksSources = false;
    protected $defaultOrderBy = NULL;
    protected $ownerDeleteAllowed = false;

    const COL_LANG = "lngcode";
    const COL_REVISIONID = "revid";
    const COL_REVISION_ACTIVE = "rev_active";
    const COL_UPDATEDON = "updatedon";
    const COL_UPDATEDBY = "updatedby";
    const COL_CREATEDON = "createdon";
    const COL_CREATEDBY = "createdby";
    const COL_SOURCE = "source"; // Source/comment column
    const COL_SOURCEDATE = "sourcedate";
    const COL_ORDER = "order";

    const LNG_PREFIX = "def_";

    public function __construct ($context, $scope, $tablename, $hasStringTable)
        {
        parent::__construct ($context);

        if (!($context instanceof PageContext))
            {
            echo "Incorect \$context value passed to DBTable (".get_class ($this).") constructor (".print_r ($context, true).")";
            exit ();
            }

        $this->db = $context->getConnection ();
        $this->tablename = $tablename;
        $this->scope = $scope;
        $this->hasStringTable = $hasStringTable;

        if (false === $this->db)
            {
            echo "No connection";
            exit();
            }
        }

    public function getLanguage ()
        {
        if (empty ($this->language))
            return $this->context->getLanguage ();

        return $this->language;
        }

    public function setLanguage ($language)
        {
        $this->language = $language;
        }

    public function areSourcesTracked ()
        {
        return $this->tracksSources;
        }

    protected function addSystemColumns ($columns, $addcreated = true, $addupdated = true, $addsource = NULL)
        {
        if (false === $columns)
            return false;

        if (NULL === $addsource)
            $addsource = $this->tracksSources;

        if ($addsource)
            {
            array_push ($columns, new TextColumn (self::COL_SOURCE, 250, true),
                                  new DateColumn (self::COL_SOURCEDATE, true));
            }
        if ($addcreated)
            {
            array_push ($columns, new CreatedOnColumn (self::COL_CREATEDON),
                                  new IntColumn (self::COL_CREATEDBY));
            }
        if ($addupdated)
            {
            array_push ($columns, new UpdatedOnColumn (self::COL_UPDATEDON),
                                  new IntColumn (self::COL_UPDATEDBY, true));
            }

        return $columns;
        }

    public function getTableName ()
        {
        return "{$this->scope}_{$this->tablename}";
        }

    public function getStringTableName ()
        {
        if (!$this->hasStringTable)
            return NULL;
        return "{$this->scope}l_{$this->tablename}";
        }

    public function getRevisionTableName ()
        {
        if (!$this->tracksRevisions)
            return NULL;
        return "{$this->scope}_{$this->tablename}_rev";
        }

    protected abstract function getColumns ();

    protected function getTranslatableColumns ()
        {
        return NULL;
        }

    protected function getAllColumns ()
        {
        return $this->addSystemColumns ($this->getColumns ());
        }

    protected function getIndexes ()
        {
        return NULL;
        }

    protected function columnNameToDefinitionMap ($columnDefinitions)
        {
        $nameToDefinition = array ();
        for ($i = 0; $i < count ($columnDefinitions); $i++)
            {
            $col = $columnDefinitions[$i];
            $nameToDefinition[$col->name] = $col;
            }
        return $nameToDefinition;
        }

    protected function columnsFromNames ($names, $availableColumns)
        {
        $columns = array();
        for ($i = 0; $i < count ($names); $i++)
            {
            for ($c = 0; $c < count ($availableColumns); $c++)
                {
                if ($availableColumns[$c]->name == $names[$i])
                    {
                    $columns[] = $availableColumns[$c];
                    break;
                    }
                }
            }

        return $columns;
        }

    public function getPrimaryIndexColumns ($useAnyUniqueIndex = false)
        {
        // if there is an autoincrement column, it will be used as primary index
        $columns = $this->getColumns ();
        for ($i = 0; $i < count ($columns); $i++)
            {
            if ($columns[$i] instanceof AutoincrementColumn)
                {
                return array (new IntColumn ($columns[$i]->name));
                }
            }

        // search for a primary index
        $indexes = $this->getIndexes ();
        $primary = $unique = NULL;
        for ($i = 0; $i < count ($indexes); $i++)
            {
            if ($indexes[$i] instanceof PrimaryIndex)
                $primary = $indexes[$i];
            else if ($useAnyUniqueIndex && $indexes[$i] instanceof UniqueIndex)
                $unique = $indexes[$i];
            }

        if (empty ($primary))
            $primary = $unique;

        if (!empty ($primary))
            return $this->columnsFromNames ($primary->columns, $columns);

        return NULL;
        }

    public function tableExists ()
        {
        return $this->db->tableExists ($this->getTableName ());
        }

    public function createTable ()
        {
        if ($this->db->tableExists ($this->getTableName ()))
            {
            $this->context->addError ("Table already exists");
            return false;
            }
        
        return $this->forceCreateTable ();
        }

    protected function forceCreateTable ()
        {
        $columns = $this->getAllColumns ();
        $translatableColumns = $this->getTranslatableColumns ();
        if ($this->hasStringTable && !empty ($translatableColumns))
            {
            foreach ($translatableColumns as $coldef)
                {
                if ($coldef instanceof LongTextColumn)
                    continue;
                $newColDef = clone $coldef;
                $newColDef->name = self::LNG_PREFIX.$coldef->name;
                $columns[] = $newColDef;
                }
            }

        $indexes = $this->getIndexes ();
        if (false === $indexes)
            return false;

        if (!$this->db->createTable ($this->getTableName (), $columns))
            return false;

        for ($i = 0; $i < count ($indexes); $i++)
            {
            $index = $indexes[$i];
            if ($index->translatableTable)
                continue;
            if (!$this->db->addIndex ($this->getTableName (), $i+1, $index))
                return false;
            }

        if ($this->hasStringTable)
            {
            if (false === $this->createStringTable ($indexes))
                return false;
            }
        if ($this->tracksRevisions)
            {
            if (false === $this->createRevisionTable ())
                {
                $this->context->addMessage ("Revision table already exists");
                }
            }

        return true;
        }

    protected function addTableIndex ($index)
        {
        if ($index->translatableTable)
            {
            $index = clone $index;
            if (!($index instanceof FullTextIndex))
                $index->columns[] = self::COL_LANG;
            $tableName = $this->getStringTableName ();
            }
        else
            $tableName = $this->getTableName (); 

        if (!$this->db->addIndex ($tableName, 0, $index))
            return false;
        return true;
        }

    protected function dropTableIndex ($index)
        {
        if ($index->translatableTable)
            $tableName = $this->getStringTableName ();
        else
            $tableName = $this->getTableName ();

        if (false === $this->db->dropIndex ($tableName, $index->name))
            return false;
        return true;
        }

    protected function createStringTable ($indexes = NULL)
        {
        if (NULL === $indexes)
            {
            $indexes = $this->getIndexes ();
            if (false === $indexes)
                return false;
            }

        $indexColumns = $this->getPrimaryIndexColumns ();
        $indexColumns[] = new TextColumn (self::COL_LANG, 5);

        $textcolumns = array_merge ($indexColumns, $this->getTranslatableColumns ());
        $textcolumns = $this->addSystemColumns ($textcolumns, false, true, false);
        if (!$this->db->createTable ($this->getStringTableName (), $textcolumns))
            return false;

        $index = array();
        foreach ($indexColumns as $col)
            $index[] = $col->name;

        if (false === $this->db->addIndex ($this->getStringTableName (), 0, new PrimaryIndex ($index)))
            return false;

        for ($i = 0; $i < count ($indexes); $i++)
            {
            $index = $indexes[$i];
            if (!$index->translatableTable)
                continue;
            $idx = clone $index;
            if (!($index instanceof FullTextIndex))
                $idx->columns[] = self::COL_LANG;

            if (!$this->db->addIndex ($this->getStringTableName (), $i+1, $idx))
                return false;
            }

        return true;
        }

    protected function getRevisionTableColumns ($addId)
        {
        $allColumns = $this->getColumns ();
        $columns = array();

        foreach ($allColumns as $col)
            {
            if ($col instanceof AutoincrementColumn)
                $columns[] = new IntColumn ($col->name);
            else
                $columns[] = $col;
            }

        if ($this->hasStringTable)
            {
            $columns[] = new TextColumn (self::COL_LANG, 5);
            $columns = array_merge ($columns, $this->getTranslatableColumns ());
            }

        $columns = $this->addSystemColumns ($columns, false, true);
        if ($addId)
            {
            $isRevActive = new BoolColumn (self::COL_REVISION_ACTIVE);
            $isRevActive->defaultValue = false;
            $additionalColumns = array (new AutoincrementColumn (self::COL_REVISIONID),
                                        $isRevActive);
            $columns = array_merge ($additionalColumns, $columns);
            }
        return $columns;
        }

    protected function createRevisionTable ()
        {
        $columns = $this->getRevisionTableColumns (true);
        if (!$this->db->createTable ($this->getRevisionTableName (), $columns))
            return false;

        $indexColumns = $this->getPrimaryIndexColumns ();
        $index = array();
        foreach ($indexColumns as $col)
            $index[] = $col->name;

        return $this->db->addIndex ($this->getRevisionTableName (), 1, new Index ($index));
        }

    protected function dropTable ($accessScope, $accessTable)
        {
        $accessRow = UsersTable::getAccess ($this->context, $this->context->getCurrentUser (), $accessScope, $accessTable);
        if (!$accessRow || !$accessRow["candelete"])
            {
            $this->log ("No table delete access (".get_class ($this).")");
            return false;
            }

        if (false === $this->db->dropTable ($this->getTableName ()))
            return false;

        if ($this->hasStringTable)
            return $this->db->dropTable ($this->getStringTableName ());
        return true;
        }

    public function deleteTable ()
        {
        if (!defined ("DELETE_TABLE_ALLOWED") || !DELETE_TABLE_ALLOWED)
            {
            $this->log ("Cannot delete table (".get_class ($this).")");
            return false;
            }

        return $this->dropTable ($this->scope, Constants::ANY);
        }

    public function dropColumn ($columnName)
        {
        if (!$this->canDelete ())
            {
            $this->log ("No drop table access (".get_class ($this).")");
            return false;
            }

        $tableName = $this->getTableName ();
        if ($this->hasStringTable)
            {
            $namesToTextColumns = $this->columnNameToDefinitionMap ($this->getTranslatableColumns ());
            if (NULL != $namesToTextColumns && isset ($namesToTextColumns[$columnName]))
                {
                if (!$namesToTextColumns[$columnName] instanceof LongTextColumn &&
                    false === $this->db->dropColumn ($tableName, self::LNG_PREFIX.$columnName))
                    {
                    return false;
                    }

                $tableName = $this->getStringTableName ();
                }
            }

        if ($this->tracksRevisions && false === $this->db->dropColumn ($this->getRevisionTableName (), $columnName))
            return false;

        return $this->db->dropColumn ($tableName, $columnName);
        }

    protected function addColumnToTable ($coldef, $translatable)
        {
        if (!$this->hasStringTable && $translatable)
            {
            // need to create a table
            $this->hasStringTable = true;
            return $this->createStringTable ();
            }

        $table = $translatable ? $this->getStringTableName () : $this->getTableName ();
        if (false === $this->db->addColumn ($table, $coldef) ||
            ($this->tracksRevisions && false === $this->db->addColumn ($this->getRevisionTableName (), $coldef)))
            {
            return false;
            }

        if ($translatable && !$coldef instanceof LongTextColumn)
            {
            $coldef->name = self::LNG_PREFIX.$coldef->name;
            if (false === $this->db->addColumn ($this->getTableName (), $coldef))
                return false;
            }

        return true;
        }

    protected function insertOrUpdateRecord ($nameToValue)
        {
        if ($this->tracksRevisions || $this->hasStringTable || !$this->canEdit () || !$this->canCreate ())
            {
            $this->log ("Insert or update statement cannot be executes if tracks revisions, has language strings or no edit+create access (".get_class ($this).")");
            $this->context->addError ("No access");
            return false;
            }

        return $this->insertRecordInternal ($nameToValue, true);
        }

    public function insertRecord ($nameToValue)
        {
        if (!$this->canCreateInstance ($nameToValue))
            {
            $this->log ("No create access (".get_class ($this).")");
            $this->context->addError ("No create access");
            return false;
            }

        return $this->insertRecordInternal ($nameToValue, false);
        }

    private function insertRecordInternal ($nameToValue, $updateOnDuplicate)
        {
        $prepared = $this->prepareStoredValues ($nameToValue);
        if (false === $prepared)
            return false;

        list ($initialValues, $initialLngValues) = $prepared;
        $revisionTableValues = $initialValues;

        $intColumn = new IntColumn (self::COL_CREATEDBY);
        $initialValues[self::COL_CREATEDBY] = $intColumn->formatValueForDB ($this->context, $this->context->getCurrentUser ());
        
        if (!empty ($initialLngValues))
            {
            $namesToTextColumns = $this->columnNameToDefinitionMap ($this->getTranslatableColumns ());

            foreach ($initialLngValues as $name => $val)
                {
                if (!$namesToTextColumns[$name] instanceof LongTextColumn)
                    $initialValues[self::LNG_PREFIX.$name] = $val;
                }
            }

        $updateValues = NULL;
        if ($updateOnDuplicate)
            {
            $updateValues = $initialValues;
            $updateValues[self::COL_UPDATEDBY] = $initialValues[self::COL_CREATEDBY];
            $updateValues[self::COL_UPDATEDON] = "CURRENT_TIMESTAMP";
            unset ($updateValues[self::COL_CREATEDBY]);

            $primaryIndex = $this->getPrimaryIndexColumns (true);
            $nameToColumns = $this->columnNameToDefinitionMap ($this->getColumns ());
            if (count ($primaryIndex) == 1 && $nameToColumns[$primaryIndex[0]->name] instanceof AutoincrementColumn)
                {
                $updateValues = NULL; // cannot add "ON DUPLICATE UPDATE" if autoincrement id is used
                }
            else
                {
                for ($i = 0; $i < count ($primaryIndex); $i++)
                    unset ($updateValues[$primaryIndex[$i]->name]);
                }
            }

        $id = $this->db->insertOrUpdateRecord ($this->getTableName (), $initialValues, $updateValues);
        
        $insertToLanguageTable = ($this->hasStringTable && count ($initialLngValues) > 0);

        if (false === $id || (!$insertToLanguageTable && !$this->tracksRevisions))
            return $id;

        $primaryIndex = $this->getPrimaryIndexColumns ();
        $nameToColumns = $this->columnNameToDefinitionMap ($this->getColumns ());
        if (count ($primaryIndex) == 1 && $nameToColumns[$primaryIndex[0]->name] instanceof AutoincrementColumn)
            {
            $initialLngValues[$primaryIndex[0]->name] = $primaryIndex[0]->formatValueForDB ($this->context, $id);
            }
        else
            {
            for ($i = 0; $i < count ($primaryIndex); $i++)
                {
                $initialLngValues[$primaryIndex[$i]->name] = $initialValues[$primaryIndex[$i]->name];
                }
            }

        $initialLngValues[self::COL_UPDATEDBY] = $initialValues[self::COL_CREATEDBY];
        $initialLngValues[self::COL_UPDATEDON] = "CURRENT_TIMESTAMP";

        if ($insertToLanguageTable)
            {
            $textColumn = new TextColumn (self::COL_LANG, 5);
            $initialLngValues[self::COL_LANG] = $textColumn->formatValueForDB ($this->context, $this->getLanguage ());

            if (false === $this->db->insertRecord ($this->getStringTableName (), $initialLngValues))
                return false;
            }

        if ($this->tracksRevisions)
            {
            $revisionTableValues[self::COL_REVISION_ACTIVE] = 1;
            $revisionTableValues = array_merge ($revisionTableValues, $initialLngValues);
            if (false === $this->db->insertRecord ($this->getRevisionTableName (), $revisionTableValues))
                return false;
            }

        return $id;
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = 1)
        {
        if (!$this->canEdit ())
            {
            $this->log ("No edit access (".get_class ($this).")");
            $this->context->addError ("No edit access");
            return false;
            }

        $indexColumns = $this->getPrimaryIndexColumns (true);
        $idColumnNames = array ();
        for ($i = 0; $i < count ($indexColumns); $i++)
            $idColumnNames[] = $indexColumns[$i]->name;

        for ($i = 0; $i < count ($criteria); $i++)
            {
            if (!$criteria[$i] instanceof EqCriterion)
                continue;

            $idx = array_search ($criteria[$i]->field, $idColumnNames);
            if (false === $idx)
                continue;

            $idCriteria[] = $criteria[$i];
            unset ($idColumnNames[$idx]);
            if (empty ($idColumnNames))
                break;
            }

        if (!empty ($indexColumns) && empty ($idColumnNames))
            return $this->updateById ($idCriteria, $criteria, $nameToValue);

        $resultColumns = array ();
        if (empty ($indexColumns))
            $indexColumns = $this->getAllColumns ();

        foreach ($indexColumns as $idx)
            $resultColumns[] = $idx->name;

        $idRows = $this->selectBy ($resultColumns, $criteria);
        if (false === $idRows)
            return false;

        if (empty ($idRows))
            return 0; // nothing to update

        if (NULL !== $maxRows && count ($idRows) > $maxRows)
            {
            $this->context->addError ("Too many rows to update");
            return false;
            }

        for ($row = 0; $row < count ($idRows); $row++)
            {
            $idCriteria = array();
            for ($c = 0; $c < count ($indexColumns); $c++)
                {
                $val = $idRows[$row][$indexColumns[$c]->name];
                if (NULL === $val)
                    $idCriteria[] = new IsNullCriterion ($indexColumns[$c]->name);
                else
                    $idCriteria[] = new EqCriterion ($indexColumns[$c]->name, $val);
                }

            if (empty ($idCriteria))
                {
                print ("Data update which potentially can lead to data loss. Report your administrator.");
                exit ();
                }

            if (1 != $this->updateById ($idCriteria, $idCriteria, $nameToValue))
                return false;
            }

        return count ($idRows);
        }

    protected function alterColumnValue ($criteria, $column, $alterBy)
        {
        if (!$this->canEdit ())
            {
            $this->log ("No edit access (".get_class ($this).")");
            return false;
            }

        $cols = $this->getAllColumns ();
        $formattedCriteria = $this->preprocessValues ($criteria, $cols);
        return $this->db->alterColumnValue ($this->getTableName (), $column, $formattedCriteria, $alterBy);
        }

    protected function prepareStoredValues ($nameToValue)
        {
        $initialValues = array ();
        $initialLngValues = NULL;

        $allColumns = $this->addSystemColumns ($this->getColumns (), false, false);
        $nameToColumns = $this->columnNameToDefinitionMap ($allColumns);
        if ($this->hasStringTable)
            {
            $namesToTextColumns = $this->columnNameToDefinitionMap ($this->getTranslatableColumns ());
            $initialLngValues = array ();
            }

        $adjustedValues = $nameToValue;
        foreach ($nameToValue as $name => $val)
            {
            $columnDef = NULL;
            if (isset ($nameToColumns[$name]))
                {
                $columnDef = $nameToColumns[$name];
                if (!$columnDef instanceof GhostColumn)
                    continue;
                }
            else if (!empty ($namesToTextColumns) && isset ($namesToTextColumns[$name]))
                {
                $columnDef = $namesToTextColumns[$name];
                if (!$columnDef instanceof GhostColumn)
                    continue;
                }
            else
                continue;

            $val = $adjustedValues[$name];
            unset ($adjustedValues[$name]);
            $columnDef->adjustStoredValues ($adjustedValues, $val);
            }

        foreach ($adjustedValues as $name => $val)
            {
            $validValue = true;
            $columnDef = NULL;
            if (isset ($nameToColumns[$name]))
                {
                if ($nameToColumns[$name] instanceof GhostColumn)
                    continue;
                $columnDef = $nameToColumns[$name];
                $initialValues[$name] = $columnDef->formatValueForDB ($this->context, $val);
                }
            else if (!empty ($namesToTextColumns) && isset ($namesToTextColumns[$name]))
                {
                if ($namesToTextColumns[$name] instanceof GhostColumn)
                    continue;
                $columnDef = $namesToTextColumns[$name];
                $initialLngValues[$name] = $columnDef->formatValueForDB ($this->context, $val);
                }
            else
                $validValue = $this->getText ("Field [_0] not found.", $name);

            if (!empty ($columnDef))
                $validValue = $columnDef->isValueValid ($this->context, $val);
            if (true === $validValue)
                continue;

            if (false === $validValue)
                $error = $this->getText ("invalid value entered for a field [_0].", $columnDef->getLabel ());
            else
                $error = $validValue;

            $this->context->addErrorPrepared ($error);
            return false;
            }

        return array ($initialValues, $initialLngValues);
        }

    protected function updateById ($idCriteria, $criteria, $nameToValue, $tracksRevisions = NULL)
        {
        if (NULL === $tracksRevisions)
            $tracksRevisions = $this->tracksRevisions;

        $prepared = $this->prepareStoredValues ($nameToValue);
        if (false === $prepared)
            return false;

        list ($initialValues, $initialLngValues) = $prepared;

        $hasMainTableChanges = count ($initialValues) > 0;
        $updatedByColumn = new IntColumn (self::COL_UPDATEDBY);
        if ($hasMainTableChanges || $tracksRevisions)
            {
            $initialValues[self::COL_UPDATEDBY] = $updatedByColumn->formatValueForDB ($this->context, $this->context->getCurrentUser ());
            $initialValues[self::COL_UPDATEDON] = "CURRENT_TIMESTAMP";
            }

        $cols = $this->getAllColumns ();
        $namesToColumns = $this->columnNameToDefinitionMap ($cols);
        $namesToTextColumns = $this->columnNameToDefinitionMap ($this->getTranslatableColumns ());

        $formattedCriteria = $this->preprocessValues ($criteria, $namesToColumns, $namesToTextColumns, true);

        if ($tracksRevisions)
            {
            // first try updating revision table
            $revisionId = $this->copyRevision ($idCriteria);
            if (false === $revisionId)
                return false;

            $revisionTableCriteria = array_merge ($formattedCriteria, array(new EqCriterion (self::COL_REVISIONID, $revisionId)));
            $revisionTableValues = array ();

            if ($hasMainTableChanges)
                $revisionTableValues[self::COL_REVISION_ACTIVE] = 1;

            if ($this->hasStringTable)
                {
                $textColumn = new TextColumn (self::COL_LANG, 5);
                $formattedLanguage = $textColumn->formatValueForDB ($this->context, $this->getLanguage ());
                $revisionTableValues[self::COL_LANG] = $formattedLanguage;
                }

            $revisionTableValues = array_merge ($initialValues, $revisionTableValues);
            $affected = $this->db->updateRecord ($this->getRevisionTableName (), $revisionTableCriteria, $revisionTableValues);
            if (1 !== $affected)
                {
                if (0 == $affected)
                    $this->context->addError ("Failed to merge changes as someone have already changed same fields.");
                return false;
                }
            }

        if (!empty ($initialLngValues))
            {
            foreach ($initialLngValues as $name => $val)
                {
                if (!empty ($val) && !$namesToTextColumns[$name] instanceof LongTextColumn)
                    {
                    $initialValues[self::LNG_PREFIX.$name] = $val;
                    }
                }
            }

        if (empty ($initialValues))
            $c = 1;
        else
            $c = $this->db->updateRecord ($this->getTableName (), $formattedCriteria, $initialValues);

        if (false === $c)
            return $c;

        $cL = $c;
        if ($this->hasStringTable && count ($initialLngValues) > 0)
            {
            foreach ($criteria as &$cri)
                $cri->reset ();

            $lngCriteria = $this->preprocessValues ($criteria, $namesToColumns, $namesToTextColumns, false);
            foreach ($idCriteria as $cri)
                $lngCriteria[] = $cri;
            $textColumn = new TextColumn (self::COL_LANG, 5);
            $formattedLanguage = $textColumn->formatValueForDB ($this->context, $this->getLanguage ());
            $lngCriteria[] = new EqCriterion (self::COL_LANG, $formattedLanguage);

            if ($tracksRevisions)
                {
                $revisionTableCriteria = array_merge ($this->preprocessValues ($criteria, $namesToColumns, $namesToTextColumns, false),
                                                      $this->preprocessValues ($idCriteria, $namesToColumns, $namesToTextColumns, true));
                $revisionTableCriteria[] = new EqCriterion (self::COL_REVISIONID, $revisionId);
                $revisionTableValues = array_merge ($initialLngValues, array (self::COL_REVISION_ACTIVE => 1, self::COL_LANG => $formattedLanguage));
    
                $affected = $this->db->updateRecord ($this->getRevisionTableName (), $revisionTableCriteria, $revisionTableValues);
                if (1 !== $affected)
                    {
                    $failed = true;
                    if (0 === $affected)
                        {
                        // check if all the values already there
                        $targetRows = $this->db->selectBy ($this->getRevisionTableName (), array_keys ($revisionTableValues), $revisionTableCriteria);
                        if (!empty ($targetRows))
                            {
                            $failed = false;
                            $targetRow = $targetRows[0];
                            foreach ($revisionTableValues as $key => $val)
                                {
                                if ("null" == $val)
                                    $val = NULL;
                                else if (strlen ($val) > 1 && "'" == $val[0] && "'" == $val[strlen ($val) - 1])
                                    $val = substr ($val, 1, -1);
                                    
                                if ($targetRow[$key] != $val)
                                    {
                                    $failed = true;
                                    break;
                                    }
                                }
                            }
                        }
                    if ($failed)
                        {
                        $this->context->addError ("Failed to update translatable columns. Non-translatable information is already saved. To save values translatable fields, reopen the editing window and modify fields once more.");
                        return false;
                        }
                    }
                }

            $initialLngValues[self::COL_UPDATEDBY] = $updatedByColumn->formatValueForDB ($this->context, $this->context->getCurrentUser ());
            $initialLngValues[self::COL_UPDATEDON] = "CURRENT_TIMESTAMP";

            $cL = $this->db->updateRecord ($this->getStringTableName (), $lngCriteria, $initialLngValues);
            
            if (1 != $cL)
                {
                // try inserting a value (it is possible that record for current language is not yet created)
                $primaryIndex = $this->getPrimaryIndexColumns ();
                $nameToColumns = $this->columnNameToDefinitionMap ($this->getColumns ());
                if (count ($primaryIndex) == 1 && $nameToColumns[$primaryIndex[0]->name] instanceof AutoincrementColumn)
                    {
                    $initialLngValues[$primaryIndex[0]->name] = $idCriteria[0]->value;
                    }
                else
                    {
                    for ($i = 0; $i < count ($primaryIndex); $i++)
                        {
                        $initialLngValues[$primaryIndex[$i]->name] = $idCriteria[$i]->value;
                        }
                    }

                $initialLngValues[self::COL_LANG] = $textColumn->formatValueForDB ($this->context, $this->getLanguage ());

                if (false === $this->db->insertRecord ($this->getStringTableName (), $initialLngValues))
                    return false;
                $cL = 1;
                }
            }

        return max ($c, $cL);
        }

    protected function copyRevision ($criteria)
        {
        $columns = $this->getRevisionTableColumns (false);
        $resultColumns = array ();
        foreach ($columns as $col)
            {
            if (!$col instanceof GhostColumn && self::COL_SOURCEDATE != $col->name && self::COL_SOURCE != $col->name)
                $resultColumns[] = $col->name;
            }

        $params = array (new ExcludeDefaultTranslations());
        $query = $this->createQuery ($resultColumns, $criteria, NULL, $params);
        $insertColumns = array ();
        foreach ($query->getColumns () as $col)
            {
            $insertColumns[] = $col->name;
            }

        $join = $query->getTranslatableColumnSubquery ();
        if (!empty ($join))
            {
            foreach ($join->getColumns () as $col)
                $insertColumns[] = $col->name;
            }

        $id = $this->db->insertFromQuery ($this->getRevisionTableName (), $insertColumns, $query);
        if (false === $id)
            return false;

        return $id;
        }

    public function preprocessValues ($criteria, $namesToColumns, $namesToTextColumns = NULL, $onlyMain = NULL)
        {
        $formattedCriteria = array ();
        for ($i = 0; $i < count ($criteria); $i++)
            {
            if (!($criteria[$i] instanceof SingleTableCriterion))
                {
                $formattedCriteria[] = $criteria[$i];
                continue;
                }

            if (NULL !== $onlyMain)
                {
                if ($onlyMain && $criteria[$i]->needsAnyColumn ($namesToTextColumns))
                    continue;
                if (!$onlyMain && $criteria[$i]->needsAnyColumn ($namesToColumns))
                    continue;
                }

            $criterion = $criteria[$i];
            
            if (false === $onlyMain)
                $criterion->adjustValue ($this->context, array_merge ($namesToColumns, $namesToTextColumns), null);
            else
                $criterion->adjustValue ($this->context, $namesToColumns, $namesToTextColumns);

            $formattedCriteria[] = $criterion;
            }

        return $formattedCriteria;
        }

    protected function splitColumns ($columns, $namesToTextColumns)
        {
        $mainTableColumns = array ();
        $lngTableColumns = array ();

        for ($i = 0; $i < count ($columns); $i++)
            {
            $colName = $columns[$i] instanceof NamedItem ? $columns[$i]->name : $columns[$i];

            if (isset ($namesToTextColumns[$colName]))
                $lngTableColumns[] = $columns[$i];
            else
                $mainTableColumns[] = $columns[$i];
            }

        return array ($mainTableColumns, $lngTableColumns);
        }

    // extract GROUP BY or ORDER BY columns
    protected function extractQueryParamsByClass ($queryParams, $className)
        {
        $columns = array ();
        if (empty ($queryParams))
            return $columns;

        foreach ($queryParams as $param)
            {
            if ($param instanceof $className)
                $columns = array_merge ($columns, $param->columns);
            }
        return $columns;
        }

    protected function filterGhostColumns (&$columns, $namesToDefinitions)
        {
        $initialColumns = $columns;
        $removedColumns = array ();
        for ($i = 0; $i < count ($initialColumns); $i++)
            {
            $colName = $initialColumns[$i] instanceof Column
                            ? $initialColumns[$i]->name
                            : $initialColumns[$i];

            if (!isset ($namesToDefinitions[$colName]))
                continue;

            if ($namesToDefinitions[$colName] instanceof GhostColumn)
                {
                $removedColumns[] = $namesToDefinitions[$colName];
                unset ($columns[$i]);
                }
            }

        return $removedColumns;
        }

    protected function processGroupByColumns (&$columns, $namesToDefinitions)
        {
        $ghostGroupByColumns = $this->filterGhostColumns ($columns, $namesToDefinitions);
        foreach ($ghostGroupByColumns as $col)
            {
            if (!empty ($col->triggeredBy))
                $columns = array_merge ($columns, $col->triggeredBy);
            }

        $columns = array_unique ($columns);
        }

    public function getAllResultColumns ()
        {
        $cols = $this->getAllColumns ();
        $resultColumns = array ();
        for ($i = 0; $i < count ($cols); $i++)
            array_push ($resultColumns, $cols[$i]->name);

        if ($this->hasStringTable)
            {
            $translatable = $this->getTranslatableColumns ();
            for ($i = 0; $i < count ($translatable); $i++)
                array_push ($resultColumns, $translatable[$i]->name);
            }

        return $resultColumns;
        }

    protected function preprocessQuery ($tableAlias, &$resultColumns, &$criteria, &$joins, &$queryParams, $namesToColumns)
        {
        for ($i = 0; $i < count ($resultColumns); $i++)
            {
            $col = $resultColumns[$i];
            $colName = $col instanceof NamedItem ? $col->name : $col;
            if (!isset ($namesToColumns[$colName]))
                continue;

            $columnDef = $namesToColumns[$colName];
            if (!$columnDef instanceof GhostColumn)
                continue;

            $columnDef->prepareQuery ($this, $tableAlias, $resultColumns, $criteria, $joins, $namesToColumns);
            }
        }

    /* create a subquery to use in master queries */
    public function createQuery ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL, $tableAlias = NULL)
        {
        if (!$this->canRead ())
            {
            $this->log ("No read access (".get_class ($this).")");
            return NULL;
            }

        $this->log ("Creating a query for table $this->tablename");
        $cols = $this->getAllColumns ();

        // name to columndef maps will be used later
        $namesToColumns = $this->columnNameToDefinitionMap ($cols);
        $namesToTextColumns = array ();
        if ($this->hasStringTable)
            {
            $lngColumns = $this->getTranslatableColumns ();
            $lngColumns[] = new TextColumn (self::COL_LANG, 5);
            $namesToTextColumns = $this->columnNameToDefinitionMap ($lngColumns);
            }

        $formattedCriteria = $this->preprocessValues ($criteria, $namesToColumns, $namesToTextColumns);

        if (NULL === $resultColumns)
            $resultColumns = $this->getAllResultColumns ();

        $includeAllLanguages = false;
        $excludeDefaultTranslations = false;
        $selectRevisions = false;
        $groupByGeneric = false;
        if (!empty ($queryParams))
            {
            foreach ($queryParams as $param)
                {
                if ($param instanceof IncludeAllTranslations)
                    $includeAllLanguages = true;
                else if ($param instanceof ExcludeDefaultTranslations)
                    $excludeDefaultTranslations = true;
                else if ($param instanceof SelectRevisions)
                    $selectRevisions = true;
                else if ($param instanceof GroupByAll)
                    $groupByGeneric = true;
                }
            }

        if ($selectRevisions)
            {
            $namesToColumns = array_merge ($namesToColumns, $namesToTextColumns);
            $namesToTextColumns = array ();
            }

        $this->preprocessQuery ($tableAlias, $resultColumns, $criteria, $joinedQueries, $queryParams,
                                array_merge ($namesToColumns, $namesToTextColumns));

        $mainTableColumns = $resultColumns;

        $groupBy = $this->extractQueryParamsByClass ($queryParams, "GroupBy");
        $orderBy = $this->extractQueryParamsByClass ($queryParams, "OrderBy");
        if (empty ($orderBy) && !empty ($this->defaultOrderBy))
            {
            $orderBy = $this->defaultOrderBy;
            }

        if ($groupByGeneric)
            {
            foreach ($mainTableColumns as $column)
                {
                if ($column instanceof AggregateFunction)
                    continue;

                $groupBy[] = $column;
                }
            }

        $transformations = array ();
        $ghostColumns = array ();
        $translationsJoin = NULL;
        $translatableResultColumns = array ();

        // add language table if any columns are requested
        if ($this->hasStringTable)
            {
            list($mainTableColumns, $lngTableColumns) = $this->splitColumns ($mainTableColumns, $namesToTextColumns);

            // ghost column values are not persisted to the database, so remove from result list
            // (transformations will be added later)
            $ghostColumns = $this->filterGhostColumns ($lngTableColumns, $namesToTextColumns);

            $postponedColumns = array ();
            foreach ($lngTableColumns as $key => $colname)
                {
                if ($colname instanceof Column || self::COL_LANG == $colname)
                    continue;

                if ($namesToTextColumns[$colname] instanceof LongTextColumn)
                    continue;

                $postponedColumns[$key] = $colname;
                }

            foreach ($postponedColumns as $key => $colname)
                {
                $col = new TranslatableResultColumn ($colname, $tableAlias);
                $translatableResultColumns[] = $col;
                $lngTableColumns[$key] = $col;
                }

            $joinCriteria = array ();
            $primaryIndex = $this->getPrimaryIndexColumns ();

            for ($i = 0; $i < count ($primaryIndex); $i++)
                {
                $joinCriteria[] = new JoinColumnsCriterion ($primaryIndex[$i]->name, $primaryIndex[$i]->name);
                }

            $lngColumn = new TextColumn (self::COL_LANG, 5);

            if (!$includeAllLanguages)
                {
                $lngCriteria = new JoinChildCriterion ($lngColumn->name, $this->context->getLanguage ());
                $lngCriteria->value = $lngColumn->formatValueForDB ($this->context, $lngCriteria->value);

                $joinCriteria[] = $lngCriteria;
                }
            else
                $lngTableColumns[] = self::COL_LANG;
            
            $join = new LeftOuterJoin ($this->getStringTableName (), $lngTableColumns, $joinCriteria, NULL, $namesToTextColumns);
            $join->tableAlias = $tableAlias;

            if (count ($groupBy) > 0)
                list($groupBy, $join->groupBy) = $this->splitColumns ($groupBy, $namesToTextColumns);

            $this->processGroupByColumns ($join->groupBy, $namesToTextColumns);

            if (count ($orderBy) > 0)
                {
                list($orderBy, $joinOrderBy) = $this->splitColumns ($orderBy, $namesToTextColumns);
                $join->setOrderBy ($joinOrderBy);
                }

            if (!empty ($transformations))
                $join->transformations = $transformations;

            $translationsJoin = $join;
            }

        $ghostColumns = array_merge ($ghostColumns,
                $this->filterGhostColumns ($mainTableColumns, $namesToColumns));

        if ($selectRevisions)
            {
            $tableName = $this->getRevisionTableName ();
            $formattedCriteria[] = new EqCriterion (self::COL_REVISION_ACTIVE, 1);
            }
        else
            $tableName = $this->getTableName ();

        $query = new Query ($tableName, $mainTableColumns, $formattedCriteria, $joinedQueries, $namesToColumns);
        $query->tableAlias = $tableAlias;
        $query->translationsJoin = $translationsJoin;

        foreach ($translatableResultColumns as $col)
            $col->primaryQuery = &$query;

        if (count ($groupBy) > 0)
            {
            $this->processGroupByColumns ($groupBy, $namesToColumns);
            $query->groupBy = $groupBy;
            }

        $query->setOrderBy ($orderBy);

        $query->transformations = array ();
        foreach ($ghostColumns as $col)
            {
            $col->customizeQuery ($query);
            }

        return $query;
        }

    public function selectBy ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL, $tableAlias = NULL)
        {
        $query = $this->createQuery ($resultColumns, $criteria, $joinedQueries, $queryParams, $tableAlias);
        if (empty ($query))
            return false;

        return $this->executeQuery ($query, $queryParams);
        }

    public function executeQuery ($query, $queryParams = NULL)
        {
        if (!$this->canRead ())
            {
            $this->log ("No read access (".get_class ($this).")");
            return false;
            }

        return $this->db->select ($query, $queryParams);
        }

    public function selectSingleBy ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL)
        {
        $rows = $this->selectBy ($resultColumns, $criteria, $joinedQueries, $queryParams);
        if (NULL == $rows || count ($rows) != 1)
            return NULL;

        return $rows[0];
        }

    protected function deleteBy ($criteria, $deleteTranslatable = false)
        {
        $permissionsGranted = $this->canDelete ();
        $cols = $this->getAllColumns ();
        $nameToDefinition = $this->columnNameToDefinitionMap ($cols);        
        $formattedCriteria = $formattedLngCriteria = $this->preprocessValues ($criteria, $nameToDefinition);

        if (!$permissionsGranted)
            {
            if (!$this->ownerDeleteAllowed)
                {
                $this->context->addError ("No delete access ([_0])", get_class ($this));
                return false;
                }
            $formattedCriteria[] = new EqCriterion (self::COL_CREATEDBY, $this->context->getCurrentUser ());
            }

        if ($this->tracksRevisions)
            {
            $indexColumns = $this->getPrimaryIndexColumns ();
            $columnNames = array ();
            foreach ($indexColumns as $col)
                $columnNames[] = $col->name;
            $queryColumns = $columnNames;
            array_push ($queryColumns, new ConstantColumn ($this->context->getCurrentUser ()), new ConstantColumn ("CURRENT_TIMESTAMP"), new ConstantColumn ("1"));
            array_push ($columnNames,  self::COL_UPDATEDBY, self::COL_UPDATEDON, self::COL_REVISION_ACTIVE);
            if ($this->tracksSources)
                {
                $queryColumns[] = new ConstantColumn ("'x'");
                $columnNames[] = self::COL_SOURCE;
                }

            $query = $this->createQuery ($queryColumns, $criteria);
            if (false === $this->db->insertFromQuery ($this->getRevisionTableName (), $columnNames, $query))
                return false;
            }

        $affected = $this->db->deleteBy ($this->getTableName (), $formattedCriteria);
        if (false === $affected)
            return false;

        if (!$permissionsGranted)
            {
            if ($affected < 1)
                {
                $this->context->addError ("No delete access ([_0])", get_class ($this));
                return false;
                }

            $rows = $this->db->selectBy ($this->getTableName (), array (self::COL_CREATEDBY), $criteria);
            if (!empty ($rows))
                {
                $this->context->addError ("Only the records you have created were deleted");
                return false;
                }
            }

        if ($affected > 0 && $this->hasStringTable && $deleteTranslatable)
            {
            if (false === $this->db->deleteBy ($this->getStringTableName (), $formattedLngCriteria))
                return false;
            }

        return true;
        }

    protected function extractSingleIdFromCriteria ($criteria)
        {
        if (is_numeric ($criteria))
            return $criteria;
        if (is_array ($criteria))
            $criteria = $criteria[0];
        if ($criteria instanceof EqCriterion)
            return $criteria->value;
        return $criteria;
        }

    public function lock ()
        {
        $this->db->lockTables (array ($this->getTableName (), $this->getStringTableName ()));
        }
    public function unlock ()
        {
        $this->db->unlockTables (array ($this->getTableName (), $this->getStringTableName ()));
        }

    public function deleteById ($criteria)
        {
        // only id columns are allowed
        $indexColumns = $this->getPrimaryIndexColumns ();
        if (!is_array ($criteria))
            $criteria = array ($criteria);

        if (count ($criteria) != count ($indexColumns))
            return false;
        for ($i = 0; $i < count ($criteria); $i++)
            {
            if (is_numeric ($criteria[$i]))
                $criteria[$i] = new EqCriterion ($indexColumns[$i]->name, $criteria[$i]);

            if (!($criteria[$i] instanceof EqCriterion) || $criteria[$i]->field != $indexColumns[$i]->name)
                return false;
            }

        return $this->deleteBy ($criteria, true);
        }

    protected function changeItemOrder ($commonCriteria, $idColumn, $id, $up)
        {
        // TODO: need to implement table locking
        $criteria = $commonCriteria;
        $params = array
                    (
                    new OrderBy (array (new OrderByColumn (DBTable::COL_ORDER, true, 2)))
                    );
        $rows = $this->selectBy (array ($idColumn, self::COL_ORDER), $criteria, NULL, $params);
        if (false === $rows)
            {
            $this->context->addError ("Order items not found.");
            return false;
            }

        $found = false;
        $lastRow = NULL;
        $nextIndex = 1;
        $idsToFix = array ();
        foreach ($rows as $row)
            {
            $index = $nextIndex;

            if ($row[$idColumn] == $id)
                {
                if ($up)
                    {
                    $index = $nextIndex - 1;
                    $idsToFix[$nextIndex] = $lastRow;
                    if (NULL === $lastRow)
                        {
                        $this->context->addError ("This item is already first.");
                        return false;
                        }
                    }
                else
                    {
                    $index = $nextIndex + 1;
                    $found = true;
                    }
                }
            else if (false === $found)
                {
                $lastRow = $row;
                }
            else if (true === $found)
                {
                $index = $nextIndex - 1;
                $found = NULL;
                }

            if ($index != $row[self::COL_ORDER])
                {
                $idsToFix[$index] = $row;
                }

            $nextIndex++;
            }

        if (true === $found)
            {
            $this->context->addError ("This item is already last.");
            return false;
            }

        foreach ($idsToFix as $order => $row)
            {
            $criteria = $commonCriteria;
            $criteria[] = new EqCriterion ($idColumn, $row[$idColumn]);
            $criteria[] = new EqCriterion (self::COL_ORDER, $row[self::COL_ORDER]);

            if (1 != $this->updateRecord ($criteria, array (self::COL_ORDER => $order)))
                {
                $this->context->addError ("Conflicts while changing item order.");
                return false;
                }
            }

        return true;
        }

    protected function getNextColumnValue ($column, $filterBy)
        {
        $maxCol = array (new FunctionMax ($column, "maxId"));
        $criteria = array ();

        $groupBy = array ();

        foreach ($filterBy as $column => $value)
            {
            $criteria[] = new EqCriterion ($column, $value);
            $groupBy[] = $column;
            }

        $row = $this->selectSingleBy ($maxCol, $criteria, NULL, array (new GroupBy ($groupBy)));
        if (false === $row)
            return false;

        return $row["maxId"]+1;
        }

    private function getCachedAccess ()
        {
        $user = $this->context->getCurrentUser ();
        $key = $user.":".$this->scope.":".$this->tablename;
        if (isset (self::$cachedAccess[$key]))
            return self::$cachedAccess[$key];

        self::$cachedAccess[$key] = UsersTable::getAccess ($this->context, $user, $this->scope, $this->tablename);
        return self::$cachedAccess[$key];
        }

    private function checkAccess ($accessType)
        {
        $row = $this->getCachedAccess ();
        if (false === $row)
            return false;
        return $row["can$accessType"];
        }

    public function canRead ()
        {
        return $this->checkAccess ("read");
        }

    public function canCreate ()
        {
        return $this->checkAccess ("create");
        }

    public function canCreateInstance ($namesToValues)
        {
        return $this->canCreate ();
        }

    public function canEdit ()
        {
        return $this->checkAccess ("edit");
        }

    public function canDelete ()
        {
        return $this->checkAccess ("delete");
        }

    public function ownerCanDelete ()
        {
        return $this->ownerDeleteAllowed;
        }
    }

abstract class DBTableWithPerspective extends DBTable
    {
    const COL_PERSPECTIVE = "perspective";
    private $perspective = false;
    
    protected function getPerspectiveColumn ()
        {
        return new TextColumn (self::COL_PERSPECTIVE, 24, false);
        }

    public function getPerspective ()
        {
        if (false === $this->perspective)
            return $this->context->getPerspective ();
        return $this->perspective;
        }

    public function setPerspective ($perspective)
        {
        $this->perspective = $perspective;
        }

    public function createQuery ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL, $tableAlias = NULL)
        {
        $criteria[] = new EqCriterion (self::COL_PERSPECTIVE, $this->getPerspective ());
        return parent::createQuery ($resultColumns, $criteria, $joinedQueries, $queryParams, $tableAlias);
        }

    public function insertRecord ($nameToValue)
        {
        $nameToValue[self::COL_PERSPECTIVE] = $this->getPerspective ();
        return parent::insertRecord ($nameToValue);
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = 1)
        {
        $criteria[] = new EqCriterion (self::COL_PERSPECTIVE, $this->getPerspective ());
        return parent::updateRecord ($criteria, $nameToValue, $maxRows);
        }
    }

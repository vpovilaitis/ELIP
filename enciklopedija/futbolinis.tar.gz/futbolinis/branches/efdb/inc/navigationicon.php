<?php
require_once (PATH.'inc/urlicon.php');

abstract class NavigationIcon extends IconAction
    {
    public function __construct ($component, $key, $tooltip)
        {
        parent::__construct ($component, $key, $tooltip);
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function getTemplateName ()
        {
        return "navigationicon";
        }

    public function isVisible ($row = NULL)
        {
        // not shown in actions column
        return false;
        }

    public function requiresId ()
        {
        return false;
        }

    public function getClassName ()
        {
        return $this->disabled ? "pagenavdisabled" : "pagenav";
        }
    }

class FirstPageIcon extends NavigationIcon
    {
    public function __construct ($component)
        {
        parent::__construct ($component, "first", $this->getText ("Navigate to first page"));
        if ($component->getPage () <= 0)
            $this->disabled = true;
        }

    public function execute ($request, $ids)
        {
        $this->component->gotoFirstPage ();
        return true;
        }
    }

class PreviousPageIcon extends NavigationIcon
    {
    public function __construct ($component)
        {
        parent::__construct ($component, "prev", $this->getText ("Previous"));
        if ($component->getPage () <= 0)
            $this->disabled = true;
        }

    public function execute ($request, $ids)
        {
        $this->component->gotoPreviousPage ();
        return true;
        }
    }

class NextPageIcon extends NavigationIcon
    {
    public function __construct ($component)
        {
        parent::__construct ($component, "next", $this->getText ("Next page"));
        if ($component->getPage () >= $component->getPageCount () - 1)
            $this->disabled = true;
        }

    public function execute ($request, $ids)
        {
        $this->component->gotoNextPage ();
        $this->log ("page from NextPageIcon - ".$this->component->getPage());
        return true;
        }
    }

class LastPageIcon extends NavigationIcon
    {
    public function __construct ($component)
        {
        parent::__construct ($component, "last", $this->getText ("Navigate to last page"));
        if ($component->getPage () >= $component->getPageCount () - 1)
            $this->disabled = true;
        }

    public function execute ($request, $ids)
        {
        $this->component->gotoLastPage ();
        return true;
        }
    }

class PageIcon extends URLAction
    {
    protected $pageNo;

    public function __construct ($component, $pageNo)
        {
        $url = $component->getSpecificPageUrl ($pageNo);
        parent::__construct ($component, $pageNo+1,
                             $this->getText ("Navigate to the page [_0]", $pageNo+1),
                             $url);

        $this->pageNo = $pageNo;
        if ($component->getPage () == $pageNo)
            $this->disabled = true;
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function isVisible ($row = NULL)
        {
        // not shown in actions column
        return false;
        }

    public function requiresId ()
        {
        return false;
        }

    public function execute ($request, $ids)
        {
        $this->component->setPage ($this->pageNo);
        return true;
        }

    public function getClassName ()
        {
        return $this->disabled ? "pagebuttondisabled" : "pagebutton";
        }
    }

class PageSizeIcon extends URLIcon
    {
    protected $pageSize;

    public function __construct ($component, $pageSize)
        {
        $url = $component->getContext()->getAdjustedUrl (array ($component->getParam ("pagesize") => $pageSize));
        parent::__construct ($component, $pageSize."x",
                             $this->ngettext ("Set page size to [_0] record", "Set page size to [_0] records", $pageSize),
                             $url);

        $this->pageSize = $pageSize;
        if ($component->getPageSize () == $pageSize)
            $this->disabled = true;
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function isVisible ($row = NULL)
        {
        // not shown in actions column
        return false;
        }

    public function requiresId ()
        {
        return false;
        }

    public function execute ($request, $ids)
        {
        $this->component->setPageSize ($this->pageNo);
        return true;
        }

    public function getClassName ()
        {
        return $this->disabled ? "pagenavdisabled" : "pagenav";
        }
    }

class PageSeparatorIcon extends URLAction
    {
    public function __construct ($component)
        {
        parent::__construct ($component, "...", "...", NULL);
        $this->disabled = true;
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return false;
        }

    public function isVisible ($row = NULL)
        {
        // not shown in actions column
        return false;
        }

    public function requiresId ()
        {
        return false;
        }

    public function getClassName ()
        {
        return "navigationseparator";
        }

    public function execute ($request, $ids)
        {
        return true;
        }
    }

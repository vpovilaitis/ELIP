<?php

class MultiRowEditor extends CompositeTemplate
    {
    protected $rowCount = -1;
    protected $defaultCount;
    protected $rows = NULL;
    protected $context;

    public function __construct ($context, $prefix, $key, $label, $subitems, $defaultCount)
        {
        parent::__construct ($prefix, $key, "multiroweditor", $label, $subitems);
        $this->defaultCount = $defaultCount;
        $this->context = $context;
        }

    protected function initialize ($request)
        {
        if (NULL != $this->rows)
            return;
        $this->rowCount = isset ($request[$this->prefix."count"])
                            ? $request[$this->prefix."count"] 
                            : $this->defaultCount;

        $prefix = $this->key;
        if (NULL == $prefix)
            $innerRequest = $request;
        else
            {
            $prefix .= "_";
            $innerRequest = array();
            foreach ($request as $key => $val)
                {
                // only pass the parameters of this component (prefixed)
                if (strpos ($key, $prefix) === 0)
                    {
                    $innerRequest[substr ($key, strlen ($prefix))] = $val;
                    }
                }
            }

        $this->rows = array ();

        for ($r = 0; $r < $this->rowCount; $r++)
            {
            $row = array ();
    
            for ($t = 0; $t < count ($this->items); $t++)
                {
                $value = $this->items[$t]->getValueForDB ($this->context, $innerRequest, $r);
                $row[$this->items[$t]->key] = $value;
                }
    
            $this->rows[] = $row;
            }
        }

    public function isHorizontalFlow ()
        {
        return true;
        }

    public function getTemplateName ()
        {
        return "multiroweditor";
        }

    public function preprocessLoadedValue (&$request, $existingRecord, $index = NULL)
        {
        if (!$existingRecord)
            {
            $this->initialize ($request);
            $request[$this->key] = $this->rows;
            }
        }

    public function getValueForDB ($context, $request, $index = NULL)
        {
        $this->initialize ($request);
        return $this->rows;
        }

    public function getValues ()
        {
        return $this->rows;
        }

    public function getTemplate ()
        {
        return $this->items;
        }

    public function getRowCount ()
        {
        return $this->rowCount;
        }
    }

?>
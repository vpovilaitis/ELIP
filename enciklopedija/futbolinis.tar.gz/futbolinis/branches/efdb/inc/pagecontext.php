<?php

require_once (PATH.'inc/base.php');
require_once (PATH.DEFAULT_DB_CLASS_INC);

class PageContext extends Base
    {
    public $title;
    private $titleHidden;
    private $menuHidden;
    public $footerLabel;
    public $charset = PAGE_CHARSET;

    private $lng = NULL;

    private static $singleton = NULL;

    private $skin = NULL;

    public $request;
    private $dbconnection;
    private $texts = NULL;
    private $user = NULL;
    private $stylesheets = array ("common");
    private $scriptFiles = array ();
    private $errorsTarget;
    private $settings = NULL;
    private $pageMetaData = array ();
    private $perspective;
    private $initializeScripts = NULL;
    private $quickLinksTable = NULL;
    private $shortSession = true;
    private $renderMode = self::RENDER_FULL;

    const LOGIN_SESSION = "uusseerr";
    const LOGIN_USERID = "userid";

    const RENDER_FULL = "full";
    const RENDER_INLINE = "inline";

    private function __construct ($request, $shortSession = true)
        {
        $this->request = $this->preprocessRequest ($request);
        if (!empty ($this->request[Constants::PARAM_RENDER_MODE]))
            $this->renderMode = $this->request[Constants::PARAM_RENDER_MODE];

        $className = DEFAULT_DB_CLASS;

        $this->dbconnection = new $className ($this);
        $this->shortSession = $shortSession;
        if (!$shortSession)
            session_start ();

        $this->log ("Current language - ".$this->getLanguage());
        $this->switchTextDomain (Constants::TEXTDOMAIN, $this->getLanguage());
        }

    public function getSessionParams ($keys)
        {
        if (!is_array ($keys))
            $keys = array ($keys);
        if ($this->shortSession)
            session_start ();
        $result = array ();
        foreach ($keys as $key)
            {
            if (array_key_exists ($key, $_SESSION))
                $result[$key] = $_SESSION[$key];
            else
                $result[$key] = null;
            }
        if ($this->shortSession)
            session_write_close(); 
        return $result;
        }

    public function setSessionParams ($pairs)
        {
        if ($this->shortSession)
            session_start ();
        foreach ($pairs as $key => $val)
            {
            if (NULL === $val)
                unset ($_SESSION[$key]);
            else
                $_SESSION[$key] = $val;
            }
        if ($this->shortSession)
            session_write_close(); 
        }

    function getFooter ()
        {
        $this->footerLabel = $this->getValue (SiteSettings::SITE_FOOTER);
        if (empty ($this->footerLabel))
            $this->footerLabel = $this->getText ("A new Futbolinis-based project.");
        return $this->footerLabel;
        }

    function getHeaderSubtitle ()
        {
        return $this->getValue (SiteSettings::SITE_SUBTITLE);
        }

    function __destruct ()
        {
        $this->flushLog ();
        }

    public static function getInstance ($request = NULL)
        {
        if (NULL == self::$singleton)
            {
            if (!defined ("PAGECONTEXTCLASS"))
                {
                print "PAGECONTEXTCLASS not defined. Exiting.";
                exit ();
                }
            $class = PAGECONTEXTCLASS;
            self::$singleton = new $class ($request, !defined ("SHORT_CONTEXT") || SHORT_CONTEXT);
            }
        return self::$singleton;
        }

    public function initializeTexts ($textdomain, $title)
        {
        $this->switchTextDomain ($textdomain, $this->getLanguage());

        if (NULL != $title)
            $this->setTitle (gettext ($title));
        }

    public function setTitle ($title)
        {
        $siteTitle = $this->getValue (SiteSettings::SITE_TITLE);
        if (!empty ($siteTitle))
            $this->title = formatText ($this->getText ("[_0] - [_1]"), $siteTitle, $title);
        else
            $this->title = $title;
        }

    public function setTitleHidden ($isHidden)
        {
        $this->titleHidden = $isHidden;
        }

    public function getTitleHidden ()
        {
        return $this->titleHidden;
        }

    public function setMenuHidden ($isHidden)
        {
        $this->menuHidden = $isHidden;
        }
    public function getMenuHidden ()
        {
        return $this->menuHidden;
        }

    public function getBaseUrl ()
        {
        $base = defined ("BASE_URL") ? BASE_URL : "";
        if (!empty ($base))
            return $base;

        return NULL;
        }

    public function getInlineContentUrl ($url)
        {
        $url .= (false === strchr ($url, "?")) ? "?" : "&";
        if (!empty ($_REQUEST["_purge"]))
            $url .= "_purge=".$_REQUEST["_purge"]."&";
        return $this->processUrl ($url.Constants::PARAM_RENDER_MODE."=".PageContext::RENDER_INLINE, true);
        }

    public function processUrl ($url, $relative = false, $lng = NULL)
        {
        $url .= (false === strchr ($url, "?")) ? "?" : "&";
        if ($relative)
            {
            $base = defined ("BASE_URL") ? BASE_URL : "";
            if (!empty ($base))
                $url = trim ($base, "/")."/".$url;
            }

        if (NULL === $lng)
            $lng = $this->getLanguage ();
        return $url.Constants::PARAM_LANGUAGE."=$lng";
        }

    public function createContentPageUrl ($pageName)
        {
        if (defined ("FRIENDLY_URL") && FRIENDLY_URL)
            return "page/$pageName/".$this->getLanguage ();

        $url = "index.php?page=$pageName";
        return $this->processUrl ($url, false);
        }

    public function chooseUrl ($friendlyUrl, $alternateUrl, $params = NULL, $lng = NULL)
        {
        if (defined ("BASE_URL") && strlen (trim (BASE_URL, " /")) > 0)
            $basePath = trim (BASE_URL, " /")."/";
        else
            $basePath = PATH;

        if (NULL === $lng)
            $lng = $this->getLanguage ();

        if (!empty ($friendlyUrl) && defined ("FRIENDLY_URL") && FRIENDLY_URL)
            {
            $url = $basePath."$friendlyUrl/$lng";
            if (!empty ($params))
                $url .= "/".$params;
            }
        else
            {
            $url = $this->processUrl ($basePath.$alternateUrl, false, $lng);
            if (!empty ($params))
                $url .= "&".$params;
            }

        return $url;
        }


    protected function adjustUrlParams ($params, $queryStringReplacements)
        {
        $arr = array ();
        if (!empty ($params))
            parse_str ($params, $arr);

        $arr[Constants::PARAM_LANGUAGE] = $this->getLanguage ();
        $queryString = array ();

        foreach ($arr as $param => $val)
            {
            if (!array_key_exists ($param, $queryStringReplacements))
                $queryString[$param] = $val;
            }

        foreach ($queryStringReplacements as $param => $val)
            {
            if (NULL === $val) // requested to remove
                continue;
            $queryString[$param] = $val;
            }

        return $queryString;
        }

    public function getAdjustedUrl ($queryStringReplacements, $baseUrl = NULL)
        {
        if (defined ("FRIENDLY_URL") && FRIENDLY_URL)
            {
            $uri = $_SERVER['REQUEST_URI'];
            $parts = explode ("/", $uri);
            $i = 0;
            foreach ($parts as $part)
                {
                if ($part == "page" || $part == "list")
                    break;
                $i++;
                if ($part == "content" || $part == "rev")
                    break;
                }

            if ($i < count ($parts))
                {
                while (count ($parts) - $i < 4) // no params added yet
                    $parts[] = "";

                $params = $this->adjustUrlParams ($parts[$i+3], $queryStringReplacements);
                $parts[$i+2] = $params[Constants::PARAM_LANGUAGE];
                unset ($params[Constants::PARAM_LANGUAGE]);
                if (empty ($params))
                    unset ($parts[$i+3]);
                else
                    {
                    $queryString = array ();
                    foreach ($params as $param => $val)
                        $queryString[] = "$param=".urlencode ($val);
                    $parts[$i+3] = implode ("&", $queryString);
                    }

                return implode ("/", $parts);
                }
            }

        $uri = $_SERVER['SCRIPT_NAME'];
        if (false === strpos ($uri, "?"))
            {
            $str = $_SERVER['QUERY_STRING'];
            }
        else
            {
            // sometimes REQUEST_URI contains query string
            $components = @parse_url ($uri);
            $uri = $components ['path'];
            $str = $components ['query'];
            }

        $params = $this->adjustUrlParams ($str, $queryStringReplacements);

        foreach ($params as $param => $val)
            $queryString[] = "$param=".urlencode ($val);

        if (NULL == $baseUrl && defined ("BASE_URL") && strlen (trim (BASE_URL, " /")) > 0)
            $baseUrl = BASE_URL;

        if (!empty ($baseUrl))
            {
            $baseUrl = trim ($baseUrl, " /")."/";
            $uri = trim ($uri, "/");
            $lastSep = strrchr ($uri, "/");
            if (false !== $lastSep)
                $uri = substr ($lastSep, 1);
            }

        if (!empty ($queryString))
            $uri .= "?".implode ("&", $queryString);

        if (NULL != $baseUrl)
            return $baseUrl.$uri;

        return PATH.$uri;
        }

    public function getLanguage ()
        {
        if (!empty ($this->lng))
            return $this->lng;

        if (!empty ($this->request[Constants::PARAM_LANGUAGE]))
            $this->lng = $this->request[Constants::PARAM_LANGUAGE];
        else if (defined ("DEFAULT_LANGUAGE"))
            $this->lng = DEFAULT_LANGUAGE;

        if (defined ("DEFAULT_LANGUAGE"))
            {
            $languages = $GLOBALS["Languages"];
            if (!empty ($languages))
                {
                $found = false;
                foreach ($languages as $language)
                    {
                    if ($language->code == $this->lng)
                        {
                        $found = true;
                        break;
                        }
                    }
                if (!$found)
                    $this->lng = DEFAULT_LANGUAGE;
                }
            }

        return $this->lng;
        }

    public function getLanguageCode ()
        {
        $lng = $this->getLanguage ();
        if (strlen ($lng) <= 2)
            return $lng;
        return substr ($lng, 0, 2);
        }

    public function setFormActionUrl ($url)
        {
        $this->formUrl = $url;
        }
        
    public function getFormActionUrl ()
        {
        if (!empty ($this->formUrl))
            return $this->formUrl;

        $url = $_SERVER["SCRIPT_NAME"];
        if (!empty ($_SERVER["QUERY_STRING"]))
            $url .= "?".htmlentities ($_SERVER["QUERY_STRING"]);
        return $url;
        }

    private function getQuickLinksTable ()
        {
        if (empty ($this->quickLinksTable) && $this->getConnection () && class_exists ("QuickLinksTable"))
            $this->quickLinksTable = new QuickLinksTable ($this);
        return $this->quickLinksTable;
        }
    public function getQuickLinks ()
        {
        $rows = QuickLinksTable::getAllLinks ($this);
        return $rows;
        }

    public function getMetroLinks ()
        {
        $result = array ();
        foreach (array (
                    array ('metro-home.png',   $this->getText ("Home|menu"),       HOME_PAGE, $this->getText ("Return to starting page")),
                    array ('metro-hour.png',   $this->getText ("Today|menu"),      'today',   $this->getText ("All important information of today football")),
                    array ('metro-history.png',$this->getText ("History|menu"),    'history', $this->getText ("Dive into history of competitions")),
                    array ('metro-stats.png',  $this->getText ("Statistics|menu"), 'stats',   $this->getText ("Statistical view of the current and historical data")),
                    array ('metro-note.png',   $this->getText ("Editor zone|menu"),'editors', $this->getText ("Join the editors and help collect and sort out the information")),
                    array ('metro-dice.png',   $this->getText ("Predictor|menu"),  'toto',    $this->getText ("Match predictor")),
                    array ('metro-about.png',  $this->getText ("About us|menu"),   'about',   $this->getText ("Information about the project, contacts")),
                    )
                    as $params)
            {
            $page = $params[2];
            $result[] = array ('img' => $this->getResourcePath ("img", $params[0]),
                               'name' => $params[1],
                               'url' => $this->chooseUrl ("page/$page", "index.php?page=$page"),
                               'tooltip' => $params[3], );
            }
        return $result;
        }

    protected $loginSuggested = false;
    public function suggestLogin ()
        {
        if ($this->getCurrentUser () > 0)
            return;

        $this->loginSuggested = true;
        }
    public function isLoginSuggested ()
        {
        return $this->loginSuggested;
        }

    public function canEditLinks ()
        {
        $dbtable = $this->getQuickLinksTable();
        return !empty ($dbtable) && $dbtable->canEdit ();
        }

    public function canCreateLinks ()
        {
        $dbtable = $this->getQuickLinksTable();
        return !empty ($dbtable) && $dbtable->canCreate ();
        }

    public function getLinkEditText ()
        {
        return $this->getText ("Edit menu");
        }

    public function getExitLinkEditorText ()
        {
        return $this->getText ("Exit editor|link editor");
        }

    public function getLoadingText ()
        {
        return $this->getText ("Loading...");
        }

    public function getLinkActionsService ()
        {
        return $this->processUrl ("index.php?service=QuickLinkService&action=enumerate", true);
        }

    public function getConnection ()
        {
        if (!defined ("DB_HOST"))
            return false;

        $fullhost = DB_HOST;
        
        if (defined ("DB_SOCKET") && strlen (DB_SOCKET) > 0)
            {
            $fullhost .= ":".DB_SOCKET;
            }
        else if (defined ("DB_PORT") && strlen (DB_PORT) > 0)
            $fullhost .= ":".DB_PORT;

        if (!$this->dbconnection->connected () &&
            !$this->dbconnection->connect ($fullhost, DB_NAME, DB_USER, DB_PASS))
            {
            return false;
            }

        return $this->dbconnection;
        }

    public function getSkin ()
        {
        if (NULL === $this->skin)
            {
            if (!empty ($_GET["skin"]))
                $this->skin = $_GET["skin"];
            else if (defined ("SITE_SKIN"))
                $this->skin = SITE_SKIN;
            if (empty ($this->skin))
                $this->skin = "default";
            }
        return $this->skin;
        }

    public function getCurrentUser ($checkSession = true)
        {
        if (NULL !== $this->user || !$checkSession)
            return $this->user;

        $this->user = $this->checkLoggedinUser ();
        return $this->user;
        }

    public function getSignInText ()
        {
        return $this->getText ("Sign in/out");
        }

    public function getSignInUrl ()
        {
        return $this->getInlineContentUrl ("login.php?".Constants::PARAM_RETURN_TO."=".rawurlencode($this->processUrl ("loginSuccess.html", true)), true);
        }

    public function getCurrentUserName ()
        {
        $userId = $this->getCurrentUser ();
        return NULL;
        }

    private function checkLoggedinUser ()
        {
        $this->log ("checkLoggedinUser ()");
        $session = $this->getSessionParams (self::LOGIN_USERID);
        $loggedInUser = $session[self::LOGIN_USERID];
        if ($loggedInUser > 0)
            {
            $this->log ("found $loggedInUser in session");
            return $loggedInUser;
            }

        if (!isset($_COOKIE[self::LOGIN_SESSION]) || strlen ($_COOKIE[self::LOGIN_SESSION]) <= 1)
            {
            if (empty ($this->triedForcedLogin) && !empty ($_GET["_user"]) && !empty ($_GET["_pwd"]))
                {
                $this->triedForcedLogin = true;

                if (true === $this->login ($_GET["_user"], $_GET["_pwd"], false))
                    return $this->user;
                }

            $this->resetUserSession ();
            return Constants::GUEST;
            }

        $ip = isset ($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : "-";
        $loginsTable = new UserLoginsTable ($this);

        $userID = $loginsTable->selectUser ($_COOKIE[self::LOGIN_SESSION], $ip);
        $this->log ("restored $userID from cookie");
        if ($userID > 0)
            {
            $this->initializeUserSession ($userID);
            return $userID;
            }

        $this->deleteCookie (self::LOGIN_SESSION);
        return Constants::GUEST;
        }
    
    public function login ($userName, $password, $persist = false)
        {
        $this->log ("login ($userName, ***, $persist)");
        $usersTable = new UsersTable ($this);
        $ip = isset ($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : "-";
        $user = $usersTable->login ($ip, $userName, $password, $persist);
        if (false == $user)
            return false;

        $this->user = $user->id;
        $this->initializeUserSession ($user->id);
        $this->setCookie (self::LOGIN_SESSION, $user->sessionId, $persist ? 60*LOGIN_COOKIE_EXPIRATION : 0);

        $this->log ("logged in (".print_r ($user, true).")");
        return true;
        }

    public function openIdLogin ($provider, $userName)
        {
        $dbtable = new OpenIdTable ($this);
        $userId = $dbtable->getUserId ($this, $provider, $userName);
        if ($userId <= 0)
            return false;

        $this->log ("openIdLogin ($provider, $userName)");
        $usersTable = new UsersTable ($this);
        $user = $usersTable->openIdLogin (isset ($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : "-", $userId);
        if (false == $user)
            return false;

        $this->user = $user->id;
        $this->initializeUserSession ($user->id);
        $this->setCookie (self::LOGIN_SESSION, $user->sessionId, 0);

        $this->log ("logged in (".print_r ($user, true).")");
        return true;
        }

    public function logout ()
        {
        $this->log ("logout ()");
        $usersTable = new UsersTable ($this);
        $ip = isset ($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : "-";
        $usersTable->logout ($this->user, $ip);

        $this->resetUserSession ();
        $this->deleteCookie (self::LOGIN_SESSION);
        $this->user = 0;
        return true;
        }

    public function isBlocked ()
        {
        // TODO
        return false;
        }

    public function checkAccess ($access, $scope, $table = Constants::ANY)
        {
        $row = UsersTable::getAccess ($this, $this->getCurrentUser(), $scope, $table);
        if (!$row)
            return false;
        return $row["can$access"] > 0;
        }

    public function canCreate ($scope, $table = Constants::ANY)
        {
        return $this->checkAccess ("create", $scope, $table);
        }

    public function canRead ($scope, $table = Constants::ANY)
        {
        return $this->checkAccess ("read", $scope, $table);
        }

    public function canEdit ($scope, $table = Constants::ANY)
        {
        return $this->checkAccess ("edit", $scope, $table);
        }

    public function canDelete ($scope, $table = Constants::ANY)
        {
        return $this->checkAccess ("delete", $scope, $table);
        }

    public function setCookie ($name, $value, $expires)
        {
        if (headers_sent())
            return;

        $this->log ("setCookie ($name, $value, $expires)");
        if (isset ($_COOKIE[$name]))
            {
            setcookie ($name, NULL, 0, COOKIE_PATH, COOKIE_DOMAIN);
            unset ($_COOKIE[$name]);
            }

        setcookie ($name, $value, $expires > 0 ? time() + $expires : 0, COOKIE_PATH, COOKIE_DOMAIN);
        }
    
    public function deleteCookie ($name)
        {
        if (headers_sent())
            return;

        $this->log ("deleteCookie ($name)");
        $this->setCookie ($name, '0', time() - 3600);
        }
    
    private function initializeUserSession ($userId)
        {
        $this->log ("initializeUserSession ($userId)");

        $this->setSessionParams (array (self::LOGIN_USERID => $userId));
        $this->log ("initializeUserSession - $userId");
        }

    private function resetUserSession ()
        {
        $this->log ("resetUserSession ()");

        $this->setSessionParams (array (self::LOGIN_USERID => NULL));
        }

    public function getResourcePath ($type, $filename, $includeDefault = false, $version = NULL, $returnArray = false)
        {
        if (defined ("BASE_URL") && strlen (trim (BASE_URL, " /")) > 0)
            $basePath = trim (BASE_URL, " /")."/";
        else
            $basePath = PATH;

        $ret = $returnArray ? array () : NULL;
        $searchFor = explode (",", $this->getSkin ());
        if (($includeDefault || !$returnArray) && "default" != $searchFor[count($searchFor)-1])
            $searchFor[] = "default";

        foreach ($searchFor as $skin)
            {
            $skin = trim ($skin);
            $path = "res/$skin/$type/$filename";
            if (file_exists (PATH.$path))
                {
                if (!$returnArray)
                    {
                    $ret = $basePath.$path;
                    break;
                    }

                $ret[] = $basePath.$path;
                if (!$includeDefault && !$returnArray)
                    break;
                }
            }

        if (!empty ($version))
            {
            if (is_array ($ret))
                {
                foreach ($ret as &$path)
                    $path .= "?ver=$version";
                }
            else if (!empty ($ret))
                $ret .= "?ver=$version";
            }

        return $ret;
        }

    public function getSmallIconPath ($name)
        {
        return $this->getResourcePath ("img", $name."16.png");
        }

    public function getTinyIconPath ($name)
        {
        $image = $this->getResourcePath ("img", $name."8.png");
        if (empty ($image))
            $image = $this->getSmallIconPath ($name);

        return $image;
        }

    public function getDisabledSmallIconPath ($name)
        {
        $disabledImage = $this->getResourcePath ("img", $name."16d.png");
        if (!empty ($disabledImage))
            return $disabledImage;
        return $this->getSmallIconPath ($name);
        }

    public function getDisabledTinyIconPath ($name)
        {
        $disabledImage = $this->getResourcePath ("img", $name."8d.png");
        if (!empty ($disabledImage))
            return $disabledImage;
        return $this->getTinyIconPath ($name);
        }

    public function addStyleSheet ($name)
        {
        if (false === array_search ($name, $this->stylesheets))
            $this->stylesheets[] = $name;
        }

    public function getStyleSheets ()
        {
        $paths = array ();
        if (JQUERY_THEME)
            $paths = array_merge ($this->getResourcePath ("css", JQUERY_THEME."/jquery-ui.css", DEFAULT_SKIN_CSS, CSS_VERSION, true), $paths);

        for ($i = 0; $i < count ($this->stylesheets); $i++)
            {
            $paths = array_merge ($this->getResourcePath ("css", $this->stylesheets[$i].".css", DEFAULT_SKIN_CSS, CSS_VERSION, true), $paths);
            }

        return array_reverse ($paths);
        }

    public function addScriptFile ($name)
        {
        if (false === array_search ($name, $this->scriptFiles))
            $this->scriptFiles[] = $name;
        }

    public function getScriptFiles ()
        {
        $paths = array ();
        for ($i = 0; $i < count ($this->scriptFiles); $i++)
            {
            $path = $this->getResourcePath ("js", $this->scriptFiles[$i].".js", false, SCRIPTS_VERSION);
            if (!empty ($path))
                $paths[] = $path;
            }

        if ($this->canEditLinks () || $this->canCreateLinks ())
            {
            $paths[] = $this->getResourcePath ("js", "quicklinks.js", false, SCRIPTS_VERSION);
            }

        if (!empty ($paths))
            {
            $paths[] = $this->getResourcePath ("js", "jquery.js");
            $paths[] = $this->getResourcePath ("js", "jquery-ui.js");
            }

        return $paths;
        }

    public function addError ($msg, $param1 = NULL, $param2 = NULL)
        {
        if (!empty ($this->errorsTarget))
            $this->errorsTarget->addError ($msg, $param1, $param2);
        else
            $this->log ($this->formatText ($msg, $param1, $param2));
        }

    public function addErrorPrepared ($error)
        {
        if (!empty ($this->errorsTarget))
            $this->errorsTarget->addErrorPrepared ($error);
        else
            $this->log ($error);
        }

    public function addMessage ($msg, $param1 = NULL, $param2 = NULL)
        {
        if (!empty ($this->errorsTarget))
            $this->errorsTarget->addMessage ($msg, $param1, $param2);
        }

    public function setErrorTarget ($component)
        {
        $oldTarget = $this->errorsTarget;
        $this->errorsTarget = $component;
        return $oldTarget;
        }

    public function hasErrors ()
        {
        if ($this->errorsTarget)
            {
            $errors = $this->errorsTarget->getErrors ();
            return !empty ($errors);
            }
        return false;
        }

    public function setPageScope ($scope, $contextId)
        {
        $this->pageScope = $scope;
        $this->pageContextId = $contextId;
        }
    public function getPageScope (&$scope, &$id)
        {
        $scope = $this->pageScope;
        $id = $this->pageContextId;
        }

    /* site settings */
    public function getValue ($sitesetting)
        {
        if (NULL === $this->settings)
            $this->settings = SiteSettings::get ($this);

        if (!isset ($this->settings[$sitesetting]))
            return NULL;
        return $this->settings[$sitesetting];
        }

    public function setMetaParam ($param, $val)
        {
        $this->pageMetaData[$param] = $val;
        }

    public function getMetaParams ()
        {
        $params = $this->pageMetaData;
        $retrieveFromSiteSettings = array
            (
            "Description" => SiteSettings::SITE_DESCRIPTION,
            "Author" => SiteSettings::SITE_AUTHOR_EMAIL,
            "Keywords" => SiteSettings::SITE_KEYWORDS
            );

        foreach ($retrieveFromSiteSettings as $metaName => $settingName)
            {
            if (array_key_exists ($metaName, $this->pageMetaData))
                continue;

            $val = $this->getValue ($settingName);
            if (!empty ($val))
                $params[$metaName] = $val;
            }

        if (!array_key_exists ("ROBOTS", $this->pageMetaData))
            $params["ROBOTS"] = "INDEX, FOLLOW";
        return $params;
        }

    public function parseCustomClass ($param, $dir)
        {
        $ret = findCustomHandlerFile ($this, $dir, $param);
        if (!empty ($ret))
            {
            list ($className, $file) = $ret;
            $ret = require_once ($file);
            if (false !== $ret && class_exists ($className))
                return $className;
            }

        $this->log ("Handler $param in directory $dir not found");
        return false;
        }

    private function preprocessRequestValue ($val)
        {
        if (!is_array ($val))
            return stripslashes ($val);

        $ret = array ();
        foreach ($val as $v)
            $ret[] = $this->preprocessRequestValue ($v);

        return $ret;
        }

    private function preprocessRequest ($request)
        {
        if (!get_magic_quotes_gpc ())
            return $request;

        $newRequest = array ();
        foreach ($request as $name => $val)
            $newRequest[$name] = $this->preprocessRequestValue ($val);

        return $newRequest;
        }

    public function applyFormat ($text, $encloseInParagraph = true)
        {
        $parser = new Parser ($this, $text);
        return $parser->process ($encloseInParagraph);
        }

    public function removeFormat ($text, $limit = NULL)
        {
        $parser = new Parser ($this, $text);
        return $parser->getPlainText ($limit);
        }

    public function createLinksFromText ($text)
        {
        $text = preg_replace ('/[a-zA-Z]+:\\/\\/(([.]?[a-zA-Z0-9_\\/-?&%+-])*)/', '<a href="\\0">\\0</a>', $text);

        return $text;
        }

    public function setPerspective ($perspective)
        {
        $old = $this->getPerspective ();
        $this->perspective = $perspective;
        return $old;
        }

    public function getPerspective ()
        {
        return empty ($this->perspective) ? SITE_PERSPECTIVE : $this->perspective;
        }
        
    public function formatRichText ($text)
        {
        return $this->formatRichTextWithContext ($this, $text);
        }

    public function renderInline ()
        {
        return self::RENDER_INLINE == $this->renderMode;
        }

    public function redirect ($url, $checkDebug = true)
        {
        return parent::redirect ($url, !$this->renderInline ());
        }

    public function getBackgroundColor ()
        {
        // TODO: should depend on the skin
        return array (0xff, 0xff, 0xff); // array (0xfb, 0xfd, 0xfa);
        }

    public function registerInitializeScript ($script)
        {
        $this->initializeScripts[] = $script;
        }

    public function getInitializeScripts ()
        {
        return $this->initializeScripts;
        }
    public function div ($x, $y)
        {
        return str_replace (",", ".", $x / $y);
        }

    };

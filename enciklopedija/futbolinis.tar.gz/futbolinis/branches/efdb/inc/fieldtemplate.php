<?php
require_once (PATH.'inc/general.php');

class FieldTemplate
    {
    public $key;
    public $label;
    public $type;
    public $tooltip;
    public $prefix;
    public $readonly = false;
    public $cssClass = "field";
    public $renderId = false;

    protected $initialValue = NULL;

    public function __construct ($prefix, $key, $type, $label, $tooltip)
        {
        $this->key = $key;
        $this->label = $label;
        $this->type = $type;
        $this->tooltip = $tooltip;

        $this->setPrefix ($prefix);
        }

    public function getParamName ($index = NULL)
        {
        if (NULL === $index)
            return $this->prefix.$this->key;
        else
            {
            return $this->prefix.$this->key."_$index";
            }
        }

    public function getLabel ($format = true)
        {
        if ($format)
            return trim (formatForHtml ($this->label));
        else
            return trim ($this->label);
        }

    public function getTooltip ()
        {
        return $this->tooltip;
        }

    public function getPrefix ()
        {
        return $this->prefix;
        }

    public function getIcon ($context)
        {
        return NULL;
        }

    public function setPrefix ($prefix)
        {
        $this->prefix = $prefix;
        if (!empty ($prefix))
            $this->prefix .= "_";
        }

    public function isHorizontalFlow ()
        {
        return false;
        }

    public function getDefaultValue ()
        {
        return $this->initialValue;
        }

    public function preprocessLoadedValue (&$request, $existingRecord, $index = NULL)
        {
        if (!$existingRecord && !empty ($this->initialValue))
            $request[$this->key] = $this->initialValue;
        }

    public function getValueForDB ($context, $request, $index = NULL)
        {
        if (NULL === $index)
            $key = $this->key;
        else
            $key = $this->key."_$index";

        if (isset ($request[$key]))
            return $request[$key];

        return NULL;
        }

    public function getValueForDisplay ($context, $row)
        {
        if (!isset ($row[$this->key]))
            return NULL;
        return $row[$this->key];
        }

    public function getValueForEditing ($context, $row)
        {
        return $this->getValueForDisplay ($context, $row);
        }

    public function getTemplateName ()
        {
        return "field";
        }

    public function getCssClass ()
        {
        return $this->cssClass;
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        $resultColumns[] = $this->key;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getId ()
        {
        if ($this->renderId)
            return $this->getParamName ();
        return NULL;
        }

    public function setValue ($value)
        {
        $this->initialValue = $value;
        }
    }

class HiddenFieldTemplate extends FieldTemplate
    {
    public function __construct ($prefix, $key)
        {
        parent::__construct ($prefix, $key, "hidden", NULL, NULL);
        }
    }

// a field for storing non persisted data
class HiddenAdditionalFieldTemplate extends HiddenFieldTemplate
    {
    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        }
    }

class IntFieldTemplate extends FieldTemplate
    {
    public function __construct ($prefix, $key, $label, $tooltip)
        {
        parent::__construct ($prefix, $key, "number", $label, $tooltip);
        $this->cssClass = "intfield";
        $this->size = 12;
        }
    }

class PasswordFieldTemplate extends FieldTemplate
    {
    public $size;

    public function __construct ($prefix, $key, $label, $tooltip, $size)
        {
        parent::__construct ($prefix, $key, "password", $label, $tooltip);
        $this->size = $size;
        }
    }

class CheckBoxFieldTemplate extends FieldTemplate
    {
    public function __construct ($prefix, $key, $label, $tooltip)
        {
        parent::__construct ($prefix, $key, "checkbox", $label, $tooltip);
        $this->cssClass = "checkboxfield";
        }

    public function getValueForDB ($context, $request, $index = NULL)
        {
        $val = parent::getValueForDB ($context, $request, $index);
        if (NULL == $val)
            return false;
        return $val ? true : false;
        }

    }

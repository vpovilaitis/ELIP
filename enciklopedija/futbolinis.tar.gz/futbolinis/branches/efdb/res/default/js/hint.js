function hint_toggle (hintTitle)
    {
    if (!empty (hintTitle.alreadyVisible))
        return;

    var hintElement = hintTitle.parentNode;
    var hintBody = hintElement.childNodes[1];
    hintTitle.className = "hinttitle";
    hintBody.style.display = "";
    hintTitle.alreadyVisible = true;
    }

function hint_handleResponse (request, hintElement, tableElement, serviceUrl, listUrl, listUrlLabel, alwaysVisible)
    {
    //hintElement.innerHTML = serviceUrl;
    if (!alwaysVisible)
        tableElement.style.display = "none";

    for (var i = hintElement.childNodes.length-1; i >= 0; i--)
        hintElement.removeChild (hintElement.childNodes[i]);

    var listLinkContainer = document.createElement ("div");
    listLinkContainer.className = "hintlink";
    var listLinkElement = document.createElement ("a");
    listLinkElement.href = listUrl;
    listLinkElement.innerHTML = listUrlLabel;
    listLinkContainer.appendChild (listLinkElement);

    var results = request.responseXML.getElementsByTagName ("Result");
    var description = null;
    if (!empty (results))
        description = getXmlSubnodeText (results[0], "description");

    if (!empty (description))
        {
        var title = getXmlSubnodeText (results[0], "title");
        var image = getXmlSubnodeText (results[0], "img");
    
        var hintTitleElement = document.createElement ("div");
        hintTitleElement.className = "hinttitle_inactive";
        addEvent (hintTitleElement, "click", function () { hint_toggle (hintTitleElement); }); 
    
        if (!empty (image))
            hintTitleElement.innerHTML = '<img src="' + image + '" align="absmiddle"> ' +
                                         title +
                                         ' <img src="' + image + '" align="absmiddle">';
        else
            hintTitleElement.innerHTML = title;
    
        var hintBodyElement = document.createElement ("div");
        hintBodyElement.className = "hintbody";
        hintBodyElement.style.display = "none";
        hintBodyElement.innerHTML = description;
    
        hintElement.appendChild (hintTitleElement); 
        hintElement.appendChild (hintBodyElement); 
        tableElement.style.display = "";
        hintElement.className = "hint";

        hintBodyElement.appendChild (listLinkContainer);
        }
    else
        {
        hintElement.appendChild (listLinkContainer);
        }
    }

function hint_prepare (hintElement, serviceUrl, tableElement, listUrl, listUrlLabel, alwaysVisible)
    {
    clearTimeout (hintElement.timer);

    var svc = hintElement.webService;
    svc.open ("GET", serviceUrl, true);
    svc.setRequestHeader ("Content-Type", "text/xml; charset=utf-8");
    svc.setRequestHeader ("Connection", "close");
    var successCallback = function (request)
        {
        hint_handleResponse (request, hintElement, tableElement, serviceUrl, listUrl, listUrlLabel, alwaysVisible);
        };
    svc.onreadystatechange = function () { handleServiceResponse (svc, successCallback); };
    svc.send (null);
    }

function hint_attach (elementid, serviceUrl, loadingText, listUrl, listUrlLabel, alwaysVisible)
    {
    var hintElement = document.getElementById (elementid);
    var tableElement = document.getElementById (elementid + "_t");

    if (empty (hintElement) || empty (tableElement))
	    return;

    tableElement.style.display = "";
    
    // TODO: add "Do not show hints" icon and use some cookie if this icon
    // is clicked. At the next line just return if cookie is set

 
    hintElement.webService = getXMLHTTP ();
    hintElement.innerHTML = loadingText;
    hintElement.timer = setTimeout (function () { hint_prepare (hintElement, serviceUrl, tableElement, listUrl, listUrlLabel, alwaysVisible); }, 0);
    }

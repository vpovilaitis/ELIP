function confirmDelete (confirmFieldName, confirmationText, itemId)
    {
    if (confirm(confirmationText))
        {
        var confirmField = $('input[name='+confirmFieldName+']');
        if (confirmField.length)
            confirmField.val (itemId);
        return true;
        }
    else
        return false;
    }

function multipleSelect (thisCheckbox, elementName)
    {
    var checkboxes = document.getElementsByName (elementName);
    for (var i = 0; i < checkboxes.length; i++)
        checkboxes[i].checked = thisCheckbox.checked;
    }

var s_popupPersistedValues = [];

function popupform_handleSaveResponse (request, parentElement, popup, saveCallback, action)
    {
    var results = request.responseXML.getElementsByTagName ("Result");

    if (saveCallback)
        return saveCallback (parentElement, popup, results, request, action);
    }

function popupform_collectFieldValues (popup)
    {
    // collect values
    var tableEl = popup.firstChild.firstChild;
    var collectedValues = [];
    for (var i = 0; i < tableEl.rows.length; i++)
        {
        if (tableEl.rows[i].cells.length < 2)
            continue;
        var cell = tableEl.rows[i].cells[1];
        for (var j = 0; j < cell.childNodes.length; j++)
            {
            var el = cell.childNodes[j];
            if (el.tagName == "INPUT" && el.type == "checkbox")
                {
                if (el.checked)
                    collectedValues[el.name] = el.value;
                }
            else
                {
                collectedValues[el.name] = el.value;
                }
            }
        }

    return collectedValues;
    }

function popupform_retrieveValues (popup)
    {
    var tableEl = popup.firstChild.firstChild;
    var collectedValues = [];
    for (var i = 0; i < tableEl.rows.length; i++)
        {
        if (tableEl.rows[i].cells.length < 2)
            continue;
        var cell = tableEl.rows[i].cells[1];
        for (var j = 0; j < cell.childNodes.length; j++)
            {
            var el = cell.childNodes[j];
            if (el.tagName == "INPUT" && el.type == "checkbox")
                {
                if (el.checked)
                    collectedValues.push (encodeURIComponent (el.name) + "=" + encodeURIComponent (el.value));
                s_popupPersistedValues[el.name] = el.checked ? true : null;
                }
            else
                {
                collectedValues.push (encodeURIComponent (el.name) + "=" + encodeURIComponent (el.value));
                s_popupPersistedValues[el.name] = el.getPersistedValue ? el.getPersistedValue () : el.value;
                }
            }
        }

    return collectedValues;
    }

function popupform_save (popup, parentElement, serviceUrl, saveCallback, action, closeCallback)
    {
    var url = serviceUrl;
    var successCallback = function (request)
        {
        popupform_handleSaveResponse (request, parentElement, popup, saveCallback, action);
        closeCallback ();
        };

    // collect values
    var collectedValues = popupform_retrieveValues (popup);
    var postData = collectedValues.join ("&");
    var progressFn = showProgress ();

    var svc = getXMLHTTP ();
    svc.open ("POST", url, true);
    svc.setRequestHeader ("Content-Type", "application/x-www-form-urlencoded; charset=utf-8");
    svc.setRequestHeader ("Content-length", postData.length);
    svc.setRequestHeader ("Connection", "close");
    svc.onreadystatechange = function () { handleServiceResponse (svc, successCallback, progressFn); };
    svc.send (postData);
    }

function popupform_postback (form, iframe, popup, parentElement, modeField, saveCallback, action)
    {
    popupform_retrieveValues (popup);
    modeField.value = action;
    $(form).data ('progressFn', showProgress ());
    form.submit ();
    }

function finishFileUpload (formId, success, text, results)
    {
    var form = document.getElementById (formId);
    if (!form)
        {
        alert ("Error finding image upload - '" + formId + "'");
        return;
        }

    var progressfinish = $(form).data ('progressFn');
    if (progressfinish)
        progressfinish ();
    $(form).data ('progressFn', 0);

    form.expectLoadedEvent = true;
    if (!success)
        alert (text);
    else
        {
        form.successCallback (form.parentNode.parentNode, form.parentNode, results, null, null);
        form.closeCallback (results);
        }
    }

function showpopup_addButtonEvent (action, popup, parentElement, serviceUrl, saveCallback, closeCallback)
    {
    if (null !== serviceUrl)
        {
        return function () { popupform_save (popup, parentElement, serviceUrl, saveCallback, action, closeCallback); };
        }
    else
        return function () { saveCallback (popup, parentElement, action, closeCallback); };
    }

function showpopup_addButtonEventWithFile (form, iframe, modeField, action, popup, parentElement, saveCallback)
    {
    return function () { popupform_postback (form, iframe, popup, parentElement, modeField, saveCallback, action); };
    }

var nextFormId = 1;
function showpopup_handleResponse (request, parentElement, options)
    {
    var loadCallback = options.onload;
    var saveCallback = options.onsave;
    var closeCallback = options.onclose;
    var className = options.className;
    var serviceUrl = options.saveUrl;

    if (empty (request.responseXML))
        {
        alert ("Error at " + serviceUrl);
        return;
        }

    var results = request.responseXML.getElementsByTagName ("Result");
    var popup = document.createElement ("DIV");

    var formId = "popupfrm_" + (nextFormId++);
    var form = toElement('<form method="post" enctype="multipart/form-data"></form>');
    form.setAttribute('action', serviceUrl);
    form.setAttribute('target', formId);                                   
    form.id = formId;
    form.closeCallback = function (results)
        {
        if (closeCallback)
            closeCallback (results);
        $(popup).dialog("close");
        };

    var popupTable = document.createElement ("TABLE");
    popup.className = "popup" + (className ? (" " + className) : "");
    popupTable.className = popup.className;
    popup.appendChild (form);
    form.appendChild (popupTable);
    document.body.appendChild (popup);

    var hasFile = false;
    for (var i = 0; i < results.length; i++)
        {
        var type = getXmlSubnodeText (results[i], "type");
        if ("file" ==  type)
            {
            hasFile = true;
            break;
            }
        }

    
    var iframe = null;
    var modeField = null;
    var buttons = [];
    // if there is at least one file field, need to create an
    if (hasFile)
        {
        iframe = toElement('<iframe src="javascript:false;" name="' + formId + '" />');
        iframe.setAttribute('id', formId + "_i");
        iframe.className = 'popup';
        form.expectLoadedEvent = true;
        form.successCallback = saveCallback;
        addEvent (iframe, "load", function ()
            {
            if (form.expectLoadedEvent)
                form.expectLoadedEvent = false;
            else
                {
                var progressfinish = $(form).data ('progressFn');
                if (progressfinish)
                    progressfinish ();
                $(form).data ('progressFn', 0);

                iframe.style.display = 'block';
                if (confirm ("Error"))
                    iframe.style.display = 'none';
                }
            });
        
        popup.appendChild (iframe);

        modeField = document.createElement("INPUT");
        modeField.type = "hidden";
        modeField.name = "mode";
        form.appendChild (modeField);
        var formIdField = document.createElement("INPUT");
        formIdField.type = "hidden";
        formIdField.name = "formid";
        formIdField.value = formId;
        form.appendChild (formIdField);
        }

    // an exception for generci autocomplete field (its service url depends on the "dbtable" dropdown selection)
    var dbTableField = null;
    var autocompleteField = null;
    var saveClickHandler = null;
    for (var i = 0; i < results.length; i++)
        {
        var id = getXmlSubnodeText (results[i], "id");
        var type = getXmlSubnodeText (results[i], "type");
        var label = getXmlSubnodeText (results[i], "label");
        var tooltip = getXmlSubnodeText (results[i], "title");
        var value = getXmlSubnodeText (results[i], "value");

        var rowIndex = popupTable.rows.length;
        var currentRow = popupTable.insertRow (rowIndex);
        
        if ("button" == type)
            {
            var callback = null;
            if ("close" == id)
                {
                callback = form.closeCallback;
                }
            else if (hasFile)
                {
                callback = showpopup_addButtonEventWithFile (form, iframe, modeField, id, popup, parentElement, saveCallback);
                }
            else
                {
                var mode = id;
                var saveUrl = null !== serviceUrl ? serviceUrl + "&mode=" + mode : null;
                callback = showpopup_addButtonEvent (id, popup, parentElement, saveUrl, saveCallback, form.closeCallback);
                saveClickHandler = callback;
                }

            buttons.push ({ text: label, title: tooltip, click: callback });
            }
        else
            {
            var tagName = "INPUT";
            if ("longtext" == type)
                tagName = "TEXTAREA";
            else if ("select" == type)
                tagName = "SELECT";

            var input = document.createElement (tagName);
            
            if ("imgautocomplete" == type || "autocomplete" == type)
                input.type = "text";
            else if ("INPUT" == tagName)
                input.type = type;

            input.className = "popup" + type + " ui-corner-all";
            input.name = id;
            input.id = id;
            input.title = tooltip;
            if (empty (value) && "longtext" != type && !empty (s_popupPersistedValues[id]))
                value = s_popupPersistedValues[id];

            if ("dbtable" == id)
                dbTableField = input;

            if (!empty (value) && "select" != type && "autocomplete" != type && "file" != type)
                input.value = value;

            var labelCell = currentRow.insertCell(0);
            labelCell.className = "editlabelv";

            if ("select" == type)
                {
                var values = getXmlSubnodeText (results[i], "values");
                if (!empty (values))
                    values = values.split ("|");

                if (!empty (values))
                    {
                    for (var o = 0; o < values.length; o++)
                        {
                        var parts = values[o].split ("=", 2);
                        var optionValue = parts[0];
                        var optionLabel = parts[1];
                        var option = document.createElement ("OPTION");
                        if (!empty (value) && optionValue == value)
                            option.selected = true;
                        option.value = optionValue;
                        option.title = optionLabel;
                        option.innerHTML = optionLabel;
                        input.appendChild (option);
                        }
                    }
                }

            if ("checkbox" != type)
                {
                labelCell.innerHTML = label;
                var inputCell = currentRow.insertCell(1);
                inputCell.appendChild (input);
                if ("imgautocomplete" == type || "autocomplete" == type)
                    {
                    var svc = getXmlSubnodeText (results[i], "service");
                    var autocomplete = suggest_attachDynamic (input, input.id, svc, true, false, value, 'not found');
                    if ("autocomplete" == type)
                        {
                        autocompleteField = autocomplete;
                        }
                    }
                }
            else
                {
                labelCell.innerHTML = "&nbsp;";
                input.value = 1;

                var inputCell = currentRow.insertCell(1);
                inputCell.appendChild (input);
                var labelSpan = document.createElement ("SPAN");
                labelSpan.innerHTML += label;
                inputCell.appendChild (labelSpan);

                if (!empty (value))
                    input.checked = true;
                }
            }
        }

    if (saveClickHandler)
        {
        $(popup).find ('INPUT[type=text]').keypress (function (e)
            {
            if (e.keyCode == 13)
                {
                saveClickHandler ();
                }
            });
        }

    $(popup).dialog ( { modal : options.modal, title : options.title, buttons: buttons } );
    if (!empty (loadCallback))
        loadCallback (parentElement, popup);

    if (!empty (dbTableField) && !empty (autocompleteField))
        {
        var originalUrl = autocompleteField.data ().serviceUrl;
        var changeEvent = function (event)
            {
            var parts = dbTableField.value.split (".");
            autocompleteField.data ('serviceUrl', originalUrl.replace ("#DBTABLE#", parts[0]));
            };
        addEvent (dbTableField, "change", changeEvent);
        changeEvent ();
        }
    }

function showPopup (contextElement, options)
    {
    var svc = getXMLHTTP ();
    var url = options.url + "&mode=show";
    svc.open ("GET", url, true);
    svc.setRequestHeader ("Content-Type", "text/xml; charset=utf-8");
    svc.setRequestHeader ("Connection", "close");
    var successCallback = function (request)
        {
        showpopup_handleResponse (request, contextElement, options);
        };
    var progressFn = showProgress ();
    svc.onreadystatechange = function () { handleServiceResponse (svc, successCallback, progressFn); };
    svc.send (null);
    }

function newsfragment_reload (newsFragment, request, reloadFn)
    {
    $(newsFragment).html (extractHtmlFromXmlResponse (request));
    reloadFn ();
    }

function news_create (event, newsFragment, container, containerElement, popupUrl, reloadFn, closeButtonText)
    {
    var options =
        {
        className: 'newspopup', url: popupUrl, saveUrl : popupUrl, modal: true,
        onsave: function (element, popup, result, request, action)
            {
            if ("save" == action)
                {
                newsfragment_reload (newsFragment, request, reloadFn, popupUrl);
                }
            else if ("preview" == action)
                {
                showPreview (extractHtmlFromXmlResponse (request), closeButtonText);
                return false;
                }
            else
                alert ("Invalid arguments");
            }};
    showPopup (container, options);
    eventCancel (event);
    return false;
    }

function newsfragment_attachCreateEvent (newsFragment, container, element, popupUrl, reloadFn, closeButtonText)
    {
    addEvent (element, "click", function (event) { return news_create (event, newsFragment, container, element, popupUrl, reloadFn, closeButtonText); });
    }

function newsfragment_hookCreateLinks (newsFragment, reloadFn, currentElement, popupUrl, closeButtonText)
    {
    for (var i = 0; i < currentElement.childNodes.length; i++)
        {
        if ("A" == currentElement.childNodes[i].tagName)
            newsfragment_attachCreateEvent (newsFragment, currentElement, currentElement.childNodes[i], popupUrl, reloadFn, closeButtonText);

        newsfragment_hookCreateLinks (newsFragment, reloadFn, currentElement.childNodes[i], popupUrl, closeButtonText);
        }
    }

function newsfragment_attachEditPopup (newsFragment, element, popupUrl, reloadFn, closeButtonText)
    {
    addEvent (element, "click", function (event) { return news_create (event, newsFragment, element.parentNode, element, popupUrl, reloadFn, closeButtonText); });
    }

function newsfragment_addPublishIcon (newsFragment, parentElement, publishLink, publishLabel, publishIcon, reloadFn)
    {
    var icon = document.createElement ("img");
    icon.src = publishIcon;
    icon.title = publishLabel;
    icon.width = 12;
    icon.height = 12;
    icon.className = "urlaction";
    addEvent (icon, "click", function ()
        {
        var svc = getXMLHTTP ();
        svc.open ("POST", publishLink, true);
        svc.setRequestHeader ("Connection", "close");
        var successCallback = function (request)
            {
            newsfragment_reload (newsFragment, request, reloadFn);
            };
        svc.onreadystatechange = function () { handleServiceResponse (svc, successCallback); };
        svc.send (null);
        }
        );
    
    parentElement.appendChild (icon);
    }

function newsfragment_enableEditing (newsFragment, currentElement, popupUrl, reloadFn, publishLink, publishLabel, publishIcon, closeButtonText)
    {
    if (currentElement.attributes && currentElement.attributes.getNamedItem ("action") && currentElement.attributes.getNamedItem ("itemid"))
        {
        var action = currentElement.attributes.getNamedItem ("action").value;
        var itemid = currentElement.attributes.getNamedItem ("itemid").value;
        if ("edit" == action)
            {
            newsfragment_attachEditPopup (newsFragment, currentElement, popupUrl + "&id=" + itemid, reloadFn, closeButtonText);
            
            if (currentElement.attributes.getNamedItem ("unpublished"))
                newsfragment_addPublishIcon (newsFragment, currentElement.parentNode, publishLink + "&id=" + itemid, publishLabel, publishIcon, reloadFn);
            }
        }

    for (var i = 0; i < currentElement.childNodes.length; i++)
        {
        newsfragment_enableEditing (newsFragment, currentElement.childNodes[i], popupUrl, reloadFn, publishLink, publishLabel, publishIcon, closeButtonText);
        }
    }

function newsfragment_attachCreationLinks
(
newsFragmentId, canCreate, containerId,
popupCreateUrl, canEdit, popupEditUrl,
publishLink, publishLabel, publishIcon, closeButtonText,
newTopicLabel, replyLabel, newCommentTitle, discussionImg
)
    {
    var newsFragment = document.getElementById (newsFragmentId);
    var containerElement = document.getElementById (containerId);
    if (!newsFragment || (canCreate && !containerElement))
        {
        alert ("Error initializing news - '" + newsFragmentId + "', '" + containerId + "'");
        return;
        }

    var reloadFn = function ()
        {
        newsfragment_attachCreationLinks (newsFragmentId, canCreate, containerId, popupCreateUrl, canEdit, popupEditUrl, publishLink, publishLabel, publishIcon, closeButtonText,
                                          newTopicLabel, replyLabel, newCommentTitle, discussionImg);
        };
    if (canCreate)
        newsfragment_hookCreateLinks (newsFragment, reloadFn, containerElement, popupCreateUrl, closeButtonText);
    
    if (canEdit)
        newsfragment_enableEditing (newsFragment, newsFragment, popupEditUrl, reloadFn, publishLink, publishLabel, publishIcon, closeButtonText);

    var discussionPanels = $('#'+ newsFragmentId + ' .news-discussion');
    discussionPanels.each (function ()
        {
        var $this = $(this);
        var a = $this.find ('a');
        var height = $this.parent ().innerHeight ();
        $this.siblings (':visible').each (
            function ()
                {
                height -= $(this).outerHeight (true);
                });
        $this.show();

        var newLinkUrl = a.siblings ('.newLinkUrl').attr('href');
        panel_fillPanelAsynchronously ($this, a.attr ('href') + '&render=inline', function ()
            {
            height -= $this.outerHeight (true) - $this.innerHeight ();
            $this.height (height);
            comments_attach ($this.find ('#discussionEditor'), $this.find ('.discussions'), newLinkUrl, newTopicLabel, replyLabel, newCommentTitle, discussionImg);
            }, true);
        });
    }

function image_reload (currentElement, src, url, label)
    {
    if (currentElement.attributes && currentElement.attributes.getNamedItem ("placeholder"))
        {
        var type = currentElement.attributes.getNamedItem ("placeholder").value;
        if ("img" == type)
            {
            currentElement.src = src.replace ("#w#", currentElement.width).replace ("#h#", currentElement.height);
            }
        else if ("title" == type)
            {
            currentElement.innerHTML = label;
            currentElement.style.display = "";
            }
        else if ("link" == type)
            {
            currentElement.href = url;
            }
        }

    for (var i = 0; i < currentElement.childNodes.length; i++)
        {
        image_reload (currentElement.childNodes[i], src, url, label);
        }
    }

function imageupload_showPopup (event, containerElement, uploadPopupUrl, title)
    {
    var onSave =
        function (parentEl, popup, results, request)
            {
            if (empty (request))
                image_reload (containerElement, results.src, results.url, results.label);
            else
                image_reload (containerElement, getXmlSubnodeText (results[0], "src"),
                              getXmlSubnodeText (results[0], "url"),
                              getXmlSubnodeText (results[0], "label"));
            };

    var options = { onsave: onSave, className: 'uploadPopup', url: uploadPopupUrl, saveUrl : uploadPopupUrl, modal: true, title: title};
    showPopup (containerElement, options);
    }

function imageupload_executeAction (url)
    {
    var progressFn = showProgress ();

    $.ajax(
        {
        url: url,
        dataType: "xml",
        cache: false,
        success: function (data)
            {
            progressFn ();
            var results = data.getElementsByTagName ("Error");
            if (results && results.length > 0)
                {
                var errors = [];
                for (var i = 0; i < results.length; i++)
                    errors.push (results[i].firstChild.data);

                alert (errors.join ("\n"));
                }
            else
                {
                location.reload();
                }
            },
        error: function (request, textStatus, errorThrown)
            {
            progressFn ();
            showWebServiceRequestError (request);
            }
        });
    }

function imageupload_attach (containerId, uploadPopupUrl, uploadText, attachPopupUrl, attachText, editPopupUrl, editText, deleteUrl, deleteText, deleteConfirm, rotateUrl, rotateText)
    {
    var containerElement = document.getElementById (containerId);
    if (!containerElement)
        {
        alert ("Error initializing image - '" + containerId + "'");
        return;
        }

    var container = $('<div class="uploadImage">');
    var editLink = null;
    var uploadLink = null;
    var attachLink = null;
    var deleteLink = null;
    var rotateLink = null;

    if (!empty (editPopupUrl))
        {
        editLink = document.createElement ("A");
        editLink.className = "uploadImage";
        editLink.innerHTML = editText;
        addEvent (editLink, "click", function (event) { return imageupload_showPopup (event, containerElement, editPopupUrl, editText); });
        $(editLink).button ();
        }

    if (!empty (rotateUrl))
        {
        rotateLink = document.createElement ("A");
        rotateLink.className = "uploadImage";
        rotateLink.innerHTML = rotateText;
        addEvent (rotateLink, "click",
            function (event)
                {
                imageupload_executeAction (rotateUrl);
                });
        $(rotateLink).button ();
        }

    if (!empty (deleteUrl))
        {
        deleteLink = document.createElement ("A");
        deleteLink.className = "uploadImage";
        deleteLink.innerHTML = deleteText;
        addEvent (deleteLink, "click",
            function (event)
                {
                if (confirm (deleteConfirm))
                    {
                    imageupload_executeAction (deleteUrl);
                    }
                });
        $(deleteLink).button ();
        }

    var hideUploadButtons = function ()
        {
        if (deleteLink)
            $(deleteLink).hide ();
        if (editLink)
            $(editLink).hide ();
        };

    if (!empty (uploadPopupUrl))
        {
        uploadLink = document.createElement ("A");
        uploadLink.className = "uploadImage";
        uploadLink.innerHTML = uploadText;
        addEvent (uploadLink, "click", function (event) { hideUploadButtons (); return imageupload_showPopup (event, containerElement, uploadPopupUrl, uploadText); });
        $(uploadLink).button ();
        }

    if (!empty (attachPopupUrl))
        {
        var attachLink = document.createElement ("A");
        attachLink.className = "uploadImage";
        attachLink.innerHTML = attachText;
        addEvent (attachLink, "click", function (event) { hideUploadButtons (); return imageupload_showPopup (event, containerElement, attachPopupUrl, attachText); });
        container.append (attachLink);
        $(attachLink).button ();
        }

    if (editLink)
        container.append (editLink);
    if (uploadLink)
        container.append (uploadLink);
    if (attachLink)
        container.append (attachLink);
    if (rotateLink)
        container.append (rotateLink);
    if (deleteLink)
        container.append (deleteLink);
    
    container.children ('a').wrap ('<div class="link" />');
    container.appendTo ($(containerElement));
    }

/* discussion page */
function comments_attach (editorId, entriesContainer, serviceUrl, newTopicLabel, replyLabel, title, imgUrl, selectedIndex)
    {
    var containerElement = $(entriesContainer);
    if (0 == containerElement.length)
        return;

    containerElement = containerElement[0];
    var createTopicLink = document.createElement('span');
    createTopicLink.innerHTML = newTopicLabel;
    createTopicLink.className = "discussButton";
    $(createTopicLink).button ({ icons: {primary: 'ui-icon-document'} });

    var successCallback = function (request)
        {
        var nextSibling = createTopicLink.nextSibling;
        var parentNode = containerElement.parentNode;
        var lastSelected = $(entriesContainer).accordion ("option", "active");
        parentNode.removeChild (containerElement);
        parentNode.removeChild (createTopicLink);
        var newElement = $(extractHtmlFromXmlResponse (request));

        if (null != nextSibling)
            newElement.insertBefore ($(nextSibling));
        else
            newElement.appendTo ($(parentNode));
        comments_attach (editorId, newElement, serviceUrl, newTopicLabel, replyLabel, title, imgUrl, lastSelected);
        };
    var clickEvent = function ()
        {
        return toggleElementPopup (createTopicLink, serviceUrl, serviceUrl, "commentsPopup", successCallback, null, title);
        };
    addEvent (createTopicLink, "click", clickEvent);

    if (null != containerElement.nextSibling)
        containerElement.parentNode.insertBefore (createTopicLink, containerElement.nextSibling);
    else
        containerElement.parentNode.appendChild (createTopicLink);

    comment_enableEditing (containerElement, containerElement, replyLabel, successCallback, title);

    var editorElement = $(editorId);
    if (editorElement.length)
        editorElement.hide ();

    $(entriesContainer).accordion( { active: selectedIndex } );
    }

function comment_enableEditing (baseContainerElement, currentElement, replyLabel, successCallback, title)
    {
    if (currentElement.attributes && currentElement.attributes.getNamedItem ("svc"))
        {
        // add a toolbar with actions applicable to the current item on top
        var svc = currentElement.attributes.getNamedItem ("svc").value;

        currentElement.innerHTML = replyLabel;
        currentElement.className = "discussButton";
        currentElement.style.display = "";

        var clickEvent = function ()
            {
            return toggleElementPopup (currentElement, svc, svc, "commentsPopup", successCallback, null, title);
            };
        addEvent (currentElement, "click", clickEvent);
        $(currentElement).button ({ icons: {primary: 'ui-icon-comment'} });
        }

    for (var i = 0; i < currentElement.childNodes.length; i++)
        {
        comment_enableEditing (baseContainerElement, currentElement.childNodes[i], replyLabel, successCallback, title);
        }
    }

    
    
function toggleElementPopup (targetElement, popupUrl, actionUrl, className, reloadFn, closeCallback, title)
    {
    if (!targetElement.popup)
        {
        var onPopupLoad = function (targetElement, popup)
            {
            targetElement.popup = popup;
            }

        var successCallback = null;
        if (null === actionUrl)
            {
            successCallback = function (popup, parentElement, buttonId, closeCallback)
                {
                reloadFn (popup, parentElement, buttonId, closeCallback);
                };
            }
        else
            {
            successCallback = function (element, popup, result, request)
                {
                if (undefined !== reloadFn)
                    reloadFn (request);
                };
            }

        var options = { title: title, onsave: successCallback, onclose: closeCallback, className: className, url: popupUrl, saveUrl : actionUrl};
        showPopup (targetElement, options);
        }
    else
        {
        targetElement.popup.dialog (targetElement.popup.dialog ('isOpen') ? 'close' : 'open');
        }
    }

function toolbar_attach (fieldId)
    {
    var fieldElement = document.getElementById (fieldId);
    var toolbarElement = document.getElementById (fieldId + "_tb");

    if (empty (toolbarElement) || empty (fieldElement))
        return;
    toolbarElement.style.display = "";
    toolbar_preprocessIcons (toolbarElement, toolbarElement, fieldElement);
    }

function wrapTextAtCursor (field, prefix, postfix)
    {
    if ("function" == typeof (field.focus))
        field.focus();

    var scrollTop = $(field).scrollTop();

    //  IE support
    if (document.selection)
        {
        var sel = document.selection.createRange();
        sel.text = prefix + sel.text + postfix;
        }
    else if (field.selectionStart || field.selectionStart == '0')
        {
        //Mozilla/Firefox/Netscape 7+ support
        var startPos = field.selectionStart;
        var endPos = field.selectionEnd;
        field.value = field.value.substring (0, startPos) + prefix + field.value.substring (startPos, endPos) + postfix + field.value.substring (endPos, field.value.length);
        field.selectionStart = endPos + prefix.length + postfix.length;
        field.selectionEnd = endPos + prefix.length + postfix.length;
        }
    else
        {
        field.value += prefix + postfix;
        }

    $(field).scrollTop (scrollTop);
    }

function toolbar_preprocessIcons (baseContainerElement, currentElement, fieldElement)
    {
    if (currentElement.attributes && currentElement.attributes.getNamedItem ("action"))
        {
        // add a toolbar with actions applicable to the current item on top
        var action = currentElement.attributes.getNamedItem ("action").value;
        var prefix = "";
        var postfix = "";
        if (currentElement.attributes.getNamedItem ("prefix"))
            prefix = currentElement.attributes.getNamedItem ("prefix").value;
        if (currentElement.attributes.getNamedItem ("postfix"))
            postfix = currentElement.attributes.getNamedItem ("postfix").value;
        currentElement.className = "toobarButton";
        currentElement.style.display = "";

        var clickEvent = null;
        if ("link" == action)
            {
            var successCallback = function (popup, parentElement, buttonId, closeCallback)
                {
                var values = popupform_collectFieldValues (popup);
                var parts = values["dbtable"].split (".");
                prefix = "[[" + parts[1] + ":" + values["id"] + "|";
                postfix = "]]";
                wrapTextAtCursor (fieldElement, prefix, postfix);
                currentElement.popupOpen = false;
                closeCallback ();
                };

            var svc = currentElement.attributes.getNamedItem ("svc").value;
            clickEvent = function ()
                {
                return toggleElementPopup (currentElement, svc, null, "linkPopup", successCallback, null);
                };
            }
        else
            {
            clickEvent = function ()
                {
                wrapTextAtCursor (fieldElement, prefix, postfix);
                };
            }
        addEvent (currentElement, "click", clickEvent);
        }

    for (var i = 0; i < currentElement.childNodes.length; i++)
        {
        toolbar_preprocessIcons (baseContainerElement, currentElement.childNodes[i], fieldElement);
        }
    }

function attachMatchScorePopupInt (link, url, title, canEdit, onSave)
    {
    if (empty (link))
        return;

    var handler = function (shiftKey)
        {
        if (shiftKey)
            return;

        var options = { title: title, onsave: onSave, url: url, saveUrl : url};
        showPopup (link[0], options);
        };

    link.click (function (event)
        {
        if (canEdit)
            handler (event.shiftKey);
        else
            window.signinForAction (function () {handler (event.shiftKey);});

        event.preventDefault();
        });
    }

function attachMatchScorePopup (containerId, url, title, canEdit)
    {
    return attachMatchScorePopupInt ($("." + containerId + " a.linkaction"), url, title, canEdit,
                                     function () { location.reload(); });
    }

function attachMissingScorePopup (selector, urlTemplate, canEdit)
    {
    var i = 0;
    $(selector).each (
        function (index)
            {
            var $this = $(this);
            var url = urlTemplate + $this.attr ('id');
            attachMatchScorePopupInt ($this, url, $this.find (".button-text").text (), canEdit
            ,                         function () { $this.hide (); });
            }
        );
    }

function initializeEditorTaskList (selector)
    {
    var onClick = function (e)
        {
        e.preventDefault ();
        if (!$(this).data ('dlg'))
            {
            var dlg = $(this).siblings ('.editortasks-task');
            dlg.dialog ( {title: $(this).text(), minWidth: 640, minHeight: 240, modal: true });
            $(this).data ('dlg', dlg);
            }

        $(this).data ('dlg').dialog ('open');
        }

    $(selector).find ('a.editor-task-link').click (onClick);
    }

function attachNavBoxEditor (selector, nameCallback)
    {
    var editableElements = $(selector).find ('.navbox-edit, .navbox-actions');
    if (0 == editableElements.length)
        return;

    var onSave = function (parentEl, popup, results, request)
        {
        location.reload();
        };
    editableElements.children ('a').click (
        function (e)
            {
            e.preventDefault ();
            var $this = $(this);

            var name = nameCallback ? nameCallback ($this) : null;
            if (!name)
                name = $this.attr('title');

            if ($this.hasClass ('delete-label'))
                {
                var title = $this.attr ('title') + ' ' + name + '?';
                if (!confirm (title))
                    return;
                $.ajax(
                    {
                    url: $this.attr('href'),
                    cache: false,
                    data: null,
                    dataType: "xml",
                    success: function (data)
                        {
                        var results = data.getElementsByTagName ("Error");
                        if (results && results.length > 0)
                            {
                            var errors = new Array ();
                            for (var i = 0; i < results.length; i++)
                                errors.push (results[i].firstChild.data);
                            alert (errors.join ("\n"));
                            }
                        else
                            window.location.reload ();
                        },
                    error: function (request, textStatus, errorThrown)
                        {
                        showWebServiceRequestError (request);
                        }
                   });
                return;
                }

            var options = { onsave: onSave, className: 'team-label-edit', url: $this.attr('href'), saveUrl : $this.attr('href'), modal: true, title: name};
            showPopup (this, options);
            }
        );
    editableElements.show ();
    }

function attachRelatedUrlEditor ()
    {
    attachNavBoxEditor ('.related-urls');
    }

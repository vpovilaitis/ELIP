function matchLink_onSave (link, popup, result)
    {
    var idx = 0;
    var label = result[idx].getElementsByTagName ("label")[0].firstChild.data;
    var url = result[idx].getElementsByTagName ("url")[0].firstChild.data;
    var replaceWith = document.createElement ("A");
    replaceWith.href = url;
    replaceWith.innerHTML = label;
    
    link.parentNode.insertBefore (replaceWith, link);
    link.parentNode.removeChild (link);
    }

function initializeCompetitionMatchLink (link, title, popupUrl)
    {
    var onClick = function ()
        {
        var options = { title: title, onsave: matchLink_onSave, className: 'newmatchpopup', url: popupUrl, saveUrl : popupUrl};
        showPopup (link, options);
        return false;
        }

    addEvent (link, "click", onClick);
    }

function initializeCompetitionMatchEditor (url, title, stageId, tableId, imageUrl, imageLabel, rounds)
    {
    var tableElement = document.getElementById (tableId);
    var teamIdCell = [];
    var cells = tableElement.rows[0].cells;
    for (var i = 0; i < cells.length; i++)
        {
        if (empty (cells[i].id))
            continue;
        teamIdCell[cells[i].id] = i;
        }
        
    for (var i = 1; i < tableElement.rows.length; i++)
        {
        var id = tableElement.rows[i].id;
        if (empty (id))
            continue;
        for (var c in teamIdCell)
            {
            if (c == id)
                continue;
            var targetCell =  tableElement.rows[i].cells[teamIdCell[c]];
            var existingCount = 0;
            for (var idx = 0; idx < targetCell.children.length; idx++)
                {
                if ("BR" == targetCell.children[idx].tagName)
                    continue;
                existingCount++;
                }

            if (existingCount >= rounds || (4 == rounds && 2 == existingCount))
                continue;

            if (targetCell.children.length > 0)
                targetCell.appendChild (document.createElement ("BR"));

            var link = document.createElement ("A");
            var popupUrl = url + "&teams=" + id + "," + c + "&comp=" + stageId;
            link.href = "javascript: void(0)";
            link.title = imageLabel;
            initializeCompetitionMatchLink (link, title, popupUrl);
            
            var img = document.createElement ("IMG");
            img.src = imageUrl;
            img.alt = "+";
            img.align = "absmiddle";
            img.border = 0;
            img.className = "urlaction";

            link.appendChild (img);
            targetCell.appendChild (link);
            }
        }
    }

function attachCompetitionMatchEditor (url, title, stageId, tableId, imageUrl, imageLabel, rounds)
    {
    if (empty (rounds))
        rounds = 1;
    window.setTimeout (function () { initializeCompetitionMatchEditor (url, title, stageId, tableId, imageUrl, imageLabel, rounds); }, 50);
    }

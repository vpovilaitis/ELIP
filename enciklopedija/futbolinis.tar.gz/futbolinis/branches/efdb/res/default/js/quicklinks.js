function quicklink_reload (quickLinksContainerElement, request, actions)
    {
    quickLinksContainerElement.innerHTML = extractHtmlFromXmlResponse (request);
    quickLinksContainerElement.editorToolbars = null;
    quickLinksContainerElement.onreload (actions);
    }

function quicklink_executeActionSvc (quickLinksContainerElement, action, id, targetElement, actions)
    {
    var postData = "id=" + id;
    var svc = getXMLHTTP ();
    svc.open ("POST", action.serviceUrl, true);
    svc.setRequestHeader ("Content-type", "application/x-www-form-urlencoded");
    svc.setRequestHeader ("Content-length", postData.length);
    svc.setRequestHeader ("Connection", "close");
    var successCallback = function (request)
        {
        quicklink_reload (quickLinksContainerElement, request, actions);
        };
    svc.onreadystatechange = function () { handleServiceResponse (svc, successCallback); };
    svc.send (postData);
    }

function quicklink_executeAction (quickLinksContainerElement, action, id, targetElement, actions)
    {
    if (action.popupUrl)
        {
        var options = { onsave: function (element, popup, result, request)
                {
                quicklink_reload (quickLinksContainerElement, request, actions);
                }, className: 'quicklinkpopup', url: action.popupUrl + "&id=" + id, saveUrl : action.serviceUrl + "&id=" + id};
        showPopup (targetElement, options);
        return;
        }

    quicklink_executeActionSvc (quickLinksContainerElement, action, id, targetElement, actions);
    }

function quicklink_createActionIcon (quickLinksContainerElement, actionContainer, action, id, actions)
    {
    var icon = document.createElement ("img");
    icon.src = action.img;
    icon.title = action.title;
    icon.width = 8;
    icon.height = 8;
    icon.className = "quicklinkaction";
    addEvent (icon, "click", function ()
        {
        if (action.confirmText && !confirm (action.confirmText))
            return;
        return quicklink_executeAction (quickLinksContainerElement, action, id, actionContainer.parentNode, actions);
        }
        );
    
    actionContainer.appendChild (icon);
    }

function quicklink_enableEditing (quickLinksContainerElement, currentElement, actions)
    {
    if (empty (actions))
        {
        return;
        }

    var modifyActions = actions[0];
    var createActions = actions[1];
    if (currentElement.attributes && currentElement.attributes.getNamedItem ("linkid"))
        {
        // add a toolbar with actions applicable to the current item on top
        var toolbar = document.createElement ("SPAN");
        var id = currentElement.attributes.getNamedItem ("linkid").value;

        for (var i = 0; i < modifyActions.length; i++)
            {
            quicklink_createActionIcon (quickLinksContainerElement, toolbar, modifyActions[i], id, actions);
            }

        toolbar.className = "quicklinkttb";
        toolbar.style.position = "absolute";
        currentElement.insertBefore (toolbar, currentElement.firstChild);
        var pos = getAbsolutePosition (currentElement);
        var posParent = getAbsolutePosition (currentElement.offsetParent);

        toolbar.style.left = (posParent.right - 25) + "px";
        toolbar.style.top = (pos.top - 5) + "px";

        // if popup does not fit into the window, try to move it to the visible area
        var pos = getAbsolutePosition (toolbar);
        if (document.body.offsetWidth && document.body.offsetWidth < pos.right)
            toolbar.style.left = (document.body.offsetWidth - toolbar.offsetWidth) + "px";

        quickLinksContainerElement.editorToolbars.push (toolbar);
        }
    else if (currentElement.attributes && currentElement.attributes.getNamedItem ("createUnder"))
        {
        // reuse placeholder to add the creation actions
        var toolbar = currentElement;
        var id = currentElement.attributes.getNamedItem ("createUnder").value;

        for (var i = 0; i < createActions.length; i++)
            {
            quicklink_createActionIcon (quickLinksContainerElement, toolbar, createActions[i], id, actions);
            }

        toolbar.style.display = "";
        quickLinksContainerElement.editorToolbars.push (toolbar);
        }

    for (var i = 0; i < currentElement.childNodes.length; i++)
        {
        quicklink_enableEditing (quickLinksContainerElement, currentElement.childNodes[i], actions);
        }
    }

function quicklink_extractActions (request)
    {
    var results = request.responseXML.getElementsByTagName ("Result");
    var modifyActions = [];
    var createActions = [];

    for (var i = 0; i < results.length; i++)
        {
        var imgSrc = getXmlSubnodeText (results[i], "img");
        var disabledImg = getXmlSubnodeText (results[i], "disabledImg");
        var title = getXmlSubnodeText (results[i], "title");
        var action = getXmlSubnodeText (results[i], "action");
        var svc = getXmlSubnodeText (results[i], "svc");
        var confirmText = getXmlSubnodeText (results[i], "confirmText");
        var popupUrl = getXmlSubnodeText (results[i], "popup");
        var existing = getXmlSubnodeText (results[i], "existing");

        var actionItem = { img: imgSrc, disabledImg: disabledImg, title: title, action: action, serviceUrl: svc, confirmText: confirmText, popupUrl: popupUrl };
        if (existing)
            modifyActions.push (actionItem);
        else
            createActions.push (actionItem);
        }

    return [modifyActions, createActions];
    }

function quicklink_initializeEditorToolbars (containerElement, buttonElement, actions, enableEditingText, exitEditorText)
    {
    containerElement.editorToolbars = [];
    containerElement.toolbarsVisible = true;
    quicklink_enableEditing (containerElement, containerElement, actions);

    if (!containerElement.toolbarsVisible)
        buttonElement.innerHTML = enableEditingText;
    else
        buttonElement.innerHTML = exitEditorText;
    }

function quicklink_toggleEditing (containerElement, buttonElement, canCreate, serviceUrl, enableEditingText, exitEditorText, loadingText)
    {
    if (null === containerElement.toolbarsVisible)
        {
        // still waiting for initialization to complete
        return;
        }

    if (!containerElement.editorToolbars)
        {
        buttonElement.innerHTML = loadingText;

        var svc = getXMLHTTP ();
        var url = serviceUrl;
        svc.open ("GET", url, true);
        svc.setRequestHeader ("Content-Type", "text/xml; charset=utf-8");
        svc.setRequestHeader ("Connection", "close");
        var successCallback = function (request)
            {
            quicklink_initializeEditorToolbars (containerElement, buttonElement, quicklink_extractActions (request), enableEditingText, exitEditorText);
            };
        svc.onreadystatechange = function () { handleServiceResponse (svc, successCallback); };
        svc.send (null);

        }
    else
        {
        var visibility = containerElement.toolbarsVisible ? "none" : "";
        for (var i = 0; i < containerElement.editorToolbars.length; i++)
            containerElement.editorToolbars[i].style.display = visibility;
        containerElement.toolbarsVisible = !containerElement.toolbarsVisible;
        }

    if (!containerElement.toolbarsVisible)
        buttonElement.innerHTML = enableEditingText;
    else
        buttonElement.innerHTML = exitEditorText;
    }

function quicklink_initializeToggleButon (containerElement, canCreate, serviceUrl, enableEditingText, exitEditorText, loadingText)
    {
    var span = document.createElement ("DIV");
    span.className = "enablelinkedit";

    var labelElement = document.createElement ("A");
    labelElement.className = "enablelinkedit";
    labelElement.innerHTML = enableEditingText;
    span.appendChild (labelElement);
    containerElement.appendChild (span);
    addEvent (labelElement, "click", function () { return quicklink_toggleEditing (containerElement, labelElement, canCreate, serviceUrl, enableEditingText, exitEditorText, loadingText); });
    return labelElement;
    }

function quicklink_attach (containerId, canCreate, serviceUrl, enableEditingText, exitEditorText, loadingText)
    {
    var containerElement = document.getElementById (containerId);
    if (!containerElement)
        return;

    quicklink_initializeToggleButon (containerElement, canCreate, serviceUrl, enableEditingText, exitEditorText, loadingText);

    containerElement.onreload =
        function (actions)
            {
            var buttonElement = quicklink_initializeToggleButon (containerElement, canCreate, serviceUrl, enableEditingText, exitEditorText, loadingText);
            quicklink_initializeEditorToolbars (containerElement, buttonElement, actions, enableEditingText, exitEditorText);
            };
    }

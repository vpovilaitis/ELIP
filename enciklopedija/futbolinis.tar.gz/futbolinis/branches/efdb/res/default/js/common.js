function empty (v)
    {
    return null === v || false === v || "" === v || undefined === v || typeof v == undefined || v.length == 0;
    }

function trim(str, chars) {
    return ltrim(rtrim(str, chars), chars);
}
 
function ltrim(str, chars) {
    chars = chars || "\\s";
    return str.replace(new RegExp("^[" + chars + "]+", "g"), "");
}
 
function rtrim(str, chars) {
    chars = chars || "\\s";
    return str.replace(new RegExp("[" + chars + "]+$", "g"), "");
}

function prepareFormForSubmit (form, evt)
    {
    if (evt.shiftKey)
        form.target='_blank';
    else
        form.target='_self';
    }

function getXMLHTTP()
    {
    if (typeof XMLHttpRequest == "undefined") {
      XMLHttpRequest = function() {
        try { return new ActiveXObject("Msxml2.XMLHTTP.6.0"); }
          catch(e) {}
        try { return new ActiveXObject("Msxml2.XMLHTTP.3.0"); }
          catch(e) {}
        try { return new ActiveXObject("Msxml2.XMLHTTP"); }
          catch(e) {}
        try { return new ActiveXObject("Microsoft.XMLHTTP"); }
          catch(e) {}
        throw new Error("This browser does not support XMLHttpRequest.");
      };
    }
    
    return new XMLHttpRequest();
    }

function addEvent (target, eventName, handler)
    {
    if (target.addEventListener)
      target.addEventListener (eventName, handler, false);
    else if (target.attachEvent)
      target.attachEvent ("on" + eventName, handler);
    else
      target["on" + eventName] = handler;
    }

function fireEvent (target, eventName, eventClass)
    {
    if (document.all)
        target.fireEvent ("on" + eventName);
    else
        {
        if (undefined === eventClass)
            eventClass = "HTMLEvents";
        var eventInstance = document.createEvent (eventClass);
        switch (eventClass)
            {
            case "HTMLEvents":
                eventInstance.initEvent (eventName, true, true);
                break;
            case "UIEvents":
                eventInstance.initUIEvent (eventName, true, true, window, null);
                break;
            case "HTMLEvents":
                eventInstance.initMouseEvent (eventName, true, true, window /* some value missing */);
                break;
            }
        target.dispatchEvent (eventInstance);
        }
    }

function showWebServiceRequestError (request)
    {
    try
        {
        if (0 == request.status)
            {
            window.status = e.message;
            return;
            }

        var status = "HTTP error received (" + request.status;
        if (request.statusText)
            status += ": " + request.statusText;
        status += ")\n\n";
        alert (status + request.responseText.toString ());
        }
    catch (e)
        {
        window.status = e.message;
        }
    }

function handleServiceResponse (request, successCallback, closeCallback)
    {
    // window.status = "State: " + request.readyState;
    if (request.readyState == 4)
        {
        if (closeCallback)
            closeCallback ();

        // window.status = window.status + " - " + request.status;
        if (200 == request.status)
            {
            if (!request.responseXML || !request.responseXML.documentElement || "Results" != request.responseXML.documentElement.nodeName)
                {
                if (!empty (request.responseText))
                    {
                    var wnd = window.open ();
                    if (undefined === wnd || null === wnd)
                        window.status = "error";
                    else
                        {
                        wnd.document.writeln (request.responseText);
                        if (empty (wnd.document.title))
                            wnd.document.title = "Error";
                        wnd.document.close();
                        }
                    }
                else
                    window.status = "unexpected error";

                return;
                }

            var results = request.responseXML.getElementsByTagName ("Error");
            if (results && results.length > 0)
                {
                var errors = new Array ();
                for (var i = 0; i < results.length; i++)
                    errors.push (results[i].firstChild.data);
                alert (errors.join ("\n"));
                }
            else
                {
                successCallback (request);
                }
            }
        else
            {
            showWebServiceRequestError (request);
            }
        }
    }

function getXmlSubnodeText (node, subnodeName)
    {
    if (empty (node))
        return null;
    var subnodes = node.getElementsByTagName (subnodeName);
    if (empty (subnodes))
        return null;
    var subnode = subnodes[0];
    if (empty (subnode.firstChild))
        return null;
    return subnode.firstChild.data;
    }

function getAbsolutePosition (element)
    {
    if (empty (element))
        return null;
    var topValue = 0;
    var leftValue = 0;
    var current = element;
    while (current)
        {
        leftValue += current.offsetLeft;
        topValue += current.offsetTop;
        current = current.offsetParent;
        }

    return { left:leftValue, right:leftValue + element.offsetWidth, top: topValue, bottom: topValue + element.offsetHeight};
    }

function eventCancel (e)
    {
    if (!e)
        {
        if (window.event)
            e = window.event;
        else
            return;
        }

    if (e.cancelBubble != null)
        e.cancelBubble = true;
    if (e.stopPropagation)
        e.stopPropagation();
    if (e.preventDefault)
        e.preventDefault();
    if (window.event)
        e.returnValue = false;
    if (e.cancel != null)
        e.cancel = true;
    }

function extractHtmlFromXmlResponse (request)
    {
    var results = request.responseXML.getElementsByTagName ("Result");
    var html = "";
    for (var i = 0; i < results.length; i++)
        html += getXmlSubnodeText (results[i], "html");
    return html;
    }

function showPreview (html, closeButtonText)
    {
    var previewBody = document.createElement ("div");
    previewBody.className = "previewbody";
    var container = document.createElement ("div");
    container.className = "previewcontainer";
    var innerContainer = document.createElement ("div");
    innerContainer.className = "previewinner";
    innerContainer.innerHTML = html;

    var closeButtonContainer = document.createElement ("div");
    closeButtonContainer.className = "previewclose";
    var closeButton = document.createElement ("input");
    closeButton.type = "button";
    closeButton.value = closeButtonText;
    closeButton.className = "previewclose";
    closeButtonContainer.appendChild (closeButton);

    previewBody.appendChild (container);
    container.appendChild (innerContainer);
    container.appendChild (closeButtonContainer);
    
    var closeFn = function ()
        {
        document.body.removeChild (previewBody);
        previewBody = null;
        };

    addEvent (previewBody, "click", closeFn);
    addEvent (closeButton, "click", closeFn);
    
    document.body.appendChild (previewBody);
    }

function toElement (html)
    {
    var div = document.createElement('div');
    div.innerHTML = html;
    var el = div.firstChild;
    return div.removeChild(el);
    }

function showOnClick (event, elementToShow, elementToHide)
    {
    $('hiddenfragm{$hiddenPieces}').show();$('more{$hiddenPieces}').hide();
    $.preventDefault (event);
    }

function showTooltip (x, y, contents)
    {
    hideTooltip ();
    $('<div id="tooltip">' + contents + '</div>').css(
        {
        position: 'absolute',
        display: 'none',
        top: y + 5,
        left: x + 5,
        border: '1px solid #fdd',
        padding: '2px',
        'background-color': '#fee',
        opacity: 0.80
        }).appendTo("body").fadeIn(200);
    }

function hideTooltip ()
    {
    $("#tooltip").remove();
    }

var previousPoint = null;
function onFlotHover(event, pos, item, labelFn)
    {
    if (item)
        {
        if (previousPoint != item.dataIndex) {
            previousPoint = item.dataIndex;
            
            var x = item.datapoint[0].toFixed(0),
                y = item.datapoint[1].toFixed(0);

            var label = labelFn ? labelFn (item.series.label, x, y)
                                : (item.series.label + " (" + x + ") - " + y);
            showTooltip (item.pageX, item.pageY, label);
            }
        }
    else
        {
        hideTooltip();
        previousPoint = null;            
        }
    }

function statistics_accordion (active)
    {
    var fn = function (event, ui)
        {
        if (ui.newContent.data ('loaded'))
            return;
        if (!ui.newHeader.children ('a').length)
            return;
        var link = ui.newHeader.children ('a').attr ('href') + '&render=inline';
        $.ajax(
            {
            url: link,
            cache: true,
            data: null,
            dataType: "text",
            success: function (data)
                {
                ui.newContent.html (data);
                },
            error: function (request, textStatus, errorThrown)
                {
                ui.newContent.html ('');
                showWebServiceRequestError (request);
                }
           });

        ui.newContent.data ('loaded', true);
        };
    $("#statistics").accordion({autoHeight:false, collapsible:true, active: false, changestart: fn});
    if (active)
        {
        $("#statistics").accordion('activate', 0);
        }
    }

function panel_fillAsynchronously (panel, callback)
    {
    var timeout = 0;
    panel.each (function(index)
        {
        var placeholder = $(this);
        var link = placeholder.children ('a.loadurl');
        if (!link.length)
            return;

        var url = link.attr ('href') + '&render=inline';
        window.setTimeout (function () { panel_fillPanelAsynchronously (placeholder, url, callback); }, timeout);
        timeout += 200;
       });
    }

function panel_fillPanelAsynchronously (placeholder, url, callback, parseXml)
    {
    $.ajax(
        {
        url: url,
        cache: true,
        data: null,
        dataType: parseXml ? "xml" : "text",
        success: function (data, textStatus, jqXHR)
            {
            if (parseXml)
                data = extractHtmlFromXmlResponse (jqXHR);

            placeholder.html (data);
            if (callback)
                callback (placeholder, 0 == placeholder.children().length);
            placeholder.find ('.linkbutton').button ();
            },
        error: function (request, textStatus, errorThrown)
            {
            placeholder.html ('');
            showWebServiceRequestError (request);
            }
       });
    }

function attachMetroSignInButton (signinText, signinUrl, imgPath, suggestLogin)
    {
    var dialog = null;
    var clickHandler = function (callback)
        {
        if (null === dialog)
            {
            var reloadCallback = function () { window.location.reload();};
            if (callback)
                reloadCallback = function () {dialog.dialog ('close'); callback();};

            dialog = $('<div>');
            dialog.dialog ( {title: signinText, modal: suggestLogin});
            showCurrentUserInfo (dialog, signinUrl, reloadCallback, reloadCallback);
            }
        dialog.dialog ('open');
        };

    var loadHandler = function ()
        {
        if ($('#showLoginDialog').length > 0 || $('#signout').length > 0)
            {
            //login fragment already exists, so no need for sign in/out button
            }
        else
            {
            var el = $('<div class="metrosignin" title="'+signinText+'"><img class="metrosignin" src="'+imgPath+'" alt="'+signinText+'"></div>');
            el.appendTo ($('body'))
              .button ()
              .click (function () {clickHandler (null);});
            if (suggestLogin)
                el.click ();
            }
        };
    window.setTimeout (loadHandler, suggestLogin ? 0 : 1000);

    window.signinForAction = function (callback) { clickHandler (callback); };
    }

function attachMetroLinks ()
    {
    var items = $(".metrolinksitem");
    items.each (function (e)
            {
            var $this = $(this);
            var originalClass = $this.hasClass ('ui-state-highlight') ? 'ui-state-highlight' : 'ui-state-default';
            $this.data ('originalClass', originalClass);
            })
        .hover (function (e)
            {
            var $this = $(this);
            var originalClass = $this.data ('originalClass');
            $(this).removeClass (originalClass).addClass ('ui-state-hover');
            },
        function (e)
            {
            var $this = $(this);
            var originalClass = $this.data ('originalClass');
            $(this).removeClass ('ui-state-hover').addClass (originalClass);
            })
        .mousedown (function (e)
            {
            var $this = $(this);
            var originalClass = $this.data ('originalClass');
            $(this).removeClass (originalClass).addClass ('ui-state-active');
            })
        .mouseup (function (e)
            {
            var $this = $(this);
            var originalClass = $this.data ('originalClass');
            $(this).removeClass ('ui-state-active').addClass (originalClass);
            });

    var parents = items.parent();
    var initialMinWidth = parents.css ('min-width');
    var minItemWidth = parseInt (initialMinWidth);
    var minWidth = minItemWidth * items.length;
    var singleItem = $(items[0]);
    var minShrunkWidth = singleItem.find('.metroimage').outerHeight () + singleItem.outerWidth(true) - singleItem.innerWidth() + 5;
    singleItem.closest ('.metromenuline').css ('min-width', minShrunkWidth * items.length);

    var anyChanges = false;
    var resize = function ()
        {
        var currentWidth = $(".metromenuline").width ();
        if (minWidth <= currentWidth)
            {
            if (anyChanges)
                {
                parents.css ('min-width', initialMinWidth);
                parents.css ('width', (100/items.length)+'%');
                items.find('.metrolabel').show();
                anyChanges = false;
                }
            return;
            }

        anyChanges = true;
        var deficit = minWidth - currentWidth;
        var shunkItems = Math.ceil (deficit / (minItemWidth - minShrunkWidth));
        parents.each (function (index)
            {
            var $this = $(this);
            if (index >= items.length - shunkItems)
                {
                // shink anythink that does not fit
                $this.css ('min-width', minShrunkWidth);
                if (index > items.length - shunkItems)
                    $this.css ('width', minShrunkWidth);
                else
                    $this.css ('width', minShrunkWidth + shunkItems * (minItemWidth - minShrunkWidth) - deficit);
                $this.find('.metrolabel').hide();
                }
            else
                {
                parents.css ('min-width', initialMinWidth);
                parents.css ('width', (100/items.length)+'%');
                $this.find('.metrolabel').show();
                }
            });
        };
    $(window).resize (resize);
    resize ();
    }

var progressDialog = null;
function showProgress ()
    {
    if (!progressDialog)
        {
        progressDialog = $('<div style="margin:0 auto; width:220px; height:19px; padding:10px;"><img src="/res/progress.gif" /></div>');
        progressDialog.dialog ( { autoOpen: false, modal: true, draggable: false, resizable: false, height: 45, width:240, dialogClass: 'progressDialog'} );
        }

    progressDialog.dialog ('open');
    return function ()
        {
        progressDialog.dialog ('close');
        };
    }

function showCreateUserDialog (link, title, callback)
    {
    var dlg = $('#createuser_dialog');
    if (0 == dlg.length)
        {
        dlg = $('<div style="display:none"></div>').appendTo ($('body'));
        var progressFn = showProgress ();
        $.ajax (
            {
            url: link,
            cache: true,
            data: null,
            dataType: "text",
            success: function (data)
                {
                progressFn ();
                dlg.attr ('id', 'createuser_dialog');
                dlg.html (data);
                var submit = dlg.find ('input[name=save]');
                submit.hide();
                dlg.dialog (
                    {
                    title:title,
                    modal:true,
                    width:500,
                    buttons:
                        [
                        {
                        text: submit.val(),
                        click: function ()
                            {
                            var data = [];
                            dlg.find ('input').each (
                                function ()
                                    {
                                    data.push ({name:$(this).attr('name'), value: $(this).val() });
                                    });
                            var progress = showProgress ();
                            $.ajax (
                                {
                                url: link,
                                cache: false,
                                data: data,
                                dataType: "text",
                                success: function (data)
                                    {
                                    progress ();
                                    dlg.html (data);
                                    submit = dlg.find ('input[name=save]');
                                    if (0 == submit.length)
                                        {
                                        dlg.dialog ('close');
                                        callback ();
                                        }
                                    else
                                        submit.hide();
                                    },
                                error: function (request, textStatus, errorThrown)
                                    {
                                    progress ();
                                    showWebServiceRequestError (request);
                                    },
                                });
                            }
                        }],
                    });
                    
                showCreateUserDialog (link, title, callback);
                },
            error: function (request, textStatus, errorThrown)
                {
                progressFn ();
                showWebServiceRequestError (request);
                },
            });
        }
    else
        {
        dlg.dialog ('open');
        }
    }

function showCurrentUserInfo (container, link, loginCallback, logoutCallback)
    {
    var fnLoadContainer = null;
    var initiallyLoggedIn = null;
    var fnUpdateContainer = function (html)
        {
        container.html (html);
        container.find ('.linkbutton').button ();
        var loginLink = container.find ('#showLoginDialog');
        var fbLoginLink = container.find ('#showFacebookLogin');
        var newUserLink = container.find ('#showNewUserDialog');
        var optoutLink = container.find ('#emailOptout');
        var loginButton = container.find ('input[name="ok"]');
        var dialog = container.find ('.logincontainer');
        if (loginButton.length)
            {
            if (null === initiallyLoggedIn)
                initiallyLoggedIn = false;

            loginButton.button ();
            var userNameField = container.find ('input[name="usr"]');
            var passwordField = container.find ('input[name="pwd"]');
            var persistField = container.find ('input[name="persist"]');
            loginButton.click (function (e)
                {
                var data = { usr: userNameField.val(), pwd: passwordField.val(), persist: persistField.val()};
                fnLoadContainer (link, data, true, dialog);
                e.preventDefault ();
                });

            if (initiallyLoggedIn && logoutCallback)
                logoutCallback ();
            }
        if (loginLink.length)
            {
            loginButton.hide ();
            dialog.dialog (
                {
                autoOpen:false,
                title:loginLink.text(),
                modal:true,
                buttons:
                    [
                    {
                    text: loginButton.val (),
                    click: function (e) { loginButton.click (); }
                    }
                    ]
                });
            loginLink.click (function (e) {
                dialog.dialog ('open');
                e.preventDefault ();
                });
            }
        if (newUserLink.length)
            {
            newUserLink.click (function (e) {
                showCreateUserDialog (newUserLink.attr ('href'), newUserLink.text (), function () { fnLoadContainer (link, null, true); });
                e.preventDefault ();
                });
            }
        if (fbLoginLink.length)
            {
            fbLoginLink.click (function (e) {
                var loginWindow = window.open (fbLoginLink.attr ('href'), 'facebookLogin', 'height=250,width=400');
                loginWindow.focus();
                e.preventDefault ();
                });
            }

        var logoutButton = container.find ('#signout');
        if (logoutButton.length)
            {
            if (null === initiallyLoggedIn)
                initiallyLoggedIn = true;
            logoutButton.click (function (e)
                {
                var logoutWindow = null;
                if (logoutButton.attr ('href').indexOf ('www.facebook.com') > 0)
                    {
                    logoutWindow = window.open (logoutButton.attr ('href'), 'facebookLogin', 'height=250,width=500');
                    logoutWindow.focus();
                    }

                if (null == logoutWindow)
                    fnLoadContainer (logoutButton.attr ('href'), null, true);
                e.preventDefault ();
                });
            if (!initiallyLoggedIn && loginCallback)
                loginCallback ();
            }
        optoutLink.change (function (e)
            {
            var progressFn = showProgress ();
            var data = { val: $(this).prop('checked') ? 1 : 0 };

            $.ajax (
                {
                url: $(this).attr('ajaxlink'),
                cache: false,
                data: data,
                dataType: "xml",
                success: function (data)
                    {
                    progressFn ();
                    var results = data.getElementsByTagName ("Error");
                    if (results && results.length > 0)
                        {
                        var errors = [];
                        for (var i = 0; i < results.length; i++)
                            errors.push (results[i].firstChild.data);

                        alert (errors.join ("\n"));
                        }
                    },
                error: function (request, textStatus, errorThrown)
                    {
                    progressFn ();
                    showWebServiceRequestError (request);
                    },
                });
            });
        }

    fnLoadContainer = function (url, data, displayProgress, targetDialog)
        {
        var progressFn = displayProgress ? showProgress () : null;
        $.ajax (
            {
            url: url,
            cache: false,
            data: data,
            dataType: "text",
            success: function (data)
                {
                if (progressFn)
                    progressFn ();

                if (targetDialog)
                    {
                    var errors = $(data).find ('.ui-state-error');
                    if (errors.length > 0)
                        {
                        targetDialog.find ('.ui-state-error').remove ();
                        targetDialog.append (errors);
                        return;
                        }

                    targetDialog.dialog ('close');
                    }
                    
                fnUpdateContainer (data);
                },
            error: function (request, textStatus, errorThrown)
                {
                if (progressFn)
                    progressFn ();
                container.html ('');
                showWebServiceRequestError (request);
                },
            });
        };

    window.reloadLoginContainer = function ()
        {
        fnLoadContainer (link, null, false);
        };
     window.reloadLoginContainer ();
    }

var g_suggest_basicmatch = /\S/i;
 
function suggest_preprocessSearchString (q)
    {
    q = q.replace ('\s+', ' ');
    if (q.length == 0 || !g_suggest_basicmatch.test (q))
        return '';
 
    return q;
    }
 
function suggest_hide (element)
    {
    if (element)
        element.data ('autocomplete')._trigger( "close" );;
    }
 
function suggest_ishidden (element)
    {
    return element.style.display == 'none';
    }
 
function suggest_show (element)
    {
    if (element)
        element.data ('autocomplete')._trigger( "open" );;
    }
 
function suggest_emptyresults (element)
    {
    if (!element)
        return;
 
    suggest_setSuggestions (element, null);
    }

function suggest_selected (field, event, ui)
    {
    event.preventDefault ();

    if (null != ui.item.url)
        {
        window.location.assign (ui.item.url);
        return;
        }

    $this = $(field);
    var createField = $this.closest ('table.autocontent').find ('.checkboxfield');

    if (null != ui.item.id)
        {
        $this.data().idField.val (ui.item.id);
        $this.data().oldLabelField.val (ui.item.value);
        $this.val (ui.item.value);
        createField.prop ('checked', false).hide ();
        }
    else
        {
        createField.prop ('checked', true).show ();
        }
    
    var linkField = $this.data().linkField;
    if (!empty (linkField))
        {
        if (null != ui.item.id)
            {
            if (empty (linkField.prop ('templateUrl')))
                {
                linkField.prop ('templateUrl', linkField.attr ('href'));
                linkField.attr ('tabIndex', -1);
                }
            linkField.attr ('href', linkField.prop ('templateUrl') + ui.item.id);
            linkField.show ();
            }
        else
            linkField.hide ();
        }

    $this.data().idField.trigger ('change');
    return false;
    }

function suggest_setvalue (element, qElt)
    {
    element.data ('autocomplete')._change (jQuery.Event("click"));
    }

function suggest_handleResponse (field, data, response, searchText)
    {
    var results = data.getElementsByTagName ("Error");
    if (results && results.length > 0)
        {
        var errors = [];
        for (var i = 0; i < results.length; i++)
            errors.push (results[i].firstChild.data);

        alert (errors.join ("\n"));
        response (null);
        }
    else if (searchText == field.val())
        {
        results = $.map (data.getElementsByTagName ("Result"), function (item)
            {
            return {
                    value: getXmlSubnodeText (item, 'label'),
                    id: getXmlSubnodeText (item, 'id'),
                    desc: getXmlSubnodeText (item, 'description'),
                    img: getXmlSubnodeText (item, 'img'),
                    url: getXmlSubnodeText (item, 'url'),
                }
            });
 
        if (!field.data().canCreate && 1 == results.length)
            {
            var timer = null;
            timer = setTimeout (function ()
                {
                clearTimeout (timer);
                if (searchText == field.val ())
                    suggest_setvalue (field);
                }, 4000);

            }

        var autoSelect = field.data('autoSelect') && 1 == results.length;
        var notFoundLabel = field.data('notFoundLabel');
        if (!empty (notFoundLabel) && (0 == results.length || (results.length > 1 && field.data().canCreate)))
            {
            results.push ({
                    value: searchText, id: null, img: null,
                    desc: notFoundLabel,
                });
            }

        field.data({ lastSuggestions: results });
        response (results);

        if (autoSelect)
            {
            field.data("autocomplete")._move("next", jQuery.Event("click"));
            }
        }
    else
        {
        response (null);
        }
    }

function suggest_setSuggestions (field, data)
    {
    field.data("autocomplete").response (data);
    if (1 == data.length)
        {
        field.data("autocomplete")._move("next", jQuery.Event("click"));
        }
    }

function suggest_getSuggestions (field, request, response)
    {
    $this = $(field);
    if (request.term == $this.data().lastTerm)
        {
        response ($this.data().lastSuggestions);
        return;
        }

    $this.data({ lastTerm: request.term, lastSuggestions: null });

    var q = suggest_preprocessSearchString (request.term);
    if (q.length == 0)
        {
        response (null);
        return;
        }

    if ($this.data().exceptionForNumbers)
        {
        var number_match = /^[0-9]+$/i;
        if (number_match.test (q))
            {
            $this.data().idField.value = "#" + q;
            $this.data().oldLabelField.value = q;
            if (!empty ($this.data().linkField))
                $this.data().linkField.hide ();
            return;
            }
        }

    var url = $this.data('serviceUrl') + "&s=" + encodeURIComponent (q);
    $.ajax(
        {
        url: url,
        dataType: "xml",
        cache: false,
        success: function (data)
            {
            suggest_handleResponse ($this, data, response, request.term);
            },
        error: function (request, textStatus, errorThrown)
            {
            showWebServiceRequestError (request);
            response (null);
            }
        });
    }

function suggest_attach (id, serviceUrl, canCreate, exceptionForNumbers, notFoundLabel)
    {
    var idElement = $('#'+id);
    var field = $('#'+id+"_label");
    var oldLabelField = $('#'+id+"_c");
    var linkField = $('#'+id+"_link");

    if (empty (idElement) || empty (field) || empty (oldLabelField))
        {
        alert ("Error attaching to an autosuggest field");
        return;
        }

    field.autocomplete ( { source: function (request, response) { return suggest_getSuggestions (field, request, response); },
                           select: function (event, ui) { return suggest_selected (field, event, ui); } } );
    field.data( "autocomplete" )._renderItem = function (ul, item)
        {
        return $( "<li></li>" ).data( "item.autocomplete", item ).append( "<a>" + (item.img ? ('<img class="autoc_img" src="' + item.img + '">') : '') + item.value + (item.desc ? ('<div class="autoc_desc">' + item.desc + '</div>') : '') + '<div class="clear"></div></a>' ).appendTo( ul );
        };

    field.data (
        {
        serviceUrl: serviceUrl,
        idField: idElement,
        oldLabelField: oldLabelField,
        linkField: linkField,
        canCreate: canCreate,
        exceptionForNumbers: exceptionForNumbers,
        notFoundLabel: notFoundLabel,
        autoSelect: true,
        });

    if (idElement.val () > 0)
        {
        field.data (
            {
            lastTerm: field.val (),
            lastSuggestions: null
            });
        }
        
    return field;
    }

function suggest_attachNavigatableSearchField (id, serviceUrl, selectedCallback)
    {
    var field = $('#'+id);
    if (empty (field))
        field = $('input[name='+id+']');
    if (empty (field))
        {
        alert ("Error attaching to an autosuggest field");
        return;
        }

    field.autocomplete ( { source: function (request, response) { return suggest_getSuggestions (field, request, response); },
                           select: function (event, ui) { return selectedCallback (field, event, ui); } } );
    field.data( "autocomplete" )._renderItem = function (ul, item)
        {
        return $( "<li></li>" ).data( "item.autocomplete", item ).append( "<a>" + (item.img ? ('<img class="autoc_img" src="' + item.img + '">') : '') + item.value + (item.desc ? ('<div class="autoc_desc">' + item.desc + '</div>') : '') + '<div class="clear"></div></a>' ).appendTo( ul );
        };

    field.data (
        {
        serviceUrl: serviceUrl,
        idField: null,
        oldLabelField: null,
        linkField: null,
        canCreate: false,
        exceptionForNumbers: false,
        notFoundLabel: null,
        autoSelect: false,
        });

    return field;
    }

function suggest_attachSearchField (id, serviceUrl)
    {
    return suggest_attachNavigatableSearchField (id, serviceUrl, suggest_selected);
    }

function suggest_attachContentPreviewSearchField (id, serviceUrl, urlPrefix)
    {
    return suggest_attachNavigatableSearchField (id, serviceUrl, function (field, event, ui)
        {
        var url = urlPrefix + ui.item.id;
        window.location.assign (url);
        return;
        });
    }

function suggest_attachDynamic (element, id, serviceUrl, canCreate, exceptionForNumbers, initialValue, notFoundLabel)
    {
    element.id = id + "_label";
    element.name = element.id;
    var idElement = document.createElement ("INPUT");
    idElement.name = idElement.id = id;
    idElement.getPersistedValue = function ()
        {
        return idElement.value + "|" + element.value;
        }
    idElement.type = "hidden";
    element.parentNode.appendChild (idElement);

    var oldValueElement = document.createElement ("INPUT");
    oldValueElement.name = oldValueElement.id = id + "_c";
    oldValueElement.type = "hidden";
    element.parentNode.appendChild (oldValueElement);

    var val = initialValue ? initialValue.split ("|") : [];
    if (2 == val.length)
        {
        idElement.value = val[0];
        element.value = val[1];
        oldValueElement.value = val[1];
        }

    var boxElement = document.createElement ("DIV");
    boxElement.id = id + "_box";
    boxElement.className = "suggest-box";
    //boxElement.style.display = "none";
    if (null == element.nextSibling)
        element.parentNode.appendChild (boxElement);
    else
        element.parentNode.insertBefore (boxElement, element.nextSibling);

    return suggest_attach (id, serviceUrl, canCreate, exceptionForNumbers, notFoundLabel);
    }
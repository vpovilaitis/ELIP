function adjustTeamFieldServiceUrl (element, params)
    {
    
    if (empty ($(element).data('originalUrl')))
        $(element).data('originalUrl', $(element).data().serviceUrl);

    var url = $(element).data('originalUrl');
    if (!empty (params))
        url += "&" + params;

    $(element).data('serviceUrl', url);
    }

function adjustTeamFieldServiceUrlByStage (element, stageElement)
    {
    var filter;
    if (stageElement.value > 0)
        filter = "stageid=" + stageElement.value;

    adjustTeamFieldServiceUrl (element, filter);
    }

function attachMatchEditor (prefix)
    {
    var stageElement = document.getElementsByName (prefix + "_cstage")[0];
    var homeTeamElement = document.getElementById (prefix+"_hometeam_label");
    var awayTeamElement = document.getElementById (prefix+"_awayteam_label");

    if (null != homeTeamElement)
        {
        var homeTeamOnFocus = function ()
            {
            adjustTeamFieldServiceUrlByStage (homeTeamElement, stageElement);
            };

        addEvent (homeTeamElement, "focus", homeTeamOnFocus);
        }
    
    if (null != awayTeamElement)
        {
        var awayTeamOnFocus = function ()
            {
            adjustTeamFieldServiceUrlByStage (awayTeamElement, stageElement);
            };

        addEvent (awayTeamElement, "focus", awayTeamOnFocus);
        }
    }

function findPlayerByNumber (playerNoField, playerElement)
    {
    var teamElement = document.getElementById (playerNoField.parentPrefix + (playerNoField.isHomeTeam ? "_hometeam" : "_awayteam"));
    var stageElement = document.getElementsByName (playerNoField.parentPrefix + "_cstage")[0];

    var teamId = 0;
    var stageId = (null == stageElement) ? playerNoField.stageId : stageElement.value;

    if (teamElement)
        teamId = teamElement.value;
    else
        {
        teamId = playerNoField.isHomeTeam ? playerNoField.homeTeam : playerNoField.awayTeam;
        }

    if (empty (playerNoField.value) || !empty (playerElement.value) ||
        teamId <= 0 || stageId <= 0)
        {
        return;
        }

    var url = playerNoField.serviceUrl + "&team=" + teamId
                                       + "&no=" + playerNoField.value
                                       + "&comp=" + stageId;

    var fieldPrefix = '#' + playerNoField.playerIdFieldPrefix;
    var field = $(fieldPrefix+"_label");
    field.addClass("ui-autocomplete-loading")

    $.ajax({
            url: url,
            cache: false,
            data: null,
            dataType: "xml",
            success: function (data)
                {
                field.removeClass("ui-autocomplete-loading")
                var results = data.getElementsByTagName ("Error");
                if (results && results.length > 0)
                    {
                    var errors = new Array ();
                    for (var i = 0; i < results.length; i++)
                        errors.push (results[i].firstChild.data);
                    alert (errors.join ("\n"));
                    }
                else
                    {
                    if (!empty (playerElement.value))
                        return;

                    var results = data.getElementsByTagName ("Result");
                    if (0 == results.length)
                        return;

                    var results = $.map (results, function (item)
                        {
                        return {
                                value: getXmlSubnodeText (item, 'label'),
                                id: getXmlSubnodeText (item, 'id'),
                                desc: getXmlSubnodeText (item, 'description'),
                                img: null
                            }
                        });

                    suggest_setSuggestions (field, results);
                    if (!field.data().canCreate && 1 == results.length)
                        suggest_setvalue (field, playerElement);
                    }
                },
            error: function (request, textStatus, errorThrown)
                {
                field.removeClass("ui-autocomplete-loading")
                showWebServiceRequestError (request);
                }
           });
    }

function attachMatchPlayerField (url, prefix, playerNoField, playerIdField, parentPrefix, isHomeTeam, homeTeamInitialId, awayTeamInitialId, stageId, playerFiller)
    {
    var playerNoElement = document.getElementsByName (prefix + "_" + playerNoField)[0];
    var playerElement = document.getElementById (prefix + "_" + playerIdField + "_label");
    var numberOnBlur = function ()
        {
        findPlayerByNumber (playerNoElement, playerElement);
        };

    playerNoElement.parentPrefix = parentPrefix;
    playerNoElement.playerIdFieldPrefix = prefix + "_" + playerIdField;
    playerNoElement.isHomeTeam = isHomeTeam;
    playerNoElement.serviceUrl = url;
    playerNoElement.homeTeam = homeTeamInitialId;
    playerNoElement.awayTeam = awayTeamInitialId;
    playerNoElement.stageId = stageId;
    addEvent (playerNoElement, "blur", numberOnBlur);
    
    if (playerFiller)
        {
        var fieldOnFocus = function ()
            {
            playerFiller (playerNoElement, playerElement);
            };
        addEvent (playerElement, "focus", fieldOnFocus);
        var playerIdElement = document.getElementsByName (playerNoElement.playerIdFieldPrefix)[0];
        addEvent (playerIdElement, "change", function () { playerFiller (playerNoElement, playerElement, playerIdElement); });
        }
    }

function createRegisteredTeamPlayerListFiller (players)
    {
    if (players.length <= 0)
        return null;
    return function (playerNoField, playerElement, playerIdElement)
        {
        if (playerIdElement)
            {
            // set the value
            if (!empty (playerNoField.value) || empty (playerIdElement.value))
                return;
            for (var i = 0; i < players.length; i++)
                {
                if (playerIdElement.value == players[i].id)
                    {
                    playerNoField.value = players[i].no;
                    break;
                    }
                }

            return;
            }

        if (!empty (playerNoField.value) || !empty (playerElement.value))
            {
            return;
            }

        var fieldPrefix = '#' + playerNoField.playerIdFieldPrefix;
        var field = $(fieldPrefix+"_label");

        var results = $.map (players, function (item)
            {
            return {
                    value: item.name,
                    id: item.id,
                    desc: null,
                    img: null
                }
            });

        suggest_setSuggestions (field, results);
        };
    }

function attachMatchPlayerFields (prefix, url, fieldPrefixes, playerNoField, playerIdField, homeTeamInitialId, awayTeamInitialId, stageId, homePlayers, awayPlayers)
    {
    var homePlayerFunction = createRegisteredTeamPlayerListFiller (homePlayers);
    var awayPlayerFunction = createRegisteredTeamPlayerListFiller (awayPlayers);
    for (var i = 0; i < fieldPrefixes.length; i++)
        {
        var isHomeTeam = 0 === fieldPrefixes[i].indexOf ("home_");
        attachMatchPlayerField (url, prefix + "_" + fieldPrefixes[i],
                                playerNoField, playerIdField, prefix,
                                isHomeTeam, homeTeamInitialId, awayTeamInitialId, stageId, isHomeTeam ? homePlayerFunction : awayPlayerFunction);
        }
    }

function attachMatchSubstituteFieldsInt ($container, statusText, unrecognizedText)
    {
    var numberfields = '';
    var players = [];
    var substitutes = [];
    $container.find('div.player-number').each (function ()
        {
        var $this = $(this);
        var substitute = $this.hasClass ('substitute');
        var playerRow = $this.closest ('.editvalue');
        var idField = playerRow.find ('table.autocontent input.autocomplete-id');
        var nameField = playerRow.find ('table.autocontent input.player');
        var numberField = $this.find ('input.playerno');

        var inst = { numberField: numberField, idField: idField, nameField: nameField };
        if (substitute)
            substitutes.push (inst);
        else
            players.push (inst);
        }
        );
    players = $(players);
    substitutes = $(substitutes);
    var substitutionRows = [];
    $container.find('div.substitute-minute').each (function ()
        {
        var row = $(this).closest ('.editvalue');
        var offField = row.find ('input.substitute-off');
        var onField = row.find ('input.substitute-on');
        var minuteField = row.find ('input.substitute-minute');

        var statusField = $('<span class="substitute-status"></span>');
        substitutionRows.push ({ onField: onField, offField: offField, minuteField: minuteField });
        statusField.appendTo (onField.parent ());

        var descriptor = { minuteField: minuteField, offField: offField, onField: onField };
        var onFocus = function (isOn, field)
            {
            var availablePlayers = [];
            var availablePlayerNumbers = [];
            var availableSubstitutes = [];
            $([players, substitutes]).each (
                function (index)
                    {
                    $.each (this, function ()
                        {
                        if (!this.idField.val ())
                            return;

                        var number = null;
                        if (this.numberField.val ())
                            {
                            number = this.numberField.val ();
                            availablePlayers[number] = { id: number, label: this.numberField.val () + " " + this.nameField.val () };
                            }
                        else
                            {
                            number = this.idField.val ();
                            availablePlayers[number] = { id: number, label: this.nameField.val () };
                            }
                        if (0 == index)
                            availablePlayerNumbers.push (number);
                        else
                            availableSubstitutes.push (number);
                        });
                    });
            var playersLeft = [];
            $.each (substitutionRows, function ()
                {
                if (!this.offField.val () || !this.onField.val () || this.minuteField.val () >= minuteField.val ())
                    return;

                var id = this.offField.val ();
                var position = $.inArray (id, availablePlayerNumbers);
                if (-1 != position)
                    availablePlayerNumbers.splice (position, 1);

                id = this.onField.val ();
                availablePlayerNumbers.push (id);
                position = $.inArray (id, availableSubstitutes);
                if (-1 != position)
                    availableSubstitutes.splice (position, 1);
                });

            var list = isOn ? availableSubstitutes : availablePlayerNumbers;
            list = $.map (list, function (no) { return availablePlayers[no]; });
            field.autocomplete (
                {
                source: list,
                minLength: 0,
                select: function (event, ui) { field.val (ui.item.id); field.change(); return false; }
                } );
            field.autocomplete ('search', '');
            };

        offField.focus (function () { return onFocus (false, offField); });
        onField.focus (function () { return onFocus (true, onField); });
        var onChange = function ()
            {
            var status = '';
            var success = false;
            if (offField.val () && onField.val ())
                {
                var availablePlayers = [];
                var availableSubstitutes = [];
                $.each (players, function ()
                    {
                    if (!this.idField.val ())
                        return;
                    if (this.numberField.val ())
                        availablePlayers[this.numberField.val ()] = { id: this.idField.val (), name: this.nameField.val () };
                    availablePlayers[this.idField.val ()] = { id: this.numberField.val (), name: this.nameField.val () };
                    });
                $.each (substitutes, function ()
                    {
                    if (!this.idField.val ())
                        return;
                    if (this.numberField.val ())
                        availableSubstitutes[this.numberField.val ()] = { id: this.idField.val (), name: this.nameField.val () };
                    availableSubstitutes[this.idField.val ()] = { id: this.numberField.val (), name: this.nameField.val () };
                    });
                $.each (substitutionRows, function ()
                    {
                    if (!this.offField.val () || !this.onField.val () || this.minuteField.val () >= minuteField.val ())
                        return;

                    var playerLeft = availablePlayers[this.offField.val ()];
                    availablePlayers[this.offField.val ()] = null;
                    if (playerLeft.id)
                        availablePlayers[playerLeft.id] = null;

                    var playerJoined = availableSubstitutes[this.onField.val ()];
                    availablePlayers[this.onField.val ()] = playerJoined;
                    availableSubstitutes[this.onField.val ()] = null;
                    if (playerJoined.id)
                        {
                        availablePlayers[playerJoined.id] = availableSubstitutes[playerJoined.id];
                        availableSubstitutes[playerJoined.id] = null;
                        }
                    });

                var playerOn = availableSubstitutes[onField.val ()];
                var playerOff = availablePlayers[offField.val ()];
                if (!playerOff)
                    status = unrecognizedText.replace ('[NO]', offField.val ());
                else if (!playerOn)
                    status = unrecognizedText.replace ('[NO]', onField.val ());
                else
                    {
                    success = true;
                    status = statusText.replace ('[MIN]', minuteField.val () ? minuteField.val () : '?')
                                       .replace ('[ON]', playerOn.name)
                                       .replace ('[OFF]', playerOff.name);
                    }
                }

            if (success)
                statusField.addClass ('ui-state-highlight').removeClass ('ui-state-error');
            else
                statusField.removeClass ('ui-state-highlight').addClass ('ui-state-error');
            statusField.text (status);
            };
        offField.change (onChange);
        offField.focus (onChange);
        onField.change (onChange);
        onField.focus (onChange);
        minuteField.change (onChange);
        }
        );
    }

function attachMatchSubstituteFields (statusText, unrecognizedText)
    {
    attachMatchSubstituteFieldsInt ($('.homeplayers'), statusText, unrecognizedText);
    attachMatchSubstituteFieldsInt ($('.awayplayers'), statusText, unrecognizedText);
    }

function showMatchReport (id, title)
    {
    var element = $("#" + id);
    var body = $("body");
    element.dialog ({ modal:false, position: 'right', dialogClass: 'reportDlg', width:body.width()*0.45, height: body.height()*0.9, title:title});
    }

function predictor_attachPopupEvent (anchorNode, panelNode)
    {
    anchorNode.click (function ()
        {
        panelNode.dialog ({title: anchorNode.attr('title'), width:anchorNode.hasClass('edit') ? "auto" : '75%', modal: true});
        return false;
        });

    var inputFields = panelNode.find ('input[type=text]');

    inputFields.keypress(function(event)
        {
        if ( event.which == 13 )
            {
            panelNode.find ('input[type=button]').click ();
            }
        });
    }

function predictor_attachSubmitEvent (containerNode, panelNode, submitElement, serviceUrl)
    {
    submitElement.click (function ()
        {
        var resultFields = panelNode.find ("INPUT[type=text]");
        var data = "r1=" + resultFields[0].value + "&r2=" + resultFields[1].value;
        data += "&id=" + containerNode.find ("a.guess").attr("id");
        var $progress = $("#progress_pred");
        $progress.remove ().insertBefore (panelNode.find (".predictor_fields"));
        $progress.show ();

        $.ajax({
                url: serviceUrl,
                cache: false,
                data: data,
                dataType: "xml",
                success: function (data)
                    {
                    $progress.hide ();
                    var results = data.getElementsByTagName ("Error");
                    if (results && results.length > 0)
                        {
                        var errors = new Array ();
                        for (var i = 0; i < results.length; i++)
                            errors.push (results[i].firstChild.data);
                        alert (errors.join ("\n"));
                        }
                    else
                        {
                        var results = data.getElementsByTagName ("Guess");
                        containerNode.removeClass("guess_highlight");
                        containerNode.addClass("guess");
                        containerNode.html (results[0].firstChild.data);
                        panelNode.dialog ('close');
                        }
                    },
                error: function (request, textStatus, errorThrown)
                    {
                    $progress.hide ();
                    showWebServiceRequestError (request);
                    }
               });
        });
    }

function predictor_initializeEvents (elements)
    {
    elements.each (function ()
        {
        var currentElement = $(this);
        var anchorNode = currentElement.find ("a.guess");
        var panelNode = currentElement.find (".predictor_guess");
        var buttonNode = currentElement.find ("input[type=button]");

        if (anchorNode.length && panelNode.length && buttonNode.length)
            {
            predictor_attachPopupEvent (anchorNode, panelNode);
            predictor_attachSubmitEvent (currentElement, panelNode, buttonNode, buttonNode.attr ("service"));
            }
        });
    }

function predictor_attach (placeholderId, listPanelId)
    {
    var placeholder = $("#"+placeholderId);
    var listPanel = $("#"+listPanelId);
    if (!placeholder.length || !listPanel.length)
        return false;

    placeholder.hide ();
    listPanel.show ();
    predictor_initializeEvents (listPanel.find ('.guessrow'));
    }

function leaguetable_filter (title)
    {
    var $menu = $('div.filter').find ('#filtermenu');
    $menu.dialog ({title:title,modal:true});
    }

function initializeLeagueListControl (selector)
    {
    var parent = $(selector);
    var listPanel = parent.find ('.leaguelist');
    var displayPanel = parent.find ('.leaguelistcontent .scrollable');
    var additionalLinkPanel = $('<div class="league-links">&nbsp;</div>');
    var progress = displayPanel.find ('img').remove ();
    var lastShownPanel = null;

    additionalLinkPanel.appendTo (displayPanel.parent ());

    displayPanel.html ('');
    var leagueLinks = listPanel.find ('a.listedleague');
    if (0 == leagueLinks.length)
        {
        return;
        }

    var scrollableList = listPanel.find ('.scrollable');
    scrollableList.css ('overflow-y', 'visible');
    scrollableList.css ('height', 'auto');
    displayPanel.height (scrollableList.height () - additionalLinkPanel.outerHeight(true));

    leagueLinks.click (function (e)
        {
        e.preventDefault ();

        var panel = $(this).data ('panel');
        if (lastShownPanel)
            lastShownPanel.hide ();

        leagueLinks.removeClass ('ui-state-active').button ('enable');
        $(this).button ('disable').removeClass ('ui-state-disabled').addClass ('ui-state-active');

        panel.show ();
        lastShownPanel = panel;
        
        var additionalLinks = $(this).next ('.other-links').clone ();
        additionalLinkPanel.html ('');
        additionalLinks.appendTo (additionalLinkPanel).show ();

        if (panel.data ('loaded'))
            return;

        panel_fillPanelAsynchronously (panel, $(this).attr ('href') + '/render=inline', function () { panel.data ('loaded', false); } );
        })
    leagueLinks.each (function (index)
        {
        var panel = $('<div></div>');
        progress.clone().appendTo (panel);
        panel.appendTo (displayPanel).hide ().data ('loaded', false);
        $(this).data ('panel', panel);
        });
    leagueLinks.first().click ();
    }

function outdateSourceDetails (url, redirectUrl, confirmText)
    {
    if (!confirm (confirmText))
        return;

    $.ajax(
        {
        url: url,
        cache: false,
        data: null,
        dataType: "text",
        success: function (data)
            {
            var html = $(data);
            var errors = html.find ('.ui-state-error');
            if (errors.length)
                alert (errors.text ());
            else
                window.location.assign (redirectUrl);
            },
        error: function (request, textStatus, errorThrown)
            {
            showWebServiceRequestError (request);
            }
       });
    }

function attachSubmitSchedule ()
    {
    var dateFields = $('input.datefield');
    dateFields.each (function (index)
        {
        $(this).blur (function ()
            {
            if (index < dateFields.length - 2)
                {
                if ("" == $(dateFields[index+1]).val ())
                    $(dateFields[index+1]).val($(this).val());
                }
            });
        });
    }

function attachTeamView ()
    {
    attachNavBoxEditor ('.clubteams', function (element)
        {
        var name = element.closest('.navbox-edit').siblings ('.current');
        var years = element.closest('.navbox-edit').siblings ('.years');
        if (years.length && years.text().length > 0)
            name = name.text() + " (" + years.text() + ")";
        else if (name.text().length > 0)
            name = name.text();
        else
            name = element.attr('title');
        return name;
        });
    }

function attachCompetitionView ()
    {
    return attachTeamView ();
    }

function initializeMatchList (editUrl, title)
    {
    var upcommingMatches = $('a.future-match');
    var onSave = function (link, popup, result, request)
        {
        var idx = 0;
        var label = getXmlSubnodeText (result[idx], "time");
        var fullDate = getXmlSubnodeText (result[idx], "fullDate");
        var url = getXmlSubnodeText (result[idx], "url");
        $(link).attr ('href', url);
        $(link).text (label);
        $(link).closest ('.singlematch').find ('div.matchdate').text (fullDate);
        };

    upcommingMatches.click (function (e)
        {
        e.preventDefault ();
        var id = $(this).attr('id');
        var url = editUrl + "&id=" + id;
        var options = { onsave: onSave, url: url, saveUrl: url, modal: true, title: title};
        showPopup (this, options);
        });
    }

function generateStatistics (placeholderId, link, evt)
    {
    if (evt && evt.shiftKey)
        return;

    var placeholderElement = document.getElementById (placeholderId);
    placeholderElement.style.display = "block";
    placeholderElement.style.textAlign = "center";
    placeholderElement.style.paddingTop = "2em";
    placeholderElement.style.paddingBottom = "2em";

    if (empty (placeholderElement.webService))
        {
        placeholderElement.webService = getXMLHTTP ();
        placeholderElement.storedInnerHTML = placeholderElement.innerHTML;
        }
    else
        placeholderElement.innerHTML = placeholderElement.storedInnerHTML;

    var svc = placeholderElement.webService;
    svc.open ("GET", link, true);
    svc.setRequestHeader ("Connection", "close");
    svc.onreadystatechange = function () { statistics_readyStateChange (svc, placeholderElement); };
    svc.send (null);

    return false;
    }

function statistics_readyStateChange (request, placeholderElement)
    {
    if (request.readyState != 4)
        return;

    if (200 != request.status)
        {
        showWebServiceRequestError (request);
        return;
        }

    placeholderElement.style.textAlign = "";
    placeholderElement.style.paddingTop = "";
    placeholderElement.style.paddingBottom = "";
    placeholderElement.innerHTML = request.responseText;
    statistics_accordion (true);
    }

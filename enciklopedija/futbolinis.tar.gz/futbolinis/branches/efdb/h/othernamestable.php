<?php

class OtherNamesTable extends ContentTable
    {
    const COL_FIRSTNAME = "name";
    const COL_SURNAME = "surname";
    const COL_SIMPLIFIEDFIRST = "simplifiedfirst";
    const COL_SIMPLIFIEDLAST = "simplifiedlast";
    const COL_SOURCETYPE = "srcType";
    const COL_FULL_NAME = "personname";
    const COL_PERSON = "person";

    const SRCTYPE_ALTERNATE = 1;
    const SRCTYPE_DECLINED = 2;
    const SRCTYPE_GENERATED = 3;
    const SRCTYPE_MULTIPLE_NAMES = 4;
    const SRCTYPE_RENAMED = 6;
    const SRCTYPE_ORPHANS = 7;
    
    public function __construct ($context, $instanceRow)
        {
        parent::__construct ($context, $instanceRow);
        }

    protected function preprocessOnWrite (&$nameToValue)
        {
        if (empty ($nameToValue["c_".self::COL_SIMPLIFIEDFIRST]) && !empty ($nameToValue["c_".self::COL_FIRSTNAME]))
            {
            $nameToValue["c_".self::COL_SIMPLIFIEDFIRST] = self::removeDiacritics ($nameToValue["c_".self::COL_FIRSTNAME]);
            }
        if (empty ($nameToValue["c_".self::COL_SIMPLIFIEDLAST]) && !empty ($nameToValue["c_".self::COL_SURNAME]))
            {
            $nameToValue["c_".self::COL_SIMPLIFIEDLAST] = self::removeDiacritics ($nameToValue["c_".self::COL_SURNAME]);
            }
        }

    public function insertRecord ($nameToValue)
        {
        $this->preprocessOnWrite ($nameToValue);
        return parent::insertRecord ($nameToValue);
        }

    public function updateRecord ($criteria, $nameToValue, $maxRows = NULL)
        {
        $this->preprocessOnWrite ($nameToValue);
        return parent::updateRecord ($criteria, $nameToValue, $maxRows);
        }

    public function createQuery ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL, $tableAlias = NULL)
        {
        if (empty ($criteria))
            $criteria = array (new EqCriterion (self::COL_SOURCETYPE, self::SRCTYPE_ALTERNATE));
        return parent::createQuery ($resultColumns, $criteria, $joinedQueries, $queryParams, $tableAlias);
        }
        
    public function deleteRecords ($ids)
        {
        $criteria = array (new InCriterion ($this->getIdColumn (), $ids));
        return $this->deleteBy ($criteria, true);
        }
    
    // Function which generates an unique name hash which is used in similar name search
    public static function removeDiacritics ($name)
        {
        if (empty ($name))
            return $name;

        $parts = preg_split ("/[ -]+/", trim ($name, " ."));
        $processed = array ();
        foreach ($parts as $part)
            $processed[] = self::removePartDiacritics ($part);
        return implode ("", $processed);
        }

    protected static function removePartDiacritics ($name)
        {
        if (empty ($name))
            return $name;

        $name = utf8_strtolower (trim ($name));
        
        $name = preg_replace ("/son$/", "sen", $name);
        $name = preg_replace ("/gu([ieao])/", "g\\1", $name);
        $name = preg_replace ("/[yij]$/", "i", $name);
        $name = preg_replace ("/(dar|der|dru)$/", "dr", $name);

        $search = array ('tch','teidis', 'tidis', 'eio', 'chr','hr', 'giorgi', 'mp', 'rijus', '\'', '-');
        $replace = array ('c', 'tides',  'tides', 'io',  'ʰr', 'ʰr', 'george', 'b',  'rius',  '',   ' ');
        $name = str_replace ($search, $replace, $name);

        $name = preg_replace ("/([bcdfghjklmnprstvzščž])[eiy]s$/", "\\1as", $name);
        $name = preg_replace ("/ija$/", "e", $name);
        $name = preg_replace ("/(.{3,50})([eėi])[j]us$/u", "$1$2i", $name);
        $name = preg_replace ("/(.{3,50})[čc]ius$/u", "$1č", $name);
        $name = preg_replace ("/([^o])z$/", "$1s", $name);
        $name = preg_replace ("/([^o])z /", "$1s ", $name);
        $name = preg_replace ("/ios$/", "as", $name);
        $name = preg_replace ("/[oó]$/u", "a", $name);

        $search = array  ('dz','dj','dž','bj','ya','ia','iā','je','ye','ej','ks','kš','sh','zh','ch','kh','ts','th', 'yo', 'jo', 'io', 'yi', 'iy', 'yj', );
        $replace = array ('d', 'd', 'd', 'bz','ia','e', 'e', 'e', 'e', 'ei','x', 'x', 'š',  'ž', 'c', 'c', 'c', 'þ',  'ё',  'ё',  'ё',  'ii', 'ii', 'ii', );
        $name = str_replace ($search, $replace, $name);

        $search = array  ('ss','kk','h', 'nn', 'ou', 'uo', 'ii', 'ss', 'll');
        $replace = array ('s', 'k', 'g', 'n',  'u',  'u',  'i',  's',  'l' );
        $name = str_replace ($search, $replace, $name);

        $start = substr ($name, 0, 2);
        if ("mc" == $start)
            $name = "mac".substr ($name, 2);
        if ("o" == $name[0])
            $name = "a".substr ($name, 1);

        $search = explode(",", "ą,č,ę,ė,į,ı,š,ş,ų,ū,ż,ž,ç,ć,ł,ň,ţ,ğ,ý,á,ă,é,ē,í,ó,ú,à,è,ì,ò,ù,ä,ë,ï,ö,ü,ÿ,â,ê,î,ô,û,å,ā,e,i,ø,ã,õ,ð,w,ņ,ķ,ļ,þ,đ,ck,k,u,æ,œ,ʰr,ces");
        $replace = explode(",","a,c,e,e,i,i,s,s,u,u,z,z,c,c,l,n,t,g,y,a,a,e,e,i,o,u,a,e,i,o,u,a,e,i,o,u,y,a,e,i,o,u,a,a,e,i,o,a,o,d,v,n,k,l,th,d,c,c,v,ae,oe,hr,cas");
        $name = str_replace ($search, $replace, $name);
       
        $name = preg_replace ("/([bcdfghjklmnprstvz])(ё|e|a|o)([bcdfghjklmnprstvz])/", "\\1…\\3", $name);
        $name = preg_replace ("/([bcdfghjklmnprstvz])(ё|e|a|o)([bcdfghjklmnprstvz])/", "\\1…\\3", $name);
        $name = preg_replace ("/^[jyeё]/u", "i", $name);
        $name = preg_replace ("/^[z]/", "s", $name);
        $name = preg_replace ("/^[hcg]/", "x", $name);
        $name = str_replace (" ", "", $name);
        $name = preg_replace ("/(.{4,50})(…s|s|i)$/Uu", "$1", $name);
        $name = preg_replace ("/(.+)[c]$/", "$1x", $name);

        return $name;
        }

    public static function createAlternativeNamePairs ($name, $surname)
        {
        $split = preg_split ("/(\s+|\-)/", "$name $surname");
        $lastPart = array_pop ($split);
        $leftovers = implode (" ", $split);
        $alternatives = self::switchMultipleNames ($leftovers, $lastPart);

        $ret = array ();
        foreach ($alternatives as $alternative)
            {
            if ($name == $alternative[0] && $surname == $alternative[1])
                continue;
            $ret[] = array (self::removeDiacritics ($alternative[0]), self::removeDiacritics ($alternative[1]), $alternative[0], $alternative[1]);
            }
        return $ret;
        }

    protected static function switchMultipleNames ($name, $surname)
        {
        $split = preg_split ("/(\s+|\-)/", $name, 2);
        if (2 == count ($split))
            {
            $other = self::switchMultipleNames ($split[1], $surname);
            $multiplied = array ();
            foreach ($other as $alternative)
                {
                $multiplied[] = array ($split[0]." ".$alternative[0], $alternative[1]);
                $multiplied[] = array ($split[0], $alternative[0]." ".$alternative[1]);
                }

            return $multiplied;
            }

        return array (array ($name, $surname));
        }
    }


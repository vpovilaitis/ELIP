<?php
require_once (PATH.'inc/webservice.php');

class QuickLinkService extends WebService
    {
    protected $returnsHTML = NULL;
    protected $data = NULL;

    public function __construct ($context)
        {
        parent::__construct ($context);
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        $dbtable = new QuickLinksTable ($this->context);
        $action = !empty ($request["action"]) ? $request["action"] : "enumerate";
        $id = !empty ($request["id"]) ? $request["id"] : NULL;

        $oldTarget = $context->setErrorTarget ($this);

        switch ($action)
            {
            case "enumerate":
                $this->data = $this->enumerateActions ($dbtable);
                break;

            case "indent-less":
                if (1 === $dbtable->indentRecordLess ($id))
                    $this->returnsHTML = true;
                else
                    $this->addError ("Item can not be promoted");
                break;

            case "indent-more":
                if (1 === $dbtable->indentRecordMore ($id))
                    $this->returnsHTML = true;
                else
                    $this->addError ("Item can not be demoted");
                break;

            case "up":
                if ($dbtable->moveRecordUp ($id))
                    $this->returnsHTML = true;
                break;

            case "down":
                if ($dbtable->moveRecordDown ($id))
                    $this->returnsHTML = true;
                break;

            case "newseparator":
                if ($dbtable->insertSeparatorAt ($id))
                    $this->returnsHTML = true;
                break;

            case "newlist":
            case "newimage":
            case "newpage":
            case "edit":
                if ($this->save ($request, $dbtable, $id, $action))
                    $this->returnsHTML = true;
                break;
                
            case "delete":
                if ($dbtable->deleteById ($id))
                    $this->returnsHTML = true;
                break;

            default:
                $this->addError ("Undefined action [_0]", $action);
                $this->data = array ();
                break;
            }

        $context->setErrorTarget ($oldTarget);
        return true;
        }

    protected function save ($request, $dbtable, $id, $action)
        {
        $label = empty ($request[QuickLinksTable::COL_LABEL]) ? "" : trim ($request[QuickLinksTable::COL_LABEL]);
        $tooltip = empty ($request[QuickLinksTable::COL_TOOLTIP]) ? "" : trim ($request[QuickLinksTable::COL_TOOLTIP]);
        $nameToValue = array (QuickLinksTable::COL_TOOLTIP => $tooltip,
                              QuickLinksTable::COL_LABEL => $label);

        switch ($action)
            {
            case "newimage":
                $src = trim ($request[QuickLinksTable::COL_PARAM_STR]);
                if (empty ($src))
                    {
                    $this->context->addError ("Please enter a valid image source.");
                    return false;
                    }
                $nameToValue[QuickLinksTable::COL_PARAM_STR] = $src;
                $nameToValue[QuickLinksTable::COL_PARAM_INT] = $request[QuickLinksTable::COL_PARAM_INT];
                $nameToValue[QuickLinksTable::COL_URL] = $request[QuickLinksTable::COL_URL];
                $nameToValue[QuickLinksTable::COL_TYPE] = QuickLinksTable::TYPE_IMAGE;
                break;
            case "newlist":
                if (empty ($label))
                    {
                    $this->context->addError ("Please enter a valid menu item label.");
                    return false;
                    }

                $table = trim ($request[QuickLinksTable::COL_PARAM_STR]);
                if (empty ($table) || !ContentTable::createInstanceByName ($this->context, $table))
                    {
                    $this->context->addError ("Please enter a valid table name.");
                    return false;
                    }
                $nameToValue[QuickLinksTable::COL_PARAM_STR] = $table;
                $nameToValue[QuickLinksTable::COL_TYPE] = QuickLinksTable::TYPE_CONTENT_LIST;
                break;

            case "newpage":
                if (empty ($label))
                    {
                    $this->context->addError ("Please enter a valid menu item label.");
                    return false;
                    }

                $nameToValue[QuickLinksTable::COL_PARAM_STR] = $request[QuickLinksTable::COL_PARAM_STR];
                $nameToValue[QuickLinksTable::COL_TYPE] = QuickLinksTable::TYPE_PAGE;
                break;

            case "edit":
                foreach (array (QuickLinksTable::COL_PARAM_STR, QuickLinksTable::COL_URL, QuickLinksTable::COL_PARAM_INT) as $key)
                    {
                    if (array_key_exists ($key, $request))
                        $nameToValue[$key] = $request[$key];
                    }

                $criteria = array (new EqCriterion (QuickLinksTable::COL_ID, $id));
                if (false === $dbtable->updateRecord ($criteria, $nameToValue))
                    {
                    $this->context->addError ("Failed to modify the menu item");
                    return false;
                    }

                return true;

            default:
                $this->addError ("Undefined action [_0]", $action);
                return false;
            }

        $nameToValue[QuickLinksTable::COL_TARGET_GROUP] = QuickLinksTable::GROUP_EVERYONE;
        $newid = $dbtable->insertRecordAt ($nameToValue, $id);
        if (false === $newid)
            {
            $this->context->addError ("Failed to create a menu item");
            return false;
            }

        return true;
        }

    public function getData ($request)
        {
        if (true === $this->returnsHTML)
            {
            $this->data = $this->getReturnedHtml ($request, "quicklinks");
            }

        return $this->data;
        }

    protected function enumerateActions ($dbtable)
        {
        $result = array ();

        if ($dbtable->canEdit ())
            {
            foreach (array ("indent-less" => $this->getText ("Indent less"),
                            "indent-more" => $this->getText ("Indent more"),
                            "up" => $this->getText ("Move up"),
                            "down" => $this->getText ("Move down"),
                            )
                        as $key => $label)
                {
                $result[] = array ("img" => $this->context->getTinyIconPath ($key),
                                   "disabledImg" => $this->context->getDisabledTinyIconPath ($key),
                                   "title" => $label,
                                   "action" => $key,
                                   "svc" => $this->context->processUrl ("index.php?service=QuickLinkService&action=$key", true),
                                   "existing" => true,
                                   );
                }

            $key = "edit";
            $result[] = array ("img" => $this->context->getTinyIconPath ($key),
                               "title" => $label,
                               "action" => $key,
                               "svc" => $this->context->processUrl ("index.php?service=QuickLinkService&action=$key", true),
                               "popup" => $this->context->processUrl ("index.php?service=EditQuickLinkPopup&action=$key", true),
                               "existing" => true,
                               );
            }

        if ($dbtable->canDelete ())
            {
            $key = "delete";
            $result[] = array ("img" => $this->context->getTinyIconPath ($key),
                               "title" => $label,
                               "action" => $key,
                               "svc" => $this->context->processUrl ("index.php?service=QuickLinkService&action=$key", true),
                               "confirmText" => $this->getText ("Item will be permanently deleted. Are you sure?"),
                               "existing" => true,
                               );
            }

        if ($dbtable->canCreate ())
            {
            foreach (array ("newseparator" => $this->getText ("Add separator"),
                            "newimage" => $this->getText ("Add image"),
                            "newlist" => $this->getText ("Add content list link"),
                            "newpage" => $this->getText ("Add page link"),
                            )
                        as $key => $label)
                {
                $result[] = array ("img" => $this->context->getTinyIconPath ("$key"),
                                   "title" => $label,
                                   "action" => $key,
                                   "svc" => $this->context->processUrl ("index.php?service=QuickLinkService&action=$key", true),
                                   "popup" => ("newseparator" == $key) ? "" : $this->context->processUrl ("index.php?service=EditQuickLinkPopup&action=$key", true),
                                   "existing" => false,
                                   );
                }
            }

        return $result;
        }

    }

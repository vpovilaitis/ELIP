<?php

class ImageSearchService extends WebService
    {
    const MAX_ITEMS = 10;

    public function __construct ($context)
        {
        parent::__construct ($context);
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getData ($request)
        {
        $tableId = isset ($request["id"]) ? $request["id"] : NULL;
        $filterBy = isset ($request["s"]) ? trim ($request["s"]) : NULL;
        if (empty ($filterBy))
            {
            $this->context->addError ("Invalid arguments passed.");
            return NULL;
            }

        $dbtable = new ImagesTable ($this->context);
        $rows = $dbtable->findImages ($filterBy, array (ImagesTable::COL_ID, ImagesTable::COL_LABEL, ImagesTable::COL_DESCRIPTION), self::MAX_ITEMS);
        if (empty ($rows))
            return array ();
        $width = 50;
        $height = (count ($rows) > (self::MAX_ITEMS / 2)) ? 30 : 50;
        foreach ($rows as $row)
            {
            $imageId = $row[ImagesTable::COL_ID];
            $url = $this->context->chooseUrl ("image/$imageId/{$width}x{$height}",
                                              "index.php?c=UserImage&id=$imageId&w=$width&h=$height");
            $result[] = array ("id" => $imageId, "label" => $row[ImagesTable::COL_LABEL],
                               "description" => $row[ImagesTable::COL_DESCRIPTION], "img" => $url);
            }

        return $result;
        }

    }

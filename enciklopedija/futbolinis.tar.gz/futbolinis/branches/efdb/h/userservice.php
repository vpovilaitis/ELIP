<?php
require_once (PATH.'inc/popupservice.php');
require_once (PATH.'inc/newstable.php');

class UserService extends WebService
    {
    public function __construct ($context)
        {
        parent::__construct ($context);
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getData ($request)
        {
        $action = empty ($request["action"]) ? NULL : $request["action"];
        if (!isset ($request["val"]) || "optin" != $action)
            {
            $this->context->addError ("Invalid arguments passed.");
            return NULL;
            }

        $optin = 0 == $request["val"];
        $dbtable = new UsersTable ($this->context);
        if (false === $dbtable->editOptInStatus ($optin))
            {
            $this->context->addError ("Error updating opt-in status.");
            return NULL;
            }

        $result[] = array ("id" => $this->context->getCurrentUser(), "optout" => $request["val"]);
        return $result;
        }
    }

<?php
require_once (PATH.'inc/popupservice.php');
require_once (PATH.'inc/quicklinkstable.php');

class EditQuickLinkPopup extends PopupService
    {
    protected $dbtable;
    protected $existingRow;

    public function __construct ($context)
        {
        parent::__construct ($context, false);
        $this->dbtable = new QuickLinksTable ($context);
        }

    protected function checkAccess ($request)
        {
        return !empty ($this->dbtable) && $this->dbtable->canCreate ();
        }

    protected function getFields ($request)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";

        $fields = array ();
        $fields[] = new TextFieldTemplate ("", QuickLinksTable::COL_LABEL,
                                           $this->getText ("Label:"), $this->getText ("Menu item label"), 64);
        $fields[] = new TextFieldTemplate ("", QuickLinksTable::COL_TOOLTIP,
                                           $this->getText ("Tooltip:"), $this->getText ("Tooltip to be displayed on the menu item"), 128);

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $criteria[] = new EqCriterion (QuickLinksTable::COL_ID, $id);
            $this->existingRow = $this->dbtable->selectSingleBy (NULL, $criteria);
            if (empty ($this->existingRow))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            switch ($this->existingRow[QuickLinksTable::COL_TYPE])
                {
                case QuickLinksTable::TYPE_CONTENT_LIST:
                    $action = "newlist";
                    break;
                case QuickLinksTable::TYPE_IMAGE:
                    $action = "newimage";
                    break;
                case QuickLinksTable::TYPE_PAGE:
                    $action = "newpage";
                    break;
                }
            }

        switch ($action)
            {
            case "newimage":
                $fields[] = new TextFieldTemplate ("", QuickLinksTable::COL_PARAM_STR,
                                                   $this->getText ("Image url:"), $this->getText ("Internet address to retrieve image from."), 256);
                $fields[] = new IntFieldTemplate ("", QuickLinksTable::COL_PARAM_INT,
                                                   $this->getText ("Image width:"), $this->getText ("Optional image width."));
                $fields[] = new TextFieldTemplate ("", QuickLinksTable::COL_URL,
                                                   $this->getText ("Links to:"), $this->getText ("Internet address to navigate if clicking on the image."), 256);
                break;
            case "newlist":
                $fields[] = new TextFieldTemplate ("", QuickLinksTable::COL_PARAM_STR,
                                                   $this->getText ("Table name:"), $this->getText ("Content table to display list for."), 64);
                break;
            case "newpage":
                $fields[] = new TextFieldTemplate ("", QuickLinksTable::COL_PARAM_STR,
                                                   $this->getText ("Page name:"), $this->getText ("Name of the page to point to."), 64);
                break;
            case "edit":
                break;
            default:
                $this->addError ("Undefined action [_0]", $action);
                return array ();
            }

        return $fields;
        }

    protected function getInitialValues ($request)
        {
        return $this->existingRow;
        }

    protected function save ($request, $values)
        {
        }

    protected function getSaveButtonText ()
        {
        return !empty ($this->existingRow) ? $this->getText ("Save") : $this->getText ("Create");
        }

    }

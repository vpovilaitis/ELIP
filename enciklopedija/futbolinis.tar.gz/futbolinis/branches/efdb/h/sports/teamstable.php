<?php
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/sports/constants.php');

class TeamsTable extends ContentTable
    {
    protected $prefixColumn;
    protected $cityColumn;
    protected $nameColumn;
    protected $countryColumn;

    public function __construct ($context, $instanceRow)
        {
        parent::__construct ($context, $instanceRow);

        if (!SIMPLIFIED_TEAM_LABELS)
            {
            $col = $this->findColumn ("prefix");
            $this->prefixColumn = $col->columnDef->name;
            }

        $col = $this->findColumn ("city");
        $this->cityColumn = $col->columnDef->name;

        $col = $this->findColumn ("name");
        $this->nameColumn = $col->columnDef->name;

        $col = $this->findColumn ("country");
        if (!empty ($col))
            $this->countryColumn = $col->name;
        }

    public function canCreateFromLabel ()
        {
        return true;
        }

    public function createFromLabel ($label)
        {
        list ($prefix, $name, $city, $year, $explicitlySpecified) = TeamFilterColumn::parseCriteriaParts ($label);
        if (empty ($city) || (empty ($name) && empty ($prefix)))
            {
            $this->context->addError ("Required fields (city and name or prefix) were not entered. Please fill the field using the template \"&lt;prefix> &lt;name> &lt;city>\".");
            return false;
            }

        $namesToValues = array
            (
            "c_city" => $city,
            );

        if (substr ($name, -2) == "-2")
            {
            $namesToValues["type"] = 3;
            $namesToValues["c_postfix"] = "2";
            $name = substr ($name, 0, -2);
            }
        else
            $namesToValues["type"] = 1;

        if ($explicitlySpecified && !empty ($name))
            $namesToValues["c_name"] = $name;
        if (!empty ($prefix))
            $namesToValues["c_prefix"] = $prefix;

        $id = $this->insertRecord ($namesToValues);
        return $id;
        }

    public function insertRecord ($nameToValue)
        {
        if (empty ($nameToValue[$this->countryColumn]) /*country not empty for national teams */ && 
            (empty ($nameToValue[$this->cityColumn]) ||
            (empty ($nameToValue[$this->nameColumn]) && empty ($nameToValue[$this->prefixColumn]))))
            {
            $this->log ("Adding default values from club name to the new team instance");
            $clubsHandler = ContentTable::createInstanceByName ($this->context, "club");
            if (empty ($clubsHandler))
                {
                $this->context->addError ("Related table not found");
                return false;
                }

            $clubIdColumn = $clubsHandler->getIdColumn ();
            $clubColumn = $this->findColumn ("club");

            if (!empty ($nameToValue["club"]))
                $clubId = $nameToValue["club"][0];

            if (empty ($clubId))
                {
                $this->context->addError ("Please select a club or enter values for city and name fields");
                return false;
                }

            $columns = array ($this->cityColumn, $this->nameColumn, $this->prefixColumn);
            $criteria = array (new EqCriterion ($clubIdColumn, $clubId));
            $row = $clubsHandler->selectSingleBy ($columns, $criteria);
            
            if (empty ($row))
                $this->log ("Error selecting parent club");
            else
                {
                if (empty ($nameToValue[$this->cityColumn]))
                    {
                    if (isset ($nameToValue[$this->cityColumn]))
                        unset ($nameToValue[$this->cityColumn]);
                    $nameToValue[$this->cityColumn] = $row[$this->cityColumn];
                    }

                if (empty ($nameToValue[$this->nameColumn]) && empty ($nameToValue[$this->prefixColumn]))
                    {
                    if (isset ($nameToValue[$this->nameColumn]))
                        unset ($nameToValue[$this->nameColumn]);
                    if (isset ($nameToValue[$this->prefixColumn]))
                        unset ($nameToValue[$this->prefixColumn]);
                    $nameToValue[$this->nameColumn] = $row[$this->nameColumn];
                    $nameToValue[$this->prefixColumn] = $row[$this->prefixColumn];
                    }
                }
            }

        $id = parent::insertRecord ($nameToValue);
        if (empty ($id) || (empty ($nameToValue[$this->cityColumn]) && empty ($nameToValue[$this->nameColumn]) && empty ($nameToValue[$this->prefixColumn])))
            return $id;

        // insert table label if creating non national team record
        $namesTable = new TeamNamesTable ($this->context);
        $values = array (TeamNamesTable::COL_CITY => $nameToValue[$this->cityColumn], TeamNamesTable::COL_TEAMID => $id);
        if (!empty ($nameToValue[$this->nameColumn]))
            $values[TeamNamesTable::COL_NAME] = $nameToValue[$this->nameColumn];
        if (!empty ($nameToValue[$this->prefixColumn]))
            $values[TeamNamesTable::COL_PREFIX] = $nameToValue[$this->prefixColumn];

        if (!empty ($nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_DECLINE]))
            $values[TeamNamesTable::COL_DECLINE] = $nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_DECLINE];

        if (!empty ($nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_SHOWPREFIX]))
            $values[TeamNamesTable::COL_SHOWPREFIX] = $nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_SHOWPREFIX];

        if (!empty ($nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_POSTFIX]))
            $values[TeamNamesTable::COL_POSTFIX] = $nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_POSTFIX];

        if (!empty ($nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_FROM]))
            $values[TeamNamesTable::COL_DATEFROM] = $nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_FROM];

        if (!empty ($nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_TO]))
            $values[TeamNamesTable::COL_DATETO] = $nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_TO];

        $nameId = $namesTable->insertRecord ($values);
        if (empty ($nameId))
            {
            $this->deleteById (array (new EqCriterion ($this->getIdColumn, $id)));
            return false;
            }

        return $id;
        }

    protected function deleteBy ($criteria, $deleteTranslatable = false)
        {
        $ret = parent::deleteBy ($criteria, $deleteTranslatable);
        if (false === $ret)
            return $ret;

        if (1 == count ($criteria) && $criteria[0]->field == $this->getIdColumn ())
            {
            $copy = clone $criteria[0];
            $copy->field = TeamNamesTable::COL_TEAMID;
            $criteria = array ($copy);
            $namesTable = new TeamNamesTable ($this->context);
            $success = $namesTable->deleteBy ($criteria);
            if (false === $success)
                return false;
            }

        return $ret;
        }

    protected function createFilterColumn ($sortColumns)
        {
        return new TeamFilterColumn ($this, $this->displayNameColumn, $sortColumns);
        }

    protected function selectForIndexing ($columns, $ids)
        {
        $columns = array ($this->getIdColumn (), "club", "prefix", "name", "city", "preferred", "manager", "country", "from", "to", "description", "shortname", DBTable::COL_UPDATEDON, DBTable::COL_CREATEDON);
        return parent::selectForIndexing ($columns, $ids);
        }

    protected function indexSingleRow ($row)
        {
        $indexed = parent::indexSingleRow ($row);
        $indexed['indexedLabel'] = $row['c_shortname']."; ".$indexed['label']."; ".$row["c_".Sports::COL_TEAM_CITY]." ".$row["c_".Sports::COL_TEAM_PREFIX]." ".$row["c_".Sports::COL_TEAM_NAME];
        if (empty ($indexed['description']))
            $indexed['description'] = $indexed['label'].".";
        /*
        $removedDiacritics = utf8_normalize ($indexed['description']);
        if ($removedDiacritics != $indexed['description'])
            $indexed['indexedDescription'] .= " $removedDiacritics";
        */
        $removedDiacritics = utf8_normalize ($indexed['indexedLabel']);
        if ($removedDiacritics != $indexed['indexedLabel'])
            $indexed['indexedLabel'] .= " $removedDiacritics";
        $indexed['label'] = $row['c_shortname'];
        return $indexed;
        }

    protected function postprocessIndexedData (&$extracted)
        {
        if (empty ($extracted))
            return true;

        $namesByTeam = array ();
        foreach ($extracted as $id => $row)
            $namesByTeam[$id] = array ();

        $teamToImage = SportsHelper::getTeamImageIds ($this->context, array_keys ($namesByTeam));

        $namesTable = new TeamNamesTable ($this->context);
        $allNames = $namesTable->selectBy (NULL, array (new InCriterion (TeamNamesTable::COL_TEAMID, array_keys ($namesByTeam))));

        if (!empty ($allNames))
            {
            foreach ($allNames as $row)
                $namesByTeam[$row[TeamNamesTable::COL_TEAMID]][] = SportsHelper::extractTeamLabel ($this->context, $row, true);
            }

        foreach ($extracted as $id => &$row)
            {
            if (!empty ($teamToImage[$id]))
                {
                $row['image'] = $teamToImage[$id];
                }
            if (!empty ($namesByTeam[$id]))
                {
                $allNames = implode (", ", $namesByTeam[$id]);
                if (empty ($row['description']))
                    $row['description'] = $allNames;
                else
                    $row['description'] = trim ($row['description'], " .").". ".$allNames;

                $row['chunks'] = array_merge ($row['chunks'], $namesByTeam[$id]);
                $row['indexedLabel'] .= "; ".$allNames."; ".utf8_normalize ($allNames);
                }
            }

        return true;
        }

    public function getExtentedPickList ($maxResults, $filterCriteria)
        {
        if ($maxResults > 20)
            $maxResults = 20;

        $criteriaText = $filterCriteria;
        TeamFilterColumn::parseCriterion ($criteriaText, $postfix, $year);
        $criteria = array ();
        
        $criteria[] = new LikeCriterion (TeamNamesTable::COL_PREFIX, $criteriaText);
        $criteria[] = new LikeCriterion (TeamNamesTable::COL_CITY, $criteriaText);
        $criteria[] = new LikeCriterion (TeamNamesTable::COL_NAME, $criteriaText);
        $parts = explode (" ", $criteriaText, 2);
        if (2 == count ($parts))
            {
            $criteria[] = new LogicalOperatorAnd
                (
                new LikeCriterion (TeamNamesTable::COL_PREFIX, trim ($parts[0], " .,")),
                new LogicalOperatorOr
                                    (
                                    new LikeCriterion (TeamNamesTable::COL_CITY, trim ($parts[1], " .,")),
                                    new LikeCriterion (TeamNamesTable::COL_NAME, trim ($parts[1], " .,"))
                                    )
                );
            $criteria[] = new LogicalOperatorAnd
                (
                new LikeCriterion (TeamNamesTable::COL_CITY, trim ($parts[0], " .,")),
                new LikeCriterion (TeamNamesTable::COL_NAME, trim ($parts[1], " .,"))
                );
            $criteria[] = new LogicalOperatorAnd
                (
                new LikeCriterion (TeamNamesTable::COL_NAME, trim ($parts[0], " .,")),
                new LikeCriterion (TeamNamesTable::COL_CITY, trim ($parts[1], " .,"))
                );
            }

        $namesTable = new TeamNamesTable ($this->context);
        $criteria = array (new LogicalOperatorOr ($criteria));

        if (empty ($postfix))
            $criteria[] = new IsNullCriterion (TeamNamesTable::COL_POSTFIX);
        else
            $criteria[] = new LikeCriterion (TeamNamesTable::COL_POSTFIX, $postfix);

        if (!empty ($year)) // check for teams existing in that year
            {
            $criteria[] = new LogicalOperatorOr
                                    (
                                    new LtCriterion (TeamNamesTable::COL_DATEFROM, $year+1),
                                    new IsNullCriterion (TeamNamesTable::COL_DATEFROM)
                                    );
            $criteria[] = new LogicalOperatorOr
                                    (
                                    new GtEqCriterion (TeamNamesTable::COL_DATETO, $year),
                                    new IsNullCriterion (TeamNamesTable::COL_DATETO)
                                    );
            }

        $idRows = $namesTable->selectBy (array (TeamNamesTable::COL_TEAMID), $criteria, NULL, array (new LimitResults (0, $maxResults)));
        $criteria = NULL;
        $params = NULL;
        if (!empty ($idRows))
            {
            $ids = array ();
            foreach ($idRows as $row)
                $ids[] = $row[TeamNamesTable::COL_TEAMID];
            $criteria[] = new InCriterion ($this->getIdColumn (), $ids);
            }
        else
            {
            $params[] = new FilterCriterion ($filterCriteria);
            }

        $list = $this->getPickList ($criteria, $maxResults, NULL, $params, false, true);
        if (empty ($list))
            return $list;

        $namesByTeam = array ();
        foreach ($list as $id => $pair)
            $namesByTeam[$id] = array ();

        $allNames = $namesTable->selectBy (NULL, array (new InCriterion (TeamNamesTable::COL_TEAMID, array_keys ($namesByTeam))));
        if (empty ($allNames))
            return $list;

        foreach ($allNames as $row)
            $namesByTeam[$row[TeamNamesTable::COL_TEAMID]][] = SportsHelper::extractTeamLabel ($this->context, $row, true);

        $result = array ();
        foreach ($list as $id => $pair)
            {
            list ($label, $description) = $pair;

            if (!empty ($description))
                $description = $this->trimSentence ($description, 70);

            if (!empty ($namesByTeam[$id]))
                {
                $namesRecorded = implode (", ", $namesByTeam[$id]);
                if (!empty ($description))
                    $description = htmlspecialchars ($namesRecorded)."\n<br>\n".htmlspecialchars ($namesRecorded);
                else
                    $description = htmlspecialchars ($namesRecorded);
                }

            $result[$id] = array ($label, $description);
            }

        return $result;
        }

    public function selectChangedRowsForIndexing ($dateFrom, $selectFromIndex, $limit)
        {
        $teamsChanged = parent::selectChangedRowsForIndexing ($dateFrom, 0, $limit + $selectFromIndex);

        $namesTable = new TeamNamesTable ($this->context);
        $params[] = new LimitResults (0, $selectFromIndex + $limit);
        $params[] = new SelectRevisions ();
        $params[] = OrderBy::create (DBTable::COL_UPDATEDON, DBTable::COL_REVISIONID);
        $criteria = array ();
        $indexColumns = $this->getPrimaryIndexColumns ();
        $columns = array (DBTable::COL_UPDATEDON, DBTable::COL_REVISIONID, TeamNamesTable::COL_TEAMID);
        if (!empty ($dateFrom))
            $criteria[] = new GtEqCriterion (DBTable::COL_UPDATEDON, $dateFrom);

        $namesChanged = $namesTable->selectBy ($columns, $criteria, NULL, $params);
        
        $rows = array_merge ($teamsChanged, $namesChanged);
        uasort ($rows, array ("TeamsTable", "compareTeamsAndNames"));
        $result = array ();
        foreach ($rows as $row)
            {
            if ($selectFromIndex > 0)
                {
                $selectFromIndex--;
                continue;
                }

            if (empty ($row[$this->getIdColumn()]))
                $row[$this->getIdColumn()] = $row[TeamNamesTable::COL_TEAMID];
            $result[] = $row;
            if (count ($result) >= $limit)
                break;
            }

        return $result;
        }

    static function compareTeamsAndNames ($a, $b)
        {
        if ($a[DBTable::COL_UPDATEDON] != $b[DBTable::COL_UPDATEDON])
            return $a[DBTable::COL_UPDATEDON] < $b[DBTable::COL_UPDATEDON] ? -1 : 1;
        if (empty ($a[TeamNamesTable::COL_TEAMID]) != empty ($b[TeamNamesTable::COL_TEAMID]))
            return empty ($a[TeamNamesTable::COL_TEAMID]) ? 1 : -1;

        return $b[DBTable::COL_REVISIONID] - $a[DBTable::COL_REVISIONID];
        }

    }

class TeamFilterColumn extends FilterColumn
    {
    protected $context;

    public function __construct ($dbtable, $displayNameColumn, $sortColumns)
        {
        parent::__construct ($dbtable, $displayNameColumn, $sortColumns);
        $this->context = $dbtable->getContext ();
        }

    public static function parseCriterion (&$filterBy, &$postfix, &$year)
        {
        $filterBy = trim ($filterBy);
        if (preg_match ("#^([^(]+)\(([^()]+)\)(.+)?$#", $filterBy, $filterMatches) > 0)
            {
            $filterBy = $filterMatches[1].$filterMatches[2].$filterMatches[3];
            }

        $year = strrchr ($filterBy, " ");
        if (is_numeric (trim ($year)))
            {
            $filterBy = substr ($filterBy, 0, -strlen ($year));
            $year = trim ($year);
            }
        else
            $year = NULL;

        $postfix = NULL;
        if (preg_match ("/^(.+)[-]([0-9]|[A-Z]{1,3})( (.+))?$/", trim ($filterBy), $matches) > 0)
            {
            $filterBy = $matches[1];
            if (!empty ($matches[3]))
                $filterBy .= $matches[3];
            $postfix = $matches[2];
            }
        }

    public function prepareQuery ($filterCriterion, &$criteria, &$joins, &$params = NULL)
        {
        $colPrefix = ContentTable::PREFIX;

        $filterBy = $filterCriterion->criterion;
        self::parseCriterion ($filterBy, $postfix, $year);
        $filterCriterion->criterion = $filterBy;

        $filterCriteria = NULL;
        parent::prepareQuery ($filterCriterion, $filterCriteria, $joins, $params);
        
        $countryJoin = NULL;
        if (!empty ($joins))
            {
            foreach ($joins as $join)
                {
                if ($join->table == "country")
                    {
                    $countryJoin = $join;
                    break;
                    }
                }
            }

        if (empty ($postfix))
            $criteria[] = new IsNullCriterion ($colPrefix."postfix");
        else
            $criteria[] = new EqCriterion ($colPrefix."postfix", $postfix);

        $countryTable = ContentTable::createInstanceByName ($this->context, "country");
        if (!empty ($countryTable))
            {
            if (empty ($countryJoin))
                {
                $crit[] = new JoinColumnsCriterion ("f_country_country_id", "country_id");
                $join = $countryTable->createQuery (array (), $crit);
                $joins[] = $join;
                $join->joinType = Constants::JOIN_LEFT_OUTER;
                }
            else
                $join = $countryJoin;

            $countryCriterion = new LikeCriterion ($colPrefix."name", $filterBy);
            $countryCriterion->translatable = true;
            $countryCriterion->query = $join;
            $filterCriteria[0]->parts[] = $countryCriterion;

            $filterCriteria[0]->parts[] = new LikeCriterion ($colPrefix."prefix", $filterBy);

            $parts = explode (" ", $filterBy, 2);
            if (2 == count ($parts))
                {
                $filterCriteria[0]->parts[] = new LogicalOperatorAnd
                    (
                    new LikeCriterion ($colPrefix."prefix", trim ($parts[0], " .,")),
                    new LikeCriterion ($colPrefix."city", trim ($parts[1], " .,"))
                    );
                $filterCriteria[0]->parts[] = new LogicalOperatorAnd
                    (
                    new LikeCriterion ($colPrefix."city", trim ($parts[0], " .,")),
                    new LikeCriterion ($colPrefix."prefix", trim ($parts[1], " .,"))
                    );
                }

            if (!empty ($year)) // check for teams existing in that year
                {
                $filterCriteria[] = new LogicalOperatorOr
                                        (
                                        new LtCriterion ($colPrefix."from", $year+1),
                                        new IsNullCriterion ($colPrefix."from")
                                        );
                $filterCriteria[] = new LogicalOperatorOr
                                        (
                                        new GtEqCriterion ($colPrefix."to", $year),
                                        new IsNullCriterion ($colPrefix."to")
                                        );
                }
            }

        if (empty ($criteria))
            $criteria = $filterCriteria;
        else
            $criteria = array_merge ($criteria, $filterCriteria);
        }

    public static function parseCriteriaParts ($filterCriterion)
        {
        $year = NULL;
        $prefix = NULL;
        $name = array ();
        $city = NULL;
        $explicitlySpecified = false;

        $pieces = explode (" ", trim ($filterCriterion));
        foreach ($pieces as $part)
            {
            $part = trim ($part);
            if (empty ($part))
                continue;

            if (is_numeric ($part) && $part > 1850)
                $year = $part;
            else if (strlen ($part) <= 2 || (strlen ($part) <= 5 && substr ($part, 1) != utf8_strtolower (substr ($part, 1))))
                {
                $prefix = $part;
                }
            else
                $name[] = $part;
            }

        if (count ($name) > 1)
            {
            $city = array_pop ($name);
            $explicitlySpecified = true;
            }
        else if (count ($name) == 1)
            {
            $city = $name[0];
            }

        return array ($prefix, implode (" ", $name), $city, $year, $explicitlySpecified);
        }
    }

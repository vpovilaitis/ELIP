<?php
require_once (PATH.'h/sports/leagueseason.php');

class LeagueSeasonNameTransformationLT extends LeagueSeasonNameTransformation
    {
    protected $lng;

    protected function getDescription ($context, $level, $name, $season, $stage)
        {
        $level = $this->prepareLevel ($level);
        if (!empty ($stage))
            {
            if (NULL === $this->lng)
                $this->lng = Language::getInstance ($context);
            $name = $this->lng->changeWordCase ($name, Language::CASE_GENITIVE);
            }

        return parent::getDescription ($context, $level, $name, $season, $stage);
        }

    protected function prepareLevel ($level)
        {
        if ($level >= 10)
            return "X".$this->prepareLevel ($level-5);

        if (4 == $level || 9 == $level)
            return "I".$this->prepareLevel ($level+1);

        if ($level >= 5)
            return "V".$this->prepareLevel ($level-5);

        if ($level > 0)
            return "I".$this->prepareLevel ($level-1);

        return "";
        }
    }

class LeagueSeasonLT extends LeagueSeason
    {
    protected function createTransformation ($nameTransform, $stageTransform, $seasonTransform)
        {
        return new LeagueSeasonNameTransformationLT ($nameTransform, $stageTransform, $seasonTransform);
        }
    }
?>

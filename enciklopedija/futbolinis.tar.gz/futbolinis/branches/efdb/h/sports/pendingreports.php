<?php
require_once (PATH."inc/sports/constants.php");

class PendingReports extends EditorTask
    {
    
    public function getTime ()
        {
        return 10;
        }

    public function getName ()
        {
        return $this->getText ("Pending reports");
        }

    public function getNameWithCount ()
        {
        $count = $this->getRemainingCount ();
        if (empty ($count))
            return $this->getText ("No pending reports");
        if ($count >= self::LIMIT)
            return $this->ngettext ("More than [_0] pending report", "More than [_0] pending reports", $count);
        return $this->ngettext ("[_0] pending report", "[_0] pending reports", $count);
        }

    public function getTitle ()
        {
        return $this->getText ("Fill match player information from provided (scanned) match reports.");
        }

    public function getDetailedDescription ()
        {
        return $this->getText ("This information is essential for league statistics (to display all league players, oldest/youngest players) and for player statistics (to corectly display matches played for the team).");
        }

    public function getInstructions ()
        {
        return $this->getText ("To enter the required information,
*select the match you wish to update
*click on the provided link,
*wait a little for scanned images to apper on the right side of the window
*and enter the numbers of the players one by one (after entering the number, suggestions will be shown in next field).");
        }

    public function getCacheContext ()
        {
        return Sports::TABLE_MATCH;
        }

    public function selectTasks ($rowsToCollect)
        {
        $context = $this->context;
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $playersTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHPLAYER);
        $imageUseTable = new ImageUseTable ($context);
        if (empty ($matchesTable))
            return false;

        // select distinct `tbl2`.`contextid` FROM `tc_imageuse` `tbl2` WHERE `tbl2`.`scope`='x_match' and `tbl2`.`zone`='report'
        $criteria = array (new EqCriterion (ImageUseTable::COL_SCOPE, HintsTable::SCOPE_CONTENTTABLE.$matchesTable->getName ()),
                           new EqCriterion (ImageUseTable::COL_ZONE, ImageUseTable::ZONE_REPORT),
                           );
        $rows = $imageUseTable->selectBy (array (ImageUseTable::COL_CONTEXTID), $criteria, NULL, array (new Distinct()));
        $i = count ($rows) - 1;
        $collected = array ();
        while ($i >= 0 && count ($collected) < $rowsToCollect)
            {
            $count = count ($collected);
            $ids = array ();
            for (; $i >= 0 && $count < $rowsToCollect; --$i)
                {
                $ids[] = $rows[$i][ImageUseTable::COL_CONTEXTID];
                $count++;
                }

            // select match_id, COUNT(*) cnt FROM `tx_matchplayers` WHERE match_id in (latest chunk) HAVING cnt > 25
            $criteria = array (new InCriterion ($matchesTable->getIdColumn (), $ids));
            $params = array (new GroupBy (array ($matchesTable->getIdColumn ())));
            $params[] = new HavingCriteria ("playercnt > 25");
            $rowsToExclude = $playersTable->selectBy (array ($matchesTable->getIdColumn (), new FunctionCount ("*", "playercnt")), $criteria, NULL, $params);
            if (empty ($rowsToExclude))
                {
                $collected = array_merge ($collected, $ids);
                break;
                }

            $excludedIds = array ();
            foreach ($rowsToExclude as $row)
                $excludedIds[] = $row[$matchesTable->getIdColumn ()];

            $collected = array_merge ($collected, array_diff ($ids, $excludedIds));
            }

        if (empty ($collected))
            return NULL;

        $columns = array ($matchesTable->getIdColumn ());
        $criteria = array (new InCriterion ($matchesTable->getIdColumn (), $collected));
        $rows = $matchesTable->selectWithDisplayName ($columns, $criteria);
        if (empty ($rows))
            return NULL;

        $result = array ();
        foreach ($rows as $row)
            {
            $id = $row[$matchesTable->getIdColumn ()];
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $matchesTable,
                                                                         $matchesTable->getId (), $id, Constants::MODE_EDIT,
                                                                         "parts=".MatchEditorMode::PLAYERS);
            $result[] = array (
                "url" => $url,
                "name" => $row[ContentTable::COL_DISPLAY_NAME],
                );
            }

        return $result;
        }

    }

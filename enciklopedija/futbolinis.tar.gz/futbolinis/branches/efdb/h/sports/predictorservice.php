<?php
require_once (PATH.'inc/sports/predictortable.php');
require_once (PATH.'inc/sports/constants.php');

class PredictorService extends WebService
    {
    protected function checkAccess ($request)
        {
        return $this->context->getCurrentUser () > 0;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getData ($request)
        {
        $editing = !empty ($request["edit"]);
        $resultHome = array_key_exists ("r1", $request) && is_numeric ($request["r1"]) ? $request["r1"] : NULL;
        $resultAway = array_key_exists ("r2", $request) && is_numeric ($request["r2"]) ? $request["r2"] : NULL;
        if (NULL === $resultHome || NULL === $resultAway || empty ($request["id"]))
            {
            $this->context->addError ("Invalid arguments passed.");
            return NULL;
            }

        $id = $request["id"];

        $predictorGamesTable = new PredictorGameTable ($this->context);
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $joinCriterion = array ();
        $joinCriterion[] = new JoinColumnsCriterion (PredictorGameTable::COL_MATCH_ID, $matchesTable->getIdColumn ());
        $joinCriterion[] = new GtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d G:i:s", time ()));
        $joins[] = $matchesTable->createQuery (array (), $joinCriterion);
        $rows = $predictorGamesTable->selectBy (array (PredictorGameTable::COL_ID), array (new EqCriterion (PredictorGameTable::COL_ID, $id)), $joins);
        if (empty ($rows))
            {
            $this->context->addError ("Game has already started, bids cannot be recorded.");
            return NULL;
            }

        $predictionsTable = new PredictorGuessTable ($this->context);
        $namesToValues = array (PredictorGuessTable::COL_GOALS_HOME => $resultHome,
                                PredictorGuessTable::COL_GOALS_AWAY => $resultAway,
                                );
        if ($editing)
            {
            $criteria = NULL;
            $criteria[] = new EqCriterion (PredictorGuessTable::COL_GAME_ID, $id);
            $criteria[] = new EqCriterion (PredictorGuessTable::COL_USER_ID, $this->context->getCurrentUser ());
            $success = $predictionsTable->updateRecord ($criteria, $namesToValues);
            }
        else
            {
            $namesToValues[PredictorGuessTable::COL_GAME_ID] = $id;
            $namesToValues[PredictorGuessTable::COL_USER_ID] = $this->context->getCurrentUser ();
            $success = $predictionsTable->insertRecord ($namesToValues);
            }

        if (false === $success)
            {
            if (!$this->context->hasErrors ())
                $this->context->addError ("Error saving the guess.");
            return NULL;
            }

        return array (array ("Guess" => "$resultHome:$resultAway"));
        }

    }

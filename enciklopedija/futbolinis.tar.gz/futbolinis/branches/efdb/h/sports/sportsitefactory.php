<?php
require_once (PATH.'inc/sports/constants.php');

class SportSiteFactory extends DefaultFactory
    {
    public function __construct ()
        {
        $this->editorMappings["match"] = "sports/MatchEditor";
        $this->editorMappings[Sports::TABLE_COMPETITIONSTAGE] = "sports/LeagueSeasonEditor";

        $this->viewerMappings[Sports::TABLE_COMPETITIONSTAGE] = "sports/LeagueTable";
        $this->viewerMappings[Sports::TABLE_TEAM] = "sports/TeamView";
        $this->viewerMappings["persons"] = "sports/PersonView";
        $this->viewerMappings["seasons"] = "sports/SeasonsView";
        $this->viewerMappings[Sports::TABLE_LEAGUE] = "sports/LeagueView";
        $this->viewerMappings["stadium"] = "sports/StadiumView";

        $this->viewerMappings["match"] = "sports/MatchView";
        $this->previewMappings["match"] = array
                (
                "matchgoal" => "sports/MatchGoals",
                "matchevent" => "sports/MatchEvents",
                "matchplayers" => "sports/MatchPlayers",
                "matchstats" => "sports/MatchStatistics",
                "matchreferee" => "sports/MatchReferees",
                "matchflow" => "sports/MatchFlow",
                );

        $this->previewMappings["club"] = array
                (
                "team" => "sports/ClubTeamList",
                );
        $this->previewMappings[Sports::TABLE_TEAM] = array
                (
                "teamleagueseasons" => "sports/LeagueAchievements",
                "competitionplayer" => "sports/TeamRegisteredPlayers"
                );
        $this->previewMappings[Sports::TABLE_LEAGUE] = array
                (
                Sports::TABLE_LEAGUE => NULL,
                Sports::TABLE_COMPETITIONSTAGE => "sports/LeagueCompetitions",
                "stadiumrace" => NULL
                );
        $this->previewMappings[Sports::TABLE_COMPETITIONSTAGE] = array
                (
                "refereerating" => "sports/RefereeRatingList",
                // "competitionstage" => NULL,
                "match" => NULL,
                "competitionplayer" => NULL,
                );
        $this->previewMappings["round"] = array
                (
                "teamcupseason" => NULL,
                "match" => NULL,
                );
        $this->previewMappings["stadium"] = array
                (
                "stadiumrace" => NULL,
                );
        $this->previewMappings["persons"] = array
                (
                "stadiumpersons" => NULL,
                "teamplayer" => "sports/TeamRelatedInfoPreview",
                "teamstaff" => "sports/TeamRelatedInfoPreview",
                );

        $this->statisticsViewMappings["persons"] = "sports/PersonStats";
        $this->statisticsViewMappings["team"] = "sports/TeamStats";
        $this->statisticsViewMappings[Sports::TABLE_COMPETITIONSTAGE] = "sports/CompetitionSeasonStats";
        $this->statisticsViewMappings["stadium"] = "sports/StadiumStats";
        
        if (!empty ($_REQUEST["season"]))
            $this->listMappings["refereerating"] = "sports/RefereeSeasonRatings";
        else
            $this->listMappings["refereerating"] = "sports/RefereeRatingList";
        }

    public function getRegisteredComponents ($context)
        {
        $availableComponents = parent::getRegisteredComponents ($context);

        $availableComponents["sports/MatchAnnouncement"] = $context->getText ("Match announcement");
        $availableComponents["sports/LeagueTableFragment"] = $context->getText ("League table");
        $availableComponents["sports/LeagueScorersFragment"] = $context->getText ("League top scorers");
        $availableComponents["sports/LeagueDisciplineFragment"] = $context->getText ("League discipline");
        $availableComponents["sports/LeagueTeamIconsFragment"] = $context->getText ("League team (icons)");
        $availableComponents["sports/CurrentLeagueListFragment"] = $context->getText ("Recent or active leagues");
        $availableComponents["sports/FutureLeagueFragment"] = $context->getText ("Future league announcement");
        if (MATCH_PREDICTOR_ENABLED)
            $availableComponents["sports/MatchPredictorFragment"] = $context->getText ("Match predictor");

        if (MATCH_REFEREE_RATINGS_ENABLED)
            $availableComponents["sports/RefereeRatingsFragment"] = $context->getText ("Referee ratings");

        return $availableComponents;
        }

    public function getQuickLinkLists ($context)
        {
        $ret = array_merge (parent::getQuickLinkLists ($context),
                            array
            (
            "team" =>  $context->getText ("Teams"),
            "league" => $context->getText ("Competitions"),
            "persons" => $context->getText ("Persons"),
            "club" => $context->getText ("Clubs"),
            ));

        return $ret;
        }

    public function getEditorTaskHandlers ($context)
        {
        $handlers = parent::getEditorTaskHandlers ($context);
        $handlers[] = "sports/MissingResults";
        $handlers[] = "sports/MissingStatistics";
        $handlers[] = "sports/PendingStatistics";
        $handlers[] = "sports/PendingReports";
        return $handlers;
        }

    protected function preprocessToolsList ($context, $tools)
        {
        $ret = array ();
        foreach ($tools as $url => $label)
            {
            $url = $context->processUrl ($url, true);
            $ret[] = "<a href=\"$url\">$label</a>";
            }
        return $ret;
        }

    protected function getMaintenanceToolsList ($context)
        {
        $urls = array ("index.php?c=sports/MergePersons" => $context->getText ("Merge duplicate person entries"),
                       "index.php?c=sports/GenerateMatchAnnouncement" => $context->getText ("Generate match announcement text"),
                       "index.php?c=sports/SubmitCareerChange" => $context->getText ("Register player transfer"),
                       );
        return $this->preprocessToolsList ($context, $urls);
        }

    protected function getAutomatedTaskList ($context)
        {
        $date = getdate ();
        $urls = array ("index.php?c=sports/SubmitPersons" => $context->getText ("Batch creation of person records"),
                       "index.php?c=sports/SubmitGameResult" => $context->getText ("Submit game results"),
                       "index.php?c=sports/HistoricalEvents&month={$date["mon"]}&day={$date["mday"]}" => $context->getText ("List todays events"),
                       );
        return $this->preprocessToolsList ($context, $urls);
        }

    protected function getIntegrityToolsList ($context)
        {
        $urls = array ("index.php?c=sports/CheckOrphanedPersons" => $context->getText ("Find persons without country"),
                       "index.php?c=sports/GenerateCompetitionStats" => $context->getText ("Competition match issues and advanced statistics"),
                       );
        return $this->preprocessToolsList ($context, $urls);
        }

    public function getRegisteredTools ($context)
        {
        $arr = parent::getRegisteredTools ($context);
        $arr[$context->getText ("Helper utilities")] = $this->getMaintenanceToolsList ($context);
        $arr[$context->getText ("Automated tasks")] = $this->getAutomatedTaskList ($context);
        $arr[$context->getText ("Integrity checks")] = $this->getIntegrityToolsList ($context);
        return $arr;
        }

    }

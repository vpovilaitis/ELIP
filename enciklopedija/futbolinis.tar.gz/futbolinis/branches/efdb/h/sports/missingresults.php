<?php
require_once (PATH."inc/sports/constants.php");

class MissingResults extends EditorTask
    {
    public function getTime ()
        {
        return 2;
        }

    public function getComplexity ()
        {
        return self::COMPLEXITY_MEDIUM;
        }

    public function getName ()
        {
        return $this->getText ("Missing match results");
        }

    public function getNameWithCount ()
        {
        $count = $this->getRemainingCount ();
        if (empty ($count))
            return $this->getText ("No missing match results");
        if ($count >= self::LIMIT)
            return $this->ngettext ("More than [_0] missing match result", "More than [_0] missing match results", $count);
        return $this->ngettext ("[_0] missing match result", "[_0] missing match results", $count);
        }

    public function getTitle ()
        {
        return $this->getText ("Find and enter results for recent matches.");
        }

    public function getDetailedDescription ()
        {
        return $this->getText ("This information will be used to display correct league table and to calculate predictor results.");
        }

    public function getSortingSetting ()
        {
        return EditorTask::SORT_DESCENDING;
        }

    public function getInstructions ()
        {
        return $this->getText ("To enter the required information,
*choose any match in the list,
*click on the provided link,
*click 'Enter result' link,
*enter home and away goals and optionally half time result,
*enter sources (URL, etc),
*Press <b>Save</b>.");
        }

    public function getCacheContext ()
        {
        return Sports::TABLE_MATCH;
        }

    public function selectTasks ($rowsToCollect)
        {
        $context = $this->context;
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        if (empty ($matchesTable))
            return false;

        $criteria[] = new GtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d H:i", time() - /*6 months*/ 6 * 30 * 24 * 60 * 60));
        $criteria[] = new LtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d H:i", time() - /*1 hour*/60 * 60));
        $criteria[] = new IsNullCriterion ("c_".Sports::COL_MATCH_HOMERESULT);
        $criteria[] = new IsNullCriterion ("c_".Sports::COL_MATCH_AWAYRESULT);
        $rows = $matchesTable->selectBy (array ($matchesTable->getIdColumn (), Sports::COL_MATCH_COMPETITION, Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT, Sports::COL_MATCH_OUTCOME), $criteria);
        if (empty ($rows))
            return NULL;

        $matchIds = array ();
        foreach ($rows as $row)
            {
            $outcome = $row["c_".Sports::COL_MATCH_OUTCOME];
            $id = $row[$matchesTable->getIdColumn ()];
            if (MatchConstants::OUTCOME_TECHNICAL_WIN == $outcome || MatchConstants::OUTCOME_NO_HOME_TEAM == $outcome || MatchConstants::OUTCOME_NO_VISITORS == $outcome)
                continue;
            $matchIds[] = $id;
            }

        $columns = array ($matchesTable->getIdColumn ());
        $criteria = array (new InCriterion ($matchesTable->getIdColumn (), $matchIds));
        $rows = $matchesTable->selectWithDisplayName ($columns, $criteria);
        if (empty ($rows))
            return NULL;

        $result = array ();
        foreach ($rows as $row)
            {
            $id = $row[$matchesTable->getIdColumn ()];
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $matchesTable,
                                                                         $matchesTable->getId (), $id);
            $result[] = array (
                "url" => $url,
                "id" => $id,
                "name" => $row[ContentTable::COL_DISPLAY_NAME],
                );
            }

        return $result;
        }

    public function createListComponent ($prefix, $context)
        {
        return new MissingResultList ($prefix, $context, $this);
        }
    }

class MissingResultList extends TaskList
    {
    public function __construct ($prefix, $context, $descriptor)
        {
        parent::__construct ($prefix, $context, $descriptor);
        $context->addScriptFile ("editor");
        }

    public function getTemplateName ()
        {
        return "sports/missingresultlist";
        }

    public function getStartupScript ()
        {
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $url = $this->context->processUrl ("index.php?service=sports/MatchScorePopup", true)."&match=";
        return "attachMissingScorePopup ('.editortask-row a', '$url', ".($dbtable->canEdit () ? 'true' : 'false').");";
        }
    }

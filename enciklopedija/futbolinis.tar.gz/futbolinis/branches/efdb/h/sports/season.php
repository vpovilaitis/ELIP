<?php
require_once (PATH.'inc/contenttable.php');

class Season extends ContentTable
    {
    public function __construct ($context, $instanceRow)
        {
        parent::__construct ($context, $instanceRow);
        }

    public function canCreateFromLabel ()
        {
        return true;
        }

    public function createFromLabel ($label)
        {
        $start = trim ($label);
        $end = $start;

        $seasonParts = explode ("-", $start, 2);
        if (1 == count ($seasonParts))
            $seasonParts = explode ("/", $start, 2);
        if (2 == count ($seasonParts))
            {
            $start = $seasonParts[0];
            $end = $start + 1;
            }

        $namesToValues = array ("c_start" => $start, "c_end" => $end);
        $id = $this->insertRecord ($namesToValues);
        return $id;
        }

    public function insertRecord ($nameToValue)
        {
        if (!empty ($nameToValue["c_start"]))
            {
            if (empty ($nameToValue["c_end"]))
                $nameToValue["c_end"] = $nameToValue["c_start"];

            if (empty ($nameToValue["c_displayname"]))
                {
                sscanf ($nameToValue["c_start"], "%d", $start);
                sscanf ($nameToValue["c_end"], "%d", $end);

                if ($start == $end)
                    $nameToValue["c_displayname"] = $this->getText ("[_0]|season", $start);
                else
                    $nameToValue["c_displayname"] = $this->getText ("[_0]-[_1]|season",
                                                                    $start,
                                                                    $end,
                                                                    sprintf ("%02d", $end % 100));
                }
            }

        return parent::insertRecord ($nameToValue);
        }
    }

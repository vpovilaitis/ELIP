<?php
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'pages/tools/parseexternalfeed.php');
require_once (PATH.'pages/sports/submitgame.php');

class SyncWithLffFeed extends SyncFeed
    {
    public $months = array ("sausio", "vasario", "kovo", "balandžio", "gegužės", "birželio",
                            "liepos", "rugpjūčio", "rugsėjo", "spalio", "lapkričio", "gruodžio");

    public function getUrl ()
        {
        return "http://www.lff.lt/lt/articles.rss";
        }

    public function retrieveEveryItem ()
        {
        return true;
        }

    public function processEntry ($title, $content, $url, $pubDate, &$log)
        {
        $this->currentUrl = $url;
        $this->currentDate = $pubDate;
        $matches = $this->extractMatchesFromHtml ($content, $log);
        if (!is_array ($matches))
            return $matches;

        $dbtable = ContentTable::createInstanceByName ($this->context, "match");
        // update sourcesdetail table
        foreach ($matches as $id => $match)
            {
            $matchUrl = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $dbtable, $dbtable->getId (), $id);
            $logger = new SyncWithLffFeedLogger ();
            $success = SubmitGame::updateSourceDetailsTable ($this->context, $dbtable, $match, $id, "match-$id", $url, $pubDate, true, $logger);
            foreach ($logger->log as $line)
                $log[] = ($success ? $line : "<b class=\"ui-state-error\">$line</b>")." - <a href=\"$matchUrl\">$id</a>";
            if ($success && !empty ($match["result"]))
                {
                $result = $match["result"];
                $criteria = array (new EqCriterion ($dbtable->getIdColumn (), $id));
                $row = $dbtable->selectSingleBy (array (Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT), $criteria);
                if (empty ($row))
                    $log[] = "<b class=\"ui-state-error\">Did not found a match <a href=\"$matchUrl\">$id</a></b>";
                else if ($row["c_".Sports::COL_MATCH_HOMERESULT] != $result[0] || $row["c_".Sports::COL_MATCH_AWAYRESULT] != $result[1])
                    {
                    $nameValues = array (Sports::COL_MATCH_HOMERESULT => $result[0], Sports::COL_MATCH_AWAYRESULT => $result[1],
                                         DBTable::COL_SOURCE => $url,
                                         DBTable::COL_SOURCEDATE => $pubDate);
                    if (false === $dbtable->updateRecord ($criteria, $nameValues))
                        $log[] = "<b class=\"ui-state-error\">Failed to update match <a href=\"$matchUrl\">$id</a> result</b>";
                    else
                        $log[] = "<i class=\"ui-state-highlight\">Updated match <a href=\"$matchUrl\">$id</a> result</i>";
                    }
                }
            }

        return true;
        }

    public function extractPiece ($content, $startMarker, $endMarker)
        {
        $pos = strpos ($content, $startMarker);
        if (false === $pos)
            return false;

        $pos += strlen ($startMarker);
        $posEnd = strpos ($content, $endMarker, $pos);

        if (false === $posEnd)
            return false;

        return trim (substr ($content, $pos, $posEnd - $pos));
        }

    public function extractMatchesFromHtml ($content, &$log)
        {
        $articleTitle = $this->extractPiece ($content, '<title>', '</title>');
        $articleDate = $this->extractPiece ($content, '<td style="padding-left: 30px;" valign="top">', '<div class="article_date"');
        if (!empty ($articleDate))
            $articleDate = $this->extractPiece ($articleDate, '<span class="article_date">', '</span>');
        $articleText = $this->extractPiece ($content, '<span class="article_text">', '<br style="clear: both"');
        if (false === $articleText)
            return "Failed to parse the article";

        if ($articleDate && preg_match ("#^(20[0-9]{2})[- ]([0-1][0-9])[- ]([0-3][0-9])#", $articleDate, $matches) > 0)
            $articleDate = $matches[1]."-".$matches[2]."-".$matches[3];
        $log[] = "Extracted article text";
        
        $matches = $this->extractMatches (trim ($articleTitle), $articleText, $articleDate, $log);
        return $matches;
        }

    protected function extractMatches ($articleTitle, $articleText, $articleDate, &$log)
        {
        if (empty ($articleDate))
            $articleDate = date ("Y-m-d");

        $articleText = preg_replace ("#</p>\s*<p>#m", "<br /><br />", $articleText);
        $article = preg_split ("#<br />#", $articleText);

        $date = $articleDate;
        $collected = NULL;
        $postfix = NULL;
        $allMatchesFound = array ();
        $months = implode ("|", $this->months);

        $log[] = "Retrieving article";
        if (false != stripos ($articleTitle, "statistik"))
            $log[] = "Statistics";
        if (false != stripos ($articleTitle, "anons"))
            $log[] = "Announcements";
        if (false != stripos ($articleTitle, "dubleri"))
            {
            $log[] = "Reserve teams";
            $postfix = 2;
            }

        foreach ($article as $line)
            {
            $line = str_replace ("&scaron;", "š", $line);
            $line = str_replace ("&Scaron;", "Š", $line);
            $line = str_replace ("&bdquo;", "„", $line);
            $line = str_replace ("&nbsp;", " ", $line);
            $line = str_replace ("&ndash;", "-", $line);
            
            $notags = trim (strip_tags ($line));
            $matchesTime = $matchesDate = NULL;

            if (preg_match ("#^Atidėtos .+ turo rungtynės$#", $notags, $matches) > 0)
                {
                continue;
                }
            if (preg_match ("#^(20[0-9]{2})[- ]([0-1][0-9])[- ]([0-3][0-9])$#", $notags, $matches) > 0)
                {
                $this->parseCollectedLines ($date, $allMatchesFound, $collected, $log, $postfix);

                $date = $matches[1]."-".$matches[2]."-".$matches[3];
                continue;
                }
            else if (preg_match ("#^($months) ([0-9]{1,2}) d.#uUi", $notags, $matchesDate) > 0 || preg_match ("#^($months) mėn\. ([0-9]{1,2}) d.#uUi", $notags, $matchesDate) > 0 || preg_match ("#^.+, ([0-2]?[0-9]\:[0-5][05])$#", $notags, $matchesTime) > 0)
                {
                $this->parseCollectedLines ($date, $allMatchesFound, $collected, $log, $postfix);
                $log[] = "Announcement found - ".$notags;
                if (!empty ($matchesDate))
                    {
                    $month = array_search (utf8_strtolower ($matchesDate[1]), $this->months);
                    if (false === $month)
                        {
                        $log[] = "Unparsable date found - ".$notags;
                        continue;
                        }
                    ++$month;
                    $date = date ('Y', strtotime ($articleDate))."-".($month < 10 ? '0' : '').$month."-".($matchesDate[2] < 10 ? '0' : '').$matchesDate[2];
                    }

                $collected[] = $notags;
                }
            else if (preg_match ("#^<span style=\"text-decoration: underline;\">.+[0-9]\:[0-9]#", $line, $matches) > 0 || preg_match ("#^<span style=\"text-decoration: underline;\">$#", $line, $matches) > 0)
                {
                $this->parseCollectedLines ($date, $allMatchesFound, $collected, $log, $postfix);

                $log[] = "Match statistics found - ".$notags;
                $collected[] = $notags;
                }
            else if (preg_match ("#^([0-9]+)\) ([0-9:]+) .+#", $line, $matches) > 0)
                {
                $this->parseCollectedLines ($date, $allMatchesFound, $collected, $log, $postfix);

                $log[] = "Match announcement found - $notags ($date)";
                $collected[] = $notags;
                }
            else if (empty ($notags))
                {
                $this->parseCollectedLines ($date, $allMatchesFound, $collected, $log, $postfix);
                }
            else if (!empty ($collected))
                $collected[] = $notags;
            }

        $this->parseCollectedLines ($date, $allMatchesFound, $collected, $log, $postfix);

        return $allMatchesFound;
        }

    protected function parseCollectedLines ($date, &$allMatchesFound, &$collected, &$log, $postfix)
        {
        if (empty ($collected))
            return;

        $originalLines = $collected;
        $lineCount = count ($collected);
        $plainStats = implode ("\n", $collected);
        $firstLine = $collected[0];

        $collected = NULL;
        $months = implode ("|", $this->months);
        if (preg_match ("#^($months) ([0-9]{1,2}) d.#uUi", $firstLine, $m) > 0 ||
            preg_match ("#^($months) mėn. ([0-9]{1,2}) d.#uUi", $firstLine, $m) > 0 ||
            preg_match ("#^.+, ([0-2]?[0-9]\:[0-5][05])$#", $firstLine, $m) > 0 ||
            preg_match ("#^([0-9]+)\) ([0-9:]+) .+#", $firstLine, $m) > 0)
            {
            if (1 != $lineCount || is_numeric ($m[1]))
                $this->parseAnnouncement ($date, $originalLines, $firstLine, $log, $postfix);
            return;
            }

        $parser = new SubmitGame ($this->context, NULL);
        $matches = $parser->collectMatches ($date, $plainStats, SubmitGame::TEAMFORMAT_ANY);
        if (empty ($matches))
            {
            $log[] = "<span class=\"ui-state-error\"><b>Failed to parse statistics of the match '$firstLine'</b></span>";
            return;
            }

        foreach ($matches as $match)
            {
            $date = !empty ($match["date"]) ? $match["date"] : date ("Y-m-d");
            list ($homeTeamIds, $awayTeamIds) = $this->findTeams ($date, $match["homeTeam"], $match["awayTeam"], $postfix);
            if (empty ($homeTeamIds))
                {
                $log[] = "<span class=\"ui-state-error\"><b>Did not found team '{$match["homeTeam"]}'</b></span>";
                return;
                }
            if (empty ($awayTeamIds))
                {
                $log[] = "<span class=\"ui-state-error\"><b>Did not found team '{$match["awayTeam"]}'</b></span>";
                return;
                }

            // search for the match by teams
            $matchId = $this->findMatch ($date, $homeTeamIds, $awayTeamIds);

            //echo "<pre>\n\n\n".json_encode ($match)."</pre>";

            if (empty ($matchId))
                $log[] = "<span class=\"ui-state-error\"><b>Did not found any match on $date for '{$match["homeTeam"]}' vs '{$match["awayTeam"]}'</b></span>";
            else if (1 != count ($matchId))
                $log[] = "<span class=\"ui-state-error\"><b>Found several matches on $date for '{$match["homeTeam"]}' vs '{$match["awayTeam"]}'</b></span>";
            else
                $allMatchesFound[$matchId[0]] = $match;
            }
        }

    protected function parseAnnouncement ($date, $lines, $label, &$log, $postfix)
        {
        $dateTime = $date;
        $stadium = $referees = $number = NULL;
        $homeTeam = $awayTeam = NULL;
        foreach ($lines as $line)
            {
            if (preg_match ("#^(.{3,10}) mėn. ([0-9]{1,2}) d.( \([a-zščį]+\))?$#uUi", $line, $m) > 0)
                continue;

            if (preg_match ("#^([0-9]+)\) ([0-9:]+) (.+) - (.+)( \((.+)\))$#", $line, $m) > 0 ||
                preg_match ("#^([0-9]+)\) ([0-9:]+) (.+) - (.+)$#", $line, $m) > 0)
                {
                $dateTime = $date." ".$m[2];
                $stadium = count ($m) > 6 ? $m[6] : NULL;
                $homeTeam = SubmitGame::cleanTeamName ($m[3], true);
                $awayTeam = SubmitGame::cleanTeamName ($m[4], false);
                $number = $m[1];
                }
            else if (preg_match ("#^(.+), ([0-2]?[0-9]\:[0-5][05])$#", $line, $matchesTime) > 0)
                {
                $stadium = $matchesTime[1];
                $dateTime = $date." ".$matchesTime[2];
                }
            else if (preg_match ("#^Teisėjai - (.+)$#", $line, $m) > 0)
                {
                $referees = $m[1];
                }
            else if (preg_match ("#^(.+) - (.+)$#", $line, $m) > 0)
                {
                $homeTeam = SubmitGame::cleanTeamName ($m[1], true);
                $awayTeam = SubmitGame::cleanTeamName ($m[2], false);
                }
            else
                $log[] = "Announcement line $line <b class=\"ui-state-error\">was not recognized</b>";
            }

        $log[] = "<i class=\"ui-state-highlight\">Announcement parsed as $dateTime $homeTeam - $awayTeam at $stadium, ref. $referees</i>";
        list ($homeTeamIds, $awayTeamIds) = $this->findTeams ($date, $homeTeam, $awayTeam, $postfix);
        if (empty ($homeTeamIds))
            {
            $log[] = "<span class=\"ui-state-error\"><b>Did not found team '{$homeTeam}'</b></span>";
            return;
            }
        if (empty ($awayTeamIds))
            {
            $log[] = "<span class=\"ui-state-error\"><b>Did not found team '{$awayTeam}'</b></span>";
            return;
            }

        // search for the match by teams
        $matches = $this->findMatch ($date, $homeTeamIds, $awayTeamIds, true);
        if (empty ($matches))
            $log[] = "<b class=\"ui-state-error\">No match entry found</b> for announcement ($label)";
        else if (count ($matches) > 1)
            $log[] = "<b class=\"ui-state-error\">Too many match entries found</b> for announcement ($label)";
        else
            {
            $row = $matches[0];
            if (trim ($row[Sports::COL_MATCH_DATE], " 0:") != trim ($dateTime, " 0:") || !empty ($stadium))
                {
                $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
                $criteria[] = new EqCriterion (Sports::COL_MATCH_DATE, $row[Sports::COL_MATCH_DATE]);
                $criteria[] = new EqCriterion ($matchesTable->getIdColumn (), $row["id"]);
                $matchUrl = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $matchesTable,
                                                                     $matchesTable->getId (), $row["id"]);
                $namesToValues = array ();
                if (trim ($row[Sports::COL_MATCH_DATE], " 0:") != trim ($dateTime, " 0:"))
                    $namesToValues[Sports::COL_MATCH_DATE] = $dateTime;

                $stadium = $this->findStadium ($stadium, $log);
                if (!empty ($stadium))
                    {
                    $stadiumColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STADIUM, Sports::TABLE_STADIUM."_id");
                    if ($row[Sports::COL_MATCH_STADIUM] != $stadium)
                        $namesToValues[$stadiumColumn] = $stadium;
                    }

                if (!empty ($namesToValues))
                    {
                    $namesToValues[DBTable::COL_SOURCE] = $this->currentUrl;
                    $namesToValues[DBTable::COL_SOURCEDATE] = $this->currentDate;
                    if (false === $matchesTable->updateRecord ($criteria, $namesToValues))
                        $log[] = "<b class=\"ui-state-error\">Failed to update time</b> for announcement (<a href=\"$matchUrl\">$label</a>)";
                    else
                        $log[] = "<i class=\"ui-state-highlight\">Updated time</i> (from {$row[Sports::COL_MATCH_DATE]} to $dateTime) for announcement (<a href=\"$matchUrl\">$label</a>)";
                    }
                }
            }

        // $plainStats = implode ("\n", $lines);
        }

    private $cachedMatches = array ();
    protected function getMatchesByDate ($date, $aproximateDays = 0)
        {
        if (isset ($this->cachedMatches[$date."-".$aproximateDays]))
            return $this->cachedMatches[$date."-".$aproximateDays];

        $dateStart = $dateEnd = $date;
        if ($aproximateDays > 0)
            {
            $dateStart = date ("Y-m-d H:i", strtotime ("-$aproximateDays days", strtotime ($date)));
            $dateEnd = date ("Y-m-d H:i", strtotime ("+$aproximateDays days", strtotime ($date)));
            }

        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $homeTeamColumn = "f_".Sports::COL_MATCH_HOMETEAM."_".Sports::TABLE_TEAM."_id";
        $awayTeamColumn = "f_".Sports::COL_MATCH_AWAYTEAM."_".Sports::TABLE_TEAM."_id";
        $stadiumColumn = "f_".Sports::COL_MATCH_STADIUM."_".Sports::TABLE_STADIUM."_id";
        $criteria[] = new GtEqCriterion ("c_".Sports::COL_MATCH_DATE, $dateStart." 00:00:00");
        $criteria[] = new LtEqCriterion ("c_".Sports::COL_MATCH_DATE, $dateEnd." 23:59:59");
        $rows = $matchesTable->selectBy (array ($matchesTable->getIdColumn (), $homeTeamColumn, $awayTeamColumn, Sports::COL_MATCH_DATE, $stadiumColumn ), $criteria);
        $matches = array ();
        if (!empty ($rows))
            {
            foreach ($rows as $row)
                {
                $m = array ("id" => $row[$matchesTable->getIdColumn ()],
                            Sports::COL_MATCH_HOMETEAM => $row[$homeTeamColumn],
                            Sports::COL_MATCH_AWAYTEAM => $row[$awayTeamColumn],
                            Sports::COL_MATCH_DATE => $row["c_".Sports::COL_MATCH_DATE],
                            Sports::COL_MATCH_STADIUM => $row[$stadiumColumn]);
                $matches[] = $m;
                }
            }

        $this->cachedMatches[$date."-".$aproximateDays] = $matches;
        return $this->cachedMatches[$date."-".$aproximateDays];
        }

    protected function findTeams ($date, $homeTeamLabel, $awayTeamLabel, $postfix)
        {
        return array ($this->findTeam ($date, $homeTeamLabel, $postfix), $this->findTeam ($date, $awayTeamLabel, $postfix));
        }

    private $cachedTeams = NULL;
    private $cachedCupTeams = NULL;
    protected function findTeam ($date, $name, $postfix = NULL)
        {
        if (NULL === $this->cachedTeams)
            {
            $this->cachedTeams = $this->collectTeamNames ($date, Sports::TABLE_TEAMLEAGUESEASON, Sports::COL_TEAMLEAGUESEASON_COMPETITION);
            // don't mix league and cup teams (league teams are more used and huge cup participant list will only confuse system)
            $this->cachedCupTeams = $this->collectTeamNames ($date, Sports::TABLE_TEAMCUPSEASON, Sports::COL_TEAMCUPSEASON_COMPETITION);
            }

        $name = trim ($name);
        $city = array ();
        $prefix = NULL;
        if (preg_match ("#^(.+) \((.+)\)$#", $name, $m) > 0 && $m[1] == $m[2])
            {
            $name = $m[1];
            }

        if ("Šiauliai" == $name)
            {
            $prefix = "FK";
            $city[] = $name;
            }
        if (preg_match ("#^([A-Z]{2,4}) (.+) \((.+)\)$#", $name, $m) > 0)
            {
            $prefix = $m[1];
            $label = $m[2];
            $name = $prefix." ".$label;
            if ("Vilniaus dailės akademija" == $m[3])
                {
                $prefix = "VDA";
                }
            else
                $city[] = $m[3];
            }
        else if (preg_match ("#^([A-Z]{2,4}) \((.+)\)$#", $name, $m) > 0)
            {
            $label = $prefix = $m[1];
            $city[] = $m[2];
            }
        else if (preg_match ("#^(.+) \((.+)\)$#", $name, $m) > 0)
            {
            $label = $name = $m[1];
            $city[] = $m[2];
            }
        else if (preg_match ("#^([A-Z]{2,4}) (.+)$#", $name, $m) > 0)
            {
            $prefix = $m[1];
            $label = $m[2];
            }
        else if (preg_match ("#^Vilnia?us (.+)$#", $name, $m) > 0)
            {
            $label = $m[1];
            $city[] = "Vilnius";
            }
        else
            {
            $label = $name;
            }

        $parts = preg_split ("#\s+#", $label);
        if (empty ($prefix) && preg_match ("#^([A-Z]{2,4})-(.+)$#", $label, $m) > 0)
            {
            $prefix = $m[1];
            $label = array ($label, $name, $m[2]);
            }
        else if (count ($parts) > 1)
            {
            $label = array_merge (array ($label, $name), $parts);
            }
        else
            $label = array ($label, $name);

        if ("Šiauliai" != $name && 2 == strlen ($prefix) && 'F' == $prefix[0])
            $prefix = NULL;

        $foundTeams = array ();

        // check $cachedTeams
        foreach ($this->cachedTeams as $row)
            {
            if (!empty ($city))
                {
                if ($this->array_levenshtein ($city, $row[ContentTable::PREFIX.Sports::COL_TEAM_CITY]) > 3)
                    continue;
                }

            if (!empty ($postfix) && $row[ContentTable::PREFIX.Sports::COL_TEAM_POSTFIX] != $postfix)
                {
                if (!empty ($row[Sports::COL_TEAM_POSTFIX]))
                continue;
                }

            $prefixMatch = $labelMatch = false;
            if (!empty ($prefix) && !empty ($row[ContentTable::PREFIX.Sports::COL_TEAM_PREFIX]))
                {
                if ($prefix != $row["c_".Sports::COL_TEAM_PREFIX])
                    continue;
                $prefixMatch = true;
                }

            if (!empty ($row[ContentTable::PREFIX.Sports::COL_TEAM_NAME]) && !empty ($label))
                {
                if ($this->array_levenshtein ($label, $row[ContentTable::PREFIX.Sports::COL_TEAM_NAME]) > 3)
                    continue;
                $labelMatch = true;
                }

            if ($prefixMatch || $labelMatch)
                $foundTeams[$row[Sports::TABLE_TEAM."_id"]] = $row;
            }

        if (empty ($foundTeams))
            {
            return false;
            }

        $ids = array ();
        foreach ($foundTeams as $id => $team)
            $ids[] = $id;
        return $ids;
        }

    protected function array_levenshtein ($arr, $label)
        {
        $min = false;
        foreach ($arr as $s)
            {
            $val = levenshtein ($s, $label);
            if (false === $min || $val < $min)
                $min = $val;
            }
        return $min;
        }

    protected function collectTeamNames ($date, $tableName, $columnName)
        {
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $leaguesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        $leagueSeasonsTable = ContentTable::createInstanceByName ($this->context, $tableName);

        $leagueSeasonColumn = "f_{$columnName}_".$leaguesTable->getIdColumn ();
        $joinCriteria = array (new JoinColumnsCriterion ($leagueSeasonColumn, $leaguesTable->getIdColumn ()));
        $joinCriteria[] = new LtEqCriterion ("c_".Sports::COL_COMPETITION_STARTS, $date);
        $joinCriteria[] = new GtEqCriterion ("c_".Sports::COL_COMPETITION_ENDS, $date);
        $joins[] = $leaguesTable->createQuery (array (), $joinCriteria);

        $teamIds = array ();
        $rows = $leagueSeasonsTable->selectBy (array ($teamsTable->getIdColumn ()), NULL, $joins);
        if (empty ($rows))
            return array ();

        foreach ($rows as $row)
            $teamIds[] = $row[$teamsTable->getIdColumn ()];

        $teamCriteria[] = new InCriterion ($teamsTable->getIdColumn (), $teamIds);
        $teamCriteria[] = new IsNotNullCriterion ("c_".Sports::COL_TEAM_CITY);
        $teamRows = $teamsTable->selectBy (array ($teamsTable->getIdColumn (), Sports::COL_TEAM_PREFIX, Sports::COL_TEAM_POSTFIX, Sports::COL_TEAM_NAME, Sports::COL_TEAM_CITY, Sports::COL_TEAM_SHORTNAME), $teamCriteria);

        if (empty ($teamRows))
            return false;

        return $teamRows;
        }

    protected function findMatch ($date, $team1, $team2, $fullRows = false)
        {
        for ($i = 0; $i < 3; $i++)
            {
            $allMatches = $this->getMatchesByDate ($date, $i*2);
            $found = array ();
            if (!empty ($allMatches))
                {
                foreach ($allMatches as $match)
                    {
                    $homeTeam = $match[Sports::COL_MATCH_HOMETEAM];
                    $awayTeam = $match[Sports::COL_MATCH_AWAYTEAM];
                    if (false !== array_search ($homeTeam, $team1) && false !== array_search ($awayTeam, $team2))
                        $found[] = $fullRows ? $match : $match["id"];
                    }
                }

            if (!empty ($found) || !$fullRows)
                break;
            }

        return $found;
        }

    protected function findStadium ($stadium, &$log)
        {
        if (empty ($stadium))
            return NULL;

        $list = array
            (
            "PFA" => array ("Panevėžys", NULL, "futbolo akademijos dirbtinės dangos aikštė"),
            "Panevėžio FA" => array ("Panevėžys", NULL, "futbolo akademijos dirbtinės dangos aikštė"),
            "Gargžd" => array ("Gargždai", NULL, "miesto stadionas"),
            "Druskinink" => array ("Druskininkai", NULL, "dirbtinės dangos"),
            "Gytarių" => array ("Šiauliai", "Gytarių", NULL),
            "Tauragės senasis" => array ("Tauragė", "Senasis", NULL),
            "Senasis Tauragės" => array ("Tauragė", "Senasis", NULL),
            "Marijampolės ARVI arena" => array ("Marijampolė", "Arvi", "arena"),
            "LFF stadionas" => array ("Vilnius", NULL, "LFF stadionas"),
            "Sportim" => array ("Vilnius", "Sportimos", NULL),
            );

        $found = NULL;
        foreach ($list as $key => $entry)
            {
            if (false === stripos ($stadium, $key))
                continue;
            $found = $entry;
            break;
            }

        if (empty ($found))
            {
            $log[] = "<b class=\"ui-state-error\">Failed to recognize stadium $stadium</b>";
            return false;
            }

        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_STADIUM);
        if (!empty ($entry[0]))
            $criteria[] = new EqCriterion (Sports::COL_STADIUM_CITY, $entry[0]);
        if (!empty ($entry[1]))
            $criteria[] = new EqCriterion (Sports::COL_STADIUM_NAME, $entry[1]);
        if (!empty ($entry[2]))
            $criteria[] = new EqCriterion (Sports::COL_STADIUM_TYPE, $entry[2]);
        $row = $dbtable->selectSingleBy (array ($dbtable->getIdColumn ()), $criteria);
        if (empty ($row))
            {
            $log[] = "<b class=\"ui-state-error\">Failed to find stadium $stadium</b>";
            return false;
            }

        return $row[$dbtable->getIdColumn ()];
        }
    }

class SyncWithLffFeedLogger
    {
    public $log = array ();

    public function writeLine ($line)
        {
        $this->log[] = $line;
        }
    }

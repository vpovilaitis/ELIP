<?php
require_once (PATH.'inc/contenttable.php');

class LeagueSeasonNameTransformation extends ValueTransformation
    {
    protected $nameTransform;
    protected $seasonTransform;
    protected $stageTransform;

    public function __construct ($nameTransform, $stageTransform, $seasonTransform)
        {
        parent::__construct (ContentTable::prepareUserColumnName ("level"));
        $this->nameTransform = $nameTransform;
        $this->stageTransform = $stageTransform;
        $this->seasonTransform = $seasonTransform;
        }

    public function getValue ($context, $transformations, $row)
        {
        $level = parent::getValue ($context, $transformations, $row);
        $name = $this->nameTransform->getValue ($context, $transformations, $row);
        $season = $this->seasonTransform->getValue ($context, $transformations, $row);

        if (!empty ($this->stageTransform))
            $stage = $this->stageTransform->getValue ($context, $transformations, $row);
        else
            $stage = NULL;

        return $this->getDescription ($context, $level, $name, $season, $stage);
        }

    protected function getDescription ($context, $level, $name, $season, $stage)
        {
        if (!empty ($stage) && !empty ($level))
            return $context->getText ("Season [_0] - level [_1] ([_2] [_3])",
                                      empty ($season) ? " " : $season,
                                      $level, $name, $stage);
        else if (!empty ($stage))
            return $context->getText ("Season [_0] - [_1] ([_2])",
                                      empty ($season) ? " " : $season,
                                      $name, $stage);
        else if (!empty ($level))
            return $context->getText ("Season [_0] - level [_1] ([_2])",
                                      empty ($season) ? " " : $season,
                                      $level, $name);
        else
            return $context->getText ("Season [_0] - [_1]",
                                      empty ($season) ? " " : $season,
                                      $name);
        }

    public function adjust ($columnPrefix)
        {
        parent::adjust ($columnPrefix);
        $this->nameTransform->adjust ($columnPrefix);
        $this->seasonTransform->adjust ($columnPrefix."season_");
        if (!empty ($this->stageTransform))
            $this->stageTransform->adjust ($columnPrefix);
        }
    }

class LeagueSeason extends ContentTable
    {
    protected $levelColumnName = NULL;
    protected $stageColumnName = NULL;

    protected function getDisplayNameColumns ($displayNameColumn)
        {
        if (NULL === $this->levelColumnName)
            {
            $col = $this->findColumn ("level");
            if (!empty ($col))
                $this->levelColumnName = $col->columnDef->name;
            }

        if (NULL === $this->stageColumnName)
            {
            $col = $this->findColumn ("stagelabel");
            if (!empty ($col))
                $this->stageColumnName = $col->columnDef->name;
            }

        $arr = parent::getDisplayNameColumns ($displayNameColumn);
        $arr[] = "season";

        if (!empty ($this->levelColumnName))
            $arr[] = $this->levelColumnName;
        if (!empty ($this->stageColumnName))
            $arr[] = $this->stageColumnName;
        return $arr;
        }

    protected function createTransformation ($nameTransform, $stageTransform, $seasonTransform)
        {
        return new LeagueSeasonNameTransformation ($nameTransform, $stageTransform, $seasonTransform);
        }

    public function createDisplayNameQuery ($name, $resultColumns, $criteria, $displayNameColumn, $joins = NULL, $params = NULL)
        {
        $this->log ("LeagueSeason::createDisplayNameQuery");
        $query = parent::createDisplayNameQuery ($name, $resultColumns, $criteria, $displayNameColumn, $joins, $params);
        if (empty ($query))
            return NULL;

        if (!empty ($name))
            $name .= "_";
        $seasonNameTransform = NULL;
        foreach ($query->getJoinedQueries () as $join)
            {
            if ($join->tableAlias == "{$name}season")
                {
                $seasonNameTransform = $join->transformations[ContentTable::COL_DISPLAY_NAME];
                break;
                }
            }

        $stageTransform = NULL;
        if (!empty ($this->stageColumnName))
            {
            $subquery = $query->getTranslatableColumnSubquery ();
            if (isset ($subquery->transformations[$this->stageColumnName]))
                $stageTransform = $subquery->transformations[$this->stageColumnName];
            }

        $transform = $this->createTransformation ($query->transformations[ContentTable::COL_DISPLAY_NAME],
                                                  $stageTransform,
                                                  $seasonNameTransform);
        unset ($query->transformations[ContentTable::COL_DISPLAY_NAME]);
        $query->transformations[ContentTable::COL_DISPLAY_NAME] = $transform;
        return $query;
        }

    }
?>

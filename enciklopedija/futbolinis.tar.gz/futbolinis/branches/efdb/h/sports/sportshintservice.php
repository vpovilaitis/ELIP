<?php
require_once (PATH.'inc/defaulthintservice.php');
require_once (PATH.'inc/sports/constants.php');

class SportsHintService extends DefaultHintService
    {
    protected function getPredefinedEditProposal ($table, $contextId)
        {
        return parent::getPredefinedEditProposal ($table, $contextId);
        }

    protected function getPredefinedEditorViewHint ($table, $contextId)
        {
        $hints = parent::getPredefinedEditorViewHint ($table, $contextId);
        switch ($table)
            {
            case Sports::TABLE_MATCH:
                $hints[] = self::composeHint ($this->getText ("Need any editing advice?"),
                                              $this->getText ("There are several ways to enter match information. Most powerfull is \"Protocol editor\" (link is located just above this hint) - it allows entering match score, players, coaches, events, goals referees. If you need to alter a score or enter attendance, there is \"Edit\" for simple editing. One more way to enter data - edit separate parts of the match by clicking editor icon (blank page with a pen) in various sections (there are sections for referees, goals, event, players)."));
                break;
            }

        return $hints;
        }
    }

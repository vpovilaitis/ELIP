<?php
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/sports/constants.php');

class StadiaTable extends ContentTable
    {
    protected function createFilterColumn ($sortColumns)
        {
        return new StadiumFilterColumn ($this, $this->displayNameColumn, $sortColumns);
        }

    protected function selectForIndexing ($columns, $ids)
        {
        $columns = array ($this->getIdColumn (), "country", "capacity", "founded", "primary", "city", "name", "type", "address", "description", DBTable::COL_UPDATEDON, DBTable::COL_CREATEDON);
        return parent::selectForIndexing ($columns, $ids);
        }

    protected function indexSingleRow ($row)
        {
        $indexed = parent::indexSingleRow ($row);
        if (empty ($row["c_type"]) && empty ($row["c_name"]))
            {
            // cities without specified stadium are not so important in search
            $indexed['indexedLabel'] = " ";
            }
        return $indexed;
        }
    }

class StadiumFilterColumn extends FilterColumn
    {
    protected $context;

    public function __construct ($dbtable, $displayNameColumn, $sortColumns)
        {
        parent::__construct ($dbtable, $displayNameColumn, $sortColumns);
        $this->context = $dbtable->getContext ();
        }

    public function prepareQuery ($filterCriterion, &$criteria, &$joins, &$params = NULL)
        {
        $filterBy = trim ($filterCriterion->criterion);
        if (preg_match ("#^(.*\s+)?„(.+)“( (.+))?$#u", $filterBy, $filterMatches) > 0)
            {
            // ;
            if (!empty ($filterMatches[1]))
                $criteria[] = new LikeCriterion ("c_".Sports::COL_STADIUM_CITY, trim ($filterMatches[1]));

            $criteria[] = new LikeCriterion ("c_".Sports::COL_STADIUM_NAME, $filterMatches[2]);

            if (!empty ($filterMatches[4]))
                $criteria[] = new LikeCriterion ("c_".Sports::COL_STADIUM_TYPE, $filterMatches[4]);
            return;
            }

        $likeCriteria = array ();
        foreach (array (Sports::COL_STADIUM_NAME, Sports::COL_STADIUM_TYPE, Sports::COL_STADIUM_CITY) as $col)
            {
            $likeCriteria[] = new LikeCriterion ("c_".$col, $filterBy);
            }

        $parts = explode (" ", $filterBy, 2);
        if (2 == count ($parts))
            {
            $likeCriteria[] = new LogicalOperatorAnd
                (
                new LikeCriterion ("c_".Sports::COL_STADIUM_CITY, trim ($parts[0], " .,")),
                new LikeCriterion ("c_".Sports::COL_STADIUM_NAME, trim ($parts[1], " .,"))
                );
            $likeCriteria[] = new LogicalOperatorAnd
                (
                new LikeCriterion ("c_".Sports::COL_STADIUM_CITY, trim ($parts[0], " .,")),
                new LikeCriterion ("c_".Sports::COL_STADIUM_TYPE, trim ($parts[1], " .,"))
                );
            $likeCriteria[] = new LogicalOperatorAnd
                (
                new LikeCriterion ("c_".Sports::COL_STADIUM_NAME, trim ($parts[0], " .,")),
                new LikeCriterion ("c_".Sports::COL_STADIUM_TYPE, trim ($parts[1], " .,"))
                );
            }

        $criteria[] = new LogicalOperatorOr ($likeCriteria);
        }

    }

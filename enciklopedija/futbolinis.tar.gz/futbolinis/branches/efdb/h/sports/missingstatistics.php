<?php
require_once (PATH."inc/sports/constants.php");

class MissingStatistics extends EditorTask
    {
    public function getTime ()
        {
        return 15;
        }

    public function getName ()
        {
        return $this->getText ("Missing match statistics");
        }

    public function getNameWithCount ()
        {
        $count = $this->getRemainingCount ();
        if (empty ($count))
            return $this->getText ("No missing match statistics");
        if ($count >= self::LIMIT)
            return $this->ngettext ("More than [_0] missing match statistics", "More than [_0] missing match statistics", $count);
        return $this->ngettext ("[_0] missing match statistics", "[_0] missing match statistics", $count);
        }

    public function getTitle ()
        {
        return $this->getText ("Submit match statistics found in external sites.");
        }

    public function getDetailedDescription ()
        {
        return $this->getText ("This information will be later processed by the system with the help of other volunteers.");
        }

    public function getSortingSetting ()
        {
        return EditorTask::SORT_DESCENDING;
        }

    public function getInstructions ()
        {
        return $this->getText ("To enter the required information,
*select the match you wish to update
*click on the provided link,
*enter match date
*copy match statistics from external site and paste into the opened form,
*click <b>Check</b> to see if statistics are recognized by the system,
*resolve teams (if exclamation mark is shown next to the team),
*Press <b>Save</b>.");
        }

    public function getCacheContext ()
        {
        return Sports::TABLE_MATCH;
        }

    public function selectTasks ($rowsToCollect)
        {
        $context = $this->context;
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $sourceDetailsTable = new SourcesDetailTable ($context);
        if (empty ($matchesTable))
            return false;

        $criteria[] = new GtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d H:i", time() - /*1 month*/ 30 * 24 * 60 * 60));
        $criteria[] = new LtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d H:i", time() - /*1 hour*/60 * 60));
        $rows = $matchesTable->selectBy (array ($matchesTable->getIdColumn (), Sports::COL_MATCH_COMPETITION, Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT, Sports::COL_MATCH_OUTCOME), $criteria);
        if (empty ($rows))
            return NULL;

        $matchIds = array ();
        $matchesWithoutResult = array ();
        $excludedCompetitions = COMPETITIONS_TO_EXCLUDE;
        $excludedCompetitions = empty ($excludedCompetitions) ? array () : preg_split ("/[,;]\s*/", COMPETITIONS_TO_EXCLUDE);
        foreach ($rows as $row)
            {
            $competitionId = $row[Sports::COL_MATCH_COMPETITION];
            if (!empty ($competitionId) && false !== array_search ($competitionId[0], $excludedCompetitions))
                {
                continue;
                }

            $outcome = $row["c_".Sports::COL_MATCH_OUTCOME];
            $id = $row[$matchesTable->getIdColumn ()];
            if (NULL !== $row["c_".Sports::COL_MATCH_HOMERESULT] && NULL !== $row["c_".Sports::COL_MATCH_AWAYRESULT])
                {
                if (MatchConstants::OUTCOME_TECHNICAL_WIN == $outcome || MatchConstants::OUTCOME_NO_HOME_TEAM == $outcome || MatchConstants::OUTCOME_NO_VISITORS == $outcome)
                    continue;
                $matchGoalCounts[$id] = $row["c_".Sports::COL_MATCH_HOMERESULT] + $row["c_".Sports::COL_MATCH_AWAYRESULT];
                $matchIds[] = $id;
                }
            else
                $matchesWithoutResult[] = $id;
            }

        if (!empty ($matchIds))
            {
            $tableName = $matchesTable->getTableName ();
            $criteria = NULL;
            $criteria[] = new EqCriterion (SourcesDetailTable::COL_SCOPE, $tableName);
            $criteria[] = new InCriterion (SourcesDetailTable::COL_CONTEXTID, $matchIds);
            $rows = $sourceDetailsTable->selectBy (array (SourcesDetailTable::COL_CONTEXTID), $criteria);
            if (!empty ($rows))
                {
                foreach ($rows as $row)
                    $ids[] = $row[SourcesDetailTable::COL_CONTEXTID];
                $matchIds = array_diff ($matchIds, $ids);
                }
            }

        // remove matches with goals and/or cards already entered
        foreach (array (Sports::TABLE_MATCHGOAL, Sports::TABLE_MATCHEVENT) as $tableName)
            {
            if (empty ($matchIds))
                continue;

            $childTable = ContentTable::createInstanceByName ($context, $tableName);
            $criteria = array (new InCriterion ($matchesTable->getIdColumn (), $matchIds));
            $rows = $childTable->selectBy (array ($matchesTable->getIdColumn (), new FunctionCount ("*", "cnt")), $criteria, NULL, array (new GroupByAll()));
            if (empty ($rows))
                continue;

            foreach ($rows as $row)
                {
                $id = $row[$matchesTable->getIdColumn ()];
                if (Sports::TABLE_MATCHGOAL == $tableName && $matchGoalCounts[$id] != $row["cnt"]) // some goals missing
                    continue;
                if (Sports::TABLE_MATCHEVENT == $tableName && 0 != $matchGoalCounts[$id])
                    continue;
                $ids[] = $id;
                }
            $matchIds = array_diff ($matchIds, $ids);
            }

        if (!empty ($matchesWithoutResult))
            $matchIds = array_merge ($matchIds, $matchesWithoutResult);

        if (empty ($matchIds))
            return NULL;

        $columns = array ($matchesTable->getIdColumn ());
        $criteria = array (new InCriterion ($matchesTable->getIdColumn (), $matchIds));
        $rows = $matchesTable->selectWithDisplayName ($columns, $criteria);
        if (empty ($rows))
            return NULL;

        $result = array ();
        foreach ($rows as $row)
            {
            $id = $row[$matchesTable->getIdColumn ()];
            $url = $this->context->processUrl ("index.php?c=sports/PrepareMatchDetails&matchId=$id", true);
            $result[] = array (
                "url" => $url,
                "name" => $row[ContentTable::COL_DISPLAY_NAME],
                );
            }

        return $result;
        }

    }

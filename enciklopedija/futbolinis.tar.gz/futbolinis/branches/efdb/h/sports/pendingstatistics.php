<?php
require_once (PATH."inc/sports/constants.php");

class PendingStatistics extends EditorTask
    {
    
    public function getTime ()
        {
        return 7;
        }

    public function getName ()
        {
        return $this->getText ("Pending match statistics");
        }

    public function getNameWithCount ()
        {
        $count = $this->getRemainingCount ();
        if (empty ($count))
            return $this->getText ("No pending statistics");
        if ($count >= self::LIMIT)
            return $this->ngettext ("More than [_0] pending statistics", "More than [_0] pending statistics", $count);
        return $this->ngettext ("[_0] pending statistics", "[_0] pending statistics", $count);
        }

    public function getTitle ()
        {
        return $this->getText ("Help system to process retrieved match statistics.");
        }

    public function getDetailedDescription ()
        {
        return $this->getText ("This information is used in league page to display top goal scorers, yellow cards.");
        }

    public function getSortingSetting ()
        {
        return EditorTask::SORT_ASCENDING;
        }

    public function getInstructions ()
        {
        return $this->getText ("To enter the required information,
*select the match you wish to update
*click on the provided link,
*wait till the system prepares statistics for saving,
*if there are any conflicts found (diplayed with red exclamation mark), resolve those conflicts by selecting the player from suggested list or by creating player record,
*Press <b>Save</b>.");
        }

    public function getCacheContext ()
        {
        return Sports::TABLE_MATCH;
        }

    public function selectTasks ($rowsToCollect)
        {
        $context = $this->context;
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $sourceDetailsTable = new SourcesDetailTable ($context);
        if (empty ($matchesTable))
            return false;

        $tableName = $matchesTable->getTableName ();
        $criteria[] = new EqCriterion (SourcesDetailTable::COL_SCOPE, $tableName);
        $criteria[] = new EqCriterion (SourcesDetailTable::COL_STATE, SourcesDetailTable::STATE_PENDING);
        $rows = $sourceDetailsTable->selectBy (array (SourcesDetailTable::COL_ID, SourcesDetailTable::COL_CONTEXTID), $criteria, NULL, array (new LimitResults (0, $rowsToCollect)));
        $ids = array ();
        if (empty ($rows))
            return NULL;

        foreach ($rows as $row)
            $ids[$row[SourcesDetailTable::COL_CONTEXTID]] = $row[SourcesDetailTable::COL_ID];

        $columns = array ($matchesTable->getIdColumn ());
        $criteria = array (new InCriterion ($matchesTable->getIdColumn (), array_keys ($ids)));
        $rows = $matchesTable->selectWithDisplayName ($columns, $criteria);
        if (empty ($rows))
            return NULL;

        $result = array ();
        foreach ($rows as $row)
            {
            $id = $ids[$row[$matchesTable->getIdColumn ()]];
            $url = $this->context->processUrl ("index.php?c=sports/SubmitPendingStats&id=$id&skip=1", true);
            $result[] = array (
                "url" => $url,
                "name" => $row[ContentTable::COL_DISPLAY_NAME],
                );
            }

        return $result;
        }

    }

<?php
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/sports/constants.php');

class ClubsTable extends ContentTable
    {
    protected function selectForIndexing ($columns, $ids)
        {
        $columns = array ($this->getIdColumn (), "country", "name", "fed_name", "fullname", "president", "founded", "closed", "description", DBTable::COL_UPDATEDON, DBTable::COL_CREATEDON);
        return parent::selectForIndexing ($columns, $ids);
        }

    protected function indexSingleRow ($row)
        {
        if (empty ($row["c_fed_name"]))
            return NULL;

        return parent::indexSingleRow ($row);
        }

    }

<?php
require_once (PATH.'inc/popupservice.php');
require_once (PATH.'inc/sports/constants.php');

class CreateMatchPopup extends PopupService
    {
    protected $dbtable;
    protected $existingRow;

    public function __construct ($context)
        {
        parent::__construct ($context);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        }

    protected function checkAccess ($request)
        {
        return !empty ($this->dbtable) && $this->dbtable->canCreate ();
        }

    protected function getFields ($request)
        {
        $action = empty ($request["action"]) ? NULL : $request["action"];
        $stadiumTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_STADIUM);
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $criteria[] = new EqCriterion ($matchesTable->getIdColumn (), $id);
            $columns = array (Sports::COL_MATCH_DATE, Sports::COL_MATCH_STADIUM, Sports::COL_MATCH_MATCHDAY, Sports::COL_MATCH_NUMBER);
            $row = $this->dbtable->selectSingleBy ($columns, $criteria);
            if (empty ($row))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $this->existingRow = array (Sports::COL_MATCH_DATE => $row[ContentTable::PREFIX.Sports::COL_MATCH_DATE],
                                        Sports::COL_MATCH_MATCHDAY => $row[ContentTable::PREFIX.Sports::COL_MATCH_MATCHDAY],
                                        Sports::COL_MATCH_STADIUM => $row[Sports::COL_MATCH_STADIUM.".".ContentTable::COL_DISPLAY_NAME],
                                        Sports::COL_MATCH_NUMBER => $row[ContentTable::PREFIX.Sports::COL_MATCH_NUMBER]);
            }

        $competitionId = empty ($request["comp"]) ? NULL : $request["comp"];
        $nextNumber = NULL;
        if (!empty ($competitionId))
            {
            $columns = array ();
            $columns[] = new FunctionCount ("*", "cnt");
            $columns[] = new FunctionMax ("c_".Sports::COL_MATCH_NUMBER, "maxNo");
            $columns[] = new ConditionalSumColumn ("sumNo", "c_".Sports::COL_MATCH_NUMBER." > 0", 1, 0);
            $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
            $criteria = array (new EqCriterion ($competitionIdColumn, $competitionId));
            $row = $matchesTable->selectSingleBy ($columns, $criteria);
            if (!empty ($row))
                {
                if (empty ($row["sumNo"]))
                    $row["sumNo"] = 0;
                if ($row["sumNo"] > 0)
                    $nextNumber = empty ($row["maxNo"]) ? 1 : $row["maxNo"] + 1;
                }
            }

        $fields = array ();
        if ("edit" != $action)
            $fields[] = new PopupAutocompleteField ("", Sports::COL_MATCH_STADIUM,
                                                $this->getText ("Stadium:"), $this->getText ("Enter part of the stadium name or city"),
                                                $stadiumTable->getId ());
        $fields[] = new DateFieldTemplate ("", Sports::COL_MATCH_DATE,
                                    $this->getText ("Date:"), $this->getText ("Date"));
        if ("edit" != $action)
            $fields[] = new TextFieldTemplate ("", Sports::COL_MATCH_RESULT,
                                    $this->getText ("Result:"), $this->getText ("Match result"), 10);
        $fields[] = new IntFieldTemplate ("", Sports::COL_MATCH_MATCHDAY,
                                    $this->getText ("Match day:"), $this->getText ("Match day"));
        $numberField = new IntFieldTemplate ("", Sports::COL_MATCH_NUMBER,
                                    $this->getText ("Match number:"), $this->getText ("Match number"));
        if (!empty ($nextNumber))
            $numberField->setValue ($nextNumber);

        $fields[] = $numberField;
        return $fields;
        }

    protected function getInitialValues ($request)
        {
        $cookieName = "lastsrc_".$this->dbtable->getName ();
        if (!empty ($_COOKIE[$cookieName]))
            $this->existingRow[DBTable::COL_SOURCE] = $_COOKIE[$cookieName];
        return $this->existingRow;
        }

    protected function save ($request, $values)
        {
        $action = empty ($request["action"]) ? NULL : $request["action"];
        if (empty ($values[DBTable::COL_SOURCE]))
            {
            $this->context->addError ("Please enter source (or change comment)");
            return NULL;
            }

        if (!empty ($values[Sports::COL_MATCH_RESULT]))
            {
            if (!preg_match ("/^([0-9]+|W)\s*[:-]\s*([0-9]+|W)/", $values[Sports::COL_MATCH_RESULT], $matches))
                {
                $this->context->addError ("Entered result ([_0]) was not recognized", $values[Sports::COL_MATCH_RESULT]);
                return NULL;
                }
            if ($matches[1] == "W" && $matches[2] == "W")
                $values[Sports::COL_MATCH_OUTCOME] = MatchConstants::OUTCOME_BOTH_LOOSE;
            else if ($matches[1] == "W")
                $values[Sports::COL_MATCH_OUTCOME] = MatchConstants::OUTCOME_NO_VISITORS;
            else if ($matches[2] == "W")
                $values[Sports::COL_MATCH_OUTCOME] = MatchConstants::OUTCOME_NO_HOME_TEAM;
            else
                {
                $values[Sports::COL_MATCH_HOMERESULT] = $matches[1];
                $values[Sports::COL_MATCH_AWAYRESULT] = $matches[2];
                }
            unset ($values[Sports::COL_MATCH_RESULT]);
            }

        if ("edit" == $action)
            {
            $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            $criteria[] = new EqCriterion ($matchesTable->getIdColumn (), $id);
            if (false === $this->dbtable->updateRecord ($criteria, $values))
                {
                $this->context->addError ("Failed to update a match record");
                return NULL;
                }
            }
        else
            {
            $parts = NULL;
            if (!empty ($request["teams"]))
                $parts = explode (",", $request["teams"]);

            if (empty ($request["teams"]) || 2 != count ($parts) || empty ($request["comp"]))
                {
                $this->context->addError ("Invalid arguments passed.");
                return NULL;
                }

            if (empty ($values[Sports::COL_MATCH_DATE]) && empty ($values[Sports::COL_MATCH_RESULT]))
                {
                $this->context->addError ("Please enter a match date and/or result");
                return NULL;
                }

            list ($homeTeam, $awayTeam) = $parts;

            $values[Sports::COL_MATCH_HOMETEAM] = $homeTeam;
            $values[Sports::COL_MATCH_AWAYTEAM] = $awayTeam;
            $values[Sports::COL_MATCH_COMPETITION] = $request["comp"];
            $values[Sports::COL_MATCH_OUTCOME] = MatchConstants::OUTCOME_FULL_TIME;

            $id = $this->dbtable->insertRecord ($values);
            if (false === $id)
                {
                $this->context->addError ("Failed to create a match record");
                return NULL;
                }
            }

        $label = $time = $fullDate = NULL;
        NULL;
        if (isset ($values[Sports::COL_MATCH_HOMERESULT]) && isset ($values[Sports::COL_MATCH_AWAYRESULT]))
            $label = $values[Sports::COL_MATCH_HOMERESULT]." : ".$values[Sports::COL_MATCH_AWAYRESULT];
        else if (!empty ($values[Sports::COL_MATCH_DATE]))
            {
            list ($year, $month, $day) = sscanf ($values[Sports::COL_MATCH_DATE], "%d-%d-%d");
            if (!empty ($month) && !empty ($day))
                $label = sprintf ("(%02d-%02d)", $month, $day);

            $lng = Language::getInstance ($this->context);
            $time = $lng->extractTimeFromDate ($values[Sports::COL_MATCH_DATE]);
            $fullDate = $lng->dateToString ($values[Sports::COL_MATCH_DATE], "long");
            }

        if (empty ($label))
            $label = "?";

        $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                     $this->dbtable->getId (),
                                                                     $id);

        $result = array (array ("label" => $label, "time" => $time, "fullDate" => $fullDate, "url" => $url));
        return $result;
        }

    protected function getSaveButtonText ()
        {
        return $this->getText ("Create");
        }
    }

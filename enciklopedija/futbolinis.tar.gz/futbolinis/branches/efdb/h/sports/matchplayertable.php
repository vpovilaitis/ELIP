<?php
require_once (PATH.'inc/contenttable.php');

class MatchPlayerTable extends ContentTable
    {
    public function insertRecord ($nameToValue)
        {
        if (empty ($nameToValue["c_priority"]))
            {
            $filterBy = array ();
            foreach ($this->parentTable->getPrimaryIndexColumns () as $idColumn)
                $filterBy[$idColumn->name] = $nameToValue[$idColumn->name];

            $val = $this->getNextColumnValue ("priority", $filterBy);
            $nameToValue["c_priority"] = $val;
            }

        return parent::insertRecord ($nameToValue);
        }
    }


<?php
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/sports/constants.php');

class CompetitionStage extends ContentTable
    {
    protected $nameCol;
    protected $levelCol;

    public function __construct ($context, $instanceRow)
        {
        parent::__construct ($context, $instanceRow);
        $this->nameCol = $this->prepareUserColumnName ("name");
        $this->levelCol = $this->prepareUserColumnName ("level");
        // season, region
        }

    public function canCreateFromLabel ()
        {
        return true;
        }

    public function createFromLabel ($label)
        {
        list ($year, $level, $name, $country, $explicitlySpecifiedCountry) = CompetitionStageFilterColumn::parseCriteriaParts ($label);
        if (empty ($year) || empty ($name) || empty ($country))
            {
            $this->context->addError ("Required fields (year, name or country) were not entered. Please fill the field using the template \"&lt;year> &lt;level> &lt;name> (&lt;country>)\".");
            return false;
            }

        $seasonTable = ContentTable::createInstanceByName ($this->context, "seasons");
        $countryTable = ContentTable::createInstanceByName ($this->context, "country");
        $competitionTable = ContentTable::createInstanceByName ($this->context, "league");
        if (empty ($seasonTable) || empty ($countryTable) || empty ($competitionTable))
            {
            $this->context->addError ("Required tables not found.");
            return false;
            }

        $namesToValues = array ("c_start" => $year[0]."-00-00");
        if (count ($year) > 1)
            $namesToValues["c_end"] = $year[1]."-00-00";
        else
            $namesToValues["c_end"] = $year[0]."-00-00";

        $seasonId = $this->findOrCreateRelatedRecord ($seasonTable, "seasons", $namesToValues, true);

        $namesToValues = array ("c_name" => $country);
        $countryId = $this->findOrCreateRelatedRecord ($countryTable, "country", $namesToValues, false);

        if (!empty ($countryId))
            {
            $namesToValues = array ("c_name" => $name, "f_country_country_id" => $countryId);
            $competitionId = $this->findOrCreateRelatedRecord ($competitionTable, "league", $namesToValues, true);
            }

        if (empty ($seasonId) || empty ($competitionId) || empty ($countryId))
            {
            $this->context->addError ("Related records not found.");
            return false;
            }

        $namesToValues = array
            (
            "f_season_seasons_id" => $seasonId,
            "f_region_country_id" => $countryId,
            "c_name" => $name,
            "f_competition_league_id" => $competitionId,
            );

        if (!empty ($level))
            $namesToValues["c_level"] = $level;

        $id = $this->insertRecord ($namesToValues);
        return $id;
        }

    protected function findOrCreateRelatedRecord ($dbtable, $tableName, $namesToValues, $create)
        {
        $criteria = array ();
        foreach ($namesToValues as $name => $val)
            $criteria[] = new EqCriterion ($name, $val);

        $rows = $dbtable->selectBy (array ($tableName."_id"), $criteria);
        if (empty ($rows))
            {
            if ($create && false !== $rows)
                {
                $id = $dbtable->insertRecord ($namesToValues);
                if (empty ($id))
                    $this->context->addError ("[_0] record not created.", $tableName);

                return $id;
                }

            return false;
            }

        return $rows[0][$tableName."_id"];
        }

    protected function createFilterColumn ($sortColumns)
        {
        return new CompetitionStageFilterColumn ($this, $this->displayNameColumn, $sortColumns);
        }

    protected function selectForIndexing ($columns, $ids)
        {
        $columns = array ($this->getIdColumn (), "competition", "season", "partof", "region", "managedby", "startdate",
                          "enddate", "promoteto", "relegateto", "level", "name", "nameprefix", "description",
                          DBTable::COL_UPDATEDON, DBTable::COL_CREATEDON);
        return parent::selectForIndexing ($columns, $ids);
        }

    protected function indexSingleRow ($row)
        {
        $indexed = parent::indexSingleRow ($row);
        $indexed['label'] = $row["season.displayname"]." ".$row["c_name"];
        return $indexed;
        }
    }

class CompetitionStageFilterColumn extends FilterColumn
    {
    protected $context;

    public function __construct ($dbtable, $displayNameColumn, $sortColumns)
        {
        parent::__construct ($dbtable, $displayNameColumn, $sortColumns);
        $this->context = $dbtable->getContext ();
        }

    public static function parseCriteriaParts ($filterCriterion)
        {
        $year = NULL;
        $level = NULL;
        $name = array ();
        $country = NULL;
        $explicitlySpecifiedCountry = false;

        $pieces = explode (" ", $filterCriterion);
        foreach ($pieces as $part)
            {
            $part = trim ($part);
            if (empty ($part))
                continue;

            if (strlen ($part) > 2 && "(".substr ($part, 1, -1).")" == $part)
                {
                $country = substr ($part, 1, -1);
                $explicitlySpecifiedCountry = true;
                continue;
                }

            $seasonParts = explode ("-", $part, 2);
            if (2 == count ($seasonParts) && is_numeric ($seasonParts[0]) && is_numeric ($seasonParts[1]))
                {
                $year[] = $seasonParts[0];
                $n = $seasonParts[1];
                $year[] = ($n < 150) ? ($n < 25 ? 2000 + $n : 1900 + $n) : $n;
                }
            else if (is_numeric ($part) && ($part > 1800 || NULL === $level))
                {
                if ($part < 5)
                    $level = $part;
                else if ($part > 1000)
                    $year[] = $part;
                else if ($part > 50)
                    $year[] = 1900 + $part;
                }
            else
                {
                if (empty ($country))
                    $country = $part;
                }
            }

        return array ($year, $level, implode (" ", $name), $country, $explicitlySpecifiedCountry);
        }

    public function prepareQuery ($filterCriterion, &$criteria, &$joins, &$params = NULL)
        {
        $filterBy = $filterCriterion->criterion;
        list ($year, $level, $name, $country, $explicitlySpecifiedCountry) = self::parseCriteriaParts ($filterBy);

        if (!empty ($level))
            $criteria[] = new EqCriterion ("c_level", $level);

        if (!empty ($year))
            {
            $seasonTable = ContentTable::createInstanceByName ($this->context, "seasons");
            if (!empty ($seasonTable))
                {
                $crit[] = new JoinColumnsCriterion ("f_season_seasons_id", "seasons_id");
                $startColumn = $seasonTable->findColumn ("start")->columnDef;
                $endColumn = $seasonTable->findColumn ("end")->columnDef;

                $crit[] = new EqCriterion ($startColumn->name, $year[0]."-00-00");

                if (count ($year) > 1)
                    $crit[] = new EqCriterion ($endColumn->name, $year[1]."-00-00");

                $join = $seasonTable->createQuery (array (), $crit);
                $joins[] = $join;
                $join->joinType = Constants::JOIN_LEFT_OUTER;
                }
            }

        if (!empty ($name) || !empty ($country))
            {
            $crit = array ();

            if (!empty ($name))
                $crit[] = new LikeCriterion ("c_name", $name);

            $joinedTable = ContentTable::createInstanceByName ($this->context, "country");
            if (!empty ($joinedTable))
                {
                $joinCriteria[] = new JoinColumnsCriterion ("f_region_country_id", "country_id");

                $join = $joinedTable->createQuery (array (), $joinCriteria);
                $joins[] = $join;
                $join->joinType = Constants::JOIN_LEFT_OUTER;

                $nameColumn = $joinedTable->findColumn ("isoalpha3")->columnDef;
                $nameCriterion = new LikeCriterion ($nameColumn->name, $country);
                $nameCriterion->query = $join;
                $nameCriterion->value = "'{$nameCriterion->value}'";
                if ($explicitlySpecifiedCountry)
                    $criteria[] = $nameCriterion;
                else
                    $crit[] = $nameCriterion;
                }

            if (!empty ($crit))
                {
                if (count ($crit) == 1)
                    $criteria[] = $crit[0];
                else
                    $criteria[] = new LogicalOperatorOr ($crit);
                }
            }
        }

    }

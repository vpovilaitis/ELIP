<?php
require_once (PATH.'inc/webservice.php');
require_once (PATH.'inc/sports/constants.php');

class PlayerFromNumberService extends WebService
    {
    public function __construct ($context)
        {
        parent::__construct ($context);
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getData ($request)
        {
        $teamId = isset ($request["team"]) ? $request["team"] : NULL;
        $number = isset ($request["no"]) ? $request["no"] : NULL;
        $competitionId = isset ($request["comp"]) ? $request["comp"] : NULL;
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $playersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHPLAYER);
        $personsTable = ContentTable::createInstanceByName ($this->context, "persons");
        if (empty ($matchesTable) || empty ($playersTable) || empty ($personsTable) || empty ($teamId) || empty ($number) || empty ($competitionId))
            {
            $this->context->addError ("Invalid arguments passed.");
            return NULL;
            }

        $leagueIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $allRows = array ();

        foreach (array ("f_hometeam_team_id" => 1, "f_awayteam_team_id" => 0) as $teamColumn => $isHome)
            {
            $playerIdColumn = "f_player_persons_id";
            $columns = array (new FunctionCount ("*", "cnt"));
            $criteria = array (new EqCriterion ($teamColumn, $teamId),
                               new EqCriterion ($leagueIdColumn, $competitionId),
                               new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ()));

            $join = $matchesTable->createQuery ($columns, $criteria, NULL, array (new GroupBy (array ("c_no"))));

            $criteria = array (new EqCriterion ("c_number", $number), new EqCriterion ("c_hometeam", $isHome));
            $columns = array ("c_number", "c_hometeam", $playerIdColumn);
            $params = array (new GroupBy (array ($playerIdColumn)));

            $rows = $playersTable->selectBy ($columns, $criteria, array ($join), $params);
            if (!empty ($rows))
                {
                $allRows = array_merge ($allRows, $rows);
                }
            }

        if (empty ($allRows))
            return array ();

        $result = array ();
        
        $playerIds = array ();
        foreach ($allRows as $row)
            $playerIds[] = $row[$playerIdColumn];
        $players = $personsTable->selectBy (array ($personsTable->getIdColumn (), "first", "last"),
                                            array (new InCriterion ($personsTable->getIdColumn (), $playerIds)));


        foreach ($players as $row)
            {
            $result[] = array ("id" => $row[$personsTable->getIdColumn ()], "label" => trim ($row["c_first"]." ".$row["c_last"]));
            }

        return $result;
        }
    }

<?php
require_once (PATH.'h/contentservice.php');

class TeamNameService extends ContentService
    {
    public function getPickList ($request, $dbtable, $filterBy)
        {
        $stageId = isset ($request["stageid"]) ? $request["stageid"] : NULL;

        $params[] = new FilterCriterion ($filterBy);
        $joins = NULL;
        $teamIdsCriteria = NULL;

        if (!empty ($stageId))
            {
            $context = $dbtable->getContext ();
            foreach (array ("teamleagueseasons", "teamcupseason") as $table)
                {
                $stageTable = ContentTable::createInstanceByName ($context, $table);
                if (!empty ($stageTable))
                    {
                    $compstageIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAMLEAGUESEASON_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
                    $criteria = array (new EqCriterion ($compstageIdColumn, $stageId));
                    $cols = array (new FunctionCount ("*", "cnt"));
                    $row = $stageTable->selectSingleBy ($cols, $criteria);
                    if ($row["cnt"] > 0)
                        {
                        $criteria = array
                            (
                            new EqCriterion ($compstageIdColumn, $stageId),
                            );
                        $altNameColumn = "f_altname_team_id";
                        $cols = array ($dbtable->getIdColumn (), $altNameColumn);
                        $rows = $stageTable->selectBy ($cols, $criteria);
                        $teamIds = NULL;
                        foreach (!empty ($rows) ? $rows : array () as $row)
                            {
                            $teamIds[] = $row[$dbtable->getIdColumn ()];
                            if (!empty ($row[$altNameColumn]))
                                $teamIds[] = $row[$altNameColumn];
                            }
                        $teamIdsCriteria[] = new InCriterion ($dbtable->getIdColumn (), empty ($teamIds) ? array (-1) : $teamIds);
                        break;
                        }
                    }
                }
            }

        if (empty ($teamIdsCriteria))
            return parent::getPickList ($request, $dbtable, $filterBy);
        $list = $dbtable->getPickList ($teamIdsCriteria, 10, $joins, $params);
        if (empty ($list))
            $list = $dbtable->getPickList ($teamIdsCriteria, 20, $joins, NULL);
        return $list;
        }
    }

<?php
require_once (PATH.'h/sports/teamstable.php');

class SimplifiedTeamsTable extends TeamsTable
    {
    protected function createFilterColumn ($sortColumns)
        {
        return new SimplifiedTeamFilterColumn ($this, $this->displayNameColumn, $sortColumns);
        }

    public function createFromLabel ($label)
        {
        list ($prefix, $name, $city, $year, $explicitlySpecified) = TeamFilterColumn::parseCriteriaParts ($label);
        if (empty ($city) || (empty ($name) && empty ($prefix)))
            {
            $this->context->addError ("Required fields (city and name or prefix) were not entered. Please fill the field using the template \"&lt;prefix> &lt;name> &lt;city>\".");
            return false;
            }

        $namesToValues = array
            (
            "c_city" => $city,
            );

        if (!empty ($prefix))
            $name = $prefix." ".$name;

        if ($explicitlySpecified && !empty ($name))
            $namesToValues["c_name"] = $name;

        $id = $this->insertRecord ($namesToValues);
        return $id;
        }

    public function selectBy ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL, $tableAlias = NULL)
        {
        $needsShortName = false;

        if (empty ($resultColumns))
            $columns = $resultColumns;
        else
            {
            $columns = array ();
            foreach ($resultColumns as $key => $col)
                {
                if (Sports::COL_TEAM_SHORTNAME == $col || ContentTable::PREFIX.Sports::COL_TEAM_SHORTNAME == $col)
                    {
                    $needsShortName = true;
                    continue;
                    }

                $columns[$key] = $col;
                }
            }

        if ($needsShortName)
            {
            $columns[] = Sports::COL_TEAM_NAME;
            $columns[] = Sports::COL_TEAM_CITY;
            }

        $rows = parent::selectBy ($columns, $criteria, $joinedQueries, $queryParams, $tableAlias);
        if (empty ($rows) || !$needsShortName)
            return $rows;

        foreach ($rows as &$row)
            {
            $name = $row[ContentTable::PREFIX.Sports::COL_TEAM_NAME];
            /*
            if (!empty ($row[ContentTable::PREFIX.Sports::COL_TEAM_CITY]))
                $name .= " (".$row[ContentTable::PREFIX.Sports::COL_TEAM_CITY].")";
            */
            $row[ContentTable::PREFIX.Sports::COL_TEAM_SHORTNAME] = $name;
            }

        return $rows;
        }

    public function insertRecord ($nameToValue)
        {
        $id = ContentTable::insertRecord ($nameToValue);
        if (empty ($id) || (empty ($nameToValue[$this->cityColumn]) && empty ($nameToValue[$this->nameColumn])))
            return $id;

        // insert table label if creating non national team record
        $namesTable = new TeamNamesTable ($this->context);
        $values = array (TeamNamesTable::COL_CITY => $nameToValue[$this->cityColumn], TeamNamesTable::COL_TEAMID => $id);
        if (!empty ($nameToValue[$this->nameColumn]))
            $values[TeamNamesTable::COL_NAME] = $nameToValue[$this->nameColumn];

        if (!empty ($nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_FROM]))
            $values[TeamNamesTable::COL_DATEFROM] = $nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_FROM];

        if (!empty ($nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_TO]))
            $values[TeamNamesTable::COL_DATETO] = $nameToValue[ContentTable::PREFIX.Sports::COL_TEAM_TO];

        $nameId = $namesTable->insertRecord ($values);
        if (empty ($nameId))
            {
            $this->deleteById (array (new EqCriterion ($this->getIdColumn, $id)));
            return false;
            }

        return $id;
        }

    public function getExtentedPickList ($maxResults, $filterCriteria)
        {
        if ($maxResults > 20)
            $maxResults = 20;

        $criteriaText = $filterCriteria;
        if (false === strpbrk ($this->value, "+-*()"))
            {
            $parts = preg_split ("/\s+/", $filterCriteria);
            if (count ($parts) > 1)
                {
                $partsAdjusted = array ();
                foreach ($parts as $part)
                    $partsAdjusted[] = "+$part";
                $criteriaText = implode (" ", $partsAdjusted);
                }

            $criteriaText .= "*";
            }

        $results = ExtractedContentTable::executeSearch ($this->context, "$criteriaText", 0, Constants::TABLES_USER."_".Sports::TABLE_TEAM);
        $ids = array ();

        if (!empty ($results))
            {
            foreach ($results as $row)
                $ids[] = $row[ExtractedContentTable::COL_ENTRYID];
            }

        $namesTable = new TeamNamesTable ($this->context);

        if (empty ($ids))
            {
            TeamFilterColumn::parseCriterion ($criteriaText, $postfix, $year);
            $criteria = array ();
            
            $criteria[] = new LikeCriterion (TeamNamesTable::COL_CITY, $criteriaText);
            $criteria[] = new LikeCriterion (TeamNamesTable::COL_NAME, $criteriaText);
            $parts = explode (" ", $criteriaText, 2);
            if (2 == count ($parts))
                {
                $criteria[] = new LogicalOperatorAnd
                    (
                    new LogicalOperatorOr
                                        (
                                        new LikeCriterion (TeamNamesTable::COL_CITY, trim ($parts[1], " .,")),
                                        new LikeCriterion (TeamNamesTable::COL_NAME, trim ($parts[1], " .,"))
                                        )
                    );
                $criteria[] = new LogicalOperatorAnd
                    (
                    new LikeCriterion (TeamNamesTable::COL_CITY, trim ($parts[0], " .,")),
                    new LikeCriterion (TeamNamesTable::COL_NAME, trim ($parts[1], " .,"))
                    );
                $criteria[] = new LogicalOperatorAnd
                    (
                    new LikeCriterion (TeamNamesTable::COL_NAME, trim ($parts[0], " .,")),
                    new LikeCriterion (TeamNamesTable::COL_CITY, trim ($parts[1], " .,"))
                    );
                }

            $criteria = array (new LogicalOperatorOr ($criteria));

            if (empty ($postfix))
                $criteria[] = new IsNullCriterion (TeamNamesTable::COL_POSTFIX);
            else
                $criteria[] = new LikeCriterion (TeamNamesTable::COL_POSTFIX, $postfix);

            if (!empty ($year)) // check for teams existing in that year
                {
                $criteria[] = new LogicalOperatorOr
                                        (
                                        new LtCriterion (TeamNamesTable::COL_DATEFROM, $year+1),
                                        new IsNullCriterion (TeamNamesTable::COL_DATEFROM)
                                        );
                $criteria[] = new LogicalOperatorOr
                                        (
                                        new GtEqCriterion (TeamNamesTable::COL_DATETO, $year),
                                        new IsNullCriterion (TeamNamesTable::COL_DATETO)
                                        );
                }

            $idRows = $namesTable->selectBy (array (TeamNamesTable::COL_TEAMID), $criteria, NULL, array (new LimitResults (0, $maxResults)));
            $criteria = NULL;
            $params = NULL;
            if (!empty ($idRows))
                {
                $ids = array ();
                foreach ($idRows as $row)
                    $ids[] = $row[TeamNamesTable::COL_TEAMID];
                }
            }

        if (empty ($ids))
            return null;

        $criteria = array (new InCriterion ($this->getIdColumn (), $ids));

        $list = $this->getPickList ($criteria, $maxResults, NULL, $params, false, true);
        if (empty ($list))
            return $list;

        $namesByTeam = array ();
        foreach ($list as $id => $pair)
            $namesByTeam[$id] = array ();

        $allNames = $namesTable->selectBy (NULL, array (new InCriterion (TeamNamesTable::COL_TEAMID, array_keys ($namesByTeam))));
        if (empty ($allNames))
            return $list;

        foreach ($allNames as $row)
            $namesByTeam[$row[TeamNamesTable::COL_TEAMID]][] = SportsHelper::extractTeamLabel ($this->context, $row, true);

        $result = array ();
        foreach ($list as $id => $pair)
            {
            list ($label, $description) = $pair;

            if (!empty ($description))
                $description = $this->trimSentence ($description, 70);

            if (!empty ($namesByTeam[$id]))
                {
                $namesRecorded = implode (", ", $namesByTeam[$id]);
                if (!empty ($description))
                    $description = htmlspecialchars ($namesRecorded)."\n<br>\n".htmlspecialchars ($namesRecorded);
                else
                    $description = htmlspecialchars ($namesRecorded);
                }

            $result[$id] = array ($label, $description);
            }

        return $result;
        }

    protected function selectForIndexing ($columns, $ids)
        {
        $columns = array ($this->getIdColumn (), "code", "name", "city", "country", "from", "to", "description", "motherteam", DBTable::COL_UPDATEDON, DBTable::COL_CREATEDON);
        return ContentTable::selectForIndexing ($columns, $ids);
        }
    protected function indexSingleRow ($row)
        {
        $indexed = ContentTable::indexSingleRow ($row);
        $indexed['indexedLabel'] = $row['c_code']."; ".$indexed['label']."; ".$row["c_".Sports::COL_TEAM_CITY];

        if (empty ($indexed['description']))
            $indexed['description'] = $indexed['label'].".";
        /*
        $removedDiacritics = utf8_normalize ($indexed['description']);
        if ($removedDiacritics != $indexed['description'])
            $indexed['indexedDescription'] .= " $removedDiacritics";
        */
        $removedDiacritics = utf8_normalize ($indexed['indexedLabel']);
        if ($removedDiacritics != $indexed['indexedLabel'])
            $indexed['indexedLabel'] .= " $removedDiacritics";
        $indexed['label'] = $row['c_name'];
        return $indexed;
        }
    }

class SimplifiedTeamFilterColumn extends TeamFilterColumn
    {
    public function prepareQuery ($filterCriterion, &$criteria, &$joins, &$params = NULL)
        {
        $colPrefix = ContentTable::PREFIX;

        $filterBy = $filterCriterion->criterion;

        $results = ExtractedContentTable::executeSearch ($this->context, "$filterBy*", 0, Constants::TABLES_USER."_".Sports::TABLE_TEAM);
        $ids = array ();

        if (!empty ($results))
            {
            foreach ($results as $row)
                $ids[] = $row[ExtractedContentTable::COL_ENTRYID];
            }

        if (empty ($ids))
            $criteria[] = new EqCriterion (Sports::TABLE_TEAM."_id", 0);
        else
            $criteria[] = new InCriterion (Sports::TABLE_TEAM."_id", $ids);
        }

    public static function parseCriteriaParts ($filterCriterion)
        {
        $year = NULL;
        $prefix = NULL;
        $name = array ();
        $city = NULL;
        $explicitlySpecified = false;

        $pieces = explode (" ", trim ($filterCriterion));
        foreach ($pieces as $part)
            {
            $part = trim ($part);
            if (empty ($part))
                continue;

            if (is_numeric ($part) && $part > 1850)
                $year = $part;
            else if (strlen ($part) <= 2 || (strlen ($part) <= 5 && substr ($part, 1) != utf8_strtolower (substr ($part, 1))))
                {
                $prefix = $part;
                }
            else
                $name[] = $part;
            }

        if (count ($name) > 1)
            {
            $city = array_pop ($name);
            $explicitlySpecified = true;
            }
        else if (count ($name) == 1)
            {
            $city = $name[0];
            }

        return array ($prefix, implode (" ", $name), $city, $year, $explicitlySpecified);
        }
    }

<?php
require_once (PATH.'inc/contenttable.php');

class TeamTypeDisplayNameColumn extends GhostColumn
    {
    const COL_TYPE = "type";
    const COL_ISWOMEN = "iswomen";
    const COL_AGE = "age";
    public $triggeredBy;
    
    public function __construct ($context)
        {
        parent::__construct (ContentTable::COL_DISPLAY_NAME, 256);

        $triggeredBy = array (self::COL_TYPE, self::COL_AGE, self::COL_ISWOMEN);
        $this->triggeredBy = array ();

        foreach ($triggeredBy as $colName)
            $this->triggeredBy[] = ContentTable::prepareUserColumnName ($colName);
        }

    public function calculateValue ($context, $transformations, $row, $columnPrefix = NULL)
        {
        return $this->createLabel ($context,
                                   $row[$this->triggeredBy[0]],
                                   $row[$this->triggeredBy[1]],
                                   $row[$this->triggeredBy[2]]);
        }

    protected function createLabel ($context, $type, $age, $women)
        {
        $label = $type;
        
        if (!empty ($age))
            {
            if ($women)
                $label = $context->getText ("U-[_0] girls", $age, $type);
            else
                $label = $context->getText ("U-[_0]", $age, $type);
            }
        else if ($women)
            {
            if (empty ($type))
                $label = $context->getText ("women");
            else
                $label = $context->getText ("women [_0]", $type);
            }

        return $label;
        }
    }

class TeamTypeTable extends ContentTable
    {
    protected $typeDisplayNameColumn;

    public function __construct ($context, $instanceRow)
        {
        parent::__construct ($context, $instanceRow);
        $this->typeDisplayNameColumn = new TeamTypeDisplayNameColumn ($context, $this);
        }

    public function getAdditionalColumns ()
        {
        $arr = parent::getAdditionalColumns ();
        $arr[] = new ValueColumn ($this->typeDisplayNameColumn,
                                  $this->context->getText ("Display name"),
                                  $this->context->getText ("Display name"));
        return $arr;
        }

    }
?>

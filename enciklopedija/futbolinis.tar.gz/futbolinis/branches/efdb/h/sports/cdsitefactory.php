<?php
require_once (PATH.'h/sports/sportsitefactory.php');

class CDSiteFactory extends SportSiteFactory
    {
    public function __construct ()
        {
        parent::__construct ();

        $this->editorMappings["teamleagueseasons"] = "sports/CDSeasonEditor";
        }
    }

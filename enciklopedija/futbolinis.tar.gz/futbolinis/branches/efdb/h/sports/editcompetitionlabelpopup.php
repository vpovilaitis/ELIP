<?php
require_once (PATH.'inc/popupservice.php');
require_once (PATH."inc/sports/competitionnamestable.php");

class EditCompetitionLabelPopup extends PopupService
    {
    protected $dbtable;
    protected $returnType = NULL;
    protected $existingRow;
    
    public function __construct ($context)
        {
        parent::__construct ($context, true);
        $this->dbtable = new CompetitionNamesTable ($context);
        }

    protected function checkAccess ($request)
        {
        return !empty ($this->dbtable) && ($this->dbtable->canEdit () || $this->dbtable->canCreate ());
        }

    protected function getFields ($request)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";

        $fields = array ();

        $fields[] = new DateFieldTemplate ("", CompetitionNamesTable::COL_DATEFROM,
                                           $this->getText ("From:"), $this->getText ("The date this name became official"));
        $fields[] = new DateFieldTemplate ("", CompetitionNamesTable::COL_DATETO,
                                           $this->getText ("To:"), $this->getText ("The date this name was used last"));
        $fields[] = new TextFieldTemplate ("", CompetitionNamesTable::COL_NAME,
                                           $this->getText ("Name:"), $this->getText ("Official name of the team in this period"), 64);

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $criteria[] = new EqCriterion (CompetitionNamesTable::COL_ID, $id);
            $this->existingRow = $this->dbtable->selectSingleBy (NULL, $criteria);
            if (empty ($this->existingRow))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            }
        else
            {
            $leagueid = !empty ($request["leagueid"]) ? $request["leagueid"] : NULL;
            if (empty ($request["leagueid"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_LEAGUE);
            $criteria[] = new EqCriterion ($teamsTable->getIdColumn (), $leagueid);
            $columns = array (Sports::COL_LEAGUE_NAME);
            $row = $teamsTable->selectSingleBy ($columns, $criteria);
            if (empty ($row))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $this->existingRow = array ();
            $this->existingRow[CompetitionNamesTable::COL_NAME] = $row[ContentTable::PREFIX.Sports::COL_LEAGUE_NAME];
            }

        return $fields;
        }

    public function getData ($request)
        {
        $ret = parent::getData ($request);
        return $ret;
        }

    protected function getInitialValues ($request)
        {
        return $this->existingRow;
        }

    protected function save ($request, $values)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            $criteria[] = new EqCriterion (CompetitionNamesTable::COL_ID, $id);
            $affected = $this->dbtable->updateRecord ($criteria, $values);
            if (1 != $affected)
                $this->addError ("Error");
            }
        else if ("new" == $action)
            {
            $leagueid = !empty ($request["leagueid"]) ? $request["leagueid"] : NULL;
            if (empty ($request["leagueid"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $values[CompetitionNamesTable::COL_LEAGUEID] = $leagueid;
            $id = $this->dbtable->insertRecord ($values);
            }

        return array ("result" => array ("id" => $id));
        }

    protected function executeCustomAction ($request, $mode)
        {
        if ("delete" == $mode)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $criteria[] = new EqCriterion (CompetitionNamesTable::COL_ID, $id);
            return false !== $this->dbtable->deleteById ($criteria);
            }

        return parent::executeCustomAction ($request, $mode);
        }

    protected function getSaveButtonText ()
        {
        return !empty ($this->existingRow) ? $this->getText ("Save") : $this->getText ("Create");
        }

    }

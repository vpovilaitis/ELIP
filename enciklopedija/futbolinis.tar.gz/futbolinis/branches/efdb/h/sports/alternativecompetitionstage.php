<?php
require_once (PATH.'h/sports/competitionstage.php');

class AlternativeCompetitionStage extends CompetitionStage
    {
    public function insertRecord ($nameToValue)
        {
        if ((empty ($nameToValue[ContentTable::PREFIX.Sports::COL_COMPETITION_STARTS]) || empty ($nameToValue[ContentTable::PREFIX.Sports::COL_COMPETITION_ENDS])) && !empty ($nameToValue["season"]))
            {
            if (empty ($nameToValue[Sports::COL_COMPETITION_SEASON]))
                $seasonId = is_array ($nameToValue["c_".Sports::COL_COMPETITION_SEASON]) ? $nameToValue["c_".Sports::COL_COMPETITION_SEASON][0] : $nameToValue["c_season"];
            else
                $seasonId = is_array ($nameToValue[Sports::COL_COMPETITION_SEASON]) ? $nameToValue[Sports::COL_COMPETITION_SEASON][0] : $nameToValue[Sports::COL_COMPETITION_SEASON];

            $seasonsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_SEASON);
            $seasonRow = $seasonsTable->selectSingleBy (array (Sports::COL_SEASON_START, Sports::COL_SEASON_END), array (new EqCriterion ($seasonsTable->getIdColumn(), $seasonId)));
            if (!empty ($seasonRow))
                {
                if (empty ($nameToValue[ContentTable::PREFIX.Sports::COL_COMPETITION_STARTS]) && !empty ($seasonRow[ContentTable::PREFIX.Sports::COL_SEASON_START]))
                    $nameToValue[ContentTable::PREFIX.Sports::COL_COMPETITION_STARTS] = $seasonRow[ContentTable::PREFIX.Sports::COL_SEASON_START];
                if (empty ($nameToValue[ContentTable::PREFIX.Sports::COL_COMPETITION_ENDS]) && !empty ($seasonRow[ContentTable::PREFIX.Sports::COL_SEASON_END]))
                    {
                    $end = $seasonRow[ContentTable::PREFIX.Sports::COL_SEASON_END];
                    if ("00" == substr ($end, 5, 2))
                        $end = substr ($end, 0, 5)."12-31";
                    $nameToValue[ContentTable::PREFIX.Sports::COL_COMPETITION_ENDS] = $end;
                    }
                }
            }

        return parent::insertRecord ($nameToValue);
        }

    public function postprocessRows ($rows)
        {
        if (empty ($rows))
            return $rows;
        foreach ($rows as &$row)
            {
            if (!empty ($row[ContentTable::PREFIX."iscup"]))
                {
                switch ($row[ContentTable::PREFIX."iscup"])
                    {
                    case 1:
                        $row[ContentTable::PREFIX.Sports::COL_COMPETITION_SYSTEM] = LeagueConstants::SYSTEM_LEAGUE_MIN;
                        break;
                    case 2:
                        $row[ContentTable::PREFIX.Sports::COL_COMPETITION_SYSTEM] = LeagueConstants::SYSTEM_CUP_MIN;

                        if (!empty ($row[ContentTable::PREFIX.ContentTable::COL_DISPLAY_NAME]))
                            {
                            $country = $row[Sports::COL_COMPETITION_REGION.".".ContentTable::COL_DISPLAY_NAME];
                            $season = $row[Sports::COL_COMPETITION_SEASON.".".ContentTable::COL_DISPLAY_NAME];
                            switch ($row[ContentTable::PREFIX."level"])
                                {
                                case 1:
                                    $displayName = $this->getText ("[_0]: [_1] Supercup", $country, $season);
                                    break;
                                case 2:
                                    $displayName = $this->getText ("[_0]: [_1] national cup", $country, $season);
                                    break;
                                default:
                                    $displayName = $this->getText ("[_0]: [_1] league cup", $country, $season);
                                    break;
                                }

                            if (!empty ($displayName))
                                {
                                if (!empty ($row[ContentTable::PREFIX."zone"]))
                                    $displayName .= " (".$row[ContentTable::PREFIX."zone"].")";
                                $row[ContentTable::PREFIX.ContentTable::COL_DISPLAY_NAME] = $displayName;
                                $row[ContentTable::COL_DISPLAY_NAME] = $displayName;
                                }
                            }
                        break;
                    default:
                        $row[ContentTable::PREFIX.Sports::COL_COMPETITION_SYSTEM] = LeagueConstants::SYSTEM_GROUP_MIN;
                        break;
                    }
                }
            }

        return $rows;
        }

    public function executeQuery ($query, $queryParams = NULL)
        {
        $rows = parent::executeQuery ($query, $queryParams);
        return $this->postprocessRows ($rows);
        }


    }

<?php
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/sports/constants.php');

class MatchesTable extends ContentTable
    {
    protected function createFilterColumn ($sortColumns)
        {
        return new MatchFilterColumn ($this, $this->displayNameColumn, $sortColumns);
        }

    public function selectBy ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL, $tableAlias = NULL)
        {
        $needsHomeTeamLabel = false;
        $needsAwayTeamLabel = false;
        $needsMatchLabel = false;
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id");
        $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id");
        if (!empty ($resultColumns))
            {
            if (false !== ($pos = array_search (Sports::COL_MATCH_HOMETEAM.".shortname", $resultColumns)))
                {
                $resultColumns[$pos] = $homeTeamIdColumn;
                $needsHomeTeamLabel = true;
                }
            if (false !== ($pos = array_search (Sports::COL_MATCH_HOMETEAM, $resultColumns)))
                {
                $resultColumns[$pos] = $homeTeamIdColumn;
                $needsHomeTeamLabel = true;
                }
            if (false !== ($pos = array_search (Sports::COL_MATCH_AWAYTEAM.".shortname", $resultColumns)))
                {
                $resultColumns[$pos] = $awayTeamIdColumn;
                $needsAwayTeamLabel = true;
                }
            if (false !== ($pos = array_search (Sports::COL_MATCH_AWAYTEAM, $resultColumns)))
                {
                $resultColumns[$pos] = $awayTeamIdColumn;
                $needsAwayTeamLabel = true;
                }
            if (false !== ($pos = array_search ("c_displayname", $resultColumns)))
                {
                $resultColumns[$pos] = Sports::COL_MATCH_DATE;
                $resultColumns[] = Sports::COL_MATCH_RESULT;
                $needsMatchLabel = true;
                }

            if ($needsHomeTeamLabel || $needsAwayTeamLabel || $needsMatchLabel)
                {
                if (!$needsHomeTeamLabel)
                    $resultColumns[] = $homeTeamIdColumn;
                if (!$needsAwayTeamLabel)
                    $resultColumns[] = $awayTeamIdColumn;
                if (!$needsMatchLabel)
                    $resultColumns[] = Sports::COL_MATCH_DATE;
                }
            }

        $rows = parent::selectBy ($resultColumns, $criteria, $joinedQueries, $queryParams, $tableAlias);
        if (empty ($rows))
            return $rows;

        if ($needsHomeTeamLabel || $needsAwayTeamLabel || $needsMatchLabel)
            {
            $teamLabelRequest = array ();
            foreach ($rows as $row)
                {
                $teamLabelRequest[] = array ($row[$homeTeamIdColumn], $row["c_".Sports::COL_MATCH_DATE]);
                $teamLabelRequest[] = array ($row[$awayTeamIdColumn], $row["c_".Sports::COL_MATCH_DATE]);
                }

            $labelsByTeam = SportsHelper::getTeamLabelsByDates ($this->context, $teamLabelRequest);
            $lng = Language::getInstance ($this->context);

            foreach ($rows as &$row)
                {
                $date = $row["c_".Sports::COL_MATCH_DATE];
                $homeLabel = $labelsByTeam[$row[$homeTeamIdColumn]][$date];
                $awayLabel = $labelsByTeam[$row[$awayTeamIdColumn]][$date];
                if ($needsHomeTeamLabel)
                    {
                    $row[Sports::COL_MATCH_HOMETEAM.".c_shortname"] = $homeLabel;
                    $row[Sports::COL_MATCH_HOMETEAM.".".ContentTable::COL_DISPLAY_NAME] = $homeLabel;
                    $row[Sports::COL_MATCH_HOMETEAM] = array ($row[$homeTeamIdColumn]);
                    }
                if ($needsAwayTeamLabel)
                    {
                    $row[Sports::COL_MATCH_AWAYTEAM.".c_shortname"] = $awayLabel;
                    $row[Sports::COL_MATCH_AWAYTEAM.".".ContentTable::COL_DISPLAY_NAME] = $awayLabel;
                    $row[Sports::COL_MATCH_AWAYTEAM] = array ($row[$awayTeamIdColumn]);
                    }
                if ($needsMatchLabel)
                    {
                    $row["c_displayname"] = $lng->dateToLongString ($date, "day")." ".$lng->beautifyTeamLabel($homeLabel)." – ".$lng->beautifyTeamLabel($awayLabel)." ".$row["c_".Sports::COL_MATCH_RESULT];
                    }
                }
            }

        return $rows;
        }
    }

class MatchFilterColumn extends FilterColumn
    {
    protected $context;

    public function __construct ($dbtable, $displayNameColumn, $sortColumns)
        {
        parent::__construct ($dbtable, $displayNameColumn, $sortColumns);
        $this->context = $dbtable->getContext ();
        }

    public function prepareQuery ($filterCriterion, &$criteria, &$joins, &$params = NULL)
        {
        $filterBy = $filterCriterion->criterion;
        $withTime = false;
        foreach (array ("%04d-%02d-%02d %02d:%02d", "%04d-%02d-%02d %02d.%02d",
                        "%04d-%02d-%02d %02d", "%04d-%02d-%02d") as $format)
            {
            $date = sscanf ($filterBy, $format);
            if (!empty ($date) && NULL !== $date[count ($date) - 1])
                {
                $withTime = count ($date) > 3;
                break;
                }

            $date = NULL;
            }

        if (empty ($date))
            {
            return false;
            }

        $teamsTable = ContentTable::createInstanceByName ($this->context, "team");
        if (!empty ($teamsTable))
            {
            preg_match ('/([A-Za-zŽžŠšČč]{2,5})/', $filterBy, $matches);
            if (count ($matches) > 1)
                {
                // search by team name or city
                $crit[] = new JoinColumnsCriterion ("f_hometeam_team_id", "team_id");
                $crit[] = new LogicalOperatorOr
                                        (
                                        new LikeCriterion ("c_name", $matches[1]),
                                        new LikeCriterion ("c_city", $matches[1])
                                        );
                $join = $teamsTable->createQuery (array (), $crit);
                $joins[] = $join;
                $join->joinType = Constants::JOIN_LEFT_OUTER;
                }
            }
            
        $dateStr = sprintf ("%04d-%02d-%02d", $date[0], $date[1], $date[2]);

        if ($withTime)
            {
            if (count ($date) < 5)
                $date[] = 0;

            $dateStr .= sprintf (" %02d:%02d:%02d", $date[3], $date[4], 0);
            $criteria[] = new EqCriterion ("c_time", $dateStr);
            return;
            }

        $criteria[] = new GtEqCriterion ("c_time", $dateStr);
        $dateStr = sprintf ("%04d-%02d-%02d", $date[0], $date[1], $date[2] + 1);
        $criteria[] = new LtCriterion ("c_time", $dateStr);
        }
    }

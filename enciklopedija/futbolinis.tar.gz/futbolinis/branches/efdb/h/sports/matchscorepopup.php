<?php
require_once (PATH.'inc/popupservice.php');
require_once (PATH.'inc/sports/constants.php');

class MatchScorePopup extends PopupService
    {
    protected $dbtable;
    protected $matchflowtable;

    const HALF_TIME_RESULT = "result_1";

    public function __construct ($context)
        {
        parent::__construct ($context);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $this->matchflowtable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHFLOW);
        }

    protected function checkAccess ($request)
        {
        return !empty ($this->dbtable) && $this->dbtable->canCreate ();
        }

    protected function getFields ($request)
        {
        $fields[] = new TextFieldTemplate ("", Sports::COL_MATCH_RESULT,
                                    $this->getText ("Result:|result"), $this->getText ("Final match result (home goals and away goals separated with colon)"), 10);
        $fields[] = new TextFieldTemplate ("", self::HALF_TIME_RESULT,
                                    $this->getText ("First half:|result"), $this->getText ("Result after first half (goal counts separated with colon)"), 10);
        return $fields;
        }

    protected function getInitialValues ($request)
        {
        $initial = array ();
        $cookieName = "lastsrc_".$this->dbtable->getName ();
        if (!empty ($_COOKIE[$cookieName]))
            $initial[DBTable::COL_SOURCE] = $_COOKIE[$cookieName];

        return $initial;
        }

    protected function save ($request, $values)
        {
        $matchId = NULL;
        if (!empty ($request["match"]))
            $matchId = $request["match"];

        if (!is_numeric ($matchId))
            {
            $this->context->addError ("Invalid arguments passed.");
            return NULL;
            }

        if (empty ($values[DBTable::COL_SOURCE]))
            {
            $this->context->addError ("Please enter source (or change comment)");
            return NULL;
            }

        if (empty ($values[Sports::COL_MATCH_RESULT]))
            {
            $this->context->addError ("Please enter a match date and/or result");
            return NULL;
            }

        $values[Sports::COL_MATCH_OUTCOME] = MatchConstants::OUTCOME_FULL_TIME;
        $result = $resultHT = NULL;

        if (!empty ($values[Sports::COL_MATCH_RESULT]))
            {
            if (!preg_match ("/^([0-9]+|W)\s*[:-]\s*([0-9]+|W)$/", trim ($values[Sports::COL_MATCH_RESULT]), $matches))
                {
                $this->context->addError ("Entered result ([_0]) was not recognized", $values[Sports::COL_MATCH_RESULT]);
                return NULL;
                }
            if ($matches[1] == "W" && $matches[2] == "W")
                $values[Sports::COL_MATCH_OUTCOME] = MatchConstants::OUTCOME_BOTH_LOOSE;
            else if ($matches[1] == "W")
                $values[Sports::COL_MATCH_OUTCOME] = MatchConstants::OUTCOME_NO_VISITORS;
            else if ($matches[2] == "W")
                $values[Sports::COL_MATCH_OUTCOME] = MatchConstants::OUTCOME_NO_HOME_TEAM;
            else
                {
                $values[Sports::COL_MATCH_HOMERESULT] = $matches[1];
                $values[Sports::COL_MATCH_AWAYRESULT] = $matches[2];
                $result = array ($matches[1], $matches[2]);
                }
            unset ($values[Sports::COL_MATCH_RESULT]);
            }

        if (!empty ($values[self::HALF_TIME_RESULT]))
            {
            if (!preg_match ("/^([0-9]+)\s*[:-]\s*([0-9]+)$/", trim ($values[self::HALF_TIME_RESULT]), $matches))
                {
                $this->context->addError ("Entered half time result ([_0]) was not recognized", $values[self::HALF_TIME_RESULT]);
                return NULL;
                }

            $resultHT = array ($matches[1], $matches[2]);
            }
        unset ($values[self::HALF_TIME_RESULT]);

        $criteria[] = new EqCriterion ($this->dbtable->getIdColumn (), $matchId);
        if (false === $this->dbtable->updateRecord ($criteria, $values))
            {
            $this->context->addError ("Failed to update match score");
            return NULL;
            }

        $this->updateOrInsertResultInstance ($matchId, $resultHT, MatchConstants::STAGE_HALF_TIME, $values[DBTable::COL_SOURCE], $values[DBTable::COL_SOURCEDATE]);
        $this->updateOrInsertResultInstance ($matchId, $result, MatchConstants::STAGE_FULL_TIME, $values[DBTable::COL_SOURCE], $values[DBTable::COL_SOURCEDATE]);
        return array ();
        }

    protected function updateOrInsertResultInstance ($matchId, $result, $partId, $sources, $sourcesDate)
        {
        if (!isset ($result))
            return true;

        $values = array ("c_home" => $result[0], "c_away" => $result[1]);
        $values[DBTable::COL_SOURCE] = $sources;
        $values[DBTable::COL_SOURCEDATE] = $sourcesDate;

        $criteria = array (new EqCriterion ("match_id", $matchId), new EqCriterion ("c_stage", $partId));
        $res = $this->matchflowtable->updateRecord ($criteria, $values);

        if ($res > 0)
            return true;

        $values["match_id"] = $matchId;
        $values["c_stage"] = $partId;

        if (false === $this->matchflowtable->insertRecord ($values))
            return false;

        return true;
        }

    protected function getSaveButtonText ()
        {
        return $this->getText ("Create");
        }
    }

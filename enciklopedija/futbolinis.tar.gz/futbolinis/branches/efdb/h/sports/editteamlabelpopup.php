<?php
require_once (PATH.'inc/popupservice.php');
require_once (PATH.'inc/newstable.php');

class EditTeamLabelPopup extends PopupService
    {
    protected $dbtable;
    protected $returnType = NULL;
    protected $existingRow;
    
    public function __construct ($context)
        {
        parent::__construct ($context, true);
        $this->dbtable = new TeamNamesTable ($context);
        }

    protected function checkAccess ($request)
        {
        return !empty ($this->dbtable) && ($this->dbtable->canEdit () || $this->dbtable->canCreate ());
        }

    protected function getFields ($request)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";

        $fields = array ();

        $fields[] = new DateFieldTemplate ("", TeamNamesTable::COL_DATEFROM,
                                           $this->getText ("From:"), $this->getText ("The date this name became official"));
        $fields[] = new DateFieldTemplate ("", TeamNamesTable::COL_DATETO,
                                           $this->getText ("To:"), $this->getText ("The date this name was used last"));
        if (!SIMPLIFIED_TEAM_LABELS)
            {
            $fields[] = new TextFieldTemplate ("", TeamNamesTable::COL_CITY,
                                               $this->getText ("City:"), $this->getText ("City in which team home matches were played"), 64);
            $fields[] = new TextFieldTemplate ("", TeamNamesTable::COL_PREFIX,
                                               $this->getText ("Prefix:"), $this->getText ("Prefix used in this period"), 64);
            }
        $fields[] = new TextFieldTemplate ("", TeamNamesTable::COL_NAME,
                                           $this->getText ("Name:"), $this->getText ("Official name of the team in this period"), 64);
        if (!SIMPLIFIED_TEAM_LABELS)
            {
            $fields[] = new TextFieldTemplate ("", TeamNamesTable::COL_POSTFIX,
                                               $this->getText ("Postfix:"), $this->getText ("Postfix used (for example '2' to show 'Name-2')"), 64);
            $fields[] = new CheckBoxFieldTemplate ("", TeamNamesTable::COL_SHOWPREFIX,
                                                   $this->getText ("Show prefix"), $this->getText ("Force name prefix to be always shown (otherwise it will be shown only if no name is entered)"));
            $fields[] = new CheckBoxFieldTemplate ("", TeamNamesTable::COL_DECLINE,
                                                   $this->getText ("Decline"), $this->getText ("Decline name where appropriate"));
            }

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $criteria[] = new EqCriterion (TeamNamesTable::COL_ID, $id);
            $this->existingRow = $this->dbtable->selectSingleBy (NULL, $criteria);
            if (empty ($this->existingRow))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            }
        else
            {
            $teamid = !empty ($request["teamid"]) ? $request["teamid"] : NULL;
            if (empty ($request["teamid"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
            $criteria[] = new EqCriterion ($teamsTable->getIdColumn (), $teamid);
            if (!SIMPLIFIED_TEAM_LABELS)
                $columns = array (Sports::COL_TEAM_PREFIX, Sports::COL_TEAM_NAME, Sports::COL_TEAM_CITY, Sports::COL_TEAM_DECLINE, Sports::COL_TEAM_SHOWPREFIX, Sports::COL_TEAM_POSTFIX);
            else
                $columns = array (Sports::COL_TEAM_NAME, Sports::COL_TEAM_CITY);
            $row = $teamsTable->selectSingleBy ($columns, $criteria);
            if (empty ($row))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $this->existingRow = array ();
            $this->existingRow[TeamNamesTable::COL_CITY] = $row[ContentTable::PREFIX.Sports::COL_TEAM_CITY];
            $this->existingRow[TeamNamesTable::COL_PREFIX] = $row[ContentTable::PREFIX.Sports::COL_TEAM_PREFIX];
            if (!SIMPLIFIED_TEAM_LABELS)
                $this->existingRow[TeamNamesTable::COL_NAME] = $row[ContentTable::PREFIX.Sports::COL_TEAM_NAME];
            else
                $this->existingRow[TeamNamesTable::COL_NAME] = $row[ContentTable::PREFIX.Sports::COL_TEAM_NAME]." ".$row[ContentTable::PREFIX.Sports::COL_TEAM_CITY];
            $this->existingRow[TeamNamesTable::COL_POSTFIX] = $row[ContentTable::PREFIX.Sports::COL_TEAM_POSTFIX];
            $this->existingRow[TeamNamesTable::COL_SHOWPREFIX] = $row[ContentTable::PREFIX.Sports::COL_TEAM_SHOWPREFIX];
            $this->existingRow[TeamNamesTable::COL_DECLINE] = $row[ContentTable::PREFIX.Sports::COL_TEAM_DECLINE];
            }

        return $fields;
        }

    public function getData ($request)
        {
        $ret = parent::getData ($request);
        return $ret;
        }

    protected function getInitialValues ($request)
        {
        return $this->existingRow;
        }

    protected function save ($request, $values)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            $criteria[] = new EqCriterion (TeamNamesTable::COL_ID, $id);
            $affected = $this->dbtable->updateRecord ($criteria, $values);
            if (1 != $affected)
                $this->addError ("Error");
            }
        else if ("new" == $action)
            {
            $teamid = !empty ($request["teamid"]) ? $request["teamid"] : NULL;
            if (empty ($request["teamid"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $values[TeamNamesTable::COL_TEAMID] = $teamid;
            $id = $this->dbtable->insertRecord ($values);
            }

        return array ("result" => array ("id" => $id));
        }

    protected function executeCustomAction ($request, $mode)
        {
        if ("delete" == $mode)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $criteria[] = new EqCriterion (TeamNamesTable::COL_ID, $id);
            return false !== $this->dbtable->deleteById ($criteria);
            }

        return parent::executeCustomAction ($request, $mode);
        }

    protected function getSaveButtonText ()
        {
        return !empty ($this->existingRow) ? $this->getText ("Save") : $this->getText ("Create");
        }

    }

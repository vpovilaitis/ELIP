<?php
require_once (PATH.'inc/sports/matchcollector.php');
require_once (PATH.'inc/sports/common.php');

class MatchAnnouncements extends BaseWithContext
    {
    protected $matchesTable;
    protected $teamsTable;
    protected $competitionsTable;
    
    public function __construct ($context)
        {
        parent::__construct ($context);
        $this->matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $this->teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        $this->competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        }

    public function getItems ()
        {
        $now = time();
        $lng = Language::getInstance ($this->context);
        $collector = new MatchCollector ($this->context, $this);

        $criteria = NULL;
        if (!empty ($_REQUEST["leagueid"]))
            {
            $competitionIdColumn = "f_".Sports::COL_MATCH_COMPETITION."_".$this->competitionsTable->getIdColumn();
            $competitionId = array ($_REQUEST["leagueid"]);
            $ids = SportsHelper::selectCompetitionHierarchyIds ($this->context, $this->competitionsTable, $competitionId);
            if (empty ($ids))
                return NULL;
            $criteria[] = new InCriterion ($competitionIdColumn, $ids);
            }

        $rows = $collector->selectMatches ($now, 0, 2, -1, $criteria);

        if (empty ($rows))
            return NULL;

        foreach ($rows as $group)
            {
            $matchesByDay = $group['matches'];
            foreach ($matchesByDay as $row)
                {
                if (empty ($row["rows"]))
                    continue;

                $entry = array ();
                $date = NULL;
                foreach ($row["rows"] as $matchEntry)
                    {
                    if ($date === NULL || $date > $matchEntry["time"])
                        $date = $matchEntry["time"];
                    }

                $entry["title"] = $this->ngettext ("[_1] - [_0] match planned on [_2]", "[_1] - [_0] matches planned on [_2]",
                                                   count ($row["rows"]), strip_tags ($row["label"]), $lng->dateToLongString ($date, "day"));
    
                $entry["description"] = $this->getEntryDescription ($lng, $row, $date);
                $entry["pubDate"] = date ("r", strtotime ($date));
                $entry["link"] = htmlspecialchars ($row["url"]);
                $entry["guid"] = htmlspecialchars ($row["url"]."#".count($row["rows"])."x".$date);
                $arr[] = $entry;
                }
            }
    
        return $arr;
        }

    protected function getEntryDescription ($lng, $row, $date)
        {
        $descr = $this->ngettext ("[_2] there is [_0] match planned in the [_1]:", "[_2] there are [_0] matches planned in the [_1]:",
                                  count ($row["rows"]), strip_tags ($row["label"]), $lng->dateToLongString ($date, "day"));

        $descr .= "<table>";
        foreach ($row["rows"] as $matchEntry)
            {
            $descr .= "<tr>";
            $descr .= "<td align=\"right\" width=\"180px\" nowrap>".$matchEntry["home"]."</td>";
            $descr .= "<td align=\"center\" width=\"30px\" nowrap>".$matchEntry["result"]."</td>";
            $descr .= "<td width=\"180px\" nowrap>".$matchEntry["away"]."</td>";
            $descr .= "<td>".(!empty($matchEntry["stadium"]) ? "(".$matchEntry["stadium"].")" : "&nbsp;")."</td>";
            $descr .= "</tr>";
            }
        $descr .= "</table>";
        return $descr;
        }

    public function getTitle ()
        {
        return $this->getText ("Match announcements");
        }
    }

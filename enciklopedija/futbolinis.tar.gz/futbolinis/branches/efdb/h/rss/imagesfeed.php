<?php

class ImagesFeed extends BaseWithContext
    {
    protected $dbtable;
    const MAX_ITEMS = 100;
    
    public function __construct ($context)
        {
        parent::__construct ($context);
        $this->dbtable = new ImageUseTable ($context);
        }

    public function getItems ()
        {
        $imagesTable = new ImagesTable ($this->context);
        $usersTable = new UsersTable ($this->context);

        $userJoin = $usersTable->createQuery (array (new Column (UsersTable::COL_NAME, "creator")),
                                          array (new JoinColumnsCriterion (DBTable::COL_CREATEDBY, UsersTable::COL_ID)));
        $userJoin->joinType = Constants::JOIN_LEFT_OUTER;
        $joinCriteria = array (new JoinColumnsCriterion (ImagesTable::COL_ID, ImageUseTable::COL_IMAGEID));
        $join = $imagesTable->createQuery (array (ImagesTable::COL_DESCRIPTION, ImagesTable::COL_AUTHOR), $joinCriteria);
        
        $params = OrderBy::create (DBTable::COL_CREATEDON, false);
        $rows = $this->dbtable->selectBy (NULL, NULL, array ($userJoin, $join), $params);
        if (empty ($rows))
            return NULL;

        $width = 300;
        $height = 0;
        foreach ($rows as $row)
            {
            $entry = array ();
            if (!empty ($row[ImagesTable::COL_AUTHOR]))
                $entry["title"] = $this->getText ('New image "[_0]" by [_1]', $row[ImageUseTable::COL_TITLE], $row[ImagesTable::COL_AUTHOR]);
            else
                $entry["title"] = $this->getText ('New image "[_0]"', $row[ImageUseTable::COL_TITLE]);
            
            $imageId = $row[ImageUseTable::COL_IMAGEID];
            $src = $this->context->chooseUrl ("image/$imageId/{$width}x{$height}",
                                              "index.php?c=UserImage&id=$imageId&w=$width&h=$height");
            $scope = $row[ImageUseTable::COL_SCOPE];
            $id = $row[ImageUseTable::COL_CONTEXTID];
            $url = $this->context->chooseUrl ("galery/$scope/$id/$imageId",
                                              "index.php?c=ImageGalery&sc=$scope&id=$id&highlight=$imageId");
            $body = "<a href=\"$url\"><img src=\"$src\" width=\"$width\"></a><br>";
            if (!empty ($row[ImagesTable::COL_DESCRIPTION]))
                $body .= $row[ImagesTable::COL_DESCRIPTION];

            if (!empty ($row["creator"]))
                $body .= "<br>".$this->getText ("Uploaded by: [_0]", $row["creator"]);
                
            $entry["description"] = $body;
            $date = !empty ($row[DBTable::COL_UPDATEDON]) ? $row[DBTable::COL_CREATEDON] : $row[DBTable::COL_UPDATEDON];
            $entry["pubDate"] = date ("r", strtotime ($date));
            $entry["link"] = $url;
            $entry["guid"] = $url."#".$date;
            $arr[] = $entry;
            }

        return $arr;
        }

    public function getTitle ()
        {
        return $this->getText ("New images");
        }
    }

<?php
require_once (PATH.'inc/newstable.php');

class NewsFeed extends BaseWithContext
    {
    protected $dbtable;
    const MAX_ITEMS = 100;
    
    public function __construct ($context)
        {
        parent::__construct ($context);
        $scope = !empty ($_REQUEST["sp"]) ? $_REQUEST["sp"] : false;
        $this->dbtable = new NewsTable ($context, $scope);
        }

    public function getItems ()
        {
        $rows = $this->dbtable->selectNews (self::MAX_ITEMS, self::MAX_ITEMS);
        if (empty ($rows))
            return NULL;

        $descr = new NewsLinkDescriptor ($this->context, $this->dbtable, NULL);
        foreach ($rows as $row)
            {
            $entry = array ();
            $entry["title"] = $row[NewsTable::COL_TITLE];
            if (!empty ($row[NewsTable::COL_DETAILS]))
                $entry["description"] = $this->context->applyFormat ($row[NewsTable::COL_DETAILS]);
            else if (!empty ($row[NewsTable::COL_OVERVIEW]))
                $entry["description"] = $this->context->applyFormat ($row[NewsTable::COL_OVERVIEW]);

            $entry["pubDate"] = date ("r", strtotime ($row[NewsTable::COL_ENTRY_DATE]));
            $url = NewsLinkDescriptor::getItemLink ($this->dbtable, $row);
            $entry["link"] = htmlspecialchars ($url);
            $entry["guid"] = htmlspecialchars ($url."#".$row[NewsTable::COL_ENTRY_DATE]);
            $arr[] = $entry;
            }

        return $arr;
        }

    public function getTitle ()
        {
        return $this->getText ("News");
        }
    }

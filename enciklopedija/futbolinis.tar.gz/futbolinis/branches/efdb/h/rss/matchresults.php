<?php
require_once (PATH.'inc/sports/matchcollector.php');
require_once (PATH.'inc/sports/common.php');

class MatchResults extends BaseWithContext
    {
    protected $matchesTable;
    protected $teamsTable;
    protected $competitionsTable;
    
    public function __construct ($context)
        {
        parent::__construct ($context);
        $this->matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $this->teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        $this->competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        }

    public function getItems ()
        {
        $now = time();
        $lng = Language::getInstance ($this->context);
        $collector = new MatchCollector ($this->context, $this);
        $criteria = NULL;
        if (!empty ($_REQUEST["leagueid"]))
            {
            $competitionIdColumn = "f_".Sports::COL_MATCH_COMPETITION."_".$this->competitionsTable->getIdColumn();
            $competitionId = array ($_REQUEST["leagueid"]);
            $ids = SportsHelper::selectCompetitionHierarchyIds ($this->context, $this->competitionsTable, $competitionId);
            if (empty ($ids))
                return NULL;
            $criteria[] = new InCriterion ($competitionIdColumn, $ids);
            }

        $rows = $collector->selectMatches ($now, 7, 0, -1, $criteria);

        if (empty ($rows))
            return NULL;

        foreach ($rows as $group)
            {
            $matchesByDay = $group['matches'];
            foreach ($matchesByDay as $row)
                {
                if (empty ($row["rows"]))
                    continue;

                $entry = array ();
                $date = NULL;
                foreach ($row["rows"] as $matchEntry)
                    {
                    if ($date === NULL || $date > $matchEntry["time"])
                        $date = $matchEntry["time"];
                    }

                $entry["title"] = $this->ngettext ("[_1] - [_0] match on [_2]", "[_1] - [_0] matches on [_2]",
                                                   count ($row["rows"]), strip_tags ($row["label"]), $lng->dateToLongString ($date, "day"));
    
                $resultCount = 0;
                $entry["description"] = $this->getEntryDescription ($lng, $row, $date, $resultCount);
                if (0 == $resultCount)
                    continue;
                $entry["pubDate"] = date ("r", strtotime ($date));
                $entry["link"] = $row["url"];
                $entry["guid"] = $row["url"]."#{$resultCount}x".$date;
                $arr[] = $entry;
                }
            }
    
        return $arr;
        }

    protected function getEntryDescription ($lng, $row, $date, &$count)
        {
        $descr = $this->ngettext ("[_2] there was [_0] match in [_1]. Match results:", "[_2] there were [_0] matches in [_1]. Match results:",
                                  count ($row["rows"]), strip_tags ($row["label"]), $lng->dateToLongString ($date, "day"));

        $descr .= "<table>";
        $count = 0;
        foreach ($row["rows"] as $matchEntry)
            {
            if (!empty ($matchEntry["resultEntered"]))
                $count++;
            $descr .= "<tr>";
            $descr .= "<td align=\"right\" width=\"180px\" nowrap>".$matchEntry["home"]."</td>";
            $descr .= "<td align=\"center\" width=\"30px\" nowrap>".$matchEntry["result"]."</td>";
            $descr .= "<td width=\"180px\" nowrap>".$matchEntry["away"]."</td>";
            $descr .= "</tr>";
            }
        $descr .= "</table>";
        return $descr;
        }

    public function getTitle ()
        {
        return $this->getText ("Match results");
        }
    }

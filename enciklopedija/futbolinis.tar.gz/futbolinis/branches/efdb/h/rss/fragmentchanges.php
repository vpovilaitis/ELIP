<?php

class FragmentChanges extends BaseWithContext
    {
    protected $dbtable;
    const MAX_ITEMS = 100;
    
    public function __construct ($context)
        {
        parent::__construct ($context);
        $this->dbtable = new FragmentsTable ($context);
        }

    public function getItems ()
        {
        $usersTable = new UsersTable ($this->context);
        $lastWeek = time() - 7 * 24 * 60 * 60;

        $userJoin2 = $usersTable->createQuery (array (new Column (UsersTable::COL_NAME, "updater")),
                                          array (new JoinColumnsCriterion (DBTable::COL_UPDATEDBY, UsersTable::COL_ID)));
        $userJoin2->joinType = Constants::JOIN_LEFT_OUTER;

        $criteria[] = new GtCriterion (DBTable::COL_UPDATEDON, date ("Y-m-d H:i", $lastWeek));
        $columns = array (DBTable::COL_UPDATEDON, FragmentsTable::COL_TITLE, 
                          FragmentsTable::COL_DESCRIPTION, FragmentsTable::COL_ID);
        $params[] = OrderBy::create (DBTable::COL_UPDATEDON, false);
        $params[] = new SelectRevisions ();
        $rows = $this->dbtable->selectBy ($columns, $criteria, array ($userJoin2), $params);
        if (empty ($rows))
            return NULL;

        foreach ($rows as $row)
            {
            $entry = array ();
            $entry["title"] = $row[FragmentsTable::COL_TITLE];
            if (!empty ($row[FragmentsTable::COL_DESCRIPTION]))
                $entry["description"] = $this->context->applyFormat ($row[FragmentsTable::COL_DESCRIPTION]);
            else if (!empty ($row[FragmentsTable::COL_TITLE]))
                $entry["description"] = $this->context->applyFormat ($row[FragmentsTable::COL_TITLE]);


            $date = $row[DBTable::COL_UPDATEDON];
            $author = $row["updater"];
            $entry["author"] = $author;
            $entry["description"] .= "<br>".$this->getText ("Updated by: [_0]", $author);

            $entry["pubDate"] = date ("r", strtotime ($date));
            // $entry["link"] = htmlspecialchars ($url);
            $entry["guid"] = htmlspecialchars ($row[FragmentsTable::COL_ID]."#".$date);
            $arr[] = $entry;
            }

        return $arr;
        }

    public function getTitle ()
        {
        return $this->getText ("Fragment changes");
        }
    }

<?php

class Comments extends BaseWithContext
    {
    protected $dbtable;
    
    public function __construct ($context)
        {
        parent::__construct ($context);
        $this->dbtable = new DiscussionsTable ($context);
        }

    public function getItems ()
        {
        $lastWeek = time() - 7 * 24 * 60 * 60;

        $topicTable = new DiscussionTopicTable ($this->context);
        $columns = array (DiscussionTopicTable::COL_SCOPE, DiscussionTopicTable::COL_CONTEXTID, DBTable::COL_LANG);
        $join = $topicTable->createQuery ($columns, array (new JoinColumnsCriterion (DiscussionsTable::COL_TOPICID, DiscussionTopicTable::COL_ID)));

        $criteria[] = new GtCriterion (DiscussionsTable::COL_CREATEDON, date ("Y-m-d H:i", $lastWeek));
        $columns = array (DiscussionsTable::COL_ID, DiscussionsTable::COL_CREATEDON, DiscussionsTable::COL_USER, DiscussionsTable::COL_TEXT);
        $rows = $this->dbtable->selectBy ($columns, $criteria, array ($join));
        if (empty ($rows))
            return NULL;

        foreach ($rows as $row)
            {
            $entry = array ();
            $entry["title"] = $this->getText ("New discussion entry");
            
            $author = $row[DiscussionsTable::COL_USER];
            $entry["description"] = trim ($row[DiscussionsTable::COL_TEXT]);;
            $entry["pubDate"] = date ("r", strtotime ($row[DiscussionsTable::COL_CREATEDON]));
            $entry["author"] = $author;

            $id = $row[DiscussionTopicTable::COL_CONTEXTID];
            $scope = explode ("_", $row[DiscussionTopicTable::COL_SCOPE], 2);
            if (PageNamesTable::TABLE_SCOPE == $scope[0] && PageNamesTable::TABLE_NAME == $scope[1])
                $tableName = "pages";
            else if (NewsTable::TABLE_SCOPE == $scope[0] && NewsTable::TABLE_NAME == $scope[1])
                $tableName = "news";
            else if (Constants::TABLES_USER == $scope[0])
                {
                $table = $scope[1];
                $tableName = "_$table";
                }

            $url = $this->context->chooseUrl ("talk/$tableName/$id", "index.php?c=Discussions&sc=$tableName&id=$id", NULL, $row[DBTable::COL_LANG]);

            $entry["link"] = htmlspecialchars ($url);
            $entry["guid"] = htmlspecialchars ($url."#".$row[DiscussionsTable::COL_ID]);
            $arr[] = $entry;
            }

        return $arr;
        }

    public function getTitle ()
        {
        return $this->getText ("Discussions");
        }
    }

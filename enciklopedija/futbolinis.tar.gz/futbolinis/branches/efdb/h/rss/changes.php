<?php

class Changes extends BaseWithContext
    {
    protected $dbtable;
    protected $excludeUsers;
    
    public function __construct ($context, $request)
        {
        parent::__construct ($context);
        
        if (empty ($request["tn"]))
            {
            $context->addError ("Content table name not defined");
            return;
            }

        $this->dbtable = ContentTable::createInstanceByName ($context, $request["tn"]);
        if (empty ($this->dbtable))
            {
            $context->addError ("Content table [_0] not found", $request["tn"]);
            return;
            }

        if (!empty ($request["exclude"]))
            {
            $this->excludeUsers = explode (",", $request["exclude"]);
            }
        }

    public function getItems ()
        {
        if (empty ($this->dbtable))
            return array ();

        $lastWeek = time() - RSS_MAX_DAYS * 24 * 60 * 60;

        $usersTable = new UsersTable ($this->context);
        $lng = Language::getInstance ($this->context);

        $rows = $this->retrieveChanges ($this->dbtable, $usersTable, $lastWeek, $tracksRevisions);
        $dependentChanges = $this->retrieveDependentChanges ($lng, $this->dbtable, $usersTable, $lastWeek);

        if (!empty ($rows))
            $arr = $this->processRows ($lng, $this->dbtable, $rows, $tracksRevisions, $dependentChanges);
        if (!empty ($dependentChanges))
            {
            $columns = array ($this->dbtable->getIdColumn ());

            $criteria[] = new InCriterion ($this->dbtable->getIdColumn (), array_keys ($dependentChanges));
            $rows = $this->dbtable->selectWithDisplayName ($columns, $criteria);
            $arr = array_merge (empty ($arr) ? array () : $arr,
                                $this->processRows ($lng, $this->dbtable, $rows, NULL, $dependentChanges));
            }

        return $arr;
        }

    protected function retrieveChanges ($dbtable, $usersTable, $oldestDate, &$tracksRevisions)
        {
        $tracksRevisions = NULL != $dbtable->getRevisionTableName ();

        $columns = array ();
        foreach ($dbtable->getPrimaryIndexColumns () as $col)
            $columns[] = $col->name;
        foreach ($dbtable->selectDisplayableColumns () as $col)
            $columns[] = $col->name;
        array_push ($columns, DBTable::COL_UPDATEDON, DBTable::COL_UPDATEDBY);

        $params[] = new LimitResults (0, 200);
        $join = $usersTable->createQuery (array (new Column (UsersTable::COL_NAME, "updator")),
                                          array (new JoinColumnsCriterion (DBTable::COL_UPDATEDBY, UsersTable::COL_ID)));
        $join->joinType = Constants::JOIN_LEFT_OUTER;
        $joins[] = $join;

        if ($tracksRevisions)
            {
            $criteria[] = new GtCriterion (DBTable::COL_UPDATEDON, date ("Y-m-d H:i", $oldestDate));
            if (!empty ($this->excludeUsers))
                {
                $criteria[] = new NotInCriterion (DBTable::COL_UPDATEDBY, $this->excludeUsers);
                }

            $params[] = new SelectRevisions ();
            $params[] = OrderBy::create (DBTable::COL_UPDATEDON, false);
            }
        else
            {
            $criterion = new GtCriterion (DBTable::COL_UPDATEDON, date ("Y-m-d H:i", $oldestDate));
            $criterion->translatable = true;
            $criterion->onlyTranslatable = true;

            $criteria[] = new LogicalOperatorOr
                            (
                            new GtCriterion (DBTable::COL_CREATEDON, date ("Y-m-d H:i", $oldestDate)),
                            new GtCriterion (DBTable::COL_UPDATEDON, date ("Y-m-d H:i", $oldestDate)),
                            $criterion
                            );

            array_push ($columns, new LastUpdatedColumn (), DBTable::COL_CREATEDON, DBTable::COL_CREATEDBY);

            $joins[] = $usersTable->createQuery (array (new Column (UsersTable::COL_NAME, "creator")),
                                                 array (new JoinColumnsCriterion (DBTable::COL_CREATEDBY, UsersTable::COL_ID)));
            $params[] = OrderBy::createByAlias (LastUpdatedColumn::COLUMN_NAME, false);
            }

        return $dbtable->selectWithDisplayName ($columns, $criteria, $joins, $params);
        }

    protected function retrieveDependentChanges ($lng, $dbtable, $usersTable, $oldestDate)
        {
        $childTables = $dbtable->getChildTables ();
        if (empty ($childTables))
            return array ();
        
        $result = array ();
        foreach ($childTables as $child)
            {
            $rows = $this->retrieveChanges ($child, $usersTable, $oldestDate, $tracksRevisions);
            if (empty ($rows))
                continue;
            $processed = $this->processDependentInstances ($lng, $dbtable, $child, $rows, $tracksRevisions);
            if (empty ($processed))
                continue;
            
            foreach ($processed as $id => $changes)
                {
                $result[$id][$child->getLabel ()] = $changes;
                }
            }

        return $result;
        }

    protected function processDependentInstances ($lng, $parentTable, $dbtable, $rows, $tracksRevisions)
        {
        $arr = array ();
        foreach ($rows as $row)
            {
            $item = array ();
            $id = array ();
            foreach ($dbtable->getPrimaryIndexColumns () as $col)
                $id[] = $row[$col->name];
            $parentId = array ();
            foreach ($parentTable->getPrimaryIndexColumns () as $col)
                $parentId[] = $row[$col->name];
            $parentId = implode ("_", $parentId);
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $dbtable, $dbtable->getId (), $id);

            $item[] = "<a href=\"$url\">".$dbtable->getDisplayName ($row, true)."</a>";
            $item[] = $row["updator"];
            
            $rawDate = $row[$tracksRevisions ? DBTable::COL_UPDATEDON : LastUpdatedColumn::COLUMN_NAME];
            $item[] = $lng->dateToString ($rawDate);
            foreach ($dbtable->selectDisplayableColumns () as $col)
                {
                if ($col instanceof ValueColumn)
                    $val = $row[$col->columnDef->name];
                else if (!empty ($row[$col->name.".displayname"]))
                    $val = $row[$col->name.".displayname"];
                else
                    $val = $row[$col->name];

                $item[] = $val;
                }
            
            $arr[$parentId][] = "<tr>\n<td>".implode ("</td>\n<td>", $item)."</td>\n</tr>";
            }
        return $arr;
        }

    protected function processRows ($lng, $dbtable, $rows, $tracksRevisions, &$dependentChanges)
        {
        foreach ($rows as $row)
            {
            $item = array ();
            $title = $dbtable->getDisplayName ($row, true);
            if (NULL !== $tracksRevisions)
                {
                $user = $row["updator"];
                if (!$tracksRevisions)
                    {
                    if ($row[DBTable::COL_UPDATEDON] == $row[LastUpdatedColumn::COLUMN_NAME])
                        {
                        $item["title"] = $this->getText ("[_0] entry created", $title);
                        $user = $row["creator"];
                        $item["author"] = $user;
                        }
                    else if (empty ($row[DBTable::COL_UPDATEDON]) || $row[DBTable::COL_UPDATEDON] < $row[LastUpdatedColumn::COLUMN_NAME])
                        {
                        $user = $this->getText ("?|unknown user");
                        $item["title"] = $this->getText ("[_0] entry translated", $title);
                        }
                    }
                }
            else
                $user = NULL;

            if (empty ($item["title"]))
                {
                $item["title"] = $this->getText ("[_0] entry modified", $title);
                if (!empty ($user))
                    $item["author"] = $user;
                }
            
            if (NULL !== $tracksRevisions)
                {
                $rawDate = $row[$tracksRevisions ? DBTable::COL_UPDATEDON : LastUpdatedColumn::COLUMN_NAME];
                $date = $lng->dateToString ($rawDate);
                $text = $this->getText ("An entry \"[_0]\" was changed on [_1] by user [_2].",
                                    $title, $date, $user);
                $text .= "<br><br>\n<table>";
                $text .= "\n<caption>".$this->getText ("Entry snapshot after the mentioned changes:")."</caption>";
                foreach ($dbtable->selectDisplayableColumns () as $col)
                    {
                    if ($col instanceof ValueColumn)
                        $val = $row[$col->columnDef->name];
                    else if (!empty ($row[$col->name.".displayname"]))
                        $val = $row[$col->name.".displayname"];
                    else
                        $val = $row[$col->name];

                    $text .= "\n <tr><th style='text-align:right'>{$col->getLabel ()}</th><td>$val</td></tr>";
                    }
                $text .= "\n</table>";
                }
            else
                $text = "";

            $id = array ();
            foreach ($dbtable->getPrimaryIndexColumns () as $col)
                $id[] = $row[$col->name];

            // add dependent changes
            $flatId = implode ("_", $id);
            $dependentCount = 0;
            if (!empty ($dependentChanges[$flatId]))
                {
                foreach ($dependentChanges[$flatId] as $title => $changedRows)
                    {
                    $text .= "\n<br>\n<h2>".$this->getText ("Related changes - [_0]", $title)."</h2>";
                    $text .= "\n<table border=\"1\" width=\"100%\">";
                    foreach ($changedRows as $changedRow)
                        $text .= "\n".$changedRow;
                    $text .= "\n</table>";
                    $dependentCount += count ($changedRows);
                    }
                unset ($dependentChanges[$flatId]);
                }

            $item["description"] = $text;
            if (!empty ($rawDate))
                {
                $item["pubDate"] = date ("r", strtotime ($rawDate));
                $postfix = $rawDate;
                if ($dependentCount > 0)
                    $postfix .= "|".$dependentCount;
                }
            else
                $postfix = $dependentCount;

            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $dbtable, $dbtable->getId (), $id);
            $item["guid"] = $url."#".$postfix;
            $item["link"] = $url;
            
            $arr[] = $item;
            }
        return $arr;
        }

    public function getTitle ()
        {
        if (!empty ($this->dbtable))
            return $this->dbtable->getDescription ();
        return $this->getText ("Content changes");
        }
    }

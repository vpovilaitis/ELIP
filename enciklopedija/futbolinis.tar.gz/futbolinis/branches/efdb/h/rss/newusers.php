<?php
require_once (PATH.'inc/usertables.php');

class NewUsers extends BaseWithContext
    {
    protected $dbtable;
    
    public function __construct ($context)
        {
        parent::__construct ($context);
        $this->dbtable = new UsersTable ($context);
        }

    public function getItems ()
        {
        $lastWeek = time() - 7 * 24 * 60 * 60;

        $criteria[] = new GtCriterion (UsersTable::COL_CREATEDON, date ("Y-m-d H:i", $lastWeek));
        $columns = array (UsersTable::COL_CREATEDON, UsersTable::COL_NAME, UsersTable::COL_DESCRIPTION);
        $rows = $this->dbtable->selectBy ($columns, $criteria);
        if (empty ($rows))
            return NULL;

        foreach ($rows as $row)
            {
            $user = array ();
            $user["title"] = $this->getText ("New user [_0]", $row[UsersTable::COL_NAME]);
            
            $title = $row[UsersTable::COL_NAME];
            $desc = trim ($row[UsersTable::COL_DESCRIPTION]);
            if (!empty ($desc))
                $title = $this->getText ("[_0] ([_1])|new user", $title, $desc);

            $user["description"] = $this->getText ("A new user [_0] was created on site.", $title)."(".$row[UsersTable::COL_CREATEDON].")";
            $user["pubDate"] = date ("r", strtotime ($row[UsersTable::COL_CREATEDON]));
            $user["guid"] = $row[UsersTable::COL_NAME];
            $arr[] = $user;
            }

        return $arr;
        }

    public function getTitle ()
        {
        return $this->getText ("Users");
        }
    }

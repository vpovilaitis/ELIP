<?php
require_once (PATH.'inc/popupservice.php');
require_once (PATH."inc/sports/competitionnamestable.php");

class EditRelatedUrlPopup extends PopupService
    {
    protected $dbtable;
    protected $returnType = NULL;
    protected $existingRow;
    
    public function __construct ($context)
        {
        parent::__construct ($context, false);
        $this->dbtable = new RelatedUrlTable ($context);
        }

    protected function checkAccess ($request)
        {
        return !empty ($this->dbtable) && ($this->dbtable->canEdit () || $this->dbtable->canCreate ());
        }

    protected function getFields ($request)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";

        $fields = array ();
        $fields[] = new TextFieldTemplate ("", RelatedUrlTable::COL_URL,
                                           $this->getText ("Url:"), $this->getText ("Url to point to"), 1024);
        $types = RelatedUrlTable::getDefaultSelection ($this->context);
        $fields[] = new DropDownFieldTemplate ("", RelatedUrlTable::COL_PRIORITY,
                                               $this->getText ("Type:"), $this->getText ("Type"), $types);

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $fields[] = new TextFieldTemplate ("", RelatedUrlTable::COL_LABEL,
                                               $this->getText ("Label:"), $this->getText ("Displayed label"), 1024);
            $criteria[] = new EqCriterion (RelatedUrlTable::COL_ID, $id);
            $this->existingRow = $this->dbtable->selectSingleBy (NULL, $criteria);
            if (empty ($this->existingRow))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            }
        else
            {
            $scope = !empty ($request["scope"]) ? $request["scope"] : NULL;
            $relatedid = !empty ($request["rid"]) ? $request["rid"] : NULL;
            if (empty ($scope) || empty ($relatedid))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            $this->existingRow = array ();
            $this->existingRow[RelatedUrlTable::COL_PRIORITY] = RelatedUrlTable::PRIORITY_AUTO;
            }

        return $fields;
        }

    public function getData ($request)
        {
        $ret = parent::getData ($request);
        return $ret;
        }

    protected function getInitialValues ($request)
        {
        return $this->existingRow;
        }

    protected function save ($request, $values)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";
        $values[RelatedUrlTable::COL_PRIORITY] = RelatedUrlTable::adjustPriority ($values[RelatedUrlTable::COL_PRIORITY], $values[RelatedUrlTable::COL_URL]);

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($id))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            $criteria[] = new EqCriterion (CompetitionNamesTable::COL_ID, $id);
            $affected = $this->dbtable->updateRecord ($criteria, $values);
            if (1 != $affected)
                $this->addError ("Error");
            }
        else if ("new" == $action)
            {
            $scope = !empty ($request["scope"]) ? $request["scope"] : NULL;
            $relatedid = !empty ($request["rid"]) ? $request["rid"] : NULL;
            if (empty ($scope) || empty ($relatedid))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            $values[RelatedUrlTable::COL_LABEL] = RelatedUrlTable::getLabel ($this->context, $values[RelatedUrlTable::COL_PRIORITY], $values[RelatedUrlTable::COL_URL]);
            $values[RelatedUrlTable::COL_SCOPE] = $scope;
            $values[RelatedUrlTable::COL_CONTEXTID] = $relatedid;
            $id = $this->dbtable->insertRecord ($values);
            }

        return array ("result" => array ("id" => $id));
        }

    protected function executeCustomAction ($request, $mode)
        {
        if ("delete" == $mode)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $criteria[] = new EqCriterion (RelatedUrlTable::COL_ID, $id);
            return false !== $this->dbtable->deleteById ($criteria);
            }

        return parent::executeCustomAction ($request, $mode);
        }

    protected function getSaveButtonText ()
        {
        return !empty ($this->existingRow) ? $this->getText ("Save") : $this->getText ("Create");
        }

    }

<?php
require_once (PATH.'inc/webservice.php');

class FullTextSearch extends WebService
    {
    public function __construct ($context)
        {
        parent::__construct ($context);
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getData ($request)
        {
        $searchString = isset ($request["s"]) ? trim ($request["s"]) : NULL;
        $searchResults = ExtractedContentTable::executeSearchByPrefix ($this->context, $searchString, 5);
        $result = array ();

        if (!empty ($searchResults))
            {
            foreach ($searchResults as $row)
                {
                if (0 == strncmp (HintsTable::SCOPE_CONTENTTABLE, $row[ExtractedContentTable::COL_SCOPE], 2))
                    {
                    $tableName = substr ($row[ExtractedContentTable::COL_SCOPE], strlen (HintsTable::SCOPE_CONTENTTABLE));
                    $dbtable = ContentTable::createInstanceByName ($this->context, $tableName);
                    $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $dbtable,
                                                                                 $dbtable->getId (),
                                                                                 $row[ExtractedContentTable::COL_ENTRYID]);
                    $row['url'] = $url;

                    if (empty ($row[ExtractedContentTable::COL_IMAGEID]))
                        {
                        $image = $this->context->getResourcePath ("img", "metro-$tableName.png");
                        if (empty ($image))
                            $image = $this->context->getResourcePath ("img", "metro-history.png");
                        }
                    else
                        {
                        $imageId = $row[ExtractedContentTable::COL_IMAGEID];
                        $size = 64;
                        $image = $this->context->chooseUrl ("image/$imageId/{$size}x{$size}",
                                                             "index.php?c=UserImage&id=$imageId&w=$size&h=$size");
                        }
                    $result[] = array ("url" => $url, "label" => $row[ExtractedContentTable::COL_LABEL],
                                       "description" => $row[ExtractedContentTable::COL_DESCRIPTION], 'img' => $image);
                    }
                }
            }

        $label = $searchString;
        $description = $this->getText ("Search for [_0] in the content", "<b>$searchString</b>");
        $url = $this->context->processUrl ("search.php?s=$searchString", true);
        $result[] = array ("url" => $url, "label" => $label,
                           "description" => $description, 'img' => $this->context->getResourcePath ("img", "metro-search-w.png"));

        return $result;
        }

    public function getPickList ($request, $dbtable, $filterBy)
        {
        $params[] = new FilterCriterion ($filterBy);
        if (is_callable (array ($dbtable, "getExtentedPickList")))
            return $dbtable->getExtentedPickList (20, $filterBy);

        $list = $dbtable->getPickList (NULL, 20, NULL, $params);
        return $list;
        }
    }

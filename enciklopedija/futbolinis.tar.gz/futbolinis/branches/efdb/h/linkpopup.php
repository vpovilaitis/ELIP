<?php
class LinkPopup extends PopupService
    {
    public function __construct ($context)
        {
        parent::__construct ($context, false);
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    protected function getFields ($request)
        {
        $fields = array ();
        $tableList = array ();
        $tableNames = NULL;

        if (defined ("LINK_TARGETS"))
            $tableNames = LINK_TARGETS;

        if (empty ($tableNames))
            {
            $metatables = new MetaDataTables ($this->context);

            $resultColumns = array (MetaDataTables::COL_TABLEID, MetaDataTables::COL_NAME, MetaDataTables::COL_LABEL);
            $rows = $metatables->selectBy ($resultColumns, NULL);
            foreach ($rows as $row)
                {
                $key = implode (".", array ($row[MetaDataTables::COL_TABLEID], $row[MetaDataTables::COL_NAME]));
                $tableList[$key] = $row[MetaDataTables::COL_LABEL];
                }
            }
        else
            {
            foreach (preg_split ("/[,;]\s*/", $tableNames) as $tablename)
                {
                $dbtable = ContentTable::createInstanceByName ($this->context, $tablename);
                if (empty ($dbtable))
                    continue;
                $key = implode (".", array ($dbtable->getId (), $dbtable->getName ()));
                $tableList[$key] = $dbtable->getLabel ();
                }
            }

        $fields[] = new DropDownFieldTemplate ("", "dbtable", _("Scope:"), _("Please select a search scope."), $tableList);
        $fields[] = new PopupAutocompleteField ("", "id",
                                                $this->getText ("Search for:"), $this->getText ("Enter part of the name to search for"));

        return $fields;
        }

    protected function save ($request, $values)
        {
        return false;
        }
    }

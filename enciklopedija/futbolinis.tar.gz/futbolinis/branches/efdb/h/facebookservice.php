<?php
require_once (PATH.'fb/facebook.php');

class FacebookService extends WebService
    {
    public function __construct ($context)
        {
        parent::__construct ($context);
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    static $facebook;
    public static function getInstance ()
        {
        if (empty (FacebookService::$facebook))
            {
            FacebookService::$facebook = new Facebook(array('appId' => FACEBOOK_APP_ID, 'secret' => FACEBOOK_SECRET));
            }

        return FacebookService::$facebook;
        }

    public function getData ($request)
        {
        $action = isset ($request["action"]) ? $request["action"] : NULL;

        $dbtable = new OpenIdTable ($this->context);
        if (empty ($dbtable))
            {
            $this->context->addError ("Invalid arguments passed.");
            return NULL;
            }

        switch ($action)
            {
            default: //"checkStatus"
                {
                $success = $this->checkStatus ($request, $dbtable);
                break;
                }
            }

        $result = NULL;
        if ($success)
            $result[] = array ("result" => $success);

        return $result;
        }

    protected function checkStatus ($request, $dbtable)
        {
        $fbApi = self::getInstance ();
        try
            {
            $facebookUserId = $fbApi->getUser();
            }
        catch (FacebookApiException $e)
            {
            $facebookUserId = NULL;
            }
        if (empty ($facebookUserId))
            {
            $this->context->addError ("You are not signed into the Facebook");
            return false;
            }

        //$dbtable->
        $this->context->addError ("You are successfully signed into the Facebook - '$facebookUserId'".$fbApi->getAppId());
        return false;
        }
    }

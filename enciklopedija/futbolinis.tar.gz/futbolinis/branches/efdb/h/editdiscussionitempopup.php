<?php
require_once (PATH.'pages/discussions.php');

class EditDiscussionItemPopup extends PopupService
    {
    protected $dbtable;
    protected $renderedComponent = NULL;
    protected $existingRow;

    public function __construct ($context)
        {
        parent::__construct ($context, false);
        $this->dbtable = new DiscussionsTable ($context);
        }

    protected function checkAccess ($request)
        {
        return !empty ($this->dbtable) && $this->dbtable->canCreate ();
        }

    protected function getFields ($request)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";

        $fields = array ();

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            $this->addError ("Not supported");
            return array ();
            }
        else
            {
            if ("reply" != $action)
                {
                $fields[] = new TextFieldTemplate ("", DiscussionTopicTable::COL_TITLE,
                                                   $this->getText ("Topic:"), $this->getText ("A name of the new topic."), 64);
                }

            $fields[] = new TextFieldTemplate ("", DiscussionsTable::COL_USER, _("Your name:"), _("Please enter your name or a nickname."), 64);
            $fields[] = new LongTextFieldTemplate ("", DiscussionsTable::COL_TEXT,
                                               $this->getText ("Text:"), $this->getText ("Please describe a topic or enter a reply."), 128);

            if ($this->context->getCurrentUser() > 0)
                {
                $dbtable = new UsersTable ($this->context);
                $row = $dbtable->selectSingleBy (array (UsersTable::COL_NAME), array (new EqCriterion (UsersTable::COL_ID, $this->context->getCurrentUser())));
                if (!empty ($row))
                    $this->existingRow = array (DiscussionsTable::COL_USER => $row[UsersTable::COL_NAME]);
                }
            if ("reply" != $action)
                $this->existingRow[DiscussionTopicTable::COL_TITLE] = $this->getText ("General discussions");
            }

        return $fields;
        }

    protected function getInitialValues ($request)
        {
        return $this->existingRow;
        }

    public function getData ($request)
        {
        $ret = parent::getData ($request);

        if (!empty ($this->renderedComponent))
            {
            $containerId = empty ($request["ctn"]) ? NULL : $request["ctn"]; //"d{$scope}$contextId";
            $ret = $this->getReturnedHtml ($request, "discussions", $this->renderedComponent, array ("entriesContainerId" => $containerId));
            }

        return $ret;
        }

    protected function save ($request, $values)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";
        $scope = !empty ($request["sc"]) ? $request["sc"] : NULL;
        $contextId = !empty ($request["cid"]) ? $request["cid"] : NULL;
        if (empty ($scope) || empty ($contextId))
            {
            $this->addError ("Invalid context");
            return array ();
            }

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            $this->addError ("Not supported");
            }
        else if ("new" == $action || "reply" == $action)
            {
            $text = trim ($values[DiscussionsTable::COL_TEXT]);
            $user = trim ($values[DiscussionsTable::COL_USER]);
            if (empty ($text) || empty ($user))
                {
                $this->addError ("Please enter the user name and the text");
                return array ();
                }

            if ("reply" == $action)
                {
                $topicId = !empty ($request["tid"]) ? $request["tid"] : NULL;
                if (empty ($topicId))
                    {
                    $this->addError ("Invalid context");
                    return array ();
                    }
                }
            else 
                {
                $topic = trim ($values[DiscussionTopicTable::COL_TITLE]);
                if (empty ($topic))
                    {
                    $this->addError ("Please enter the topic name");
                    return array ();
                    }

                $topicsTable = new DiscussionTopicTable ($this->context);
                $topicId = $topicsTable->create ($scope, $contextId, $topic);
                if (false === $topicId)
                    {
                    $this->addError ("Cannot create the new topic");
                    return array ();
                    }
                }

            $id = $this->dbtable->create ($topicId, $user, $text);
            if (false !== $id)
                {
                $dbtable = Discussions::getTableFromScopeName ($this->context, $scope);
                $this->renderedComponent = new DiscussionsComponent ($this->context, $scope, $contextId);
                }
            }
        else if ("show" == $action)
            {
            $id = $contextId;
            if (false !== $contextId)
                {
                $dbtable = Discussions::getTableFromScopeName ($this->context, $scope);
                $this->renderedComponent = new DiscussionsComponent ($this->context, $scope, $contextId);
                }
            }

        return $id > 0;
        }

    protected function getSaveButtonText ()
        {
        return !empty ($this->existingRow) ? $this->getText ("Save") : $this->getText ("Create");
        }
    }

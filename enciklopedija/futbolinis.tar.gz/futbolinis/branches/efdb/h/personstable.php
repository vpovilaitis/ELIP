<?php
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'inc/sports/common.php');
require_once (PATH.'h/othernamestable.php');

class PersonsTable extends ContentTable
    {
    protected $fullNameCol;
    protected $lastNameCol;
    protected $firstNameCol;
    protected $descriptionCol;

    public function __construct ($context, $instanceRow)
        {
        parent::__construct ($context, $instanceRow);
        $this->fullNameCol = $this->prepareUserColumnName ("full");
        $this->lastNameCol = $this->prepareUserColumnName ("last");
        $this->firstNameCol = $this->prepareUserColumnName ("first");
        $this->descriptionCol = $this->prepareUserColumnName ("description");
        $this->metaCol = $this->prepareUserColumnName ("meta");
        }

    public function canCreateFromLabel ()
        {
        return true;
        }

    public function createFromLabel ($label)
        {
        $parts = preg_split ("/[\+\*]/", $label, 5);
        if (count ($parts) > 1)
            {
            $namesToValues = array ($this->fullNameCol => $parts[0]);
            $country = null;

            for ($i = 1; $i < count ($parts); $i++)
                {
                if (preg_match ('/^([0-9-]+)$/', $parts[$i], $match) > 0)
                    $namesToValues['c_birthday'] = $parts[$i];
                else if (preg_match ('/^([0-9]+)kg$/', $parts[$i], $match) > 0)
                    $namesToValues['c_'.Sports::COL_PERSON_WEIGHT] = $match[1];
                else if (preg_match ('/^([0-9]+)cm$/', $parts[$i], $match) > 0)
                    $namesToValues['c_'.Sports::COL_PERSON_HEIGHT] = $match[1];
                else if (preg_match ('/^W$/U', $parts[$i], $match) > 0)
                    $namesToValues['c_woman'] = 1;
                else
                    $country = $parts[$i];
                }
            if (!empty ($country))
                {
                $table = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COUNTRY);
                $countryResult = $table->selectSingleBy (array ($table->getIdColumn ()),
                                                         array (new LikeCriterion ('c_name', $country)));

                if (!empty ($countryResult))
                    $namesToValues[ContentTable::generateForeignKeyColumn ('citizen', $table->getIdColumn ())] = $countryResult[$table->getIdColumn ()];
                }
            }
        else
            $namesToValues = array ($this->fullNameCol => $label);
        if (!empty (SportsHelper::$KnownSourceList[utf8_strtolower ($label)]))
            $namesToValues[DBTable::COL_SOURCE] = SportsHelper::$KnownSourceList[utf8_strtolower ($label)];
        else if (!empty (SportsHelper::$KnownSourceList[DBTable::COL_SOURCE]))
            $namesToValues[DBTable::COL_SOURCE] = SportsHelper::$KnownSourceList[DBTable::COL_SOURCE];

        $id = $this->insertRecord ($namesToValues);
        return $id;
        }

    protected function generateDescription (&$row)
        {
        if (empty ($row) || !array_key_exists ($this->descriptionCol, $row) || !array_key_exists ($this->metaCol, $row))
            return;

        if (!empty ($row[$this->descriptionCol]) && empty ($_REQUEST["generate"]))
            return;

        if (empty ($row[$this->descriptionCol]))
            $row[$this->descriptionCol] = $row[$this->metaCol];

        if (empty ($_REQUEST["generate"]))
            return;

        /*
        Select count of games and goals, grouped by team and competition season

        SELECT (case when p.c_hometeam = 1 THEN f_hometeam_team_id ELSE f_awayteam_team_id END) teamid,
               COUNT(*), SUM(p.c_left-p.c_entered), f_cstage_competitionstage_id, MIN(c_time), MAX(c_time)
          FROM `tx_matchplayers` p INNER JOIN tx_match m ON m.match_id = p.match_id
         WHERE `f_player_persons_id` = 236 AND (c_unused IS NULL OR c_unused = 0)
         GROUP BY teamid, f_cstage_competitionstage_id
        */
        
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $matchPlayersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHPLAYER);
        $matchGoalsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHGOAL);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        if (empty ($matchesTable) || empty ($matchPlayersTable) || empty ($matchGoalsTable) || empty ($teamsTable))
            return false;

        // first create games query
        $leagueIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $teamIdColumn = "team.id";
        $teamColumn = new ConditionalResultColumn($teamIdColumn, "c_hometeam = 1", "f_hometeam_team_id", "f_awayteam_team_id");
        $columns = array ($teamColumn, new FunctionCount ("*", "cnt"),
                          new FunctionMin ("c_time", "mintime"),
                          new FunctionMax ("c_time", "maxtime"),
                          $leagueIdColumn
                          );

        $criteria = array (new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ()));
        $join = $matchesTable->createQuery ($columns, $criteria, NULL, array (new GroupBy (array ($teamIdColumn, $leagueIdColumn))));
        
        $criteria = array (new EqCriterion ("f_player_".$this->getIdColumn (), $row[$this->getIdColumn ()]), new EqCriterion ("c_unused", 0));
        $groupedGames = $matchPlayersTable->selectBy (array (), $criteria, array ($join));
        if (empty ($groupedGames))
            $groupedGames = array ();

        // next - goals
        $teamColumn = new ConditionalResultColumn($teamIdColumn, "c_ishome = 1", "f_hometeam_team_id", "f_awayteam_team_id");
        $columns = array ($teamColumn, new FunctionCount ("*", "cnt"),
                          new FunctionMin ("c_time", "mintime"),
                          new FunctionMax ("c_time", "maxtime"),
                          $leagueIdColumn
                          );

        $criteria = array (new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ()));
        $join = $matchesTable->createQuery ($columns, $criteria, NULL, array (new GroupBy (array ($teamIdColumn, $leagueIdColumn))));

        $criteria = array (new EqCriterion ("f_player_".$this->getIdColumn (), $row[$this->getIdColumn ()]));
        $groupedGoals = $matchGoalsTable->selectBy (array (), $criteria, array ($join));
        if (empty ($groupedGoals))
            {
            if (empty ($groupedGames))
                return;
            $groupedGoals = array ();
            }

        $teamIdsWithDates = array ();
        $teamGames = array ();
        $teamGoals = array ();
        foreach ($groupedGames as $singleRow)
            {
            $id = $singleRow[$teamIdColumn];
            if (!array_key_exists ($id, $teamGames))
                {
                $teamIdsWithDates[] = array ($id, $singleRow['mintime']);
                $teamIdsWithDates[] = array ($id, $singleRow['maxtime']);
                $teamGames[$id] = array ();
                $teamGoals[$id] = array ();
                }

            $teamGames[$id][] = $singleRow;
            }

        foreach ($groupedGoals as $singleRow)
            {
            $id = $singleRow[$teamIdColumn];
            if (!array_key_exists ($id, $teamGames))
                {
                $teamIdsWithDates[] = array ($id, $singleRow['mintime']);
                $teamIdsWithDates[] = array ($id, $singleRow['maxtime']);
                $teamGames[$id] = array ();
                $teamGoals[$id] = array ();
                }

            $teamGoals[$id][] = $singleRow;
            }

        $lng = Language::getInstance ($this->context);
        $labelsByTeam = SportsHelper::getTeamLabelsByDates ($this->context, $teamIdsWithDates);
        if (!empty ($labelsByTeam))
            {
            $teams = array ();
            foreach ($labelsByTeam as $id => $teamLabels)
                {
                $minDate = NULL;
                $maxDate = NULL;
                $labels = array ();
                foreach ($teamLabels as $date => $label)
                    $labels[] = $label;

                $labels = array_unique ($labels);
                $matchesPlayed = 0;
                $goalsScored = 0;

                foreach ($teamGames[$id] as $singleRow)
                    {
                    $matchesPlayed += $singleRow["cnt"];
                    if (NULL === $minDate || $minDate > $singleRow["mintime"])
                        $minDate = $singleRow["mintime"];
                    if (NULL === $maxDate || $maxDate < $singleRow["maxtime"])
                        $maxDate = $singleRow["maxtime"];
                    }

                foreach ($teamGoals[$id] as $singleRow)
                    {
                    $goalsScored += $singleRow["cnt"];
                    if (NULL === $minDate || $minDate > $singleRow["mintime"])
                        $minDate = $singleRow["mintime"];
                    if (NULL === $maxDate || $maxDate < $singleRow["maxtime"])
                        $maxDate = $singleRow["maxtime"];
                    }

                $url = $teamsTable->getContentLink ($id);
                $name = "<a href=\"$url\">".implode (", ", $labels)."</a>";
                $minDate = $lng->dateToLongString ($minDate, "month");
                $maxDate = $lng->dateToLongString ($maxDate, "month");
                if ($minDate == $maxDate)
                    $date = $minDate;
                else
                    $date = $this->getText ("[_0]-[_1]", $minDate, $maxDate);

                if (0 == $matchesPlayed && 0 == $goalsScored)
                    continue;

                if (0 == $matchesPlayed)
                    $teams[] = $this->ngettext ("[_1] ([_0] goals on [_2])", "[_1] ([_0] goals during [_2])",
                                                $goalsScored, $name, $date);
                else if (0 == $goalsScored)
                    $teams[] = $this->ngettext ("[_1] ([_0] match on [_2])", "[_1] ([_0] matches during [_2])",
                                                $matchesPlayed, $name, $date);
                else
                    {
                    $goalsText = $this->ngettext ("[_0] goal", "[_0] goals", $goalsScored);
                    $teams[] = $this->ngettext ("[_1] ([_2] in [_0] match on [_3])", "[_1] ([_2] in [_0] matches during [_3])",
                                                $matchesPlayed, $name, $goalsText, $date);
                    }
                }

            $row[$this->descriptionCol] .= "\n\n".$this->getText ("Played in following teams: [_0].", implode (", ", $teams));
            }
        }

    public function selectBy ($resultColumns, $criteria, $joinedQueries = NULL, $queryParams = NULL, $tableAlias = NULL)
        {
        $rows = parent::selectBy ($resultColumns, $criteria, $joinedQueries, $queryParams, $tableAlias);

        if (!empty ($queryParams) && false !== array_search ("View", $queryParams) && 1 == count ($rows))
            $this->generateDescription ($rows[0]);

        return $rows;
        
        }

    public function insertRecord ($nameToValue)
        {
        if (empty ($nameToValue[$this->fullNameCol]))
            {
            $parts = array ();
            if (!empty ($nameToValue[$this->lastNameCol]))
                $parts[] = $nameToValue[$this->firstNameCol];
            if (!empty ($nameToValue[$this->lastNameCol]))
                $parts[] = $nameToValue[$this->lastNameCol];

            if (!empty ($parts))
                $nameToValue[$this->fullNameCol] = implode (" ", $parts);
            }
        else if (empty ($nameToValue[$this->lastNameCol]) && empty ($nameToValue[$this->firstNameCol]))
            {
            $label = $nameToValue[$this->fullNameCol];
            $lastname = strrchr ($label, " ");
            if (false === $lastname)
                $lastname = $label;
            else
                {
                $firstname = substr ($label, 0, 0 - strlen ($lastname) );
                $nameToValue[$this->firstNameCol] = $firstname;
                $lastname = trim ($lastname);
                }

            $nameToValue[$this->lastNameCol] = $lastname;
            }

        $id = parent::insertRecord ($nameToValue);
        if (false !== $id)
            {
            $namesTable = ContentTable::createInstanceByName ($this->context, "person_names");
            if (!empty ($namesTable) && $namesTable->canCreate ())
                {
                $namesToValues = array ();
                if (!empty ($nameToValue[$this->firstNameCol]))
                    $namesToValues["c_".OtherNamesTable::COL_FIRSTNAME] = $nameToValue[$this->firstNameCol];
                $namesToValues["c_".OtherNamesTable::COL_SURNAME] = $nameToValue[$this->lastNameCol];
                $namesToValues["c_".OtherNamesTable::COL_SOURCETYPE] = OtherNamesTable::SRCTYPE_GENERATED;
                $namesToValues[OtherNamesTable::COL_PERSON] = array ($id);
                $affected = $namesTable->insertRecord ($namesToValues);
                if (false === $affected)
                    {
                    $this->context->log ("Error inserting person_names record");
                    }
                }
            }

        return $id;
        }

    protected function updateById ($idCriteria, $criteria, $nameToValue, $tracksRevisions = NULL)
        {
        $needOtherNameUpdating = !empty ($nameToValue[$this->lastNameCol]) || !empty ($nameToValue[$this->firstNameCol]);
        if ($needOtherNameUpdating)
            {
            // reset "alternate names table updated" flag
            $nameToValue["c_othernamesupdated"] = "0000-00-00 00:00:00";
            }
        else if (1 == count ($nameToValue) && array_key_exists ("c_othernamesupdated", $nameToValue))
            {
            $tracksRevisions = false;
            }

        $ret = parent::updateById ($idCriteria, $criteria, $nameToValue, $tracksRevisions);

        $namesTable = ContentTable::createInstanceByName ($this->context, "person_names");
        if (false !== $ret && !empty ($namesTable) && $namesTable->canEdit () && $needOtherNameUpdating)
            {
            $namesCriteria = array (clone $idCriteria[0]);
            $namesCriteria[0]->field = OtherNamesTable::COL_PERSON;
            $namesCriteria[] = new EqCriterion (OtherNamesTable::COL_SOURCETYPE, OtherNamesTable::SRCTYPE_GENERATED);
            $namesToValues = array ();
            if (!empty ($nameToValue[$this->firstNameCol]))
                $namesToValues["c_".OtherNamesTable::COL_FIRSTNAME] = $nameToValue[$this->firstNameCol];
            if (!empty ($nameToValue[$this->lastNameCol]))
                $namesToValues["c_".OtherNamesTable::COL_SURNAME] = $nameToValue[$this->lastNameCol];

            $affected = $namesTable->updateRecord ($namesCriteria, $namesToValues, 1);
            if (false === $affected)
                {
                $this->context->log ("Error inserting person_names record");
                }
            }
        return $ret;
        }

    protected function createFilterColumn ($sortColumns)
        {
        return new PersonFilterColumn ($this, $this->displayNameColumn, $sortColumns);
        }

    public function getExtentedPickList ($maxResults, $filterCriteria)
        {
        $params[] = new FilterCriterion ($filterCriteria);

        if ($maxResults > 20)
            $maxResults = 20;

        $list = $this->getPickList (NULL, $maxResults, NULL, $params, false, true);
        if (empty ($list))
            return $list;

        $idArray = array ();
        foreach ($list as $id => $label)
            $idArray[] = $id;

        $idToTeam = $this->findPlayerTeamLabels ($idArray);
        $result = array ();
        foreach ($list as $id => $pair)
            {
            list ($label, $description) = $pair;

            if (!empty ($description))
                $description = $this->trimSentence ($description, 70);

            if (!empty ($idToTeam[$id]))
                {
                $teamsRecorded = implode (", ", $idToTeam[$id]);
                if (!empty ($description))
                    $description = htmlspecialchars ($teamsRecorded)."\n<br>\n".htmlspecialchars ($description);
                else
                    $description = htmlspecialchars ($teamsRecorded);
                }

            $result[$id] = array ($label, $description);
            }
        return $result;
        }

    public function collectPlayerTeams ($tableName, &$idToTeams, $idArray, $homeTeamColumn, $additionalCriteria, $playerColumn = "player")
        {
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $dbtable = ContentTable::createInstanceByName ($this->context, $tableName);
        $teamIdColumn = "team.id";
        $teamColumn = new ConditionalResultColumn($teamIdColumn, "$homeTeamColumn = 1", "f_hometeam_team_id", "f_awayteam_team_id");
        $columns = array ($teamColumn, new FunctionCount ("*", "cnt"),
                          new FunctionMin ("c_time", "mintime"),
                          new FunctionMax ("c_time", "maxtime"),
                          );
        $criteria = array (new EqCriterion ("c_unofficial", 0),
                           new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ()));
        /*
        $criteria[] = new InCriterion (ContentTable::prepareUserColumnName (Sports::COL_MATCH_OUTCOME),
                                       array (MatchConstants::OUTCOME_FULL_TIME, MatchConstants::OUTCOME_EXTRA_TIME,
                                              MatchConstants::OUTCOME_PENALTIES, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                              MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_NOT_STARTED,
                                              MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        */

        $join = $matchesTable->createQuery ($columns, $criteria, NULL, array (new GroupBy (array ($teamIdColumn))));

        $criteria = $additionalCriteria;
        $personIdColumn = "f_{$playerColumn}_".$this->getIdColumn ();
        $criteria[] = new InCriterion ($personIdColumn, $idArray);
        $params = array (new GroupBy (array ($personIdColumn)));

        $rows = $dbtable->selectBy (array ($personIdColumn), $criteria, array ($join), $params);
        if (empty ($rows))
            return;

        foreach ($rows as $row)
            {
            $personId = $row[$personIdColumn];
            $teamId = $row[$teamIdColumn];
            if (empty ($idToTeams[$personId]))
                $idToTeams[$personId] = array ();

            if (empty ($idToTeams[$personId][$teamId]))
                $idToTeams[$personId][$teamId] = array ($row["mintime"], $row["maxtime"]);
            else
                {
                $idToTeams[$personId][$teamId][0] = min ($row["mintime"], $idToTeams[$personId][$teamId][0]);
                $idToTeams[$personId][$teamId][1] = max ($row["maxtime"], $idToTeams[$personId][$teamId][1]);
                }
            }
        }

    public function findPlayerTeamLabels ($idArray)
        {
        $idToTeams = array ();
        $this->collectPlayerTeams (Sports::TABLE_MATCHGOAL, $idToTeams, $idArray,
                                   "c_ishome", array (new EqCriterion ("c_own", 0)));
        $this->collectPlayerTeams (Sports::TABLE_MATCHPLAYER, $idToTeams, $idArray, "c_hometeam", NULL);
        $this->collectPlayerTeams (Sports::TABLE_MATCHEVENT, $idToTeams, $idArray, "c_ishome", NULL);

        // now try to find in which teams player has scored goals or recieved cards
        $unrecognizedIds = array ();
        foreach ($idArray as $id)
            {
            if (empty ($idToTeams[$id]))
                $unrecognizedIds[] = $id;
            }

        $lng = Language::getInstance ($this->context);
        $idToTeamLabels = array ();
        if (!empty ($idToTeams))
            {
            $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
            $teamIdsWithDates = array ();
            foreach ($idToTeams as $playerId => $teams)
                {
                foreach ($teams as $id => $minmax)
                    {
                    list ($min, $max) = $minmax;
                    $teamIdsWithDates[] = array ($id, $min);
                    $teamIdsWithDates[] = array ($id, $max);
                    }
                }

            $labelsByTeam = SportsHelper::getTeamLabelsByDates ($this->context, $teamIdsWithDates);

            foreach ($idToTeams as $playerId => $teams)
                {
                $labels = array ();
                foreach ($teams as $teamId => $period)
                    {
                    list ($min, $max) = $period;
                    $labelMin = $labelsByTeam[$teamId][$min];
                    $labelMax = $labelsByTeam[$teamId][$max];
                    if (!empty ($labelMin) && !empty ($labelMax) && $labelMin != $labelMax)
                        {
                        $label = $labelMax." (".$labelMin."; ";
                        }
                    else
                        $label = (empty ($labelMax) ? $labelMin : $labelMax)." (";

                    $periodStart = substr ($min, 0, 4);
                    $periodEnd = substr ($max, 0, 4);
                    if ($periodStart == $periodEnd)
                        $labels[] = $this->getText ("[_0][_1])|team member from-to", $label, $periodStart);
                    else
                        $labels[] = $this->getText ("[_0][_1]-[_2])|team member from-to", $label, $periodStart, $periodEnd);
                    }
                $idToTeamLabels[$playerId] = $labels;
                }
            }

        if (empty ($unrecognizedIds))
            return $idToTeamLabels;

        $careerTable = ContentTable::createInstanceByName ($this->context, "teamplayer");
        if (!empty ($careerTable))
            {
            $criteria[] = new InCriterion ("f_person_persons_id", $unrecognizedIds);
            // $criteria[] = new IsNullCriterion ("c_ended");
            $params = array (OrderBy::create ("c_started", true));
            $rows = $careerTable->selectBy (array ("f_person_persons_id", "team.shortname", "started", "ended"), $criteria, NULL, $params);
            if (empty ($rows))
                $rows = array ();

            foreach ($rows as $row)
                {
                $id = $row["f_person_persons_id"];
                $label = $row["team.c_shortname"];
                if (!empty ($row["c_started"]) && !empty ($row["c_ended"]))
                    $label = $this->getText ("[_0] ([_1]-[_2])|team member from-to", $label, substr ($row["c_started"], 0, 4), substr ($row["c_ended"], 0, 4));
                else if (!empty ($row["c_started"]))
                    $label = $this->getText ("[_0] (from [_1])|team member from", $label, substr ($row["c_started"], 0, 4));

                if (empty ($idToTeamLabels[$id]))
                    $idToTeamLabels[$id] = array ();
                $idToTeamLabels[$id][] = $label;
                }
            }

        return $idToTeamLabels;
        }

    protected function indexSingleRow ($row)
        {
        $indexed = parent::indexSingleRow ($row);
        $indexed["indexedLabel"] = $indexed["label"]." ".$row["c_oldsurname"]." ".$row["c_birthday"];
        return $indexed;
        }

    protected function postprocessIndexedData (&$extracted)
        {
        if (empty ($extracted))
            return true;

        $ids = array ();
        foreach ($extracted as $id => $row)
            $ids[] = $id;

        $idToTeam = $this->findPlayerTeamLabels ($ids);
        foreach ($extracted as $id => &$row)
            {
            if (empty ($idToTeam[$id]))
                continue;
            $row['chunks'] = array_merge ($row['chunks'], $idToTeam[$id]);
            }

        return true;
        }
    }

class PersonFilterColumn extends FilterColumn
    {
    protected $context;
    protected $dbtable;
    protected static $cachedOtherNameResults = array ();

    public function __construct ($dbtable, $displayNameColumn, $sortColumns)
        {
        parent::__construct ($dbtable, $displayNameColumn, $sortColumns);
        $this->context = $dbtable->getContext ();
        $this->dbtable = $dbtable;
        }

    protected function getMatchingIdsByAlternativeNames ($name, $surname, $limit)
        {
        $key = "$name|$surname";
        if (!array_key_exists ($key, self::$cachedOtherNameResults))
            self::$cachedOtherNameResults[$key] = $this->selectByOtherNames ($name, $surname, $limit);

        return self::$cachedOtherNameResults[$key];
        }

    protected function selectByOtherNames ($name, $surname, $limit, $exactMatch = true)
        {
        $namesTable = ContentTable::createInstanceByName ($this->context, "person_names");
        if (empty ($namesTable))
            return NULL;

        $nameColumn = $namesTable->findColumn ("name")->columnDef;
        $tryLoose = true;

        if ($exactMatch && !empty ($surname) && $surname[strlen ($surname) - 1] == "+")
            {
            $exactMatch = false;
            $surname = substr ($surname, 0, -1);
            }
        else if (!empty ($surname) && $surname[strlen ($surname) - 1] == "!")
            {
            if (!$exactMatch)
                return NULL;
            $surname = substr ($surname, 0, -1);
            $tryLoose = false;
            }

        $surnameCriterionClass = $exactMatch ? "EqCriterion" : "LikeCriterion";

        if (!empty ($surname) && !empty ($name))
            {
            $name = OtherNamesTable::removeDiacritics ($name);
            $surname = OtherNamesTable::removeDiacritics ($surname);
            $crit[] = new LogicalOperatorAnd
                (
                new LikeCriterion ("c_".OtherNamesTable::COL_SIMPLIFIEDFIRST, trim ($name, " .,")),
                new $surnameCriterionClass ("c_".OtherNamesTable::COL_SIMPLIFIEDLAST, trim ($surname, " .,"))
                );
            }
        else if (empty ($surname))
            return NULL;
        else
            {
            $surname = OtherNamesTable::removeDiacritics ($surname);
            $crit[] = new $surnameCriterionClass ("c_".OtherNamesTable::COL_SIMPLIFIEDLAST, trim ($surname, " .,"));
            }

        if (empty ($limit))
            $limit = new LimitResults (0, 20);
        else
            $limit = new LimitResults (0, $limit->upperBound - $limit->lowerBound);
        $rows = $namesTable->selectBy (array ("f_person_persons_id"), $crit, NULL, array ($limit));
        if (empty ($rows))
            {
            // if exact match not found, try matching surname with LIKE
            if ($tryLoose && "LikeCriterion" !== $surnameCriterionClass)
                return $this->selectByOtherNames ($name, $surname, $limit, false);
            return NULL;
            }

        $ids = array ();
        foreach ($rows as $row)
            {
            $id = $row["f_person_persons_id"];
            if (false === array_search ($id, $ids))
                $ids[] = $id;
            }

        return $ids;
        }

    public function prepareQuery ($filterCriterion, &$criteria, &$joins, &$params = NULL)
        {
        $filterBy = trim ($filterCriterion->criterion);

        if (preg_match ('/^(.+)[+* ]([0-9]{4}-[0-9]{2}-[0-9]{2})/', $filterBy, $match) > 0)
            {
            $filterCriterion->criterion = $filterBy = $match[1];
            $birthDate = $match[2];
            }

        $year = strrchr ($filterBy, " ");
        if (is_numeric (trim ($year)))
            {
            $filterCriterion->criterion = $filterBy = substr ($filterBy, 0, -strlen ($year));
            $year = trim ($year);
            }
        else
            $year = NULL;

        $parts = preg_split ("/[. ]+/", $filterBy, 2);
        if (2 == count ($parts))
            $filterCriterion->criterion = trim ($parts[0])." ".trim ($parts[1]);

        $limit = NULL;
        if (!empty ($params))
            {
            foreach ($params as $param)
                {
                if (!$param instanceof LimitResults)
                    continue;
                $limit = $param;
                }
            }

        $ids = $this->getMatchingIdsByAlternativeNames (count ($parts) > 1 ? $parts[0] : NULL, count ($parts) > 1 ? $parts[1] : $parts[0], $limit);

        if (empty ($ids))
            {
            $containsWildCard = false !== strpbrk ($filterBy, "*%_");
            if ($containsWildCard)
                {
                // lets fall back to inneficient query
                return parent::prepareQuery ($filterCriterion, $criteria, $joins, $params);
                }
            return false;
            }

        $criteria[] = new InCriterion ($this->dbtable->getIdColumn(), $ids);
        if (!empty ($year)) // filter by birthday
            {
            $criteria[] = new LogicalOperatorOr
                                    (
                                    new LtCriterion ("c_birthday", $year-10),
                                    new IsNullCriterion ("c_birthday")
                                    );
            $criteria[] = new LogicalOperatorOr
                                    (
                                    new GtEqCriterion ("c_deathday", $year),
                                    new IsNullCriterion ("c_deathday")
                                    );
            }
        if (!empty ($birthDate))
            $criteria[] = new EqCriterion ("c_birthday", $birthDate);
        }
    }

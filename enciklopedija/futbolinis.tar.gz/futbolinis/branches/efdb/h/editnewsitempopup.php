<?php
require_once (PATH.'inc/popupservice.php');
require_once (PATH.'inc/newstable.php');

class EditNewsItemPopup extends PopupService
    {
    protected $dbtable;
    protected $returnType = NULL;
    protected $existingRow;
    protected $previewData;
    
    const RETURN_HTML = 1;
    const RETURN_PREVIEW = 2;

    public function __construct ($context)
        {
        parent::__construct ($context, true);
        $scope = !empty ($_REQUEST["sp"]) ? $_REQUEST["sp"] : false;
        $this->dbtable = new NewsTable ($context, $scope);
        }

    protected function checkAccess ($request)
        {
        return !empty ($this->dbtable) && $this->dbtable->canCreate ();
        }

    protected function getFields ($request)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";

        $fields = array ();

        $fields[] = new TextFieldTemplate ("", NewsTable::COL_TITLE,
                                           $this->getText ("Title:"), $this->getText ("News item title"), 64);
        $fields[] = new LongTextFieldTemplate ("", NewsTable::COL_OVERVIEW,
                                           $this->getText ("Overview:"), $this->getText ("Short overview"), 128);
        $fields[] = new LongTextFieldTemplate ("", NewsTable::COL_DETAILS,
                                           $this->getText ("Full text:"), $this->getText ("Full news item content"));

        if ("edit" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }
            $criteria[] = new EqCriterion (NewsTable::COL_ID, $id);
            $columns = array (NewsTable::COL_ID, NewsTable::COL_TITLE, NewsTable::COL_OVERVIEW, NewsTable::COL_DETAILS, NewsTable::COL_HIDDEN);
            $this->existingRow = $this->dbtable->selectSingleBy ($columns, $criteria);
            if (empty ($this->existingRow))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            if (!empty ($this->existingRow[NewsTable::COL_HIDDEN]))
                {
                $fields[] = new CheckBoxFieldTemplate ("", NewsTable::COL_HIDDEN,
                                                       $this->getText ("Leave unpublished"), $this->getText ("Do not make this entry publicly available (must be published manually)."));
                }
            else
                {
                $fields[] = new CheckBoxFieldTemplate ("", NewsTable::COL_UPDATE_ENTRY_DATE,
                                                       $this->getText ("Mark updated"), $this->getText ("Mark this news item as updated."));
                }
            }
        else
            {
            $fields[] = new CheckBoxFieldTemplate ("", NewsTable::COL_HIDDEN,
                                                   $this->getText ("Do not publish"), $this->getText ("Do not make this entry publicly available (must be published manually)."));
            }

        return $fields;
        }

    public function select ($context, $criteria)
        {
        return $this->dbtable->selectNews (NewsTable::DEFAULT_ITEMS, NULL, $this->dbtable->canEdit ());
        }

    protected function executeCustomAction ($request, $mode)
        {
        if ("preview" == $mode)
            {
            $values = $this->prepareValues ($request);
            if (!empty ($values) && empty ($values[NewsTable::COL_DETAILS]))
                $values[NewsTable::COL_DETAILS] = $values[NewsTable::COL_OVERVIEW];
            $this->previewData = new NewsPreviewData ($this->context, $values);
            $this->returnType = self::RETURN_PREVIEW;
            return true;
            }

        return parent::executeCustomAction ($request, $mode);
        }

    public function getData ($request)
        {
        $ret = parent::getData ($request);

        if (self::RETURN_HTML === $this->returnType)
            {
            $ret = $this->getReturnedHtml ($request, "news");
            }
        else if (self::RETURN_PREVIEW === $this->returnType)
            {
            $ret = $this->getReturnedHtml ($request, "pages/newsitem", $this->previewData);
            }

        return $ret;
        }

    public function getUniqueId ()
        {
        return $this->context->request["uniqueId"];
        }

    protected function getInitialValues ($request)
        {
        return $this->existingRow;
        }

    protected function save ($request, $values)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";

        if ("edit" == $action || "publish" == $action)
            {
            $id = !empty ($request["id"]) ? $request["id"] : NULL;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return array ();
                }

            if ("publish" == $action)
                $values = array (NewsTable::COL_HIDDEN => false);

            $criteria[] = new EqCriterion (NewsTable::COL_ID, $id);
            $affected = $this->dbtable->updateRecord ($criteria, $values);
            if (1 != $affected)
                $this->addError ("Error");
            else
                $this->returnType = self::RETURN_HTML;
            }
        else if ("new" == $action)
            {
            $id = $this->dbtable->insertRecord ($values);
            if (false !== $id)
                $this->returnType = self::RETURN_HTML;
            }

        return $id > 0;
        }

    protected function getSaveButtonText ()
        {
        return !empty ($this->existingRow) ? $this->getText ("Save") : $this->getText ("Create");
        }

    public function getDescriptor ()
        {
        return new NewsLinkDescriptor ($this->context, $this->dbtable, $this->getUniqueId ());
        }

    protected function getButtons ()
        {
        $buttons = parent::getButtons ();
        $buttons["preview"] = $this->getText ("Preview");
        return $buttons;
        }
    }

class NewsPreviewData
    {
    protected $values;

    public function __construct ($context, $values)
        {
        $this->values = $values;
        }
        
    public function getInstance ()
        {
        return $this->values;
        }

    public function getActionList ()
        {
        return array ();
        }

    public function getConfirmField ()
        {
        return "";
        }
    }

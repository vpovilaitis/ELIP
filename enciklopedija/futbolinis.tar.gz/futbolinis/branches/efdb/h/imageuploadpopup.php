<?php

class ImageUploadPopup extends PopupService
    {
    protected $dbtable;
    protected $returnType = NULL;
    protected $existingRow;
    protected $imageId;
    protected $imageTitle;
    
    const RETURN_HTML = 1;
    const RETURN_XML = 2;

    public function __construct ($context)
        {
        parent::__construct ($context, false);
        $this->dbtable = new ImagesTable ($context);
        }

    protected function checkAccess ($request)
        {
        return !empty ($this->dbtable) && $this->dbtable->canCreate ();
        }

    protected function getUploadField ()
        {
        return new FileFieldTemplate ("", ImagesTable::COL_FILENAME,
                                      $this->getText ("Image:"), $this->getText ("Select an image to upload"));
        }

    protected function getFields ($request)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";

        $fields = array ();

        if ("new" == $action || "edit" == $action)
            {
            $licenseTable = new ImageLicenseTable ($this->context);
            $licenseRows = $licenseTable->selectLicenses ();
            $licenses = array ();
            if (!empty ($licenseRows))
                {
                foreach ($licenseRows as $row)
                    {
                    if (empty ($row[ImageLicenseTable::COL_DESCRIPTION]))
                        $label = $row[ImageLicenseTable::COL_NAME];
                    else
                        $label = $row[ImageLicenseTable::COL_DESCRIPTION];
                    $licenses[$row[ImageLicenseTable::COL_ID]] = $label;
                    }
                }

            if (empty ($request["zone"]))
                {
                $this->addError ("Invalid context given");
                return false;
                }
            $zone = $request["zone"];
        
            if ("new" == $action)
                {
                $fields[] = $this->getUploadField ();
                if (ImageUseTable::ZONE_LOGO == $zone)
                    {
                    $fields[] = new DateFieldTemplate ("", ImageUseTable::COL_DATEFROM,
                                                       $this->getText ("Adopted:"), $this->getText ("Date logo was adopted"));
                    $fields[] = new DateFieldTemplate ("", ImageUseTable::COL_DATETO,
                                                       $this->getText ("Retired:"), $this->getText ("Date logo was retired"));
                    $fields[] = new LongTextFieldTemplate ("", ImagesTable::COL_DESCRIPTION,
                                                       $this->getText ("Description:"), $this->getText ("Detailed logo description (if any)"));
                    $uploadStatus = array (0 => $this->getText ("unknown"),
                                           1 => $this->getText ("I confirm that this logo will be used under fair use terms"));
                    $this->existingRow = array ("confirm" => 1);
                    }
                else if (ImageUseTable::ZONE_REPORT == $zone)
                    {
                    $fields[] = new TextFieldTemplate ("", ImagesTable::COL_LABEL,
                                                       $this->getText ("Label:"), $this->getText ("Short image description"), 64);
                    $fields[] = new LongTextFieldTemplate ("", ImagesTable::COL_DESCRIPTION,
                                                       $this->getText ("Description:"), $this->getText ("Detailed logo description (if any)"));
                    $uploadStatus = array (0 => $this->getText ("unknown"),
                                           1 => $this->getText ("I confirm that this is official match report"));
                    $this->existingRow = array ("confirm" => 1);
                    }
                else
                    {
                    $fields[] = new TextFieldTemplate ("", ImagesTable::COL_LABEL,
                                                       $this->getText ("Label:"), $this->getText ("Short image description"), 64);
                    $fields[] = new LongTextFieldTemplate ("", ImagesTable::COL_DESCRIPTION,
                                                       $this->getText ("Description:"), $this->getText ("Full image description (if any)"));
                    $fields[] = new TextFieldTemplate ("", ImagesTable::COL_KEYWORDS,
                                                       $this->getText ("Keywords:"), $this->getText ("Category names or keywords (separated with comma)"), 128);
                    $fields[] = new DropDownFieldTemplate ("", ImagesTable::COL_LICENSE_ID,
                                                           $this->getText ("License:"), $this->getText ("Terms under which the image is published"), $licenses);
                    $fields[] = new TextFieldTemplate ("", ImagesTable::COL_AUTHOR,
                                                       $this->getText ("Author:"), $this->getText ("Creator of the image"), 128);
                    $uploadStatus = array (0 => $this->getText ("unknown"),
                                           1 => $this->getText ("I am the creator of the image"),
                                           2 => $this->getText ("I have written permission to use the image"));
                    }
                $fields[] = new DropDownFieldTemplate ("", "confirm",
                                                       $this->getText ("Upload status:"), "", $uploadStatus);
                }
            else if ("edit" == $action)
                {
                if (empty ($request["id"]))
                    {
                    $this->addError ("Invalid id given");
                    return array ();
                    }
                if (empty ($request["sc"]) || empty ($request["cid"]))
                    {
                    $this->addError ("Invalid context given");
                    return false;
                    }
                $scope = $request["sc"];
                $contextId = $request["cid"];
                $id = $request["id"];

                $fields[] = new TextFieldTemplate ("", ImageUseTable::COL_TITLE,
                                                   $this->getText ("Display label:"), $this->getText ("Image title displayed in this page"), 64);
                if (ImageUseTable::ZONE_LOGO == $zone)
                    {
                    $fields[] = new DateFieldTemplate ("", ImageUseTable::COL_DATEFROM,
                                                       $this->getText ("Adopted:"), $this->getText ("Date logo was adopted"));
                    $fields[] = new DateFieldTemplate ("", ImageUseTable::COL_DATETO,
                                                       $this->getText ("Retired:"), $this->getText ("Date logo was retired"));
                    $fields[] = new LongTextFieldTemplate ("", ImagesTable::COL_DESCRIPTION,
                                                       $this->getText ("Description:"), $this->getText ("Detailed logo description (if any)"));
                    $fields[] = new TextFieldTemplate ("", ImagesTable::COL_KEYWORDS,
                                                       $this->getText ("Keywords:"), $this->getText ("Category names or keywords (separated with comma)"), 128);
                    }
                else if (ImageUseTable::ZONE_REPORT == $zone)
                    {
                    $fields[] = new TextFieldTemplate ("", ImagesTable::COL_LABEL,
                                                       $this->getText ("Label:"), $this->getText ("Short image description"), 64);
                    $fields[] = new LongTextFieldTemplate ("", ImagesTable::COL_DESCRIPTION,
                                                       $this->getText ("Description:"), $this->getText ("Detailed logo description (if any)"));
                    $fields[] = new TextFieldTemplate ("", ImagesTable::COL_KEYWORDS,
                                                       $this->getText ("Keywords:"), $this->getText ("Category names or keywords (separated with comma)"), 128);
                    }
                else
                    {
                    $fields[] = new TextFieldTemplate ("", ImagesTable::COL_LABEL,
                                                       $this->getText ("Searchable label:"), $this->getText ("Short image description (for search)"), 64);
                    $fields[] = new LongTextFieldTemplate ("", ImagesTable::COL_DESCRIPTION,
                                                       $this->getText ("Description:"), $this->getText ("Full image description (if any)"));
                    $fields[] = new TextFieldTemplate ("", ImagesTable::COL_KEYWORDS,
                                                       $this->getText ("Keywords:"), $this->getText ("Category names or keywords (separated with comma)"), 128);
                    $fields[] = new DropDownFieldTemplate ("", ImagesTable::COL_LICENSE_ID,
                                                       $this->getText ("License:"), $this->getText ("Terms under which the image is published"), $licenses);
                    $fields[] = new TextFieldTemplate ("", ImagesTable::COL_AUTHOR,
                                                       $this->getText ("Author:"), $this->getText ("Creator of the image"), 128);
                    }

                $imageUseTable = new ImageUseTable ($this->context);
                $criteria = array (new JoinColumnsCriterion (ImageUseTable::COL_IMAGEID, ImagesTable::COL_ID));
                $criteria[] = new EqCriterion (ImageUseTable::COL_SCOPE, $scope);
                $criteria[] = new EqCriterion (ImageUseTable::COL_CONTEXTID, $contextId);
                $criteria[] = new EqCriterion (ImageUseTable::COL_ZONE, $zone);
                $join = $imageUseTable->createQuery (array (ImageUseTable::COL_TITLE, ImageUseTable::COL_DATEFROM, ImageUseTable::COL_DATETO), $criteria);
                $criteria = array (new EqCriterion (ImagesTable::COL_ID, $id));
                $columns = array (ImagesTable::COL_ID, ImagesTable::COL_LABEL, ImagesTable::COL_DESCRIPTION, ImagesTable::COL_KEYWORDS, ImagesTable::COL_LICENSE_ID, ImagesTable::COL_AUTHOR);
                $this->existingRow = $this->dbtable->selectSingleBy ($columns, $criteria, array ($join));
                if (empty ($this->existingRow))
                    {
                    $this->addError ("Invalid id given");
                    return array ();
                    }
                }
            }
        else
            {
            $fields[] = new ImageAutocompleteField ("", ImageUseTable::COL_IMAGEID,
                                                    $this->getText ("Search for:"), $this->getText ("Enter part of the name to search for an image"));
            $fields[] = new TextFieldTemplate ("", ImageUseTable::COL_TITLE,
                                               $this->getText ("New title:"), $this->getText ("Short image description"), 64);
            }

        return $fields;
        }

    public function processInput ($context, &$request)
        {
        $this->getData ($request);
        return true;
        }

    protected function getDisplayParams ($request)
        {
        if (self::RETURN_HTML === $this->returnType)
            return array ("this" => $this);
        return parent::getDisplayParams ($request);
        }

    public function getData ($request)
        {
        if (empty ($this->cachedData))
            $this->cachedData = parent::getData ($request);
        return $this->cachedData;
        }

    public function getTemplateName ()
        {
        if (self::RETURN_HTML === $this->returnType)
            return "fileuploadresults";
        return parent::getTemplateName ();
        }

    public function getResultString ()
        {
        if ($this->containsErrors ())
            return implode ("\r\n", $this->getErrors ());
        return "OK";
        }

    public function getFormId ()
        {
        return !empty ($this->request["formid"]) ? $this->request["formid"] : "";
        }

    protected function getInitialValues ($request)
        {
        return $this->existingRow;
        }

    public function getImageUrl ()
        {
        $width = "#w#";
        $height = "#h#";
        return $this->context->chooseUrl ("image/$this->imageId/{$width}x{$height}",
                                          "index.php?c=UserImage&id=$this->imageId&w=$width&h=$height");
        }

    public function getGaleryUrl ()
        {
        if (empty ($this->request["sc"]) || empty ($this->request["cid"]))
            return NULL;

        $scope = $this->request["sc"];
        $contextId = $this->request["cid"];
        return $this->context->chooseUrl ("galery/$scope/$contextId/$this->imageId",
                                          "index.php?c=ImageGalery&sc=$scope&id=$contextId&highlight=$this->imageId");
        }

    public function getImageTitle ()
        {
        return $this->imageTitle;
        }

    protected function save ($request, $values)
        {
        $action = !empty ($request["action"]) ? $request["action"] : "";
        $imageUseTable = new ImageUseTable ($this->context);

        if (empty ($request["sc"]) || empty ($request["cid"]) || empty ($request["zone"]))
            {
            $this->addError ("Invalid context given");
            return false;
            }
        $scope = $request["sc"];
        $contextId = $request["cid"];
        $zone = $request["zone"];

        if ("edit" == $action)
            {
            $this->returnType = self::RETURN_XML;
            if (empty ($request["id"]))
                {
                $this->addError ("Invalid id given");
                return false;
                }
            $id = $request["id"];

            $imageUseValues = array
                (
                ImageUseTable::COL_TITLE => $values[ImageUseTable::COL_TITLE],
                );
            unset ($values[ImageUseTable::COL_TITLE]);

            if (ImageUseTable::ZONE_LOGO == $zone)
                {
                $imageUseValues[ImageUseTable::COL_DATEFROM] = $values[ImageUseTable::COL_DATEFROM];
                $imageUseValues[ImageUseTable::COL_DATETO] = $values[ImageUseTable::COL_DATETO];
                unset ($values[ImageUseTable::COL_DATEFROM]);
                unset ($values[ImageUseTable::COL_DATETO]);
                }

            $criteria[] = new EqCriterion (ImagesTable::COL_ID, $id);
            $affected = $this->dbtable->updateRecord ($criteria, $values);
            if (1 != $affected)
                {
                $this->addError ("Error");
                return false;
                }

            if (empty ($imageUseValues[ImageUseTable::COL_TITLE]))
                $imageUseValues[ImageUseTable::COL_TITLE] = $values[ImagesTable::COL_LABEL];
            $criteria = array ();
            $criteria[] = new EqCriterion (ImageUseTable::COL_IMAGEID, $id);
            $criteria[] = new EqCriterion (ImageUseTable::COL_SCOPE, $scope);
            $criteria[] = new EqCriterion (ImageUseTable::COL_CONTEXTID, $contextId);
            $criteria[] = new EqCriterion (ImageUseTable::COL_ZONE, $zone);
            $affected = $imageUseTable->updateRecord ($criteria, $imageUseValues);
            if (1 != $affected)
                return false;

            $this->imageId = $id;
            $this->imageTitle = empty ($imageUseValues[ImageUseTable::COL_TITLE]) ? $values[ImagesTable::COL_LABEL] : $imageUseValues[ImageUseTable::COL_TITLE];
            }
        else if ("new" == $action)
            {
            $this->returnType = self::RETURN_HTML;
            $uploadField = $this->getUploadField ();
            $uploadError = $uploadField->getUploadError ($this->context, $request);
            $dateFrom = $dateTo = NULL;
            if (false !== $uploadError)
                {
                $this->addErrorPrepared ($uploadError);
                return false;
                }
            if (empty ($request["confirm"]))
                {
                $this->addError ("Upload status is unknown. You must be authorized to use the image in this project to continue. If you are the creator of the image or you have a written permission to use the image in this project, please select appropriate upload status.");
                return false;
                }

            if (ImageUseTable::ZONE_LOGO == $zone)
                {
                if (empty ($values[ImageUseTable::COL_DATEFROM]))
                    {
                    if (!empty ($values[ImageUseTable::COL_DATETO]))
                        $values[ImageUseTable::COL_DATEFROM] = $values[ImageUseTable::COL_DATETO];
                    else
                        $values[ImageUseTable::COL_DATEFROM] = date ("Y-00-00");
                    }

                $values[ImagesTable::COL_AUTHOR] = " ";
                $dateFrom = $values[ImageUseTable::COL_DATEFROM];
                $dateTo = $values[ImageUseTable::COL_DATETO];
                if (!empty ($dateTo))
                    $values[ImagesTable::COL_LABEL] = $this->getText ("Logo in [_0]-[_1]", substr ($dateFrom, 0, 4), substr ($dateTo, 0, 4));
                else
                    $values[ImagesTable::COL_LABEL] = $this->getText ("Logo in [_0]", substr ($dateFrom, 0, 4));
                    
                $values[ImagesTable::COL_LICENSE_ID] = ImageLicenseTable::getLicenseId ($this->context, ImageUseTable::ZONE_LOGO);
                if (empty ($values[ImagesTable::COL_LICENSE_ID]))
                    {
                    $this->addError ("Logo license is not setup in database.");
                    return false;
                    }
                }
            else if (ImageUseTable::ZONE_REPORT == $zone)
                {
                $values[ImagesTable::COL_AUTHOR] = " ";
                if (empty ($values[ImagesTable::COL_LABEL]))
                    $values[ImagesTable::COL_LABEL] = $this->getText ("Match report");
                $values[ImagesTable::COL_LICENSE_ID] = ImageLicenseTable::getLicenseId ($this->context, ImageUseTable::ZONE_REPORT);
                if (empty ($values[ImagesTable::COL_LICENSE_ID]))
                    {
                    $this->addError ("Report license is not setup in database.");
                    return false;
                    }
                }
            else
                {
                if (empty ($values[ImagesTable::COL_AUTHOR]))
                    {
                    $this->addError ("Author name or source is not given.");
                    return false;
                    }
                }

            unset ($values["confirm"]);
            unset ($values[ImageUseTable::COL_DATEFROM]);
            unset ($values[ImageUseTable::COL_DATETO]);
            
            $filePath = $uploadField->getFilePath ($request);
            $image = new Image ();
            if (!$image->readFile ($this->context, $filePath))
                {
                $this->addError ("Could not open scanned image.");
                return false;
                }

            $files = array ($filePath);
            $deleteFiles = false;

            if ($image->isMultiPage ())
                {
                $basePath = realpath (USER_UPLOAD_DIR)."/tiff/";
                if (!is_dir ($basePath) && !mkdir ($basePath))
                    {
                    $this->context->addError ("Failed to split the scanned image.");
                    return false;
                    }
                
                $files = $image->splitPages ($basePath, $values[ImagesTable::COL_FILENAME]);
                $deleteFiles = true;
                }

            $result = true;
            $initialLabel = $values[ImagesTable::COL_LABEL];
            foreach ($files as $page => $fileName)
                {
                if (0 !== $page)
                    $values[ImagesTable::COL_LABEL] = $this->getText ("[_0] (page [_1])", $initialLabel, $page);

                $values[ImagesTable::COL_FILEPATH] = $fileName;
                if ($deleteFiles)
                    $values[ImagesTable::COL_FILENAME] = pathinfo ($fileName, PATHINFO_BASENAME);
                $id = $this->dbtable->insertRecord ($values);
                if (false === $id)
                    {
                    $result = false;
                    break;
                    }

                $imageUseValues = array
                    (
                    ImageUseTable::COL_IMAGEID => $id,
                    ImageUseTable::COL_SCOPE => $scope,
                    ImageUseTable::COL_CONTEXTID => $contextId,
                    ImageUseTable::COL_ZONE => $zone,
                    ImageUseTable::COL_TITLE => $values[ImagesTable::COL_LABEL],
                    ImageUseTable::COL_DATEFROM => $dateFrom,
                    ImageUseTable::COL_DATETO => $dateTo,
                    );
                if (false === $imageUseTable->insertRecord ($imageUseValues))
                    {
                    $result = false;
                    break;
                    }

                $this->imageId = $id;
                }

            if ($deleteFiles)
                {
                foreach ($files as $page => $fileName)
                    unlink ($fileName);
                }
            if (!$result)
                return $result;

            $this->imageTitle = $values[ImagesTable::COL_LABEL];
            return true;
            }
        else if ("connect" == $action)
            {
            $this->returnType = self::RETURN_XML;

            $imageUseValues = array
                (
                ImageUseTable::COL_IMAGEID => $values[ImageUseTable::COL_IMAGEID],
                ImageUseTable::COL_SCOPE => $scope,
                ImageUseTable::COL_CONTEXTID => $contextId,
                ImageUseTable::COL_ZONE => $zone,
                );
            if (!empty ($values[ImageUseTable::COL_TITLE]))
                $imageUseValues[ImageUseTable::COL_TITLE] = $values[ImageUseTable::COL_TITLE];
            else
                {
                $row = $this->dbtable->selectSingleBy (array (ImagesTable::COL_LABEL), array (new EqCriterion (ImagesTable::COL_ID, $values[ImageUseTable::COL_IMAGEID])));
                if (!empty ($row))
                    $imageUseValues[ImageUseTable::COL_TITLE] = $row[ImagesTable::COL_LABEL];
                }

            if (false === $imageUseTable->insertRecord ($imageUseValues))
                return false;

            $this->imageId = $values[ImageUseTable::COL_IMAGEID];
            $this->imageTitle = $imageUseValues[ImageUseTable::COL_TITLE];
            }
        else
            return false;

        $ret[] = array ("src" => $this->getImageUrl (),
                        "url" => $this->getGaleryUrl (),
                        "label" => $this->getImageTitle ());

        return $ret;
        }

    protected function rotateImage ($request, $mode)
        {
        if (empty ($request["id"]))
            {
            $this->addError ("Invalid context given");
            return false;
            }

        $id = $request["id"];
        $criteria[] = new EqCriterion (ImagesTable::COL_ID, $id);
        $row = $this->dbtable->selectSingleBy (array (ImagesTable::COL_FILENAME, DBTable::COL_CREATEDON), $criteria);
        if (empty ($row))
            {
            $this->addError ("Invalid id given");
            return false;
            }

        $fileName = $row[ImagesTable::COL_FILENAME];
        $filePath = USER_UPLOAD_DIR."/".$fileName;

        try
            {
            set_time_limit  (90);
            $image = new Imagick ();
            if (true !== $image->readImage ($filePath) ||
                !$image->rotateImage(new ImagickPixel(), 180) ||
                !$image->writeImage ($filePath))
                {
                $context->addError ("Incorrect image was uploaded.");
                return false;
                }
            }
        catch(Exception $e)
            {
            $this->addError ($e->getMessage());
            return false;
            }

        $this->dbtable->clearImageCache ($fileName);

        $affected = $this->dbtable->updateRecord ($criteria, array ());
        if (1 != $affected)
            {
            $this->addError ("Error");
            return false;
            }

        return array (array ("sucess" => 1));
        }

    protected function removeImage ($request, $mode)
        {
        $imageUseTable = new ImageUseTable ($this->context);

        if (empty ($request["sc"]) || empty ($request["cid"]) || empty ($request["zone"]) || empty ($request["id"]))
            {
            $this->addError ("Invalid context given");
            return false;
            }
        $scope = $request["sc"];
        $contextId = $request["cid"];
        $zone = $request["zone"];
        $id = $request["id"];
        
        if (false === $imageUseTable->deleteRecord ($scope, $contextId, $zone, $id))
            return false;

        return array (array ("sucess" => 1));
        }

    protected function executeCustomAction ($request, $mode)
        {
        if ("remove" == $mode)
            return $this->removeImage ($request, $mode);
        if ("rotate" == $mode)
            return $this->rotateImage ($request, $mode);

        return parent::executeCustomAction ($request, $mode);
        }

    public function isDebugMode ()
        {
        return false;
        }
        
    protected function getSaveButtonText ()
        {
        return !empty ($this->existingRow) ? $this->getText ("Save") : $this->getText ("Create");
        }
    }

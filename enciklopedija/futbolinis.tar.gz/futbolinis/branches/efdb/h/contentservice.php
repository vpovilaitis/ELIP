<?php
require_once (PATH.'inc/webservice.php');

class ContentService extends WebService
    {
    public function __construct ($context)
        {
        parent::__construct ($context);
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getData ($request)
        {
        $tableId = isset ($request["id"]) ? $request["id"] : NULL;
        $filterBy = isset ($request["s"]) ? trim ($request["s"]) : NULL;
        $dbtable = ContentTable::createInstanceById ($this->context, $tableId);
        if (empty ($dbtable) || empty ($filterBy))
            {
            $this->context->addError ("Invalid arguments passed.");
            return NULL;
            }

        $list = $this->getPickList ($request, $dbtable, $filterBy);
        $result = array ();

        if (!empty ($list))
            {
            foreach ($list as $id => $label)
                {
                if (is_array ($label))
                    $result[] = array ("id" => $id, "label" => $label[0], "description" => $label[1]);
                else
                    $result[] = array ("id" => $id, "label" => $label);
                }
            }

        return $result;
        }

    public function getPickList ($request, $dbtable, $filterBy)
        {
        $params[] = new FilterCriterion ($filterBy);
        if (is_callable (array ($dbtable, "getExtentedPickList")))
            return $dbtable->getExtentedPickList (20, $filterBy);

        $list = $dbtable->getPickList (NULL, 20, NULL, $params);
        return $list;
        }
    }

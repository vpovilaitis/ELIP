<?php


define ("PATH", "../");
require_once (PATH."inc/pagecontext.php");
require_once (PATH."inc/general.php");
require_once (PATH."inc/usertables.php");
require_once (PATH."inc/contenttable.php");

if (empty ($_GET["start"]) || empty ($_GET["end"]))
    {
    echo
<<<EOT
<html>
 <body>
    use:
    <ul>
        <ol>h/generate.php?start=1999&end=2001
        <ol>(optionally) &mode=autumn-spring
    </ul>
EOT;
    exit();
    }
$start = $_GET["start"];
$end = $_GET["end"];
$mode = isset ($_GET["mode"]) ? "autumn-spring" == $_GET["mode"] : false;

$context = PageContext::getInstance ($_REQUEST);
$dbtable = ContentTable::createInstanceByName ($context, "seasons");
$colName = ContentTable::prepareUserColumnName ("displayname");
$colStart = ContentTable::prepareUserColumnName ("start");
$colEnd = ContentTable::prepareUserColumnName ("end");

?>
<html>
 <body>
<?php
$count = 0;
for ($year = $start; $year <= $end; $year++)
    {
    if (!is_numeric ($year))
        exit();

    $yearEnd = $year;
    if ($mode)
        $yearEnd++;

    $dbtable->setLanguage ("lt");
    $values = array ($colStart => "$year-00-00", $colEnd => "$yearEnd-00-00");
    $id = $dbtable->insertRecord ($values);
    if (false === $id)
        {
        echo "<h2>Error creating</h2>";
        break;
        }

    $count++;
    $idCriteria = array (new EqCriterion ($dbtable->getIdColumn (), $id));

    $dbtable->setLanguage ("en");
    $label = ($yearEnd == $year) ? "$year" : "$year/".substr ($yearEnd, -2);
    $values = array ($colName => $label);
    if (false === $dbtable->updateRecord ($idCriteria, $values))
        {
        echo "<h2>Error creating en</h2>";
        break;
        }

    }

echo $count;
?>
records created
 </body>
</html>

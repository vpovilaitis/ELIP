<?php
require_once (PATH.'inc/webservice.php');

class HintService extends WebService
    {
    public function __construct ($context)
        {
        parent::__construct ($context);
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getData ($request)
        {
        $scope = isset ($request["sc"]) ? $request["sc"] : NULL;
        $contextMode = isset ($request["cmode"]) ? $request["cmode"] : NULL;
        $targetGroup = isset ($request["grp"]) ? $request["grp"] : NULL;
        $contextId = isset ($request["id"]) ? $request["id"] : NULL;

        $hintProvider = ComponentFactory::getHintsService ($this->context);
        $hint = $hintProvider->getHint ($scope, $contextMode, $targetGroup, $contextId);
        
        $result = array ();
        if (!empty ($hint))
            {
            $entry = $hint;
            $entry["img"] = $this->context->getTinyIconPath ("hints");
            }
        else
            $entry = array ();

        $entry["listUrl"] = NULL;
        $result[] = $entry;        return $result;
        }
    }

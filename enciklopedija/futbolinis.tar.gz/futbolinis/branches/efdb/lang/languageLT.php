<?php
require_once (PATH.'inc/language.php');

class LanguageLT extends Language
    {

    public function __construct ($context)
        {
        parent::__construct ($context);
        }

    public function dateToAnyString ($date, $modifier, $long)
        {
        if (empty ($date))
            return "";

        $parts = explode (" ", $date);
        $time = "";
        if (2 == count ($parts))
            {
            $date = $parts[0];
            $time = preg_split ("/[:.]/", $parts[1]);
            while (count ($time) > 2)
                array_pop ($time);
            if ($time[0] > 0 || $time[1] > 0)
                $time = sprintf (" %d.%02d", $time[0], $time[1]);
            else
                $time = "";
            }

        list ($year, $month, $day) = sscanf ($date, "%d-%d-%d");

        if (empty ($year))
            return "";

        $str = $year;
        if ($long)
            $str .= " m.";

        if ("year" == $modifier)
            return $str;

        $end = "";
        if (isset ($month) && $month > 0)
            {
            if (!$long && $month < 10)
                $month = "0$month";
            if ($long)
                {
                $monthNames = array ("sausio", "vasario", "kovo",
                                     "balandžio", "gegužės", "birželio",
                                     "liepos", "rugpjūčio", "rugsėjo",
                                     "spalio", "lapkričio", "gruodžio");
                $str .= " {$monthNames[$month-1]}";
                }
            else
                $str .= "-".$month;
            }

        if ("month" == $modifier)
            {
            $day = 0;
            $time = "";
            }

        if (isset ($day) && $day > 0)
            {
            if (!$long && $day < 10)
                $day = "0$day";
            if ($long)
                $str .= " {$day} d.";
            else
                $str .= "-{$day}";
            }
        else if ($long && isset ($month) && $month > 0)
            $str .= " mėn.";

        if ("day" == $modifier)
            return $str;

        if (!empty ($time) && $long)
            $time .= " val.";

        return $str.$time;
        }

    public function dateToLongString ($date, $modifier = NULL)
        {
        return $this->dateToAnyString ($date, $modifier, true);
        }

    public function dateToString ($date, $modifier = NULL)
        {
        return $this->dateToAnyString ($date, $modifier, "long" == $modifier);
        }

    public function changeWordCase ($sentence, $case)
        {
        $piecesOn = explode (" prie ", $sentence); // two or more equivalent parts
        if (count ($piecesOn) > 1)
            {
            $piecesOn[0] = $this->changeCase ($piecesOn[0], $case);
            return implode (" prie ", $piecesOn);
            }
            
        $pieces = explode ("-", $sentence); // two or more equivalent parts
        if (count ($pieces) > 1)
            {
            for ($i = 0; $i < count ($pieces); $i++)
                {
                $pieces[$i] = $this->changeWordCase ($pieces[$i], $case);
                }

            return implode ("-", $pieces);
            }

        $pieces = explode (" ir ", $sentence); // two or more equivalent parts

        for ($i = 0; $i < count ($pieces); $i++)
            {
            $pieces[$i] = $this->changeCase ($pieces[$i], $case);
            }
        return implode (" ir ", $pieces);
        }

    public function changeCase ($sentence, $case)
        {
        if (preg_match ("/^(.+ „)(.+)([“])$/uU", $sentence, $match) > 0)
            {
            return $match[1].$this->changeCase ($match[2], $case).$match[3];
            }

        switch ($case)
            {
            case Language::CASE_GENITIVE:
                return $this->getGenitive ($sentence);
            case Language::CASE_LOCATIVE:
                return $this->getLocative ($sentence);
            case Language::CASE_ACCUSATIVE:
                return $this->getAccusative ($sentence);
            default:
                return $word;
            }
        }

    protected function replaceEndings ($word, $endings)
        {
        foreach ($endings as $searchFor => $replaceWith)
            {
            $ending = substr ($word, -strlen ($searchFor));
            if (0 === strcmp ($ending, $searchFor))
                return substr ($word, 0, -strlen ($searchFor)).$replaceWith;
            }
        return $word;
        }

    public function getGenitiveForNoun ($word)
        {
        return $this->replaceEndings ($word, array
            (
            "Kaišiadorys" => "Kaišiadorių", // exception
            "Neris" => "Neries", // exception
            "Taitis" => "Taičio", // exception
            "Grandis" => "Grandies", // exception

            "ainys" => "ainių", // for example, "Smurgainys" -> "Smurgainių"
            "ainis" => "ainio", // for example, "Svarainis" -> "Svarainio"
            "aitis" => "aičio", // for example, "Žemaitis" -> "Žemaičio"
            "alnis" => "alnio", // for example, "Žaliakalnis" -> "Žaliakalnio"
            "kštis" => "kšties", // for example, "Kibirkštis" => "Kibirkšties"
            "lnis" => "lnies", // for example, "Vilnis" -> "Vilnies"
            "ltis" => "lties", // for example, "Viltis" -> "Vilties"
            "lžis" => "lžies", // for example, "Tulžis" -> "Tulžies"
            "itis" => "ities", // for example, "sritis" -> "srities"
            "inys" => "inio", // for example, "Šulinys" -> "Šulinio"
            "onys" => "onių", // for example, "Švenčionys" -> "Švenčionių"
            "anys" => "anio", // for example, "Banys" -> "Banio"
            "ytis" => "yčio", // for example, "Alytis" -> "Alyčio"
            "tis" => "čio", // for example, "Trivartis" -> "Trivarčio", "Ploješties" -> "Ploješčio"
            "tės" => "čių", // for example, "Žalgirietės" -> "Žalgiriečių"
            "dis" => "džio", // for example, "Balandis" -> "Balandžio" (wrong with "Grandis" -> "Grandies")
            "dys" => "džio", // for example, "Gaidys" -> "Gaidžio"
            "jis" => "jo", // for example, "Pakruojis" -> "Pakruojo"
            "jas" => "jo", // for example, "Vėjas" -> "Vėjo"
            "jys" => "jo", // for example, "Žvejys" -> "Žvejo"
            "nys" => "nų", // for example, "Akmenys" -> "Akmenų"
            "oni" => "onų", // for example, "Raudoni" -> "Raudonų"
            "is" => "io", // for example, "Viltis" -> "Vilties"
            "oa" => "oa", // international names (no declination)
            "ua" => "ua", // international names (no declination)
            "uo" => "ens", // for example, "Šelmuo" -> "Šelmens"
            "as" => "o", // for example, "Kaunas" -> "Kauno"
            "us" => "aus", // for example, "Vilnius" -> "Vilniaus"
            "ai" => "ų", // for example, "Trakai" -> "Trakų", "Šiauliai" -> "Šiaulių"
            "os" => "ų", // for example, "Malkos" -> "Malkų"
            "ys" => "io", // for example, "Pasvalys" -> "Pasvalio"
            "ės" => "ių", // for example, "Rūdiškės" -> "Rūdiškių"
            "a" => "os", // for example, "Palanga" -> "Palangos"
            "ė" => "ės", // for example, "Kernavė" -> "Kernavės"
            ));
        }

    public function getGenitiveForAdjective ($word)
        {
        return $this->replaceEndings ($word, array
            (
            "Vieni" => "Vienų", // exception
            "dieji" => "džiųjų", // for example, "Gardieji" -> "Gardžiųjų"
            "lieji" => "liųjų", // for example, "Dailieji" -> "Dailiųjų"
            "sieji" => "siųjų", // for example, "Baisieji" -> "Baisiųjų"
            "ieji" => "ųjų", // for example, "Naujieji" -> "Naujųjų", "Baltieji" -> "Baltųjų"
            "asis" => "ojo", // for example, "Žaliasis" -> "Žaliojo"
            "inis" => "inio", // for example, "Geležinis" -> "Geležinio"
            "oji" => "osios", // for example, "Penktoji" -> "Penktosios"
            "eji" => "ejų", // for example, "Dveji" -> "Dvejų"
            "inė" => "inės", // for example, "Pirminė" -> "Pirminės"
            "as" => "o", // for example, "Pirmas" -> "Pirmo"
            ));
        }

    public function getGenitive ($sentence)
        {
        $words = explode (" ", $sentence);

        // only adjectives matters until last word
        for ($i = 0; $i < count ($words) - 1; $i++)
            {
            $words[$i] = $this->getGenitiveForAdjective ($words[$i]);
            }

        // decline last word (expect it to be noun)
        $words[$i] = $this->getGenitiveForNoun ($words[$i]);
        return implode (" ", $words);
        }

    public function getLocativeForNoun ($word)
        {
        return $this->replaceEndings ($word, array
            (
            "Kaišiadorys" => "Kaišiadoryse", // exception
            "Neris" => "Neryje", // exception

            // "ainis" => "ainio", // for example, "Svarainis" -> "Svarainio"
            // "lnis" => "lnies", // for example, "Vilnis" -> "Vilnies"
            // "ltis" => "lties", // for example, "Viltis" -> "Vilties"
            // "lžis" => "lžies", // for example, "Tulžis" -> "Tulžies"
            "is" => "yje", // for example, "Naerobis" -> "Naerobyje"
            "oa" => "oa", // international names (no declination)
            "ua" => "ua", // international names (no declination)
            "as" => "e", // for example, "Kaunas" -> "Kaune"
            "us" => "uje", // for example, "Vilnius" -> "Vilniuje"
            "ai" => "uose", // for example, "Trakai" -> "Trakuose"
            "ys" => "yje", // for example, "Pasvalys" -> "Pasvalyje"
            "ės" => "ėse", // for example, "Rūdiškės" -> "Rūdiškėse"
            "os" => "ose", // for example, "Malkos" -> "Malkose"
            "a" => "oje", // for example, "Palanga" -> "Palangoje"
            "ė" => "ėje", // for example, "Kernavė" -> "Kernavėje"
            ));
        }

    public function getLocativeForAdjective ($word)
        {
        return $this->replaceEndings ($word, array
            (
            "jieji" => "juosiuose", // for example, "Naujieji" -> "Naujųjų"
            "ieji" => "uosiuose", // for example, "Baltieji" -> "Baltuosiuose"
            "asis" => "ajame", // for example, "Žaliasis" -> "Žaliajame"
            "inis" => "iniame", // for example, "Geležinis" -> "Geležiniame"
            "oji" => "ojoje", // for example, "Penktoji" -> "Penktojoje"
            "inė" => "inėje", // for example, "Pirminė" -> "Pirminėje"
            "as" => "ame", // for example, "Pirmas" -> "Pirmame"
            ));
        }

    public function getLocative ($sentence)
        {
        $words = explode (" ", $sentence);

        // only adjectives matters until last word
        for ($i = 0; $i < count ($words) - 1; $i++)
            {
            $words[$i] = $this->getLocativeForAdjective ($words[$i]);
            }

        // decline last word (expect it to be noun)
        $words[$i] = $this->getLocativeForNoun ($words[$i]);
        return implode (" ", $words);
        }

    public function getAccusativeForNoun ($word)
        {
        return $this->replaceEndings ($word, array
            (
            "tės" => "tes", // for example, "Žalgirietės" -> "Žalgiriečių"
            "jas" => "ją", // for example, "Vėjas" -> "Vėją"
            "jys" => "jį", // for example, "Žvejys" -> "Žvejį"
            "nys" => "nius", // for example, "Žvejys" -> "Žvejus"
            "oni" => "onus", // for example, "Raudoni" -> "Raudonus"
            "is" => "į", // for example, "Viltis" -> "Viltį"
            "oa" => "oa", // international names (no declination)
            "ua" => "ua", // international names (no declination)
            "uo" => "enį", // for example, "Šelmuo" -> "Šelmenį"
            "as" => "ą", // for example, "Kaunas" -> "Kauną"
            "us" => "ų", // for example, "Vilnius" -> "Vilnių"
            "ai" => "us", // for example, "Trakai" -> "Trakus", "Šiauliai" -> "Šiaulius"
            "os" => "as", // for example, "Malkos" -> "Malkas"
            "ys" => "į", // for example, "Pasvalys" -> "Pasvalį"
            "ės" => "es", // for example, "Rūdiškės" -> "Rūdiškes"
            "a" => "ą", // for example, "Palanga" -> "Palangą"
            "ė" => "ę", // for example, "Kernavė" -> "Kernavę"
            ));
        }

    public function getAccusative ($sentence)
        {
        $words = explode (" ", $sentence);

        // only adjectives matters until last word
        for ($i = 0; $i < count ($words) - 1; $i++)
            {
            $words[$i] = /*$this->getGenitiveForAdjective*/ ($words[$i]);
            }

        // decline last word (expect it to be noun)
        $words[$i] = $this->getAccusativeForNoun ($words[$i]);
        return implode (" ", $words);
        }

    public function calculateYearDecade ($year)
        {
        return parent::calculateYearDecade ($year - 1);
        }

    public function getDecadeLabel ($decade)
        {
        $y = $decade % 100;
        $century = ($decade - $y) / 100 + 1;
        $y /= 10;
        $y++;
        return "$century a. $y dešimtmetis";
        }

    public function extractTimeFromDate ($date)
        {
        list ($year, $month, $day, $hour, $minute) = sscanf ($date, "%d-%d-%d %d:%d");
        if (0 == $hour && 0 == $minute)
            return false;

        return sprintf ("%02d.%02d", $hour,$minute);
        }

    protected function getRelativeDayLabel ($relativeDayFromToday)
        {
        switch ($relativeDayFromToday)
            {
            case 2:
                return "poryt";
            case 1:
                return "rytoj";
            case 0:
                return "šiandien";
            case -1:
                return "vakar";
            case -2:
                return "užvakar";
            }

        return NULL;
        }

    public function getRelativeDayName ($relativeDays, $now)
        {
        $givenDay = strtotime (date ("Y-m-d 00:00:00", $now + 24*60*60 * $relativeDays));
        $today = strtotime (date ("Y-m-d 00:00:00"));
        $str = $this->getRelativeDayLabel (($givenDay - $today) / (24*60*60));

        if (empty ($str))
            $str = $this->dateToLongString (date ("Y-m-d 00:00:00", $now + 24*60*60 * $relativeDays));
        return $str;
        }

    public function decimalToString ($dec, $decimalPlaces)
        {
        return str_replace (".", ",", sprintf ("%.{$decimalPlaces}f", $dec));
        }
        

    // Sports specialization - to be moved to some separate file 
    public function beautifyTeamLabel ($label)
        {
        preg_match ('/„(.{2,50})“.*/uU', $label, $m);
        if (!empty ($m))
            return $m[1];

        preg_match ('/^(.*) (jaunių |)merginų iki ([0-9]+) m\. rinktinė/uU', $label, $m);
        if (!empty ($m))
            return "{$m[1]} merginų U-{$m[3]}";

        preg_match ('/^(.*) (jaunimo|jaunių) iki ([0-9]+) m\. rinktinė/uU', $label, $m);
        if (!empty ($m))
            return "{$m[1]} U-{$m[3]}";

        if (preg_match ('/^(.+) ([A-Z]{3,7})$/uU', $label, $m) > 0)
            return "{$m[2]}";

        $label = str_replace (" vyrų ", " ", $label);
        $label = str_replace (" rinktinė", " r.", $label);
        return $label;
        }
    public function getTeamLabel ($row)
        {
        $postfix = empty ($row[TeamNamesTable::COL_POSTFIX]) ? "" : "-".$row[TeamNamesTable::COL_POSTFIX];
        $parts = array ();
        if (!empty ($row[TeamNamesTable::COL_CITY]))
            $parts[] = $this->getGenitive ($row[TeamNamesTable::COL_CITY]);

        if (!empty ($row[TeamNamesTable::COL_PREFIX]) && (empty ($row[TeamNamesTable::COL_NAME]) || !empty ($row[TeamNamesTable::COL_SHOWPREFIX])))
            $parts[] = $row[TeamNamesTable::COL_PREFIX].(empty ($row[TeamNamesTable::COL_NAME]) ? $postfix : "");

        if (!empty ($row[TeamNamesTable::COL_NAME]))
            {
            $name = $row[TeamNamesTable::COL_NAME].$postfix;
            //if (!empty ($row[TeamNamesTable::COL_DECLINE]))
            $parts[] = "„".$name."“";
            }

        return implode (" ", $parts);
        }
  
    public function makePlural ($word)
        {
        $word = trim ($word);
        if (empty ($word))
            return NULL;

        return $this->replaceEndings ($word, array
            (
            "gus" => "nės",
            "ius" => "iai",
            "as" => "ai",
            "is" => "iai",
            "a" => "os",
            ));
        }
    }

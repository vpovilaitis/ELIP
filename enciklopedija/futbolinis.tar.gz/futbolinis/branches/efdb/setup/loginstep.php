<?php
include PATH.'setup/common.php';

define ('PARAM_USER', 'usr');
define ('PARAM_PASS', 'pwd');
define ('PARAM_PERSIST', 'persist');

class LoginStep extends DeploymentStep
    {
    public $user;
    public $pass;
    public $persist;

    public function __construct ($context)
        {
        parent::__construct ($context, _("Administrator login"), Constants::CONFIGSTATE_NEEDSLOGIN);
        }

    public function processInput ($context, &$request)
        {
        $this->user = isset($request[PARAM_USER]) ? $request[PARAM_USER] : "";
        $this->pass = isset($request[PARAM_PASS]) ? $request[PARAM_PASS] : "";
        $this->persist = isset($request[PARAM_PERSIST]) ? $request[PARAM_PERSIST] : 0;

        if (isset($request[PARAM_USER]))
            {
            if (0 == strlen ($this->user))
                {
                $this->addError ("Please provide a valid user name.");
                }
            else if (!$context->login ($this->user, $this->pass, $this->persist))
                {
                $this->addError ("User name and password do not match.");
                }
            else
                {
                $this->stepComplete ("");
                exit;
                }
            }

        return true;
        }

    }

?>

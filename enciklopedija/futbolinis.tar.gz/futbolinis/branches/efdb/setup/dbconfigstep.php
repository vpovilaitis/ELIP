<?php
include PATH.'setup/common.php';

define ('PARAM_HOST', 'host');
define ('PARAM_PORT', 'port');
define ('PARAM_SOCKET', 'sock');
define ('PARAM_DB', 'db');
define ('PARAM_USER', 'user');
define ('PARAM_PASS', 'pass');
define ('PARAM_PREF', 'pref');

class DBConfigStep extends DeploymentStep
    {
    public $host;
    public $port;
    public $socket;
    public $dbname;
    public $user;
    public $pass;
    public $pref;

    public function __construct ($context)
        {
        parent::__construct ($context, _("Database Configuration"), Constants::CONFIGSTATE_NODB);
        }

    public function processInput ($context, &$request)
        {
        $this->host = isset ($request[PARAM_HOST]) ? $request[PARAM_HOST] : "localhost";
        $this->port = isset ($request[PARAM_PORT]) ? $request[PARAM_PORT] : "";
        $this->socket = isset ($request[PARAM_SOCKET]) ? $request[PARAM_SOCKET] : "";
        $this->dbname = isset ($request[PARAM_DB]) ? $request[PARAM_DB] : "";
        $this->user = isset ($request[PARAM_USER]) ? $request[PARAM_USER] : "";
        $this->pass = isset ($request[PARAM_PASS]) ? $request[PARAM_PASS] : "";
        $this->pref = isset ($request[PARAM_PREF]) ? $request[PARAM_PREF] : "";

        if (!isset ($request[PARAM_HOST]))
            return true;

        if (0 == strlen ($this->host) && 0 == strlen ($this->socket))
            $this->addError ("Please enter a valid host name or a socket name.");
        if (0 == strlen ($this->dbname))
            $this->addError ("Please enter a value for a field \"Database name\".");
        if (0 == strlen ($this->user))
            $this->addError ("Please enter a value for a field \"Database user name\".");
        
        if ($this->containsMessages ())
            return true;

        define("DB_HOST", $this->host);
        define("DB_PORT", $this->port);
        define("DB_SOCKET", $this->socket);
        define("DB_NAME", $this->dbname);
        define("DB_USER", $this->user);
        define("DB_PASS", $this->pass);

        // try connecting to the database
        if (!$context->getConnection ())
            {
            $this->addError ("Failed to connect to the database");
            return true;
            }

        $content = <<<EOT
<?php
// Database server host and optionally port and socket
define("DB_HOST", "{$this->host}");
define("DB_PORT", "{$this->port}");
define("DB_SOCKET", "{$this->socket}");
// Database name
define("DB_NAME", "{$this->dbname}");
define("DB_USER", "{$this->user}");
define("DB_PASS", "{$this->pass}");
// Prefix for database tables
define("DB_PREF", "{$this->pref}");
?>
EOT;

        // save options to the "conf/dbconfig.php"
        $filename = PATH."conf/dbconfig.php";
        $handle = fopen ($filename, "x");
        if (FALSE == $handle || !fwrite ($handle, $content))
            {
            $this->addError ("Cant create the file \"[_0]\". Please ensure web server user has permisions to create the file or create the file manually with the following content:<br/><pre>[_1]</pre>", $filename, $content);
            return true;
            }

        fclose ($handle);

        // redirect to index.php
        $this->stepComplete (Constants::PARAM_LANGUAGE.'='.$this->context->getLanguage());
        exit ();
        }

    protected function getDisplayParams ($request)
        {
        return array_merge (parent::getDisplayParams ($request), array ('PARAM_LANGUAGE' => $this->context->getLanguage()) );
        }
    }

?>
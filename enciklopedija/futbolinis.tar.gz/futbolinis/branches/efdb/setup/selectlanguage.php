<?php
include PATH.'setup/common.php';

define ('PARAM_SELECTED_LNG', 'newlng');

class SelectLanguage extends DeploymentStep
    {
    public $lng;

    public function __construct ($context)
        {
        parent::__construct ($context, _("Select Default Language"), Constants::CONFIGSTATE_NOLANGUAGE);
        }

    public function processInput ($context, &$request)
        {
        if (!isset ($request[PARAM_SELECTED_LNG]))
            {
            $this->lng = "";
            return true;
            }

        $this->lng = $request[PARAM_SELECTED_LNG];
        $content = <<<EOT
<?php

define("DEFAULT_LANGUAGE", "{$this->lng}");

// define("DEBUG", true);
// define("DEBUG_VERBOSE", true);

// define("SITE_SKIN", "default");

?>
EOT;
        // save options to the "conf/user.config.php"
        $filename = PATH."conf/user.config.php";
        $handle = fopen ($filename, "x");
        if (FALSE == $handle || !fwrite ($handle, $content))
            {
            $this->addError ("Cant create the file \"[_0]\". Please ensure web server user has permisions to create the file or create the file manually with the following content:<br/><pre>[_1]</pre>", $filename, $content);
            return true;
            }
    
        fclose ($handle);

        // redirect to next step
        $this->stepComplete ("");
        exit ();
        }

    protected function getDisplayParams ($request)
        {
        $lngArray = $GLOBALS["Languages"];
        $languages = array ();
        foreach ($lngArray as $lng)
            {
            $languages[$lng->code] = $lng->label;
            }

        asort ($languages);
        return array_merge (parent::getDisplayParams ($request), array ("languages" => $languages));
        }
    }

?>

<?php
require_once (PATH.'conf/config.php');
require_once (PATH.'inc/general.php');
require_once (PATH.'inc/page.php');

abstract class DeploymentStep extends Page
    {
    protected $expectedStatus;

    public function __construct ($context, $title, $expectedStatus)
        {
        parent::__construct ($context, $title);
        
        $this->expectedStatus = $expectedStatus;
        $context->addStyleSheet ("setup");
        }

    protected function checkAccess ($request)
        {
        return ($this->expectedStatus == configurationStatus ($this->context));
        }

    protected function getPageTemplateDir ()
        {
        return "setup";
        }

    protected function getTemplateName ()
        {
        return strtolower (get_class ($this));
        }

    public function getStepTitle ()
        {
        $name = get_class ($this);

        $pages = getConfigurationPageArray ();
        $totalStepCount = count ($pages);
        $i = 1;
        foreach ($pages as $pageStatus => $pageName)
            {
            if ($pageName == $name)
                break;
            $i++;
            }

        return $this->ngettext ("[_2] ([_1] of [_0] step)", "[_2] ([_1] of [_0] steps)", $totalStepCount, $i, $this->context->title);
        }

    protected function stepComplete ($params)
        {
        $redirectTo = PATH."admin.php?$params";

        if (!DEBUG) // in debug mode user might want to view the log
            header ("Location: $redirectTo");
        else
            echo "<HTML>
    <BODY>
    DEBUG mode on, so automatic redirect is disabled<br/>
    <a href=\"$redirectTo\">click here to proceed to the next step</a><br/><br/>
    </BODY>
    </HTML>";
        exit;
        }

    public function ensureTitle ($context, &$request)
        {
        if ($this->initialTitle)
            $context->title = $this->initialTitle;
        return true;
        }

    }

?>

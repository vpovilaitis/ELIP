<?php
include PATH.'setup/common.php';

define ('PARAM_USER', 'user');
define ('PARAM_PASS', 'pass');
define ('PARAM_PASS_CONFIRM', 'pass2');

class CreateAdminStep extends DeploymentStep
    {
    public $user;
    public $pass;
    public $pass2;

    public function __construct ($context)
        {
        parent::__construct ($context, _("Administrator Login Configuration"), Constants::CONFIGSTATE_NOUSER);
        }

    public function processInput ($context, &$request)
        {
        $this->user = isset($request[PARAM_USER]) ? $request[PARAM_USER] : "admin";
        $this->pass = isset($request[PARAM_PASS]) ? $request[PARAM_PASS] : "";
        $this->pass2 = isset($request[PARAM_PASS_CONFIRM]) ? $request[PARAM_PASS_CONFIRM] : "";

        if (!isset ($request[PARAM_USER]))
            return true;

        if (0 == strlen ($this->user))
            $this->addError ("Please enter a value for the \"Administrator user\" field.");
        if (0 == strlen ($this->pass))
            $this->addError ("Please enter a value for the \"Password\" field.");
        
        if ($this->containsMessages ())
            return true;
    
        if ($this->pass != $this->pass2)
            {
            $this->addError ("Passwords entered do not match.");
            return true;
            }

        $dbconn = $context->getConnection ();
        if (!$dbconn->startTransaction ())
            {
            $this->addError ("Unspecified database error.");
            return true;
            }
    
        $tables = array ("GroupsTable", "GroupMembersTable", "GroupAccessTable", "UsersTable", "UserLoginsTable");
    
        for ($i = 0; $i < count ($tables); $i++)
            {
            $context->log ("creating `$tables[$i]`");
            $table = $tables[$i];
            $instance = new $table ($context);
            if ($dbconn->tableExists ($instance->getTableName ()))
                continue;
    
            if (!$instance->createTable ())
                {
                $dbconn->rollbackTransaction ();
                $this->addError ("Error creating database table for users.");
                return true;
                }
            }
    
        $groupsTable = new GroupsTable ($context);
        $groupsTable->skipAccessChecks = true;
        $adminGroupId = $groupsTable->create ("admin", $this->getText ('Administrators'), $this->getText ('Administrator users'));
        if ($adminGroupId <= 0)
            {
            $dbconn->rollbackTransaction ();
            $this->addError ("Error creating an administrators group.");
            return true;
            }
    
        $guestsGroupId = $groupsTable->create ("*", $this->getText ('Guests'), $this->getText ("All non authenticated site visitors"));
        if ($guestsGroupId <= 0)
            {
            $dbconn->rollbackTransaction ();
            $this->addError ("Error creating a site visitors group.");
            return true;
            }
    
        $groupAccessTable = new GroupAccessTable ($context);
        $groupAccessTable->skipAccessChecks = true;
        if (!$groupAccessTable->set ($adminGroupId, Constants::ANY, Constants::ANY, true, true, true, true) ||
            !$groupAccessTable->set ($guestsGroupId, Constants::TABLES_USER, Constants::ANY, true, false, false, false) ||
            !$groupAccessTable->set ($guestsGroupId, Constants::TABLES_META, Constants::ANY, true, false, false, false)
            )
            {
            $dbconn->rollbackTransaction ();
            $this->addError ("Error granting an access to the administrator user.");
            return true;
            }
    
        $usersTable = new UsersTable ($context);
        $usersTable->skipAccessChecks = true;
        $adminUserId = $usersTable->create ($this->user, NULL, NULL, $this->pass);
        if ($adminUserId <= 0)
            {
            $dbconn->rollbackTransaction ();
            $this->addError ("Error creating an administrator user.");
            return true;
            }
    
        $groupMembersTable = new GroupMembersTable ($context);
        $groupMembersTable->skipAccessChecks = true;
        if (!$groupMembersTable->add ($adminGroupId, $adminUserId) ||
            !$groupMembersTable->add ($guestsGroupId, Constants::GUEST))
            {
            $dbconn->rollbackTransaction ();
            $this->addError ("Error granting an access to the administrator user.");
            return true;
            }
    
        $dbconn->commitTransaction ();
    
        if (!$context->login ($this->user, $this->pass))
            {
            $this->addError ("User name and password do not match.");
            return true;
            }
    
        // redirect to index.php
        $this->stepComplete (PARAM_USER.'='.$this->user);
        exit ();
        }

    }

?>
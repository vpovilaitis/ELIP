<?php
include_once PATH.'setup/common.php';

class SiteSettingsPage extends DeploymentStep
    {
    public function __construct ($context)
        {
        parent::__construct ($context, _("Site Settings"), Constants::CONFIGSTATE_NOSITESETTINGS);
        }

    public function getTemplateFields ($request)
        {
        $template = array
            (
            new TextFieldTemplate ("s", SiteSettings::SITE_TITLE,
                                   $this->getText ("Site label:"),
                                   $this->getText ("Short name of the site (1-2 words) - will be used as part of page title."),
                                   48),

            new TextFieldTemplate ("s", SiteSettings::SITE_DESCRIPTION,
                                   $this->getText ("Site description:"),
                                   $this->getText ("Longer description of the site - will be used as default value for meta description tag."),
                                   48),

            new TextFieldTemplate ("s", SiteSettings::SITE_AUTHOR,
                                   $this->getText ("Author:"),
                                   $this->getText ("Optional author name."),
                                   48),

            new TextFieldTemplate ("s", SiteSettings::SITE_AUTHOR_EMAIL,
                                   $this->getText ("Author e-mail:"),
                                   $this->getText ("Optional author e-mail address - to use in meta tags."),
                                   48),

            new TextFieldTemplate ("s", SiteSettings::SITE_FOOTER,
                                   $this->getText ("Page footer:"),
                                   $this->getText ("Optional footer text to display at every page."),
                                   48),

            new TextFieldTemplate ("s", SiteSettings::SITE_KEYWORDS,
                                   $this->getText ("Keywords:"),
                                   $this->getText ("Some keywords describing a site - will be used in meta tags."),
                                   48),
            );
        if (!empty ($template))
            {
            foreach ($template as $field)
                {
                $field->setPrefix ($this->getPrefix ());
                }
            }
        return $template;
        }

    public function processInput ($context, &$request)
        {
        if (!isset ($request["ok"]))
            return true;

        $templateFields = $this->getTemplateFields ($request);
        $values = array();

        foreach ($templateFields as $template)
            {
            $val = $template->getValueForDB ($context, $request);
            $values[$template->key] = $val;
            }

        if (empty ($values[SiteSettings::SITE_TITLE]))
            $this->addError ("Please enter a valid site name.");
        if (empty ($values[SiteSettings::SITE_DESCRIPTION]))
            $this->addError ("Please enter a site description.");

        if ($this->containsMessages ())
            return true;

        $dbconn = $context->getConnection ();
        if (!$dbconn->startTransaction ())
            {
            $this->addError ("Unspecified database error.");
            return true;
            }

        $handler = new SiteSettings ($context);
        if (!$handler->tableExists () && false === $handler->createTable ())
            {
            $dbconn->rollbackTransaction ();
            $this->addError ("Could not create a site settings table.");
            return true;
            }

        $nonTranslatable = array (SiteSettings::SITE_AUTHOR, SiteSettings::SITE_AUTHOR_EMAIL);
        foreach ($values as $name => $val)
            {
            if (empty ($val))
                continue;

            $translatable = (false === array_search ($name, $nonTranslatable));

            if (false === $handler->set ($name, $translatable, $val))
                {
                $dbconn->rollbackTransaction ();
                $this->addError ("Could not write a settings to the database.");
                return true;
                }
            }

        $handler->set (SiteSettings::SITE_WELCOME, true, $this->getText ("Welcome aboard"));
        $dbconn->commitTransaction ();

        // redirect to the next step
        $this->stepComplete ("");
        exit ();
        }

    public function getInstance ()
        {
        return $this->getRequest ();
        }

	}

?>
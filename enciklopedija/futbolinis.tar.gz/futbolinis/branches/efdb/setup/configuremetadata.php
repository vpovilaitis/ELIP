<?php
include PATH.'setup/common.php';

define ('PARAM_TYPE', 'type');

class ConfigureMetaData extends DeploymentStep
    {
    public $type;

    public function __construct ($context)
        {
        parent::__construct ($context, _("Configure data model"), Constants::CONFIGSTATE_NOMETADATA);
        }

    public function processInput ($context, &$request)
        {
        $this->type = isset($request[PARAM_TYPE]) ? $request[PARAM_TYPE] : "";

        if (!isset ($request[PARAM_TYPE]))
            return true;

        $dbconn = $context->getConnection ();
        if (!$dbconn->startTransaction ())
            {
            $this->addError ("Unspecified database error.");
            return true;
            }
    
        $tables = MetaDataTables::getMetaClassNames ($context);
    
        for ($i = 0; $i < count ($tables); $i++)
            {
            $context->log ("creating `$tables[$i]`");
            $table = $tables[$i];
            $instance = new $table ($context);
            if ($dbconn->tableExists ($instance->getTableName ()))
                continue;
    
            if (!$instance->createTable ())
                {
                $dbconn->rollbackTransaction ();
                $this->addError ("Error creating database table for meta data.");
                return true;
                }
            }

        if (!empty ($request[PARAM_TYPE]))
            {
            $basePath = $request[PARAM_TYPE];
            $files = scandir ($basePath);
            
            if (FALSE !== $files)
                {
                foreach ($files as $file)
                    {
                    $path = $basePath."/".$file;
                    $ext = substr($file, strrpos($file, '.') + 1);
                    if (is_dir ($path) || $ext != "tbl")
                        continue;
                    
                    $this->log ("importing file $path");

                    if (!MetaExport::importFromFile ($context, $path))
                        $this->addMessage ("Error importing for meta data from file $path.");
                    }
                }
            }

        $dbconn->commitTransaction ();

        // redirect to index.php
        $this->stepComplete ("");
        exit ();
        }

    protected function getDisplayParams ($request)
        {
        $models = array ("" => htmlspecialchars (_("<no template>")));
        
        $basePath = PATH."setup/models";
        $files = scandir ($basePath );
        
        if (FALSE !== $files)
            {
            for ($i = 0; $i < count ($files); $i++)
                {
                $path = $basePath."/".$files[$i];
                $this->log ("file$i - $path");
                if ($files[$i][0] == "." || !is_dir ($path))
                    continue;
                
                $models[$path] = htmlspecialchars ($files[$i]);
                }
            }

        return array_merge (parent::getDisplayParams ($request), array ('models' => $models) );
        }

    protected function checkAccess ($request)
        {
        if (!parent::checkAccess ($request))
            return false;
        return $this->context->canCreate ("*");
        }
    }

?>
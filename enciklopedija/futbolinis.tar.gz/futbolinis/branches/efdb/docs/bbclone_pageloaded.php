<?php

define("_BBC_PAGE_NAME", $context->title);
define("_BBCLONE_DIR", PATH."bbclone/");
define("COUNTER", _BBCLONE_DIR."mark_page.php");

if (is_readable(COUNTER))
    include_once(COUNTER);

?>

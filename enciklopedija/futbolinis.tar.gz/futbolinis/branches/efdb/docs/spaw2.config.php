<?php
$resourceFile = !defined ("PATH");
if ($resourceFile)
    {
    define ("PATH", str_replace('\\\\','/',dirname(__FILE__)).'/../../');
    define ("DEBUG", false);
    }

require_once (PATH.'conf/spaw2.config.php');
    
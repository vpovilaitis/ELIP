<?php
require_once (PATH.'inc/instanceeditor.php');
require_once (PATH.'inc/newstable.php');

class NewsEditor extends InstanceEditor
    {
    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $scope = !empty ($_REQUEST["sp"]) ? $_REQUEST["sp"] : false;
        $this->dbtable = new NewsTable ($context, $scope);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        $fields = array ();
        $prefix  = $this->getPrefix ();

        $fields[] = new TextFieldTemplate ($prefix, NewsTable::COL_TITLE,
                                           $this->getText ("Title:"), $this->getText ("News item title"), 64);
        $fields[] = new LongTextFieldTemplate ($prefix, NewsTable::COL_OVERVIEW,
                                           $this->getText ("Overview:"), $this->getText ("Short overview"));
        $fields[] = new LongTextFieldTemplate ($prefix, NewsTable::COL_DETAILS,
                                           $this->getText ("Full text:"), $this->getText ("Full news item content"));

        if (!$isCreating)
            {
            $fields[] = new UpdateEntryFieldTemplate ($prefix, NewsTable::COL_UPDATE_ENTRY_DATE,
                                                   $this->getText ("Mark updated:"), $this->getText ("Mark this news item as updated."));
            }

        $fields[] = new CheckBoxFieldTemplate ($prefix, NewsTable::COL_HIDDEN,
                                               $this->getText ("Draft:"), $this->getText ("Do not make this entry publicly available (must be published manually)."));
        $fields[] = new TextFieldTemplate ("", DBTable::COL_SOURCE,
                                    $this->getText ("Source(s):"), $this->getText ("Source and comments"), 64);
        $fields[] = new DateFieldTemplate ("", DBTable::COL_SOURCEDATE,
                                    $this->getText ("Updated on:"), $this->getText ("Sources updated on"));

        return $fields;
        }

    public function getFields ()
        {
        $ret = parent::getFields ();
        if (!empty ($this->instance) && empty ($this->instance[NewsTable::COL_HIDDEN]))
            {
            // disdable "Hidden field" if it is already published
            foreach ($ret as &$field)
                {
                if (NewsTable::COL_HIDDEN == $field->key)
                    $field->readonly = true;
                }
            }

        return $ret;
        }

    public function getPageTitle ($isCreating = false)
        {
        return $isCreating
                    ? $this->getText ("Adding a news entry")
                    : $this->getText ("Modifying the news entry");
        }

    protected function valueChanged ($initialValues, $key, $newValue)
        {
        if (NewsTable::COL_UPDATE_ENTRY_DATE == $key)
            return $newValue;

        return parent::valueChanged ($initialValues, $key, $newValue);
        }

    protected function addSafeguardCriterion (&$criteria, $initialValues, $key)
        {
        if (NewsTable::COL_UPDATE_ENTRY_DATE == $key)
            return;
        return parent::addSafeguardCriterion ($criteria, $initialValues, $key);
        }

    public function showCancel ()
        {
        return true;
        }

    protected function showSuccessPage ($request)
        {
        if ($this->isCreating ())
            {
            $url = $this->context->chooseUrl ("sitenews", "index.php?c=NewsListPage");
            $this->context->redirect ($url);
            return false;
            }

        return $this->redirectOnSuccess ();
        }

    public function redirectOnSuccess ()
        {
        $ids = $this->getIds ();
        $id = $ids[0];
        $url = $this->context->chooseUrl ("newsitem/$id", "index.php?c=NewsListPage&id=$id");
        $this->context->redirect ($url);
        return false;
        }

    }

class UpdateEntryFieldTemplate extends CheckBoxFieldTemplate
    {
    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        // "update date" column does not exist in the database, it is only recognized by the updateRecord method, so no need to alter result columns
        }
    }

<?php

require_once (PATH.'pages/contenteditor.php');
require_once (PATH.'inc/componentfactory.php');

class RevisionsLink extends SingleRowURL
    {
    protected $dbtable;
    public function __construct ($component, $dbtable)
        {
        parent::__construct ($component, Constants::MODE_REVISIONS, $this->getText ("Revisions"), NULL);
        $this->dbtable = $dbtable;
        }

    public function getUrl ($request, $id)
        {
        return LabelContentLinkFieldTemplate::createContentViewLink ($this->component->getContext (),
                                                                     $this->dbtable, $this->dbtable->getId (),
                                                                     array ($id), Constants::MODE_REVISIONS);
        }

    public function isVisible ($row = NULL)
        {
        $revTable = $this->dbtable->getRevisionTableName ();
        if (empty ($revTable))
            return false;

        return NULL != $row;
        }
    }

class ContentPreviewLink extends SingleRowURL
    {
    protected $dbtable;
    public function __construct ($component, $dbtable)
        {
        parent::__construct ($component, "list", $dbtable->getDescription (), NULL);
        $this->dbtable = $dbtable;
        }

    public function getUrl ($request, $id)
        {
        if (defined ("BASE_URL") && strlen (trim (BASE_URL, " /")) > 0)
            $basePath = trim (BASE_URL, " /")."/";
        else
            $basePath = PATH;

        if (defined ("FRIENDLY_URL") && FRIENDLY_URL)
            {
            if (!empty ($this->dbtable))
                {
                return $basePath."list/".$this->dbtable->getName ()."/".$this->context->getLanguage ();
                }
            }

        $url = "index.php?c=ContentPreviewPage&tn={$this->dbtable->getName()}";
        return $this->context->processUrl ($url, true);
        }

    public function isVisible ($row = NULL)
        {
        $parent = $this->dbtable->getParentTable ();
        if (!empty ($parent))
            return false;

        return NULL != $row;
        }
    }

class ContentView extends ContentInstanceEditor
    {
    public $lastUnconfirmedId = NULL;
    protected $hiddenDisplayNameField = NULL;
    protected $hasStatistics;

    public function __construct ($context, $prefix, $dbtable)
        {
        $this->hasStatistics = ComponentFactory::hasStatisticsView ($context, $dbtable);
        parent::__construct ($context, $prefix, $dbtable);
        $context->addScriptFile ("contentview");
        $this->readonly = true;
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        if (!empty ($this->context->request["diff"]))
            {
            $params[] = new SelectRevisions ();
            $criteria[] = new EqCriterion (DBTable::COL_REVISIONID, $this->context->request["diff"]);
            }
        else
            {
            // creator id is used to decide if item is deleteable
            $resultColumns[] = DBTable::COL_CREATEDBY;
            }

        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        if (NULL !== $this->hiddenDisplayNameField)
            $this->hiddenDisplayNameField->prepareQuery ($resultColumns, $criteria, $joins, $params);
        if (false === array_search ("meta", $resultColumns))
            {
            $col = $this->dbtable->findColumn ("meta");
            if (!empty ($col))
                $resultColumns[] = "meta";
            }

        $params[] = "View";
        }

    public function getTitleHidden ()
        {
        return false;
        }

    protected function createField ($request, $prefix, $col)
        {
        if (MetaDataColumns::CATEGORY_GENERATED == $col->category)
            return NULL;

        if ($col instanceof ValueColumn)
            {
            $columnDef = $col->columnDef;
            if ($columnDef instanceof DateColumn || $columnDef instanceof DateTimeColumn)
                $field = new LabelDateFieldTemplate ("i", $columnDef->name, $col->getLabel ());
            else if ($columnDef instanceof BoolColumn)
                $field = new LabelBoolFieldTemplate ("i", $columnDef->name, $col->getLabel ());
            else if ($columnDef instanceof NamedIntColumn)
                $field = new LabelNamedIntFieldTemplate ("i", $columnDef->name, $col);
            else if ($columnDef instanceof WeightColumn)
                $field = new LabelWeightFieldTemplate ("i", $columnDef->name, $col->getLabel ());
            else if ($columnDef instanceof HeightColumn)
                $field = new LabelHeightFieldTemplate ("i", $columnDef->name, $col->getLabel ());
            else if ($columnDef instanceof DecimalColumn)
                $field = new LabelDecimalFieldTemplate ("i", $columnDef->name, $col->getLabel ());
            else if ($columnDef instanceof IntColumn)
                $field = new LabelIntFieldTemplate ("i", $columnDef->name, $col->getLabel ());
            else if ($columnDef instanceof LongTextColumn)
                {
                $field = new FormattedFieldLabelTemplate ("i", $columnDef->name, $col->getLabel ());
                }
            else
                $field = new LabelFieldTemplate ("i", $columnDef->name,
                                                 $col->getLabel (),
                                                 $columnDef instanceof LongTextColumn);
            }
        else
            {
            $field = new LabelRelationFieldTemplate ($this->context, $prefix, $col);
            }

        if (MetaDataColumns::CATEGORY_ADDITIONAL == $col->category)
            {
            if (ContentTable::COL_DISPLAY_NAME == $col->name)
                $this->hiddenDisplayNameField = $field;
            return NULL;
            }

        return $field;
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if ($this->isCreating () || empty ($this->dbtable))
            return true;

        $id = $this->getIds ();
        $relatedtables = $this->dbtable->getRelatedTables ();
        if (!empty ($relatedtables))
            {
            foreach ($relatedtables as $pair)
                {
                list ($table, $columns) = $pair;
                $component = ComponentFactory::createPreview ($this->context,
                                                              "related{$table->getName()}",
                                                              $table, DefaultFactory::PREVIEW_RELATED,
                                                              $this->dbtable);

                if (empty ($component))
                    continue;
                $criteria = array ();
                foreach ($columns as $col)
                    {
                    $criteria[] = new EqCriterion ($col->name, $id);
                    }

                $component->setCriteria (array (new LogicalOperatorOr ($criteria)));
                $component->showParentField (true);

                if (1 == count ($columns)) // exclude only if a single related column
                    {
                    $relatedColumn = array_shift ($columns);
                    $component->excludeColumns (array ($relatedColumn->name));
                    $component->setTitle ($relatedColumn->getRelationName ());
                    }
                else
                    $component->setTitle ($table->getDescription ());

                $this->addComponent ($request, "related_{$table->getName()}", $component);
                }
            }

        return true;
        }

    protected function createChildPreview ($context, $request, $id, $table)
        {
        if (!$table->integrateIntoParent ())
            return parent::createChildPreview ($context, $request, $id, $table);

        $component = new ContentIntegratedPreview ($context, "preview{$table->getId()}", $table, $id);
        return $component;
        }

    protected function createRecord (&$request, $values)
        {
        return false;
        }

    public function getSectionName ()
        {
        return NULL;
        }

    public function getPageTitle ()
        {
        $instance = $this->getInstance ();
        if (!empty ($instance))
            $label = $this->dbtable->getDisplayName ($instance);

        if (empty ($label))
            {
            $label = $this->dbtable->getDescription ();
            if (empty ($label))
                $label = $this->dbtable->getName ();
            }

        if (!empty ($this->context->request["diff"]))
            return $this->formatText ("[_0] (old version)", $label);

        return $this->formatText ("[_0] (view)", $label);
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "contentview";
        }

    public function hasStatisticsLink ($instance)
        {
        return $this->hasStatistics;
        }

    public function initiallyDisplayStatistics ($instance)
        {
        return false;
        }

    public function getFacebookIntegrationLink ()
        {
        $table = $this->dbtable->getName();
        $id = implode ("_", $this->getIds ());
        $url = $this->context->chooseUrl ("content/$table/$id",
                                          "index.php?c=ContentPage&mode=view&tn=$table&id=$id");
        return $url;
        }

    public function getShowStatisticsScript ($instance, $forEvent = false)
        {
        $postFix = $forEvent ? ", event" : "";
        return "generateStatistics('statistics_placeholder', '{$this->getStatisticsLink($instance,true)}'$postFix);";
        }

    public function getStatisticsLink ($instance, $inline = false)
        {
        if (!$this->hasStatistics)
            return false;

        $table = $this->dbtable->getName();
        $id = implode ("_", $this->getIds ());
        $url = $this->context->chooseUrl ("stats/$table/$id",
                                          "index.php?c=ContentPage&mode=stats&tn=$table&id=$id");

        if ($inline)
            $url .= ((false === strpos ($url, "&id=")) ? "/" : "&").Constants::PARAM_RENDER_MODE."=".PageContext::RENDER_INLINE;

        return $url;
        }
    public function getStatisticsLinkTitle ()
        {
        return $this->getText ("Detailed statistics");
        }

    public function processInputFields ($context, &$request)
        {
        $template = $this->collectTemplateFields ($request, $this->isCreating ());

        // retrieve values from database
        $this->retrieveCached ($request, $this->getIds ());
        $values = &$this->instance;

        foreach ($template as $field)
            {
            $field->preprocessLoadedValue ($values, !$this->isCreating ());
            }

        return true;
        }

    public function getActionList ()
        {
        if (empty ($this->dbtable))
            return NULL;

        $arr = array ();
        if ($this->dbtable->canEdit ())
            {
            $url = "index.php?c=ContentPage&action=".Constants::MODE_EDIT."&tid={$this->dbtable->getId()}";
            $arr[] = new SingleRowURL ($this, Constants::MODE_EDIT, $this->getText ("Edit"), $url);
            }

        // add "Revisions" link
        $discussionstable = new DiscussionsTable ($this->context);
        if ($discussionstable->canRead ())
            {
            $table = $this->dbtable->getName();
            $id = implode ("_", $this->getIds ());
            $url = $this->context->chooseUrl ("talk/_$table/$id",
                                              "index.php?c=Discussions&sc=_$table&id=$id");
            $title = $this->getText ("Discussions");
            $arr[] = new SimpleLinkAction ($this, "discuss", $title, $url, true);
            }

        if ($this->dbtable->canDelete ())
            $canDelete = true;
        else
            {
            $instance = $this->getInstance ();
            $canDelete = $this->dbtable->ownerCanDelete () && (empty ($instance[DBTable::COL_CREATEDBY]) || $instance[DBTable::COL_CREATEDBY] == $this->context->getCurrentUser ());
            }

        $arr[] = new RevisionsLink ($this, $this->dbtable);
        $arr[] = new ContentPreviewLink ($this, $this->dbtable);

        if ($canDelete)
            $arr[] = new DeleteIcon ($this, $this->dbtable, true);

        return $arr;
        }

    public function getId ($row)
        {
        if (NULL == $this->dbtable)
            return false;

        $cols = $this->dbtable->getPrimaryIndexColumns ();
        $ids = array ();
        foreach ($cols as $col)
            $ids[] = $row[$col->name];

        return implode ("_", $ids);
        }

    public function getMetaDescription ()
        {
        if (NULL == $this->dbtable)
            return NULL;
        $description = $this->dbtable->getInstanceDescription ($this->getInstance ());
        if (empty ($description))
            return NULL;
        return $this->trimSentence (strip_tags ($description), 150);
        }

    protected function getHintContextMode ()
        {
        return HintsTable::CONTEXT_VIEW;
        }
        
    public function retrieveImageContext ($instance, $zone, $width, $height, $canRotate = true)
        {
        if (empty ($this->dbtable))
            return NULL;
        
        $scope = HintsTable::SCOPE_CONTENTTABLE.$this->dbtable->getName ();
        $id = $this->getId ($instance);
        return parent::getImageContext ($scope, $id, $zone, $width, $height, $canRotate);
        }
    }

require_once (PATH.'pages/contentintegratedpreview.php');

<?php

class SimpleText extends TextComponent
    {
    protected $title;
    protected $description;
    protected $titleInline = false;

    public function __construct ($context, $prefix, $table, $title = NULL, $description = NULL)
        {
        $this->title = $title;
        $this->description = $description;
        parent::__construct ($prefix, $context, NULL);
        }

    public function isTitleDisplayedInline ()
        {
        return $this->titleInline;
        }

    public function getTitle ()
        {
        return $this->title;
        }

    public function getDisplayedText ()
        {
        return $this->description;
        }

    public function getMoreInformationUrl ()
        {
        // override to provide "More information" link at the bottom 
        return NULL;
        }

    public function getMoreInformationText ()
        {
        return $this->getText ("More...");
        }
    }

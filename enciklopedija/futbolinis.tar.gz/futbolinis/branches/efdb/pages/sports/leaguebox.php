<?php
require_once (PATH."pages/navigationbox.php");
require_once (PATH."inc/sports/competitionnamestable.php");

class LeagueBox extends NavigationBox
    {
    protected $competitionId;
    protected $lng;
    const MAX_ITEMS = 4;

    public function __construct ($context, $dbtable, $currentItemId)
        {
        parent::__construct ($context, $dbtable, $currentItemId, array ("league_id"));
        $this->lng = Language::getInstance ($context);
        }

    public function selectNeighbours ($context, &$request)
        {
        if (SIMPLIFIED_TEAM_LABELS)
            {
            $dbtable = new CompetitionNamesTable ($context);
            $teamId = implode ("_", $this->currentItemId);
            $criteria[] = new EqCriterion (CompetitionNamesTable::COL_LEAGUEID, $teamId);
            $params[] = OrderBy::create (CompetitionNamesTable::COL_DATEFROM);
            $names = $dbtable->selectBy (NULL, $criteria, null, $params);
            return $names;
            }

        $idColumn = $this->idColumns[0];
        $columns = array ("predecessor");
        $currentId = implode ("_", $this->currentItemId);
        $criteria = array (new EqCriterion ($idColumn, $currentId));
        $item = $this->dbtable->selectSingleBy ($columns, $criteria);
        if (empty ($item))
            return false;

        $columns = array ($idColumn, "name", "predecessor");
        $criteria = array
            (
            new EqCriterion ($idColumn, $currentId),
            new EqCriterion ("predecessor", $this->currentItemId),
            );

        if (!empty ($item["predecessor"]))
            {
            $predecessorId = implode ("_", $item["predecessor"]);
            $criteria[] = new EqCriterion ($idColumn, $predecessorId);
            }

        $criteria = array (new LogicalOperatorOr ($criteria));

        $rows = $this->dbtable->selectBy ($columns, $criteria);
        if (empty ($rows))
            return false;

        $predecessor = NULL;
        $current = NULL;
        $successor = NULL;

        foreach ($rows as $row)
            {
            if (!empty ($item["predecessor"]) && $row[$idColumn] == $predecessorId)
                {
                $predecessor = $row;
                }
            else if ($row[$idColumn] == $currentId)
                {
                $current = $row;
                }
            else
                $successor = $row;
            }

        $rows = array ();
        if (!empty ($predecessor))
            $rows[] = $predecessor;
        if (!empty ($current))
            $rows[] = $current;
        if (!empty ($successor))
            $rows[] = $successor;

        return $rows;
        }

    public function createItem ($row, $id)
        {
        if (SIMPLIFIED_TEAM_LABELS)
            {
            $editLink = $deleteLink = NULL;
            $dbtable = new CompetitionNamesTable ($this->context);
            if ($dbtable->canEdit ())
                $editLink = $this->context->processUrl ("index.php?service=sports/EditCompetitionLabelPopup&action=edit&id=".$row[CompetitionNamesTable::COL_ID], true);
            if ($dbtable->canDelete ())
                $deleteLink = $this->context->processUrl ("index.php?service=sports/EditCompetitionLabelPopup&mode=delete&id=".$row[CompetitionNamesTable::COL_ID], true);

            $from = $row[CompetitionNamesTable::COL_DATEFROM];
            $to = $row[CompetitionNamesTable::COL_DATETO];
            $years = "";
            if (!empty ($from) && !empty ($to))
                {
                $years = $this->getText ("[_0]-[_1]|team existence years",
                                         $this->lng->dateToString ($from, "year"),
                                         $this->lng->dateToString ($to, "year"));
                }
            else if (!empty ($from))
                {
                $years = $this->getText ("[_0]-|team existence years",
                                         $this->lng->dateToString ($from, "year"));
                }
            else if (!empty ($to))
                {
                $years = $this->getText ("-[_0]|team existence years",
                                         $this->lng->dateToString ($to, "year"));

                }

            return array
                    (
                    "years" => $years,
                    self::LABEL => $row[CompetitionNamesTable::COL_NAME],
                    "editUrl" => $editLink,
                    "deleteUrl" => $deleteLink,
                    );
            }

         return array
                (
                self::LABEL => $row["c_name"],
                );
        }

    public function getTitle ()
        {
        return SIMPLIFIED_TEAM_LABELS ? $this->getText ("Historical names") : $this->getText ("Successor/predecessor");
        }

    public function getCssClass ()
        {
        return SIMPLIFIED_TEAM_LABELS ? "clubteams" : "successors";
        }

    public function isVisible ($inline = false)
        {
        return $inline && (count ($this->items) > 1 || $this->context->getCurrentUser() > 0);
        }

    public function getCreateUrl ()
        {
        $dbtable = new CompetitionNamesTable ($this->context);
        if (SIMPLIFIED_TEAM_LABELS && $dbtable->canCreate ())
            {
            $id = implode ("_", $this->currentItemId);
            return $this->context->processUrl ("index.php?service=sports/EditCompetitionLabelPopup&action=new&leagueid=".$id, true);
            }
        return NULL;
        }
    }

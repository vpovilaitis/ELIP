<?php
require_once (PATH."pages/statisticsview.php");
require_once (PATH."inc/sports/constants.php");
require_once (PATH."inc/sports/common.php");
require_once (PATH."inc/sports/scorecollector.php");
require_once (PATH."inc/sports/statistics.php");
require_once (PATH."pages/sports/teampreseasonchanges.php");

class CompetitionSeasonStats extends StatisticsView
    {
    const COL_PLAYER = "player";
    const COL_TEAM = CompetitionStatistics::COL_TEAM;
    const COL_YELLOW_COUNT = "ycount";
    const COL_YELLOWRED_COUNT = "yrcount";
    const COL_RED_COUNT = "rcount";
    const COL_MISS_COUNT = "misscount";
    const COL_COUNT = "count";
    const COL_TOTAL_RED_COUNT = "totalred";
    const COL_AVG_COUNT = "avgCount";
    const COL_SCORED = "scored";
    const COL_CONCEDED = "conceded";
    const COL_REF_EVAL = "refeval";

    const COL_CAUSE = "cause";
    const COL_PERCENT = "pct";
    const COL_REFEREE = "referee";
    const COL_GAMES = "games";
    const COL_GAMES_REGISTERED = "registered";
    const COL_AS_SUBSTITUTE = "assubst";
    const COL_SUBSTITUTED = "substituted";
    const COL_MINUTES = "min";
    const COL_ON_BENCH = "onbench";
    const COL_FULL_MATCHES = "full";
    const COL_DISTINCT_REGISTERED = "distPlayers";
    const COL_DISTINCT_PLAYED = "distReg";
    const COL_DISTINCT_MATCHES = "distMatch";

    const COL_MAX_AGE = "maxAge";
    const COL_MIN_AGE = "minAge";
    const COL_AVG_AGE = "avgAge";
    const COL_BIRTH_DATE = "birth";
    const COL_RELIABILITY = "reliability";
    const COL_FIRST_MATCH = "firstmatch";
    const COL_LAST_MATCH = "lastmatch";
    
    const COL_GOALS = "goals";
    const COL_OWN_GOALS = "owngoals";
    const COL_PENALTIES = "penalties";

    const COL_STADIUM = "stadium";
    const COL_MAX_ATTENDANCE = "maxAtt";
    const COL_MIN_ATTENDANCE = "minAtt";
    const COL_AVG_ATTENDANCE = "avgAtt";
    const COL_TOTAL_ATTENDANCE = "sumAtt";

    const CARDS_ALL = 0;
    const CARDS_PLAYER = 10;
    const CARDS_TEAM = 20;

    const PLAYERS_ALL = 0;
    const PLAYERS_BY_MINUTES = 10;
    const PLAYERS_BY_MINUTES_DESC = 11;
    const PLAYERS_BY_GAMES = 20;
    const PLAYERS_BY_GAMES_REG = 25;
    const PLAYERS_UNUSED = 30;
    const PLAYERS_ON_BENCH = 40;
    const PLAYERS_SUBSTITUTED = 50;

    protected $lng;
    protected $createdIdCriterion = array ();

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $this->lng = Language::getInstance ($context);
        $context->addStyleSheet ("sports");
        }

    protected function getQueryStringParts ()
        {
        return array_merge (parent::getQueryStringParts (), array ("teamid", "dfrom", "dto"));
        }

    protected function getCachedComponentData ($request, $table, $method, $id, $param)
        {
        $cache = Cache::getInstance ($table, 6*60*60);
        $paramSerialized = $param;
        if (is_array($param))
            $paramSerialized = implode ("|", $param);
        else if (NULL === $paramSerialized)
            $paramSerialized = "NULL";
        else if (false === $paramSerialized)
            $paramSerialized = "false";

        $teamId = !empty ($request["teamid"]) ? $request["teamid"] : NULL;
        $dateFrom = !empty ($request["dfrom"]) ? $request["dfrom"] : NULL;
        $dateTo = !empty ($request["dto"]) ? $request["dto"] : NULL;
        $cacheId = md5 ("stats:".$method.":".$id.":".$paramSerialized.".$teamId.$dateFrom.$dateTo");
        $startTime = microtime (true);

        if (false === ($result = $cache->get ($cacheId)))
            {
            $result = call_user_func (array($this, $method), $id, $param);
            $endTime = microtime (true);
            $this->context->log ("Cache miss. $method took ".($endTime-$startTime)." s");

            $cache->save ($result, $cacheId);

            $endTime2 = microtime (true);
            $this->context->log ("Saving to the cache took ".($endTime2-$endTime)." s");
            }
        else
            {
            $endTime = microtime (true);
            $this->context->log ("Cache hit ($method) - ".($endTime-$startTime)." s");
            }

        return $result;
        }

    protected function createComponents ($context, $request)
        {
        $idArr = $this->getIds ();
        $id = $idArr[0];
        $idx = 0;

        $arr = array ();

        $type = empty ($request["stats"]) ? NULL : $request["stats"];
        $el = empty ($request["el"]) ? NULL : $request["el"];
        switch ($type)
            {
            case "playercards":
                {
                $key = "c".(++$idx);
                if (empty ($el) || $key == $el)
                    {
                    $yellowCards = $this->getCachedComponentData ($request, Sports::TABLE_MATCHEVENT, "selectPlayerCardStatistics", $id, true);
                    if (!empty ($yellowCards))
                        {
                        $arr[] = new StatisticsRowsComponent ($this, $key, $this->getText ("Player yellow cards"), $yellowCards, $this->selectPlayerCardColumns (true));
                        }
                    }

                $key = "c".(++$idx);
                if (empty ($el) || $key == $el)
                    {
                    $redCards = $this->getCachedComponentData ($request, Sports::TABLE_MATCHEVENT, "selectPlayerCardStatistics", $id, false);
                    if (!empty ($redCards))
                        {
                        $arr[] = new StatisticsRowsComponent ($this, $key, $this->getText ("Player red cards"), $redCards, $this->selectPlayerCardColumns (false), true);
                        }
                    }
                break;
                }

            case "players":
                {
                $players = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectPlayerStatistics", $id, self::PLAYERS_ALL);
                if (!empty ($players))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "pla".(++$idx), $this->getText ("All players (sorted by time spent on the field)"), $players, $this->selectPlayerColumns (true), true);
                    }
                $players = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectPlayerStatistics", $id, self::PLAYERS_UNUSED);
                if (!empty ($players))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "pla".(++$idx), $this->getText ("Players who spent all their season on the bench"), $players, $this->selectPlayerColumns (true), true);
                    }
                break;
                }

            case "playerssorted":
                {
                $players = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectPlayerStatistics", $id, self::PLAYERS_BY_MINUTES);
                if (!empty ($players))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "pla".(++$idx), $this->getText ("Players who spent most time on the field"), $players, $this->selectPlayerColumns (true));
                    }
                $players = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectPlayerStatistics", $id, self::PLAYERS_BY_GAMES);
                if (!empty ($players))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "pla".(++$idx), $this->getText ("Players who played in most games"), $players, $this->selectPlayerColumns (true));
                    }
                $players = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectPlayerStatistics", $id, self::PLAYERS_BY_MINUTES_DESC);
                if (!empty ($players))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "pla".(++$idx), $this->getText ("Players who spent least time on the field"), $players, $this->selectPlayerColumns (true));
                    }
                $players = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectPlayerStatistics", $id, self::PLAYERS_BY_GAMES_REG);
                if (!empty ($players))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "pla".(++$idx), $this->getText ("Players who were registered for most games"), $players, $this->selectPlayerColumns (true));
                    }
                $players = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectPlayerStatistics", $id, self::PLAYERS_ON_BENCH);
                if (!empty ($players))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "pla".(++$idx), $this->getText ("Players who spent most games on the bench"), $players, $this->selectPlayerColumns (true));
                    }
                $players = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectPlayerStatistics", $id, self::PLAYERS_SUBSTITUTED);
                if (!empty ($players))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "pla".(++$idx), $this->getText ("Players who were substituted in most games"), $players, $this->selectPlayerColumns (true));
                    }
                break;
                }

            case "teamcards":
                {
                $cards = $this->getCachedComponentData ($request, Sports::TABLE_MATCHEVENT, "selectTeamCardStatistics", $id, false);
                if (!empty ($cards))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "ct".(++$idx), $this->getText ("Cards by team"), $cards, $this->selectTeamCardColumns (true));
                    }
                $cards = $this->getCachedComponentData ($request, Sports::TABLE_MATCHEVENT, "selectTeamCardStatistics", $id, true);
                if (!empty ($cards))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "ct".(++$idx), $this->getText ("Cards against team"), $cards, $this->selectTeamCardColumns (true));
                    }

                $cards = $this->getCachedComponentData ($request, Sports::TABLE_MATCHEVENT, "selectTeamCardTypeStatistics", $id, false);
                if (!empty ($cards))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "ct".(++$idx), $this->getText ("Most common event cause"), $cards, $this->selectTeamCardTypeColumns (false));
                    }
                $cards = $this->getCachedComponentData ($request, Sports::TABLE_MATCHEVENT, "selectTeamCardTypeStatistics", $id, true);
                if (!empty ($cards))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "ct".(++$idx), $this->getText ("Most common event cause by team"), $cards, $this->selectTeamCardTypeColumns (true));
                    }
                break;
                }

            case "teamplayers":
                {
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectTeamPlayerStatistics", $id, NULL);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "tp".(++$idx), $this->getText ("Team player statistics"), $rows, $this->selectTeamPlayerColumns ());
                    }
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectTeamPlayerAgeStatistics", $id, NULL);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "tp".(++$idx), $this->getText ("Team player ages"), $rows, $this->selectTeamPlayerAgeStatsColumns ());
                    }
                if (!empty ($request["all"]) || !empty ($request["teamid"]))
                    {
                    $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectTeamPlayersWithAge", $id, NULL);
                    if (!empty ($rows))
                        {
                        $arr[] = new StatisticsRowsComponent ($this, "tp".(++$idx), $this->getText ("All players by age"), $rows, $this->selectTeamPlayerAgeColumns ());
                        }
                    }
                else
                    {
                    $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectTeamPlayersWithAge", $id, false);
                    if (!empty ($rows))
                        {
                        $arr[] = new StatisticsRowsComponent ($this, "tp".(++$idx), $this->getText ("Youngest players"), $rows, $this->selectTeamPlayerAgeColumns ());
                        }
                    $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHPLAYER, "selectTeamPlayersWithAge", $id, true);
                    if (!empty ($rows))
                        {
                        $arr[] = new StatisticsRowsComponent ($this, "tp".(++$idx), $this->getText ("Oldest players"), $rows, $this->selectTeamPlayerAgeColumns ());
                        }
                    }

                break;
                }

            case "goal":
                {
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHGOAL, "selectPlayerGoalStatistics", $id, NULL);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("All goal scorers"), $rows, $this->selectGoalScorersColumns (), true);
                    }
                break;
                }

            case "assist":
                {
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHGOAL, "selectPlayerGoalStatistics", $id, "assist");
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("Assists by players"), $rows, $this->selectGoalScorersColumns (), true);
                    }
                break;
                }

            case "goals":
                {
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHGOAL, "selectPlayerGoalStatistics", $id, NULL);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("All goal scorers"), $rows, $this->selectGoalScorersColumns (), true);
                    }
                if (!empty ($_REQUEST["teamid"]))
                    {
                    $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHGOAL, "selectPlayerGoalStatisticsInverted", $id, NULL);
                    if (!empty ($rows))
                        {
                        $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("All opponent scorers"), $rows, $this->selectGoalScorersColumns (), true);
                        }
                    }

                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHGOAL, "selectPlayerGoalStatistics", $id, true);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("Youngest scorers"), $rows, $this->selectGoalScorersColumns (true));
                    }
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHGOAL, "selectPlayerGoalStatistics", $id, false);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("Oldest scorers"), $rows, $this->selectGoalScorersColumns (true));
                    }
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHGOAL, "selectTeamGoalAgeStatistics", $id, NULL);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("Team goal scorer ages"), $rows, $this->selectTeamPlayerAgeStatsColumns ());
                    }
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCH, "selectTeamGoalStatistics", $id, NULL);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("Team goals scored and conceded"), $rows, $this->selectTeamGoalColumns ());
                    }
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHGOAL, "selectGoalTypeStatistics", $id, false);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("Most common goal types"), $rows, $this->selectGoalTypeColumns (false));
                    }
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHGOAL, "selectGoalTypeStatistics", $id, true);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("Most common scored goal types by team"), $rows, $this->selectGoalTypeColumns (true));
                    }
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCHGOAL, "selectGoalTypeStatisticsInverted", $id, NULL);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "gt".(++$idx), $this->getText ("Most common conceded goal types by team"), $rows, $this->selectGoalTypeColumns (true));
                    }
                break;
                }

            case "stadia":
                {
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCH, "selectAttendanceStatistics", $id, NULL);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "r".(++$idx), $this->getText ("Stadium attendance"), $rows, $this->selectAttendanceColumns (), true);
                    }
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCH, "selectAttendanceStatistics", $id, true);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "r".(++$idx), $this->getText ("Stadium attendance by club"), $rows, $this->selectAttendanceColumns (true), true);
                    }
                $rows = $this->getCachedComponentData ($request, Sports::TABLE_MATCH, "selectAttendanceStatistics", $id, 2);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "r".(++$idx), $this->getText ("Away attendance by club"), $rows, $this->selectAttendanceColumns (true), true);
                    }
                break;
                }

            case "refrating":
                {
                $referees = $this->getCachedComponentData ($request, Sports::TABLE_MATCHREFEREE, "selectRefereeStatistics", $id, NULL);
                if (!empty ($referees))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "r".(++$idx), $this->getText ("Match referee rating"), $referees, $this->selectRefereeColumns (true, true), true);
                    }
                break;
                }

            case "referees":
                {
                $key = "r".(++$idx);
                if (empty ($el) || $key == $el)
                    {
                    $referees = $this->getCachedComponentData ($request, Sports::TABLE_MATCHREFEREE, "selectRefereeStatistics", $id,
                                                               array (MatchConstants::REFEREE_PRIMARY));
                    if (!empty ($referees))
                        {
                        $arr[] = new StatisticsRowsComponent ($this, $key, $this->getText ("Match referees"), $referees, $this->selectRefereeColumns (true), true);
                        }
                    }
                $referees = $this->getCachedComponentData ($request, Sports::TABLE_MATCHREFEREE, "selectRefereeStatistics", $id,
                                                           array (MatchConstants::REFEREE_ASSISTANT1, MatchConstants::REFEREE_ASSISTANT2, MatchConstants::REFEREE_ASSISTANT_UNSPECIFIED));
                if (!empty ($referees))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "r".(++$idx), $this->getText ("Assistant referees"), $referees, $this->selectRefereeColumns (), true);
                    }
                $referees = $this->getCachedComponentData ($request, Sports::TABLE_MATCHREFEREE, "selectRefereeStatistics", $id,
                                                           array (MatchConstants::REFEREE_RESERVE));
                if (!empty ($referees))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "r".(++$idx), $this->getText ("4th referees"), $referees, $this->selectRefereeColumns (), true);
                    }
                $referees = $this->getCachedComponentData ($request, Sports::TABLE_MATCHREFEREE, "selectRefereeStatistics", $id,
                                                           array (MatchConstants::REFEREE_INSPECTOR));
                if (!empty ($referees))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "r".(++$idx), $this->getText ("Match inspectors"), $referees, $this->selectRefereeColumns (), true);
                    }
                $cards = $this->getCachedComponentData ($request, Sports::TABLE_MATCHEVENT, "selectRefereeCardTypeStatistics", $id, true);
                if (!empty ($cards))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "ct".(++$idx), $this->getText ("Most common event cause by referee"), $cards, $this->selectRefereeCardTypeColumns (true));
                    }
                $cards = $this->getCachedComponentData ($request, Sports::TABLE_MATCHEVENT, "selectRefereeCardTypeStatistics", $id, false);
                if (!empty ($cards))
                    {
                    $arr[] = new StatisticsRowsComponent ($this, "ct".(++$idx), $this->getText ("Most common event cause by referee"), $cards, $this->selectRefereeCardTypeColumns (false));
                    }
                break;
                }

            case "attplot":
                $teamId = !empty ($request["teamid"]) ? $request["teamid"] : NULL;
                $arr[] = new StatisticsPlotComponent ($this, "p3", $this->getText ("Attendance by round"), CompetitionStatistics::getAttendanceStatisticsByRound ($this->context, $id, $teamId));
                $arr[] = new StatisticsPlotComponent ($this, "p2", $this->getText ("Goals by round"), CompetitionStatistics::getMatchStatisticsByRound ($this->context, $id, $teamId));
                break;
            
            case "general":
            default:
                $teamId = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
                if (!empty ($teamId))
                    {
                    $rows = $this->selectTeamGeneralStatistics ($id, $teamId);
                    if (!empty ($rows))
                        {
                        $arr[] = new StatisticsEnumeratorComponent ($this, "overview", $this->getText ("Team information - [_0]", $rows[self::COL_TEAM]), $rows, $this->getTeamSimpleStatsColumnNames ());
                        }

                    $component = new TeamPreseasonChanges ($this, "changes", $this->getText ("Team pre-season changes"), $id, $teamId);
                    if ($component->isVisible ())
                        $arr[] = $component;

                    if ("prev_names" == $el)
                        {
                        $component = new TeamNameChanges ($this, "prev_names", $this->getText ("Team names"), $id, $teamId);
                        if ($component->isVisible ())
                            $arr[] = $component;
                        }
                    if ("matches" == $el)
                        {
                        $component = new TeamMatchesComponent ($this, "matches", $id, $teamId);
                        if ($component->isVisible ())
                            $arr[] = $component;
                        }
                    }

                $rows = $this->selectSimpleStatistics ($id);
                if (!empty ($rows))
                    {
                    $arr[] = new StatisticsEnumeratorComponent ($this, "a1", $this->getText ("Facts and sequences"), $rows, $this->getStatsColumnNames ());
                    }

                $teamId = !empty ($request["teamid"]) ? $request["teamid"] : NULL;
                $arr[] = new StatisticsPlotComponent ($this, "p1", $this->getText ("Goals and cards by minute"), CompetitionStatistics::getGoalsAndCardsStatistics ($this->context, $id, 1, $teamId));
                $arr[] = new StatisticsPlotComponent ($this, "p2", $this->getText ("Goals by round"), CompetitionStatistics::getMatchStatisticsByRound ($this->context, $id, $teamId));
                $arr[] = new StatisticsPlotComponent ($this, "p3", $this->getText ("Attendance by round"), CompetitionStatistics::getAttendanceStatisticsByRound ($this->context, $id, $teamId));
                break;
            }

        return $arr;
        }

    public function retrieveTeamsWithFixedStats ($context, $leagueIds)
        {
        return CompetitionStatistics::retrieveTeamsWithFixedStatsByCriteria ($context, Sports::TABLE_TEAMLEAGUESEASON,
                                                             new InCriterion (ContentTable::generateForeignKeyColumn (Sports::COL_TEAMLEAGUESEASON_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id"), $leagueIds),
                                                             array (Sports::COL_TEAMLEAGUESEASON_PLACE),
                                                             NULL, true);
        }

    protected function getAlternativeStatisticsLinks ()
        {
        $teamLabels = $teamIds = $ids = NULL;
        $type = empty ($this->request["stats"]) ? "general" : $this->request["stats"];
        $teamId = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;

        if (empty ($teamId) && "referees" != $type)
            {
            $idArr = $this->getIds ();
            $ids = $this->extractSeasonId ($idArr[0]);
            }

        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        if (!empty ($ids))
            {
            $teamIds = $this->retrieveTeamsWithFixedStats ($this->context, $ids);
            $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);
            }
            

        $statisticsLinks = array (
                "general" => $this->getText ("Facts|statistics"),
                "referees" => $this->getText ("Referees|statistics"),
                "stadia" => $this->getText ("Attendance|statistics"),
                "goals" => $this->getText ("Goals"),
                "teamplayers" => $this->getText ("Teams"),
                "teamcards" => $this->getText ("Team discipline"),
                "playerssorted" => $this->getText ("Players"),
                "playercards" => $this->getText ("Player discipline"),
                "players" => $this->getText ("Player list"),
                );

        if (!empty ($teamId))
            {
            $teamLinks = array ();
            $teamLabels = SportsHelper::getTeamLabels ($this->context, array ($teamId));
            $teamLinks[""] = $teamLabels[$teamId].":";

            foreach ($statisticsLinks as $type => $text)
                {
                if ("referees" == $type)
                    continue;
                $teamLinks["$type|teamid=$teamId"] = $text;
                }

            $teamLinks["|"] = $this->getText ("All teams:");

            $statisticsLinks = array_merge ($teamLinks, $statisticsLinks);
            }
        else if (!empty ($teamIds))
            {
            $statisticsLinks["|"] = $this->getText ("By team:");
            foreach ($teamIds as $teamId)
                {
                if (empty ($teamLabels[$teamId]))
                    continue;
                $statisticsLinks["$type|teamid=$teamId"] = $teamLabels[$teamId];
                }
            }

        return $statisticsLinks;
        }

    protected function getStatsColumnNames ()
        {
        $ret = ScoreCollector::getColumnNames ($this->context);
        $ret[] = new StatisticsColumn (self::COL_YELLOW_COUNT, $this->context->getText ("Yellow cards:"), "statsint");
        $ret[] = new StatisticsColumn (self::COL_RED_COUNT, $this->context->getText ("Red cards:"), "statsint");
        $ret[] = new StatisticsColumn (self::COL_MISS_COUNT, $this->context->getText ("Missed p.k.:"), "statsint");
        return $ret;
        }

    protected function getTeamSimpleStatsColumnNames ()
        {
        return CompetitionStatistics::getTeamSimpleStatsColumnNames ($this->context);
        }

    protected function extractSeasonId ($id)
        {
        $ids = array ($id);
        if (!empty ($id))
            {
            // an exception to generate statistics for all the seasons of some league
            if ("L" == $id[0])
                $ids = SportsHelper::selectLeagueSeasonIds ($this->context, $this->dbtable, substr ($id, 1));
            else
                $ids = SportsHelper::selectCompetitionHierarchyIds ($this->context, $this->dbtable, $ids);
            return $ids;
            }
        return NULL;
        }

    protected function createIdCriterion ($id, $includeFilters = true, $includeTeamCriterion = true)
        {
        $teamId = $includeTeamCriterion && !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
        $dateFrom = !empty ($_REQUEST["dfrom"]) ? $_REQUEST["dfrom"] : NULL;
        $dateTo = !empty ($_REQUEST["dto"]) ? $_REQUEST["dto"] : NULL;
        $key = $id."#".($includeFilters ? 1 : 0)."#$teamId.$dateFrom.$dateTo";
        if (!empty ($this->createdIdCriterion[$key]))
            return $this->createdIdCriterion[$key];

        $ids = $this->extractSeasonId ($id);
        $arr = SportsHelper::createMatchTableCriterion ($this->context, $ids, $teamId, $includeFilters, $dateFrom, $dateTo);

        $this->createdIdCriterion[$key] = $arr;
        return $arr;
        }

    protected function selectTeamGeneralStatistics ($id, $teamId)
        {
        if (empty ($teamId))
            return NULL;

        return CompetitionStatistics::getTeamGeneralStatistics ($this->context, $teamId, $id);
        }

    protected function selectSimpleStatistics ($id)
        {
        $teamId = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
        $cardStatistics = $this->selectRawCardStatistics ($id, self::CARDS_ALL, false);
        $criteria = $this->createIdCriterion ($id, false);

        $scoreCollector = new ScoreCollector ();
        if (!empty ($teamId))
            $scoreCollector->setTeam ($teamId);
        $result = $scoreCollector->selectStatistics ($this->context, $this->request, "competitionstats", $criteria, $id."#".$teamId);
        if (!empty ($cardStatistics))
            {
            $cardStatistics = $cardStatistics[0];
            $yellowRedCount = $cardStatistics[self::COL_YELLOWRED_COUNT];
            if (!empty ($cardStatistics[self::COL_YELLOW_COUNT]))
                $result[self::COL_YELLOW_COUNT] = ScoreCollector::createValueDescription ($this->context, $cardStatistics[self::COL_YELLOW_COUNT], false, empty ($result["gamecnt"]) ? 0 : $result["gamecnt"]);

            if (!empty ($cardStatistics[self::COL_MISS_COUNT]))
                $result[self::COL_MISS_COUNT] = ScoreCollector::createValueDescription ($this->context, $cardStatistics[self::COL_MISS_COUNT], $cardStatistics[self::COL_MISS_COUNT] + $result[ScoreCollector::PENALTY_COUNT], false);
          
            if ($yellowRedCount > 0)
                {
                if (0 == $cardStatistics[self::COL_RED_COUNT])
                    $result[self::COL_RED_COUNT] = $this->ngettext ("[_0] time (for second yellow card)",
                                                                    "[_0] times (for second yellow card)",
                                                                    $yellowRedCount);
                else
                    $result[self::COL_RED_COUNT] = $this->ngettext ("[_1] ([_0] time for second yellow card)",
                                                                    "[_1] ([_0] times for second yellow card)",
                                                                    $yellowRedCount, $cardStatistics[self::COL_RED_COUNT] + $yellowRedCount);
                }
            else
                $result[self::COL_RED_COUNT] = $cardStatistics[self::COL_RED_COUNT];
            }
        return $result;
        }

    protected function selectPlayerCardColumns ($yellow = true)
        {
        if ($yellow)
            return array
                (
                new StatisticsColumn (self::COL_PLAYER, $this->getText ("Player"), "row_label"),
                new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "label"),
                new StatisticsColumn (self::COL_YELLOW_COUNT, $this->getText ("Yellow cards"), "statsint", "yellow"),
                new StatisticsColumn (self::COL_YELLOWRED_COUNT, $this->getText ("Yellow with red cards"), "statsint", "yellow-red"),
                new StatisticsColumn (self::COL_RED_COUNT, $this->getText ("Red cards"), "statsint", "red"),
                );
        return array
            (
            new StatisticsColumn (self::COL_PLAYER, $this->getText ("Player"), "row_label"),
            new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "label"),
            new StatisticsColumn (self::COL_RED_COUNT, $this->getText ("Red cards"), "statsint", "red"),
            new StatisticsColumn (self::COL_YELLOWRED_COUNT, $this->getText ("Yellow with red cards"), "statsint", "yellow-red"),
            new StatisticsColumn (self::COL_YELLOW_COUNT, $this->getText ("Yellow cards"), "statsint", "yellow"),
            );
        }

    protected function selectPlayerColumns ()
        {
        return array
            (
            new StatisticsColumn (self::COL_PLAYER, $this->getText ("Player"), "row_label"),
            new StatisticsColumn (self::COL_GAMES, $this->getText ("Games"), "statsint"),
            new StatisticsColumn (self::COL_MINUTES, $this->getText ("Minutes"), "statsint"),
            new StatisticsColumn (self::COL_FULL_MATCHES, $this->getText ("Full matches"), "statsint"),
            new StatisticsColumn (self::COL_GAMES_REGISTERED, $this->getText ("Games registered"), "statsint"),
            new StatisticsColumn (self::COL_AS_SUBSTITUTE, $this->getText ("As substitute"), "statsint"),
            new StatisticsColumn (self::COL_SUBSTITUTED, $this->getText ("Substituted"), "statsint"),
            new StatisticsColumn (self::COL_ON_BENCH, $this->getText ("On bench"), "statsint"),
            );
        }

    protected function selectTeamCardColumns ()
        {
        return array
            (
            new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "row_label"),
            new StatisticsColumn (self::COL_RED_COUNT, $this->getText ("Red cards"), "statsint", "red"),
            new StatisticsColumn (self::COL_YELLOWRED_COUNT, $this->getText ("Yellow with red cards"), "statsint", "yellow-red"),
            new StatisticsColumn (self::COL_YELLOW_COUNT, $this->getText ("Yellow cards"), "statsint", "yellow"),
            );
        }

    protected function selectTeamPlayerColumns ()
        {
        return array
            (
            new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "row_label"),
            new StatisticsColumn (self::COL_DISTINCT_REGISTERED, $this->getText ("Registered|players"), "statsint"),
            new StatisticsColumn (self::COL_DISTINCT_PLAYED, $this->getText ("Played|statistics"), "statsint"),
            new StatisticsColumn (self::COL_COUNT, $this->getText ("Players per game"), "statsint", "members"),
            new StatisticsColumn (self::COL_SUBSTITUTED, $this->getText ("Subtitutions per game"), "statsint", "substitute"),
            new StatisticsColumn (self::COL_ON_BENCH, $this->getText ("Unused substitutes per game"), "statsint", "unused"),
            );
        }

    protected function selectTeamPlayerAgeStatsColumns ()
        {
        return array
            (
            new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "row_label"),
            new StatisticsColumn (self::COL_AVG_AGE, $this->getText ("Average|age"), "statsint"),
            new StatisticsColumn (self::COL_MIN_AGE, $this->getText ("Youngest"), "label"),
            new StatisticsColumn (self::COL_MAX_AGE, $this->getText ("Oldest"), "label"),
            new StatisticsColumn (self::COL_RELIABILITY, $this->getText ("Reliability"), "label"),
            );
        }

    protected function selectTeamPlayerAgeColumns ()
        {
        return array
            (
            new StatisticsColumn (self::COL_PLAYER, $this->getText ("Player"), "row_label"),
            new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "label"),
            new StatisticsColumn (self::COL_COUNT, $this->getText ("Games played"), "statsint", "cntgames"),
            new StatisticsColumn (self::COL_BIRTH_DATE, $this->getText ("Birth date"), "label"),
            new StatisticsColumn (self::COL_FIRST_MATCH, $this->getText ("First match"), "match-age"),
            new StatisticsColumn (self::COL_LAST_MATCH, $this->getText ("Last match"), "match-age"),
            );
        }

    protected function selectRefereeColumns ($includeCards = false, $includeEvaluation = false)
        {
        $ret = array
            (
            new StatisticsColumn (self::COL_REFEREE, $this->getText ("Referee"), "row_label"),
            new StatisticsColumn (self::COL_GAMES, $this->getText ("Matches"), "statsint"),
            );

        if ($includeEvaluation)
            $ret[] = new StatisticsColumn (self::COL_REF_EVAL, $this->getText ("Evl.|referee rating"), "statsint");

        if ($includeCards)
            {
            $ret[] = new StatisticsColumn (self::COL_COUNT, $this->getText ("Cards"), "statsint");
            $ret[] = new StatisticsColumn (self::COL_AVG_COUNT, $this->getText ("Avg.|cards"), "statsint");
            $ret[] = new StatisticsColumn (self::COL_YELLOW_COUNT, $this->getText ("Yellow cards"), "statsint", "yellow");
            $ret[] = new StatisticsColumn (self::COL_YELLOWRED_COUNT, $this->getText ("Yellow with red cards"), "statsint", "yellow-red");
            $ret[] = new StatisticsColumn (self::COL_RED_COUNT, $this->getText ("Red cards"), "statsint", "red");
            }

        $ret[] = new StatisticsColumn (self::COL_FIRST_MATCH, $this->getText ("First match"), "match-age");
        $ret[] = new StatisticsColumn (self::COL_LAST_MATCH, $this->getText ("Last match"), "match-age");
        return $ret;
        }

    protected function selectAttendanceColumns ($groupByClub = false)
        {
        $ret = array
            (
            new StatisticsColumn (self::COL_STADIUM, $groupByClub ? $this->getText ("Team") : $this->getText ("Stadium"), "row_label"),
            new StatisticsColumn (self::COL_GAMES, $this->getText ("Matches"), "statsint"),
            new StatisticsColumn (self::COL_AVG_ATTENDANCE, $this->getText ("Attendance"), "statsint"),
            new StatisticsColumn (self::COL_MIN_ATTENDANCE, $this->getText ("Min|attendance"), "statsint"),
            new StatisticsColumn (self::COL_MAX_ATTENDANCE, $this->getText ("Max|attendance"), "statsint"),
            new StatisticsColumn (self::COL_TOTAL_ATTENDANCE, $this->getText ("Total|attendance"), "statsint"),
            new StatisticsColumn (self::COL_RELIABILITY, $this->getText ("Reliability"), "label"),
            );
        return $ret;
        }

    protected function selectTeamCardTypeColumns ($groupByTeam)
        {
        $result = array ();
        if ($groupByTeam)
            $result[] = new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "row_label");

        $result[] = new StatisticsColumn (self::COL_CAUSE, $this->getText ("Card cause"), "label");
        $result[] = new StatisticsColumn (self::COL_COUNT, $this->getText ("Count|Card cause"), "statsint");
        if (!$groupByTeam)
            $result[] = new StatisticsColumn (self::COL_PERCENT, $this->getText ("%|Card cause"), "statsint");

        return $result;
        }

    protected function selectRefereeCardTypeColumns ($sortByReferee)
        {
        $result = array ();
        $result[] = new StatisticsColumn (self::COL_TEAM, $this->getText ("Referee"), "row_label");
        $result[] = new StatisticsColumn (self::COL_CAUSE, $this->getText ("Card cause"), "label");
        $result[] = new StatisticsColumn (self::COL_COUNT, $this->getText ("Count|Card cause"), "statsint");
        if ($sortByReferee)
            $result[] = new StatisticsColumn (self::COL_PERCENT, $this->getText ("%|Card cause"), "statsint");

        return $result;
        }

    protected function selectGoalTypeColumns ($groupByTeam)
        {
        $result = array ();
        if ($groupByTeam)
            $result[] = new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "row_label");

        $result[] = new StatisticsColumn (self::COL_CAUSE, $this->getText ("Goal type"), "label");
        $result[] = new StatisticsColumn (self::COL_COUNT, $this->getText ("Count|Goal type"), "statsint");
        if (!$groupByTeam)
            $result[] = new StatisticsColumn (self::COL_PERCENT, $this->getText ("%|Goal type"), "statsint");

        return $result;
        }

    protected function selectTeamGoalColumns ()
        {
        $result = array ();
        $result[] = new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "row_label");
        $result[] = new StatisticsColumn (self::COL_COUNT, $this->getText ("Games"), "statsint");
        $result[] = new StatisticsColumn (self::COL_SCORED, $this->getText ("Scored"), "statsint");
        $result[] = new StatisticsColumn (self::COL_CONCEDED, $this->getText ("Conceded"), "statsint");
        $result[] = new StatisticsColumn (self::COL_COUNT."_home", $this->getText ("Home games"), "statsint");
        $result[] = new StatisticsColumn (self::COL_SCORED."_home", $this->getText ("Scored (home)"), "statsint");
        $result[] = new StatisticsColumn (self::COL_CONCEDED."_home", $this->getText ("Conc. (home)"), "statsint");
        $result[] = new StatisticsColumn (self::COL_COUNT."_away", $this->getText ("Away games"), "statsint");
        $result[] = new StatisticsColumn (self::COL_SCORED."_away", $this->getText ("Scored (away)"), "statsint");
        $result[] = new StatisticsColumn (self::COL_CONCEDED."_away", $this->getText ("Conc. (away)"), "statsint");

        return $result;
        }

    protected function selectGoalScorersColumns ($includeBirthday = false)
        {
        $columns = array
            (
            new StatisticsColumn (self::COL_PLAYER, $this->getText ("Player"), "row_label"),
            new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "label"),
            new StatisticsColumn (self::COL_GOALS, $this->getText ("Goals"), "statsint", "goal"),
            new StatisticsColumn (self::COL_OWN_GOALS, $this->getText ("Own goals"), "statsint", "owngoal"),
            new StatisticsColumn (self::COL_PENALTIES, $this->getText ("Penalties"), "statsint", "penalty"),
            new StatisticsColumn (self::COL_FIRST_MATCH, $this->getText ("First goal"), "match-age"),
            new StatisticsColumn (self::COL_LAST_MATCH, $this->getText ("Last goal"), "match-age"),
            );
        if ($includeBirthday)
            $columns[] = new StatisticsColumn (self::COL_BIRTH_DATE, $this->getText ("Birth date"), "label");
        return $columns;
        }

    protected function selectRawCardStatistics ($id, $mode, $invert)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $eventsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHEVENT);
        if (empty ($matchTable) || empty ($personsTable) || empty ($teamsTable) || empty ($eventsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $isHomeTeamColumn = "c_".Sports::COL_EVENT_ISHOME;
        $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $teamsTable->getIdColumn ());
        $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $teamsTable->getIdColumn ());

        $matchJoins = NULL;
        $columns = array ();
        $params = NULL;
        if (self::CARDS_TEAM == $mode)
            {
            $val = $invert ? 0 : 1;
            $columns[] = new ConditionalResultColumn ("team.id", "$isHomeTeamColumn = $val", $homeTeamColumn, $awayTeamColumn);
            $params[] = new GroupBy (array ("team.id"));
            }

        $joinCriteria = $this->createIdCriterion ($id, true, false);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $filterByTeam = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
        if (is_numeric ($filterByTeam))
            $joinCriteria[] = new FilterByTeamCriterion ($filterByTeam, "c_".Sports::COL_EVENT_ISHOME);
        $columns[] = new ConditionalMaxColumn ("teamMax", "$isHomeTeamColumn = 1", $homeTeamColumn, $awayTeamColumn);
        $columns[] = new ConditionalMinColumn ("teamMin", "$isHomeTeamColumn = 1", $homeTeamColumn, $awayTeamColumn);
        $columns[] = new ConditionalDistinctCountColumn ("teamCnt", "$isHomeTeamColumn = 1", $homeTeamColumn, $awayTeamColumn);
        $joins[] = $matchTable->createQuery ($columns, $joinCriteria, $matchJoins, $params);
        $criteria = array ();

        if (self::CARDS_PLAYER == $mode)
            {
            $personColumn = "f_".Sports::COL_EVENT_PLAYER."_".$personsTable->getIdColumn ();
            $joinCriteria = array (new JoinColumnsCriterion ($personColumn, $personsTable->getIdColumn ()));
            $params = NULL;
            $joins[] = $personsTable->createQuery (array ($personsTable->getIdColumn ()), $joinCriteria, NULL, $params);
            $criteria[] = new GtCriterion ($personColumn, 0);
            }

        $params = array ();

        $columns = array ();
        $columns[] = new ConditionalSumColumn (self::COL_YELLOW_COUNT, "c_".Sports::COL_EVENT_TYPE." = ".MatchConstants::EVENT_YELLOW, 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_YELLOWRED_COUNT, "c_".Sports::COL_EVENT_TYPE." = ".MatchConstants::EVENT_YELLOW_RED, 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_RED_COUNT, "c_".Sports::COL_EVENT_TYPE." = ".MatchConstants::EVENT_RED, 1, 0);

        if (self::CARDS_ALL == $mode)
            {
            $columns[] = new ConditionalSumColumn (self::COL_COUNT, "c_".Sports::COL_EVENT_TYPE." <> ".MatchConstants::EVENT_MISS, 1, 0);
            $columns[] = new ConditionalSumColumn (self::COL_MISS_COUNT, "c_".Sports::COL_EVENT_TYPE." = ".MatchConstants::EVENT_MISS, 1, 0);
            }
        else if (self::CARDS_PLAYER == $mode)
            {
            $params[] = new GroupBy (array ($personColumn));

            $columns[] = Sports::COL_EVENT_PLAYER.".".Sports::COL_PERSON_FIRST_NAME;
            $columns[] = Sports::COL_EVENT_PLAYER.".".Sports::COL_PERSON_SURNAME;
            if (!$invert)
                {
                $columns[] = new FunctionCount ("*", self::COL_COUNT);
                $params[] = OrderBy::createByAlias (self::COL_YELLOW_COUNT, false, 1, self::COL_COUNT, false, 2,
                                                    self::COL_RED_COUNT, false, 3, Sports::COL_EVENT_PLAYER, true, 4);
                $paramsCopy = $params;
                $params[] = new LimitByPage (0, 100);
                $params[] = new HavingCriteria (self::COL_COUNT." > 2");
                }
            else
                {
                $columns[] = new ConditionalSumColumn (self::COL_TOTAL_RED_COUNT, "c_".Sports::COL_EVENT_TYPE." IN (".MatchConstants::EVENT_YELLOW_RED.",".MatchConstants::EVENT_RED.")", 1, 0);
                $params[] = new HavingCriteria (self::COL_TOTAL_RED_COUNT." > 0");
                $params[] = OrderBy::createByAlias (self::COL_TOTAL_RED_COUNT, false, 1, self::COL_RED_COUNT, false, 2,
                                                    self::COL_YELLOW_COUNT, false, 3, Sports::COL_EVENT_PLAYER, true, 4);
                }
            }
        else if (self::CARDS_TEAM == $mode || self::CARDS_TEAM_AGAINST == $mode)
            {
            $columns[] = new FunctionCount ("*", self::COL_COUNT);
            $params[] = OrderBy::createByAlias (self::COL_COUNT, false, 1, self::COL_RED_COUNT, false, 2,
                                                self::COL_YELLOWRED_COUNT, false, 3, self::COL_YELLOW_COUNT, false, 4);
            }

        if (self::CARDS_ALL != $mode)
            $criteria[] = new InCriterion ("c_".Sports::COL_EVENT_TYPE, array (MatchConstants::EVENT_YELLOW, MatchConstants::EVENT_YELLOW_RED, MatchConstants::EVENT_RED));
        $rows = $eventsTable->selectBy ($columns, $criteria, $joins, $params);
        if (self::CARDS_PLAYER == $mode && !$invert && count ($rows) < 10)
            {
            // in case there are too little results to show, include all the cards (remove "having" part)
            $params = $paramsCopy;
            $params[] = new LimitByPage (0, 20);
            $rows = $eventsTable->selectBy ($columns, $criteria, $joins, $params);
            }

        if (empty ($rows))
            return $rows;

        if (self::CARDS_TEAM == $mode)
            {
            $teamIds = array ();
            foreach ($rows as &$row)
                {
                $teamIds[] = $row["team.id"];
                $row["c_".Sports::COL_TEAM_SHORTNAME] = $row["team.id"];
                $row[$teamsTable->getIdColumn ()] = $row["team.id"];
                }
            $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);

            foreach ($rows as &$row)
                {
                $teamId = $row["team.id"];
                if (array_key_exists ($teamId, $teamLabels))
                    $row["c_".Sports::COL_TEAM_SHORTNAME] = $teamLabels[$teamId];
               }
            }
        else
            {
            $lng = Language::getInstance ($this->context);
            $teamLabels = $this->collectTeamLabelsByMinMax ($teamsTable, $rows);

            foreach ($rows as &$row)
                {
                $row[self::COL_TEAM] = $this->guessPlayerTeamByMinMax ($teamsTable, $lng, $teamLabels, $row);
               }
            }

        return $rows;
        }

    protected function selectPlayerCardStatistics ($id, $yellow = true)
        {
        $rows = $this->selectRawCardStatistics ($id, self::CARDS_PLAYER, !$yellow);
        if (empty ($rows))
            return NULL;

        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        $results = array ();
        foreach ($rows as $row)
            {
            $result = NULL;
            $result[self::COL_YELLOW_COUNT] = $row[self::COL_YELLOW_COUNT];
            $result[self::COL_YELLOWRED_COUNT] = $row[self::COL_YELLOWRED_COUNT];
            $result[self::COL_RED_COUNT] = $row[self::COL_RED_COUNT];
            $name = array ();

            if (!empty ($row[Sports::COL_EVENT_PLAYER.".c_".Sports::COL_PERSON_FIRST_NAME]))
                $name[] = $row[Sports::COL_EVENT_PLAYER.".c_".Sports::COL_PERSON_FIRST_NAME];
            if (!empty ($row[Sports::COL_EVENT_PLAYER.".c_".Sports::COL_PERSON_SURNAME]))
                $name[] = $row[Sports::COL_EVENT_PLAYER.".c_".Sports::COL_PERSON_SURNAME];
            if (count ($name) < 2 && !empty ($row[Sports::COL_EVENT_PLAYER.".c_".Sports::COL_PERSON_FULL_NAME]))
                $name = array ($row[Sports::COL_EVENT_PLAYER.".c_".Sports::COL_PERSON_FULL_NAME]);

            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $personsTable,
                                                                         $personsTable->getId (),
                                                                         $row[$personsTable->getIdColumn ()]);
            $result[self::COL_PLAYER] = "<a href=\"$url\">".implode (" ", $name)."</a>";
            $result[self::COL_TEAM] = $row[self::COL_TEAM];
            $results[] = $result;
            }

        return $results;
        }

    protected function selectPlayerStatistics ($id, $mode)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $playersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHPLAYER);
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        if (empty ($matchTable) || empty ($playersTable) || empty ($personsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $joinCriteria = $this->createIdCriterion ($id, true, true);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $filterByTeam = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
        if (is_numeric ($filterByTeam))
            $joinCriteria[] = new FilterByTeamCriterion ($filterByTeam, "c_".Sports::COL_PLAYER_ISHOME);

        $joins[] = $matchTable->createQuery (array (), $joinCriteria);
        $criteria = array ();

        $params = array ();
        $personColumn = "f_".Sports::COL_PLAYER_PERSON."_".$personsTable->getIdColumn ();
        $substituteColumn = "f_".Sports::COL_PLAYER_SUBSTITUTED_BY."_".$personsTable->getIdColumn ();
        $leftColumn = "c_".Sports::COL_PLAYER_TO;
        $params[] = new GroupBy (array ($personColumn));

        $columns = array (Sports::COL_PLAYER_PERSON);
        $columns[] = new FunctionCount ("*", self::COL_GAMES_REGISTERED);
        $columns[] = new ConditionalSumColumn (self::COL_MINUTES, "c_".Sports::COL_PLAYER_FROM." IS NOT NULL AND c_".Sports::COL_PLAYER_TO." IS NOT NULL", "c_".Sports::COL_PLAYER_TO." - c_".Sports::COL_PLAYER_FROM, 0);
        $columns[] = new ConditionalSumColumn (self::COL_GAMES, "c_".Sports::COL_PLAYER_UNUSED."=0", 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_AS_SUBSTITUTE, "c_".Sports::COL_PLAYER_FROM.">0", 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_SUBSTITUTED, "$substituteColumn IS NOT NULL", 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_ON_BENCH, "c_".Sports::COL_PLAYER_UNUSED."=1", 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_FULL_MATCHES, "c_".Sports::COL_PLAYER_FROM."=0 AND $substituteColumn IS NULL AND ($leftColumn = 80 OR $leftColumn = 90 OR $leftColumn = 120)", 1, 0);

        $limit = 25;
        switch ($mode)
            {
            case self::PLAYERS_ALL:
                $limit = 0;
                $params[] = new HavingCriteria (self::COL_GAMES.">0");
                $params[] = OrderBy::createByAlias (self::COL_MINUTES, false, self::COL_GAMES, false, self::COL_GAMES_REGISTERED, false, Sports::COL_PLAYER_PERSON);
                break;
            case self::PLAYERS_BY_MINUTES:
                $params[] = OrderBy::createByAlias (self::COL_MINUTES, false, self::COL_GAMES, false, self::COL_GAMES_REGISTERED, false, Sports::COL_PLAYER_PERSON);
                break;
            case self::PLAYERS_BY_GAMES:
                $params[] = OrderBy::createByAlias (self::COL_GAMES, false, self::COL_MINUTES, false, self::COL_GAMES_REGISTERED, false, Sports::COL_PLAYER_PERSON);
                break;
            case self::PLAYERS_BY_GAMES_REG:
                $params[] = OrderBy::createByAlias (self::COL_GAMES_REGISTERED, false, self::COL_MINUTES, true, self::COL_GAMES, true, Sports::COL_PLAYER_PERSON);
                break;
            case self::PLAYERS_BY_MINUTES_DESC:
                $params[] = new HavingCriteria (self::COL_GAMES.">0");
                $params[] = OrderBy::createByAlias (self::COL_MINUTES, true, self::COL_GAMES, false, self::COL_GAMES_REGISTERED, false, Sports::COL_PLAYER_PERSON);
                break;
            case self::PLAYERS_UNUSED:
                $limit = 0;
                $params[] = new HavingCriteria (self::COL_GAMES."=0");
                $params[] = OrderBy::createByAlias (self::COL_GAMES_REGISTERED, false, 1, Sports::COL_PLAYER_PERSON);
                break;
            case self::PLAYERS_ON_BENCH:
                $params[] = OrderBy::createByAlias (self::COL_ON_BENCH, false, self::COL_MINUTES, true, self::COL_GAMES, true, Sports::COL_PLAYER_PERSON);
                break;
            case self::PLAYERS_SUBSTITUTED:
                $params[] = OrderBy::createByAlias (self::COL_SUBSTITUTED, false, self::COL_MINUTES, true, self::COL_GAMES, true, Sports::COL_PLAYER_PERSON);
                break;
            }

        if ($limit > 0)
            $params[] = new LimitByPage (0, $limit);

        $rows = $playersTable->selectBy ($columns, $criteria, $joins, $params);

        if (empty ($rows))
            return false;

        $results = array ();
        foreach ($rows as $row)
            {
            $result = NULL;
            $result[self::COL_GAMES] = $row[self::COL_GAMES];
            $result[self::COL_MINUTES] = $row[self::COL_MINUTES];
            $result[self::COL_GAMES_REGISTERED] = $row[self::COL_GAMES_REGISTERED];
            $result[self::COL_AS_SUBSTITUTE] = $row[self::COL_AS_SUBSTITUTE];
            $result[self::COL_SUBSTITUTED] = $row[self::COL_SUBSTITUTED];
            $result[self::COL_ON_BENCH] = $row[self::COL_ON_BENCH];
            $result[self::COL_FULL_MATCHES] = $row[self::COL_FULL_MATCHES];
            $name = array ();

            if (!empty ($row[Sports::COL_PLAYER_PERSON.".c_".Sports::COL_PERSON_FIRST_NAME]))
                $name[] = $row[Sports::COL_PLAYER_PERSON.".c_".Sports::COL_PERSON_FIRST_NAME];
            if (!empty ($row[Sports::COL_PLAYER_PERSON.".c_".Sports::COL_PERSON_SURNAME]))
                $name[] = $row[Sports::COL_PLAYER_PERSON.".c_".Sports::COL_PERSON_SURNAME];
            if (empty ($name) && !empty ($row[Sports::COL_PLAYER_PERSON.".c_".Sports::COL_PERSON_FULL_NAME]))
                $name[] = $row[Sports::COL_PLAYER_PERSON.".c_".Sports::COL_PERSON_FULL_NAME];

            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $personsTable,
                                                                         $personsTable->getId (),
                                                                         $row[$personColumn]);
            $result[self::COL_PLAYER] = "<a href=\"$url\">".implode (" ", $name)."</a>";
            $results[] = $result;
            }

        return $results;
        }

    protected function selectRefereeStatistics ($id, $refereeType)
        {
        $includeRating = false;
        if (NULL === $refereeType)
            {
            $refereeType = array (MatchConstants::REFEREE_PRIMARY);
            $includeRating = true;
            }

        $includeCards = (count ($refereeType) == 1 && $refereeType[0] == MatchConstants::REFEREE_PRIMARY);
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $refereeTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHREFEREE);
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        $eventsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHEVENT);
        if (empty ($matchTable) || empty ($refereeTable) || empty ($personsTable) || empty ($eventsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $matchJoins = NULL;
        if ($includeCards)
            {
            $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
            $joinCriteria[] = new LogicalOperatorOr (new InCriterion ("c_".Sports::COL_EVENT_TYPE, array (MatchConstants::EVENT_YELLOW, MatchConstants::EVENT_YELLOW_RED, MatchConstants::EVENT_RED)), new IsNullCriterion ("c_".Sports::COL_EVENT_TYPE));
            $columns[] = new ConditionalSumColumn (self::COL_YELLOW_COUNT, "c_".Sports::COL_EVENT_TYPE." = ".MatchConstants::EVENT_YELLOW, 1, 0);
            $columns[] = new ConditionalSumColumn (self::COL_YELLOWRED_COUNT, "c_".Sports::COL_EVENT_TYPE." = ".MatchConstants::EVENT_YELLOW_RED, 1, 0);
            $columns[] = new ConditionalSumColumn (self::COL_RED_COUNT, "c_".Sports::COL_EVENT_TYPE." = ".MatchConstants::EVENT_RED, 1, 0);
            $join = $eventsTable->createQuery ($columns, $joinCriteria);
            $join->joinType = Constants::JOIN_LEFT_OUTER;
            $matchJoins[] = $join;
            }
        
        $joinCriteria = $this->createIdCriterion ($id);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $matchColumns = array ();
        $matchColumns[] = new FunctionMin ("c_".Sports::COL_MATCH_DATE, self::COL_FIRST_MATCH);
        $matchColumns[] = new FunctionMax ("c_".Sports::COL_MATCH_DATE, self::COL_LAST_MATCH);
        $joins[] = $matchTable->createQuery ($matchColumns, $joinCriteria, $matchJoins);
        $criteria = array ();

        $criteria = array ();
        $criteria[] = new InCriterion ("f_".Sports::COL_REFEREE_TYPE."_".Sports::TABLE_REFEREETYPE."_id", $refereeType);

        $params = array ();
        $personColumn = "f_".Sports::COL_REFEREE_PERSON."_".$personsTable->getIdColumn ();
        $params[] = new GroupBy (array ($personColumn));
        $params[] = OrderBy::createByAlias (self::COL_GAMES, false, 1, Sports::COL_REFEREE_PERSON);

        $columns = array (Sports::COL_REFEREE_PERSON);
        $columns[] = new FunctionDistinctCount ($matchTable->getIdColumn (), self::COL_GAMES);
        
        $rows = $refereeTable->selectBy ($columns, $criteria, $joins, $params);

        if (empty ($rows))
            return false;

        $refereeRatings = array ();
        if ($includeRating)
            {
            $joins = array ($matchTable->createQuery (array (), $joinCriteria));
            $columns[] = new ConditionalSumColumn ("homeSum", "c_".Sports::COL_REFEREE_RATED_BY_HOME." > 0", "c_".Sports::COL_REFEREE_RATED_BY_HOME, 0);
            $columns[] = new ConditionalSumColumn ("homeCnt", "c_".Sports::COL_REFEREE_RATED_BY_HOME." > 0", 1, 0);
            $columns[] = new ConditionalSumColumn ("awaySum", "c_".Sports::COL_REFEREE_RATED_BY_AWAY." > 0", "c_".Sports::COL_REFEREE_RATED_BY_AWAY, 0);
            $columns[] = new ConditionalSumColumn ("awayCnt", "c_".Sports::COL_REFEREE_RATED_BY_AWAY." > 0", 1, 0);
            $ratingRows = $refereeTable->selectBy ($columns, $criteria, $joins, $params);

            if (!empty ($ratingRows))
                {
                foreach ($ratingRows as $row)
                    {
                    if ($row["homeCnt"] + $row["awayCnt"] > 0)
                        $refereeRatings[$row[$personColumn]] = $result["rating"] = ($row["homeSum"] + $row["awaySum"]) / ($row["homeCnt"] + $row["awayCnt"]);
                    }
                }
            }

        $results = array ();
        foreach ($rows as $row)
            {
            $result = NULL;
            $result[self::COL_GAMES] = $row[self::COL_GAMES];
            if (!empty ($row[self::COL_FIRST_MATCH]))
                $result[self::COL_FIRST_MATCH] = $this->lng->dateToLongString ($row[self::COL_FIRST_MATCH], "day");
            if (!empty ($row[self::COL_LAST_MATCH]))
                $result[self::COL_LAST_MATCH] = $this->lng->dateToLongString ($row[self::COL_LAST_MATCH], "day");

            if ($includeCards)
                {
                $result[self::COL_YELLOW_COUNT] = $row[self::COL_YELLOW_COUNT];
                $result[self::COL_YELLOWRED_COUNT] = $row[self::COL_YELLOWRED_COUNT];
                $result[self::COL_RED_COUNT] = $row[self::COL_RED_COUNT];
                $result[self::COL_COUNT] = $result[self::COL_YELLOW_COUNT] + $result[self::COL_YELLOWRED_COUNT] + $result[self::COL_RED_COUNT];
                $result[self::COL_AVG_COUNT] = $this->lng->decimalToString ($result[self::COL_COUNT] / $row[self::COL_GAMES], 2);

                if (array_key_exists ($row[$personColumn], $refereeRatings))
                    {
                    $result["rating"] = $refereeRatings[$row[$personColumn]];
                    $result[self::COL_REF_EVAL] = $this->lng->decimalToString ($result["rating"], 2);
                    }
                else
                    {
                    $result[self::COL_REF_EVAL] = NULL;
                    $result["rating"] = 0;
                    }
                }

            $name = array ();

            if (!empty ($row[Sports::COL_REFEREE_PERSON.".c_".Sports::COL_PERSON_FIRST_NAME]))
                $name[] = $row[Sports::COL_REFEREE_PERSON.".c_".Sports::COL_PERSON_FIRST_NAME];
            if (!empty ($row[Sports::COL_REFEREE_PERSON.".c_".Sports::COL_PERSON_SURNAME]))
                $name[] = $row[Sports::COL_REFEREE_PERSON.".c_".Sports::COL_PERSON_SURNAME];
            if (empty ($name) && !empty ($row[Sports::COL_REFEREE_PERSON.".c_".Sports::COL_PERSON_FULL_NAME]))
                $name[] = $row[Sports::COL_REFEREE_PERSON.".c_".Sports::COL_PERSON_FULL_NAME];

            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $personsTable,
                                                                         $personsTable->getId (),
                                                                         $row[$personColumn]);
            $result[self::COL_REFEREE] = "<a href=\"$url\">".implode (" ", $name)."</a>";
            $results[] = $result;
            }

        if ($includeRating)
            uasort ($results, array($this, "compareByRating"));

        return $results;
        }

    protected function compareByRating ($a, $b)
        {
        return $b["rating"] > $a["rating"] ? 1 : ($b["rating"] < $a["rating"] ? -1 : 0);
        }

    protected function selectTeamCardStatistics ($id, $invert = true)
        {
        $rows = $this->selectRawCardStatistics ($id, self::CARDS_TEAM, $invert);
        if (empty ($rows))
            return NULL;

        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $results = array ();
        foreach ($rows as $row)
            {
            $result = NULL;
            $result[self::COL_YELLOW_COUNT] = $row[self::COL_YELLOW_COUNT];
            $result[self::COL_YELLOWRED_COUNT] = $row[self::COL_YELLOWRED_COUNT];
            $result[self::COL_RED_COUNT] = $row[self::COL_RED_COUNT];

            $name = $row["c_".Sports::COL_TEAM_SHORTNAME];
            if (empty ($name))
                $result[self::COL_TEAM] = $this->getText ("Unknown");
            else
                {
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                             $teamsTable->getId (),
                                                                             $row[$teamsTable->getIdColumn ()]);
                $result[self::COL_TEAM] = "<a href=\"$url\">$name</a>";
                }

            $results[] = $result;
            }

        return $results;
        }

    protected function selectTeamPlayerStatistics ($id, $invert = false)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $playersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHPLAYER);
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        if (empty ($matchTable) || empty ($teamsTable) || empty ($playersTable) || empty ($personsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $joinCriteria = $this->createIdCriterion ($id, true, false);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $filterByTeam = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
        if (is_numeric ($filterByTeam))
            $joinCriteria[] = new FilterByTeamCriterion ($filterByTeam, "c_".Sports::COL_PLAYER_ISHOME);
        $joins[] = $matchTable->createQuery (array (), $joinCriteria);
        $criteria = array ();

        $params = array ();
        $columns = array ();
        $personColumn = "f_".Sports::COL_PLAYER_PERSON."_".$personsTable->getIdColumn ();
        $homeTeamColumn = "f_".Sports::COL_MATCH_HOMETEAM."_".$teamsTable->getIdColumn ();
        $awayTeamColumn = "f_".Sports::COL_MATCH_AWAYTEAM."_".$teamsTable->getIdColumn ();
        $isHomeCondition = "c_".Sports::COL_PLAYER_ISHOME."=".($invert ? 0 : 1);

        $columns[] = new FunctionDistinctCount ($personColumn, self::COL_DISTINCT_REGISTERED);
        $columns[] = new FunctionDistinctCount ("(case WHEN c_".Sports::COL_PLAYER_UNUSED."=0 THEN $personColumn ELSE 0 END)", self::COL_DISTINCT_PLAYED);
        $columns[] = new FunctionDistinctCount ($matchTable->getIdColumn (), self::COL_DISTINCT_MATCHES);
        $columns[] = new ConditionalSumColumn (self::COL_SUBSTITUTED, "c_".Sports::COL_PLAYER_UNUSED."=1", 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_ON_BENCH, "c_".Sports::COL_PLAYER_UNUSED."=1", 1, 0);
        $columns[] = new ConditionalResultColumn ("teamid", $isHomeCondition, $homeTeamColumn, $awayTeamColumn);
        $columns[] = new FunctionCount ("*", self::COL_COUNT);

        $params[] = OrderBy::createByAlias (self::COL_COUNT, false, "teamid", true);
        $params[] = new GroupBy (array ("(case WHEN $isHomeCondition THEN $homeTeamColumn ELSE $awayTeamColumn END)"));
        $rows = $playersTable->selectBy ($columns, $criteria, $joins, $params);
        if (empty ($rows))
            return false;

        $teamIds = array ();
        foreach ($rows as $row)
            $teamIds[] = $row["teamid"];
        $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);

        foreach ($rows as $row)
            {
            $result = NULL;
            $result[self::COL_COUNT] = $this->lng->decimalToString ($row[self::COL_COUNT] / $row[self::COL_DISTINCT_MATCHES], 2);
            $result[self::COL_DISTINCT_REGISTERED] = $row[self::COL_DISTINCT_REGISTERED];
            $result[self::COL_DISTINCT_PLAYED] = $row[self::COL_DISTINCT_PLAYED] - ($row[self::COL_ON_BENCH] > 0 ? 1 : 0);
            $result[self::COL_SUBSTITUTED] = $this->lng->decimalToString (($row[self::COL_COUNT] - $row[self::COL_ON_BENCH]) / $row[self::COL_DISTINCT_MATCHES] - 11, 2);
            $result[self::COL_ON_BENCH] = $this->lng->decimalToString ($row[self::COL_ON_BENCH] / $row[self::COL_DISTINCT_MATCHES], 2);
            
            $teamId = $row["teamid"];
            if (empty ($teamLabels[$teamId]))
                $result[self::COL_TEAM] = $this->getText ("Unknown");
            else
                {
                $name = $teamLabels[$teamId];
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                             $teamsTable->getId (),
                                                                             $teamId);
                $result[self::COL_TEAM] = "<a href=\"$url\">$name</a>";
                }

            $results[] = $result;
            }

        return $results;
        }

    protected function selectTeamPlayersWithAge ($id, $oldest)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $playersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHPLAYER);
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        if (empty ($matchTable) || empty ($teamsTable) || empty ($playersTable) || empty ($personsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $personColumn = "f_".Sports::COL_PLAYER_PERSON."_".$personsTable->getIdColumn ();
        $homeTeamColumn = "f_".Sports::COL_MATCH_HOMETEAM."_".$teamsTable->getIdColumn ();
        $awayTeamColumn = "f_".Sports::COL_MATCH_AWAYTEAM."_".$teamsTable->getIdColumn ();
        $isHomeCondition = "c_".Sports::COL_PLAYER_ISHOME."=1";
            
        // need to join match table (to add competition criteria)
        $columns = array ();
        $joinCriteria = $this->createIdCriterion ($id, true, false);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $filterByTeam = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
        if (is_numeric ($filterByTeam))
            $joinCriteria[] = new FilterByTeamCriterion ($filterByTeam, "c_".Sports::COL_PLAYER_ISHOME);
        $columns[] = new FunctionMin ("c_".Sports::COL_MATCH_DATE, self::COL_FIRST_MATCH);
        $columns[] = new FunctionMax ("c_".Sports::COL_MATCH_DATE, self::COL_LAST_MATCH);
        $columns[] = new FunctionCount ($matchTable->getIdColumn (), self::COL_COUNT);

        $joinCriteria[] = new DayIsNotEmptyCriteria ("c_".Sports::COL_MATCH_DATE);
        $joins[] = $matchTable->createQuery ($columns, $joinCriteria);

        // also join persons table (to retrieve birthday information)
        $joinCriteria = NULL;
        $joinCriteria[] = new JoinColumnsCriterion ($personColumn, $personsTable->getIdColumn ());
        $columns = array ();
        $columns[] = true === $oldest
                        ? new FunctionMax ("DATEDIFF(c_".Sports::COL_MATCH_DATE.", c_".Sports::COL_PERSON_BIRTHDATE.")", self::COL_MIN_AGE)
                        : new FunctionMin ("DATEDIFF(c_".Sports::COL_MATCH_DATE.", c_".Sports::COL_PERSON_BIRTHDATE.")", self::COL_MIN_AGE);
        $columns[] = Sports::COL_PERSON_FIRST_NAME;
        $columns[] = Sports::COL_PERSON_SURNAME;
        $columns[] = Sports::COL_PERSON_BIRTHDATE;
        $columns[] = $personsTable->getIdColumn ();
        if (false === $oldest)
            $joinCriteria[] = new DayIsNotEmptyCriteria ("c_".Sports::COL_PERSON_BIRTHDATE);
        $joins[] = $personsTable->createQuery ($columns, $joinCriteria);

        $criteria = array ();
        $criteria[] = new EqCriterion (Sports::COL_PLAYER_UNUSED, 0);

        $params = array ();
        $columns = array ();

        $columns[] = new FunctionDistinctCount ($matchTable->getIdColumn (), self::COL_DISTINCT_MATCHES);
        $columns[] = new ConditionalResultColumn ("teamid", $isHomeCondition, $homeTeamColumn, $awayTeamColumn);
        $columns[] = new FunctionCount ("*", self::COL_COUNT);

        $params[] = OrderBy::createByAlias (self::COL_MIN_AGE, !$oldest, "teamid", true);
        $params[] = new GroupBy (array ("(case WHEN $isHomeCondition THEN $homeTeamColumn ELSE $awayTeamColumn END)", $personColumn));
        if (NULL !== $oldest)
            $params[] = new LimitByPage (0, 50);

        $rows = $playersTable->selectBy ($columns, $criteria, $joins, $params);
        if (empty ($rows))
            return false;

        $teamIds = array ();
        foreach ($rows as $row)
            $teamIds[] = $row["teamid"];
        $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);
        
        foreach ($rows as $row)
            {
            $result = NULL;
            $maxAge = $this->getAgeDiff ($this->context, $row[self::COL_LAST_MATCH], $row["c_".Sports::COL_PERSON_BIRTHDATE]);
            $minAge = $this->getAgeDiff ($this->context, $row[self::COL_FIRST_MATCH], $row["c_".Sports::COL_PERSON_BIRTHDATE]);
            $result[self::COL_BIRTH_DATE] = empty ($row["c_".Sports::COL_PERSON_BIRTHDATE]) ? $this->getText ("Unknown") : $this->lng->dateToLongString ($row["c_".Sports::COL_PERSON_BIRTHDATE]);
            $firstMatch = empty ($row[self::COL_FIRST_MATCH]) ? "?" : $this->lng->dateToLongString ($row[self::COL_FIRST_MATCH], "day");
            $lastMatch = empty ($row[self::COL_LAST_MATCH]) ? "?" : $this->lng->dateToLongString ($row[self::COL_LAST_MATCH], "day");
            $result[self::COL_FIRST_MATCH] = "<span style=\"white-space:nowrap;\">$firstMatch</span><br/>($minAge)";
            $result[self::COL_LAST_MATCH] = "<span style=\"white-space:nowrap;\">$lastMatch</span><br/>($maxAge)";
            $result[self::COL_COUNT] = $row[self::COL_COUNT];

            $name = array ();
            if (!empty ($row["c_".Sports::COL_PERSON_FIRST_NAME]))
                $name[] = $row["c_".Sports::COL_PERSON_FIRST_NAME];
            if (!empty ($row["c_".Sports::COL_PERSON_SURNAME]))
                $name[] = $row["c_".Sports::COL_PERSON_SURNAME];
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $personsTable,
                                                                         $personsTable->getId (),
                                                                         $row[$personsTable->getIdColumn ()]);
            $result[self::COL_PLAYER] = "<a href=\"$url\">".implode (" ", $name)."</a>";
            
            $teamId = $row["teamid"];
            if (empty ($teamLabels[$teamId]))
                $result[self::COL_TEAM] = $this->getText ("Unknown");
            else
                {
                $name = $teamLabels[$teamId];
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                             $teamsTable->getId (),
                                                                             $teamId);
                $result[self::COL_TEAM] = "<a href=\"$url\">$name</a>";
                }

            $results[] = $result;
            }

        return $results;
        }

    protected function selectTeamPlayerAgeStatistics ($id, $invert = false)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $playersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHPLAYER);
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        if (empty ($matchTable) || empty ($teamsTable) || empty ($playersTable) || empty ($personsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $personColumn = "f_".Sports::COL_PLAYER_PERSON."_".$personsTable->getIdColumn ();
        $homeTeamColumn = "f_".Sports::COL_MATCH_HOMETEAM."_".$teamsTable->getIdColumn ();
        $awayTeamColumn = "f_".Sports::COL_MATCH_AWAYTEAM."_".$teamsTable->getIdColumn ();
        $isHomeCondition = "c_".Sports::COL_PLAYER_ISHOME."=".($invert ? 0 : 1);
            
        // need to join match table (to add competition criteria)
        $joinCriteria = $this->createIdCriterion ($id, true, false);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $filterByTeam = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
        if (is_numeric ($filterByTeam))
            $joinCriteria[] = new FilterByTeamCriterion ($filterByTeam, "c_".Sports::COL_PLAYER_ISHOME);
        $joins[] = $matchTable->createQuery (array (), $joinCriteria);

        // also join persons table (to retrieve birthday information)
        $joinCriteria = NULL;
        $joinCriteria[] = new JoinColumnsCriterion ($personColumn, $personsTable->getIdColumn ());
        $columns = array ();
        $columns[] = new FunctionMax ("DATEDIFF(c_".Sports::COL_MATCH_DATE.", c_".Sports::COL_PERSON_BIRTHDATE.")", self::COL_MAX_AGE);
        $columns[] = new FunctionMin ("DATEDIFF(c_".Sports::COL_MATCH_DATE.", c_".Sports::COL_PERSON_BIRTHDATE.")", self::COL_MIN_AGE);
        $columns[] = new FunctionAvg ("DATEDIFF(c_".Sports::COL_MATCH_DATE.", c_".Sports::COL_PERSON_BIRTHDATE.")", self::COL_AVG_AGE);
        $columns[] = new ConditionalSumColumn ("missingDate", "c_".Sports::COL_PERSON_BIRTHDATE." IS NULL OR DAY(c_".Sports::COL_PERSON_BIRTHDATE.") = 0", 1, 0);
        $joins[] = $personsTable->createQuery ($columns, $joinCriteria);

        $criteria = array ();
        $criteria[] = new EqCriterion (Sports::COL_PLAYER_UNUSED, 0);

        $params = array ();
        $columns = array ();

        $columns[] = new FunctionDistinctCount ($matchTable->getIdColumn (), self::COL_DISTINCT_MATCHES);
        $columns[] = new ConditionalResultColumn ("teamid", $isHomeCondition, $homeTeamColumn, $awayTeamColumn);
        $columns[] = new FunctionCount ("*", self::COL_COUNT);

        $params[] = OrderBy::createByAlias ("avgAge", true, "teamid", true);
        $params[] = new GroupBy (array ("(case WHEN $isHomeCondition THEN $homeTeamColumn ELSE $awayTeamColumn END)"));
        $rows = $playersTable->selectBy ($columns, $criteria, $joins, $params);
        if (empty ($rows))
            return false;

        $teamIds = array ();
        foreach ($rows as $row)
            $teamIds[] = $row["teamid"];
        $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);
        
        foreach ($rows as $row)
            {
            $result = NULL;
            if ($row["missingDate"])
                $result[self::COL_RELIABILITY] =  $this->getText ("Missing [_0] %",
                                                                  $this->lng->decimalToString ($row["missingDate"] / $row[self::COL_COUNT] * 100, 2));
            else
                $result[self::COL_RELIABILITY] =  $this->getText ("reliable");
            $result[self::COL_MAX_AGE] = $this->getAgeLabel ($this->context, $row[self::COL_MAX_AGE]);
            $result[self::COL_MIN_AGE] = $this->getAgeLabel ($this->context, $row[self::COL_MIN_AGE]);
            $result[self::COL_AVG_AGE] = $this->lng->decimalToString ($row[self::COL_AVG_AGE] / 365.2425, 2);
            
            $teamId = $row["teamid"];
            if (empty ($teamLabels[$teamId]))
                $result[self::COL_TEAM] = $this->getText ("Unknown");
            else
                {
                $name = $teamLabels[$teamId];
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                             $teamsTable->getId (),
                                                                             $teamId);
                $result[self::COL_TEAM] = "<a href=\"$url\">$name</a>";
                }

            $results[] = $result;
            }

        return $results;
        }

    protected function groupHomeAndAway ($rowsHome, $homeTeamColumn, $rowsAway, $awayTeamColumn, $columns)
        {
        $result = array ();
        foreach (array ("home" => array ($rowsHome, $homeTeamColumn),
                        "away" => array ($rowsAway, $awayTeamColumn)) as $key => $val)
            {
            list ($rows, $teamIdColumn) = $val;
            foreach ($rows as $row)
                {
                $teamId = $row[$teamIdColumn];
                if (!array_key_exists ($teamId, $result))
                    {
                    $result[$teamId] = array ("teamid" => $teamId);
                    foreach ($columns as $column)
                        {
                        $result[$teamId][$column] = 0;
                        $result[$teamId][$column."_home"] = 0;
                        $result[$teamId][$column."_away"] = 0;
                        }
                    }

                foreach ($columns as $column)
                    {
                    $result[$teamId][$column."_".$key] += $row[$column];
                    $result[$teamId][$column] += $row[$column];
                    }
                }
            }

        return $result;
        }

    protected function selectTeamGoalStatistics ($id)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        if (empty ($matchTable) || empty ($teamsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $teamsTable->getIdColumn ());
        $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $teamsTable->getIdColumn ());
            
        $criteria = $this->createIdCriterion ($id);
        $columns = array ($homeTeamColumn);
        $columns[] = new FunctionSum ("c_".Sports::COL_MATCH_HOMERESULT, self::COL_SCORED);
        $columns[] = new FunctionSum ("c_".Sports::COL_MATCH_AWAYRESULT, self::COL_CONCEDED);
        $columns[] = new FunctionCount ("*", self::COL_COUNT);
        $params[] = new GroupBy (array ($homeTeamColumn));
        $rowsHome = $matchTable->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rowsHome))
            return false;

        $columns = array ($awayTeamColumn);
        $columns[] = new FunctionSum ("c_".Sports::COL_MATCH_HOMERESULT, self::COL_CONCEDED);
        $columns[] = new FunctionSum ("c_".Sports::COL_MATCH_AWAYRESULT, self::COL_SCORED);
        $columns[] = new FunctionCount ("*", self::COL_COUNT);
        $params = array (new GroupBy (array ($awayTeamColumn)));
        $rowsAway = $matchTable->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rowsHome))
            return false;

        $rows = $this->groupHomeAndAway ($rowsHome, $homeTeamColumn, $rowsAway, $awayTeamColumn,
                                         array (self::COL_COUNT, self::COL_SCORED, self::COL_CONCEDED));
        $rowsAway = $rowsHome = NULL;

        $teamIds = array_keys ($rows);
        $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);
        $teamParents = SportsHelper::getTeamTypesAndParents ($teamsTable, $teamIds);
        $clubTeams = array ();

        // map club ids to team ids (to check if there are teams of same club)
        foreach ($teamParents as $teamId => $val)
            {
            list ($type, $clubId) = $val;
            if (empty ($clubId))
                continue;
            $clubTeams[$type."#".$clubId][] = $teamId;
            }

        foreach ($clubTeams as $clubKey => $clubTeamIds)
            {
            if (count ($clubTeamIds) <= 1)
                continue;

            $labels = NULL;
            $newRow = NULL;
            foreach ($clubTeamIds as $teamId)
                {
                if (!empty ($teamLabels[$teamId]))
                    $labels[] = $teamLabels[$teamId];
                if (empty ($newRow))
                    $newRow = $rows[$teamId];
                else
                    {
                    foreach ($rows[$teamId] as $key => $val)
                        {
                        if ("teamid" == $key)
                            continue;
                        $newRow[$key] += $val;
                        }
                    }

                unset ($rows[$teamId]);
                }
            $newRow["teamid"] = $clubKey;
            $teamLabels[$clubKey] = implode (", ", $labels);
            $rows[$clubKey] = $newRow;
            }

        $totalsRow = NULL;
        foreach ($rows as $row)
            {
            $result = $row;
            
            if (empty ($totalsRow))
                {
                $totalsRow = $row;
                $totalsRow[self::COL_TEAM] = $this->getText ("Total:");
                }
            else
                {
                foreach ($row as $key => $val)
                    {
                    if ("teamid" == $key)
                        continue;
                    $totalsRow[$key] += $val;
                    }
                }

            $teamId = $row["teamid"];
            if (empty ($teamLabels[$teamId]))
                $result[self::COL_TEAM] = $this->getText ("Unknown");
            else
                {
                $name = $teamLabels[$teamId];
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                             $teamsTable->getId (),
                                                                             $teamId);
                $result[self::COL_TEAM] = "<a href=\"$url\">$name</a>";
                }

            $results[] = $result;
            }

        uasort ($results, array("CompetitionSeasonStats", "compareByTeamGoals"));

        if (count ($results) > 1 && !empty ($totalsRow))
            $results[] = $totalsRow;
        return $results;
        }

    static function compareByTeamGoals ($a, $b)
        {
        if ($a[self::COL_SCORED] != $b[self::COL_SCORED])
            return $b[self::COL_SCORED] - $a[self::COL_SCORED];
        if ($a[self::COL_CONCEDED] != $b[self::COL_CONCEDED])
            return $a[self::COL_CONCEDED] - $b[self::COL_CONCEDED];

        return $b[self::COL_COUNT] - $a[self::COL_COUNT];
        }

    protected function selectTeamGoalAgeStatistics ($id, $invert = false)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $goalsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHGOAL);
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        if (empty ($matchTable) || empty ($teamsTable) || empty ($goalsTable) || empty ($personsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $personColumn = "f_".Sports::COL_GOAL_SCORER."_".$personsTable->getIdColumn ();
        $homeTeamColumn = "f_".Sports::COL_MATCH_HOMETEAM."_".$teamsTable->getIdColumn ();
        $awayTeamColumn = "f_".Sports::COL_MATCH_AWAYTEAM."_".$teamsTable->getIdColumn ();
        $isHomeCondition = "c_".Sports::COL_GOAL_HOME."=".($invert ? 0 : 1);
            
        // need to join match table (to add competition criteria)
        $joinCriteria = $this->createIdCriterion ($id, true, false);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $filterByTeam = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
        if (is_numeric ($filterByTeam))
            $joinCriteria[] = new FilterByTeamCriterion ($filterByTeam, "c_".Sports::COL_GOAL_HOME);
        $joins[] = $matchTable->createQuery (array (), $joinCriteria);

        // also join persons table (to retrieve birthday information)
        $joinCriteria = NULL;
        $joinCriteria[] = new JoinColumnsCriterion ($personColumn, $personsTable->getIdColumn ());
        $columns = array ();
        $columns[] = new FunctionMax ("DATEDIFF(c_".Sports::COL_MATCH_DATE.", c_".Sports::COL_PERSON_BIRTHDATE.")", self::COL_MAX_AGE);
        $columns[] = new FunctionMin ("DATEDIFF(c_".Sports::COL_MATCH_DATE.", c_".Sports::COL_PERSON_BIRTHDATE.")", self::COL_MIN_AGE);
        $columns[] = new FunctionAvg ("DATEDIFF(c_".Sports::COL_MATCH_DATE.", c_".Sports::COL_PERSON_BIRTHDATE.")", self::COL_AVG_AGE);
        $columns[] = new ConditionalSumColumn ("missingDate", "c_".Sports::COL_PERSON_BIRTHDATE." IS NULL OR DAY(c_".Sports::COL_PERSON_BIRTHDATE.") = 0", 1, 0);
        $joins[] = $personsTable->createQuery ($columns, $joinCriteria);

        $criteria = array ();
        $criteria[] = new EqCriterion (Sports::COL_GOAL_OWN, 0);

        $params = array ();
        $columns = array ();

        $columns[] = new FunctionDistinctCount ($matchTable->getIdColumn (), self::COL_DISTINCT_MATCHES);
        $columns[] = new ConditionalResultColumn ("teamid", $isHomeCondition, $homeTeamColumn, $awayTeamColumn);
        $columns[] = new FunctionCount ("*", self::COL_COUNT);

        $params[] = OrderBy::createByAlias ("avgAge", true, "teamid", true);
        $params[] = new GroupBy (array ("(case WHEN $isHomeCondition THEN $homeTeamColumn ELSE $awayTeamColumn END)"));
        $rows = $goalsTable->selectBy ($columns, $criteria, $joins, $params);

        if (empty ($rows))
            return false;

        $teamIds = array ();
        foreach ($rows as $row)
            $teamIds[] = $row["teamid"];
        $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);
        
        foreach ($rows as $row)
            {
            $result = NULL;
            if ($row["missingDate"])
                $result[self::COL_RELIABILITY] =  $this->getText ("Missing [_0] %",
                                                                  $this->lng->decimalToString ($row["missingDate"] / $row[self::COL_COUNT] * 100, 2));
            else
                $result[self::COL_RELIABILITY] =  $this->getText ("reliable");
            $result[self::COL_MAX_AGE] = $this->getAgeLabel ($this->context, $row[self::COL_MAX_AGE]);
            $result[self::COL_MIN_AGE] = $this->getAgeLabel ($this->context, $row[self::COL_MIN_AGE]);
            $result[self::COL_AVG_AGE] = $this->lng->decimalToString ($row[self::COL_AVG_AGE] / 365.2425, 2);
            
            $teamId = $row["teamid"];
            if (empty ($teamLabels[$teamId]))
                $result[self::COL_TEAM] = $this->getText ("Unknown");
            else
                {
                $name = $teamLabels[$teamId];
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                             $teamsTable->getId (),
                                                                             $teamId);
                $result[self::COL_TEAM] = "<a href=\"$url\">$name</a>";
                }

            $results[] = $result;
            }

        return $results;
        }

    public static function getAgeLabel ($context, $age)
        {
        $yearLength = 365.2425;
        $years = floor ($age / $yearLength);
        $days = $age - $years * $yearLength;
        if ($days >= round ($yearLength))
            {
            $years++;
            $days = 0;
            }
        $yearsLabel = $context->ngettext ("[_0] yr.|s", "[_0] yr.|p", $years);
        if (0 == $days)
            return $yearsLabel;
        $daysLabel = $context->ngettext ("[_0] day", "[_0] days", round ($days));
        return $context->getText ("[_0] [_1]|years days", $yearsLabel, $daysLabel);
        }

    public static function getAgeDiff ($context, $age1, $age2)
        {
        if (strlen ($age2) < strlen ("2009-09-09"))
            return $context->getText ("Unknown");
        list ($year2, $month2, $day2) = sscanf ($age2, "%d-%d-%d");
        if (0 == $month2 || 0 == $day2)
            return $context->getText ("Unknown");

        list ($year1, $month1, $day1) = sscanf ($age1, "%d-%d-%d");
        // strtotime does not handle dates prior 13 Dec 1901 20:45:54 UTC, so avoid it
        $targetTimestamp = strtotime ($age1);

        $years = $year1-$year2;
        $year2 = $year1;

        if ($month2 > $month1 || ($month2 == $month1 && $day2 > $day1))
            {
            $years--;
            $year2--;
            }

        $curentlyAt = strtotime ("$year2".substr ($age2, 4));

        $days = ($targetTimestamp - $curentlyAt) / (24 * 60 * 60);
        $yearsLabel = $context->ngettext ("[_0] yr.|singular", "[_0] yr.|plural", $years);
        if (0 == $days)
            return $yearsLabel;
        $daysLabel = $context->ngettext ("[_0] day", "[_0] days", round ($days));
        return $context->getText ("[_0] [_1]|years days", $yearsLabel, $daysLabel);
        return date ("Y-m-d", $curentlyAt);
        }

    protected function selectRefereeCardTypeStatistics ($id, $sortByReferee)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        $refereeTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHREFEREE);
        $eventsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHEVENT);
        if (empty ($matchTable) || empty ($personsTable) || empty ($eventsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $columns = array ();
        $matchJoins = NULL;
        $params = array ();
        $refIdColumn = "f_".Sports::COL_REFEREE_PERSON."_".$personsTable->getIdColumn ();
        $matchIdColumn = "f_".Sports::COL_REFEREE_PERSON."_".$personsTable->getIdColumn ();
        $params[] = new GroupBy (array ($refIdColumn));
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $joinCriteria[] = new EqCriterion ("f_".Sports::COL_REFEREE_TYPE."_".Sports::TABLE_REFEREETYPE."_id", MatchConstants::REFEREE_PRIMARY);
        $matchJoins[] = $refereeTable->createQuery (array ($refIdColumn), $joinCriteria, NULL, $params);
        $params = NULL;

        $joinCriteria = $this->createIdCriterion ($id);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $joins[] = $matchTable->createQuery (array (), $joinCriteria, $matchJoins);
        $criteria = array ();

        $params[] = new GroupBy (array ("c_".Sports::COL_EVENT_CAUSE));

        $columns[] = Sports::COL_EVENT_CAUSE;
        $columns[] = new FunctionCount ("*", self::COL_COUNT);
        
        if ($sortByReferee)
            $params[] = OrderBy::createByAlias ($refIdColumn, true, 1, self::COL_COUNT, false, 2, "c_".Sports::COL_EVENT_CAUSE, true, 3);
        else
            $params[] = OrderBy::createByAlias ("c_".Sports::COL_EVENT_CAUSE, true, 1, self::COL_COUNT, false, 2, $refIdColumn, true, 3);

        $criteria[] = new InCriterion ("c_".Sports::COL_EVENT_TYPE, array (MatchConstants::EVENT_YELLOW, MatchConstants::EVENT_YELLOW_RED, MatchConstants::EVENT_RED));
        $rows = $eventsTable->selectBy ($columns, $criteria, $joins, $params);
        if (empty ($rows))
            return false;

        $refIds = array ();
        $totalCount = 0;
        foreach ($rows as $row)
            {
            $totalCount += $row[self::COL_COUNT];
            $refIds[] = $row[$refIdColumn];
            }

        $personLabels = SportsHelper::getPlayerLabels ($personsTable, $refIds);
        $refTotals = array ();

        if ($sortByReferee)
            {
            foreach ($rows as $row)
                {
                $refId = $row[$refIdColumn];
                if (empty ($refTotals[$refId]))
                    $refTotals[$refId] = 0;

                $refTotals[$refId] += $row[self::COL_COUNT];
                }
            }

        $causeColumn = $eventsTable->findColumn (Sports::COL_EVENT_CAUSE);
        $unknownCount = 0;
        foreach ($rows as $row)
            {
            $result = NULL;
            $result[self::COL_CAUSE] = NamedIntColumn::getItem ($causeColumn, $row["c_".Sports::COL_EVENT_CAUSE]);
            if (empty ($result[self::COL_CAUSE]))
                {
                $unknownCount += $row[self::COL_COUNT];
                continue;
                }

            if ($row[self::COL_COUNT] < 1)
                continue;

            $result[self::COL_COUNT] = $row[self::COL_COUNT];
            if ($sortByReferee)
                $result[self::COL_PERCENT] = $this->lng->decimalToString ($row[self::COL_COUNT] / $refTotals[$row[$refIdColumn]] * 100, 1);

            if (empty ($personLabels[$row[$refIdColumn]]))
                $name = $this->getText ("Unknown");
            else
                $name = $personLabels[$row[$refIdColumn]];
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $personsTable,
                                                                         $personsTable->getId (),
                                                                         $row[$refIdColumn]);
            $result[self::COL_TEAM] = "<a href=\"$url\">$name</a>";

            $results[] = $result;
            }

        return $results;
        }
        
    protected function selectTeamCardTypeStatistics ($id, $groupByTeam = true, $invert = false)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $eventsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHEVENT);
        if (empty ($matchTable) || empty ($teamsTable) || empty ($eventsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $columns = array ();
        $matchJoins = NULL;
        $params = array ();
        if ($groupByTeam)
            {
            $teamIdColumn = "teamid";
            $homeTeamColumn = "f_".Sports::COL_MATCH_HOMETEAM."_".$teamsTable->getIdColumn ();
            $awayTeamColumn = "f_".Sports::COL_MATCH_AWAYTEAM."_".$teamsTable->getIdColumn ();
            $isHomeCondition = "c_".Sports::COL_EVENT_ISHOME."=".($invert ? 0 : 1);
            $columns[] = new ConditionalResultColumn ($teamIdColumn, $isHomeCondition, $homeTeamColumn, $awayTeamColumn);
            $params[] = new GroupBy (array ("(case WHEN $isHomeCondition THEN $homeTeamColumn ELSE $awayTeamColumn END)"));
            }

        $joinCriteria = $this->createIdCriterion ($id, true, false);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $filterByTeam = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
        if (is_numeric ($filterByTeam))
            {
            $joinCriteria[] = new FilterByTeamCriterion ($filterByTeam, "c_".Sports::COL_EVENT_ISHOME, $groupByTeam);
            }
        $joins[] = $matchTable->createQuery (array (), $joinCriteria, $matchJoins);
        $criteria = array ();

        $params[] = new GroupBy (array ("c_".Sports::COL_EVENT_CAUSE));

        $columns[] = Sports::COL_EVENT_CAUSE;
        $columns[] = new FunctionCount ("*", self::COL_COUNT);
        
        if ($groupByTeam)
            $params[] = OrderBy::createByAlias ($teamIdColumn, true, 1, self::COL_COUNT, false, 2, "c_".Sports::COL_EVENT_CAUSE);
        else
            $params[] = OrderBy::createByAlias (self::COL_COUNT, false, 1, "c_".Sports::COL_EVENT_CAUSE);

        $criteria[] = new InCriterion ("c_".Sports::COL_EVENT_TYPE, array (MatchConstants::EVENT_YELLOW, MatchConstants::EVENT_YELLOW_RED, MatchConstants::EVENT_RED));
        $rows = $eventsTable->selectBy ($columns, $criteria, $joins, $params);
        if (empty ($rows))
            return false;

            $teamIds = array ();
        $totalCount = 0;
        foreach ($rows as $row)
            {
            $totalCount += $row[self::COL_COUNT];

            if ($groupByTeam)
                $teamIds[] = $row[$teamIdColumn];
            }

        if ($groupByTeam)
            $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);

        $causeColumn = $eventsTable->findColumn (Sports::COL_EVENT_CAUSE);
        $unknownCount = 0;
        foreach ($rows as $row)
            {
            $result = NULL;
            $result[self::COL_CAUSE] = NamedIntColumn::getItem ($causeColumn, $row["c_".Sports::COL_EVENT_CAUSE]);
            if (empty ($result[self::COL_CAUSE]))
                {
                $unknownCount += $row[self::COL_COUNT];
                continue;
                }

            if (!is_numeric ($filterByTeam))
                {
                if ($groupByTeam && $row[self::COL_COUNT] < 2)
                    continue;
                if (!$groupByTeam && $row[self::COL_COUNT] < 5)
                    continue;
                }

            $result[self::COL_COUNT] = $row[self::COL_COUNT];
            $result[self::COL_PERCENT] = $this->lng->decimalToString ($row[self::COL_COUNT] / $totalCount * 100, 2);

            if ($groupByTeam)
                {
                if (empty ($teamLabels[$row[$teamIdColumn]]))
                    $result[self::COL_TEAM] = $this->getText ("Unknown");
                else
                    {
                    $name = $teamLabels[$row[$teamIdColumn]];
                    $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                                 $teamsTable->getId (),
                                                                                 $row[$teamIdColumn]);
                    $result[self::COL_TEAM] = "<a href=\"$url\">$name</a>";
                    }
                }

            $results[] = $result;
            }

        if (!$groupByTeam && $unknownCount > 0)
            {
            $part = $this->lng->decimalToString ($unknownCount / $totalCount * 100, 2);
            $results[] = array (self::COL_CAUSE => $this->getText ("Not set"), self::COL_COUNT => $unknownCount, self::COL_PERCENT => $part);
            }

        return $results;
        }
        
    protected function selectGoalTypeStatisticsInverted ($id)
        {
        return $this->selectGoalTypeStatistics ($id, true, true);
        }

    protected function selectGoalTypeStatistics ($id, $groupByTeam = true, $invert = false)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $goalsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHGOAL);
        if (empty ($matchTable) || empty ($teamsTable) || empty ($goalsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $homeTeamColumn = "f_".Sports::COL_MATCH_HOMETEAM."_".$teamsTable->getIdColumn ();
        $awayTeamColumn = "f_".Sports::COL_MATCH_AWAYTEAM."_".$teamsTable->getIdColumn ();
        $isHomeCondition = "c_".Sports::COL_GOAL_HOME."=".($invert ? 0 : 1);

        $joinCriteria = $this->createIdCriterion ($id);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $params = array ();
        if ($groupByTeam)
            {
            $columns[] = new ConditionalResultColumn ("teamid", $isHomeCondition, $homeTeamColumn, $awayTeamColumn);
            $params[] = OrderBy::createByAlias (self::COL_COUNT, false, "teamid", true);
            $params[] = new GroupBy (array ("(case WHEN $isHomeCondition THEN $homeTeamColumn ELSE $awayTeamColumn END)"));
            }

        $joins[] = $matchTable->createQuery (array (), $joinCriteria);
        $criteria = array ();

        $params[] = new GroupBy (array ("c_".Sports::COL_GOAL_TYPE));

        $columns = array (Sports::COL_GOAL_TYPE);
        if ($groupByTeam)
            $columns[] = new ConditionalResultColumn ("teamid", $isHomeCondition, $homeTeamColumn, $awayTeamColumn);

        $columns[] = new FunctionCount ("*", self::COL_COUNT);
        
        if ($groupByTeam)
            $params[] = OrderBy::createByAlias ("teamid", true, self::COL_COUNT, false, "c_".Sports::COL_GOAL_TYPE);
        else
            $params[] = OrderBy::createByAlias (self::COL_COUNT, false, "c_".Sports::COL_GOAL_TYPE);

        $rows = $goalsTable->selectBy ($columns, $criteria, $joins, $params);
        if (empty ($rows))
            return false;

        $teamIds = array ();
        $totalCount = 0;
        foreach ($rows as $row)
            {
            $totalCount += $row[self::COL_COUNT];
            if ($groupByTeam)
                $teamIds[] = $row["teamid"];
            }

        if ($groupByTeam)
            $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);

        $goalTypeColumn = $goalsTable->findColumn (Sports::COL_GOAL_TYPE);
        $unknownCount = 0;
        $results = NULL;
        foreach ($rows as $row)
            {
            $result = NULL;
            $goalType = $row["c_".Sports::COL_GOAL_TYPE];
            if (MatchConstants::GOAL_TYPE_NORMAL == $goalType || MatchConstants::GOAL_TYPE_COUNTER_ATACK == $goalType)
                continue;

            if ($goalType > 0)
                $result[self::COL_CAUSE] = NamedIntColumn::getItem ($goalTypeColumn, $goalType);
            if (empty ($result[self::COL_CAUSE]))
                {
                $unknownCount += $row[self::COL_COUNT];
                continue;
                }

            if ($groupByTeam && $row[self::COL_COUNT] < 2)
                continue;
            if (!$groupByTeam && $row[self::COL_COUNT] < 5)
                continue;

            $result[self::COL_COUNT] = $row[self::COL_COUNT];
            $result[self::COL_PERCENT] = $this->lng->decimalToString ($row[self::COL_COUNT] / $totalCount * 100, 2);

            if ($groupByTeam)
                {
                if (empty ($teamLabels[$row["teamid"]]))
                    $result[self::COL_TEAM] = $this->getText ("Unknown");
                else
                    {
                    $name = $teamLabels[$row["teamid"]];
                    $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                                 $teamsTable->getId (),
                                                                                 $row["teamid"]);
                    $result[self::COL_TEAM] = "<a href=\"$url\">$name</a>";
                    }
                }

            $results[] = $result;
            }

        if (!$groupByTeam && !empty ($results) && $unknownCount > 0)
            {
            $part = $this->lng->decimalToString ($unknownCount / $totalCount * 100, 2);
            $results[] = array (self::COL_CAUSE => $this->getText ("Not set"), self::COL_COUNT => $unknownCount, self::COL_PERCENT => $part);
            }

        return $results;
        }

    protected function selectPlayerGoalStatisticsInverted ($id)
        {
        return $this->selectPlayerGoalStatistics ($id, NULL, true);
        }

    protected function selectPlayerGoalStatistics ($id, $sortByYoungest = NULL, $invert = false)
        {
        $assists = 0 == strcmp ("assist", $sortByYoungest);
        if ($assists)
            $sortByYoungest = NULL;

        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        $goalsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHGOAL);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        if (empty ($matchTable) || empty ($personsTable) || empty ($goalsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $personColumn = "f_".($assists ? Sports::COL_GOAL_ASSIST : Sports::COL_GOAL_SCORER)."_".$personsTable->getIdColumn ();
        $isHomeTeamColumn = "c_".Sports::COL_GOAL_HOME;
        $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $teamsTable->getIdColumn ());
        $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $teamsTable->getIdColumn ());

        $joinCriteria = $this->createIdCriterion ($id, true, true);
        $joinCriteria[] = new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ());
        $filterByTeam = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;
        if (is_numeric ($filterByTeam))
            $joinCriteria[] = new FilterByTeamCriterion ($filterByTeam, "c_".Sports::COL_GOAL_HOME, $invert);
        $columns = array ();
        $columns[] = new FunctionMin ("c_".Sports::COL_MATCH_DATE, self::COL_FIRST_MATCH);
        $columns[] = new FunctionMax ("c_".Sports::COL_MATCH_DATE, self::COL_LAST_MATCH);
        $columns[] = new ConditionalMaxColumn ("teamMax", "$isHomeTeamColumn = 1 - c_".Sports::COL_GOAL_OWN, $homeTeamColumn, $awayTeamColumn);
        $columns[] = new ConditionalMinColumn ("teamMin", "$isHomeTeamColumn = 1 - c_".Sports::COL_GOAL_OWN, $homeTeamColumn, $awayTeamColumn);
        $columns[] = new ConditionalDistinctCountColumn ("teamCnt", "$isHomeTeamColumn = 1", $homeTeamColumn, $awayTeamColumn);
        $joins[] = $matchTable->createQuery ($columns, $joinCriteria);
        
        // also join persons table (to retrieve birthday information)
        $joinCriteria = NULL;
        $joinCriteria[] = new JoinColumnsCriterion ($personColumn, $personsTable->getIdColumn ());
        $columns = array ();
        $columns[] = new FunctionMin ("DATEDIFF(c_".Sports::COL_MATCH_DATE.", c_".Sports::COL_PERSON_BIRTHDATE.")", self::COL_MIN_AGE);
        $columns[] = new FunctionMax ("DATEDIFF(c_".Sports::COL_MATCH_DATE.", c_".Sports::COL_PERSON_BIRTHDATE.")", self::COL_MAX_AGE);
        $columns[] = Sports::COL_PERSON_FIRST_NAME;
        $columns[] = Sports::COL_PERSON_SURNAME;
        $columns[] = Sports::COL_PERSON_BIRTHDATE;
        $columns[] = $personsTable->getIdColumn ();
        if (NULL !== $sortByYoungest)
            $joinCriteria[] = new DayIsNotEmptyCriteria ("c_".Sports::COL_PERSON_BIRTHDATE);
        $joins[] = $personsTable->createQuery ($columns, $joinCriteria);
        
        $criteria = array ();
        $params = array ();

        $columns = array ();
        $columns[] = new ConditionalSumColumn (self::COL_GOALS, "c_".Sports::COL_GOAL_OWN."=0", 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_OWN_GOALS, "c_".Sports::COL_GOAL_OWN."=1", 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_PENALTIES, "c_".Sports::COL_GOAL_PENALTY."=1", 1, 0);
        $params[] = new GroupBy (array ($personColumn));

        if (NULL === $sortByYoungest)
            {
            $params[] = new LimitByPage (0, 200);
            $params[] = OrderBy::createByAlias (self::COL_GOALS, false, self::COL_PENALTIES, false,
                                                self::COL_OWN_GOALS, true, Sports::COL_EVENT_PLAYER, true);
            }
        else
            {
            $params[] = new LimitByPage (0, 20);
            $criteria[] = new EqCriterion (Sports::COL_GOAL_OWN, 0);
            if ($sortByYoungest)
                {
                $params[] = OrderBy::createByAlias (self::COL_MIN_AGE, true, self::COL_GOALS, false, self::COL_PENALTIES, false,
                                                    self::COL_OWN_GOALS, true, Sports::COL_EVENT_PLAYER, true);
                }
            else
                {
                $params[] = OrderBy::createByAlias (self::COL_MAX_AGE, false, self::COL_GOALS, false, self::COL_PENALTIES, false,
                                                    self::COL_OWN_GOALS, true, Sports::COL_EVENT_PLAYER, true);
                }
            }

        $rows = $goalsTable->selectBy ($columns, $criteria, $joins, $params);

        if (empty ($rows))
            return NULL;

        $lng = Language::getInstance ($this->context);
        $teamLabels = $this->collectTeamLabelsByMinMax ($teamsTable, $rows);

        $results = array ();
        foreach ($rows as $row)
            {
            $result = NULL;
            $result[self::COL_GOALS] = $row[self::COL_GOALS];
            $result[self::COL_OWN_GOALS] = $row[self::COL_OWN_GOALS];
            $result[self::COL_PENALTIES] = $row[self::COL_PENALTIES];
            $birthDay = $row["c_".Sports::COL_PERSON_BIRTHDATE];
            $maxAge = $this->getAgeDiff ($this->context, $row[self::COL_LAST_MATCH], $birthDay);
            $minAge = $this->getAgeDiff ($this->context, $row[self::COL_FIRST_MATCH], $birthDay);
            $result[self::COL_BIRTH_DATE] = empty ($birthDay) ? $this->getText ("Unknown") : $this->lng->dateToLongString ($birthDay);
            $firstMatch = empty ($row[self::COL_FIRST_MATCH]) ? "?" : $this->lng->dateToLongString ($row[self::COL_FIRST_MATCH], "day");
            $lastMatch = empty ($row[self::COL_LAST_MATCH]) ? "?" : $this->lng->dateToLongString ($row[self::COL_LAST_MATCH], "day");
            $result[self::COL_FIRST_MATCH] = "<span style=\"white-space:nowrap;\">$firstMatch</span><br/>($minAge)";
            $result[self::COL_LAST_MATCH] = "<span style=\"white-space:nowrap;\">$lastMatch</span><br/>($maxAge)";

            $name = array ();

            if (!empty ($row["c_".Sports::COL_PERSON_FIRST_NAME]))
                $name[] = $row["c_".Sports::COL_PERSON_FIRST_NAME];
            if (!empty ($row["c_".Sports::COL_PERSON_SURNAME]))
                $name[] = $row["c_".Sports::COL_PERSON_SURNAME];

            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $personsTable,
                                                                         $personsTable->getId (),
                                                                         $row[$personsTable->getIdColumn ()]);
            $result[self::COL_PLAYER] = "<a href=\"$url\">".implode (" ", $name)."</a>";
            $result[self::COL_TEAM] = $this->guessPlayerTeamByMinMax ($teamsTable, $lng, $teamLabels, $row);

            $results[] = $result;
            }

        return $results;
        }

    protected function collectTeamLabelsByMinMax ($teamsTable, $rows)
        {
        $teamIds = array ();
        foreach ($rows as $row)
            {
            if (empty ($row["teamMax"]) && empty ($row["teamMin"]))
                continue;

            if (false === array_search ($row["teamMax"], $teamIds))
                $teamIds[] = $row["teamMax"];
            if (false === array_search ($row["teamMin"], $teamIds))
                $teamIds[] = $row["teamMin"];
            }

        return SportsHelper::getTeamLabels ($this->context, $teamIds);
        }

    protected function guessPlayerTeamByMinMax ($teamsTable, $lng, $teamLabels, $row)
        {
        if (empty ($row["teamMax"]) || empty ($row["teamMin"]))
            return NULL;

        $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                     $teamsTable->getId (),
                                                                     $row["teamMin"]);
        $label = "<a href=\"$url\">".$lng->beautifyTeamLabel ($teamLabels[$row["teamMin"]])."</a>";

        if ($row["teamMax"] != $row["teamMin"])
            {
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                         $teamsTable->getId (),
                                                                         $row["teamMax"]);
            $label .= ", <a href=\"$url\">".$lng->beautifyTeamLabel ($teamLabels[$row["teamMax"]])."</a>";

            $cnt = $row["teamCnt"];
            while ($cnt > 2)
                {
                $label .= ", ...";
                $cnt--;
                }
            }

        return $label;
        }

    protected function selectAttendanceStatistics ($id, $groupByClub)
        {
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $stadiumTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_STADIUM);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        if (empty ($matchTable) || empty ($stadiumTable) || empty ($teamsTable))
            {
            $this->context->setError ("Table not found");
            return false;
            }

        $stadiumIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STADIUM, $stadiumTable->getIdColumn ());
        $joinCriteria = $this->createIdCriterion ($id);
        $joinCriteria[] = new InCriterion ("c_".Sports::COL_MATCH_OUTCOME,
                               array (MatchConstants::OUTCOME_NOT_STARTED, MatchConstants::OUTCOME_FULL_TIME,
                                      MatchConstants::OUTCOME_EXTRA_TIME, MatchConstants::OUTCOME_PENALTIES,
                                      MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                      MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $joinCriteria[] = new LogicalOperatorOr (new EqCriterion ("c_".Sports::COL_MATCH_EXCLUDED, 0), new IsNullCriterion ("c_".Sports::COL_MATCH_EXCLUDED));
        $joinCriteria[] = new IsNotNullCriterion ("c_".Sports::COL_MATCH_HOMERESULT);
        $columns = array ();
        $columns[] = new FunctionMin (Sports::COL_MATCH_SPECTATORS, self::COL_MIN_ATTENDANCE);
        $columns[] = new FunctionMax (Sports::COL_MATCH_SPECTATORS, self::COL_MAX_ATTENDANCE);
        $columns[] = new FunctionAvg (Sports::COL_MATCH_SPECTATORS, self::COL_AVG_ATTENDANCE);
        $columns[] = new FunctionSum (Sports::COL_MATCH_SPECTATORS, self::COL_TOTAL_ATTENDANCE);
        $columns[] = new ConditionalSumColumn (self::COL_GAMES, "c_".Sports::COL_MATCH_SPECTATORS." IS NOT NULL", 1, 0);
        $homeTeamColumn = ContentTable::generateForeignKeyColumn (2 === $groupByClub ? Sports::COL_MATCH_AWAYTEAM : Sports::COL_MATCH_HOMETEAM, $teamsTable->getIdColumn ());
        if ($groupByClub)
            {
            $params = NULL;
            $columns[] = $homeTeamColumn;
            $columns[] = new FunctionCount ("*", self::COL_COUNT);
            $params[] = new GroupBy (array ($homeTeamColumn));
            $params[] = OrderBy::createByAlias (self::COL_AVG_ATTENDANCE);
            $rows = $matchTable->selectBy ($columns, $joinCriteria, NULL, $params);
            }
        else
            {
            $joinCriteria[] = new JoinColumnsCriterion ($stadiumTable->getIdColumn (), $stadiumIdColumn);
            $joins[] = $matchTable->createQuery ($columns, $joinCriteria);

            $criteria = array ();
            $columns = array ();
            $stadiumNameIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_STADIUM_ACTUAL, Sports::TABLE_STADIUM."_id");
            $columns[] = new ConditionalResultColumn ("stadium.id", "$stadiumNameIdColumn IS NULL", "tbl1.".$stadiumTable->getIdColumn (), $stadiumNameIdColumn);
            $columns[] = new FunctionCount ("*", self::COL_COUNT);
            $params = NULL;
            $params[] = new GroupBy (array ("stadium.id"));

            $params[] = OrderBy::createByAlias (self::COL_AVG_ATTENDANCE);
            
            $rows = $stadiumTable->selectBy ($columns, $criteria, $joins, $params);

            if (empty ($rows))
                return false;

            $stadiumIds = array ();
            foreach ($rows as $row)
                $stadiumIds[] = $row["stadium.id"];

            $criteria = array (new InCriterion ($stadiumTable->getIdColumn (), $stadiumIds));
            $stadiums = $stadiumTable->selectWithDisplayName (array ($stadiumTable->getIdColumn ()), $criteria);
            if (empty ($stadiums))
                return false;

            $stadiumLabels = array ();
            foreach ($stadiums as $row)
                $stadiumLabels[$row[$stadiumTable->getIdColumn ()]] = $row[ContentTable::COL_DISPLAY_NAME];
            }

        if (empty ($rows))
            return false;

        if ($groupByClub)
            {
            foreach ($rows as $row)
                $teamIds[] = $row[$homeTeamColumn];
            $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);
            }

        $results = array ();
        $totalGames = $totalCountable = $totalAttendance = $minAttendance = $maxAttendance = NULL;
        foreach ($rows as $row)
            {
            $result = NULL;
            $result[self::COL_GAMES] = $row[self::COL_COUNT];
            $result[self::COL_MIN_ATTENDANCE] = $row[self::COL_MIN_ATTENDANCE];
            $result[self::COL_MAX_ATTENDANCE] = $row[self::COL_MAX_ATTENDANCE];
            $result[self::COL_AVG_ATTENDANCE] = $this->lng->decimalToString ($row[self::COL_AVG_ATTENDANCE], 2);
            $result[self::COL_TOTAL_ATTENDANCE] = $row[self::COL_TOTAL_ATTENDANCE];
            $totalGames += $row[self::COL_COUNT];
            $totalCountable += $row[self::COL_GAMES];
            $totalAttendance += $row[self::COL_TOTAL_ATTENDANCE];
            if (NULL !== $row[self::COL_MIN_ATTENDANCE] && (NULL === $minAttendance || $row[self::COL_MIN_ATTENDANCE] < $minAttendance))
                $minAttendance = $row[self::COL_MIN_ATTENDANCE];
            $maxAttendance = $maxAttendance < $row[self::COL_MAX_ATTENDANCE] ? $row[self::COL_MAX_ATTENDANCE] : $maxAttendance;

            if ($row[self::COL_GAMES] != $row[self::COL_COUNT])
                {
                $result[self::COL_RELIABILITY] =  $this->getText ("Missing [_0] %",
                                                                  $this->lng->decimalToString (($row[self::COL_COUNT] - $row[self::COL_GAMES]) / $row[self::COL_COUNT] * 100, 2));
                if (NULL !== $row[self::COL_TOTAL_ATTENDANCE])
                    {
                    $result[self::COL_TOTAL_ATTENDANCE] = $this->getText ("~[_1] ([_0])",
                                                                      $row[self::COL_TOTAL_ATTENDANCE],
                                                                      $this->lng->decimalToString ($row[self::COL_TOTAL_ATTENDANCE] / (1 - ($row[self::COL_COUNT] - $row[self::COL_GAMES]) / $row[self::COL_COUNT]), 0));
                    }
                if (NULL !== $row[self::COL_COUNT])
                    {
                    $result[self::COL_GAMES] = "{$row[self::COL_COUNT]}<br>({$row[self::COL_GAMES]})";
                    }
                }
            else
                $result[self::COL_RELIABILITY] =  $this->getText ("reliable");

            if ($groupByClub)
                {
                $teamId = $row[$homeTeamColumn];
                $url = NULL;
                if (array_key_exists ($teamId, $teamLabels))
                    {
                    $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                                 $teamsTable->getId (), $teamId);
                    $result[self::COL_STADIUM] = "<a href=\"$url\">".$teamLabels[$teamId]."</a>";
                    }
                }
            else
                {
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $stadiumTable,
                                                                             $stadiumTable->getId (),
                                                                             $row["stadium.id"]);
                $result[self::COL_STADIUM] = "<a href=\"$url\">".$stadiumLabels[$row["stadium.id"]]."</a>";
                }
            $results[] = $result;
            }

        if ($totalGames != $totalCountable)
            $reliability =  $this->getText ("Missing [_0] %",
                                            $this->lng->decimalToString (($totalGames - $totalCountable) / $totalGames * 100, 2));
        else
            $reliability =  $this->getText ("reliable");
            
        $totalGamesText = $totalGames;
        if ($totalGames != $totalCountable)
            {
            $totalAttendanceLabel = $this->getText ("~[_1] ([_0])",
                                               $totalAttendance,
                                               $this->lng->decimalToString ($totalAttendance / (1 - ($totalGames - $totalCountable) / $totalGames), 0));
            $totalGamesText = "$totalGames ($totalCountable)";
            }
        else
            $totalAttendanceLabel = $totalAttendance;
        $results[] = array (self::COL_STADIUM => $this->getText ("Total:"), self::COL_GAMES => $totalGamesText,
                            self::COL_TOTAL_ATTENDANCE => $totalAttendanceLabel,
                            self::COL_RELIABILITY => $reliability,
                            self::COL_MIN_ATTENDANCE => $minAttendance, self::COL_MAX_ATTENDANCE => $maxAttendance,
                            self::COL_AVG_ATTENDANCE => $this->lng->decimalToString ($totalAttendance / $totalCountable, 2));
        return $results;
        }

    }

class MatchTeamJoinCriterion extends JoinCriterion
    {
    protected $teamColumn;
    protected $isHomeColumn;
    protected $invert;

    public function __construct ($teamColumn, $isHomeColumn, $invert = false)
        {
        $this->teamColumn = $teamColumn;
        $this->isHomeColumn = $isHomeColumn;
        $this->invert = $invert;
        }

    public function formatForDB ($dbconnection, $parentTableAlias, $childTableAlias)
        {
        if (NULL != $parentTableAlias)
            $parentTableAlias .= ".";
        if (NULL != $childTableAlias)
            $childTableAlias .= ".";

        $isHomeColumn = $this->isHomeColumn;
        $homeTeamColumn = $parentTableAlias."f_".Sports::COL_MATCH_HOMETEAM."_".Sports::TABLE_TEAM."_id";
        $awayTeamColumn = $parentTableAlias."f_".Sports::COL_MATCH_AWAYTEAM."_".Sports::TABLE_TEAM."_id";
        $childColumn = $childTableAlias.$this->teamColumn;
        $one = 1;
        $zero = 0;
        if ($this->invert)
            list ($one, $zero) = array ($zero, $one);

        return "(($isHomeColumn=$one and $homeTeamColumn=$childColumn) or ($isHomeColumn=$zero and $awayTeamColumn=$childColumn))";
        }
    }

class StatisticsPlotComponent extends StatisticsSection
    {
    protected $customTooltip;
    public function __construct ($parent, $id, $title, $data, $customTooltip = NULL)
        {
        parent::__construct ($parent, $id, $title, $data, NULL);
        $this->customTooltip = $customTooltip;
        }

    public function getTemplateName ()
        {
        return "statsplot";
        }

    public function getCustomTooltipTemplate ()
        {
        return $this->customTooltip;
        }
    }

class TeamMatchesComponent extends StatisticsSection
    {
    protected $teamId;
    private $leagueId;

    public function __construct ($parent, $id, $leagueId, $teamId)
        {
        parent::__construct ($parent, $id, $parent->getText ("Friendlies"), NULL, NULL);
        $this->leagueId = $leagueId;
        $this->teamId = $teamId;
        }

    public function ensureChildren ($context, $request)
        {
        $competitiontable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $columns = array (Sports::COL_COMPETITION_STARTS, Sports::COL_COMPETITION_ENDS);
        $leagueRow = $competitiontable->selectSingleBy ($columns, array (new EqCriterion ($competitiontable->getIdColumn (), $this->leagueId)));
        if (!empty ($leagueRow) && !empty ($leagueRow["c_".Sports::COL_COMPETITION_ENDS]) && !empty ($leagueRow["c_".Sports::COL_COMPETITION_STARTS]))
            {
            $dateFrom = date ("Y-m-d", strtotime ("-11 months", strtotime ($leagueRow["c_".Sports::COL_COMPETITION_ENDS])));
            $this->addComponent ($request, "announce-{$this->teamId}", new TeamMatches ($context, $this->teamId, "announce-{$this->teamId}", $dateFrom, $leagueRow["c_".Sports::COL_COMPETITION_STARTS]));
            }
        else
            $this->addComponent ($request, "announce-{$this->teamId}", new TeamMatches ($context, $this->teamId));
        }

    public function getTemplateName ()
        {
        return "pages/simplecontainer";
        }

    public function processInput ($context, &$request)
        {
        return true;
        }
    }

<?php
require_once (PATH."pages/contentpreview.php");

class LeagueAchievements extends ContentPreview
    {
    protected $seasonField;
    protected $levelField;
    protected $competitionField;
    protected $cachedLeagueAchievements = NULL;
    protected $cachedCupAchievements = NULL;

    protected function getDisplayTemplate ()
        {
        $fields = parent::getDisplayTemplate ();
        return array_merge
            (
            array
                (
                $this->seasonField,
                $this->competitionField,
                $this->levelField,
                ),
            $fields
            );
        }

    protected function createFieldFromColumn ($col, $displayNameColumn, &$displayColumnShown)
        {
        if ($col->name == "season")
            {
            $this->seasonField = new AchievementSeasonField ($this->context, "i", $col);
            $this->levelField = new AchievementLevelField ($this->context, "i", $col);
            $this->competitionField = new AchievementCompetitionField ($this->context, "i", $col);
            return NULL;
            }
        else if ($col->name == "place")
            {
            return new AchievementPlaceField ("i", $col->columnDef->name, $col->getLabel ());
            }

        return parent::createFieldFromColumn ($col, $displayNameColumn, $displayColumnShown);
        }

    public function getPageSize ()
        {
        return 100;
        }

    public function select ($context, $criteria = NULL, $mode = 0)
        {
        if (NULL === $this->cachedLeagueAchievements)
            {
            $this->cachedLeagueAchievements = parent::select ($context, $criteria);
            }

        $rows = $this->cachedLeagueAchievements;
        if (empty ($rows))
            return $rows;

        $primaryAchievements = array ();
        $otherAchievements = array ();
        foreach ($rows as $row)
            {
            if (empty ($row["season.c_level"]))
                $otherAchievements[] = $row;
            else
                $primaryAchievements[] = $row;
            }

        switch ($mode)
            {
            case 1:
                return $primaryAchievements;

            case 2:
                return $otherAchievements;

            default:
                return array_merge ($primaryAchievements, $otherAchievements);
            }
        }

    public function getTemplateName ()
        {
        return "sports/leagueachievements";
        }

    public function getTitle ($mode = 0)
        {
        switch ($mode)
            {
            case 1:
                return $this->getText ("League achievements");

            case 2:
                return $this->getText ("Other tournaments");

            default:
                return parent::getTitle ();
            }
        }

    public function getNavigationIcons ()
        {
        return NULL;
        }
    }

class AchievementCompetitionField extends LabelRelationFieldTemplate
    {
    protected $context;

    public function __construct ($context, $prefix, $relationColumn)
        {
        $this->context = $context;
        parent::__construct ($context, $prefix, $relationColumn);
        }

    public function getValueForDisplay ($context, $row, $key = NULL)
        {
        if (empty ($row[$this->key.".c_name"]))
            return NULL;
        return $row[$this->key.".c_name"];
        }

    public function getLabel ($format = true)
        {
        return $this->context->getText ("Competition");
        }
    }

class AchievementSeasonField extends LabelRelationFieldTemplate
    {
    protected $context;

    public function __construct ($context, $prefix, $relationColumn)
        {
        $this->context = $context;
        parent::__construct ($context, $prefix, $relationColumn);
        $this->cssClass = "achievementseason";
        }

    public function getValueForDisplay ($context, $row, $key = NULL)
        {
        return parent::getValueForDisplay ($context, $row, $this->key.".season");
        }

    public function getLabel ($format = true)
        {
        return $this->context->getText ("Season");
        }
    }

class AchievementLevelField extends LabelIntFieldTemplate
    {
    protected $context;

    public function __construct ($context, $prefix, $relationColumn)
        {
        parent::__construct ($prefix, $relationColumn->name.".c_level", $context->getText ("Level"));
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        $resultColumns[] = $this->key;
        }

    }

class AchievementPlaceField extends LabelIntFieldTemplate
    {
    public function getValueForDisplay ($context, $row, $key = NULL)
        {
        $level = $row["season.c_level"];
        if (!empty ($row[$this->key]))
            $this->cssClass = "l{$level}_place{$row[$this->key]}";
        else
            $this->cssClass = "noplace";

        return $row[$this->key];
        }

    }

<?php

require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'pages/contentpreview.php');

class RefereeRatingList extends InteractiveComponent
    {
    protected $criteria;
    protected $title;
    protected $dbtable;
    protected $groups = NULL;

    public function __construct ($context, $prefix, $table, $title = NULL, $description = NULL)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_REFEREERATING);
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "sports/refereeratinglist";
        }

    public function getActionList ()
        {
        $actions = array ();
       
        if ($this->dbtable->canCreate ())
            {
            $action = "new";
            $url = "index.php?c=ContentPage&tn={$this->dbtable->getName()}&action=$action";
            
            $actions[] = new AdditionalURLIcon ($this, $action, $title, $url);
            }

        return $actions;
        }

    public function setCriteria ($criteria)
        {
        $this->criteria = $criteria;
        }

    public function getDescription ()
        {
        return $this->getText ("Referee ratings by season");
        }

    public function getTableName ()
        {
        return Sports::TABLE_REFEREERATING;
        }

    public function showParentField ($show)
        {
        }

    public function excludeColumns ($excludedColumns)
        {
        }

    public function setTitle ($title)
        {
        $this->title = $title;
        }

    public function getTitle ()
        {
        return $this->title;
        }

    public function getLinkGroups ()
        {
        if (NULL !== $this->groups)
            return $this->groups;

        $this->groups = array ();
        $singleSeasonList = !empty ($this->criteria);
        
        $columns = array (Sports::COL_REFEREERATING_SEASON, Sports::COL_REFEREERATING_TYPE);
        $params[] = new GroupByAll ();
        $rows = $this->dbtable->selectBy ($columns, $this->criteria, NULL, $params);
        if (empty ($rows))
            return $this->groups;

        $table = $this->dbtable->getName ();
        if ($singleSeasonList)
            {
            $group = array ();
            foreach ($rows as $row)
                {
                $type = $row["c_".Sports::COL_REFEREERATING_TYPE];
                $seasonId = $row[Sports::COL_REFEREERATING_SEASON][0];

                $url = $this->context->chooseUrl ("list/$table", "index.php?c=ContentPreviewPage&tn=$table", "season=$seasonId&tp=$type");
                if (1 == $type)
                    $group[$url] = $this->getText ("Season referee ratings");
                else
                    $group[$url] = $this->getText ("Season assistant referee ratings");
                }
            
            if (!empty ($group))
                $this->groups[$this->getText ("Ratings:")] = $group;
            }
        else
            {
            $refereeRatingSeasons = array ();
            $assistantRatingSeasons = array ();
            foreach ($rows as $row)
                {
                $season = $row[Sports::COL_REFEREERATING_SEASON.".".ContentTable::COL_DISPLAY_NAME];
                $type = $row["c_".Sports::COL_REFEREERATING_TYPE];
                $seasonId = $row[Sports::COL_REFEREERATING_SEASON][0];

                $url = $this->context->chooseUrl ("list/$table", "index.php?c=ContentPreviewPage&tn=$table", "season=$seasonId&tp=$type");
                if (1 == $type)
                    $refereeRatingSeasons[$url] = $season;
                else
                    $assistantRatingSeasons[$url] = $season;
                }

            if (!empty ($refereeRatingSeasons))
                {
                $label = $this->getText ("Referee ratings:");
                $this->groups[$label] = $refereeRatingSeasons;
                }
            if (!empty ($assistantRatingSeasons))
                {
                $label = $this->getText ("Assistant referee ratings:");
                $this->groups[$label] = $assistantRatingSeasons;
                }

            if (empty ($this->groups))
                $this->groups[$this->getText ("No ratings entered")] = array ();
            }

        return $this->groups;
        }

    public function showCreateIcon ()
        {
        return NULL != $this->dbtable && $this->dbtable->canCreate ();
        }

    public function isVisible ()
        {
        if (empty ($this->criteria))
            return true;

        $groups = $this->getLinkGroups ();
        if (!$this->showCreateIcon() && empty ($groups))
            return false;
        return true;
        }
    }

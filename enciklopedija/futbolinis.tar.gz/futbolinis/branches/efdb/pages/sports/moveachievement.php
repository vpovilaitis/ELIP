<?php
require_once (PATH.'pages/submit.php');
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/relationfields.php');

class MoveAchievement extends Submit
    {
    protected $matchesTable;
    protected $sourceTeam;
    protected $targetTeam;

    public function __construct ($context, $request)
        {
        $isCup = !empty ($request["cup"]);
        $this->dbtable = ContentTable::createInstanceByName ($context, $isCup ? "teamcupseason" : "teamleagueseasons");
        $this->matchesTable = ContentTable::createInstanceByName ($context, "match");

        if (empty ($this->dbtable) || empty ($this->matchesTable))
            {
            $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            $this->allTablesLoaded = false;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        $context->addScriptFile ("autosuggest");
        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ("Batch creation of the players");
        return true;
        }

    public function createSourceFields ()
        {
        parent::createSourceFields ();
        $teamColumn = $this->matchesTable->findColumn ("hometeam");
        $sourceTeam = clone $teamColumn;
        $sourceTeam->label = "Source team";
        $sourceTeam->name = "sourceTeam";
        $targetTeam = clone $teamColumn;
        $targetTeam->label = "Target team";
        $targetTeam->name = "targetTeam";

        $this->sourceTeam = RelationDropDownFieldTemplate::createInstance ($this->context, "", $sourceTeam);
        $this->targetTeam = RelationDropDownFieldTemplate::createInstance ($this->context, "", $targetTeam);
        }
        
    protected function processInputFields ($context, &$request)
        {
        parent::processInputFields ($context, $request);

        $this->createSourceFields ();

        $this->sourceTeam->processInput ($context, $request);
        $this->targetTeam->processInput ($context, $request);
        }

    public function collectInputData ($context, &$request)
        {
        if (empty ($request["achievement"]) || empty ($request["sourceTeam"]) || empty ($request["targetTeam"]))
            return NULL;

        $this->createSourceFields ();
        $this->source = $this->sourcesField->getValueForDB ($context, $request);
        $this->sourceDate = $this->sourcesDateField->getValueForDB ($context, $request);

        return array ("achievement" => $request["achievement"],
                      "sourceTeam" => $request["sourceTeam"],
                      "targetTeam" => $request["targetTeam"],
                      "cup" => $request["cup"]);
        }
        
    public function validateInput ($context, &$input)
        {
        if (empty ($input["achievement"]) || empty ($input["sourceTeam"]) || empty ($input["targetTeam"]))
            return false;
        return true;
        }

    public function getNextAvailableId ($teamId)
        {
        $maxCol = array (new FunctionMax ($this->dbtable->getIdColumn (), "maxId"));
        $criteria = array ();

        $teamIdColumn = $this->dbtable->getParentTable ()->getIdColumn ();
        $groupBy = array ();
        $id = array ($teamId);

        $criteria[] = new EqCriterion ($teamIdColumn, $teamId);
        $groupBy[] = $teamIdColumn;

        $row = $this->dbtable->selectSingleBy ($maxCol, $criteria, NULL, array (new GroupBy ($groupBy)));
        if (false === $row)
            return false;

        $val = $row["maxId"]+1;
        $id[] = $val;
        return $id;
        }
        
    public function saveInput ($context, &$request, &$input)
        {
        if (empty ($input))
            return;

        $teamIdColumn = $this->dbtable->getParentTable ()->getIdColumn ();
        $achievementIdColumn = $this->dbtable->getIdColumn ();
        $sourceTeamId = $input["sourceTeam"];
        $targetTeamId = $input["targetTeam"];
        $isCup = $input["cup"];

        $criteria[] = new EqCriterion ($teamIdColumn, $sourceTeamId);
        $criteria[] = new EqCriterion ($achievementIdColumn, $input["achievement"]);

        $row = $this->dbtable->selectSingleBy (array ("f_season_season_id"), $criteria);
        if (false === $row)
            return false;

        $seasonId = $row["f_season_season_id"];
        $nextId = $this->getNextAvailableId ($targetTeamId);
        $oldId = array ($sourceTeamId, $input["achievement"]);

        $tablePrefix = DB_PREF;
        $tableName = $this->dbtable->getTableName ();
        $revTableName = $this->dbtable->getStringTableName ();
        $stringTableName = $this->dbtable->getRevisionTableName ();
        
        $setPart = "`team_id` = {$nextId[0]}, `$achievementIdColumn` = {$nextId[1]}";
        $wherePart = "`team_id` = {$oldId[0]} AND `$achievementIdColumn` = {$oldId[1]}";
        print (<<<EOT
<pre>
UPDATE `$tablePrefix$stringTableName` SET {$setPart} WHERE {$wherePart};

UPDATE `$tablePrefix$tableName` SET {$setPart} WHERE {$wherePart};

UPDATE `$tablePrefix$revTableName` SET {$setPart} WHERE {$wherePart};

UPDATE `$tablePrefix{$this->matchesTable->getTableName()}` SET `f_hometeam_team_id`={$targetTeamId} WHERE `f_hometeam_team_id`={$sourceTeamId} AND `f_cstage_competitionstage_id`={$seasonId};

UPDATE `$tablePrefix{$this->matchesTable->getRevisionTableName()}` SET `f_hometeam_team_id`={$targetTeamId} WHERE `f_hometeam_team_id`={$sourceTeamId} AND `f_cstage_competitionstage_id`={$seasonId};

UPDATE `$tablePrefix{$this->matchesTable->getTableName()}` SET `f_awayteam_team_id`={$targetTeamId} WHERE `f_awayteam_team_id`={$sourceTeamId} AND `f_cstage_competitionstage_id`={$seasonId};

UPDATE `$tablePrefix{$this->matchesTable->getRevisionTableName()}` SET `f_awayteam_team_id`={$targetTeamId} WHERE `f_awayteam_team_id`={$sourceTeamId} AND `f_cstage_competitionstage_id`={$seasonId};

</pre>
EOT
);
        /*return array ("achievement" => $request["achievement"],
                      "sourceTeam" => $request["sourceTeam"],
                      "targetTeam" => $request["targetTeam"]);*/

        return true;
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();

        $arr = array
            (
            $this->sourceTeam,
            new IntFieldTemplate ("", "achievement", "AchievementId:", "Second part of the id"),
            $this->targetTeam,
            new CheckBoxFieldTemplate ("", "cup", $this->getText ("Cup season?"), $this->getText ("Not a league competition, but cup competition achievement")),
            );

        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));
        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }
    }

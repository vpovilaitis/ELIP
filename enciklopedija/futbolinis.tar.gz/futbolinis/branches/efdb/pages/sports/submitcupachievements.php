<?php
require_once (PATH.'pages/sports/submitgame.php');

class SubmitCupAchievements extends SubmitGame
    {
    public function ensureTitle ($context, &$request)
        {
        $title = "Submit cup achievements";
        $context->setTitle ($title);
        return true;
        }

    public function collectInputData ($context, &$request)
        {
        $year = $request["year"];

        $this->createSourceFields ();
        $this->source = $this->sourcesField->getValueForDB ($context, $request);
        $this->sourceDate = $this->sourcesDateField->getValueForDB ($context, $request);

        $achievementLines = preg_split("/[\n\r]+/", $request["parse"]);
        $containsErrors = false;
        $achievementsToSave = array ();

        foreach ($achievementLines as $line)
            {
            $line = trim ($line);
            if (empty ($line))
                continue;

            if (!preg_match ("#^(.+) (1?/?[0-9]+|F|C)#", $line, $matches))
                {
                $this->logError ("Row $line not suitable");
                $containsErrors = true;
                continue;
                }
            
            $arr = array ("team" => $matches[1], "stage" => $matches[2]);
            $this->checkTeam ($arr, "team");
            $this->checkStage ($arr, $arr["stage"]);
            $achievementsToSave[] = $arr;
            }

        if ($containsErrors)
            return false;
        return $achievementsToSave;
        }

    public function validateInput ($context, &$input)
        {
        return count ($input) > 0;
        }

    public function saveInput ($context, &$request, &$input)
        {
        $season = $request["cstage"];
        $dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMCUPSEASON);
        $count = 0;

        foreach ($input as $row)
            {
            $teamId = $row["teamId"];
            $achievementId = $row["roundId"];
            if (empty ($row["teamId"]) || empty ($row["roundId"]))
                return $this->logError ("Error saving achievement");
            $namesToValues = array ();
            $namesToValues[Sports::TABLE_TEAM."_id"] = $teamId;
            $namesToValues[Sports::COL_TEAMCUPSEASON_COMPETITION] = $season;
            $namesToValues[Sports::COL_TEAMCUPSEASON_ACHIEVEMENT] = $achievementId;
            $namesToValues[DBTable::COL_SOURCE] = $this->source;
            $namesToValues[DBTable::COL_SOURCEDATE] = $this->sourceDate;

            if (false === $dbtable->insertRecord ($namesToValues))
                $this->logError ("Error saving achievement ({$row["team"]}, {$row["stage"]})");
            else
                $count++;
            }

        print ($count." records(s) created");
        return true;
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();

        $arr[] = $this->competitionField;
        $arr[] = new DateFieldTemplate ("", "year", $this->getText ("Year (optional):"), $this->getText ("Enter the year competition took place"));
        $arr[] = new LongTextFieldTemplate ("", "parse", $this->getText ("Results:"), $this->getText ("Enter teams with achievements"));

        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));
        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }
    }

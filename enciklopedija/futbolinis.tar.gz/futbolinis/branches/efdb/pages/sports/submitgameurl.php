<?php
require_once (PATH.'pages/sports/submitgame.php');
require_once (PATH.'pages/sports/submitgameurl-saff.php');
require_once (PATH.'pages/sports/submitgameurl-vaff.php');
require_once (PATH.'pages/sports/submitgameurl-sfl.php');
require_once (PATH.'pages/sports/submitgameurl-uefa.php');

class SubmitGameUrl extends SubmitGame
    {
    const PARAM_MATCH_ID = "matchid";
    const PARAM_NOCARDS = "nocards";
    const PARAM_NOHOME = "nohome";
    const PARAM_NOAWAY = "noway";

    public function ensureTitle ($context, &$request)
        {
        $title = "Submit results for existing game";
        $context->setTitle ($title);
        return true;
        }

    public function prepareMatch (&$match, $skipTeamNames = false)
        {
        return parent::prepareMatch ($match, true);
        }

    public function processInput ($context, &$request)
        {
        if (!isset ($request["save"]) && !isset ($request["skip"]))
            return true;

        $this->collectInputFields ($context, $request);

        $match = $this->collectMatchParts ($request);

        if (false === $match)
            $this->logError ("Error parsing the results");
        else if (false === $this->prepareMatch ($match))
            $this->logError ("Error preparing the match");
        else
            {
            if ($this->allTablesLoaded && !$this->hasUnrecognizedItems)
                {
                $title = isset ($request["save"]) ? "Saving" : "Checking";
                $this->writeLine ("<h1>$title</h1><pre>");

                if (isset ($request["save"]) && false === $this->storeMatches (NULL, NULL, array ($match)))
                    $this->logError ("Error saving the match");

                $this->writeLine ("</pre>");
                }
            }

        $this->processInputFields ($context, $request);
        return true;
        }

    public function collectMatchParts ($request)
        {
        if (empty ($request[self::PARAM_MATCH_ID]))
            return $this->logError ("Match id not entered");

        $response = $this->retrieveHtml ($this->source);
        if (empty ($response))
            return $this->logError ("Cannot retrieve content from given URL");

        $content = PreprocessedMatchUrlContent::createInstance ($this->context, $this, $response, $this->source);
        if (false === $content)
            return false;

        $match = $content->getMatch ();
        if (empty ($match))
            return false;
        $match["id"] = $request[self::PARAM_MATCH_ID];
        
        if (!empty ($match["goal"]))
            {
            $criteria = array (new EqCriterion ("match_id", $match["id"]));
            $rows = $this->goaltable->selectBy (array (), $criteria);
            if (false === $rows)
                $this->logError ("Cannot retrieve existing match goals");
            else if (count ($rows) > 0)
                {
                if (count ($rows) != count ($match["goal"]))
                    $this->logError ("Match goals already entered (".count ($rows)." entered, ".count ($match["goal"])." expected)");
                else
                    $this->logError ("Match goals already entered");
                unset ($match["goal"]);
                }
            }

        if (!empty ($request[self::PARAM_NOCARDS]))
            {
            unset ($match["book"]);
            unset ($match["sent"]);
            unset ($match["miss"]);
            }

        if (!empty ($request[self::PARAM_NOHOME]))
            {
            $this->writeLine ("<pre>\nskipping home players:\n");
            foreach ($match["homePlayers"] as $player)
                $this->writeLine ("{$player["name"]};\n");
            $this->writeLine ("\n</pre>");
            unset ($match["homePlayers"]);
            }

        if (!empty ($request[self::PARAM_NOAWAY]))
            {
            $this->writeLine ("<pre>\nskipping away players:\n");
            foreach ($match["awayPlayers"] as $player)
                $this->writeLine ("{$player["name"]};\n");
            $this->writeLine ("\n</pre>");
            unset ($match["awayPlayers"]);
            }
        return $match;
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();

        $arr[] = new RelationAutocompleteField ("", $this->dbtable, self::PARAM_MATCH_ID, "Match id:", "Enter id of the existing match", true);

        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));

        $this->sourcesField->label = "Url";
        $this->sourcesField->tooltip = "Enter url to retrieve results from";
        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        $arr[] = new CheckBoxFieldTemplate ("", self::PARAM_NOCARDS, "Skip cards?", "Ignore parsed yellow and red cards");
        $arr[] = new CheckBoxFieldTemplate ("", self::PARAM_NOHOME, "Skip home?", "Ignore parsed home players");
        $arr[] = new CheckBoxFieldTemplate ("", self::PARAM_NOAWAY, "Skip away?", "Ignore parsed away players");
        return $arr;
        }
    }

class PreprocessedMatchUrlContent
    {
    protected $context;
    public $date;
    public $score;
    public $homeEvents;
    public $awayEvents;
    public $homePlayers;
    public $awayPlayers;
    public $goals;
    public $missedPenalties;
    public $yellowCards;
    public $redCards;
    public $referees = array ();
    public $stadium;
    public $spectators;

    protected function __construct ($context, $parent)
        {
        $this->context = $context;
        $this->parent = $parent;
        }

    public function writeLine ($text)
        {
        $this->parent->writeLine ($text);
        }

    public function setDescription ($description)
        {
        $date = cutTextPiece ($description, '</span>', '</p>');
        // $this->date = $date;
        }

    public function setReferees ($referees)
        {
        $referees = strip_tags ($referees);
        $parts = split ("[;,]", $referees);
        $type = null;
        foreach ($parts as $part)
            {
            $arr = explode ("-", $part);
            if (count ($arr) == 2)
                {
                list ($type, $name) = $arr;
                $type = strtolower (substr (trim ($type), 0, 3));
                }
            else
                {
                if ($type == "asi")
                    $type = "as2";
                $name = $part;
                }

            $name = trim ($name, "- ");
            switch ($type)
                {
                case "tei":
                    $type = "aik";
                case "aik":
                    $key = "referee";
                    break;
                case "asi":
                    $key = "refereeA1";
                    break;
                case "as2":
                    $key = "refereeA2";
                    break;
                case "rez":
                    $key = "refereeR";
                    break;
                case "ins":
                    $key = "refereeI";
                    break;
                default:
                    return $this->logError ("Errors while parsing referee $part");
                }

            if (empty ($name))
                continue;
            $this->referees[$key] = $name;
            }
        }

    public function setEvents ($events)
        {
        $initialList = $events;
        $substitutes = false;

        while (!empty ($events))
            {
            $row = cutTextPiece ($events, '<tr', '</tr>', true);
            if (empty ($row))
                break;
            if ($initialList == $events)
                return $this->logError ("Errors while parsing events");

            if (false !== strpos ($row, 'class="title"'))
                continue;
            $initialList = $events;
            
            list ($homeEvent, $awayEvent) = $this->parseEventsRow ($row);
            if (empty ($homeEvent) && empty ($awayEvent))
                return $this->logError ("Cannot parse given URL player");
            
            if (!empty ($homeEvent))
                $this->homeEvents[] = $homeEvent;
            if (!empty ($awayEvent))
                $this->awayEvents[] = $awayEvent;
            }
        }

    public function setPlayers ($players)
        {
        $initialList = $players;
        $this->homePlayers = array ();
        $this->awayPlayers = array ();
        $substitutes = false;
        $firstLine = true;

        while (!empty ($players))
            {
            $row = cutTextPiece ($players, '<tr', '</tr>', true);
            if (empty ($row))
                break;
            if ($initialList == $players)
                return $this->logError ("Errors while parsing players");

            if (false !== strpos ($row, 'Atsarginiai žaidėjai'))
                $substitutes = true;
            if (false !== strpos ($row, 'class="title"') || false !== strpos ($row, 'colspan="5"'))
                continue;
            $initialList = $players;

            list ($homeNo, $homePlayer, $awayNo, $awayPlayer) = $this->parsePlayersRow ($row);
            if (empty ($homePlayer) && empty ($awayPlayer))
                return $this->logError ("Cannot parse given URL player (h - ".htmlspecialchars ($row).")");
            
            if ($substitutes)
                $template = array ("unused" => $substitutes);
            else
                $template = array ("unused" => false, "from" => 0, "to" => 90);

            if ($firstLine)
                {
                $template["pos"] = "GK";
                $firstLine = false;
                }

            if (!empty ($homePlayer))
                {
                $found = false;
                foreach ($this->homePlayers as $player)
                    {
                    if ($player["name"] == $homePlayer)
                        {
                        $found = true;
                        break;
                        }
                    }
                if (!$found)
                    $this->homePlayers[] = array_merge (array ("name" => $homePlayer, "home" => true, "no" => $homeNo), $template);
                }
            if (!empty ($awayPlayer))
                {
                $found = false;
                foreach ($this->awayPlayers as $player)
                    {
                    if ($player["name"] == $homePlayer)
                        {
                        $found = true;
                        break;
                        }
                    }
                if (!$found)
                    $this->awayPlayers[] = array_merge (array ("name" => $awayPlayer, "home" => false, "no" => $awayNo), $template);
                }
            }
        }

    protected function retrievePlayerFromCell ($cell)
        {
        $pos = strpos ($cell, "<", 1);
        if (false !== $pos)
            $cell = substr ($cell, 0, $pos);

        return trim (strip_tags ($cell));
        }

    protected function parsePlayersRow ($row)
        {
        $pos1 = strpos ($row, "<th>");
        $pos2 = strpos ($row, '<td colspan="2">');
        if (false !== $pos2 && $pos1 > $pos2)
            {
            // skip home event
            cutTextPiece ($row, '<td colspan="2">', '</td>', true);
            $no1 = $player1 = NULL;
            }
        else
            {
            $no1 = cutTextPiece ($row, '<th>', '&nbsp;</th>', true);
            $player1 = $this->retrievePlayerFromCell (cutTextPiece ($row, '<td>', '</td>', true));
            }
            
        if (false === strpos ($row, 'colspan="2"'))
            {
            $no2 = cutTextPiece ($row, '<th>', '&nbsp;</th>', true);
            $player2 = $this->retrievePlayerFromCell (cutTextPiece ($row, '<td>', '</td>', true));
            }
        else
            $no2 = $player2 = NULL;

        return array ($no1, $player1, $no2, $player2);
        }

    protected function parseEventsRow ($row)
        {
        $homeEvent = null;
        $awayEvent = null;
        $pos1 = strpos ($row, "<th");
        $pos2 = strpos ($row, '<td class="last" colspan="3">');
        if (false !== $pos2 && $pos1 > $pos2)
            {
            // skip home event
            cutTextPiece ($row, '<td class="last" colspan="3">', '</td>', true);
            }
        else
            {
            $min = cutTextPiece ($row, '<th class="no">', '‘</th>', true);
            $eventType = cutTextPiece ($row, '<th><img src="images/icon_', '.gif" alt=""/></th>', true);
            $player = trim (cutTextPiece ($row, '<td class="last">', '</td>', true));
            
            if (empty ($player) || empty ($eventType))
                $this->logError ("No player or event type ($player, $eventType)");
            $homeEvent = new RawEvent ($min, $eventType, $player);
            }

        if (false === strpos ($row, 'colspan="3"'))
            {
            $min = cutTextPiece ($row, '<th class="no">', '‘</th>', true);
            $eventType = cutTextPiece ($row, '<th><img src="images/icon_', '.gif" alt=""/></th>', true);
            $player = trim (cutTextPiece ($row, '<td class="last">', '</td>', true));

            if (empty ($player) || empty ($eventType))
                $this->logError ("No player or event type ($player, $eventType)");
            $awayEvent = new RawEvent ($min, $eventType, $player);
            }
        
        return array ($homeEvent, $awayEvent);
        }

    protected function logError ($error, $returnValue = false)
        {
        $this->context->addError ($error);
        return $returnValue;
        }
        
    public static function createInstance ($context, $parent, $content, $url)
        {
        if (false != strpos ($url, "sfl.lt"))
            $result = new PreprocessedMatchUrlContentSfl ($context, $parent);
        else if (false != strpos ($url, "kaff.lt"))
            $result = new PreprocessedMatchUrlContentKaff ($context, $parent);
        else if (false != strpos ($url, ".saff.lt"))
            $result = new PreprocessedMatchUrlContentSaff ($context, $parent);
        else if (false != strpos ($url, "vaff.lt") || false != strpos ($url, "/vaff/"))
            $result = new PreprocessedMatchUrlContentVaff ($context, $parent);
        else if (false != strpos ($url, "uefa"))
            $result = new PreprocessedMatchUrlContentUefa ($context, $parent);
        else
            $result = new PreprocessedMatchUrlContent ($context, $parent);
        if (false === $result->initialize ($content))
            return false;
        return $result;
        }

    protected function initialize ($content)
        {
        $content = cutTextPiece ($content, '<div id="game_info">', "<div class=\"clearfooter\">");
        if (false === $content)
            return $this->logError ("Cannot parse given URL content");
        
        $description = cutTextPiece ($content, '<div class="row">', "</div>", true);
        if (false === $description)
            return $this->logError ("Cannot parse given URL description");

        if (false !== strpos ($content, 'Teisėjai:'))
            {
            $referees = cutTextPiece ($content, 'Teisėjai:', "</div>", true);
            if (false === $referees)
                return $this->logError ("Cannot parse given URL referees");
            }

        $score = cutTextPiece ($content, '<div class="score">', "</div>", true);
        if (false === $score)
            return $this->logError ("Cannot parse given URL description");
print "<pre>$score\n</pre>";

        $events = cutTextPiece ($content, '<table border="0" cellspacing="0" cellpadding="0" class="game_protocol">', "</table>", true);
        if (false === $events)
            return $this->logError ("Cannot parse given URL events");

        $players = cutTextPiece ($content, '<table border="0" cellspacing="0" cellpadding="0" class="game_players">', "</table>", true);
        if (false === $players)
            return $this->logError ("Cannot parse given URL players");

        preg_match ('/[0-9]+ - [0-9]+/u', $score, $matches);
        if (count ($matches) < 1)
            return $this->logError ("Cannot parse score");
        if (false === $this->setScore ($matches[0]))
            return $this->logError ("Cannot parse given URL score");

        $this->setDescription ($description);
        $this->setPlayers ($players);
        $this->setEvents ($events);
        
        if (!empty ($referees))
            {
            if (false === $this->setReferees ($referees))
                return false;
            }
        }

    protected function processEvents (&$players, $events)
        {
        if (empty ($events))
            return;

        $lastOut = null;
        foreach ($events as $event)
            {
            if (null !== $lastOut)
                {
                if (RawEvent::EVENT_IN != $event->eventType)
                    return $this->logError ("Player in and player out should be paired");

                $playerInKey = &$this->findPlayerIndex ($players, $event->player);
                if (false === $playerInKey)
                    {
                    return $this->logError ("Substitute player ({$event->player}) not found");
                    }

                $playerIn = $players[$playerInKey];
                unset ($players[$playerInKey]);

                $playerOutKey = $this->findPlayerIndex ($players, $lastOut);
                if (false === $playerOutKey)
                    return $this->logError ("Substituted player $lastOut not found");

                if (is_array ($playerOutKey))
                    {
                    $playerOut = &$players[$playerOutKey[0]]["substitute"];
                    }
                else
                    $playerOut = &$players[$playerOutKey];

                if (!empty ($playerOut["substitute"]))
                    return $this->logError ("Substituted player already substituted");

                $playerIn["from"] = $event->min;
                $playerIn["to"] = $playerOut["to"];
                $playerIn["unused"] = false;
                $playerOut["substitute"] = $playerIn;
                $playerOut["to"] = $event->min;

                $lastOut = null;
                continue;
                }

            if (RawEvent::EVENT_OUT == $event->eventType)
                $lastOut = $event->player;
            }
        }

    protected function findPlayerIndex ($players, $name)
        {
        foreach ($players as $key => $player)
            {
            if ($player["name"] == $name)
                {
                return $key;
                }

            if (!empty ($player["substitute"]))
                {
                $res = $this->findPlayerIndex (array ($player["substitute"]), $name);
                if (false !== $res)
                    {
                    if (is_array ($res))
                        return $this->logError ("Unexpected count of substitutes");
                    return array ($key, $res);
                    }
                }
            }
        return false;
        }

    protected function calculateTeamScores ($events, $home)
        {
        $halfTimeScore = 0;
        $score = 0;
        if (!empty ($events))
            {
            foreach ($events as $event)
                {
                $player = array ("name" => $event->player, "home" => $home);
                if (!empty ($event->url))
                    $player["url"] = $event->url;

                if (NULL !== $event->min)
                    {
                    if (preg_match ("#^([0-9]+)\+([0-9]+)$#", $event->min, $minMatches) > 0)
                        {
                        $player["min"] = $minMatches[1];
                        $player["extra"] = $minMatches[2];
                        }
                    else
                        $player["min"] = $event->min;
                    }

                if (RawEvent::EVENT_GOAL != $event->eventType && RawEvent::EVENT_OWN_GOAL != $event->eventType && RawEvent::EVENT_PENALTY != $event->eventType)
                    {
                    if (RawEvent::EVENT_YELLOW == $event->eventType)
                        $this->yellowCards[] = $player;
                    else if (RawEvent::EVENT_RED == $event->eventType || RawEvent::EVENT_YELLOW_RED == $event->eventType)
                        {
                        if (RawEvent::EVENT_YELLOW_RED == $event->eventType)
                            $player["yellow"] = true;
                        $this->redCards[] = $player;
                        }
                    else if (RawEvent::EVENT_PENALTY_MISS == $event->eventType)
                        $this->missedPenalties[] = $player;
                    continue;
                    }

                if (NULL === $event->min)
                    $halfTimeScore = NULL;
                if (NULL !== $halfTimeScore && $event->min <= 45)
                    $halfTimeScore++;
                $score++;

                if (RawEvent::EVENT_PENALTY == $event->eventType)
                    $player["pk"] = true;
                else if (RawEvent::EVENT_OWN_GOAL == $event->eventType)
                    $player["og"] = true;
                $this->goals[] = $player;
                }
            }

        return array ($score, $halfTimeScore);
        }

    protected function extractScorePiece ($score)
        {
        $score = trim ($score);
        
        if (preg_match ('#^([0-9]+) \([0-9]+\)$#', $score, $m) > 0)
            return $m[1];
        return $score;
        }

    protected function setScore ($score)
        {
        $score = trim (strip_tags ($score));
        $parts = preg_split ("#[:-]#", $score);
        if (count ($parts) < 2)
            return $this->logError ("Cannot parse score");

        $this->score = array ($this->extractScorePiece ($parts[0]), $this->extractScorePiece ($parts[1]));
        }

    protected function retrieveResult (&$match)
        {
        $this->goals = array ();
        $homeScores = $this->calculateTeamScores ($this->homeEvents, true);
        $awayScores = $this->calculateTeamScores ($this->awayEvents, false);
        $match["result"] = array ($homeScores[0], $awayScores[0]);

        if (!empty ($this->score) && $this->score != $match["result"])
            {
            $this->logError ("Calculated (".implode(":", $match["result"]).") and retrieved (".implode(":", $this->score).") scores do not match");
            $match["result"] = $this->score;
            }
        else if (NULL !== $homeScores[1] && NULL !== $awayScores[1])
            $match["resultHalfTime"] = array ($homeScores[1], $awayScores[1]);

        if (!empty ($this->goals))
            $match["goal"] = $this->goals;
        if (!empty ($this->yellowCards))
            $match["book"] = $this->yellowCards;
        if (!empty ($this->redCards))
            $match["sent"] = $this->redCards;
        if (!empty ($this->missedPenalties))
            $match["miss"] = $this->missedPenalties;
        }

    public function getMatch ()
        {
        if (false === $this->processEvents ($this->homePlayers, $this->homeEvents) ||
            false === $this->processEvents ($this->awayPlayers, $this->awayEvents))
            {
            return false;
            }

        $match = array
            (
            SubmitGame::MATCH_OUTCOME => SubmitGame::OUTCOME_NORMAL,
            "homePlayers" => $this->homePlayers,
            "awayPlayers" => $this->awayPlayers
            );

        $this->retrieveResult ($match);

        foreach ($this->referees as $key => $name)
            {
            if (preg_match ("#^(.+)\s*\((.+)\)$#", trim ($name), $refMatches) > 0)
                {
                $match[$key] = $refMatches[1]."+".$refMatches[2];
                $match[$key."City"] = $refMatches[2];
                }
            else
                $match[$key] = $name;
            }

        if (!empty ($this->spectators))
            $match["spectators"] = $this->spectators;
        if (!empty ($this->stadium))
            $match["stadium"] = $this->stadium;
        if (!empty ($this->date))
            $match["date"] = $this->date;
        if (!empty ($this->homeCoach))
            $match["homeCoach"] = $this->homeCoach;
        if (!empty ($this->awayCoach))
            $match["awayCoach"] = $this->awayCoach;

        return $match;
        }
    }
    
class RawEvent
    {
    public $min;
    public $eventType;
    public $player;
    public $url;

    const EVENT_GOAL = 113;
    const EVENT_OWN_GOAL = 122;
    const EVENT_PENALTY = 114;
    const EVENT_PENALTY_MISS = 125;
    const EVENT_RED = 116;
    const EVENT_YELLOW = 117;
    const EVENT_YELLOW_RED = 118;
    const EVENT_IN = 124;
    const EVENT_OUT = 224;

    public function __construct ($min, $eventType, $player, $url = null)
        {
        $this->min = $min;
        $this->url = $url;
        switch ($eventType)
            {
            case "113":
                $this->eventType = self::EVENT_GOAL;
                break;
            case "114":
                $this->eventType = self::EVENT_PENALTY;
                break;
            case "116":
                $this->eventType = self::EVENT_RED;
                break;
            case "117":
                $this->eventType = self::EVENT_YELLOW;
                break;
            case "118":
                $this->eventType = self::EVENT_YELLOW_RED;
                break;
            case "122":
                $this->eventType = self::EVENT_OWN_GOAL;
                break;
            case "124-1":
                $this->eventType = self::EVENT_IN;
                break;
            case "124":
                $this->eventType = self::EVENT_OUT;
                break;
            case "125":
                $this->eventType = self::EVENT_PENALTY_MISS;
                break;
            default:
                $this->eventType = $eventType;
            }

        $this->player = trim (strip_tags ($player));
        }
    }

class SflEvent extends RawEvent
    {
    public function __construct ($eventType, $player, $min, $url = null)
        {
        switch ($eventType)
            {
            case "red":
                $this->eventType = self::EVENT_RED;
                break;
            case "yellow":
                $this->eventType = self::EVENT_YELLOW;
                break;
            case "goal":
                $this->eventType = self::EVENT_GOAL;
                break;
            case "goalOwn":
                $this->eventType = self::EVENT_OWN_GOAL;
                break;
            default:
                $this->eventType = $eventType;
            }

        $this->player = trim ($player);
        if (NULL !== $min)
            $this->min = $min;
        $this->url = trim ($url);
        }
    }

class KaffEvent extends RawEvent
    {
    public function __construct ($eventType, $player, $min)
        {
        switch ($eventType)
            {
            case "Raudona kortelė":
                $this->eventType = self::EVENT_RED;
                break;
            case "Geltona kortelė":
                $this->eventType = self::EVENT_YELLOW;
                break;
            case "Antra geltona kortelė":
                $this->eventType = self::EVENT_YELLOW_RED;
                break;
            case "Įvartis":
                $this->eventType = self::EVENT_GOAL;
                break;
            case "11 m.":
                $this->eventType = self::EVENT_PENALTY;
                break;
            case "Miss":
                $this->eventType = self::EVENT_PENALTY_MISS;
                break;
            default:
                $this->eventType = $eventType;
            }

        $this->player = trim ($player);
        if (NULL !== $min)
            $this->min = $min;
        }
    }
    
class PreprocessedMatchUrlContentKaff extends PreprocessedMatchUrlContent
    {
    protected function initialize ($content)
        {
        $content = cutTextPiece ($content, '<div class="article">', '</tbody>');
        if (false === $content)
            return $this->logError ("Cannot parse given URL content");

        $homeTeam = NULL;
        $awayTeam = NULL;
        $score = NULL;
        $refereCount = 0;

        while (!empty ($content))
            {
            $part = cutTextPiece ($content, '<tr>', "</tr>", true);
            if (false === $part)
                return $this->logError ("Cannot parse given URL part");
            $part = trim ($part);
            
            if ($part == '<td colspan="3">&nbsp;</td>')
                continue;
            if ($part == '<td style="padding-left:15px;">&nbsp;</td>')
                break;
            if (NULL === $homeTeam)
                {
                $homeTeam = cutTextPiece ($part, '<td width="40%" align="right" style="border-bottom: solid 1px #000">', '</td');
                $awayTeam = cutTextPiece ($part, '<td width="40%" style="border-bottom: solid 1px #000">', '</td');
                if (empty ($homeTeam) || empty ($awayTeam))  
                    return $this->logError ("Cannot parse team name");
                $homeTeam = trim (strip_tags ($homeTeam));
                $awayTeam = trim (strip_tags ($awayTeam));
                continue;
                }

            $part = trim (strip_tags ($part));
            if (NULL === $score)
                {
                $score = $part;
                if (false === $this->setScore ($score))
                    return false;
                continue;
                }

            $parts = explode (":", $part, 2);
            if (1 == count ($parts))
                {
                if ($refereCount < 1 && $refereCount > 2)
                    return $this->logError ("Unexpected count of referees");

                $part = trim ($part);
                if (!empty ($part))
                    {
                    $this->referees["refereeA{$refereCount}"] = $part;
                    print "<pre>Asistentas $refereCount: $part\n</pre>";
                    }

                $refereCount++;
                continue;
                }

            list ($key, $val) = $parts;
            $val = trim ($val);
print "<pre>$key: $val\n</pre>";
            switch ($key)
                {
                case "Data":
                    $this->date = $val;
                    break;
                case "Laikas":
                    $this->date .= " ".$val;
                    break;
                case "Stadionas":
                    $this->stadium = $val;
                    break;
                case "Žiūrovų skaičius":
                    $this->spectators = $val;
                    break;
                case "Teisėjai":
                    if (!empty ($val))
                        $this->referees["referee"] = $val;
                    $refereCount++;
                    break;
                default:
                    return $this->logError ("Unexpected parameter found");
                }
            }

print "<pre>$score\n</pre>";

        $pos = strpos ($content, "<tbody>");
        if (false === $pos)
            return $this->logError ("Cannot parse given URL events");

        $content = substr ($content, $pos);

        $this->setEventsK ($content, $homeTeam, $awayTeam);
        }

    public function setEventsK ($text, $homeTeam, $awayTeam)
        {
        while (false !== ($goalLine = cutTextPiece ($text, '<tr>', "</tr>", true, true)))
            {
            $line = trim ($goalLine);
            $eventTime = cutTextPiece ($goalLine, '<td>', '</td>', true);
            $eventType = cutTextPiece ($goalLine, 'img name="', '"', true, true);
            if (false === $eventType)
                {
                if (false !== strpos ($goalLine, "Nerealizuotas 11m"))
                    $eventType = "Miss";
                else if (false !== strpos ($goalLine, "Įvartis į savo vartus"))
                    $eventType = RawEvent::EVENT_OWN_GOAL;
                else
                    return $this->logError ("Cannot parse event type '".htmlspecialchars ($line)."'");
                }
            else if (false !== strpos ($goalLine, "(11m)") || false !== strpos ($goalLine, "(11 m. baudinys)"))
                $eventType = "11 m.";
            $player = cutTextPiece ($goalLine, '<td>', '</td>', true);
            $team = cutTextPiece ($goalLine, '<td>', '</td>', true);

            if (false === $eventTime || false === $eventType || false === $player)
                {
                return $this->logError ("Cannot parse event '".htmlspecialchars ($line)."'");
                }

            $player = strip_tags ($player);
            $names = explode (",", $player, 2);
            $player = trim ($names[1])." ".trim ($names[0]);
            $event = new KaffEvent (trim ($eventType), trim ($player), trim ($eventTime));

            $homeEvent = !empty ($team) && 0 == strcasecmp (trim ($team), trim ($homeTeam));
            if (RawEvent::EVENT_OWN_GOAL == $eventType)
                $homeEvent = !$homeEvent;

            if ($homeEvent)
                $this->homeEvents[] = $event;
            else
                $this->awayEvents[] = $event;
            }
        

        }
    }

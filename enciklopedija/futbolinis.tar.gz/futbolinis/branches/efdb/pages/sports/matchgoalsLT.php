<?php
require_once (PATH."pages/sports/matchgoals.php");

class MatchGoalsLT extends MatchGoals
    {
    protected function getAssistModifier ($assistedPlayer, $assistedPlayerUrl, $own, $penalty)
        {
        $lng = Language::getInstance ($this->context);
        $player = $lng->changeCase ($assistedPlayer, Language::CASE_GENITIVE);
        $player = "<a href=\"$assistedPlayerUrl\" class=\"assisted\">$player</a>";
        if ($own)
            return "(į savus vartus po $player smūgio)";
        if ($penalty)
            return "(11 m. baudinys, uždirbtas $player)";
        return "(po $player perdavimo)";
        }

    }

<?php
require_once (PATH.'pages/sports/matchannouncement.php');

class StadiumMatches extends MatchAnnouncement
    {
    protected $stadiumId;

    public function __construct ($context, $stadiumId)
        {
        parent::__construct ($context, "announce", NULL);
        $this->stadiumId = $stadiumId;
        }

    protected function selectMatches ($now)
        {
        $collector = new MatchCollector ($this->context, true);
        return $collector->selectStadiumMatches ($now, $this->stadiumId, 10);
        }

    public function isVisible ($inline = false)
        {
        $parts = $this->getDisplayableParts ();
        return !empty ($parts);
        }
    }

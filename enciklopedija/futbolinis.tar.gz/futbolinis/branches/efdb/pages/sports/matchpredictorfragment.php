<?php
require_once (PATH.'pages/componentfragment.php');
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'inc/sports/common.php');
require_once (PATH.'inc/sports/predictortable.php');

class MatchPredictorFragment extends ComponentFragment
    {
    const PARAM_SEASON_ID = "seasonid";
    const PARAM_IMAGE_URL = "seasonid";

    protected function getAdditionalEditorFields ()
        {
        $arr = parent::getAdditionalEditorFields ();
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        $arr[] = new TextFieldTemplate ("fld", self::PARAM_IMAGE_URL, $this->getText ("Image:|predictor"),
                                                $this->getText ("Url of the image to show in the fragment"),
                                                false);

        return $arr;
        }

    protected function createComponent ($context, $prefix, $additionalParams)
        {
        $imageUrl = !empty ($additionalParams[self::PARAM_IMAGE_URL]) ? $additionalParams[self::PARAM_IMAGE_URL] : NULL;
        $seasonId = "s1";
        if (empty ($seasonId))
            return new ErrorComponent ($prefix, $context,
                                       $context->getText ("Season is not specified"));

        return new MatchPredictorComponent ($context, $imageUrl, $this->getTitle (), $this->getDisplayedText (), $this->getIcon ());
        }
    }

class MatchPredictorComponent extends Component
    {
    protected $imageUrl;
    protected $title;
    protected $description;
    protected $predictorGamesTable;
    protected $predictionsTable;
    protected $predictorSeasonsTable;
    protected $gamesToPredict = NULL;

    public function __construct ($context, $imageUrl, $title, $description, $icon)
        {
        parent::__construct ("prefix", $context);
        $this->imageUrl = $imageUrl;
        $this->title = $title;
        $this->description = $description;
        $this->predictorGamesTable = new PredictorGameTable ($context);
        $this->predictionsTable = new PredictorGuessTable ($context);
        $this->predictorSeasonsTable = new PredictorSeasonTable ($context);
        $this->icon = $icon;

        $context->addStyleSheet ("sports");
        $context->addScriptFile ("sports");
        }

    public function getIcon ()
        {
        return $this->icon;
        }

    public function processInput ($context, &$request)
        {
        if (!empty ($_REQUEST["create"]))
            {
            if (!$this->predictorGamesTable->tableExists () && !$this->predictorGamesTable->createTable ())
                {
                $this->context->addError ("Unable to create the database table.");
                }
            if (!$this->predictionsTable->tableExists () && !$this->predictionsTable->createTable ())
                {
                $this->context->addError ("Unable to create the database table.");
                }
            if (!$this->predictorSeasonsTable->tableExists () && !$this->predictorSeasonsTable->createTable ())
                {
                $this->context->addError ("Unable to create the database table.");
                }
            }

        return true;
        }

    public function getImageUrl ()
        {
        return $this->imageUrl;
        }

    public function getTitle ()
        {
        return $this->title;
        }

    public function getDisplayedText ()
        {
        return $this->description;
        }

    public function getInvitationText ()
        {
        if ($this->context->getCurrentUser () <= 0)
            {
            $loginUrl = $this->context->processUrl ("login.php?".Constants::PARAM_RETURN_TO."=".rawurlencode ($this->context->getAdjustedUrl (array (Constants::PARAM_RETURN_TO => NULL))), true);
            $registerUrl = $this->context->processUrl ("index.php?c=CreateUser", true);
            return $this->getText ("You must be logged in to submit predictions. Please <a href=\"[_0]\" target=\"_top\">register</a> or <a href=\"[_1]\" target=\"_top\">login</a> if you are already registered.", $registerUrl, $loginUrl);
            }

        $rows = $this->selectGames ();
        if (empty ($rows))
            {
            if (false === $rows && !$this->predictorGamesTable->tableExists ())
                {
                $createUrl = $this->context->getAdjustedUrl (array ("create" => "1"));
                return $this->getText ("Database tables required for predictions system do not exist. Click <a href=\"[_0]\">this link</a> to create the tables.", $createUrl);
                }

            return $this->getText ("No upcomming games.");
            }
        }

    public function getPlaceholderText ()
        {
        return $this->getText ("Loading... (if this message does not go away in few seconds, you might need to enable scripts - otherwise you will not be able to submit your guesses)");
        }

    public function getGamesTableCaption ()
        {
        return $this->getText ("Upcomming games|predictor");
        }

    public function getGuessText ()
        {
        return $this->getText ("Guess|predictor");
        }

    public function getGuessResultLabel ()
        {
        return $this->getText ("Guess the result of this match:|predictor");
        }

    public function getSubmitText ()
        {
        return $this->getText ("Submit|predictor");
        }

    public function getCloseText ()
        {
        return $this->getText ("Close");
        }

    public function getGuessServiceUrl ($edit = false)
        {
        return $this->context->processUrl ('index.php?service=sports/PredictorService&action=guess'. ($edit ? '&edit=1' : ''), true);
        }

    public function getFullListLabel ()
        {
        return $this->getText ("Full list");
        }

    public function getFullListUrl ()
        {
        return $this->context->processUrl ("index.php?c=sports/PredictorList", true);
        }

    public function getInitializeScript ($placeholderId, $listPanelId)
        {
        $rows = $this->selectGames ();
        if (!empty ($rows))
            return "predictor_attach (\"$placeholderId\", \"$listPanelId\");";
        return NULL;
        }

     function selectLeaders ()
        {
        $cache = Cache::getInstance (Sports::TABLE_MATCH, 6*60*60);
        $cacheId = "predictorleaders_15";

        if (false === ($rows = $cache->get ($cacheId)))
            {
            $rows = $this->predictionsTable->selectLeaders (NULL, 15, true);
            $cache->save ($rows, $cacheId);
            }

        return $rows;
        }

     function selectGames ()
        {
        if (NULL !== $this->gamesToPredict)
            return $this->gamesToPredict;

        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $seasonTable = new PredictorSeasonTable ($this->context);
        
        $joinCriteria = array (new JoinColumnsCriterion (PredictorGameTable::COL_SEASON_ID, PredictorSeasonTable::COL_ID));
        $joins[] = $seasonTable->createQuery (array (), $joinCriteria);

        $joinCriterion = array ();
        $joinCriterion[] = new JoinColumnsCriterion (PredictorGameTable::COL_MATCH_ID, $matchesTable->getIdColumn ());
        $joinCriterion[] = new GtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d G:i:s", time ()));
        $params = array (OrderBy::create ("c_".Sports::COL_MATCH_DATE));
        $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id");
        $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id");

        $joins[] = $matchesTable->createQuery (array ("c_".Sports::COL_MATCH_DATE, $homeTeamColumn, $awayTeamColumn),
                                               $joinCriterion, NULL, $params);

        $joinCriterion = array ();
        $joinCriterion[] = new JoinColumnsCriterion (PredictorGameTable::COL_ID, PredictorGuessTable::COL_GAME_ID);
        $joinCriterion[] = new JoinChildCriterion (PredictorGuessTable::COL_USER_ID, $this->context->getCurrentUser ());
        $join = $this->predictionsTable->createQuery (array (PredictorGuessTable::COL_GOALS_HOME, PredictorGuessTable::COL_GOALS_AWAY), $joinCriterion);
        $join->joinType = Constants::JOIN_LEFT_OUTER;
        $joins[] = $join;

        $rows = $this->predictorGamesTable->selectBy (array (PredictorGameTable::COL_ID, PredictorGameTable::COL_MATCH_ID, PredictorGameTable::COL_ANNOUNCEMENT_TEXT),
                                                      NULL, $joins);

        if (!empty ($rows))
            {
            $lng = Language::getInstance ($this->context);
            $teamIds = array ();
            foreach ($rows as $row)
                {
                $teamIds[] = $row[$homeTeamColumn];
                $teamIds[] = $row[$awayTeamColumn];
                }

            $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);
            foreach ($rows as &$row)
                {
                $row["home"] = $teamLabels[$row[$homeTeamColumn]];
                $row["away"] = $teamLabels[$row[$awayTeamColumn]];
                $row["date"] = $lng->dateToLongString ($row["c_".Sports::COL_MATCH_DATE]);
                $row["id"] = $row[PredictorGameTable::COL_ID];
                $row["announcement"] = $row[PredictorGameTable::COL_ANNOUNCEMENT_TEXT];

                $matchId = $row[PredictorGameTable::COL_MATCH_ID];
                $table = $matchesTable->getName();
                $url = $this->context->chooseUrl ("talk/_$table/$matchId",
                                                  "index.php?c=Discussions&sc=_$table&id=$matchId");

                $row["announcement"] .= "\n\n";
                $row["announcement"] .= $this->getText ("Check that others think in <a href=\"[_0]\">match discussions page</a>.", $url);
                if (NULL !== $row[PredictorGuessTable::COL_GOALS_HOME])
                    {
                    $row["result"] = $row[PredictorGuessTable::COL_GOALS_HOME].":".$row[PredictorGuessTable::COL_GOALS_AWAY];
                    $row["resultH"] = $row[PredictorGuessTable::COL_GOALS_HOME];
                    $row["resultA"] = $row[PredictorGuessTable::COL_GOALS_AWAY];
                    }
                else
                    $row["result"] = NULL;
                }
            }

        $this->gamesToPredict = $rows;
        return $this->gamesToPredict;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "sports/matchpredictor";
        }
    }

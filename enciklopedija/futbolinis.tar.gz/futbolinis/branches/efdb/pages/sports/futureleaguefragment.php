<?php
require_once (PATH.'pages/sports/baseleaguefragment.php');
require_once (PATH.'pages/sports/leagueprojectioncomponent.php');

class FutureLeagueFragment extends BaseLeagueFragment
    {
    const ITEMS_SHOWN = 5;

    public function showHeader ()
        {
        return true;
        }

    protected function createLeagueDependentComponent ($context, $prefix, $dbtable, $leagueId)
        {
        $criteria = array (new EqCriterion ($dbtable->getIdColumn (), $leagueId));
        $parentColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_LEAGUE, Sports::TABLE_LEAGUE."_id");
        $columns = array ($dbtable->getIdColumn (), $parentColumn, Sports::COL_COMPETITION_SYSTEM, Sports::COL_COMPETITION_STARTS);
        $row = $dbtable->selectSingleBy ($columns, $criteria);
        if (empty ($row))
            return new ErrorComponent ($prefix, $context,
                                       $context->getText ("Competition was not found"));
        return new LeagueProjectionComponent ($context, $dbtable, $leagueId, $row);
        }
    }

<?php
require_once (PATH."inc/sports/constants.php");
require_once (PATH."inc/sports/common.php");
require_once (PATH."inc/sports/scorecollector.php");
require_once (PATH."inc/sports/statistics.php");
require_once (PATH."pages/statisticssection.php");

class LeagueProjectionComponent extends Component
    {
    protected $leagueId;
    protected $parentId;
    protected $startDate;

    public function __construct ($context, $table, $leagueId, $instanceRow)
        {
        $parentColumn = "f_".Sports::COL_COMPETITION_LEAGUE."_".Sports::TABLE_LEAGUE."_id";
        $this->parentId = $instanceRow[$parentColumn];
        $this->leagueId = $leagueId;
        $this->startDate = $instanceRow["c_".Sports::COL_COMPETITION_STARTS];
        parent::__construct ("a", $context, $table->getName ());

        $context->addStyleSheet ("sports");
        }

    public function isVisible ()
        {
        return count ($this->components) > 0;
        }

    public function getTitle ()
        {
        return $this->getText ("Competition overview");
        }

    public function getTemplateName ()
        {
        return "sports/leagueoverview";
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function ensureChildren ($context, $request)
        {
        if (empty ($this->leagueId))
            return true;

        $teamIds = CompetitionStatistics::retrieveTeamsWithFixedStatsByCriteria ($context, Sports::TABLE_TEAMLEAGUESEASON,
                                                             new EqCriterion ("f_season_competitionstage_id", $this->leagueId),
                                                             NULL, NULL, true);

        if (!empty ($teamIds))
            {
            $teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
            $logos = SportsHelper::getTeamLogos ($context, $teamIds, $this->startDate);
            $labels = SportsHelper::getTeamLabels ($context, $teamIds, $this->startDate);
            $lng = Language::getInstance ($this->context);
            $teamIds = $this->sortTeams ($context, $teamIds);

            foreach ($teamIds as $teamId)
                {
                if (empty ($labels[$teamId]))
                    continue;
                $componentId = "s$teamId";
                $label = $lng->beautifyTeamLabel ($labels[$teamId]);
                $component = new TeamOverviewStatistics ($this, $componentId, $label, $teamId, $this->leagueId);
                if (!empty ($logos[$teamId]))
                    $component->setLogo ($logos[$teamId]);
                $this->addComponent ($request, $componentId, $component);
                }
            }

        return parent::ensureChildren ($context, $request);
        }

    public function sortTeams ($context, $teamIds)
        {
        $competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $parentColumn = "f_".Sports::COL_COMPETITION_LEAGUE."_".Sports::TABLE_LEAGUE."_id";
        $criteria[] = new EqCriterion ($parentColumn, $this->parentId);
        $criteria[] = new LtCriterion ("c_".Sports::COL_COMPETITION_STARTS, $this->startDate);
        $row = $competitionsTable->selectSingleBy (array ($competitionsTable->getIdColumn ()), $criteria, NULL, array (OrderBy::create ("c_".Sports::COL_COMPETITION_STARTS, false), new LimitResults (0,1)));
        if (empty ($row))
            return $teamIds;

        $id = $row[$competitionsTable->getIdColumn ()];
        
        $criteria = array (new EqCriterion ("f_season_competitionstage_id", $id));
        $criteria[] = new InCriterion ("team_id", $teamIds);
        $rows = CompetitionStatistics::retrieveTeamsWithFixedStatsByCriteria ($context, Sports::TABLE_TEAMLEAGUESEASON,
                                                             $criteria, array ("c_place"), NULL, false);
        if (empty ($rows))
            return $teamIds;

        $newIds = array ();
        $maxPlace = 1;
        foreach ($rows as $row)
            {
            $place = $row["c_place"];
            if (empty ($place))
                continue;

            $newIds[$place] = $row['team_id'];
            if ($place > $maxPlace)
                $maxPlace = $place;
            }

        ksort ($newIds);

        foreach ($teamIds as $id)
            {
            if (false === array_search ($id, $newIds))
                $newIds[++$maxPlace] = $id;
            }

        return $newIds;
        }

    public function getNoScriptText ()
        {
        return $this->getText ("Please enable script support in your browser to view team overview");
        }
    }

class TeamOverviewStatistics extends StatisticsSection
    {
    private $logo = NULL;
    private $teamId = NULL;
    private $competitionId = NULL;

    public function __construct ($parent, $id, $title, $teamId, $competitionId)
        {
        parent::__construct ($parent, $id, $title, NULL, NULL);
        $this->teamId = $teamId;
        $this->competitionId = $competitionId;
        }

    public function getTemplateName ()
        {
        return "sports/teamoverviewstats";
        }

    public function setLogo ($logo)
        {
        $this->logo = $logo;
        }
    public function getLogo ()
        {
        return $this->logo;
        }

    public function getOverviewTitle ()
        {
        return $this->getText ("Team overview");
        }

    public function getChangesTitle ()
        {
        return $this->getText ("Team pre-season changes");
        }

    public function getStatsUrl ($componentId)
        {
        $params = array ("el=$componentId", "stats=general", "teamid=$this->teamId");
        $url = $this->context->chooseUrl ("stats/".Sports::TABLE_COMPETITIONSTAGE."/$this->competitionId",
                                          "index.php?c=ContentPage&mode=stats&tn=".Sports::TABLE_COMPETITIONSTAGE."&id=$this->competitionId", implode ("&", $params));
        return $url;
        }
    }

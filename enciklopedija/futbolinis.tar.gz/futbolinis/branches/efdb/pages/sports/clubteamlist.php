<?php
require_once (PATH."pages/contentpreview.php");

class ClubTeamList extends ContentPreview
    {
    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        $params[] = new OrderBy (array (
                            new OrderByColumn ("type", true, 1, true),
                            new OrderByColumn ("c_from", false, 2, true),
                            ));
        }
    }

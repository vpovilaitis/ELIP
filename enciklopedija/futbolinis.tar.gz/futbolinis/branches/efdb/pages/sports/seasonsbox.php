<?php
require_once (PATH."pages/navigationbox.php");

class SeasonsBox extends NavigationBox
    {
    protected $competitionId;
    protected $lng;
    const MAX_ITEMS = 4;

    public function __construct ($context, $dbtable, $currentItemId)
        {
        parent::__construct ($context, $dbtable, $currentItemId, array ("seasons_id"));
        $this->lng = Language::getInstance ($context);
        }

    public function selectNeighbours ($context, &$request)
        {
        $idColumn = $this->idColumns[0];
        $columns = array ("start");
        $criteria = array (new EqCriterion ($idColumn, implode ("_", $this->currentItemId)));
        $row = $this->dbtable->selectSingleBy ($columns, $criteria);
        if (empty ($row))
            return false;

        $columns = array ($idColumn, "displayname");
        $criteria = array (new GtCriterion ("c_start", $row["c_start"] - self::MAX_ITEMS - 2),
                           new LtCriterion ("c_start", $row["c_start"] + self::MAX_ITEMS + 2));

        $rows = $this->dbtable->selectBy ($columns, $criteria);
        if (empty ($rows))
            return false;

        $currentFound = false;
        $trimmedStart = false;
        $preceededItems = array ();
        $succeededItems = array ();
        foreach ($rows as $row)
            {
            if ($row[$idColumn] == $this->currentItemId[0])
                {
                $currentFound = true;
                $preceededItems[] = $row;
                continue;
                }

            if (!$currentFound)
                {
                if (count ($preceededItems) == self::MAX_ITEMS)
                    {
                    array_shift ($preceededItems);
                    $trimmedStart = true;
                    }
                $preceededItems[] = $row;
                }
            else
                {
                if (count ($succeededItems) == self::MAX_ITEMS)
                    {
                    $succeededItems[] = "...";
                    break;
                    }

                $succeededItems[] = $row;
                }
            }

        if ($trimmedStart)
            array_unshift ($preceededItems, "...");

        return array_merge ($preceededItems, $succeededItems);
        }

    public function createItem ($row, $id)
        {
        return array
                (
                self::LABEL => $row["c_displayname"],
                );
        }

    protected function constructDisplayRow ($row, $id)
        {
        if ("..." == $row)
            return array ("current" => true, "labels" => array (self::LABEL => "..."));

        return parent::constructDisplayRow ($row, $id);
        }

    public function getTitle ()
        {
        return $this->getText ("Neighbours");
        }

    public function getCssClass ()
        {
        return "clubteams";
        }
    }

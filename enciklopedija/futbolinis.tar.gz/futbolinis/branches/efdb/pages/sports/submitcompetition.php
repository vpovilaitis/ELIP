<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/relationfields.php');
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'pages/sports/submitleaguescores.php');

class SubmitCompetition extends SubmitLeagueScores
    {
    protected $teams = array ();

    const PARAM_CREATE = "createcompetition";
    const PARAM_COMPETITION = "competition";
    const PARAM_LEVEL = "level";
    const PARAM_YEAR = Sports::COL_COMPETITION_SEASON;
    protected $competitionId = NULL;

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ("Create season");
        return true;
        }

    public function processCompetitionField ($context, &$request)
        {
        $this->createCommonFields ();
        $this->competitionField->processInput ($context, $request);
        if (empty ($request[self::PARAM_YEAR]))
            return $this->logError ("Please enter a competition season", true);
        else if (empty ($request[Sports::COL_COMPETITION_REGION]))
            return $this->logError ("Please enter the country", true);
        else if (!isset ($request[self::PARAM_LEVEL]))
            return $this->logError ("Please enter the level", true);

        if (!empty ($request[Sports::COL_COMPETITION_REGION]) && !empty ($request[self::PARAM_YEAR]) && !empty ($request[self::PARAM_LEVEL]))
            {
            $competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);

            if (empty ($competitionsTable))
                {
                $this->addError ("Invalid parameters passed (requested data table not configured)");
                return true;
                }

            $isCup = !is_numeric ($request[self::PARAM_LEVEL]);
            $level = NULL;
            $name = NULL;
            switch ($request[self::PARAM_LEVEL])
                {
                case 't':
                    $level = 0;
                    $name = "National cup";
                    break;
                case 'l':
                    $level = 1;
                    $name = "League cup";
                    break;
                case 's':
                    $level = 2;
                    $name = "Supercup";
                    break;
                default:
                    $level = $request[self::PARAM_LEVEL] + 1;
                    switch ($level)
                        {
                        case '1':
                            $name = "Premier league";
                            break;
                        case '2':
                            $name = "2nd tier";
                            break;
                        case '3':
                            $name = "3rd tier";
                            break;
                        default:
                            $name = $level."th tier";
                            break;
                        }
                    break;
                }

            // f_region_country_id 	c_iscup 	c_level 	f_season_seasons_id 	c_zone
            $criteria[] = new EqCriterion (Sports::COL_COMPETITION_REGION, $request[Sports::COL_COMPETITION_REGION]);
            $criteria[] = new EqCriterion (Sports::COL_COMPETITION_SEASON, $request[Sports::COL_COMPETITION_SEASON]);
            $criteria[] = new EqCriterion ("c_".Sports::COL_COMPETITION_ISCUP, $isCup ? 2 : 1);
            $criteria[] = new EqCriterion ("c_".Sports::COL_COMPETITION_LEVEL, $level);
            if (!empty ($request["zone"]))
                $criteria[] = new EqCriterion ("c_zone", $request["zone"]);

            $columns = array ($competitionsTable->getIdColumn (), ContentTable::COL_DISPLAY_NAME);
            $rows = $competitionsTable->selectBy ($columns, $criteria, NULL, NULL);

            if (empty ($rows))
                {
                $this->writeLine ('Creating new competition season...');
                $values = array (Sports::COL_COMPETITION_REGION => $request[Sports::COL_COMPETITION_REGION],
                                 Sports::COL_COMPETITION_SEASON => $request[Sports::COL_COMPETITION_SEASON],
                                 Sports::COL_COMPETITION_ISCUP => $isCup ? 2 : 1,
                                 Sports::COL_COMPETITION_LEVEL => $level,
                                 "zone" => $request["zone"]);
                $this->competitionId = $competitionsTable->insertRecord ($values);// $competitionsTable->createFromLabel ($filter);
                if (false === $this->competitionId)
                    return $this->logError ("Could not create the competition", true);

                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $competitionsTable,
                                                                             $competitionsTable->getId (), $this->competitionId);
                $this->writeLine ('New <a href="'.$url.'">season record</a> was created');
                }
            else if (count ($rows) > 1)
                {
                $err = "Too many competitions matching the criteria";
                $this->addError ($err);
                }
            else
                {
                $this->competitionId = $rows[0][$competitionsTable->getIdColumn ()];
                $competitionName = $competitionsTable->getDisplayName ($rows[0]);
                }

/*
            if (!empty ($this->competitionId))
                {
                if (empty ($competitionName))
                    $competitionName = $competitionsTable->getDisplayNameById (explode ("_", $this->competitionId), true);
                $this->competitionField->forceValue ($request, $this->competitionId, $competitionName);
                }
*/
            }
        else
            $this->writeLine ('Incorrect parameters');

        }

    protected function getTemplateName ()
        {
        return "sports/submitcompetition";
        }

    public function getCompetitionFields ()
        {
        if (empty ($this->dbtable))
            return NULL;

        $this->createCommonFields ();
        /*
        $competitionId = $this->competitionField->getValueForDB ($this->context, $this->request);
        if (!empty ($competitionId))
            return array ($this->competitionField);
        */

        $level = new DropDownFieldTemplate ("", self::PARAM_LEVEL, "Level:", "Level",
                                             array (0 => "0 - Premier league",
                                                    1 => "1 - 2nd tier",
                                                    2 => "2 - 3rd tier",
                                                    "t" => "t - National cup",
                                                    "l" => "l - League cup",
                                                    "s" => "s - Supercup",
                                                    )
                                            );
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        $column = clone $dbtable->findColumn (Sports::COL_COMPETITION_REGION);
        $column->inputType = MetaDataColumns::INPUT_AUTOCOMPLETE;
        $countryField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
        $countryField->label = "Country:";

        $column = clone $dbtable->findColumn (Sports::COL_COMPETITION_SEASON);
        $column->inputType = MetaDataColumns::INPUT_AUTOCOMPLETE;
        $seasonField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
        $seasonField->label = "Year(s):";
        $arr = array
            (
            $countryField, // new TextFieldTemplate ("country", self::PARAM_COUNTRY, "Country:", "Country", 12),
            $level,
            new TextFieldTemplate ("zone", "zone", "Zone:", "Zone (optional)", 12),
            $seasonField, // new IntFieldTemplate ("year:", self::PARAM_YEAR, "Year(s):", "Competition year"),
            //new TextFieldTemplate ("competition", self::PARAM_COMPETITION, "Competition:", "Competition name", 32),
            );

        /*
        foreach ($arr as &$field)
            {
            if (NULL === $field)
                continue;

            $field->cssClass = "";
            if ($field instanceof IntFieldTemplate)
                $field->size = 4;
            }
        */
        return $arr;
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;

        $this->createCommonFields ();
        $format = new DropDownFieldTemplate ("", "format", "Format:", "How lines should be parsed",
                                             array (//self::FORMAT_FULL => "Full. Example - 1 Zalgiris Vilnius 20 17 2 1 101- 12 89 53",
                                                    self::FORMAT_EXTENDED => "Extended. Example - 1 Zalgiris Vilnius 20 17 2 1 101-12 53",
                                                    self::FORMAT_MINI => "Mini. Example - 1 Minija Kretinga  20  81:16  36",
                                                    )
                                            );

        $arr = $this->getCompetitionFields ();
        $arr[] = $format;
        $arr[] = new LongTextFieldTemplate ("", "parse", "Results:", "Enter results");
        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));
        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }

    public function collectInputData ($context, &$request)
        {
        $this->createCommonFields ();
        if (false === $this->processCompetitionField ($context, $request))
            return false;

        return parent::collectInputData ($context, $request);
        }

    public function validateInput ($context, &$results)
        {
        if (empty ($results))
            return true;

        $res = true;
        foreach ($results as &$resultLine)
            {
            if (false === $this->prepareResultLine ($context, $resultLine))
                $res = false;
            }

        return $res;
        }

    protected function onInputFieldCollected ($context, &$request, $type, $key, $val)
        {
        if (!empty ($val))
            {
            switch ($type)
                {
                case "team":
                    $this->teams[$key] = $val;
                    break;
                }
            }
        }

    public function prepareResultLine ($context, &$result)
        {
        $team = $result["label"];
        $requestKey = $this->encodeKey ($team);
        $recognized = array_key_exists ($requestKey, $this->teams);

        if ($recognized)
            {
            $result["team_id"] = $this->teams[$requestKey];
            }

        $id = $this->updateField ("team", Constants::PARENT, $requestKey, $team);
        if (!empty ($id))
            {
            $result["team_id"] = $id;
            }

        if (empty ($result["team_id"]))
            {
            $this->hasUnrecognizedItems = true;
            if (false === array_search ("team", $this->fieldsNotReady))
                {
                $this->logError ("Unrecognized teams ('$team', ...)");
                $this->fieldsNotReady[] = "team";
                }
            }
        }

    public function saveInput ($context, &$request, &$results)
        {
        if (empty ($results))
            return $this->logError ("No results enterred");

        if (empty ($this->competitionId))
            return $this->logError ("No competition enterred");

        foreach ($results as &$resultLine)
            {
            if (false === $this->saveResultsLine ($context, $this->competitionId, $resultLine))
                {
                if (!isset ($res)) // if failed on first line, terminate
                    return false;

                // otherwise try to save other lines
                $res = false;
                }
            else
                {
                if (!isset ($res))
                    $res = true;
                $this->writeLine ("Participant added");
                }
            }

        return $res;
        }

    public function saveResultsLine ($context, $competitionId, &$result)
        {
        $values = array ("season" => $competitionId);
        foreach ($result as $key => $value)
            {
            if ("label" == $key)
                continue;

            if ("team_id" == $key)
                $values[$key] = $value[0];
            else
                $values["c_".$key] = $value;
            }

        $id = $this->dbtable->insertRecord ($values);
        if (empty ($id))
            return false;
        }

    protected function createField ($type, $columnName, $key)
        {
        return new RelationAutocompleteField ("", $this->dbtable->getParentTable (),
                                              "res_{$type}_".$key, $key, "Team", true);
        }
    }

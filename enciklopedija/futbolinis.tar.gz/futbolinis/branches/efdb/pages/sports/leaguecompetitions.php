<?php
require_once (PATH."pages/contentpreview.php");
require_once (PATH."inc/sports/constants.php");

class LeagueCompetitions extends ContentPreview
    {
    public function getPageSize ()
        {
        return 100;
        }

    protected function prepareRowCountQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        parent::prepareRowCountQuery ($resultColumns, $criteria, $joins, $params);

        $criteria[] = new IsNullCriterion (Sports::COL_COMPETITION_PARENT);
        }

    public function select ($context, $criteria = NULL, $mode = 0)
        {
        $rows = parent::select ($context, $criteria, $mode);
        if (empty ($rows))
            return $rows;
        return array_reverse ($rows);
        }
    }

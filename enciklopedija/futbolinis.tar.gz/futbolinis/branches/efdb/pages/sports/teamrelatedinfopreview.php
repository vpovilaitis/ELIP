<?php

require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'pages/contentpreview.php');

class TeamRelatedInfoPreview extends ContentPreview
    {

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        $ret = parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        switch ($this->dbtable->getName())
            {
            case Sports::TABLE_TEAMPLAYER:
                $columns = array (Sports::COL_TEAMPLAYER_LOANED_FROM, Sports::COL_TEAMPLAYER_TEAM);
                break;
            case Sports::TABLE_TEAMSTAFF:
                break;
            }

        if (!empty ($columns))
            {
            foreach ($columns as $col)
                {
                $idCol = ContentTable::generateForeignKeyColumn ($col, Sports::TABLE_TEAM."_id");
                if (false !== ($pos = array_search ($col, $resultColumns)))
                    $resultColumns[$pos] = $idCol;
                }
            }
        return $ret;
        }
    public function select ($context, $criteria = NULL)
        {
        $ret = parent::select ($context, $criteria);
        if (empty ($ret))
            return $ret;

        switch ($this->dbtable->getName())
            {
            case Sports::TABLE_TEAMPLAYER:
                $columns = array (Sports::COL_TEAMPLAYER_LOANED_FROM, Sports::COL_TEAMPLAYER_TEAM);
                $startColumn = Sports::COL_TEAMPLAYER_STARTED;
                $endColumn = Sports::COL_TEAMPLAYER_ENDED;
                break;
            case Sports::TABLE_TEAMSTAFF:
                $columns = array (Constants::PARENT);
                $startColumn = Sports::COL_TEAMSTAFF_STARTED;
                $endColumn = Sports::COL_TEAMSTAFF_ENDED;
                break;
            default:
                return $ret;
            }

        $startColumn = "c_".$startColumn;
        $endColumn = "c_".$endColumn;
        $teamIdsWithDates = array ();
        foreach ($ret as $row)
            {
            $start = $row[$startColumn];
            $end = $row[$endColumn];
            foreach ($columns as $col)
                {
                if (Constants::PARENT == $col)
                    $idCol = Sports::TABLE_TEAM."_id";
                else
                    $idCol = ContentTable::generateForeignKeyColumn ($col, Sports::TABLE_TEAM."_id");
                if (empty ($row[$idCol]))
                    continue;
                if (!empty ($start))
                    $teamIdsWithDates[] = array ($row[$idCol], $start);
                if ($end != $start && !empty ($end))
                    $teamIdsWithDates[] = array ($row[$idCol], $end);
                else if (empty ($start) && empty ($end))
                    $teamIdsWithDates[] = array ($row[$idCol], date ("Y-m-d"));
                }
            }

        if (empty ($teamIdsWithDates))
            return $ret;

        $labelsByTeam = SportsHelper::getTeamLabelsByDates ($this->context, $teamIdsWithDates);
        foreach ($ret as &$row)
            {
            $start = $row[$startColumn];
            $end = $row[$endColumn];
            foreach ($columns as $col)
                {
                if (Constants::PARENT == $col)
                    $idCol = Sports::TABLE_TEAM."_id";
                else
                    {
                    $idCol = ContentTable::generateForeignKeyColumn ($col, Sports::TABLE_TEAM."_id");
                    $row[$col] = array ($row[$idCol]);
                    }

                if (empty ($row[$idCol]))
                    continue;

                $labelStart = $labelsByTeam[$row[$idCol]][$start];
                $labelEnd = $labelsByTeam[$row[$idCol]][$end];
                if ($labelStart != $labelEnd)
                    {
                    if (empty ($labelStart))
                        $label = $labelEnd;
                    else if (empty ($labelEnd))
                        $label = $labelStart;
                    else
                        $label = "$labelEnd ($labelStart)";
                    }
                else
                    $label = $labelStart;

                $row[$col.".".ContentTable::COL_DISPLAY_NAME] = $label;
                }
            }

        return $ret;
        }
    }

<?php

require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'pages/contentpreview.php');

class RefereeSeasonRatings extends ContentPreview
    {
    protected function getFilterCriteria ()
        {
        $criteria = parent::getFilterCriteria ();
        $season = !empty ($this->context->request["season"]) ? $this->context->request["season"] : NULL;
        $tp = !empty ($this->context->request["tp"]) ? $this->context->request["tp"] : NULL;

        if (!empty ($season))
            $criteria[] = new EqCriterion (Sports::COL_REFEREERATING_SEASON, $season);
        if (!empty ($tp))
            $criteria[] = new EqCriterion (Sports::COL_REFEREERATING_TYPE, $tp);

        return $criteria;
        }

    public function getSearchFields ()
        {
        return NULL;
        }
    }

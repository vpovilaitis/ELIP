<?php
require_once (PATH.'inc/sports/predictortable.php');
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'inc/sports/common.php');

class PredictorList extends Page
    {
    protected $dbtable;

    public function __construct ($context, $request)
        {
        $this->dbtable = new PredictorGuessTable ($context);
        $context->addStyleSheet ("sports");
        parent::__construct ($context, NULL, PredictorGameTable::TABLE_SCOPE, PredictorGameTable::TABLE_NAME);
        $this->lng = Language::getInstance ($context);
        }

    public function ensureTitle ($context, &$request)
        {
        parent::ensureTitle ($context, $request);
        $context->setTitle ($this->getTitle ());
        return true;
        }

    public function getTitle ()
        {
        return $this->getText ("Predictor top-guessers");
        }

    public function getCountLabel ()
        {
        return $this->getText ("Gueses");
        }

    public function getGuessedOutcomeLabel ($short = false)
        {
        if ($short)
            return $this->getText ("Correct");
        return $this->getText ("Correct outcome");
        }

    public function getGuessedResultLabel ()
        {
        return $this->getText ("Correct result");
        }

    public function getGuesserLabel ()
        {
        return $this->getText ("Guesser");
        }

    public function getEfficiencyLabel ()
        {
        return $this->getText ("Efficiency");
        }

    public function getPointsLabel ()
        {
        return $this->getText ("Points");
        }

    public function getFormatPercentage ($val)
        {
        return NULL === $val ? NULL : $this->lng->decimalToString ($val * 100, 2)." %";
        }

     protected function prepareGroup (&$rows, $seasonId, $maxCount = 100)
        {
        if (empty ($rows))
            return false;

        $excluded = defined ("MATCH_PREDICTOR_EXCLUDE") ? preg_split ("/[,; |]/", MATCH_PREDICTOR_EXCLUDE) : array ();
        $result = array ();
        $index = 0;
        foreach ($rows as $row)
            {
            $excludedUser = false !== array_search ($row["uid"], $excluded);
            if (0 == $row["uid"])
                continue;
            if (!$excludedUser)
                $index++;

            if ($row["totalcount"] != $row["cnt"])
                $row["cnt"] = "{$row["cnt"]} ({$row["totalcount"]})";
            if ($this->context->getCurrentUser() == $row["uid"])
                {
                if (count ($result) > 0 && $result[count($result)-1]["index"] != $index - ($excludedUser ? 0 : 1))
                    {
                    // separator
                    $result[] = null;
                    }

                $row["name"] = "<b>{$row["name"]}</b>";
                }
            else
                {
                if ($excludedUser || $index > $maxCount)
                    continue;
                }

            $url = $this->context->getAdjustedUrl (array ("uid" => $row["uid"], "season" => $seasonId));
            $row["name"] = "<a href=\"$url\">{$row["name"]}</a>";
            $row["index"] = $index;

            if ($excludedUser)
                {
                if ($this->context->getCurrentUser() != $row["uid"])
                    continue;
                $row["name"] = "({$row["name"]})";
                $row["exclude"] = true;
                }

            $result[] = $row;
            }

        return $result;
        }

     public function selectLeaderGroups ()
        {
        $cache = Cache::getInstance (Sports::TABLE_MATCH, 6*60*60);
        $maxTotal = empty ($_REQUEST["maxTotal"]) ? 25 : $_REQUEST["maxTotal"];
        $cacheId = "predictorleaders_$maxTotal";

        if (false === ($result = $cache->get ($cacheId)))
            {
            $result = array ();
            $seasonsTable = new PredictorSeasonTable ($this->context);
            $criteria = array ();
            $criteria[] = new LtCriterion (PredictorSeasonTable::COL_START_DATE, date ("Y-m-d G:i:s", time ()));
            $criteria[] = new LogicalOperatorOr (new GtEqCriterion (PredictorSeasonTable::COL_END_DATE, date ("Y-m-d 00:00:00", time () - 28 * 24 * 60 * 60)),
                                                 new IsNullCriterion (PredictorSeasonTable::COL_END_DATE));
            $seasonRows = $seasonsTable->selectBy (array (PredictorSeasonTable::COL_ID, PredictorSeasonTable::COL_LABEL), $criteria);

            $rows = $this->dbtable->selectLeaders (NULL, NULL);

            $result[] = array (NULL, $this->getText ("Total"), $rows);

            if (count ($seasonRows) > 1)
                {
                foreach ($seasonRows as $season)
                    {
                    $rows = $this->dbtable->selectLeaders ($season[PredictorSeasonTable::COL_ID], NULL);
                    $result[] = array ($season[PredictorSeasonTable::COL_ID], $season[PredictorSeasonTable::COL_LABEL], $rows);
                    }
                }

            $cache->save ($result, $cacheId);
            }

        $prepared = array ();
        foreach ($result as $row)
            {
            list ($id, $label, $rows) = $row;
            $prepared[$label] = $this->prepareGroup ($rows, $id, NULL !== $id ? 15 : $maxTotal);
            }

        return $prepared;
        }

     public function selectRoundLeaderGroups ()
        {
        if (!defined ("MATCH_PREDICTOR_PRIMARY_COMPETITION"))
            return NULL;

        $cache = Cache::getInstance (Sports::TABLE_MATCH, 6*60*60);
        $cacheId = "predictorroundleaders.".MATCH_PREDICTOR_PRIMARY_COMPETITION;

        if (false === ($result = $cache->get ($cacheId)))
            {
            $competitionsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
            $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);

            $competitionIdColumn = "f_".Sports::COL_MATCH_COMPETITION."_".$competitionsTable->getIdColumn();

            $criteria[] = new EqCriterion ($competitionIdColumn, MATCH_PREDICTOR_PRIMARY_COMPETITION);
            $criteria[] = new LtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d G:i:s", time ()));
            $rows = $matchesTable->selectBy (array ($matchesTable->getIdColumn (), Sports::COL_MATCH_MATCHDAY), $criteria);
            $roundMatches = array ();
            foreach ($rows as $row)
                {
                $matchDay = $row["c_".Sports::COL_MATCH_MATCHDAY];
                if (empty ($roundMatches[$matchDay]))
                    $roundMatches[$matchDay] = array ();
                $roundMatches[$matchDay][] = $row[$matchesTable->getIdColumn ()];
                }

            $result = array ();
            foreach ($roundMatches as $round => $matches)
                {
                $index = count ($result);
                $maxCount = 3;
                if (count ($roundMatches) > 5 && $index < count ($roundMatches) / 2)
                    $maxCount = 2;
                else if ($index + 1 >= count ($roundMatches))
                    $maxCount = 10;
                else if ($index + 2 >= count ($roundMatches))
                    $maxCount = 5;
                $rows = $this->dbtable->selectLeadersByMatchList ($matches, $maxCount);
                $result[$this->getText ("Round [_0]", $round)] = $rows;
                }

            $result = array_reverse ($result, true);
            $cache->save ($result, $cacheId);
            }

        return $result;
        }

    public function selectUserGuessesLabel ()
        {
        return $this->getText ("User guesses");
        }

    public function selectUserGuesses ()
        {
        if (empty ($_REQUEST["uid"]))
            return NULL;
        $userIds = preg_split ("/[,;|]/", $_REQUEST["uid"]);
        $seasonId = empty ($_REQUEST["season"]) ? NULL : $_REQUEST["season"];
        $matches = $this->getAllAnnouncedMatches ($seasonId);
        $gameIds = array ();
        foreach ($matches as $row)
            $gameIds[] = $row[PredictorGameTable::COL_ID];

        if (empty ($gameIds))
            $rows = array ();
        else
            {
            $columns = array (PredictorGuessTable::COL_USER_ID, PredictorGuessTable::COL_GAME_ID, PredictorGuessTable::COL_GOALS_HOME, PredictorGuessTable::COL_GOALS_AWAY);
            $rows = $this->dbtable->selectBy ($columns, array (new InCriterion (PredictorGuessTable::COL_USER_ID, $userIds),
                                                               new InCriterion (PredictorGuessTable::COL_GAME_ID, $gameIds)));
            }

        $guessesByGame = array ();
        foreach ($rows as $row)
            {
            $gameId = $row[PredictorGuessTable::COL_GAME_ID];
            $userId = $row[PredictorGuessTable::COL_USER_ID];
            if (!array_key_exists ($gameId, $guessesByGame))
                $guessesByGame[$gameId] = array ();

            $guessesByGame[$gameId][$userId] = array ($row[PredictorGuessTable::COL_GOALS_HOME], $row[PredictorGuessTable::COL_GOALS_AWAY]);
            }

        $usersTable = new UsersTable ($this->context);
    
        $rows = $usersTable->selectBy (array (UsersTable::COL_ID, UsersTable::COL_NAME), array (new InCriterion (UsersTable::COL_ID, $userIds)));
        foreach ($rows as $row)
            $users[$row[UsersTable::COL_ID]] = $row[UsersTable::COL_NAME];

        $lng = Language::getInstance ($this->context);
        $result = array ();
        $gameLabel = $this->getText ("Match");
        $resultLabel = $this->getText ("Result");
        foreach ($matches as $row)
            {
            $resultRow = array ();
            $resultRow[$gameLabel] = $lng->dateToLongString ($row["c_".Sports::COL_MATCH_DATE])." {$row["home"]}-{$row["away"]}";
            $resultRow[$resultLabel] = $row["c_".Sports::COL_MATCH_RESULT];
            $gameId = $row[PredictorGameTable::COL_ID];

            foreach ($users as $userId => $name)
                {
                if (empty ($guessesByGame[$gameId]))
                    $resultRow[$name] = "&nbsp;";
                else
                    {
                    $guess = $guessesByGame[$gameId][$userId];
                    if ($guess[0] == $row["c_".Sports::COL_MATCH_HOMERESULT] && $guess[1] == $row["c_".Sports::COL_MATCH_AWAYRESULT])
                        $resultRow[$name] = "<b>".implode (":", $guess)."</b>";
                    else
                        {
                        $outcomeReal = gmp_sign ($row["c_".Sports::COL_MATCH_HOMERESULT] - $row["c_".Sports::COL_MATCH_AWAYRESULT]);
                        $outcomeGuessed = gmp_sign ($guess[0] - $guess[1]);
                        if ($outcomeReal != $outcomeGuessed)
                            $resultRow[$name] = "<i>".implode (":", $guess)."</i>";
                        else
                            $resultRow[$name] = implode (":", $guess);
                        }
                    }
                }
            
            $result[] = $resultRow;
            }

        return $result;
        }

    protected function getAllAnnouncedMatches ($seasonId)
        {
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $predictorGamesTable = new PredictorGameTable ($this->context);
        $joinCriterion = array ();
        $joinCriterion[] = new JoinColumnsCriterion (PredictorGameTable::COL_MATCH_ID, $matchesTable->getIdColumn ());
        $joinCriterion[] = new LtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d G:i:s", time ()));

        $params = array (OrderBy::create ("c_".Sports::COL_MATCH_DATE));
        $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id");
        $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id");

        $joins[] = $matchesTable->createQuery (array ("c_".Sports::COL_MATCH_DATE, $homeTeamColumn, $awayTeamColumn, Sports::COL_MATCH_RESULT),
                                               $joinCriterion, NULL, $params);

        $criteria = NULL;
        if (!empty ($seasonId))
            $criteria[] = new EqCriterion (PredictorGameTable::COL_SEASON_ID, $seasonId);
        else
            {
            $seasonTable = new PredictorSeasonTable ($this->context);
            $joinCriteria = array (new JoinColumnsCriterion (PredictorGameTable::COL_SEASON_ID, PredictorSeasonTable::COL_ID));
            $joinCriteria[] = new LtCriterion (PredictorSeasonTable::COL_START_DATE, date ("Y-m-d G:i:s", time ()));
            $joinCriteria[] = new LogicalOperatorOr (new GtEqCriterion (PredictorSeasonTable::COL_END_DATE, date ("Y-m-d 00:00:00", time () - 7 * 24 * 60 * 60)),
                                                 new IsNullCriterion (PredictorSeasonTable::COL_END_DATE));
            $joins[] = $seasonTable->createQuery (array (), $joinCriteria);
            }

        $rows = $predictorGamesTable->selectBy (array (PredictorGameTable::COL_ID, PredictorGameTable::COL_MATCH_ID, PredictorGameTable::COL_ANNOUNCEMENT_TEXT),
                                          $criteria, $joins);

        if (empty ($rows))
            return array ();
        
        $teamIds = array ();
        foreach ($rows as $row)
            {
            $teamIds[] = $row[$homeTeamColumn];
            $teamIds[] = $row[$awayTeamColumn];
            }

        $lng = Language::getInstance ($this->context);
        $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);
        foreach ($rows as &$row)
            {
            $row["home"] = $lng->beautifyTeamLabel ($teamLabels[$row[$homeTeamColumn]]);
            $row["away"] = $lng->beautifyTeamLabel ($teamLabels[$row[$awayTeamColumn]]);
            }

        return $rows;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function getTemplateName ()
        {
        return "sports/predictorlist";
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }
    }

<?php
require_once (PATH.'pages/sports/relatedrecordfield.php');

class MatchRefereeField extends RelatedRecordField
    {
    const KEY_REFEREE_PRIMARY = "f_referee_p";
    const KEY_REFEREE_ASISTANT1 = "f_assistant1";
    const KEY_REFEREE_ASISTANT2 = "f_assistant2";
    const KEY_REFEREE_RESERVE = "f_referee_res";
    const KEY_REFEREE_INSPECTOR = "f_inspector";
    const KEY_REFEREE_DELEGATE = "f_delegate";

    public function __construct ($context, $prefix, $key, $label, $tooltip, $notes = NULL)
        {
        parent::__construct ($context, $prefix, $key, Sports::TABLE_MATCHREFEREE, $label, $tooltip, $notes);
        if (self::KEY_REFEREE_INSPECTOR == $key || self::KEY_REFEREE_DELEGATE == $key)
            $this->columns = array (Sports::COL_REFEREE_PERSON, Sports::COL_REFEREE_TYPE, Sports::COL_REFEREE_FROM);
        else if (MATCH_REFEREE_RATINGS_ENABLED && self::KEY_REFEREE_PRIMARY == $this->key)
            $this->columns = array (Sports::COL_REFEREE_PERSON, Sports::COL_REFEREE_TYPE, Sports::COL_REFEREE_FROM,
                                    Sports::COL_REFEREE_CATEGORY, Sports::COL_REFEREE_RATED_BY_HOME, Sports::COL_REFEREE_RATED_BY_AWAY);
        else
            $this->columns = array (Sports::COL_REFEREE_PERSON, Sports::COL_REFEREE_TYPE, Sports::COL_REFEREE_FROM, Sports::COL_REFEREE_CATEGORY);
        $this->tableName = $context->getText ("Match referee");
        }

    protected function isEmptyRecord ($context, $request)
        {
        return empty ($request[Sports::COL_REFEREE_PERSON]);
        }

    public function prepareRow ($row, $additional = NULL)
        {
        $column = $this->dbtable->findColumn (Sports::COL_REFEREE_CATEGORY);
        if ($row[$column->columnDef->name] == '')
            $row[$column->columnDef->name] = 0;
        $prepared = parent::prepareRow ($row);
        RelationAutocompleteField::cacheLabel ($prepared[Sports::COL_REFEREE_PERSON], $row[Sports::COL_REFEREE_PERSON.".".ContentTable::COL_DISPLAY_NAME]);
        return $prepared;
        }

    protected function addCriterionForUpdate (&$criteria, $column, $value, $deleting)
        {
        if ($deleting && Sports::COL_REFEREE_FROM == $column)
            return false;

        if ((Sports::COL_REFEREE_CATEGORY == $column || Sports::COL_REFEREE_RATED_BY_HOME == $column || Sports::COL_REFEREE_RATED_BY_AWAY == $column) && 0 == $value)
            {
            $criteria[] = new LogicalOperatorOr (new IsNullCriterion ($column), new EqCriterion ($column, 0));
            return false;
            }

        if (Sports::COL_REFEREE_FROM == $column && empty ($value))
            {
            $criteria[] = new IsNullCriterion ($column);
            return false;
            }

        return parent::addCriterionForUpdate ($criteria, $column, $value, $deleting);
        }

    public function retrieveRecord ($context, $criteria, &$row, &$cache)
        {
        $row[$this->key] = NULL;

        if (!array_key_exists (Sports::TABLE_MATCHREFEREE, $cache))
            $cache[Sports::TABLE_MATCHREFEREE] = $this->retrieveRecords ($context, $criteria);

        $refereeRows = $cache[Sports::TABLE_MATCHREFEREE];
        if (empty ($refereeRows))
            return;

        $assistants = array ();
        foreach ($refereeRows as $singleRow)
            {
            $preparedRow = $this->prepareRow ($singleRow);
            $currentKey = NULL;
            switch ($preparedRow[Sports::COL_REFEREE_TYPE])
                {
                case MatchConstants::REFEREE_PRIMARY:
                    $currentKey = self::KEY_REFEREE_PRIMARY;
                    break;
                case MatchConstants::REFEREE_ASSISTANT1:
                    $currentKey = self::KEY_REFEREE_ASISTANT1;
                    break;
                case MatchConstants::REFEREE_ASSISTANT2:
                    $currentKey = self::KEY_REFEREE_ASISTANT2;
                    break;
                case MatchConstants::REFEREE_RESERVE:
                    $currentKey = self::KEY_REFEREE_RESERVE;
                    break;
                case MatchConstants::REFEREE_INSPECTOR:
                    $currentKey = self::KEY_REFEREE_INSPECTOR;
                    break;
                case MatchConstants::REFEREE_DELEGATE:
                    $currentKey = self::KEY_REFEREE_DELEGATE;
                    break;
                case MatchConstants::REFEREE_ASSISTANT_UNSPECIFIED:
                    $assistants[] = $preparedRow;
                    break;
                }

            if ($currentKey != $this->key)
                continue;

            $row[$this->key] = $preparedRow;
            return;
            }

        $preparedRow = NULL;
        if (self::KEY_REFEREE_ASISTANT1 == $this->key && count ($assistants) >= 1)
            $preparedRow = $assistants[0];
        else if (self::KEY_REFEREE_ASISTANT2 == $this->key && count ($assistants) >= 2)
            $preparedRow = $assistants[1];

        if (!empty ($preparedRow))
            {
            $preparedRow[Sports::COL_REFEREE_TYPE] = (self::KEY_REFEREE_ASISTANT1 == $this->key) ? MatchConstants::REFEREE_ASSISTANT1 : MatchConstants::REFEREE_ASSISTANT2;
            $row[$this->key] = $preparedRow;
            }
        }

    public function prepareForStoring ($context, &$values, $initialValues, &$prepared)
        {
        $map = array (self::KEY_REFEREE_PRIMARY => MatchConstants::REFEREE_PRIMARY,
                      self::KEY_REFEREE_ASISTANT1 => MatchConstants::REFEREE_ASSISTANT1,
                      self::KEY_REFEREE_ASISTANT2 => MatchConstants::REFEREE_ASSISTANT2,
                      self::KEY_REFEREE_RESERVE => MatchConstants::REFEREE_RESERVE,
                      self::KEY_REFEREE_INSPECTOR => MatchConstants::REFEREE_INSPECTOR,
                      self::KEY_REFEREE_DELEGATE => MatchConstants::REFEREE_DELEGATE);
        $initialValue = !empty ($initialValues) ? $initialValues[$this->key] : NULL;
        if ($this->areValuesModified ($initialValue, $values[$this->key]))
            {
            $record = $values[$this->key];
            if (empty ($record[Sports::COL_REFEREE_PERSON]))
                $record[Sports::COL_REFEREE_TYPE] = NULL;
            else if (empty ($record[Sports::COL_REFEREE_TYPE]))
                $record[Sports::COL_REFEREE_TYPE] = $map[$this->key];

            $prepared[$this->key] = $record;
            }

        unset ($values[$this->key]);
        }

    public function createFields ()
        {
        $prefix = $this->getPrefix().$this->key;

        $arr = array ();

        $col = $this->dbtable->findColumn (Sports::COL_REFEREE_PERSON);
        $relatedTable = ContentTable::createInstanceById ($this->dbtable->getContext (), $col->relatedTableId);
        $personField = new RelationAutocompleteField ($prefix, $relatedTable,
                                                      Sports::COL_REFEREE_PERSON,
                                                      $col->label, $col->description, $col->required);
        $personField->cssClass = "referee";
        $personField->size = 5;
        $arr[] = $personField;

        if (self::KEY_REFEREE_INSPECTOR != $this->key && self::KEY_REFEREE_DELEGATE != $this->key)
            {
            $col = $this->dbtable->findColumn (Sports::COL_REFEREE_CATEGORY);
            $categoryField = new DropDownFieldTemplate ($prefix, $col->name, $col->getLabel (), $col->description, NamedIntColumn::getItems ($col));
            $categoryField->cssClass = "refereecategory";
            $arr[] = $categoryField;
            }
        
        $fromField = new TextFieldTemplate ($prefix, Sports::COL_REFEREE_FROM, "", "", 10);
        $fromField->cssClass = "refereefrom";
        $arr[] = $fromField;

        if (MATCH_REFEREE_RATINGS_ENABLED && self::KEY_REFEREE_PRIMARY == $this->key)
            {
            $field = new IntFieldTemplate ($prefix, Sports::COL_REFEREE_RATED_BY_HOME, "", "", 10);
            $field->cssClass = "refereefrom";
            $arr[] = $field;
            $field = new IntFieldTemplate ($prefix, Sports::COL_REFEREE_RATED_BY_AWAY, "", "", 10);
            $field->cssClass = "refereefrom";
            $arr[] = $field;
            }

        $arr[] = new HiddenFieldTemplate ($prefix, Sports::COL_REFEREE_TYPE);
        return $arr;
        }

    }

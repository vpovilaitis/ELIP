<?php
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'inc/sports/common.php');
require_once (PATH."inc/sports/leaguetablecollector.php");

abstract class SeasonResultsBase extends Component
    {
    protected $competitionRow;
    protected $dbtable;
    protected $leagueId;
    protected $teams;
    protected $hasMatches = false;
    protected $explicitlySpecified;
    protected $system;
    protected $rounds;
    protected $title = NULL;
    protected $forExport;

    public function __construct ($context, $dbtable, $leagueId, $system, $rounds = NULL, $explicitlySpecified = false, $forExport = false)
        {
        $this->dbtable = $dbtable;
        $this->leagueId = $leagueId;
        $this->system = $system;
        $this->rounds = $rounds;
        $this->explicitlySpecified = $explicitlySpecified;
        $this->forExport = $forExport;
        parent::__construct ("table", $context);
        $context->addStyleSheet ("sports");
        }

    public function setTitle ($title)
        {
        $this->title = $title;
        }

    public function exportRequested ()
        {
        return $this->forExport;
        }

    protected function createMatchDateLabel ($date)
        {
        return LeagueTableCollector::createMatchDateLabel ($this->context, $date);
        }

    public function getDBTable ($context, $name)
        {
        $table = ContentTable::createInstanceByName ($context, $name);
        if (empty ($table))
            {
            $this->log ("ERROR: \"$name\" content table not found");
            $this->displayErrorPage ("Invalid arguments passed.");
            return false;
            }
        return $table;
        }

    public function getTeamLeagueSeasonsTable ($context)
        {
        return $this->getDBTable ($context, Sports::TABLE_TEAMLEAGUESEASON);
        }

    public function getTeamCupSeasonsTable ($context)
        {
        return $this->getDBTable ($context, Sports::TABLE_TEAMCUPSEASON);
        }

    public function getTeamsTable ($context)
        {
        return $this->getDBTable ($context, Sports::TABLE_TEAM);
        }

    public function getMatchesTable ($context)
        {
        return $this->getDBTable ($context, "match");
        }

    public function getRoundsTable ($context)
        {
        return $this->getDBTable ($context, "round");
        }

    public function getCompetitionTable ($context)
        {
        return $this->getDBTable ($context, Sports::TABLE_COMPETITIONSTAGE);
        }


    public function createTeamsTableJoin ($context)
        {
        $teamsTable = $this->getTeamsTable ($context);
        if (empty ($teamsTable))
            return false;

        $columns = array ("shortname");
        $criteria = array (new JoinColumnsCriterion ("team_id", "team_id"));
        $teamsQuery = $teamsTable->createQuery ($columns, $criteria);
        return $teamsQuery;
        }

    public function getLink ()
        {
        if (NULL === $this->title)
            return NULL;

        $url = $this->getCompetitionUrl ();
        $title = $this->getText ("More (details, games, sources)");
        $img = $this->context->getSmallIconPath ("more");
        return array ("url" => $url, "tooltip" => $title, "src" => $img);
        }

    public function getCompetitionUrl ($view = NULL)
        {
        $params = empty ($view) ? NULL : array ("view" => $view);
        return LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                     $this->dbtable->getId (),
                                                                     $this->leagueId, Constants::MODE_VIEW, $params);
        }

    protected function getCompetitionRow ()
        {
        if (NULL === $this->competitionRow)
            {
            $competitionsTable = $this->getCompetitionTable ($this->context);
            if (empty ($competitionsTable))
                return false;

            $criteria = array (new EqCriterion ($competitionsTable->getIdColumn (), $this->leagueId));
            $this->competitionRow = $competitionsTable->selectSingleBy (NULL, $criteria);
            }

        return $this->competitionRow;
        }

    public static function ensureTeamLabels ($context, &$teams, $date)
        {
        return LeagueTableCollector::ensureTeamLabels ($context, $teams, $date);
        }

    }

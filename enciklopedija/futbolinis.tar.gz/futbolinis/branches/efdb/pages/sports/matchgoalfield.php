<?php
require_once (PATH.'pages/sports/relatedrecordfield.php');

class MatchGoalField extends RelatedRecordField
    {
    protected $rowIndex;
    protected $defaultAsHome;

    const GOAL_TYPE = "goaltype";
    const GOAL_NORMAL = "n";

    public function __construct ($context, $prefix, $label, $tooltip, $index, $defaultAsHome = false)
        {
        $key = self::getKey ($index);

        parent::__construct ($context, $prefix, $key, Sports::TABLE_MATCHGOAL, $label, $tooltip);

        $this->columns = self::getColumns ();
        $this->tableName = $context->getText ("Match goals");
        $this->rowIndex = $index;
        $this->defaultAsHome = $defaultAsHome;
        }

    public static function getKey ($index)
        {
        return "goal_$index";
        }

    public static function getColumns ()
        {
        return array (Sports::COL_GOAL_TIME_MIN, Sports::COL_GOAL_TIME_EXTRA,
                      Sports::COL_GOAL_SCORER, Sports::COL_GOAL_OWN,
                      Sports::COL_GOAL_PENALTY, Sports::COL_GOAL_HOME,
                      Sports::COL_GOAL_ASSIST,
                      Sports::TABLE_MATCHGOAL."_id");
        }

    public function prepareRow ($row, $playerRows = NULL)
        {
        $prepared = parent::prepareRow ($row);

        $isHomeAssist = $isHome = $prepared[Sports::COL_GOAL_HOME];
        $prepared[self::GOAL_TYPE] = self::GOAL_NORMAL;
        if (!empty ($prepared[Sports::COL_GOAL_PENALTY]))
            $prepared[self::GOAL_TYPE] = Sports::COL_GOAL_PENALTY;
        else if (!empty ($prepared[Sports::COL_GOAL_OWN]))
            {
            $prepared[self::GOAL_TYPE] = Sports::COL_GOAL_OWN;
            $isHome = $prepared[Sports::COL_GOAL_HOME] = !$isHome;
            }

        if (!empty ($prepared[Sports::COL_GOAL_SCORER]))
            {
            list ($number, $id)  = $this->findPlayer ($prepared[Sports::COL_GOAL_SCORER], $isHome, $playerRows);
            NumberAutocompleteField::setId ($prepared, Sports::COL_GOAL_SCORER, $id, $number, $row[Sports::COL_GOAL_SCORER.".".ContentTable::COL_DISPLAY_NAME]);
            }

        if (!empty ($prepared[Sports::COL_GOAL_ASSIST]))
            {
            list ($number, $id)  = $this->findPlayer ($prepared[Sports::COL_GOAL_ASSIST], $isHomeAssist, $playerRows);
            NumberAutocompleteField::setId ($prepared, Sports::COL_GOAL_ASSIST, $id, $number, $row[Sports::COL_GOAL_ASSIST.".".ContentTable::COL_DISPLAY_NAME]);
            }

        if (!empty ($prepared[Sports::COL_GOAL_TIME_MIN]) && !empty ($prepared[Sports::COL_GOAL_TIME_EXTRA]))
            $prepared[Sports::COL_GOAL_TIME_MIN] .= "+".$prepared[Sports::COL_GOAL_TIME_EXTRA];

        return $prepared;
        }

    protected function addCriterionForUpdate (&$criteria, $column, $value, $deleting)
        {
        if (empty ($value) && (Sports::COL_GOAL_SCORER == $column || Sports::COL_GOAL_ASSIST == $column ||
                               Sports::COL_GOAL_OWN == $column || Sports::COL_GOAL_HOME == $column ||
                               Sports::COL_GOAL_PENALTY == $column || Sports::COL_GOAL_TIME_EXTRA == $column ||
                               Sports::COL_GOAL_TIME_MIN == $column))
            {
            $criteria[] = new LogicalOperatorOr (new IsNullCriterion ($column), new EqCriterion ($column, 0));
            return false;
            }

        return parent::addCriterionForUpdate ($criteria, $column, $value, $deleting);
        }

    protected function isEmptyRecord ($context, $request)
        {
        return empty ($request[Sports::COL_GOAL_TIME_MIN]) && empty ($request[Sports::COL_GOAL_SCORER]);
        }

    public function retrieveRecord ($context, $criteria, &$row, &$cache)
        {
        $row[$this->key] = NULL;

        if (!array_key_exists (Sports::TABLE_MATCHGOAL, $cache))
            $cache[Sports::TABLE_MATCHGOAL] = $this->retrieveRecords ($context, $criteria);

        $goalRows = $cache[Sports::TABLE_MATCHGOAL];
        if (empty ($goalRows))
            {
            if ($this->defaultAsHome)
                $row[$this->key] = array (Sports::COL_GOAL_HOME => true);
            return;
            }

        if (empty ($cache[Sports::TABLE_MATCHPLAYER]))
            $playerRows = array ();
        else
            $playerRows = $cache[Sports::TABLE_MATCHPLAYER];

        $i = 0;
        foreach ($goalRows as $singleRow)
            {
            if ($this->rowIndex != $i++)
                continue;

            $preparedRow = $this->prepareRow ($singleRow, $playerRows);
            $row[$this->key] = $preparedRow;
            return;
            }
        }

    public function prepareForStoring ($context, &$values, $initialValues, &$prepared)
        {
        $initialValue = !empty ($initialValues) ? $initialValues[$this->key] : NULL;
        $record = $values[$this->key];
        unset ($values[$this->key]);

        if (empty ($initialValue) && (empty ($record) || $this->isEmptyRecord ($context, $record)))
            return;

        $anyChanges = false;
        foreach (array (Sports::COL_GOAL_TIME_MIN, self::GOAL_TYPE, Sports::COL_GOAL_SCORER, Sports::COL_GOAL_ASSIST) as $key)
            {
            if ('' == $record[$key])
                $record[$key] = NULL;
            $initialVal = isset ($initialValue[$key]) ? $initialValue[$key] : NULL;
            if ($initialVal !== $record[$key])
                {
                $anyChanges = true;
                break;
                }
            }

        if (!$anyChanges && $initialValue[Sports::COL_GOAL_HOME] != $record[Sports::COL_GOAL_HOME])
            $anyChanges = true;
        if (!$anyChanges)
            return;

        $record[Sports::COL_GOAL_TIME_EXTRA] = NULL;
        $record[Sports::COL_GOAL_PENALTY] = false;
        $record[Sports::COL_GOAL_OWN] = false;

        if (!empty ($record[Sports::COL_GOAL_TIME_MIN]))
            {
            $parts = explode ("+", $record[Sports::COL_GOAL_TIME_MIN]);
            if (2 == count ($parts))
                list ($record[Sports::COL_GOAL_TIME_MIN], $record[Sports::COL_GOAL_TIME_EXTRA]) = $parts;
            }

        $isHome = $record[Sports::COL_GOAL_HOME];
        if (!empty ($record[self::GOAL_TYPE]))
            {
            switch ($record[self::GOAL_TYPE])
                {
                case Sports::COL_GOAL_PENALTY:
                    $record[Sports::COL_GOAL_PENALTY] = true;
                    break;
                case Sports::COL_GOAL_OWN:
                    $record[Sports::COL_GOAL_OWN] = true;
                    $record[Sports::COL_GOAL_HOME] = !$record[Sports::COL_GOAL_HOME];
                    break;
                }
            }

        $isNumber = NULL;
        $id = NumberAutocompleteField::getIdOrNumber ($record, Sports::COL_GOAL_SCORER, $isNumber);
        if (!empty ($id))
            {
            $record[Sports::COL_GOAL_SCORER] = $isNumber ? $id : ("X".$id);

            if (false === $this->processPlayerNumber ($context, $record, $prepared, Sports::COL_GOAL_SCORER, $isHome))
                return false;
            }

        $isNumber = NULL;
        $id = NumberAutocompleteField::getIdOrNumber ($record, Sports::COL_GOAL_ASSIST, $isNumber);
        if (!empty ($id))
            {
            $record[Sports::COL_GOAL_ASSIST] = $isNumber ? $id : ("X".$id);

            $home = $record[Sports::COL_GOAL_OWN] ? !$isHome : $isHome;
            if (false === $this->processPlayerNumber ($context, $record, $prepared, Sports::COL_GOAL_ASSIST, $home))
                return false;
            }

        if (empty ($record[Sports::COL_GOAL_OWN]))
            $record[Sports::COL_GOAL_OWN] = false;
        if (empty ($record[Sports::COL_GOAL_HOME]))
            $record[Sports::COL_GOAL_HOME] = false;
        if (empty ($record[Sports::COL_GOAL_PENALTY]))
            $record[Sports::COL_GOAL_PENALTY] = false;
        if (empty ($record[Sports::COL_GOAL_ASSIST]))
            $record[Sports::COL_GOAL_ASSIST] = NULL;
        if (empty ($record[Sports::COL_GOAL_TIME_EXTRA]))
            $record[Sports::COL_GOAL_TIME_EXTRA] = NULL;

        // set the prepared record to be stored later
        $prepared[$this->key] = $record;
        $prepared[$this->key."_initial"] = $record;
        }

    public function createFields ()
        {
        $prefix = $this->getPrefix().$this->key;
        $context = $this->dbtable->getContext ();

        $col = $this->dbtable->findColumn (Sports::COL_GOAL_SCORER);
        $relatedTable = ContentTable::createInstanceById ($this->dbtable->getContext (), $col->relatedTableId);

        $arr = array ();

        $field = RelatedRecordField::createIntField ($prefix, Sports::COL_GOAL_TIME_MIN, $context->getText ("Minute (integer and optionally plus sign and extra time minute)"), 5);
        $field->cssClass = "goalmin";
        $arr[] = $field;

        $field = new LabelTemplate ($context->getText ("min."));
        $field->cssClass = "goalmin_l";
        $arr[] = $field;

        $field = new LabelTemplate ($context->getText ("No:"));
        $field->cssClass = "goalplayer_l";
        $arr[] = $field;

        $arr[] = new NumberAutocompleteField ($prefix, $relatedTable,
                                              Sports::COL_GOAL_SCORER,
                                              $col->label, $context->getText ("Number or name of the player which scored the goal"),
                                              $col->required);

        $teamField = new DropDownFieldTemplate ($prefix, Sports::COL_GOAL_HOME, "", $context->getText ("Team"), array (1 => $context->getText ("Home team"), 0 => $context->getText ("Away team")));
        $teamField->cssClass = "team";
        $arr[] = $teamField;

        $items = array (self::GOAL_NORMAL => $context->getText ("A - goal"),
                        Sports::COL_GOAL_PENALTY => $context->getText ("B - penalty"),
                        Sports::COL_GOAL_OWN => $context->getText ("C - own goal"),
                        /*"miss" => $context->getText ("D - missed penalty")*/);
        $teamField = new DropDownFieldTemplate ($prefix, self::GOAL_TYPE, "", $context->getText ("Goal type"), $items);
        $teamField->cssClass = "team";
        $arr[] = $teamField;

        $field = new LabelTemplate ($context->getText ("Assist:|player assisting"));
        $field->cssClass = "goalassist_l";
        $arr[] = $field;

        $col = $this->dbtable->findColumn (Sports::COL_GOAL_ASSIST);
        $personField = new NumberAutocompleteField ($prefix, $relatedTable,
                                                      Sports::COL_GOAL_ASSIST,
                                                      $col->label, $context->getText ("Number or name of the player which did the assist (earned the penalty or hit the ball before own goal)"),
                                                      $col->required);
        $arr[] = $personField;

        $arr[] = new HiddenFieldTemplate ($prefix, $this->dbtable->getIdColumn ());
        return $arr;
        }

    protected function getRecordLabel ($context, $ticket)
        {
        $parts = explode ("_", $ticket);
        list ($min, $extra, $scorer, $own, $penalty, $home, $assist) = $parts;
        if (!empty ($extra))
            $min .= "+$extra";
        $modifiers = array ();
        if ($scorer)
            $modifiers[] = $context->getText ("scorer: [_0]", $scorer);
        if ($assist)
            $modifiers[] = $context->getText ("assist: [_0]", $assist);

        if ($own)
            {
            $modifiers[] = $context->getText ("own goal");
            $home = !$home;
            }

        if ($penalty)
            $modifiers[] = $context->getText ("penalty");

        $modifiers[] = $home ? $context->getText ("home goal") : $context->getText ("away goal");

        return $context->getText ("[_0]' [_1]", $min, implode (", ", $modifiers));
        }

    public static function getCount ($context, $request, $criteria, &$cache)
        {
        if (!array_key_exists (Sports::TABLE_MATCHGOAL, $cache))
            {
            $dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHGOAL);
            $cache[Sports::TABLE_MATCHGOAL] = self::selectRecords ($context, $dbtable, self::getColumns (), $context->getText ("Match goals"), $criteria);
            }

        return count ($cache[Sports::TABLE_MATCHGOAL]);
        }
    }

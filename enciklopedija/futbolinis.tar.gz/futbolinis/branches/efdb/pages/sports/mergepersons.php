<?php
require_once (PATH.'h/othernamestable.php');
require_once (PATH.'pages/mergerecords.php');

class MergePersons extends MergeRecords
    {
    public function __construct ($context, $request)
        {
        parent::__construct ($context, $request, "persons");
        }

    protected function moveRelatedColumnData ($input, $table, $column, $criteria, $nameToValue)
        {
        if ("person_names" == $table->getName ())
            {
            $leaveAlternative = !empty ($input["othernames"]);
            if (!$leaveAlternative)
                return 0;

            $criteriaCopy = $criteria;
            $criteriaCopy[] = new NotEqCriterion (OtherNamesTable::COL_SOURCETYPE, OtherNamesTable::SRCTYPE_GENERATED);
            $affected = parent::moveRelatedColumnData ($input, $table, $column, $criteriaCopy, $nameToValue);
            if (false === $affected)
                return $affected;
            
            $criteriaCopy = $criteria;
            $criteriaCopy[] = new EqCriterion (OtherNamesTable::COL_SOURCETYPE, OtherNamesTable::SRCTYPE_GENERATED);
            $nameToValue[OtherNamesTable::COL_SOURCETYPE] = OtherNamesTable::SRCTYPE_RENAMED;
            $affected2 = parent::moveRelatedColumnData ($input, $table, $column, $criteriaCopy, $nameToValue);
            if (false === $affected2)
                return $affected2;
            return $affected + $affected2;
            }

        return parent::moveRelatedColumnData ($input, $table, $column, $criteria, $nameToValue);
        }

    protected function isColumnIncluded ($column)
        {
        if ("othernamesupdated" == $column->name)
            return false;

        return parent::isColumnIncluded ($column);
        }
        
    protected function getTemplateRecordField ()
        {
        $namesTable = ContentTable::createInstanceByName ($this->context, "person_names");
        return $namesTable->findColumn (OtherNamesTable::COL_PERSON);
        }
    protected function getAdditionalFields ()
        {
        return array (
            new CheckBoxFieldTemplate ("", "othernames", $this->getText ("Remember as alternative:"), $this->getText ("Remember source (duplicate) person name as a valid alternative")),
            );
        }
    }

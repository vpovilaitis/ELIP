<?php
require_once (PATH.'pages/submit.php');
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/relationfields.php');

class CheckOrphanedPersons extends Submit
    {
    const SKIP = 0;
    const CREATE = -2;

    protected $idToCountry = array ();

    public function __construct ($context, $request)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, "persons");

        if (empty ($this->dbtable))
            {
            $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            $this->allTablesLoaded = false;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        $context->addScriptFile ("autosuggest");
        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ($this->getText ("Find orphaned person records"));
        return true;
        }

    protected function onInputFieldCollected ($context, &$request, $type, $key, $val)
        {
        if (!empty ($val))
            $this->idToCountry[$key] = $val;
        }

    public function collectInputData ($context, &$request)
        {
        $this->createSourceFields ();
        $this->source = $this->sourcesField->getValueForDB ($context, $request);
        $this->sourceDate = $this->sourcesDateField->getValueForDB ($context, $request);

        return $this->idToCountry;
        }
        
    public function validateInput ($context, &$input)
        {
        return true;
        }

    public function saveInput ($context, &$request, &$input)
        {
        if (empty ($input))
            return;
        $count = 0;

        foreach ($input as $personId => $countryId)
            {
            $criteria = array ();
            $criteria[] = new EqCriterion ($this->dbtable->getIdColumn (), $personId);
            $criteria[] = new IsNullCriterion ("citizen");
            $values = array ("citizen" => $countryId);
            $values[DBTable::COL_SOURCE] = $this->source;
            $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;

            if (1 !== $this->dbtable->updateRecord ($criteria, $values))
                {
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                             $this->dbtable->getId (), $personId);
                $url = "<a href=\"$url\">$personId</a>";
                printf ($this->_("Error updating record [_0].", $url));
                }
            else
                $count++;
            }

        printf ($this->ngettext ("Updated [_0] record", "Updated [_0] records", $count));
        return true;
        }

        
    protected function getOrphanedRecords ()
        {
        $columns = array ($this->dbtable->getIdColumn (), "first", "last", "birthday", "height", "weight");
        $criteria[] = new IsNullCriterion ("citizen");
        $startAt = empty ($_REQUEST["startAt"]) ? 0 : $_REQUEST["startAt"];
        $limit = empty ($_REQUEST["limit"]) ? 10 : $_REQUEST["limit"];
        $params[] = new LimitResults ($startAt, $limit);
        $rows = $this->dbtable->selectBy ($columns, $criteria, NULL, $params);
        return $rows;
        }

    protected function guessPersonCountries ($personIds)
        {
        /*
        SELECT (case when mp.c_hometeam = 1 THEN f_hometeam_team_id ELSE f_awayteam_team_id END) teamid, mp.f_player_persons_id
          FROM tx_match m INNER JOIN tx_matchplayers mp ON m.match_id = mp.match_id AND mp.f_player_persons_id > 7621
         GROUP BY teamid,mp.f_player_persons_id
        */
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $matchPlayersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHPLAYER);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        if (empty ($matchesTable) || empty ($matchPlayersTable) || empty ($teamsTable))
            return false;

        $teamIdColumn ="team.id";
        $teamColumn = new ConditionalResultColumn($teamIdColumn, "c_hometeam = 1", "f_hometeam_team_id", "f_awayteam_team_id");
        $columns = array ($teamColumn);
        $criteria = array (new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ()));
        $join = $matchesTable->createQuery ($columns, $criteria, NULL, array (new GroupBy (array ($teamIdColumn))));

        $playerIdColumn = "f_player_persons_id";
        $criteria = array (new InCriterion ($playerIdColumn, $personIds));
        $params = array (new GroupBy (array ($playerIdColumn)));

        $rows = $matchPlayersTable->selectBy (array ($playerIdColumn), $criteria, array ($join), $params);
        if (empty ($rows))
            return NULL;

        $teamPlayers = array ();
        foreach ($rows as $row)
            {
            $teamId = $row[$teamIdColumn];
            if (!array_key_exists ($teamId, $teamPlayers))
                $teamPlayers[$teamId] = array ();

            $teamPlayers[$teamId][] = $row[$playerIdColumn];
            }

        $countryIdColumn = "f_country_country_id";
        $criteria = array (new InCriterion ($teamsTable->getIdColumn (), array_keys ($teamPlayers)), new GtCriterion ($countryIdColumn, 0));
        $rows = $teamsTable->selectBy (array ($teamsTable->getIdColumn (), $countryIdColumn), $criteria);
        if (empty ($rows))
            return NULL;

        $playerCountry = array ();
        foreach ($rows as $row)
            {
            $players = $teamPlayers[$row[$teamsTable->getIdColumn ()]];
            $countryId = $row[$countryIdColumn];
            foreach ($players as $playerId)
                {
                if (array_key_exists ($playerId, $playerCountry))
                    {
                    if ($playerCountry[$playerId] != $countryId)
                        $this->logError ("Player $playerId was in multiple national teams");
                    continue;
                    }

                $playerCountry[$playerId] = $countryId;
                }
            }

        return $playerCountry;
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();

        if (empty ($this->fields))
            {
            $rows = $this->getOrphanedRecords ();
            if (empty ($rows))
                return array (new LabelTemplate ($this->getText ('No orphaned records found'), "", true));

            $this->fields = array ();
            $countryColumn = $this->dbtable->findColumn ("citizen");
            $relatedTable = ContentTable::createInstanceById ($this->context, $countryColumn->relatedTableId);
            $personIds = array ();

            foreach ($rows as $row)
                {
                $id = $row[$this->dbtable->getIdColumn ()];
                $personIds[] = $id;
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                             $this->dbtable->getId (), $id);
                $name = "<a href=\"$url\">".$row["c_first"]." ".$row["c_last"]."</a>";
                $field = new RelationAutocompleteField ("", $relatedTable, "res_pl_$id", $name, $this->getText ("Set country person belongs to"), true);
                $this->fields[] = $field;
                }

            $guessedCountries = $this->guessPersonCountries ($personIds);
            if (!empty ($guessedCountries))
                {
                foreach ($guessedCountries as $playerId => $country)
                    {
                    $this->request["res_pl_$playerId"] = $country;
                    }
                }

            foreach ($this->fields as $field)
                {
                $field->preprocessLoadedValue ($this->request, true);
                }
            }

        $arr = array
            (
            new LabelTemplate ($this->getText ('Assign country of citizenship to each person'), "", true),
            );

        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));

        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }
    }

<?php
require_once (PATH."pages/navigationbox.php");

class CompetitionBox extends NavigationBox
    {
    protected $competitionId;
    protected $label;
    protected $lng;
    const MAX_ITEMS = 6;

    public function __construct ($context, $dbtable, $currentItemId)
        {
        parent::__construct ($context, $dbtable, $currentItemId, array (Sports::TABLE_COMPETITIONSTAGE));
        $this->lng = Language::getInstance ($context);
        }

    public function selectNeighbours ($context, &$request)
        {
        $idColumn = $this->idColumns[0];
        $columns = array (ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_PARENT, Sports::TABLE_COMPETITIONSTAGE."_id"));
        if (!SIMPLIFIED_TEAM_LABELS)
            $columns[] = "f_competition_league_id";
        $criteria = array (new EqCriterion ($idColumn, implode ("_", $this->currentItemId)));
        $row = $this->dbtable->selectSingleBy ($columns, $criteria);
        if (empty ($row))
            return false;

        if (SIMPLIFIED_TEAM_LABELS)
            $this->competitionId = UNSPECIFIED_COMPETITION_ID;
        else
            $this->competitionId = $row["f_competition_league_id"];

        if (UNSPECIFIED_COMPETITION_ID == $this->competitionId)
            return false;
        $leagueIds = SportsHelper::colectLeaguePredecessors ($context, $this->competitionId, true);

        $columns = array ($idColumn, "season", "name");
        $criteria = array (new InCriterion ("f_competition_league_id", $leagueIds ),
                           new IsNullCriterion ("f_partof_competitionstage_id"));

        $rows = $this->dbtable->selectBy ($columns, $criteria);
        if (empty ($rows))
            return false;

        $currentFound = false;
        $trimmedStart = false;
        $preceededItems = array ();
        $succeededItems = array ();
        foreach ($rows as $row)
            {
            if ($row[$idColumn] == $this->currentItemId[0])
                {
                $currentFound = true;
                $preceededItems[] = $row;
                $this->label = $row["c_name"];
                continue;
                }

            if (!$currentFound)
                {
                if (count ($preceededItems) == self::MAX_ITEMS)
                    {
                    array_shift ($preceededItems);
                    $trimmedStart = true;
                    }
                $preceededItems[] = $row;
                }
            else
                {
                if (count ($succeededItems) == self::MAX_ITEMS)
                    {
                    $succeededItems[] = "...";
                    break;
                    }

                $succeededItems[] = $row;
                }
            }

        if ($trimmedStart)
            array_unshift ($preceededItems, "...");

        return array_merge ($preceededItems, $succeededItems);
        }

    public function createItem ($row, $id)
        {
        return array
                (
                "seasonYear" => $row["season.displayname"],
                self::LABEL => $row["c_name"],
                );
        }

    protected function constructDisplayRow ($row, $id)
        {
        if ("..." == $row)
            return array ("current" => true, "labels" => array ("seasonYear" => "...", self::LABEL => "..."));

        return parent::constructDisplayRow ($row, $id);
        }

    public function getTitle ()
        {
        return !empty ($this->label) ? $this->label : $this->getText ("Neighbours");
        }

    public function getCssClass ()
        {
        return "clubteams";
        }

    public function getTemplateName ()
        {
        return "sports/competitionbox";
        }

    protected function getItemUrl ($context, $dbtable, $id)
        {
        $params = array ("view" => "about");
        return LabelContentLinkFieldTemplate::createContentViewLink ($context,
                                                    $dbtable, $dbtable->getId (),
                                                    $id, Constants::MODE_VIEW, $params);
        }

    }

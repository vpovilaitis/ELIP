<?php
require_once (PATH.'pages/componentfragment.php');
require_once (PATH.'inc/sports/constants.php');

class CurrentLeagueListFragment extends FragmentTemplate
    {
    private $gerenatedList = NULL;

    public function __construct ($context, $prefix, $table, $title = NULL, $description = NULL, $params = NULL)
        {
        parent::__construct ($context, $prefix, $table, $title, $description, $params);
        $context->addStyleSheet ("sports");
        $context->addScriptFile ("sports");
        }

    protected function getShowDescription ()
        {
        return true;
        }
        
    public function getDescription ()
        {
        $list = $this->getLeagueList ();
        if (empty ($list))
            return $this->getText ("No competitions running.");
        }

    public function getLeagueList ()
        {
        if (NULL === $this->gerenatedList)
            {
            $this->gerenatedList = $this->generateLeagueList ($this->context);
            }

        return $this->gerenatedList;
        }

    public function getNoScriptText ()
        {
        return $this->getText ("Please enable script support in your browser to view league tables inline");
        }

    public function getHeight ()
        {
        $height = parent::getHeight ();
        if (NULL === $height)
            return "300px";
        return $height;
        }

    protected static function generateLeagueList ($context)
        {
        $dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $columns = array ($dbtable->getIdColumn (), Sports::COL_COMPETITION_LEVEL, Sports::COL_COMPETITION_ANNOUNCEMENENT,
                          Sports::COL_COMPETITION_PARENT, Sports::COL_COMPETITION_PRIORITY, Sports::COL_COMPETITION_UNOFFICIAL);
        $now = time ();
        $aproximateStartDate = date ("Y-m-d 00:00:00", strtotime ("+1 month", $now));
        $aproximateEndDate = date ("Y-m-d 00:00:00", strtotime ("-7 day", $now));
        $criteria[] = new LtCriterion ("c_".Sports::COL_COMPETITION_STARTS, $aproximateStartDate);
        $criteria[] = new GtCriterion ("c_".Sports::COL_COMPETITION_ENDS, $aproximateEndDate);
        $parentColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_PARENT, $dbtable->getIdColumn ());
        $criteria[] = new IsNullCriterion ($parentColumn);
        $rows = $dbtable->selectWithDisplayName ($columns, $criteria);
        if (empty ($rows))
            return NULL;

        $competitions = array ();
        foreach ($rows as $row)
            {
            $level = $row["c_".Sports::COL_COMPETITION_LEVEL];
            $unofficial = $row["c_".Sports::COL_COMPETITION_UNOFFICIAL];
            $category = NULL;
            if ($unofficial)
                $category = $context->getText ("Other competitions:");
            else if ($level > 0)
                $category = $context->getText ("Level [_0] competitions:", $level);
            else
                $category = $context->getText ("Important competitions:");
            $newLevel = $unofficial ? 1000 : ($level > 0 ? $level : 100);

            if (empty ($competitions[$newLevel]))
                $competitions[$newLevel] = array ('category' => $category, 'names' => array ());

            $id = $row[$dbtable->getIdColumn ()];
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $dbtable, $dbtable->getId (), $id);

            $table = $dbtable->getName();
            $statsUrl = $context->chooseUrl ("stats/$table/$id", "index.php?c=ContentPage&mode=stats&tn=$table&id=$id");
            $scheduleUrl = $context->processUrl ("index.php?c=sports/MatchList&leagueid=$id", true);

            $name = $row[ContentTable::COL_DISPLAY_NAME];
            $competitions[$newLevel]['names'][] = array ('url' => $url, 'name' => $name, 'statsUrl' => $statsUrl, 'scheduleUrl' => $scheduleUrl);
            }

        ksort ($competitions);
        return $competitions;
        }

    public function getScheduleLinkLabel ()
        {
        return $this->getText ("Schedule");
        }

    public function getStatisticsLinkLabel ()
        {
        return $this->getText ("Statistics");
        }

    public function getDisplayTemplateName ()
        {
        return "sports/currentleagues";
        }
    }

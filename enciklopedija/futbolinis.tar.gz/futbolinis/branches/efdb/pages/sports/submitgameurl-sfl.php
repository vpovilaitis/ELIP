<?php

class PreprocessedMatchUrlContentSfl extends PreprocessedMatchUrlContent
    {
    protected function initialize ($content)
        {
        $content = cutTextPiece ($content, '<div id="content">', '<!--KOMENTARAI-->');
        if (false === $content)
            return $this->logError ("Cannot parse given URL content");
        
        $description = cutTextPiece ($content, '<td class="info">', "</table>", true);
        if (false === $description)
            return $this->logError ("Cannot parse given URL description");

        if (preg_match_all ("#<a href=\"/teisejas/[0-9]+-[^/]+/\"\s*>([^<]+)</a>#", $content, $matches) > 0)
            {
            $refereeArray = $matches[1];

            if (3 == count ($refereeArray))
                {
                $this->referees["refereeA1"] = $refereeArray[0];
                $this->referees["referee"] = $refereeArray[1];
                $this->referees["refereeA2"] = $refereeArray[2];
                }
            else if (2 == count ($refereeArray))
                {
                $this->referees["refereeA1"] = $refereeArray[0];
                $this->referees["refereeA2"] = $refereeArray[1];
                }
            else if (1 == count ($refereeArray))
                {
                $this->referees["referee"] = $refereeArray[0];
                }
            else
                return $this->logError ("Cannot parse given URL referees");
            }
        else if (false !== strpos ($description, 'Teisėjas:'))
            {
            $referees = cutTextPiece ($description, 'Teisėjas:', "</a>", false);
            if (false === $referees)
                return $this->logError ("Cannot parse given URL referees");
            $referees = strip_tags ($referees);
            }

        $score = "";
        if (preg_match_all ('#text.php\?a=([0-9:]+)"#', $description, $matches) > 0)
            {
            foreach ($matches[1] as $scorePart)
                {
                $score .= $scorePart;
                }
            }

        if (empty ($score) || false === $this->setScore ($score))
            return $this->logError ("Cannot parse score");

$this->writeLine ("<pre>$score\n</pre>");

        $events = cutTextPiece ($content, '<!--KORTELES-->', "<!--// KORTELES-->");
        if (false === $events)
            return $this->logError ("Cannot parse events");
        $events = trim ($events);
        if (!empty ($events))
            $this->setEvents ($events);

        $this->setDescription ($description);

        if (trim ($score) != "0:0")
            {
            $goals = cutTextPiece ($content, '<!--IVARCIAI-->', "<!--// IVARCIAI-->");
            if (false === $goals)
                return $this->logError ("Cannot parse goals");

            $this->setGoals ($goals);
            }

        $players = cutTextPiece ($content, '<!--ZAIDEJAI-->', "<!--// ZAIDEJAI-->");
        if (!empty ($players))
            {
            $homePlayers = cutTextPiece ($players, '<td style="width: 50%;">', "</td>", true, true);
            $awayPlayers = cutTextPiece ($players, '<td style="width: 50%;">', "</td>", true, true);
            $this->homePlayers = $this->parsePlayers ($homePlayers);
            $this->awayPlayers = $this->parsePlayers ($awayPlayers);
            }

        if (!empty ($referees))
            {
            $this->referees["referee"] = $referees;
            }
        }

    protected function parsePlayers ($content)
        {
        if (empty ($content))
            return NULL;

        $parts = preg_split ('#<hr class="lineup">#', $content, 2);
        $ret = NULL;
        if (preg_match_all ("#<a href=\"(/zaidejas/[0-9]+-[^/]+/)\"\s*>(.+)</a>#uU", $parts[0], $matches) > 0)
            {
            foreach ($matches[2] as $key => $player)
                {
                $ret[] = array ("name" => $player, "url" => "http://www.sfl.lt".$matches[1][$key]);
                }
            if (11 != count ($ret))
                $this->logError ("Incorrect number of players (".count ($ret).") on field at start of the game");
            }

        if (count ($parts) > 1 && preg_match_all ("#<a href=\"(/zaidejas/[0-9]+-[^/]+/)\"\s*>(.+)</a>#", $parts[1], $matches) > 0)
            {
            foreach ($matches[2] as $key => $player)
                {
                $ret[] = array ("name" => $player, "url" => "http://www.sfl.lt".$matches[1][$key], "unused" => true);
                }
            }

        return $ret;
        }

    public function setDescription ($description)
        {
        preg_match ('/([12][0-9]{3})\s+([0-9]{2})\s+([0-9]{2})\s+([0-9]{2}\:[0-9]{2})/um', $description, $matches);
        if (count ($matches) < 4)
            return $this->logError ("Cannot parse date ".strip_tags ($description));
        $date = $matches[1]."-".$matches[2]."-".$matches[3]." ".$matches[4];
        $this->date = $date;

        preg_match ('/Stadionas\: (.+)/u', $description, $matches);
        if (count ($matches) == 2)
            $this->stadium = trim (strip_tags ($matches[1]));
        }

    protected function parseEvents (&$events, $eventList, $min = NULL)
        {
        $eventLines = explode ("<br />", $eventList);
        foreach ($eventLines as $event)
            {
            $event = trim ($event);
            if (empty ($event))
                continue;

            if (preg_match ('#a href=("(/zaidejas/[0-9]+-[^/]+/)"|"(/player.php\?id\=[0-9]+)" class="komanda")\s*>(.+)</a#', $event, $matches) > 0)
                {
                $name = $matches[4];
                $url = "http://www.sfl.lt".(empty ($matches[2]) ? $matches[3] : $matches[2]);
                }
            else
                {
                $this->logError ("Cannot parse player ".strip_tags ($event));
                continue;
                }

            $type = cutTextPiece ($event, 'img src="/images/', '.gif"', false);
            if (false != strpos ($event, "Į savo vartus"))
                $type = RawEvent::EVENT_OWN_GOAL;
            else if (false != strpos ($event, "(11 m.)"))
                $type = RawEvent::EVENT_PENALTY;
            else if ("yellow" == $type && false != strpos ($event, "red.gif"))
                $type = RawEvent::EVENT_YELLOW_RED;
            $events[] = new SflEvent ($type, $name, $min, $url);
            }

        return $events;
        }

    public function setEvents ($events)
        {
        $homeEvents = cutTextPiece ($events, '<td style="width:40%">', '</td>', true);
        if (false === $homeEvents)
            return $this->logError ("Cannot parse home events");
        $awayEvents = cutTextPiece ($events, '<td style="width:40%">', '</td>', true);
        if (false === $awayEvents)
            return $this->logError ("Cannot parse away events");

        if (!empty ($homeEvents))
            $this->parseEvents ($this->homeEvents, $homeEvents);
        if (!empty ($awayEvents))
            $this->parseEvents ($this->awayEvents, $awayEvents);
        }

    public function setGoals ($text)
        {
        while (false !== ($goalLine = cutTextPiece ($text, '<tr>', "</tr>", true, true)))
            {
            $line = trim ($goalLine);
            if (false !== strpos ($line, '<th colspan="3" class="heading_row">'))
                continue;

            $homeEvent = cutTextPiece ($goalLine, '<td style="width:40%', '</td>', true);
            $eventTime = cutTextPiece ($goalLine, '<td style="width:20%', '</td>', true);
            $awayEvent = cutTextPiece ($goalLine, '<td style="width:40%', '</td>', true);

            if (false === $homeEvent || false === $eventTime || false === $awayEvent)
                {
                return $this->logError ("Cannot parse goal '".htmlspecialchars ($line)."'");
                }

            preg_match ('/\[([0-9]{1,3}) min\./u', trim ($eventTime), $matches);
            if (count ($matches) < 2)
                return $this->logError ("Cannot parse event (goal - '$eventTime')");

            $min = $matches[1];
            $homeEvent = trim ($homeEvent, " ;<>\"");
            $awayEvent = trim ($awayEvent, " ;<>\"");
            if (empty ($homeEvent) == empty ($awayEvent))
                return $this->logError ("Cannot parse event ($homeEvent $eventTime $awayEvent)");

            if (!empty ($homeEvent))
                $this->parseEvents ($this->homeEvents, $homeEvent, $min);
            else
                $this->parseEvents ($this->awayEvents, $awayEvent, $min);
            }
        

        }
    }

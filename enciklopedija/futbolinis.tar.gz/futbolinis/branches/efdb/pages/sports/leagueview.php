<?php
require_once (PATH."pages/contentview.php");
require_once (PATH."pages/relatedurllist.php");
require_once (PATH."pages/sports/leaguebox.php");

class LeagueView extends ContentView
    {
    protected $navigationBox = NULL;

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $context->addStyleSheet ("sports");
        }

    public function getDetailedDescription ()
        {
        return null;
        }

    public function ensureChildren ($context, $request)
        {
        parent::ensureChildren ($context, $request);

        if (NULL != $this->dbtable)
            {
            $this->navigationBox = new LeagueBox ($this->context, $this->dbtable, $this->getIds ());
            $this->addComponent ($request, "leagues", $this->navigationBox);
            $this->addComponent ($request, "relatedurls", new RelatedUrlList ($this->context, $this->dbtable, $this->getIds ()));
            }

        if (SIMPLIFIED_TEAM_LABELS)
            {
            $dbtable = new CompetitionNamesTable ($context);
            if ($dbtable->canEdit ())
                {
                $context->addScriptFile ("sports");
                $script = "attachCompetitionView ();";
                $this->addComponent ($context, "script", new StartupScript ($context, $script));
                }
            }
        }

    public function getNavigationBox ()
        {
        return $this->navigationBox;
        }

    public function getTemplateName ()
        {
        return "sports/competitionwithbox";
        }
    }


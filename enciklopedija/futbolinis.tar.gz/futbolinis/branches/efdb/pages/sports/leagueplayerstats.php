<?php
require_once (PATH."inc/sports/constants.php");
require_once (PATH."inc/sports/common.php");
require_once (PATH."inc/preview.php");

abstract class LeaguePlayerStats extends Preview
    {
    protected $leagueId;
    protected $selectHierarchy;

    const ITEMS_SHOWN_DEFAULT = 10;

    public function __construct ($context, $targetTable, $leagueId, $selectHierarchy = false)
        {
        $table = ContentTable::createInstanceByName ($context, $targetTable);
        $this->leagueId = $leagueId;
        $this->selectHierarchy = $selectHierarchy;
        parent::__construct ($targetTable, $context, $table);
        $context->addStyleSheet ("sports");
        }

    protected abstract function getColumnName ();

    protected function getDisplayTemplate ()
        {
        $playerColumn = $this->dbtable->findColumn ($this->getColumnName ());
        return array
            (
            new LabelRelationFieldTemplate ($this->context, "i", $playerColumn),
            new GoalCountField ($this->context, "i")
            );
        }

    protected function getMaxItemCount ()
        {
        return self::ITEMS_SHOWN_DEFAULT;
        }

    protected function getMinEventCount ()
        {
        return 1;
        }

    abstract protected function getHomeTeamColumnName ();

    public function select ($context, $criteria = NULL)
        {
        if (NULL == $this->dbtable)
            return false;

        $params[] = new LimitByPage (0, $this->getMaxItemCount ());
        $joins = NULL;

        $this->prepareQuery ($cols, $criteria, $joins, $params);

        $errorTarget = $this->context->setErrorTarget ($this);
        $ret = $this->dbtable->selectBy ($cols, $criteria, $joins, $params);
        $this->context->setErrorTarget ($errorTarget);
        
        if (!empty ($ret))
            {
            $lng = Language::getInstance ($context);
            $teamIds = array ();
            foreach ($ret as $row)
                {
                if (empty ($row["teamMax"]) && empty ($row["teamMin"]))
                    continue;

                if (false === array_search ($row["teamMax"], $teamIds))
                    $teamIds[] = $row["teamMax"];
                if (false === array_search ($row["teamMin"], $teamIds))
                    $teamIds[] = $row["teamMin"];
                }

            $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
            $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);
            foreach ($ret as &$row)
                {
                if (!empty ($row["player.c_".Sports::COL_PERSON_FIRST_NAME]) && !empty ($row["player.c_".Sports::COL_PERSON_SURNAME]))
                    {
                    $row["player.".ContentTable::COL_DISPLAY_NAME] = utf8_substr ($row["player.c_".Sports::COL_PERSON_FIRST_NAME], 0, 1).". ".$row["player.c_".Sports::COL_PERSON_SURNAME];
                    }
                else
                    $row["player.".ContentTable::COL_DISPLAY_NAME] = $row["player.c_".Sports::COL_PERSON_SURNAME];

                if (empty ($row["teamMax"]) && empty ($row["teamMin"]))
                    continue;

                if ($row["teamMax"] == $row["teamMin"])
                    $row["team"] = $lng->beautifyTeamLabel ($teamLabels[$row["teamMin"]]);
                else
                    {
                    $row["team"] = $lng->beautifyTeamLabel ($teamLabels[$row["teamMin"]]).", ".$lng->beautifyTeamLabel ($teamLabels[$row["teamMax"]]);
                    $cnt = $row["teamCnt"];
                    while ($cnt > 2)
                        {
                        $row["team"] .= ", ...";
                        $cnt--;
                        }
                    }
                }
            }

        return $ret;
        }

    protected function prepareRowCountQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $matchTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        if (empty ($matchTable) || empty ($teamsTable))
            {
            $this->setError ("Matches table not found");
            return false;
            }

        $joinCriteria = array (new JoinColumnsCriterion ($matchTable->getIdColumn (), $matchTable->getIdColumn ()));
        if ($this->selectHierarchy)
            {
            $competitionTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
            $this->leagueId = SportsHelper::selectCompetitionHierarchyIds ($this->context, $competitionTable,
                                                                           is_array ($this->leagueId) ? $this->leagueId  : array ($this->leagueId ));
            }

        if (is_array ($this->leagueId))
            $joinCriteria[] = new InCriterion (ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id"), $this->leagueId);
        else
            $joinCriteria[] = new EqCriterion ("cstage", $this->leagueId);
        $joinCriteria[] = new InCriterion ("c_outcome", array (MatchConstants::OUTCOME_NOT_STARTED, MatchConstants::OUTCOME_FULL_TIME,
                                                               MatchConstants::OUTCOME_EXTRA_TIME, MatchConstants::OUTCOME_PENALTIES,
                                                               MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_PENALTIES_AWAY),
                                                               MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT);
        $joinCriteria[] = new LogicalOperatorOr (new EqCriterion ("c_exclude", 0), new IsNullCriterion ("c_exclude"));
        $matchTableColumns = array ();
        $isHomeTeamColumn = $this->getHomeTeamColumnName ();
        if (!empty ($isHomeTeamColumn))
            {
            $isHomeTeamColumn = "c_".$isHomeTeamColumn;
            $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $teamsTable->getIdColumn ());
            $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $teamsTable->getIdColumn ());
            $matchTableColumns[] = new ConditionalMaxColumn ("teamMax", "$isHomeTeamColumn = 1", $homeTeamColumn, $awayTeamColumn);
            $matchTableColumns[] = new ConditionalMinColumn ("teamMin", "$isHomeTeamColumn = 1", $homeTeamColumn, $awayTeamColumn);
            $matchTableColumns[] = new ConditionalDistinctCountColumn ("teamCnt", "$isHomeTeamColumn = 1", $homeTeamColumn, $awayTeamColumn);
            }

        $joins[] = $matchTable->createQuery ($matchTableColumns, $joinCriteria);

        $personColumn = "f_".$this->getColumnName ()."_persons_id";
        $criteria[] = new GtCriterion ($personColumn, 0);

        if (empty ($params) || count ($params) < 1 || !$params[0] instanceof LimitByPage)
            $params[] = new LimitByPage (0, 1);

        $params[] = new OrderBy (array (new OrderByColumn ("cnt", false, 1, true)));
        $params[] = new GroupBy (array ($personColumn));
        $params[] = new HavingCriteria ("cnt >= {$this->getMinEventCount()}");
        }

    public function getActionList ($excludeDelete = false)
        {
        return array ();
        }

    public function isVisible ()
        {
        if ($this->getTotalCount () <= 0)
            return false;

        return true;
        }

    public function getFullListUrl ()
        {
        return NULL;
        }

    public function getFullListLabel ()
        {
        return $this->getText ("Show full list");
        }

    public function getTemplateName ()
        {
        return "sports/leaguescorers";
        }
    }

class GoalCountField extends LabelIntFieldTemplate
    {
    public function __construct ($context, $prefix)
        {
        parent::__construct ($prefix, "cnt", $context->getText ("Goals"));
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        $resultColumns[] = new FunctionCount ("*", "cnt");
        }
    }
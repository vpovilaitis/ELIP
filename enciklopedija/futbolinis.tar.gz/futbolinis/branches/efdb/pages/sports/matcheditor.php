<?php
require_once (PATH.'pages/contentinstanceeditor.php');
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'pages/sports/matchview.php');
require_once (PATH.'pages/sports/resultfieldtemplate.php');
require_once (PATH.'pages/sports/matchrefereefield.php');
require_once (PATH.'pages/sports/matchplayerfield.php');
require_once (PATH.'pages/sports/matchgoalfield.php');
require_once (PATH.'pages/sports/matcheventfield.php');
require_once (PATH.'pages/sports/substitutefield.php');

class MatchEditor extends ContentInstanceEditor
    {
    const PLAYER_COUNT = 11;
    const SUBSTITUTE_COUNT = 7;
    const MAX_SUBSTITUTED = 5;
    const GOAL_COUNT = 10;
    const EVENT_COUNT = 10;

    protected $includedFields = array ();
    protected $relatedDataFields;
    protected $mode;
    protected $childrenCache = array ();
    protected $headerFields;
    protected $matchRow = NULL;
    protected $matchPlayerFieldKeys = array ();
    protected $goalCount = NULL;
    protected $eventCount = NULL;
    protected $playerCounts = NULL;

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);

        if (empty ($_REQUEST["parts"]) || !is_numeric ($_REQUEST["parts"]))
            $this->mode = MatchEditorMode::RESULT | MatchEditorMode::HEADER | MatchEditorMode::DESCRIPTION;
        else
            $this->mode = (int)$_REQUEST["parts"];

        $this->headerFields = array ("cstage", "hometeam", "awayteam",
                                     "stadium", "c_time", "round", "c_no", "c_".Sports::COL_MATCH_NUMBER);
        }

    protected function collectTemplateFields ($request, $isCreating)
        {
        $fields = parent::collectTemplateFields ($request, $isCreating);

        if ($this->isComplexView () && NULL === $this->relatedDataFields)
            {
            $this->relatedDataFields = false;
            $this->relatedDataFields = $this->createRelatedDataFields ($this->context);
            $fields = array_merge ($fields, $this->relatedDataFields);
            $this->template = $this->fields = $fields;
            }

        return $fields;
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        $context->addScriptFile ("sports");
        $context->addStyleSheet ("sports_editor");
        $script = "attachMatchEditor ('".$this->getPrefix()."');";
        $this->addComponent ($context, "script", new StartupScript ($context, $script));
        return true;
        }

    protected function createField ($request, $prefix, $col)
        {
        $complexView = $this->isComplexView ();

        if ($complexView && ("homeresult" == $col->name || "awayresult" == $col->name))
            return NULL;

        $field = parent::createField ($request, $prefix, $col);
        if (empty ($field))
            return $field;

        if ($field instanceof RelationAutocompleteField)
            {
            if ($field->key == "hometeam" || $field->key == "awayteam")
                $field->setServiceName ("sports/TeamNameService");
            }

        if (!$complexView)
            return $field;

        if (0 == (MatchEditorMode::RESULT & $this->mode) &&
            (Sports::COL_MATCH_SPECTATORS == $col->name || Sports::COL_MATCH_OUTCOME == $col->name ||
             Sports::COL_MATCH_EXCLUDED == $col->name || Sports::COL_MATCH_UNOFFICIAL == $col->name ||
             Sports::COL_MATCH_RELIABILITY == $col->name))
            {
            return NULL;
            }

        if (0 == (MatchEditorMode::HEADER & $this->mode) && false !== array_search ($field->key, $this->headerFields))
            return NULL;

        if (0 == ((MatchEditorMode::HEADER|MatchEditorMode::PLAYERS) & $this->mode) && ("homecoach" == $field->key || "awaycoach" == $field->key))
            return NULL;

        if (0 == (MatchEditorMode::DESCRIPTION & $this->mode) && ("c_description" == $field->key || "c_reliability" == $field->key))
            {
            return NULL;
            }
        else if ("c_description" == $field->key)
            {
            $field->cssClass = "description";
            }
        

        return $field;
        }

    public function isComplexView ()
        {
        $template = parent::getTemplateName ();
        return !$this->flatTemplate;
        }

    public function getTemplateName ()
        {
        $ret = parent::getTemplateName ();
        if ("instanceeditor" == $ret)
            $ret = "sports/matcheditor";

        return $ret;
        }

    public function getFields ($zone = NULL)
        {
        $fields = parent::getFields ();
        switch ($zone)
            {
            case "top":
                if (0 == (MatchEditorMode::HEADER & $this->mode))
                    return NULL;
                $fields = $this->filterFields ($fields, $this->headerFields);
                break;
            case "result":
                if (0 == (MatchEditorMode::RESULT & $this->mode))
                    return NULL;
                $fields = $this->filterFields ($fields, array ("c_outcome", ResultFieldTemplate::KEY_RESULT_FULL_TIME, ResultFieldTemplate::KEY_RESULT_HALF_TIME, ResultFieldTemplate::KEY_RESULT_EXTRA_TIME, ResultFieldTemplate::KEY_RESULT_PENALTIES, "c_attendance", "c_exclude"));
                break;
            case "referees":
                if (0 == (MatchEditorMode::REFEREES & $this->mode))
                    return NULL;

                $fields = $this->filterFields ($fields, array (MatchRefereeField::KEY_REFEREE_PRIMARY,
                                                               MatchRefereeField::KEY_REFEREE_ASISTANT1,
                                                               MatchRefereeField::KEY_REFEREE_ASISTANT2,
                                                               MatchRefereeField::KEY_REFEREE_RESERVE,
                                                               MatchRefereeField::KEY_REFEREE_INSPECTOR,
                                                               MatchRefereeField::KEY_REFEREE_DELEGATE));
                break;

            case "goals":
                if (0 == (MatchEditorMode::GOALS & $this->mode))
                    return NULL;

                $goalCount = $this->getGoalCount ();
                $goalFields = array ("goalcount");
                for ($i = 0; $i < $goalCount; $i++)
                    $goalFields[] = MatchGoalField::getKey ($i);
                $fields = $this->filterFields ($fields, $goalFields);
                break;

            case "events":
                if (0 == (MatchEditorMode::EVENTS & $this->mode))
                    return NULL;

                $eventFields = array ("eventcount");
                $eventCount = $this->getEventCount ();
                for ($i = 0; $i < $eventCount; $i++)
                    $eventFields[] = MatchEventField::getKey ($i);
                $fields = $this->filterFields ($fields, $eventFields);
                break;

            case "homeplayers":
                if (0 == (MatchEditorMode::PLAYERS & $this->mode))
                    return NULL;

                list ($homePlayers, $homeSubstitutePlayers, $homeSubstitutions,
                      $awayPlayers, $awaySubstitutePlayers, $awaySubstitutions) = $this->getPlayerCounts ();

                $playerFields = array ();
                for ($i = 0; $i < $homePlayers; $i++)
                    $playerFields[] = MatchPlayerField::getKey (true, false, $i);
                for ($i = 0; $i < $homeSubstitutePlayers; $i++)
                    $playerFields[] = MatchPlayerField::getKey (true, true, $i);
                $playerFields[] = "homecoach";
                for ($i = 0; $i < $homeSubstitutions; $i++)
                    $playerFields[] = SubstituteField::getKey (true, $i);

                $fields = $this->filterFields ($fields, $playerFields);
                break;
            case "awayplayers":
                if (0 == (MatchEditorMode::PLAYERS & $this->mode))
                    return NULL;

                list ($homePlayers, $homeSubstitutePlayers, $homeSubstitutions,
                      $awayPlayers, $awaySubstitutePlayers, $awaySubstitutions) = $this->getPlayerCounts ();

                $playerFields = array ();
                for ($i = 0; $i < $awayPlayers; $i++)
                    $playerFields[] = MatchPlayerField::getKey (false, false, $i);
                for ($i = 0; $i < $awaySubstitutePlayers; $i++)
                    $playerFields[] = MatchPlayerField::getKey (false, true, $i);
                $playerFields[] = "awaycoach";
                for ($i = 0; $i < $awaySubstitutions; $i++)
                    $playerFields[] = SubstituteField::getKey (false, $i);

                $fields = $this->filterFields ($fields, $playerFields);
                break;
            case "bottom":
                if (0 == (MatchEditorMode::DESCRIPTION & $this->mode))
                    return NULL;
                $fields = $this->filterFields ($fields, array ("c_description"));
                break;
            default:
                $zone = "";
                break;
            }

        if (!empty ($zone))
            {
            foreach ($fields as $field)
                $this->includedFields[] = $field->key;
            }
        else
            {
            $notIncluded = array ();
            foreach ($fields as $field)
                {
                if (false === array_search ($field->key, $this->includedFields))
                    {
                    if ($field->readonly)
                        continue;
                    $notIncluded[] = $field;
                    }
                }

            $fields = $notIncluded;
            }

        $this->log ("MatchEditor::getFields ($zone) finished");
        return $fields;
        }

    public function getComponents ()
        {
        return array ($this->components["script"]);
        }

    protected function getTemplateParts ($request)
        {
        $fields = parent::getTemplateParts ($request);
        if ($this->isComplexView ())
            {
            if (!empty ($this->relatedDataFields))
                $fields = array_merge ($fields, $this->relatedDataFields);
            }
        return $fields;
        }

    protected function createRelatedDataFields ()
        {
        $fields = array ();

        if (MatchEditorMode::RESULT == (MatchEditorMode::RESULT & $this->mode))
            {
            $fields[] = new ResultFieldTemplate ($this->context, $this->getPrefix (),
                                             ResultFieldTemplate::KEY_RESULT_FULL_TIME,
                                             $this->getText ("Final score:"),
                                             $this->getText ("Enter match result after full time (two halfs)."),
                                             $this->getText ("full time score, not including extra time and penalty shootout."));
            $fields[] = new ResultFieldTemplate ($this->context, $this->getPrefix (),
                                             ResultFieldTemplate::KEY_RESULT_HALF_TIME,
                                             $this->getText ("Half time:"),
                                             $this->getText ("Enter match result after first half."),
                                             $this->getText ("score after first half."));
            $fields[] = new ResultFieldTemplate ($this->context, $this->getPrefix (),
                                             ResultFieldTemplate::KEY_RESULT_EXTRA_TIME,
                                             $this->getText ("Extra time:"),
                                             $this->getText ("Enter match result after extra time."),
                                             $this->getText ("(leave empty if extra time was not played)"));
            $fields[] = new ResultFieldTemplate ($this->context, $this->getPrefix (),
                                             ResultFieldTemplate::KEY_RESULT_PENALTIES,
                                             $this->getText ("After penalties:"),
                                             $this->getText ("Enter match result after penalties (including extra time score)."),
                                             $this->getText ("final result after penalty shootout (including extra time score)."));
            }

        if (MatchEditorMode::REFEREES == (MatchEditorMode::REFEREES & $this->mode))
            {
            $fields[] = new MatchRefereeField ($this->context, $this->getPrefix (),
                                         MatchRefereeField::KEY_REFEREE_PRIMARY,
                                         $this->getText ("Referee:"),
                                         $this->getText ("Match referee (with origin and category)."));
            $fields[] = new MatchRefereeField ($this->context, $this->getPrefix (),
                                         MatchRefereeField::KEY_REFEREE_ASISTANT1,
                                         $this->getText ("Assistant:"),
                                         $this->getText ("Referee assistant (with origin and category)."));
            $fields[] = new MatchRefereeField ($this->context, $this->getPrefix (),
                                         MatchRefereeField::KEY_REFEREE_ASISTANT2,
                                         $this->getText ("Assistant:"),
                                         $this->getText ("Referee assistant (with origin and category)."));
            $fields[] = new MatchRefereeField ($this->context, $this->getPrefix (),
                                         MatchRefereeField::KEY_REFEREE_RESERVE,
                                         $this->getText ("Fourth referee:"),
                                         $this->getText ("Reserve referee (with origin and category)."));
            $fields[] = new MatchRefereeField ($this->context, $this->getPrefix (),
                                         MatchRefereeField::KEY_REFEREE_INSPECTOR,
                                         $this->getText ("Inspector:"),
                                         $this->getText ("Match inspector."));
            $fields[] = new MatchRefereeField ($this->context, $this->getPrefix (),
                                         MatchRefereeField::KEY_REFEREE_DELEGATE,
                                         $this->getText ("Delegate:"),
                                         $this->getText ("Match delegate."));
            }

        if (MatchEditorMode::PLAYERS == (MatchEditorMode::PLAYERS & $this->mode))
            {
            list ($homePlayers, $homeSubstitutePlayers, $homeSubstitutions,
                  $awayPlayers, $awaySubstitutePlayers, $awaySubstitutions) = $this->getPlayerCounts ();
            for ($i = 0; $i < $homePlayers; $i++)
                {
                $fields[] = $this->createMatchPlayerField ($this->getText ("Player:"),
                                                 $this->getText ("Home player."),
                                                 true, false, $i);
                }
            for ($i = 0; $i < $homeSubstitutePlayers; $i++)
                {
                $fields[] = $this->createMatchPlayerField ($this->getText ("Substitute:"),
                                                 $this->getText ("Substitute."),
                                                 true, true, $i);
                }
            for ($i = 0; $i < $homeSubstitutions; $i++)
                {
                $fields[] = new SubstituteField ($this->context, $this->getPrefix (),
                                                 $this->getText ("Substitution:"),
                                                 $this->getText ("Substitution."),
                                                 true, $i);
                }
            for ($i = 0; $i < $awayPlayers; $i++)
                {
                $fields[] = $this->createMatchPlayerField ($this->getText ("Player:"),
                                                 $this->getText ("Away player."),
                                                 false, false, $i);
                }
            for ($i = 0; $i < $awaySubstitutePlayers; $i++)
                {
                $fields[] = $this->createMatchPlayerField ($this->getText ("Substitute:"),
                                                 $this->getText ("Substitute."),
                                                 false, true, $i);
                }
            for ($i = 0; $i < $awaySubstitutions; $i++)
                {
                $fields[] = new SubstituteField ($this->context, $this->getPrefix (),
                                                 $this->getText ("Substitution:"),
                                                 $this->getText ("Substitution."),
                                                 false, $i);
                }

            $fields[] = new HiddenAdditionalFieldTemplate ($this->getPrefix (), "playercount");
            }


        if (MatchEditorMode::GOALS == (MatchEditorMode::GOALS & $this->mode))
            {
            $homeGoals = 0;
            $goalCount = $this->getGoalCount ($homeGoals);
            for ($i = 0; $i < $goalCount; $i++)
                {
                $fields[] = new MatchGoalField ($this->context, $this->getPrefix (),
                                                 $this->getText ("Goal:"),
                                                 $this->getText ("Goal."), $i, $i < $homeGoals);
                }
            $fields[] = new HiddenAdditionalFieldTemplate ($this->getPrefix (), "goalcount");
            }

        if (MatchEditorMode::EVENTS == (MatchEditorMode::EVENTS & $this->mode))
            {
            $eventCount = $this->getEventCount ();
            for ($i = 0; $i < $eventCount; $i++)
                {
                $fields[] = new MatchEventField ($this->context, $this->getPrefix (),
                                                 $this->getText ("Player no:"),
                                                 $this->getText ("Yellow or red card."), $i);
                }
            $fields[] = new HiddenAdditionalFieldTemplate ($this->getPrefix (), "eventcount");
            }

        return $fields;
        }

    protected function getPlayerCounts ()
        {
        if (NULL !== $this->playerCounts)
            return explode (",", $this->playerCounts);

        $id = $this->getIds ();
        $cnt = NULL;

        $idColumns = $this->dbtable->getPrimaryIndexColumns ();
        $criteria = array (new EqCriterion ($idColumns[0]->name, $id[0]));

        $existingCount = MatchPlayerField::getCount ($this->context, $this->request, $criteria, $this->childrenCache);

        list ($homeCount, $homeSubstCount, $homeSubst, $awayCount, $awaySubstCount, $awaySubst) = $existingCount;
        if ($homeCount < self::PLAYER_COUNT)
            $homeCount = self::PLAYER_COUNT;
        if ($awayCount < self::PLAYER_COUNT)
            $awayCount = self::PLAYER_COUNT;
        if ($homeSubstCount < self::SUBSTITUTE_COUNT)
            $homeSubstCount = self::SUBSTITUTE_COUNT;
        if ($awaySubstCount < self::SUBSTITUTE_COUNT)
            $awaySubstCount = self::SUBSTITUTE_COUNT;
        if ($homeSubst < self::MAX_SUBSTITUTED)
            $homeSubst = self::MAX_SUBSTITUTED;
        if ($awaySubst < self::MAX_SUBSTITUTED)
            $awaySubst = self::MAX_SUBSTITUTED;

        $this->playerCounts = implode (",", array ($homeCount, $homeSubstCount, $homeSubst, $awayCount, $awaySubstCount, $awaySubst));
        return explode (",", $this->playerCounts);
        }

    protected function getGoalCount (&$homeGoals = NULL)
        {
        if (NULL !== $this->goalCount)
            return $this->goalCount;

        $id = $this->getIds ();
        $cnt = NULL;
        $instance = $this->retrieveMatchItem ($this->request, $id);
        if (NULL !== $instance["c_homeresult"] && NULL !== $instance["c_awayresult"])
            {
            $cnt = $instance["c_homeresult"] + $instance["c_awayresult"];
            if (NULL !== $homeGoals)
                $homeGoals = $instance["c_homeresult"];
            }

        if (NULL === $cnt && !empty ($this->request["goalcount"]))
            $cnt = $this->request["goalcount"];

        $idColumns = $this->dbtable->getPrimaryIndexColumns ();
        $criteria = array (new EqCriterion ($idColumns[0]->name, $id[0]));

        $existingCount = MatchGoalField::getCount ($this->context, $this->request, $criteria, $this->childrenCache);
        if ($existingCount > 0 && $existingCount > $cnt)
            $cnt = $existingCount;

        if (NULL === $cnt)
            $cnt = self::GOAL_COUNT;
        $this->goalCount = $cnt;
        return $this->goalCount;
        }

    protected function getEventCount ()
        {
        if (NULL !== $this->eventCount)
            return $this->eventCount;

        $id = $this->getIds ();
        $cnt = NULL;
        if (!empty ($this->request["eventcount"]))
            $cnt = $this->request["eventcount"];

        if (NULL === $cnt)
            $cnt = self::EVENT_COUNT;

        $idColumns = $this->dbtable->getPrimaryIndexColumns ();
        $criteria = array (new EqCriterion ($idColumns[0]->name, $id[0]));
        $existingCount = MatchEventField::getCount ($this->context, $this->request, $criteria, $this->childrenCache);
        if ($existingCount > $cnt)
            $cnt = $existingCount;

        $this->eventCount = $cnt;
        return $this->eventCount;
        }

    protected function createMatchPlayerField ($label, $tooltip, $isHome, $substitute, $index)
        {
        $field = new MatchPlayerField ($this->context, $this->getPrefix (), $label, $tooltip, $isHome, $substitute, $index);
        
        $this->matchPlayerFieldKeys[] = MatchPlayerField::getKey ($isHome, $substitute, $index);
        return $field;
        }

    public function getStartupScript ()
        {
        $script = "";
        if (!empty ($this->matchPlayerFieldKeys))
            {
            $url = $this->context->processUrl ("index.php?service=sports/PlayerFromNumberService", true);
            $homeTeam = $awayTeam = $stageId = 0;
            $instance = $this->retrieveMatchItem ($this->request, $this->getIds ());
            if (!empty ($instance))
                {
                $homeTeam = empty ($instance["f_hometeam_team_id"]) ? 0 : $instance["f_hometeam_team_id"];
                $awayTeam = empty ($instance["f_awayteam_team_id"]) ? 0 : $instance["f_awayteam_team_id"];
                $stageId = empty ($instance["f_cstage_competitionstage_id"]) ? 0 : $instance["f_cstage_competitionstage_id"];
                }

            $registeredHomePlayers = array ();
            $registeredAwayPlayers = array ();
            if (!empty ($stageId) && (!empty ($homeTeam) || !empty ($awayTeam)))
                {
                $registrationsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_REGISTRATIONS);
                if (!empty ($registrationsTable))
                    {
                    $teamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_REGISTRATION_TEAM, Sports::TABLE_TEAM."_id");
                    $playerIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_REGISTRATION_PLAYER, Sports::TABLE_PERSON."_id");
                    $criteria = NULL;
                    $criteria[] = new EqCriterion (Sports::COL_REGISTRATION_COMPETITION, $stageId);
                    $criteria[] = new InCriterion ($teamIdColumn, array ($homeTeam, $awayTeam));
                    $columns = array ($teamIdColumn, $playerIdColumn, Sports::COL_REGISTRATION_NUMBER, Sports::COL_REGISTRATION_NUMBERFIXED);
                    $rows = $registrationsTable->selectBy ($columns, $criteria);
                    $playerIds = array ();
                    $rowsByPlayer = array ();
                    foreach (empty ($rows) ? array() : $rows as $row)
                        {
                        $playerIds[] = $row[$playerIdColumn];
                        $rowsByPlayer[$row[$playerIdColumn]] = $row;
                        }

                    $playerNames = empty($playerIds) ? array () : $this->getPlayerLabels ($playerIds);

                    foreach ($playerNames as $playerId => $playerLabel)
                        {
                        $row = $rowsByPlayer[$playerId];
                        $isHomeTeam = $homeTeam == $row[$teamIdColumn];
                        if (empty ($playerLabel))
                            continue;
                        $number = empty ($row["c_".Sports::COL_REGISTRATION_NUMBER]) || empty ($row["c_".Sports::COL_REGISTRATION_NUMBERFIXED]) ? "null" : $row["c_".Sports::COL_REGISTRATION_NUMBER];
                        $entry = "{id:$playerId,no:$number,name:".formatForJavaScript ($number > 0 ? "$number - $playerLabel" : $playerLabel).'}';
                        if ($homeTeam == $row[$teamIdColumn])
                            $registeredHomePlayers[] = $entry;
                        else
                            $registeredAwayPlayers[] = $entry;
                        }
                    }
                }

            $prefixes = "[ '" . implode ("', '", $this->matchPlayerFieldKeys) . "' ]";
            $homePlayers = "[" . implode (",", $registeredHomePlayers) . "]";
            $awayPlayers = "[" . implode (",", $registeredAwayPlayers) . "]";
            $script = "attachMatchPlayerFields ('".$this->getPrefix ()."', '$url', $prefixes, '".Sports::COL_PLAYER_NO."', '".Sports::COL_PLAYER_PERSON."', $homeTeam, $awayTeam, $stageId, $homePlayers, $awayPlayers);";
            $script .= "\nattachMatchSubstituteFields ('".$this->getText ("On [MIN] min [OFF] was replaced by [ON]")."', '".$this->getText ("Unrecognized number [NO]")."');";
            }

        if ($this->showReportImages ($instance))
            $script .= "\nshowMatchReport ('report', '".$this->getText ("Report")."');";

        if (empty ($script))
            return false;

        return new StartupScript ($this->context, $script);
        }

    public function showReportImages ($instance)
        {
        if (!empty ($instance) && !empty ($instance["c_time"]))
            {
            $date = $instance["c_time"];
            // check if match started at least 100 minutes ago
            $currentTime = strftime ("%Y-%m-%d %H:%M:%S", time () - 100 * 60);
            if ($date > $currentTime)
                return false;
            }

        if (0 != ((MatchEditorMode::REFEREES | MatchEditorMode::PLAYERS | MatchEditorMode::GOALS | MatchEditorMode::EVENTS) & $this->mode))
            return true;

        return false;
        }

    public function retrieveImageContext ($instance, $zone, $width, $height)
        {
        if (empty ($this->dbtable))
            return NULL;
        
        $scope = HintsTable::SCOPE_CONTENTTABLE.$this->dbtable->getName ();
        $id = implode (",", $this->getIds ($instance));
        $images = parent::getAllImages ($scope, $id, $zone, $width, $height);
        return $images;
        }

    public function getPlayerLabels ($ids)
        {
        $playersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        $params[] = OrderBy::createByAlias ("c_".Sports::COL_PERSON_SURNAME);
        $rows = $playersTable->selectWithDisplayName (array ($playersTable->getIdColumn ()), array (new InCriterion ($playersTable->getIdColumn (), $ids)), NULL, $params);
        $players = array ();
        if (!empty ($rows))
            {
            foreach ($rows as $row)
                $players[$row[$playersTable->getIdColumn ()]] = $row[ContentTable::COL_DISPLAY_NAME];
            }
        return $players;
        }

    public function getZoneTitle ($zone)
        {
        switch ($zone)
            {
            case "top":
                return $this->getText ("Match information");
            case "result":
                return $this->getText ("Match result");
            case "referees":
                return $this->getText ("Match referees");
            case "goals":
                return $this->getText ("Match goals");
            case "events":
                return $this->getText ("Cautions");
            case "homeplayers":
                return $this->getText ("Home team");
            case "awayplayers":
                return $this->getText ("Away team");
            case "other":
                return $this->getText ("Other information");
            }

        return NULL;
        }

    public function getZoneList ()
        {
        $arr = array ();
        if (0 != (MatchEditorMode::HEADER & $this->mode))
            $arr[] = "top";

        if (0 != (MatchEditorMode::RESULT & $this->mode))
            $arr[] = "result";

        if (0 != (MatchEditorMode::REFEREES & $this->mode))
            $arr[] = "referees";
        if (MatchEditorMode::GOALS == (MatchEditorMode::GOALS & $this->mode))
            $arr[] = "goals";
        if (MatchEditorMode::EVENTS == (MatchEditorMode::EVENTS & $this->mode))
            $arr[] = "events";
        if (0 != (MatchEditorMode::PLAYERS & $this->mode))
            {
            $arr[] = "homeplayers";
            $arr[] = "awayplayers";
            }
        if (0 != (MatchEditorMode::DESCRIPTION & $this->mode))
            $arr[] = "other";
        return $arr;
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);

        if ($this->isComplexView ())
            {
            $resultColumns[] = "c_homeresult";
            $resultColumns[] = "c_awayresult";
            $resultColumns[] = "f_cstage_competitionstage_id";
            }
        }

    protected function retrieveMatchItem ($request, $id, $reset = false)
        {
        if ($reset || NULL === $this->matchRow)
            $this->matchRow = parent::retrieveExisting ($request, $id);

        return $this->matchRow;
        }

    protected function retrieveExisting ($request, $id)
        {
        $this->log ("Retrieving match entry");
        $row = $this->retrieveMatchItem ($request, $id);
        if (empty ($row) || !$this->isComplexView ())
            return $row;

        $idColumns = $this->dbtable->getPrimaryIndexColumns ();
        $criteria = array (new EqCriterion ($idColumns[0]->name, $id[0]));

        foreach ($this->relatedDataFields as $field)
            {
            if (!$field instanceof RelatedRecordField)
                continue;
            $field->retrieveRecord ($this->context, $criteria, $row, $this->childrenCache);
            }

        if (MatchEditorMode::GOALS == (MatchEditorMode::GOALS & $this->mode))
            $row["goalcount"] = $this->getGoalCount ();
        if (MatchEditorMode::EVENTS == (MatchEditorMode::EVENTS & $this->mode))
            $row["eventcount"] = $this->getEventCount ();

        return $row;
        }

    protected function createRecord (&$request, $values)
        {
        if (!$this->isComplexView ())
            return parent::createRecord ($request, $values);

        $related = $this->prepareRelatedData ($request, $values);
        if (false === $related)
            return false;
        $ret = parent::createRecord ($request, $values);
        if (!$ret)
            return $ret;

        if (!$this->updateRelatedData ($this->getIds (), $related, $values, NULL))
            return false;
        return $ret;
        }

    protected function modifyRecord ($request, $id, $values)
        {
        if (!$this->isComplexView ())
            return parent::modifyRecord ($request, $id, $values);

        $related = $this->prepareRelatedData ($request, $values);
        if (false === $related)
            return false;
        $ret = parent::modifyRecord ($request, $id, $values);
        if (!$ret)
            return $ret;

        // update cached instance
        $modifiedRow = $this->retrieveMatchItem ($request, $id, true);
        $this->partiallyUpdateInitialValues ($modifiedRow);
        
        // modify related info
        if (false === $this->updateRelatedData ($id, $related, $values, $modifiedRow))
            {
            $this->log ("Failed to update related match data");
            return false;
            }
        return $ret;
        }

    protected function prepareRelatedData ($request, &$values)
        {
        $source = trim ($values[DBTable::COL_SOURCE]);
        if (empty ($source))
            {
            $this->addError ("Please enter source (or change comment)");
            if (!DEBUG)
                return false;
            }

        $output = array ();
        $initialValues = $this->getInitialValues ();

        foreach ($this->relatedDataFields as $field)
            {
            if (!$field instanceof RelatedRecordField)
                {
                unset ($values[$field->key]);
                continue;
                }
            if (false === $field->prepareForStoring ($this->context, $values, $initialValues, $output))
                return false;
            }

        return $output;
        }

    protected function updateRelatedData ($id, $prepared, $values, $modifiedRow)
        {
        $sourceValues = array ();
        if (!empty ($values[DBTable::COL_SOURCE]))
            $sourceValues[DBTable::COL_SOURCE] = $values[DBTable::COL_SOURCE];
        if (!empty ($values[DBTable::COL_SOURCEDATE]))
            $sourceValues[DBTable::COL_SOURCEDATE] = $values[DBTable::COL_SOURCEDATE];

        $atLeastOneSucceeded = true; // if set to "false", saving will stop if first call fails
        $ret = true;
        foreach ($this->relatedDataFields as $field)
            {
            if (!$field instanceof RelatedRecordField)
                continue;

            if (false === $field->storePreparedRecord ($this->context, $this->request, $id, $prepared, $sourceValues, $modifiedRow))
                {
                if (!$atLeastOneSucceeded)
                    return false;
                $ret = false;
                }

            $atLeastOneSucceeded = true;
            }

        return $ret;
        }

    protected function valueChanged ($initialValues, $key, $newValue)
        {
        if (0 === strncasecmp ($key, "r_", 2) && array_key_exists ($key, $initialValues))
            {
            // data from other tables (match flow, players, etc) should be checked separatelly
            $initialValue = $initialValues[$key];
            return ($initialValue != $newValue);
            }

        return parent::valueChanged ($initialValues, $key, $newValue);
        }
    }

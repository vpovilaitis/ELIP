<?php
require_once (PATH.'pages/sports/matchannouncement.php');

class TeamMatches extends MatchAnnouncement
    {
    protected $teamId;
    protected $dateFrom;
    protected $dateTo;

    public function __construct ($context, $teamId, $prefix = "announce", $dateFrom = NULL, $dateTo = NULL)
        {
        parent::__construct ($context, $prefix, NULL);
        $this->teamId = $teamId;
        $this->showRssLinks = false;
        $this->dateFrom = $dateFrom;
        $this->dateTo = $dateTo;
        }

    protected function selectMatches ($now)
        {
        $cache = Cache::getInstance (Sports::TABLE_MATCH, 6*60*60);
        $cacheId = "teammatches+.$this->teamId.$now.$this->dateFrom.$this->dateTo";

        if (false === ($rows = $cache->get ($cacheId)))
            {
            $collector = new MatchCollector ($this->context, true);
            $rows = $collector->selectTeamMatches ($now, $this->teamId, !empty ($this->dateFrom) ? 20 : 10, $this->dateFrom, $this->dateTo);
            if (!empty ($rows) && !empty ($this->dateFrom))
                {
                $combined = array ();
                foreach ($rows as $rowGroup)
                    $combined = array_merge ($combined, $rowGroup["matches"]);
                $rows = array ($this->getText ("Friendlies") => array ("title" => $this->getText ("Friendlies"), "matches" => $combined));
                }

            $cache->save ($rows, $cacheId);
            }

        return $rows;
        }

    public function isVisible ($inline = false)
        {
        $parts = $this->getDisplayableParts ();
        return !empty ($parts);
        }
    }

<?php
require_once (PATH."pages/sports/teamview.php");

class TeamPreseasonChanges extends StatisticsSection
    {
    private $leagueId;
    private $teamId;

    public function __construct ($parent, $id, $title, $leagueId, $teamId)
        {
        parent::__construct ($parent, $id, $title, NULL, NULL);
        $this->leagueId = $leagueId;
        $this->teamId = $teamId;
        }

    public function getTemplateName ()
        {
        return "sports/preseasonchanges";
        }

    public function isVisible ()
        {
        $this->ensureData ($this->parent->getContext ());
        return count ($this->rows) > 0;
        }

    public function getData ()
        {
        return $this->ensureData ($this->parent->getContext ());
        }

    protected function ensureData ($context)
        {
        $cache = Cache::getInstance (Sports::TABLE_TEAMPLAYER, 6*60*60);
        $cacheId = "teamchanges.$this->leagueId.$this->teamId.".$context->getLanguage ();

        if (false === ($this->rows = $cache->get ($cacheId)))
            {
            $this->rows = array ();

            $competitiontable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
            $personstable = ContentTable::createInstanceByName ($context, Sports::TABLE_PERSON);
            $idColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAMPLAYER_PLAYER, Sports::TABLE_PERSON."_id");
            $staffIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAMSTAFF_PERSON, Sports::TABLE_PERSON."_id");
            
            $columns = array (Sports::COL_COMPETITION_STARTS, Sports::COL_COMPETITION_ENDS);
            $leagueRow = $competitiontable->selectSingleBy ($columns, array (new EqCriterion ($competitiontable->getIdColumn (), $this->leagueId)));
            if (!empty ($leagueRow) && !empty ($leagueRow["c_".Sports::COL_COMPETITION_ENDS]) && !empty ($leagueRow["c_".Sports::COL_COMPETITION_STARTS]))
                {
                $startDate = $leagueRow["c_".Sports::COL_COMPETITION_STARTS];
                $endDate = $leagueRow["c_".Sports::COL_COMPETITION_ENDS];
                $playersLeft = $this->getPlayersChanged ($context, $idColumn, $startDate, $endDate, true);
                $playersJoined = $this->getPlayersChanged ($context, $idColumn, $startDate, $endDate, false);
                $managersLeft = $this->getPersonelChanged ($context, $staffIdColumn, $startDate, $endDate, true);
                $managersJoined = $this->getPersonelChanged ($context, $staffIdColumn, $startDate, $endDate, false);

                $playersJoinedIds = $this->extractIds ($context, $idColumn, $playersJoined);
                $playersLeftIds = $this->extractIds ($context, $idColumn, $playersLeft);
                $playerIds = array_unique (array_merge ($playersLeftIds, $playersJoinedIds,
                                                        $this->extractIds ($context, $staffIdColumn, $managersLeft),
                                                        $this->extractIds ($context, $staffIdColumn, $managersJoined)));
                $labels = SportsHelper::getPlayerLabels ($personstable, $playerIds);
                $playersLeft = $this->mergeMaps ($this->processPlayersList ($context, $personstable, $idColumn, Sports::COL_TEAMPLAYER_POSITION, $playersLeft, $labels, $playersLeftIds, $startDate, $endDate, true),
                                            $this->processList ($context, $personstable, $staffIdColumn, Sports::COL_TEAMSTAFF_ROLE, $managersLeft, $labels));
                if (!empty ($playersLeft))
                    $this->rows[$context->getText ("Personel left:")] = $playersLeft;
                $playersJoined = $this->mergeMaps ($this->processPlayersList ($context, $personstable, $idColumn, Sports::COL_TEAMPLAYER_POSITION, $playersJoined, $labels, $playersJoinedIds, $startDate, $endDate, false),
                                              $this->processList ($context, $personstable, $staffIdColumn, Sports::COL_TEAMSTAFF_ROLE, $managersJoined, $labels));
                if (!empty ($playersJoined))
                    $this->rows[$context->getText ("Personel joined:")] = $playersJoined;
                }

            $cache->save ($this->rows, $cacheId);
            }

        return $this->rows;
        }

    protected function mergeMaps ($arr1, $arr2)
        {
        $arr = empty ($arr1) ? array () : $arr1;
        foreach ($arr2 as $k => $val)
            $arr[$k] = $val;
        return $arr;
        }

    protected function extractIds ($context, $idColumn, $players)
        {
        $ids = array ();
        if (empty ($players))
            return $ids;

        foreach ($players as $row)
            {
            $ids[] = $row[$idColumn];
            }

        return $ids;
        }

    protected function processPlayersList ($context, $personstable, $idColumn, $positionColumn, $players, $labels, $ids, $startDate, $endDate, $left)
        {
        $additional = array ();
        if (!empty ($endDate) && !empty ($ids))
            {
            $rows = $this->getRelatedChanges ($context, NULL, $ids, Sports::TABLE_TEAMPLAYER,
                                         $idColumn, Sports::COL_TEAMPLAYER_STARTED, Sports::COL_TEAMPLAYER_ENDED,
                                         Sports::COL_TEAMPLAYER_TEAM, Sports::COL_TEAMPLAYER_POSITION,
                                         $startDate, $endDate, $left);

            if (!empty ($rows))
                {
                $teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
                $teamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAMPLAYER_TEAM, $teamsTable->getIdColumn ());
                $playerNextTeams = array ();
                $teamIds = array ();
                foreach ($rows as $row)
                    {
                    $id = $row[$idColumn];
                    $started = $row["c_".Sports::COL_TEAMPLAYER_STARTED];

                    if (!empty ($playerNextTeams[$id]))
                        {
                        // if several teams were selected, we need only the first one
                        if ($started > $playerNextTeams[$id][Sports::COL_TEAMPLAYER_STARTED])
                            continue;
                        }

                    $playerNextTeams[$id] = array (Sports::COL_TEAMPLAYER_TEAM => $row[$teamIdColumn], Sports::COL_TEAMPLAYER_STARTED => $started);
                    $teamIds[] = $row[$teamIdColumn];
                    }

                $teamLabels = SportsHelper::getTeamLabels ($teamsTable, $teamIds);
                foreach ($playerNextTeams as $id => $row)
                    {
                    $teamId = $row[Sports::COL_TEAMPLAYER_TEAM];
                    if (empty ($teamLabels[$teamId]))
                        continue;
                    if (empty ($additional[$id]))
                        $additional[$id] = array ();
                    $additional[$id][] = $left ? $context->getText ("to [_0]|transfer", $teamLabels[$teamId]) : $context->getText ("from [_0]|transfer", $teamLabels[$teamId]);
                    }

                }

            $national = NULL;
            if (PRIMARY_COUNTRY > 0 && !$left)
                $national = $this->getNationalTeamStats ($context, PRIMARY_COUNTRY, $ids, $startDate);

            if (!empty ($national))
                {
                foreach ($national as $id => $list)
                    {
                    if (empty ($additional[$id]))
                        $additional[$id] = array ();
                    $additional[$id] = array_merge ($additional[$id], $list);
                    }
                }
            }

        $result = $this->processList ($context, $personstable, $idColumn, $positionColumn, $players, $labels, $additional);
        return $result;
        }

    protected function processPlayersJoined ($context, $personstable, $idColumn, $positionColumn, $players, $labels, $ids)
        {
        $result = $this->processList ($context, $personstable, $idColumn, $positionColumn, $players, $labels);
        return $result;
        }

    protected function processList ($context, $personstable, $idColumn, $positionColumn, $players, $labels, $additional = NULL)
        {
        if (empty ($players))
            return array ();

        $list = array ();
        foreach ($players as $row)
            {
            $id = $row[$idColumn];
            if (empty ($labels[$id]))
                {
                continue;
                }

            $additionalInfo = empty ($additional[$id]) ? NULL : implode (", ", $additional[$id]);
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $personstable,
                                                                         $personstable->getId (),
                                                                         $id);
            $list[] = array ("label" => $labels[$id], "url" => $url, "position" => $row[$positionColumn.".".ContentTable::COL_DISPLAY_NAME],
                             "additional" => $additionalInfo);
            }

        $byPosition = array ();
        $lng = Language::getInstance ($context);
        foreach ($list as $row)
            {
            $pos = $row["position"];
            if (empty ($pos))
                $pos = $context->getText ("Player");

            if (empty ($byPosition[$pos]))
                $byPosition[$pos] = array ();
            $byPosition[$pos][] = $row;
            }

        $list = array ();
        foreach ($byPosition as $key => $rows)
            {
            if (count ($rows) > 1)
                $key = $lng->makePlural ($key);

            $list[empty ($key) ? " " : $key] = $rows;
            }

        return $list;
        }

    protected function getNationalTeamStats ($context, $country, $ids, $startDate)
        {
        $teams = $GLOBALS["NATIONAL_TEAMS"];
        if (empty ($ids) || empty ($teams))
            return NULL;

        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $matchPlayersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHPLAYER);
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        $matchGoalsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHGOAL);
        if (empty ($matchesTable) || empty ($matchPlayersTable) || empty ($matchGoalsTable))
            return false;

        $leagueIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $playerIdColumn = ContentTable::generateForeignKeyColumn ("player", $personsTable->getIdColumn ());
        $teamIdColumn = "team.id";

        $joinCriteria = array (new FilterByTeamCriterion ($teams, "c_hometeam", false));
        $columns = array ($playerIdColumn);
        $criteria = array (new EqCriterion ("c_unused", 0));
        $groupedGames = PlayerStatistics::selectPlayerMatches ($personsTable, $matchesTable, $matchPlayersTable,
                                                    $leagueIdColumn, $teamIdColumn,
                                                    "c_hometeam", $criteria, $ids, "player", $columns, $joinCriteria, false);
        $joinCriteria = array (new FilterByTeamCriterion ($teams, "c_ishome", false));
        $criteria = array (new EqCriterion ("c_own", 0));
        $groupedGoals = PlayerStatistics::selectPlayerMatches ($personsTable, $matchesTable, $matchGoalsTable,
                                                    $leagueIdColumn, $teamIdColumn,
                                                    "c_ishome", $criteria, $ids, "player", $columns, $joinCriteria, false);

        $list = array ();
        if (!empty ($groupedGames))
            {
            $goals = array ();
            if (!empty ($groupedGoals))
                {
                foreach ($groupedGoals as $row)
                    {
                    $player = $row[$playerIdColumn];
                    $team = $row[$teamIdColumn];
                    $count = $row["cnt"];
                    if (empty ($goals[$player]))
                        $goals[$player] = array ();
                    $goals[$player][$team] = $count;
                    }
                }

            foreach ($groupedGames as $row)
                {
                $player = $row[$playerIdColumn];
                $team = $row[$teamIdColumn];
                $count = $row["cnt"];
                $from = $row["mintime"];
                $to = $row["maxtime"];
                $teamCategory = array_search ($team, $teams);
                $diff = 0;
                $goalsScored = 0;

                if (!empty ($goals[$player]) && !empty ($goals[$player][$team]))
                    $goalsScored = $goals[$player][$team];

                if (!empty ($to))
                    {
                    $t = strtotime ($to);
                    $diff = (time () - $t) / (60 * 60 * 24 * 365.25);
                    $modifier = $count > 10 ? 4 : ($count < 3 ? 1 : 2);
                    if ($teamCategory > 0)
                        {
                        if ($teamCategory >= 21)
                            $modifier *= 2;
                        if ($diff > $modifier) // do not care about very old U-17 and U-19 results
                            continue;
                        }
                    }

                if (empty ($list[$player]))
                    $list[$player] = array ();

                $goalsText = NULL;
                if ($goalsScored > 0)
                    $goalsText = $context->ngettext ("[_0] goal|in X games", "[_0] goals|in X games", $goalsScored);
                
                $label = NULL;
                if (0 == $teamCategory && $diff > 2)
                    {
                    $toYear = substr ($to, 0, 4);
                    $fromYear = substr ($from, 0, 4);
                    if ($toYear == $fromYear)
                        {
                        if ($goalsScored > 0)
                            $label = $context->ngettext ("in [_1] scored [_2] in [_0] game for national team", "in [_1] scored [_2] in [_0] games for national team",
                                                 $count, $fromYear, $goalsText);
                        else
                            $label = $context->ngettext ("in [_1] played [_0] game for national team", "in [_1] played [_0] games for national team",
                                                 $count, $fromYear);
                        }
                    else if ($goalsScored > 0)
                        $label = $context->ngettext ("in [_1]-[_2] scored [_3] in [_0] game for national team", "in [_1]-[_2] scored [_3] in [_0] games for national team",
                                                 $count, $fromYear, $toYear, $goalsText);
                    else
                        $label = $context->ngettext ("in [_1]-[_2] played [_0] game for national team", "in [_1]-[_2] played [_0] games for national team",
                                                 $count, $fromYear, $toYear);
                    }
                else if (0 == $teamCategory)
                    {
                    if ($goalsScored > 0)
                        $label = $context->ngettext ("[_1] in [_0] game for national team", "[_1] in [_0] games for national team", $count, $goalsText);
                    else
                        $label = $context->ngettext ("[_0] game for national team", "[_0] games for national team", $count);
                    }
                else if ($goalsScored > 0)
                    $label = $context->ngettext ("[_2] in [_0] game for U-[_1] team", "[_2] in [_0] games for U-[_1] team", $count, $teamCategory, $goalsText);
                else
                    $label = $context->ngettext ("[_0] game for U-[_1] team", "[_0] games for U-[_1] team", $count, $teamCategory);

                $list[$player][] = $label;
                }
            }

        return $list;
        }

    protected function getPersonelChanged ($context, $idColumn, $startDate, $endDate, $left)
        {
        return $this->getRelatedChanges ($context, $this->teamId, NULL, Sports::TABLE_TEAMSTAFF,
                                         $idColumn, Sports::COL_TEAMSTAFF_STARTED, Sports::COL_TEAMSTAFF_ENDED,
                                         Sports::COL_TEAMSTAFF_TEAM."_id", Sports::COL_TEAMSTAFF_ROLE,
                                         $startDate, $endDate, $left);
        }

    protected function getPlayersChanged ($context, $idColumn, $startDate, $endDate, $left)
        {
        $teamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAMPLAYER_TEAM, Sports::TABLE_TEAM."_id");
        return $this->getRelatedChanges ($context, $this->teamId, NULL, Sports::TABLE_TEAMPLAYER,
                                         $idColumn, Sports::COL_TEAMPLAYER_STARTED, Sports::COL_TEAMPLAYER_ENDED,
                                         $teamIdColumn, Sports::COL_TEAMPLAYER_POSITION,
                                         $startDate, $endDate, $left);
        }

    protected function getRelatedChanges ($context, $teamId, $playerIds, $table, $idColumn, $startColumn, $endColumn, $teamColumn, $positionColumn, $startDate, $endDate, $left)
        {
        $playerstable = ContentTable::createInstanceByName ($context, $table);
        $month = substr ($endDate, 5, 2);
        $checkForYear = 0 == $month || $month >= 10;
        $aproximateEndDate = date ("Y-m-d 00:00:00", strtotime ("-14 month", strtotime ($endDate)));
        $aproximateStartDate = date ("Y-m-d 00:00:00", strtotime ("+1 month", strtotime ($startDate)));
        $year = substr ($endDate, 0, 4);
        $checkColumn = NULL;

        if (empty ($teamId))
            {
            if ($left)
                {
                // select next teams for the given players
                $checkColumn = $startColumn;
                $criteria[] = new GtCriterion ("c_".$startColumn, $aproximateEndDate);
                $criteria[] = new LtCriterion ("c_".$startColumn, $aproximateStartDate);
                $checkForYear = false;
                }
            else
                {
                $checkColumn = $endColumn;
                $year--;
                $criteria[] = new GtCriterion ("c_".$endColumn, $aproximateEndDate);
                $criteria[] = new LtCriterion ("c_".$endColumn, $aproximateStartDate);
                }
            }
        else if ($left)
            {
            $criteria[] = new GtCriterion ("c_".$endColumn, $aproximateEndDate);
            $criteria[] = new LtCriterion ("c_".$endColumn, $startDate);
            $checkColumn = $endColumn;
            if ($checkForYear)
                $criteria[] = new NotEqCriterion ("c_".$endColumn, "$year-00-00 00:00:00");
            $year--;
            }
        else
            {
            $criteria[] = new GtCriterion ("c_".$startColumn, $aproximateEndDate);
            $criteria[] = new LtCriterion ("c_".$startColumn, $aproximateStartDate);
            $checkColumn = $startColumn;
            $checkForYear = false;
            }

        if ($checkForYear)
            {
            $criteria = array (new LogicalOperatorOr (new LogicalOperatorAnd ($criteria), new EqCriterion ("c_".$checkColumn, "$year-00-00 00:00:00")));
            }

        if (!empty ($teamId))
            $criteria[] = new EqCriterion ($teamColumn, $this->teamId);
        if (!empty ($playerIds))
            $criteria[] = new InCriterion ($idColumn, $playerIds);

        $columns = array ($idColumn, $teamColumn, $positionColumn, $startColumn, $endColumn);
        $rows = $playerstable->selectBy ($columns, $criteria);
        return $rows;
        }

    }

class TeamNameChanges extends StatisticsSection
    {
    private $leagueId;
    private $teamId;

    public function __construct ($parent, $id, $title, $leagueId, $teamId)
        {
        parent::__construct ($parent, $id, $title, NULL, NULL);
        $this->leagueId = $leagueId;
        $this->teamId = $teamId;
        }

    public function getTemplateName ()
        {
        return "sports/teamnamechanges";
        }

    public function isVisible ()
        {
        $this->ensureData ($this->parent->getContext ());
        return count ($this->rows) > 1;
        }

    public function getData ()
        {
        return $this->ensureData ($this->parent->getContext ());
        }

    protected function ensureData ($context)
        {
        $cache = Cache::getInstance (Sports::TABLE_TEAM, 6*60*60);
        $cacheId = "teamnames.$this->leagueId.$this->teamId.".$context->getLanguage ();

        if (false === ($this->rows = $cache->get ($cacheId)))
            {
            $this->rows = array ();
            $lng = Language::getInstance ($context);

            $rows = SportsHelper::getPredecessorTeamList ($context, $this->teamId);
            if (!empty ($rows))
                {
                foreach ($rows as $row)
                    {
                    $teamIds[] = $row[Sports::TABLE_TEAM."_id"];
                    }

                $competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
                $seasons = $this->getCompetitionSeasonIds ($context, $competitionsTable, $this->leagueId);

                if (!empty ($seasons))
                    {
                    $criteria = array (new InCriterion ("f_season_competitionstage_id", $seasons));
                    $criteria[] = new InCriterion ("team_id", $teamIds);
                    $stats = CompetitionStatistics::retrieveTeamsWithFixedStatsByCriteria ($context, Sports::TABLE_TEAMLEAGUESEASON,
                                                                         $criteria, array ("season"), NULL, false);
                    if (!empty ($stats))
                        {
                        $importantIds = array ();
                        foreach ($stats as $srow)
                            {
                            $id = $srow[Sports::TABLE_TEAM."_id"];
                            if (false === array_search ($id, $importantIds))
                                $importantIds[] = $id;
                            }
                        foreach ($rows as $row)
                            {
                            if (false === array_search ($row[Sports::TABLE_TEAM."_id"], $importantIds))
                                continue;
                            $this->rows[] = $lng->beautifyTeamLabel ($row["c_".Sports::COL_TEAM_SHORTNAME]);
                            }

                        $this->rows = array_unique ($this->rows);
                        }
                    }
                }

            $cache->save ($this->rows, $cacheId);
            }

        return $this->rows;
        }

    protected function getCompetitionSeasonIds ($context, $competitionsTable, $competitionId)
        {
        $parentColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_LEAGUE, Sports::TABLE_LEAGUE."_id");
        $criteria[] = new EqCriterion ($competitionsTable->getIdColumn (), $competitionId);
        $leagueRows = $competitionsTable->selectBy (array ($parentColumn, Sports::COL_COMPETITION_STARTS), $criteria);
        if (empty ($leagueRows))
            return NULL;

        $leagueId = $leagueRows[0][$parentColumn];
        $leagueIds = SportsHelper::colectLeaguePredecessors ($context, $leagueId);

        $criteria = array (new InCriterion ($parentColumn, $leagueIds));
        if (!empty ($leagueRows[0]["c_".Sports::COL_COMPETITION_STARTS]))
            $criteria[] = new LtCriterion ("c_".Sports::COL_COMPETITION_STARTS, $leagueRows[0]["c_".Sports::COL_COMPETITION_STARTS]);

        $rows = $competitionsTable->selectBy (array ($competitionsTable->getIdColumn ()), $criteria);
        if (empty ($rows))
            return NULL;

        $leagueSeasonIds = array ();
        foreach ($rows as $row)
            {
            $leagueSeasonIds[] = $row[$competitionsTable->getIdColumn ()];
            }

        return $leagueSeasonIds;
        }
    }

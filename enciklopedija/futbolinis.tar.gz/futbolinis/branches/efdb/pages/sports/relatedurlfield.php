<?php
require_once (PATH.'pages/sports/relatedrecordfield.php');

class RelatedUrlField extends RelatedRecordField
    {
    protected $rowIndex;
    protected $scope;

    public function __construct ($context, $prefix, $scope, $label, $tooltip, $index)
        {
        $key = self::getKey ($index);

        parent::__construct ($context, $prefix, $key, Sports::TABLE_SEASON, $label, $tooltip);

        $this->dbtable = new RelatedUrlTable ($context);
        $this->columns = self::getColumns ();
        $this->tableName = $context->getText ("Related external urls");
        $this->rowIndex = $index;
        $this->scope = $scope;
        }

    public static function getKey ($index)
        {
        return "relurl_$index";
        }

    public static function getColumns ()
        {
        return array (RelatedUrlTable::COL_PRIORITY, RelatedUrlTable::COL_URL, RelatedUrlTable::COL_ID);
        }

    /*
    protected function addCriterionForUpdate (&$criteria, $column, $value, $deleting)
        {
        if ($deleting && Sports::COL_EVENT_CAUSE == $column)
            return false; 

        if (empty ($value) && (Sports::COL_EVENT_PLAYER == $column ||
                               Sports::COL_EVENT_CAUSE == $column || Sports::COL_EVENT_ISHOME == $column ||
                               Sports::COL_EVENT_TIME_MIN == $column))
            {
            $criteria[] = new LogicalOperatorOr (new IsNullCriterion ($column), new EqCriterion ($column, 0));
            return false;
            }

        if (empty ($value) && Sports::COL_EVENT_TIME_EXTRA == $column)
            {
            $criteria[] = new IsNullCriterion ($column);
            return false;
            }

        return parent::addCriterionForUpdate ($criteria, $column, $value, $deleting);
        }
    */

    protected function isEmptyRecord ($context, $request)
        {
        return empty ($request[RelatedUrlTable::COL_URL]);
        }

    public function retrieveRecord ($context, $criteria, &$row, &$cache)
        {
        $row[$this->key] = NULL;

        if (!array_key_exists (RelatedUrlTable::TABLE_NAME, $cache))
            $cache[RelatedUrlTable::TABLE_NAME] = $this->retrieveRecords ($context, $criteria);

        $rows = $cache[RelatedUrlTable::TABLE_NAME];
        if (empty ($rows))
            return;

        $i = 0;
        foreach ($rows as $singleRow)
            {
            if ($this->rowIndex != $i++)
                continue;

            $preparedRow = $this->prepareRow ($singleRow);
            $row[$this->key] = $preparedRow;
            return;
            }
        }

    public function prepareForStoring ($context, &$values, $initialValues, &$prepared)
        {
        $initialValue = !empty ($initialValues) ? $initialValues[$this->key] : NULL;
        $record = $values[$this->key];
        unset ($values[$this->key]);

        if (empty ($initialValue) && (empty ($record) || $this->isEmptyRecord ($context, $record)))
            return;

        $anyChanges = false;
        foreach ($this->columns as $key)
            {
            if ('' == $record[$key])
                $record[$key] = NULL;

            $equals = ($initialValue[$key] === $record[$key]);

            if (!$equals)
                {
                $anyChanges = true;
                break;
                }
            }

        if (!$anyChanges)
            return;

        $record[RelatedUrlTable::COL_LABEL] = RelatedUrlTable::getLabel ($this->dbtable->getContext (), $record[RelatedUrlTable::COL_PRIORITY], $record[RelatedUrlTable::COL_URL]);
        // set the prepared record to be stored later
        $prepared[$this->key] = $record;
        $prepared[$this->key."_initial"] = $record;
        }

    protected function removeEntry ($values, $criteria)
        {
        $criteria = NULL;
        $ticket = $values[self::KEY_TICKET];
        $parts = explode (self::TICKET_SEPARATOR, $ticket, count ($this->columns));
        for ($i = 0; $i < count ($this->columns); $i++)
            {
            if (RelatedUrlTable::COL_ID == $this->columns[$i] && $this->addCriterionForUpdate ($criteria, $this->columns[$i], $parts[$i], true))
                break;
            }
        if (empty ($criteria))
            return false;

        return $this->dbtable->removeEntry ($criteria);
        }

    protected function findColumn ($column)
        {
        switch ($column)
            {
            case RelatedUrlTable::COL_PRIORITY:
                return new IntColumn (RelatedUrlTable::COL_PRIORITY, true, "");
            case RelatedUrlTable::COL_URL:
                return new TextColumn (RelatedUrlTable::COL_URL, 1, true, "");
            }
        return null;
        }

    protected function getDBIdColumn ()
        {
        return RelatedUrlTable::COL_ID;
        }

    protected function addParentIdValues (&$namesToValues, $id)
        {
        $namesToValues[RelatedUrlTable::COL_SCOPE] = $this->scope;
        $namesToValues[RelatedUrlTable::COL_CONTEXTID] = $id[0];
        }

    public function getParentCriteria ($idColumns, $id)
        {
        return array (new EqCriterion (RelatedUrlTable::COL_SCOPE, $this->scope), new EqCriterion (RelatedUrlTable::COL_CONTEXTID, $id[0]));
        }

    protected function getValues ($values, $sourceValues)
        {
        $namesToValues = array ();
        foreach ($this->columns as $col)
            {
            if ($this->getDBIdColumn () == $col)
                continue;
            $namesToValues[$col] = $values[$col];
            }

        $namesToValues[RelatedUrlTable::COL_LABEL] = $values[RelatedUrlTable::COL_LABEL];
        return $namesToValues;
        }

    public function createFields ()
        {
        $prefix = $this->getPrefix().$this->key;
        $context = $this->dbtable->getContext ();

        $arr = array ();

        $types = RelatedUrlTable::getDefaultSelection ($context);
        $arr[] = new DropDownFieldTemplate ($prefix, RelatedUrlTable::COL_PRIORITY,
                                            $context->getText ("Type:"), $context->getText ("Type"), $types);

        $arr[] = new TextFieldTemplate ($prefix, RelatedUrlTable::COL_URL, "", $context->getText ("Url"), 256);
        $arr[] = new HiddenFieldTemplate ($prefix, $this->getDBIdColumn ());
        return $arr;
        }

    /*
    protected function getRecordLabel ($context, $ticket)
        {
        $parts = explode ("_", $ticket);
        list ($min, $extra, $player, $type, $cause, $home) = $parts;
        if (!empty ($extra))
            $min .= "+$extra";
        $modifiers = array ();
        if ($cause)
            $modifiers[] = $context->getText ("cause: [_0]", $cause);
        if ($type)
            $modifiers[] = $context->getText ("type: [_0]", $type);

        $modifiers[] = $home ? $context->getText ("home team") : $context->getText ("away team");

        return $context->getText ("[_0]' [_1] [_2]", $min, $player, implode (", ", $modifiers));
        }
    */
    }

<?php
require_once (PATH.'pages/contentpreview.php');
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'pages/sports/matchview.php');

class MatchList extends ReaderPage
    {
    public function __construct ($context, $request)
        {
        parent::__construct ($context, NULL, Constants::TABLES_USER, "match");
        $this->context->setTitle ($this->getText ("Match list"));
        $context->addStyleSheet ("sports");
        $context->addScriptfile ("sports");
        $context->addScriptfile ("competition");
        }

    public function getTemplateName ()
        {
        return "simplepage";
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function ensureChildren ($context, $request)
        {
        $this->addComponent ($request, "list", new MatchListComponent ($context, "l"));

        $title = $context->getText ("Edit match");
        $url = $context->processUrl ("index.php?service=sports/CreateMatchPopup&action=edit", true);
        $this->addComponent ($request, "scr", new StartupScript ($context, "initializeMatchList('$url', '$title');"));
        return true;
        }

    }

class MatchListComponent extends ContentPreview
    {
    public function __construct ($context, $prefix)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, "match");
        parent::__construct ($context, $prefix, "match");
        $this->setTitle ($this->getText ("Match list"));
        
        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $stageColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STAGE, Sports::TABLE_ROUND."_id");
        //$this->setOrderByCriterion ("c_".Sports::COL_MATCH_DATE, OrderBy::create ($competitionIdColumn, $stageColumn, "c_".Sports::COL_MATCH_MATCHDAY));
        }

    public function getTemplateName ()
        {
        return "sports/matchlistcomponent";
        }

    public function getPageSize ()
        {
        return 300;
        }

    protected function getFilterCriteria ()
        {
        $criteria = NULL;
        if (!empty ($_REQUEST["leagueid"]))
            {
            $leagueId = $_REQUEST["leagueid"];
            $teamId = !empty ($_REQUEST["teamid"]) ? $_REQUEST["teamid"] : NULL;

            $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
            $ids = SportsHelper::selectCompetitionHierarchyIds ($this->context, $dbtable, array ($leagueId));
            $criteria = SportsHelper::createMatchTableCriterion ($this->context, $ids, $teamId, false);
            }

        if (!empty ($_REQUEST["to"]))
            {
            $to = $_REQUEST["to"];
            if (preg_match ('/^[0-9]{4}\-[0-9]{2}\-[0-9]{2}?$/u', trim ($to), $matches))
                $to = $matches[0]." 23:59";

            $criteria[] = new LtEqCriterion ("c_".Sports::COL_MATCH_DATE, $to);
            }

        if (!empty ($_REQUEST["from"]))
            {
            $from = $_REQUEST["from"];
            if (preg_match ('/^[0-9]{4}\-[0-9]{2}\-[0-9]{2}?$/u', trim ($from), $matches))
                $from = $matches[0]." 00:00";

            $criteria[] = new GtEqCriterion ("c_".Sports::COL_MATCH_DATE, $from);
            }

        if (!empty ($_REQUEST["outcome"]))
            {
            $outcome = $_REQUEST["outcome"];
            $criteria[] = new EqCriterion ("c_outcome", $outcome);
            }

        return $criteria;
        }

    public function select ($context, $criteria = NULL)
        {
        $fields = $this->getMappedFields();
        $raw = parent::select ($context, $criteria);
        if (empty ($raw))
            return $raw;

        $rows = array ();
        foreach ($raw as $instanceRow)
            {
            $row = array ('id' => $instanceRow[$this->dbtable->getIdColumn()]);
            foreach (array ('result', 'date', 'number', 'stadium', 'hometeam', 'awayteam') as $key)
                $row[$key] = $fields[$key]->getValueForDisplay ($context, $instanceRow);
            foreach (array ('result', 'stadium', 'hometeam', 'awayteam') as $key)
                $row[$key.'_uri'] = $fields[$key]->getUri ($context, $instanceRow);
            
            $row['time'] = $this->extractTime ($instanceRow);
            $rows[] = $row;
            }

        return $rows;
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        if (!empty ($_REQUEST["byno"]))
            $this->setOrderByCriterion (OrderBy::create ("c_".Sports::COL_MATCH_NUMBER, "c_".Sports::COL_MATCH_DATE));
        else
            $this->setOrderByCriterion (OrderBy::create ("c_".Sports::COL_MATCH_DATE, "c_".Sports::COL_MATCH_NUMBER));

        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        }
        
    protected function isFieldVisible ($col, &$hiddenFields)
        {
        // if adding a field there, don't forget to add it to the self::getMappedFields
        if (Sports::COL_MATCH_OUTCOME == $col->name || Sports::COL_MATCH_MATCHDAY == $col->name ||
            Sports::COL_MATCH_STADIUM == $col->name || Sports::COL_MATCH_STAGE == $col->name ||
            Sports::COL_MATCH_SPECTATORS == $col->name || Sports::COL_MATCH_NUMBER == $col->name)
            {
            return true;
            }

        return parent::isFieldVisible ($col, $hiddenFields);
        }

    protected function createFieldFromColumn ($col, $displayNameColumn, &$displayColumnShown)
        {
        if ($col instanceof ValueColumn)
            {
            $columnDef = $col->columnDef;

            if ("attendance" == $col->name)
                return new AttendanceFieldTemplate ("i", $columnDef->name, $col->getLabel ());
            if (Sports::COL_MATCH_NUMBER == $col->name)
                return new MatchNumberFieldTemplate ("i", $columnDef->name, $col->getLabel ());
            if (Sports::COL_MATCH_MATCHDAY == $col->name)
                return NULL;
            if (Sports::COL_MATCH_RESULT == $col->name)
                {
                $idColumns = $this->getIndexColumns ();
                $field = new ViewUriFieldTemplate ($this->dbtable->getId (), $idColumns, "i", $col->columnDef->name, $col->getLabel ());
                $displayColumnShown = true;
                return $field;
                }
            }
        else
            {
            if ("hometeam" == $col->name || "awayteam" == $col->name)
                return new LabelRelationFieldTemplate ($this->context, "i", $col, $col->name.".shortname");

            if ("round" == $col->name)
                return new RoundFieldTemplate ($this->context, "i", $col);
            }

        return parent::createFieldFromColumn ($col, $displayNameColumn, $displayColumnShown);
        }

    public function getMappedFields ()
        {
        $template = $this->getTemplate ();
        $fields = array ();
        // if adding a field there, don't forget to add it to the self::isFieldVisible
        $mapFieldToKey = array ("c_".Sports::COL_MATCH_DATE => "date",
                                Sports::COL_MATCH_STADIUM => "stadium",
                                Sports::COL_MATCH_COMPETITION => "league",
                                "c_".Sports::COL_MATCH_RESULT => "result",
                                Sports::COL_MATCH_HOMETEAM => "hometeam",
                                Sports::COL_MATCH_AWAYTEAM => "awayteam",
                                "c_".Sports::COL_MATCH_NUMBER => "number"
                                );
        foreach ($template as $field)
            {
            if (array_key_exists ($field->key, $mapFieldToKey))
                {
                $targetKey = $mapFieldToKey[$field->key];
                $fields[$targetKey] = $field;
                }
            }

        return $fields;
        }

    public function extractTime ($instanceRow)
        {
        if (!empty ($instanceRow) && !empty ($instanceRow["c_".Sports::COL_MATCH_DATE]))
            {
            $lng = Language::getInstance ($this->context);
            $time = $lng->extractTimeFromDate ($instanceRow["c_".Sports::COL_MATCH_DATE]);
            }

        if (empty ($time))
            return "...";
        return $time;
        }

    public function getUpcommingGamesLabel ()
        {
        return $this->getText ("Upcomming games");
        }
    }

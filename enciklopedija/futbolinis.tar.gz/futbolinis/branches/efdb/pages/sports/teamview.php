<?php
require_once (PATH."inc/sports/common.php");
require_once (PATH."pages/contentview.php");
require_once (PATH."pages/navigationbox.php");
require_once (PATH."pages/relatedurllist.php");
require_once (PATH."pages/sports/teammatches.php");

class TeamView extends ContentView
    {
    protected $clubTeamsComponent = NULL;

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $context->addStyleSheet ("sports");
        }

    public function ensureChildren ($context, $request)
        {
        if (isset ($request["id"]))
            {
            $teamId = $request["id"];
            }

        if (empty ($teamId))
            {
            $this->displayErrorPage ("Invalid arguments passed.");
            return false;
            }

        $this->setMode (false, $teamId);

        $this->addComponent ($request, "announce", new TeamMatches ($context, $teamId));

        $this->clubTeamsComponent = new ClubTeamsComponent ($this->context, $this->dbtable, $this->getIds ());
        $this->addComponent ($request, "club", $this->clubTeamsComponent);

        $dbtable = new TeamNamesTable ($context);
        if ($dbtable->canEdit ())
            {
            $context->addScriptFile ("sports");
            $script = "attachTeamView ();";
            $this->addComponent ($context, "script", new StartupScript ($context, $script));
            }

        $this->addComponent ($request, "relatedurls", new RelatedUrlList ($this->context, $this->dbtable, $this->getIds ()));

        return parent::ensureChildren ($context, $request);
        }

    public function getNavigationBox ()
        {
        return $this->clubTeamsComponent;
        }

    public function getTemplateName ()
        {
        return "sports/teamview";
        }
    }

class ClubTeamsComponent extends NavigationBox
    {
    protected $clubId;
    protected $lng;

    public function __construct ($context, $dbtable, $currentItemId)
        {
        parent::__construct ($context, $dbtable, $currentItemId, array ("team_id"));
        $this->lng = Language::getInstance ($context);
        }

    public function selectNeighbours ($context, &$request)
        {
        $dbtable = new TeamNamesTable ($context);
        $teamId = implode ("_", $this->currentItemId);
        $criteria[] = new EqCriterion (TeamNamesTable::COL_TEAMID, $teamId);
        $params[] = OrderBy::create (TeamNamesTable::COL_DATEFROM);
        $teamRows = $dbtable->selectBy (NULL, $criteria, null, $params);
        $names = array ();
        if (!empty ($teamRows))
            {
            $teamsWithDates = array ();
            foreach ($teamRows as $row)
                {
                $id = $row[TeamNamesTable::COL_TEAMID];
                $date = $row[TeamNamesTable::COL_DATEFROM];
                $teamsWithDates[] = array ($teamId, $date);
                }

            $logos = SportsHelper::getTeamLogosByDates ($context, $teamsWithDates);
            $logos = empty ($logos) || empty ($logos[$teamId]) ? array () : $logos[$teamId];
            foreach ($teamRows as $row)
                {
                $id = $row[TeamNamesTable::COL_TEAMID];
                $date = $row[TeamNamesTable::COL_DATEFROM];

                if (!empty ($logos[$date]))
                    $row["logo"] = $logos[$date];
                $row[$this->dbtable->getIdColumn ()] = $teamId;
                $names[] = $row;
                }
            }
        
        if (!SIMPLIFIED_TEAM_LABELS)
            {
            $rows = SportsHelper::getPredecessorTeamList ($context, $teamId);
            if (!empty ($rows) && count ($rows) > 1)
                {
                $teamsWithDates = array ();
                foreach ($rows as $row)
                    {
                    $date = $row["c_from"];
                    if (!empty ($row["c_to"]) && (empty ($row["c_from"]) || 0 != strncmp ($row["c_to"], $row["c_from"], 4)))
                        {
                        // take one year from the end of the team
                        $year = substr ($row["c_to"], 0, 4) + 1;
                        $date = "$year-00-00";
                        }
                    else if (!empty ($date) && empty ($row["c_to"]))
                        $date = date ("Y-00-00");
                    
                    $teamsWithDates[$row[$this->dbtable->getIdColumn ()]] = $date;
                    }

                $logos = SportsHelper::getTeamLogosByDates ($context, $teamsWithDates);
                if (!empty ($logos))
                    {
                    foreach ($rows as &$row)
                        {
                        $id = $row[$this->dbtable->getIdColumn ()];
                        if (!empty ($logos[$id]))
                            $row["logo"] = $logos[$id];
                        }
                    }

                $names = array_merge ($names, $rows);
                }
            }

        return $names;
        }

    public function createItem ($row, $id)
        {
        if (!empty ($row[TeamNamesTable::COL_TEAMID]))
            {
            $label = SportsHelper::extractTeamLabel ($this->context, $row);
            $from = $row[TeamNamesTable::COL_DATEFROM];
            $to = $row[TeamNamesTable::COL_DATETO];
            }
        else
            {
            $label = $row["c_shortname"];
            $from = $row["c_from"];
            $to = $row["c_to"];
            }

        $years = "";
        if (!empty ($from) && !empty ($to))
            {
            $years = $this->getText ("[_0]-[_1]|team existence years",
                                     $this->lng->dateToString ($from, "year"),
                                     $this->lng->dateToString ($to, "year"));
            }
        else if (!empty ($from))
            {
            $years = $this->getText ("[_0]-|team existence years",
                                     $this->lng->dateToString ($from, "year"));
            }
        else if (!empty ($to))
            {
            $years = $this->getText ("-[_0]|team existence years",
                                     $this->lng->dateToString ($to, "year"));

            }

        $editLink = $deleteLink = NULL;
        if (!empty ($row[TeamNamesTable::COL_ID]))
            {
            $dbtable = new TeamNamesTable ($this->context);
            if ($dbtable->canEdit ())
                $editLink = $this->context->processUrl ("index.php?service=sports/EditTeamLabelPopup&action=edit&id=".$row[TeamNamesTable::COL_ID], true);
            if ($dbtable->canDelete ())
                $deleteLink = $this->context->processUrl ("index.php?service=sports/EditTeamLabelPopup&mode=delete&id=".$row[TeamNamesTable::COL_ID], true);
            }

        return array
                (
                "years" => $years,
                "logo" => empty ($row["logo"]) ? "" : '<img src="'.$row["logo"].'" class="teamboxlogo"/>',
                "editUrl" => $editLink,
                "deleteUrl" => $deleteLink,
                self::LABEL => $label,
                );
        }

    public function getCreateUrl ()
        {
        $dbtable = new TeamNamesTable ($this->context);
        if ($dbtable->canCreate ())
            {
            $teamId = implode ("_", $this->currentItemId);
            return $this->context->processUrl ("index.php?service=sports/EditTeamLabelPopup&action=new&teamid=".$teamId, true);
            }
        return NULL;
        }

    public function getTitle ()
        {
        return $this->getText ("Team old names");
        }

    public function getCssClass ()
        {
        return "clubteams";
        }

    public function isVisible ($inline = false)
        {
        return $inline && ((!empty ($this->items) &&
               (count ($this->items) > 1) || $this->context->getCurrentUser() > 0));
        }
    }

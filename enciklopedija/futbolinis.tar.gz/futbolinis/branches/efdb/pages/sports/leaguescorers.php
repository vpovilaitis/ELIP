<?php
require_once (PATH."pages/sports/leagueplayerstats.php");

class LeagueScorers extends LeaguePlayerStats
    {
    protected $scorers;
    protected $maxItems;

    const ITEMS_SHOWN_SCORERS = 15;
    const ITEMS_SHOWN_ASSISTS = 5;
    const MIN_COUNT_SCORERS = 2;
    const MIN_COUNT_ASSISTS = 3;
    
    public function __construct ($context, $dbtable, $leagueId, $scorers = true, $selectHierarchy = false, $maxItems = NULL)
        {
        $this->scorers = $scorers;
        $this->maxItems = $maxItems;
        parent::__construct ($context, Sports::TABLE_MATCHGOAL, $leagueId, $selectHierarchy);
        $context->addStyleSheet ("sports");
        }

    protected function getColumnName ()
        {
        return $this->scorers ? Sports::COL_GOAL_SCORER : Sports::COL_GOAL_ASSIST;
        }

    protected function getHomeTeamColumnName ()
        {
        return Sports::COL_GOAL_HOME;
        }

    protected function getMinEventCount ()
        {
        return $this->scorers ? self::MIN_COUNT_SCORERS : self::MIN_COUNT_ASSISTS;
        }

    protected function getMaxItemCount ()
        {
        if (!empty ($this->maxItems))
            return $this->maxItems;
        return $this->scorers ? self::ITEMS_SHOWN_SCORERS : self::ITEMS_SHOWN_ASSISTS;
        }

    protected function prepareRowCountQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        parent::prepareRowCountQuery ($resultColumns, $criteria, $joins, $params);
        $criteria[] = new LogicalOperatorOr (new NotEqCriterion ("c_".Sports::COL_GOAL_OWN, true), new IsNullCriterion ("c_".Sports::COL_GOAL_OWN));
        }

    public function getTitle ()
        {
        return $this->scorers ? $this->getText ("Best scorers") : $this->getText ("Most assists");
        }

    public function getFullListUrl ()
        {
        $leagueId = $this->leagueId[0];
        return $this->context->chooseUrl ("stats/".Sports::TABLE_COMPETITIONSTAGE."/$leagueId",
                                          "index.php?c=ContentPage&mode=stats&tn=".Sports::TABLE_COMPETITIONSTAGE."&id=$leagueId",
                                          "stats=".($this->scorers ? "goal" : "assist"));
        }
    }

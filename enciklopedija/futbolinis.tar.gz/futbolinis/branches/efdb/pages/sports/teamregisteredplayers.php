<?php
require_once (PATH."pages/contentpreview.php");

class TeamRegisteredPlayers extends ContentPreview
    {
    public function getPageSize ()
        {
        return 100;
        }

    public function select ($context, $criteria = NULL, $mode = 0)
        {
        $now = getdate ();
        $year = $now["year"];
        $criteria[] = new GtCriterion ("c_".Sports::COL_REGISTRATION_DATE, "$year-01-01 00:00:00");
        return parent::select ($context, $criteria);
        }

    }

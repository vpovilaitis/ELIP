<?php
require_once (PATH."pages/contentview.php");
require_once (PATH."pages/sports/inlinematchpreview.php");

class MatchView extends ContentView
    {
    protected $componentsAlreadyAdded = array ();
    protected $matchPreview = NULL;

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $context->addStyleSheet ("sports");
        }

    public function ensureChildren ($context, $request)
        {
        parent::ensureChildren ($context, $request);
        }

    public function getTemplateName ()
        {
        return "sports/matchview";
        }

    public function getTitleHidden ()
        {
        return true;
        }

    public function getSubmittedReportsLabel ()
        {
        return $this->getText ("Submitted match reports:");
        }

    public function isZoneVisible ($instance, $zone)
        {
        switch ($zone)
            {
            case "bottom":
                return !empty ($instance["c_description"]);
                break;
            }
        return true;
        }

    protected function retrieveExisting ($request, $id)
        {
        $instance = parent::retrieveExisting ($request, $id);
        if (empty ($instance))
            return $instance;

        $instance["homelogo"] = $instance["awaylogo"] = NULL;
        $homeTeamId = $instance[ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id")];
        $awayTeamId = $instance[ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id")];
        $teams = array ();
        if (!empty ($homeTeamId))
            $teams[] = $homeTeamId;
        if (!empty ($awayTeamId))
            $teams[] = $awayTeamId;
        if (!empty ($teams))
            {
            $logos = SportsHelper::getTeamLogos ($this->context, $teams, $instance["c_".Sports::COL_MATCH_DATE]);

            if (!empty ($logos[$homeTeamId]))
                $instance["homelogo"] = $logos[$homeTeamId];
            if (!empty ($logos[$awayTeamId]))
                $instance["awaylogo"] = $logos[$awayTeamId];
            }

        return $instance;
        }

    public function getFields ($zone = NULL)
        {
        $fields = parent::getFields ();
        return self::getFieldsByZone ($this, $fields, $zone);
        }

    public static function getFieldsByZone ($component, $fields, $zone = NULL)
        {
        if (empty ($zone))
            return $fields;
        switch ($zone)
            {
            case "topleft":
                $fields = $component->filterFields ($fields, array ("cstage", "round", "c_no"));
                break;
            case "top":
                $fields = $component->filterFields ($fields, array ("c_".Sports::COL_MATCH_NUMBER, "c_time"));
                break;
            case "topright":
                $fields = $component->filterFields ($fields, array ("stadium", "c_attendance", "c_".Sports::COL_MATCH_WEATHER));
                break;
            case "left":
                $fields = $component->filterFields ($fields, array ("hometeam"));
                break;
            case "right":
                $fields = $component->filterFields ($fields, array ("awayteam"));
                break;
            case "result":
                $fields = $component->filterFields ($fields, array ("c_result"));
                break;
            case "bottom":
                $fields = $component->filterFields ($fields, array ("c_description"));
                break;
            }

        return $fields;
        }

    protected function createField ($request, $prefix, $col)
        {
        if ($col instanceof ValueColumn)
            {
            $columnDef = $col->columnDef;

            if ("attendance" == $col->name)
                return new AttendanceFieldTemplate ("i", $columnDef->name, $col->getLabel ());
            if (Sports::COL_MATCH_NUMBER == $col->name)
                return new MatchNumberFieldTemplate ("i", $columnDef->name, $col->getLabel ());
            if ("no" == $col->name)
                return NULL;
            }
        else
            {
            if ("hometeam" == $col->name || "awayteam" == $col->name)
                return new LabelRelationFieldTemplate ($this->context, $prefix, $col, $col->name.".shortname");

            if ("round" == $col->name)
                return new RoundFieldTemplate ($this->context, $prefix, $col);
            }

        return parent::createField ($request, $prefix, $col);
        }

    public function canEnterResult ($instance)
        {
        if (empty ($instance) || !empty ($instance ["c_result"]) || empty ($instance["c_time"]))
            return false;

        $date = $instance["c_time"];
        // check if match started at least 100 minutes ago
        $currentTime = strftime ("%Y-%m-%d %H:%M:%S", time () - 100 * 60);

        return $date <= $currentTime;
        }

    public function gameFinished ($instance)
        {
        if (empty ($instance) || empty ($instance["c_time"]))
            return false;

        $date = $instance["c_time"];
        // check if match started at least 100 minutes ago
        $currentTime = strftime ("%Y-%m-%d %H:%M:%S", time () - 100 * 60);

        return $date <= $currentTime;
        }

    public function getResultActionList ()
        {
        $url = "index.php?c=ContentPage&action=".Constants::MODE_EDIT."&tid={$this->dbtable->getId()}&parts=".MatchEditorMode::RESULT;
        $action = new SingleRowURL ($this, Constants::MODE_EDIT, $this->getText ("Enter result"), $url);

        return array ($action);
        }

    public function getHeaderActions ()
        {
        if (!$this->dbtable->canEdit ())
            return NULL;

        if (!$this->gameFinished ($this->getInstance ()))
            {
            $url = "index.php?c=ContentPage&action=".Constants::MODE_EDIT."&tid={$this->dbtable->getId()}&parts=".MatchEditorMode::HEADER;
            $action = new SingleRowURL ($this, "edithead", $this->getText ("Alter date or stadium"), $url);
            }
        else
            {
            $matchId = $this->getIds ();
            $matchId = $matchId[0];
            $url = "index.php?c=sports/PrepareMatchDetails&matchId=$matchId";
            $action = new SimpleLinkAction ($this, "edithead", $this->getText ("Enter statistics"), $url);
            }

        return array ($action);
        }

    public function getActionList ()
        {
        $actions = parent::getActionList ();
        if (empty ($actions))
            return NULL;

        $arr = array ();
        if ($this->dbtable->canEdit () && $this->gameFinished ($this->getInstance ()))
            {
            $url = "index.php?c=ContentPage&action=".Constants::MODE_EDIT."&tid={$this->dbtable->getId()}&parts=255";
            $arr[] = new SingleRowURL ($this, Constants::MODE_EDIT, $this->getText ("Edit protocol"), $url);
            }
        if (MATCH_PREDICTOR_ENABLED)
            {
            require_once (PATH.'inc/sports/predictortable.php');
            $predictorGamesTable = new PredictorGameTable ($this->context);
            $canManage = $predictorGamesTable->canCreate ();
            if (!$canManage && defined ("MATCH_PREDICTOR_ADMINISTRATORS"))
                {
                $administrators = preg_split ("/[,; ]/", MATCH_PREDICTOR_ADMINISTRATORS);
                $canManage = false !== array_search ($this->context->getCurrentUser (), $administrators);
                }

            if ($canManage)
                {
                $matchId = $this->getIds ();
                $matchId = $matchId[0];
                $rows = $predictorGamesTable->selectBy (array (PredictorGameTable::COL_ID),
                                                        array (new EqCriterion (PredictorGameTable::COL_MATCH_ID, $matchId)));
                $url = "index.php?c=sports/ManagePrediction&skip=1";
                $arr[] = new SingleRowURL ($this, "predict",
                                           empty ($rows) ? $this->getText ("Include in predictor") : $this->getText ("Manage predictions"), $url);
                }
            }

        if (!empty ($arr))
            return array_merge ($arr, $actions);

        return $actions;
        }

    public function getComponent ($tableName)
        {
        if ("matchpreview" == $tableName && NULL == $this->matchPreview)
            {
            $this->addComponent ($request, "matchpreview", new InlineMatchPreview ($this->context, $this->getInstance ()));
            }

        $foundKey = NULL;
        foreach ($this->components as $key => $component)
            {
            $parts = explode ("_", $key, 2);
            if (count ($parts) < 2)
                continue;
            if ($tableName == $parts[1])
                {
                $foundKey = $key;
                break;
                }
            }

        if (empty ($foundKey))
            return NULL;

        $this->componentsAlreadyAdded[] = $foundKey;
        return array ($this->components[$foundKey]);
        }

    public function getComponents ()
        {
        $res = array ();
        foreach ($this->components as $key => $component)
            {
            if (false !== array_search ($key, $this->componentsAlreadyAdded))
                continue;
            $res[$key] = $component;
            }

        return $res;
        }

    public function getStartupScript ()
        {
        $matchId = $this->getIds ();
        $matchId = $matchId[0];
        $url = $this->context->processUrl ("index.php?service=sports/MatchScorePopup&match=$matchId", true);
        $title = $this->getText ("Enter the score");
        $script = "attachMatchScorePopup ('matchresult', '$url', '$title', ".($this->dbtable->canEdit () ? 'true' : 'false').");";
        return new StartupScript ($this->context, $script);
        }

    }

class AttendanceFieldTemplate extends LabelIntFieldTemplate
    {
    public function getValueForDisplay ($context, $row)
        {
        $attendance = NULL;
        $attendanceUnofficial = NULL;
        if (isset ($row[$this->key]))
            $attendance = $row[$this->key];
        if (isset ($row["c_".Sports::COL_MATCH_UNOFFICIAL_ATTENDANCE]))
            $attendanceUnofficial = $row["c_".Sports::COL_MATCH_UNOFFICIAL_ATTENDANCE];

        if (NULL === $attendance && NULL === $attendanceUnofficial)
            return NULL;

        if (!empty ($attendance) && !empty ($attendanceUnofficial))
            return $context->ngettext ("[_0] spectator (unoff. [_1])", "[_0] spectators (unoff. [_1])", $attendance, $attendanceUnofficial);
            
        if (!empty ($attendanceUnofficial))
            return $context->ngettext ("[_0] spectator (unofficial)", "[_0] spectators (unofficial)", $attendanceUnofficial);

        return $context->ngettext ("[_0] spectator", "[_0] spectators", $attendance);
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        $resultColumns[] = Sports::COL_MATCH_UNOFFICIAL_ATTENDANCE;
        }
    }

class RoundFieldTemplate extends LabelRelationFieldTemplate
    {
    public function getValueForDisplay ($context, $row, $key = NULL)
        {
        $text = parent::getValueForDisplay ($context, $row, $key);
        $day = $row["c_no"];
        if (empty ($text) && empty ($day))
            return NULL;
        if (!empty ($text) && !empty ($day))
            return $context->getText ("[_0]. Day [_1]", $text, $day);
        if (!empty ($day))
            return $context->getText ("Day [_0]", $day);

        return $text;
        }

    public function getUri ($context, $row)
        {
        return NULL;
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        $resultColumns[] = "no";
        }
    }

class MatchNumberFieldTemplate extends LabelIntFieldTemplate
    {
    public function __construct ($prefix, $key, $label)
        {
        parent::__construct ($prefix, $key, $label);
        $this->cssClass = "matchnumber";
        }

    public function getValueForDisplay ($context, $row)
        {
        if (!isset ($row[$this->key]))
            return NULL;
        $number = $row[$this->key];

        return $context->getText ("No. [_0]", $number);
        }
    }

<?php
require_once (PATH."pages/statisticsview.php");
require_once (PATH."inc/sports/constants.php");
require_once (PATH."inc/sports/statistics.php");

class PersonStats extends StatisticsView
    {
    const COL_COMPETITION = "competition";
    const COL_TEAM = "team";
    const COL_GOALS = "goals";
    const COL_OWNGOALS = "own";
    const COL_ASSISTS = "assists";
    const COL_GAMES = "games";
    const COL_YELLOW = "yellow";
    const COL_RED = "red";
    const COL_FIRSTGAME = "first";
    const COL_LASTGAME = "last";
    const COL_LASTGOAL = "lastgoal";
    const COL_UNUSED = "unused";
    const COL_SCORE = "score";
    const COL_CONCEED = "conceed";
    const COL_WIN = "win";
    const COL_DRAW = "draw";
    const COL_LOST = "lost";
    const COL_REF_A = "refa";
    const COL_REF_4 = "ref4";
    const COL_REF_I = "refi";
    const COL_REF_D = "refd";

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        }


    protected function createComponents ($context, $request)
        {
        $id = $this->getIds ();

        $arr = array ();

        $res = $this->selectCareerStatsByTeam ($id);
        if (!empty ($res))
            {
            list ($byTeam, $byLeague) = $res;
            if (!empty ($byTeam))
                $arr[] = new StatisticsSection ($this, "a1", $this->getText ("Player career"), $byTeam, $this->getCareerStatsColumnNames ());
            if (!empty ($byLeague))
                $arr[] = new StatisticsSection ($this, "a2", $this->getText ("Games by competition"), $byLeague, $this->getCareerStatsColumnNames (false));
            }

        $res = $this->selectCoachingStatsByTeam ($id);
        if (!empty ($res))
            {
            list ($byTeam, $byLeague) = $res;
            if (!empty ($byTeam))
                $arr[] = new StatisticsSection ($this, "a3", $this->getText ("Coach career"), $byTeam, $this->getCoachCareerStatsColumnNames ());
            if (!empty ($byLeague))
                $arr[] = new StatisticsSection ($this, "a4", $this->getText ("Coached games by competition"), $byLeague, $this->getCoachCareerStatsColumnNames (false));
            }

        $res = $this->selectRefereeStats ($id);
        if (!empty ($res))
            {
            $arr[] = new StatisticsSection ($this, "a10", $this->getText ("Referee statistics"), $res, $this->getRefereeStatsColumnNames ());
            }

        return $arr;
        }

    protected function getCoachCareerStatsColumnNames ($groupByClub = true)
        {
        return array
            (
            $groupByClub
                ? new StatisticsColumn (self::COL_COMPETITION, $this->getText ("Competition"), "row_label")
                : new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "row_label"),
            new StatisticsColumn (self::COL_GAMES, $this->getText ("Games"), "statsint"),
            new StatisticsColumn (self::COL_WIN, $this->getText ("W|Win"), "statsint"),
            new StatisticsColumn (self::COL_DRAW, $this->getText ("D|Draw"), "statsint"),
            new StatisticsColumn (self::COL_LOST, $this->getText ("L|Lost"), "statsint"),
            new StatisticsColumn (self::COL_SCORE, $this->getText ("+|Scored"), "statsint"),
            new StatisticsColumn (self::COL_CONCEED, $this->getText ("-|Conceded"), "statsint"),
            new StatisticsColumn (self::COL_FIRSTGAME, $this->getText ("Debuted"), "statsdate"),
            new StatisticsColumn (self::COL_LASTGAME, $this->getText ("Last game"), "statsdate"),
            );
        }

    protected function getRefereeStatsColumnNames ()
        {
        return array
            (
            new StatisticsColumn (self::COL_COMPETITION, $this->getText ("Competition"), "row_label"),
            new StatisticsColumn (self::COL_GAMES, $this->getText ("Games"), "statsint"),
            new StatisticsColumn (self::COL_REF_A, $this->getText ("Assistant"), "statsint"),
            new StatisticsColumn (self::COL_REF_4, $this->getText ("4th official"), "statsint"),
            new StatisticsColumn (self::COL_REF_I, $this->getText ("Inspector"), "statsint"),
            new StatisticsColumn (self::COL_REF_D, $this->getText ("Delegate"), "statsint"),
            new StatisticsColumn (self::COL_FIRSTGAME, $this->getText ("Debuted"), "statsdate"),
            new StatisticsColumn (self::COL_LASTGAME, $this->getText ("Last game"), "statsdate"),
            );
        }

    protected function getCareerStatsColumnNames ($groupByClub = true)
        {
        return array
            (
            $groupByClub
                ? new StatisticsColumn (self::COL_COMPETITION, $this->getText ("Competition"), "row_label")
                : new StatisticsColumn (self::COL_TEAM, $this->getText ("Team"), "row_label"),
            new StatisticsColumn (self::COL_GAMES, $this->getText ("Games"), "statsint"),
            new StatisticsColumn (self::COL_GOALS, $this->getText ("Goals"), "statsint", "goal"),
            new StatisticsColumn (self::COL_YELLOW, $this->getText ("Yellow cards"), "statsint", "yellow"),
            new StatisticsColumn (self::COL_RED, $this->getText ("Red cards"), "statsint", "red"),
            new StatisticsColumn (self::COL_ASSISTS, $this->getText ("Assists"), "statsint", "assist"),
            new StatisticsColumn (self::COL_UNUSED, $this->getText ("Games on the bench"), "statsint", "unused"),
            new StatisticsColumn (self::COL_OWNGOALS, $this->getText ("Own goals"), "statsint", "owngoal"),
            new StatisticsColumn (self::COL_FIRSTGAME, $this->getText ("Debuted"), "statsdate"),
            new StatisticsColumn (self::COL_LASTGAME, $this->getText ("Last game"), "statsdate"),
            new StatisticsColumn (self::COL_LASTGOAL, $this->getText ("Last goal"), "statsdate"),
            );
        }

    protected function groupByTeam ($leagueIdColumn, $teamIdColumn, &$teamIds, &$competitionIds, $groupedRows)
        {
        $teamMatches = array ();
        foreach ($groupedRows as $singleRow)
            {
            $id = $singleRow[$teamIdColumn];
            if (!array_key_exists ($id, $teamMatches))
                $teamMatches[$id] = array ();

            if (false === array_search ($id, $teamIds))
                $teamIds[] = $id;

            $teamMatches[$id][] = $singleRow;

            $competitionId = $singleRow[$leagueIdColumn];
            if ($competitionId > 0 && false === array_search ($competitionId, $competitionIds))
                $competitionIds[] = $competitionId;
            }

        return $teamMatches;
        }

    protected function splitEvents ($eventTypeColumn, $teamEvents)
        {
        $teamYCards = $teamRCards = $teamMiss = array ();
        foreach ($teamEvents as $eventRow)
            {
            switch ($eventRow[$eventTypeColumn])
                {
                case MatchConstants::EVENT_YELLOW:
                    $teamYCards[] = $eventRow;
                    break;
                case MatchConstants::EVENT_YELLOW_RED:
                    $teamYCards[] = $eventRow;
                    $teamRCards[] = $eventRow;
                    break;
                case MatchConstants::EVENT_RED:
                    $teamRCards[] = $eventRow;
                    break;
                case MatchConstants::EVENT_MISS:
                    $teamMiss[] = $eventRow;
                    break;
                }
            }

        return array ($teamYCards, $teamRCards, $teamMiss);
        }

    protected function getLeagueLabels ($leagueIds)
        {
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_LEAGUE);
        $rows = $dbtable->selectWithDisplayName (array ($dbtable->getIdColumn ()), array (new InCriterion ($dbtable->getIdColumn (), $leagueIds)));
        if (empty ($rows))
            return array ();
        $leagues = array ();
        foreach ($rows as $row)
            $leagues[$row[$dbtable->getIdColumn ()]] = $row[ContentTable::COL_DISPLAY_NAME];
        return $leagues;
        }

    protected function selectCareerStatsByTeam ($id)
        {
        $matchesTable = ContentTable::createInstanceByName ($this->context, "match");
        $matchPlayersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHPLAYER);
        $matchGoalsTable = ContentTable::createInstanceByName ($this->context, "matchgoal");
        $matchEventsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHEVENT);
        $teamsTable = ContentTable::createInstanceByName ($this->context, "team");
        $competitionsTable = ContentTable::createInstanceByName ($this->context, "competitionstage");
        if (empty ($matchesTable) || empty ($matchPlayersTable) ||
            empty ($matchGoalsTable) || empty ($teamsTable) ||
            empty ($matchEventsTable) || empty ($competitionsTable))
            {
            return false;
            }

        $id = $id[0];

        $leagueIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, $competitionsTable->getIdColumn ());
        $competitionGroupIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_LEAGUE, Sports::TABLE_LEAGUE."_id");
        $teamIdColumn = "team.id";
        
        // first create games query
        $criteria = array (new EqCriterion ("c_unused", 0));
        $groupedGames = PlayerStatistics::selectPlayerMatches ($this->dbtable, $matchesTable, $matchPlayersTable,
                                                    $leagueIdColumn, $teamIdColumn,
                                                    "c_hometeam", $criteria, $id);
        $criteria = array (new EqCriterion ("c_unused", 1));
        $groupedUnusedGames = PlayerStatistics::selectPlayerMatches ($this->dbtable, $matchesTable, $matchPlayersTable,
                                                    $leagueIdColumn, $teamIdColumn,
                                                    "c_hometeam", $criteria, $id);

        // next - goals
        $criteria = array (new EqCriterion ("c_own", 0));
        $groupedGoals = PlayerStatistics::selectPlayerMatches ($this->dbtable, $matchesTable, $matchGoalsTable,
                                                    $leagueIdColumn, $teamIdColumn,
                                                    "c_ishome", $criteria, $id);

        $criteria = array (new EqCriterion ("c_own", 1));
        $groupedOwnGoals = PlayerStatistics::selectPlayerMatches ($this->dbtable, $matchesTable, $matchGoalsTable,
                                                    $leagueIdColumn, $teamIdColumn,
                                                    "1-c_ishome", $criteria, $id);

        // next - assists
        $criteria = array ();
        $groupedAssists = PlayerStatistics::selectPlayerMatches ($this->dbtable, $matchesTable, $matchGoalsTable,
                                                      $leagueIdColumn, $teamIdColumn,
                                                      "c_ishome", $criteria, $id, "assist");

        // next - cards
        $eventTypeColumn = ContentTable::prepareUserColumnName (Sports::COL_EVENT_TYPE);
        $groupedEvents = PlayerStatistics::selectPlayerMatches ($this->dbtable, $matchesTable, $matchEventsTable,
                                                     $leagueIdColumn, $teamIdColumn,
                                                     "c_ishome", NULL, $id, "player", array ($eventTypeColumn));

        if (empty ($groupedGames) && empty ($groupedGoals) &&
            empty ($groupedEvents) && empty ($groupedAssists) &&
            empty ($groupedUnusedGames) && empty ($groupedOwnGoals))
            {
            return NULL;
            }

        list ($groupedYellow, $groupedRed, $groupedMiss) = $this->splitEvents ($eventTypeColumn, $groupedEvents);

        $teamIds = array ();
        $competitionIds = array ();
        $teamGames = $this->groupByTeam ($leagueIdColumn, $teamIdColumn,
                                         $teamIds, $competitionIds, $groupedGames);
        $unusedGames = $this->groupByTeam ($leagueIdColumn, $teamIdColumn,
                                         $teamIds, $competitionIds, $groupedUnusedGames);
        $teamGoals = $this->groupByTeam ($leagueIdColumn, $teamIdColumn,
                                         $teamIds, $competitionIds, $groupedGoals);
        $teamAssists = $this->groupByTeam ($leagueIdColumn, $teamIdColumn,
                                         $teamIds, $competitionIds, $groupedAssists);
        $teamYCards = $this->groupByTeam ($leagueIdColumn, $teamIdColumn,
                                          $teamIds, $competitionIds, $groupedYellow);
        $teamRCards = $this->groupByTeam ($leagueIdColumn, $teamIdColumn,
                                          $teamIds, $competitionIds, $groupedRed);
        $teamOwnGoals = $this->groupByTeam ($leagueIdColumn, $teamIdColumn,
                                         $teamIds, $competitionIds, $groupedOwnGoals);

        $lng = Language::getInstance ($this->context);
        $criteria = array (new InCriterion ($teamsTable->getIdColumn (), $teamIds));
        $teamRowsSelected = $teamsTable->selectWithDisplayName (array ("country", "shortname", $teamsTable->getIdColumn ()), $criteria);
        $teams = array ();

        $competitions = array ();
        $competitionLeagues = array ();
        $leagueLabels = array ();
        if (!empty ($competitionIds))
            {
            $criteria = array (new InCriterion ($competitionsTable->getIdColumn (), $competitionIds));
            $competitionTableColumns = array ($competitionsTable->getIdColumn (), "c_".Sports::COL_COMPETITION_UNOFFICIAL, $competitionGroupIdColumn);
            $competitionRows = $competitionsTable->selectWithDisplayName ($competitionTableColumns, $criteria);
            if (!empty ($competitionRows))
                {
                foreach ($competitionRows as $competition)
                    {
                    $id = $competition[$competitionsTable->getIdColumn ()];
                    $url = $competitionsTable->getContentLink ($id);
                    $name = "<a href=\"$url\">".$competition["c_displayname"]."</a>";
                    $competitions[$id] = $name;
                    if (!$competition["c_".Sports::COL_COMPETITION_UNOFFICIAL])
                        $competitionLeagues[$id] = $competition[$competitionGroupIdColumn];
                    }
                if (!empty ($competitionLeagues))
                    $leagueLabels = $this->getLeagueLabels (array_unique (array_values ($competitionLeagues)));
                }
            }

        $groupedByLeague = array ();

        if (!empty ($teamRowsSelected))
            {
            foreach ($teamRowsSelected as $team)
                {
                $id = $team[$teamsTable->getIdColumn ()];
                $url = $teamsTable->getContentLink ($id);
                $name = "<a href=\"$url\">".$team["c_shortname"]."</a>";
                $minDate = $minOfficialDate = NULL;
                $maxDate = $maxOfficialDate = NULL;
                $lastGoalDate = $lastOfficialGoalDate = NULL;
                $pieces = array (self::COL_GOALS => $teamGoals,
                                self::COL_GAMES => $teamGames,
                                self::COL_YELLOW => $teamYCards,
                                self::COL_RED => $teamRCards,
                                self::COL_ASSISTS => $teamAssists,
                                self::COL_UNUSED => $unusedGames,
                                self::COL_OWNGOALS => $teamOwnGoals);
                $totals = array ();
                foreach ($pieces as $key => $arr)
                    $totals[$key] = 0;
                $totalsOfficial = $totals;

                $competitionIds = array ();
                $hasFriendlies = false;
                foreach ($pieces as $group)
                    {
                    if (!isset ($group[$id]))
                        continue;

                    foreach ($group[$id] as $singleRow)
                        {
                        $competitionId = $singleRow[$leagueIdColumn];
                        if ($competitionId > 0 && false === array_search ($competitionId, $competitionIds))
                            $competitionIds[] = $competitionId;
                        else if (!$competitionId)
                            $hasFriendlies = true;
                        }
                    }

                $teamRows = array ();
                foreach ($competitions as $competitionId => $competitionName)
                    {
                    if (false === array_search ($competitionId, $competitionIds))
                        continue;

                    $newRow = array (self::COL_COMPETITION => $competitionName, self::COL_FIRSTGAME => NULL, self::COL_LASTGAME => NULL, self::COL_LASTGOAL => NULL);
                    foreach ($pieces as $key => $arr)
                        $newRow[$key] = NULL;
                    $teamRows[$competitionId] = $newRow;
                    
                    if (!array_key_exists ($competitionId, $competitionLeagues))
                        continue;
                    $leagueId = $competitionLeagues[$competitionId];
                    if (!array_key_exists ($leagueId, $groupedByLeague))
                        $groupedByLeague[$leagueId] = array ();

                    $newRow = array (self::COL_TEAM => $name, self::COL_FIRSTGAME => NULL, self::COL_LASTGAME => NULL, self::COL_LASTGOAL => NULL);
                    foreach ($pieces as $key => $arr)
                        $newRow[$key] = NULL;
                    $groupedByLeague[$leagueId][$id] = $newRow;
                    }

                if ($hasFriendlies)
                    {
                    $newRow = array (self::COL_COMPETITION => $this->getText ("Friendly games"),
                                     self::COL_FIRSTGAME => NULL, self::COL_LASTGAME => NULL, self::COL_LASTGOAL => NULL);
                    foreach ($pieces as $key => $arr)
                        $newRow[$key] = NULL;
                    $teamRows[0] = $newRow;
                    }

                foreach ($pieces as $key => $group)
                    {
                    if (!isset ($group[$id]))
                        continue;

                    foreach ($group[$id] as $singleRow)
                        {
                        $competitionId = $singleRow[$leagueIdColumn];
                        $officialCompetition = array_key_exists ($competitionId, $competitionLeagues);
                        if ($officialCompetition)
                            $totalsOfficial[$key] += $singleRow["cnt"];
                        $totals[$key] += $singleRow["cnt"];

                        if (NULL === $minDate || (self::COL_UNUSED != $key && $minDate > $singleRow["mintime"]))
                            $minDate = $singleRow["mintime"];
                        if ($officialCompetition && (NULL === $minOfficialDate || (self::COL_UNUSED != $key && $minOfficialDate > $singleRow["mintime"])))
                            $minOfficialDate = $singleRow["mintime"];
                        if (NULL === $maxDate || (self::COL_UNUSED != $key && $maxDate < $singleRow["maxtime"]))
                            $maxDate = $singleRow["maxtime"];
                        if ($officialCompetition && (NULL === $maxOfficialDate || (self::COL_UNUSED != $key && $maxOfficialDate < $singleRow["maxtime"])))
                            $maxOfficialDate = $singleRow["maxtime"];

                        if (!array_key_exists ($competitionId, $teamRows))
                            $competitionId = 0;

                        $teamRows[$competitionId][$key] += $singleRow["cnt"];
                        if (NULL === $teamRows[$competitionId][self::COL_FIRSTGAME] || (self::COL_UNUSED != $key && $teamRows[$competitionId][self::COL_FIRSTGAME] > $singleRow["mintime"]))
                            $teamRows[$competitionId][self::COL_FIRSTGAME] = $singleRow["mintime"];
                        if (NULL === $teamRows[$competitionId][self::COL_LASTGAME] || (self::COL_UNUSED != $key && $teamRows[$competitionId][self::COL_LASTGAME] < $singleRow["maxtime"]))
                            $teamRows[$competitionId][self::COL_LASTGAME] = $singleRow["maxtime"];
                        if (self::COL_GOALS == $key && (NULL === $teamRows[$competitionId][self::COL_LASTGOAL] || $teamRows[$competitionId][self::COL_LASTGOAL] < $singleRow["maxtime"]))
                            {
                            $teamRows[$competitionId][self::COL_LASTGOAL] = $singleRow["maxtime"];
                            if (NULL === $lastGoalDate || $lastGoalDate < $singleRow["maxtime"])
                                $lastGoalDate = $singleRow["maxtime"];
                            }

                        if (self::COL_GOALS == $key && $officialCompetition && (NULL === $lastOfficialGoalDate || $lastOfficialGoalDate < $singleRow["maxtime"]))
                            $lastOfficialGoalDate = $singleRow["maxtime"];

                        if (!array_key_exists ($competitionId, $competitionLeagues))
                            continue;
                        $leagueId = $competitionLeagues[$competitionId];
                        $clubInCompetitionGroup = &$groupedByLeague[$leagueId][$id];

                        $clubInCompetitionGroup[$key] += $singleRow["cnt"];
                        if (NULL === $clubInCompetitionGroup[self::COL_FIRSTGAME] || (self::COL_UNUSED != $key && $clubInCompetitionGroup[self::COL_FIRSTGAME] > $singleRow["mintime"]))
                            $clubInCompetitionGroup[self::COL_FIRSTGAME] = $singleRow["mintime"];
                        if (NULL === $clubInCompetitionGroup[self::COL_LASTGAME] || (self::COL_UNUSED != $key && $clubInCompetitionGroup[self::COL_LASTGAME] < $singleRow["maxtime"]))
                            $clubInCompetitionGroup[self::COL_LASTGAME] = $singleRow["maxtime"];
                        if (self::COL_GOALS == $key && (NULL === $clubInCompetitionGroup[self::COL_LASTGOAL] || $clubInCompetitionGroup[self::COL_LASTGOAL] < $singleRow["maxtime"]))
                            {
                            $clubInCompetitionGroup[self::COL_LASTGOAL] = $singleRow["maxtime"];
                            if (NULL === $lastGoalDate || $lastGoalDate < $singleRow["maxtime"])
                                $lastGoalDate = $singleRow["maxtime"];
                            }
                        }
                    }

                foreach ($teamRows as &$row)
                    {
                    if (NULL !== $row[self::COL_FIRSTGAME])
                        $row[self::COL_FIRSTGAME] = $lng->dateToLongString ($row[self::COL_FIRSTGAME], "day");
                    if (NULL !== $row[self::COL_LASTGAME])
                        $row[self::COL_LASTGAME] = $lng->dateToLongString ($row[self::COL_LASTGAME], "day");
                    if (NULL !== $row[self::COL_LASTGOAL])
                        $row[self::COL_LASTGOAL] = $lng->dateToLongString ($row[self::COL_LASTGOAL], "day");
                    }

                $minDateLong = $lng->dateToLongString ($minDate, "day");
                $maxDateLong = $lng->dateToLongString ($maxDate, "day");
                $lastGoalDateLong = $lng->dateToLongString ($lastGoalDate, "day");
                $lastOfficialGoalDateLong = $lng->dateToLongString ($lastOfficialGoalDate, "day");

                $officialGamesRow = array (self::COL_LABEL => $name,
                                  self::COL_COMPETITION => $this->getText ("Official games:"),
                                  self::COL_FIRSTGAME => $lng->dateToLongString ($minOfficialDate, "day"),
                                  self::COL_LASTGAME => $lng->dateToLongString ($maxOfficialDate, "day"),
                                  self::COL_LASTGOAL => $lastOfficialGoalDateLong,
                                  "mindate" => $minDate,
                                  "maxdate" => $maxDate,);
                $totalsRow = array (self::COL_LABEL => $name,
                                  self::COL_COMPETITION => $this->getText ("Total:"),
                                  self::COL_FIRSTGAME => $minDateLong,
                                  self::COL_LASTGAME => $maxDateLong,
                                  self::COL_LASTGOAL => $lastGoalDateLong,
                                  "mindate" => $minDate,
                                  "maxdate" => $maxDate);
                $showOfficialGames = false;
                foreach ($pieces as $key => $arr)
                    {
                    if ($totalsOfficial[$key] > 0)
                        $officialGamesRow[$key] = $totalsOfficial[$key];
                    else
                        $officialGamesRow[$key] = NULL;
                    if ($totals[$key] > 0)
                        $totalsRow[$key] = $totals[$key];
                    else
                        $totalsRow[$key] = NULL;

                    if ($officialGamesRow[$key] > 0 && $officialGamesRow[$key] != $totalsRow[$key])
                        $showOfficialGames = true;
                    }

                if ($showOfficialGames)
                    $teamRows[] = $officialGamesRow;
                $totalsRow[self::COL_INNER] = $teamRows;

                $teams[] = $totalsRow;
                }
            }

        uasort ($teams, array ("PersonStats", "compare"));

        return array ($teams, $this->preProcessLeagueStatistics ($lng, $leagueLabels, $groupedByLeague, array_keys ($pieces)));
        }

    protected function selectCoachMatches ($matchesTable, $leagueIdColumn, $teamIdColumn, $id)
        {
        $coachIdColumn = "coach.id";
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        $homeCoachIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMECOACH, $personsTable->getIdColumn ());
        $awayCoachIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYCOACH, $personsTable->getIdColumn ());
        $teamColumn = new ConditionalResultColumn($teamIdColumn, "$homeCoachIdColumn = $id", "f_hometeam_team_id", "f_awayteam_team_id");

        $columns = array ($teamColumn, 
                          new FunctionCount ("*", self::COL_GAMES),
                          new FunctionMin ("c_time", "mintime"),
                          new FunctionMax ("c_time", "maxtime"),
                          $leagueIdColumn
                          );
        //$columns[] = new ConditionalResultColumn($coachIdColumn, "$homeTeamColumn = 1", $homeCoachIdColumn, $awayCoachIdColumn);
        $columns[] = new ConditionalSumColumn (self::COL_SCORE, "$homeCoachIdColumn = $id", "c_".Sports::COL_MATCH_HOMERESULT, "c_".Sports::COL_MATCH_AWAYRESULT);
        $columns[] = new ConditionalSumColumn (self::COL_CONCEED, "$homeCoachIdColumn = $id", "c_".Sports::COL_MATCH_AWAYRESULT, "c_".Sports::COL_MATCH_HOMERESULT);
        $columns[] = new ConditionalSumColumn (self::COL_WIN, "(($homeCoachIdColumn = $id AND c_".Sports::COL_MATCH_AWAYRESULT." < c_".Sports::COL_MATCH_HOMERESULT.") OR ($awayCoachIdColumn = $id AND c_".Sports::COL_MATCH_AWAYRESULT." > c_".Sports::COL_MATCH_HOMERESULT."))", 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_DRAW, "c_".Sports::COL_MATCH_AWAYRESULT." = c_".Sports::COL_MATCH_HOMERESULT, 1, 0);
        $columns[] = new ConditionalSumColumn (self::COL_LOST, "(($homeCoachIdColumn = $id AND c_".Sports::COL_MATCH_AWAYRESULT." > c_".Sports::COL_MATCH_HOMERESULT.") OR ($awayCoachIdColumn = $id AND c_".Sports::COL_MATCH_AWAYRESULT." < c_".Sports::COL_MATCH_HOMERESULT."))", 1, 0);

        $criteria = array (new EqCriterion ("c_unofficial", 0),
                           new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ()));
        $criteria[] = new InCriterion (ContentTable::prepareUserColumnName (Sports::COL_MATCH_OUTCOME),
                                       array (MatchConstants::OUTCOME_FULL_TIME, MatchConstants::OUTCOME_EXTRA_TIME,
                                              MatchConstants::OUTCOME_PENALTIES, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                              MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_NOT_STARTED,
                                              MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $criteria[] = new LogicalOperatorOr (new EqCriterion ($homeCoachIdColumn, $id), new EqCriterion ($awayCoachIdColumn, $id));

        $rows = $matchesTable->selectBy ($columns, $criteria, NULL, array (new GroupBy (array ($teamIdColumn, $leagueIdColumn))));
        if (empty ($rows))
            $rows = array ();

        return $rows;
        }

    protected function selectCoachingStatsByTeam ($id)
        {
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $competitionsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        if (empty ($matchesTable) || empty ($teamsTable) || empty ($competitionsTable))
            {
            return false;
            }

        $id = $id[0];
        //return false;

        $leagueIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, $competitionsTable->getIdColumn ());
        $competitionGroupIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_LEAGUE, Sports::TABLE_LEAGUE."_id");
        $teamIdColumn = "team.id";
        
        // first create games query
        $groupedGames = $this->selectCoachMatches ($matchesTable, $leagueIdColumn, $teamIdColumn, $id);

        if (empty ($groupedGames))
            {
            return NULL;
            }

        $teamIds = array ();
        $competitionIds = array ();
        $teamGames = $this->groupByTeam ($leagueIdColumn, $teamIdColumn,
                                         $teamIds, $competitionIds, $groupedGames);

        $lng = Language::getInstance ($this->context);
        $criteria = array (new InCriterion ($teamsTable->getIdColumn (), $teamIds));
        $teamRowsSelected = $teamsTable->selectWithDisplayName (array ("country", "shortname", $teamsTable->getIdColumn ()), $criteria);
        $teams = array ();

        $competitions = array ();
        $competitionLeagues = array ();
        $leagueLabels = array ();
        if (!empty ($competitionIds))
            {
            $criteria = array (new InCriterion ($competitionsTable->getIdColumn (), $competitionIds));
            $competitionTableColumns = array ($competitionsTable->getIdColumn (), "c_".Sports::COL_COMPETITION_UNOFFICIAL, $competitionGroupIdColumn);
            $competitionRows = $competitionsTable->selectWithDisplayName ($competitionTableColumns, $criteria);
            if (!empty ($competitionRows))
                {
                foreach ($competitionRows as $competition)
                    {
                    $id = $competition[$competitionsTable->getIdColumn ()];
                    $url = $competitionsTable->getContentLink ($id);
                    $name = "<a href=\"$url\">".$competition["c_displayname"]."</a>";
                    $competitions[$id] = $name;
                    if (!$competition["c_".Sports::COL_COMPETITION_UNOFFICIAL])
                        $competitionLeagues[$id] = $competition[$competitionGroupIdColumn];
                    }
                if (!empty ($competitionLeagues))
                    $leagueLabels = $this->getLeagueLabels (array_unique (array_values ($competitionLeagues)));
                }
            }

        $groupedByLeague = array ();

        if (!empty ($teamRowsSelected))
            {
            foreach ($teamRowsSelected as $team)
                {
                $id = $team[$teamsTable->getIdColumn ()];
                $url = $teamsTable->getContentLink ($id);
                $name = "<a href=\"$url\">".$team["c_shortname"]."</a>";
                $minDate = $minOfficialDate = NULL;
                $maxDate = $maxOfficialDate = NULL;
                $lastGoalDate = NULL;
                $pieces = array (self::COL_GAMES, self::COL_WIN,
                                 self::COL_DRAW, self::COL_LOST,
                                 self::COL_SCORE, self::COL_CONCEED);
                $totals = array ();
                foreach ($pieces as $key)
                    $totals[$key] = 0;
                $totalsOfficial = $totals;

                $competitionIds = array ();
                $hasFriendlies = false;

                if (!isset ($teamGames[$id]))
                    continue;

                foreach ($teamGames[$id] as $singleRow)
                    {
                    $competitionId = $singleRow[$leagueIdColumn];
                    if ($competitionId > 0 && false === array_search ($competitionId, $competitionIds))
                        $competitionIds[] = $competitionId;
                    else if (!$competitionId)
                        $hasFriendlies = true;
                    }

                $teamRows = array ();
                foreach ($competitions as $competitionId => $competitionName)
                    {
                    if (false === array_search ($competitionId, $competitionIds))
                        continue;

                    $newRow = array (self::COL_COMPETITION => $competitionName, self::COL_FIRSTGAME => NULL, self::COL_LASTGAME => NULL);
                    foreach ($pieces as $key)
                        $newRow[$key] = NULL;
                    $teamRows[$competitionId] = $newRow;
                    
                    if (!array_key_exists ($competitionId, $competitionLeagues))
                        continue;
                    $leagueId = $competitionLeagues[$competitionId];
                    if (!array_key_exists ($leagueId, $groupedByLeague))
                        $groupedByLeague[$leagueId] = array ();

                    $newRow = array (self::COL_TEAM => $name, self::COL_FIRSTGAME => NULL, self::COL_LASTGAME => NULL);
                    foreach ($pieces as $key)
                        $newRow[$key] = NULL;
                    $groupedByLeague[$leagueId][$id] = $newRow;
                    }

                if ($hasFriendlies)
                    {
                    $newRow = array (self::COL_COMPETITION => $this->getText ("Friendly games"),
                                     self::COL_FIRSTGAME => NULL, self::COL_LASTGAME => NULL, self::COL_LASTGOAL => NULL);
                    foreach ($pieces as $key)
                        $newRow[$key] = NULL;
                    $teamRows[0] = $newRow;
                    }

                foreach ($teamGames[$id] as $singleRow)
                    {
                    $competitionId = $singleRow[$leagueIdColumn];
                    $officialCompetition = array_key_exists ($competitionId, $competitionLeagues);
                    if (!array_key_exists ($competitionId, $teamRows))
                        $competitionId = 0;

                    foreach ($pieces as $key)
                        {
                        if ($officialCompetition)
                            $totalsOfficial[$key] += $singleRow[$key];
                        $totals[$key] += $singleRow[$key];
                        $teamRows[$competitionId][$key] += $singleRow[$key];
                        }

                    if (NULL === $minDate || $minDate > $singleRow["mintime"])
                        $minDate = $singleRow["mintime"];
                    if ($officialCompetition && (NULL === $minOfficialDate || $minOfficialDate > $singleRow["mintime"]))
                        $minOfficialDate = $singleRow["mintime"];
                    if (NULL === $maxDate || $maxDate < $singleRow["maxtime"])
                        $maxDate = $singleRow["maxtime"];
                    if ($officialCompetition && (NULL === $maxOfficialDate || $maxOfficialDate < $singleRow["maxtime"]))
                        $maxOfficialDate = $singleRow["maxtime"];

                    if (NULL === $teamRows[$competitionId][self::COL_FIRSTGAME] || $teamRows[$competitionId][self::COL_FIRSTGAME] > $singleRow["mintime"])
                        $teamRows[$competitionId][self::COL_FIRSTGAME] = $singleRow["mintime"];
                    if (NULL === $teamRows[$competitionId][self::COL_LASTGAME] || $teamRows[$competitionId][self::COL_LASTGAME] < $singleRow["maxtime"])
                        $teamRows[$competitionId][self::COL_LASTGAME] = $singleRow["maxtime"];

                    if (!array_key_exists ($competitionId, $competitionLeagues))
                        continue;
                    $leagueId = $competitionLeagues[$competitionId];
                    $clubInCompetitionGroup = &$groupedByLeague[$leagueId][$id];

                    foreach ($pieces as $key)
                        {
                        $groupedByLeague[$leagueId][$id][$key] += $singleRow[$key];
                        }

                    if (NULL === $clubInCompetitionGroup[self::COL_FIRSTGAME] || $clubInCompetitionGroup[self::COL_FIRSTGAME] > $singleRow["mintime"])
                        $clubInCompetitionGroup[self::COL_FIRSTGAME] = $singleRow["mintime"];
                    if (NULL === $clubInCompetitionGroup[self::COL_LASTGAME] || $clubInCompetitionGroup[self::COL_LASTGAME] < $singleRow["maxtime"])
                        $clubInCompetitionGroup[self::COL_LASTGAME] = $singleRow["maxtime"];
                    }

                foreach ($teamRows as &$row)
                    {
                    if (NULL !== $row[self::COL_FIRSTGAME])
                        $row[self::COL_FIRSTGAME] = $lng->dateToLongString ($row[self::COL_FIRSTGAME], "day");
                    if (NULL !== $row[self::COL_LASTGAME])
                        $row[self::COL_LASTGAME] = $lng->dateToLongString ($row[self::COL_LASTGAME], "day");
                    }

                $minDateLong = $lng->dateToLongString ($minDate, "day");
                $maxDateLong = $lng->dateToLongString ($maxDate, "day");

                $officialGamesRow = array (self::COL_LABEL => $name,
                                  self::COL_COMPETITION => $this->getText ("Official games:"),
                                  self::COL_FIRSTGAME => $lng->dateToLongString ($minOfficialDate, "day"),
                                  self::COL_LASTGAME => $lng->dateToLongString ($maxOfficialDate, "day"),
                                  "mindate" => $minDate,
                                  "maxdate" => $maxDate);
                $totalsRow = array (self::COL_LABEL => $name,
                                  self::COL_COMPETITION => $this->getText ("Total:"),
                                  self::COL_FIRSTGAME => $minDateLong,
                                  self::COL_LASTGAME => $maxDateLong,
                                  "mindate" => $minDate,
                                  "maxdate" => $maxDate);
                $showOfficialGames = false;
                foreach ($pieces as $key)
                    {
                    $officialGamesRow[$key] = $totalsOfficial[$key];
                    $totalsRow[$key] = $totals[$key];

                    if ($officialGamesRow[$key] > 0 && $officialGamesRow[$key] != $totalsRow[$key])
                        $showOfficialGames = true;
                    }

                if ($showOfficialGames)
                    $teamRows[] = $officialGamesRow;
                $totalsRow[self::COL_INNER] = $teamRows;

                $teams[] = $totalsRow;
                }
            }

        uasort ($teams, array ("PersonStats", "compare"));

        return array ($teams, $this->preProcessLeagueStatistics ($lng, $leagueLabels, $groupedByLeague, $pieces, true));
        }

    protected function selectRefereeMatches ($matchesTable, $leagueIdColumn, $typeColumn, $id)
        {
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHREFEREE);
        $columns = array (new FunctionCount ("*", "cnt"),
                          new FunctionMin ("c_time", "mintime"),
                          new FunctionMax ("c_time", "maxtime"),
                          $leagueIdColumn
                          );
        $criteria = array (new EqCriterion ("c_unofficial", 0),
                           new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ()));
        $criteria[] = new InCriterion (ContentTable::prepareUserColumnName (Sports::COL_MATCH_OUTCOME),
                                       array (MatchConstants::OUTCOME_FULL_TIME, MatchConstants::OUTCOME_EXTRA_TIME,
                                              MatchConstants::OUTCOME_PENALTIES, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                              MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_NOT_STARTED,
                                              MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));

        $join = $matchesTable->createQuery ($columns, $criteria, NULL, array (new GroupBy (array ($leagueIdColumn))));

        $idColumn = ContentTable::generateForeignKeyColumn (Sports::COL_REFEREE_PERSON, $this->dbtable->getIdColumn ());
        $criteria = NULL;
        $criteria[] = new EqCriterion ($idColumn, $id);
        $params = array (new GroupBy (array ($idColumn, $typeColumn)));

        $rows = $dbtable->selectBy (array ($idColumn, $typeColumn), $criteria, array ($join), $params);
        if (empty ($rows))
            $rows = array ();

        return $rows;
        }

    protected function selectRefereeStats ($id)
        {
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $competitionsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        if (empty ($matchesTable) || empty ($competitionsTable))
            {
            return false;
            }

        $id = $id[0];

        $leagueIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, $competitionsTable->getIdColumn ());
        $competitionGroupIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_LEAGUE, Sports::TABLE_LEAGUE."_id");
        $typeColumn = ContentTable::generateForeignKeyColumn (Sports::COL_REFEREE_TYPE, Sports::TABLE_REFEREETYPE."_id");
        
        // first create games query
        $groupedRows = $this->selectRefereeMatches ($matchesTable, $leagueIdColumn, $typeColumn, $id);

        if (empty ($groupedRows))
            return NULL;

        $competitionMatches = array ();
        foreach ($groupedRows as $singleRow)
            {
            $id = $singleRow[$leagueIdColumn];
            if (empty ($id))
                continue;

            if (!array_key_exists ($id, $competitionMatches))
                {
                $competitionMatches[$id] = array ($leagueIdColumn => $id, self::COL_GAMES => 0, self::COL_REF_A => 0, self::COL_REF_4 => 0, self::COL_REF_I => 0, self::COL_REF_D => 0);
                $competitionIds[] = $id;
                }

            $merged = &$competitionMatches[$id];
            if (empty ($merged["mintime"]) || $singleRow["mintime"] < $merged["mintime"])
                $merged["mintime"] = $singleRow["mintime"];
            if (empty ($merged["maxtime"]) || $singleRow["maxtime"] > $merged["maxtime"])
                $merged["maxtime"] = $singleRow["maxtime"];

            switch ($singleRow[$typeColumn])
                {
                case MatchConstants::REFEREE_PRIMARY:
                    $merged[self::COL_GAMES] += $singleRow["cnt"];
                    break;
                case MatchConstants::REFEREE_ASSISTANT1:
                case MatchConstants::REFEREE_ASSISTANT2:
                case MatchConstants::REFEREE_ASSISTANT_UNSPECIFIED:
                    $merged[self::COL_REF_A] += $singleRow["cnt"];
                    break;
                case MatchConstants::REFEREE_RESERVE:
                    $merged[self::COL_REF_4] += $singleRow["cnt"];
                    break;
                case MatchConstants::REFEREE_INSPECTOR:
                    $merged[self::COL_REF_I] += $singleRow["cnt"];
                    break;
                case MatchConstants::REFEREE_DELEGATE:
                    $merged[self::COL_REF_D] += $singleRow["cnt"];
                    break;
                }
            }

        $lng = Language::getInstance ($this->context);

        $competitions = array ();
        $competitionLeagues = array ();
        $leagueLabels = array ();
        if (!empty ($competitionIds))
            {
            $criteria = array (new InCriterion ($competitionsTable->getIdColumn (), $competitionIds));
            $competitionTableColumns = array ($competitionsTable->getIdColumn (), "c_".Sports::COL_COMPETITION_UNOFFICIAL, $competitionGroupIdColumn);
            $competitionRows = $competitionsTable->selectWithDisplayName ($competitionTableColumns, $criteria);
            if (!empty ($competitionRows))
                {
                foreach ($competitionRows as $competition)
                    {
                    $id = $competition[$competitionsTable->getIdColumn ()];
                    $url = $competitionsTable->getContentLink ($id);
                    $name = "<a href=\"$url\">".$competition["c_displayname"]."</a>";
                    $competitions[$id] = $name;
                    if (!$competition["c_".Sports::COL_COMPETITION_UNOFFICIAL])
                        $competitionLeagues[$id] = $competition[$competitionGroupIdColumn];
                    }
                if (!empty ($competitionLeagues))
                    $leagueLabels = $this->getLeagueLabels (array_unique (array_values ($competitionLeagues)));
                }
            }

        $groupedByLeague = array ();

        foreach ($competitionMatches as $competitionId => $row)
            {

            if (!array_key_exists ($competitionId, $competitionLeagues))
                continue;
                
            $leagueId = $competitionLeagues[$competitionId];
            if (!array_key_exists ($leagueId, $groupedByLeague))
                $groupedByLeague[$leagueId] = array ();

            $newRow = $row;
            $newRow[self::COL_COMPETITION] = $competitions[$competitionId];
            $newRow[self::COL_FIRSTGAME] = $row["mintime"];
            $newRow[self::COL_LASTGAME] = $row["maxtime"];

            $groupedByLeague[$leagueId][$competitionId] = $newRow;
            }

        $pieces = array (self::COL_GOALS, self::COL_GAMES, self::COL_REF_A,
                         self::COL_REF_4, self::COL_REF_I, self::COL_REF_D);

        return $this->preProcessLeagueStatistics ($lng, $leagueLabels, $groupedByLeague, $pieces, true);
        }

    protected function preProcessLeagueStatistics ($lng, $leagueLabels, $groupedByLeague, $columnNames, $displayZeroes = false)
        {
        $result = array ();
        foreach ($groupedByLeague as $leagueId => $clubRows)
            {
            $minDate = NULL;
            $maxDate = NULL;
            $lastGoalDate = NULL;

            $groupRows = array ();
            foreach ($clubRows as $singleRow)
                {
                if (NULL === $minDate || $minDate > $singleRow[self::COL_FIRSTGAME])
                    $minDate = $singleRow[self::COL_FIRSTGAME];
                $singleRow["mindate"] = $singleRow[self::COL_FIRSTGAME];
                $singleRow[self::COL_FIRSTGAME] = $lng->dateToLongString ($singleRow[self::COL_FIRSTGAME], "day");

                if (NULL === $maxDate || $maxDate < $singleRow[self::COL_LASTGAME])
                    $maxDate = $singleRow[self::COL_LASTGAME];
                $singleRow["maxdate"] = $singleRow[self::COL_LASTGAME];
                $singleRow[self::COL_LASTGAME] = $lng->dateToLongString ($singleRow[self::COL_LASTGAME], "day");

                if (!empty ($singleRow[self::COL_LASTGOAL]))
                    {
                    if (NULL === $lastGoalDate || $lastGoalDate < $singleRow[self::COL_LASTGOAL])
                        $lastGoalDate = $singleRow[self::COL_LASTGOAL];
                    if (!empty ($singleRow[self::COL_LASTGOAL]))
                        $singleRow[self::COL_LASTGOAL] = $lng->dateToLongString ($singleRow[self::COL_LASTGOAL], "day");
                    }
                $groupRows[] = $singleRow;
                }
            uasort ($groupRows, array ("PersonStats", "compare"));

            $minDateLong = $lng->dateToLongString ($minDate, "day");
            $maxDateLong = $lng->dateToLongString ($maxDate, "day");
            $lastGoalDateLong = !empty ($lastGoalDate) ? $lng->dateToLongString ($lastGoalDate, "day") : NULL;
            $name = $leagueLabels[$leagueId];
            $totals = array (self::COL_LABEL => $name,
                              self::COL_COMPETITION => $this->getText ("Total:"),
                              self::COL_FIRSTGAME => $minDateLong,
                              self::COL_LASTGAME => $maxDateLong,
                              self::COL_LASTGOAL => $lastGoalDateLong,
                              "mindate" => $minDate,
                              "maxdate" => $maxDate, self::COL_INNER => $groupRows);

            foreach ($columnNames as $key)
                {
                $total = 0;
                foreach ($groupRows as $singleRow)
                    $total += empty ($singleRow[$key]) ? 0 : $singleRow[$key];
                $totals[$key] = $displayZeroes || $total > 0 ? $total : NULL;
                }
            $result[] = $totals;
            }

        return $result;
        }

    static function compare ($a, $b)
        {
        if ($a["mindate"] < $b["mindate"])
            return -1;
        if ($a["mindate"] > $b["mindate"])
            return 1;

        return 0;
        }
    }


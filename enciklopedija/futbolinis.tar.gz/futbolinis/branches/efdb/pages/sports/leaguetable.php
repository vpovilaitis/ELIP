<?php
require_once (PATH."pages/contentview.php");
require_once (PATH."inc/sports/common.php");
require_once (PATH."pages/sports/leaguetablecomponent.php");
require_once (PATH."pages/sports/cupresultscomponent.php");
require_once (PATH."pages/sports/leaguescorers.php");
require_once (PATH."pages/sports/leaguecards.php");
require_once (PATH."pages/sports/competitionbox.php");
require_once (PATH."pages/sports/competitionmatches.php");
require_once (PATH."pages/sports/lightweightleaguetable.php");
require_once (PATH."pages/sports/leagueabout.php");
require_once (PATH."pages/sports/leaguestatisticscomponent.php");
require_once (PATH."pages/sports/leagueprojectioncomponent.php");
require_once (PATH."pages/relatedurllist.php");

class LeagueTable extends ContentView
    {
    protected $title;
    protected $description;
    protected $navigationBox;
    protected $mode;
    protected $postponedComponents;
    protected $singleLeagueId;
    protected $detailedLeagueTable;
    protected $idHierarchy = NULL;
    protected $hierarchy = NULL;
    protected $componentAbout = NULL;

    const MODE_LEAGUE = 1;
    const MODE_CUP = 2;
    const MODE_STAGE_GROUP = 3;

    const COMPONENT_SCORERS = "best";
    const COMPONENT_ASSISTS = "assist";
    const COMPONENT_DISCIPLINE = "cards";
    const COMPONENT_MATCHES = "announce";
    const COMPONENT_ABOUT = "about";
    const COMPONENT_STATS = "stats";
    const COMPONENT_FUTURE = "future";

    public function __construct ($context, $prefix, $dbtable, $title = NULL, $description = NULL)
        {
        $this->title = $title;
        $this->description = $description;
        parent::__construct ($context, $prefix, $dbtable);
        $context->addStyleSheet ("sports");

        if ($context->getCurrentUser () > 0 && !$context->renderInline ())
            {
            $context->addScriptFile ("competition");
            $context->addScriptFile ("editor");
            }
        }

    public function ensureChildren ($context, $request)
        {
        if (isset ($request["id"]))
            {
            $leagueId = $request["id"];
            }

        if (empty ($leagueId))
            {
            $this->displayErrorPage ("Invalid arguments passed.");
            return false;
            }

        $this->setMode (false, $leagueId);
        $row = $this->retrieveCached ($request, $this->getIds ());
        $system = $row["c_system"];
        $leagueIds = $leagueId;

        $this->addSingleStage ($context, $request, $leagueId, $row, true);

        $this->addComponent ($request, self::COMPONENT_MATCHES, new CompetitionMatches ($context, $leagueId));

        $allChildrenIds = $this->selectChildStageIds ($this->getIds ());
        if (!empty ($allChildrenIds) && (NULL == $system || ($system >= LeagueConstants::SYSTEM_GROUP_MIN && $system <= LeagueConstants::SYSTEM_GROUP_MAX)))
            {
            $this->mode = self::MODE_STAGE_GROUP;
            $criteria = array (new InCriterion ($this->dbtable->getIdColumn (), $allChildrenIds));
            $parentColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_PARENT, Sports::TABLE_COMPETITIONSTAGE."_id");
            $columns = array ($this->dbtable->getIdColumn (), $parentColumn);
            if (!SIMPLIFIED_TEAM_LABELS)
                {
                $columns[] = "system";
                $columns[] = "rounds";
                $columns[] = "description";
                }
            $rows = $this->dbtable->selectWithDisplayName ($columns, $criteria);
            if (!empty ($rows))
                {
                $leagueIds = $this->addStages ($context, $request, $rows, $leagueId);
                }
            }

        if (!empty ($allChildrenIds))
            {
            $this->addComponent ($request, self::COMPONENT_SCORERS,
                                 new LeagueScorers ($this->context, $this->dbtable, $allChildrenIds, true, false, 10));
            if (false)
                {
                $this->addComponent ($request, self::COMPONENT_ASSISTS,
                                     new LeagueScorers ($this->context, $this->dbtable, $allChildrenIds, false));
                }

            $this->addComponent ($request, self::COMPONENT_DISCIPLINE,
                                 new LeagueCards ($this->context, $this->dbtable, $allChildrenIds));
            }

        $this->navigationBox = new CompetitionBox ($this->context, $this->dbtable, $this->getIds ());
        $this->addComponent ($request, "box", $this->navigationBox);
        $this->addComponent ($request, "relatedurls", new RelatedUrlList ($this->context, $this->dbtable, $this->getIds ()));

        return parent::ensureChildren ($context, $request);
        }

    protected function selectChildStageIds ($ids)
        {
        return SportsHelper::selectCompetitionHierarchyIds ($this->context, $this->dbtable, $ids);
        }

    protected function addStages ($context, $request, $rows, $leagueId)
        {
        $leagues = array();

        $parentColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_PARENT, Sports::TABLE_COMPETITIONSTAGE."_id");
        foreach ($rows as $row)
            {
            // filter only direct descendants
            if ($row[$parentColumn] != $leagueId)
                continue;

            $stageId = $row[Sports::TABLE_COMPETITIONSTAGE."_id"];
            $system = $row["c_system"];

            $this->addSingleStage ($context, $request, $stageId, $row, false);
            $leagues[] = $stageId;

            if (NULL == $system || ($system >= LeagueConstants::SYSTEM_GROUP_MIN && $system <= LeagueConstants::SYSTEM_GROUP_MAX))
                {
                $leagueIds = $this->addStages ($context, $request, $rows, $stageId);
                if (!empty ($leagueIds))
                    $leagues = array_merge ($leagues, $leagueIds);
                }
            }

        return $leagues;
        }

    protected function addSingleStage ($context, $request, $leagueId, $row, $primary)
        {
        $system = $row["c_system"];
        $displayName = $primary ? NULL : $this->dbtable->getDisplayName ($row);

        $startDate = empty ($row["c_".Sports::COL_COMPETITION_STARTS]) ? NULL : $row["c_".Sports::COL_COMPETITION_STARTS];
        $futureCompetition = false;

        if (!empty ($startDate))
            {
            if (!empty ($_REQUEST["today"]))
                $now = strtotime ($_REQUEST["today"]);
            if (empty ($now))
                $now = time ();

            $today = date ("Y-m-d", $now);
            if ($startDate > $today)
                $futureCompetition = true;
            }

        if (empty ($system) || ($system >= LeagueConstants::SYSTEM_LEAGUE_MIN && $system <= LeagueConstants::SYSTEM_LEAGUE_MAX))
            {
            $rounds = empty ($row["c_rounds"]) ? NULL : $row["c_rounds"];
            $component = new LeagueTableComponent ($context, $this->dbtable, $leagueId, $system, $rounds, !empty ($system));
            if ($primary && !empty ($system))
                {
                $this->singleLeagueId = $leagueId;
                $this->detailedLeagueTable = $component;
                $component = new LightweightLeagueTable ($context, $this->dbtable, $leagueId, $system);
                $this->mode = self::MODE_LEAGUE;
                }

            $this->addComponent ($request, "table$leagueId", $component);
            $component->setTitle ($displayName);
            }

        if (empty ($system) || ($system >= LeagueConstants::SYSTEM_CUP_MIN && $system <= LeagueConstants::SYSTEM_CUP_MAX) || LeagueConstants::SYSTEM_STAGE_GROUP_WITH_FINALS == $system)
            {
            $component = new CupResultsComponent ($context, $this->dbtable, $leagueId, $system, NULL, !empty ($system));
            $this->addComponent ($request, "cup$leagueId", $component);
            $component->setTitle ($displayName);
            if ($primary && !empty ($system))
                $this->mode = self::MODE_CUP;
            }

        if ($primary && (self::MODE_LEAGUE == $this->mode || self::MODE_CUP == $this->mode))
            {
            $this->createDescriptionComponent ($leagueId, $row);
            
            if ($futureCompetition)
                {
                if (!$this->context->renderInline ())
                    {
                    $component = new LeagueProjectionComponent ($this->context, $this->dbtable, $leagueId, $row);
                    $this->addComponent ($this->request, self::COMPONENT_FUTURE, $component);
                    }
                }
            else
                {
                $component = new LeagueStatisticsComponent ($this->context, $this->dbtable, $leagueId, $this->getStatisticsLink ($row));
                $this->addComponent ($this->request, self::COMPONENT_STATS, $component);
                }
            }
        }

    public function createDescriptionComponent ($leagueId, $row)
        {
        $this->componentAbout = new LeagueAbout ($this->context, $this->dbtable, $leagueId, $row);
        $this->addComponent ($this->request, self::COMPONENT_ABOUT, $this->componentAbout);
        }

    public function getDetailedDescription ()
        {
        if (!empty ($this->componentAbout))
            return $this->componentAbout->getDisplayedText();
        return null;
        }

    public function addComponent ($request, $name, $component)
        {
        // filter teamleagueseason component
        if ($component instanceof ContentPreview &&
            ("teamleagueseasons" == $component->getTableName () || "teamcupseason" == $component->getTableName ()))
            {
            return;
            }

        $this->postponedComponents[$name] = $component;
        }

    public function extractComponentIdHierarchy ($idHierarchy, &$components)
        {
        $extracted = array ();
        foreach ($idHierarchy as $class => $id)
            {
            if (is_array ($id))
                {
                $extracted[$class] = $this->extractComponentIdHierarchy ($id, $components);
                continue;
                }

            if (empty ($components[$id]))
                continue;

            $extracted[$class] = $components[$id];
            unset ($components[$id]);
            }
 
        return $extracted;
        }

    public function getComponentHierarchy ()
        {
        if (NULL !== $this->hierarchy)
            return $this->hierarchy;

        $components = $this->getComponents ();
        $orderedComponents = array (); // the ones moved to the top and optionally grouped into columns

        if (!empty ($this->primaryComponentId))
            {
            // move primary element to the begining
            $orderedComponents[$this->primaryComponentId] = $components[$this->primaryComponentId];
            unset ($components[$this->primaryComponentId]);
            }

        if (!empty ($this->idHierarchy))
            {
            $orderedComponents = array_merge ($orderedComponents, $this->extractComponentIdHierarchy ($this->idHierarchy, $components));
            }

        $this->hierarchy = array_merge ($orderedComponents, $components);

        return $this->hierarchy;
        }

    public function getComponents ()
        {
        // initialization is postponed as various view can be displayed and not all the components are required (for example, detailed league view could be replaced with lightweight one)
        foreach ($this->postponedComponents as $name => $component)
            parent::addComponent ($this->request, $name, $component);

        return parent::getComponents ();
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        if (SIMPLIFIED_TEAM_LABELS)
            $resultColumns[] = "iscup";
        else
            {
            $resultColumns[] = "system";
            $resultColumns[] = "rounds";
            }
        }

    public function getTemplateName ()
        {
        if (self::MODE_LEAGUE != $this->mode)
            return "sports/competitionwithbox";

        $view = empty ($this->request["view"]) ? NULL : $this->request["view"];
        $viewPostfix = "-$view";

        switch ($view)
            {
            case "table":
                if (self::MODE_LEAGUE == $this->mode && !empty ($this->detailedLeagueTable))
                    {
                    $this->postponedComponents["table$this->singleLeagueId"] = $this->detailedLeagueTable;
                    $this->primaryComponentId = "table$this->singleLeagueId";
                    }
                break;
            case "about":
                unset ($this->postponedComponents[self::COMPONENT_ABOUT]);
                break;

            default:
                // unrecognized, so just ignore
                $viewPostfix = NULL;
                break;
            }

        if (!empty ($this->singleLeagueId) && "table" != $view)
            {
            unset ($this->postponedComponents["related_".Sports::TABLE_COMPETITIONSTAGE]);
            // ligthweight league table and "About" section on the left side, statistics and announcements on the right
            $this->idHierarchy = array ("leaguetop" =>
                                    array ("leagueleftside"
                                                => array ("leaguetable" => "table$this->singleLeagueId",
                                                          "scorers" => self::COMPONENT_SCORERS),
                                           "leaguerightside"
                                                => array ("announcements" => self::COMPONENT_MATCHES,
                                                          "leagueabout" => self::COMPONENT_ABOUT,
                                                          "leagueoverview" => COMPONENT_FUTURE,
                                                          "leaguestats" => self::COMPONENT_STATS,
                                                          self::COMPONENT_DISCIPLINE,
                                                          "related_".Sports::TABLE_REFEREERATING, )
                                          )
                                        );
            }
        else if (!empty ($this->singleLeagueId))
            {
            $this->idHierarchy = array ("leaguetop" =>
                                    array ("leagueleftside"
                                                => array ("leagueabout" => self::COMPONENT_ABOUT,
                                                          "scorers" => self::COMPONENT_SCORERS,
                                                          "related_".Sports::TABLE_REFEREERATING),
                                           "leaguerightside"
                                                => array ("announcements" => self::COMPONENT_MATCHES,
                                                          "leagueoverview" => COMPONENT_FUTURE,
                                                          "leaguestats" => self::COMPONENT_STATS,
                                                          self::COMPONENT_ASSISTS, self::COMPONENT_DISCIPLINE),
                                           "scorers" => self::COMPONENT_SCORERS
                                          )
                                        );
            }

        return "sports/leagueseason$viewPostfix";
        }

    public function getNavigationBox ()
        {
        $this->getComponentHierarchy(); // just to ensure that components are initialized
        return $this->navigationBox;
        }

    public function getParticipantsCreationLinks ()
        {
        $id = $this->getIds ();
        if (empty ($id))
            return NULL;

        $row = $this->retrieveCached ($request, $id);
        $system = $row["c_system"];
        $id = implode (",", $id);
        $arr = NULL;
        $leagueSeasonsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMLEAGUESEASON);
        if ($leagueSeasonsTable->canCreate () && (empty ($system) || ($system >= LeagueConstants::SYSTEM_LEAGUE_MIN && $system <= LeagueConstants::SYSTEM_LEAGUE_MAX)))
            {
            $arr[] = array ('url' => $this->context->processUrl ("index.php?c=ContentPage&tn=".Sports::TABLE_TEAMLEAGUESEASON."&action=new&e_e0_season=$id", true),
                            'label' => $this->getText ("Add participant|league"),
                            'image' => $this->context->getResourcePath ("img", "metro-note.png"));
            }

        $cupSeasonsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMCUPSEASON);
        if ($cupSeasonsTable->canCreate () && (empty ($system) || ($system >= LeagueConstants::SYSTEM_CUP_MIN && $system <= LeagueConstants::SYSTEM_CUP_MAX) || LeagueConstants::SYSTEM_STAGE_GROUP_WITH_FINALS == $system))
            {
            $arr[] = array ('url' => $this->context->processUrl ("index.php?c=ContentPage&tn=".Sports::TABLE_TEAMCUPSEASON."&action=new&e_e0_season=$id", true),
                            'label' => $this->getText ("Add participant|cup"),
                            'image' => $this->context->getResourcePath ("img", "metro-note.png"));
            }

        if ($this->dbtable->canCreate ())
            {
            $arr[] = array ('url' => $this->context->processUrl ("index.php?c=ContentPage&tn=".Sports::TABLE_COMPETITIONSTAGE."&action=new&templ=$id", true),
                            'label' => $this->getText ("New season|by template"),
                            'image' => $this->context->getResourcePath ("img", "metro-competitionstage.png"));
            $arr[] = array ('url' => $this->context->processUrl ("index.php?c=sports/SubmitLeagueScores&season=$id", true),
                            'label' => $this->getText ("Upload teams"),
                            'image' => $this->context->getResourcePath ("img", "metro-note.png"));
            }

        return $arr;
        }

    public function getFields ()
        {
        $ret = parent::getFields ();

        // move description and teamcount fields to the top
        $countField = null;
        $descriptionField = null;
        foreach (array_keys ($ret) as $key)
            {
            $field = $ret[$key];

            if ("c_description" == $field->key)
                {
                $descriptionField = $field;
                unset ($ret[$key]);
                }
            else if ("c_teamcount" == $field->key)
                {
                $countField = $field;
                unset ($ret[$key]);
                }
            }

        if (!empty ($countField))
            array_unshift ($ret, $countField);
        if (!empty ($descriptionField))
            array_unshift ($ret, $descriptionField);
        return $ret;
        }

    }

<?php
require_once (PATH.'pages/sports/baseleaguefragment.php');
require_once (PATH.'pages/sports/leaguescorers.php');

class LeagueScorersFragment extends BaseLeagueFragment
    {
    const ITEMS_SHOWN_SCORERS = 5;

    protected function createLeagueDependentComponent ($context, $prefix, $dbtable, $leagueId)
        {
        return new LeagueScorers ($context, $dbtable, $leagueId, true, true, self::ITEMS_SHOWN_SCORERS);
        }
    }

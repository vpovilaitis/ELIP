<?php

class VaffEvent extends RawEvent
    {
    public function __construct ($eventType, $player, $min)
        {
        switch ($eventType)
            {
/*              $this->eventType = self::EVENT_RED;
                $this->eventType = self::EVENT_YELLOW_RED;
                $this->eventType = self::EVENT_OWN_GOAL;
                $this->eventType = self::EVENT_PENALTY;
                $this->eventType = self::EVENT_PENALTY_MISS;
  */
            case "ycard":
                $this->eventType = self::EVENT_YELLOW;
                break;
            case "ball":
                $this->eventType = self::EVENT_GOAL;
                break;
            default:
                $this->eventType = $eventType;
            }

        $this->player = trim ($player);
        if (NULL !== $min)
            $this->min = $min;
        }
    }

class PreprocessedMatchUrlContentVaff extends PreprocessedMatchUrlContent
    {
    protected function initialize ($content)
        {
        $content = cutTextPiece ($content, '<table border="0" cellpadding="0" cellspacing="4" width="100%">', '<td width="270" valign="top">');
        if (false === $content)
            return $this->logError ("Cannot parse given URL content");

        $header1 = cutTextPiece ($content, '<table', '</table>');
        $header2 = cutTextPiece ($content, '<TABLE', '</TABLE>');
        if (false === $header1 || false === $header2)
            return $this->logError ("Cannot parse the header");

        $r1 = cutTextPiece ($header1, '<tr>', '</tr>', true);
        $teams = cutTextPiece ($header1, '<tr>', '</tr>', true);
        $score = cutTextPiece ($header1, '<tr>', '</tr>', true);
        if (false === $r1 || false === $teams || false === $score)
            return $this->logError ("Cannot parse the header");

        $homeTeam = cutTextPiece ($teams, '>', '</td>', true);
        $f1 = cutTextPiece ($teams, '>', '</td>', true);
        $awayTeam = cutTextPiece ($teams, '>', '</td>', true);

        if (false === $homeTeam || false === $awayTeam)
            return $this->logError ("Cannot parse teams");

        $description = cutTextPiece ($header2, '<TD valign="top" align="" width="49%">', '</TD>', true);
        $parts = explode ("<br>", $description);
        if (false === $description || count ($parts) < 3)
            return $this->logError ("Cannot parse description");

        $this->date = trim ($parts[1]);
        $this->stadium = trim ($parts[2]);

        $ref = cutTextPiece ($header2, 'Rungtynių teisėjas:</span>', '<br>', true);
        if (false === $ref)
            return $this->logError ("Cannot parse referee");
        $this->referees["referee"] = $ref;

        $refs = cutTextPiece ($header2, 'Teisėjo asistentai:</span>');
        $parts = explode (",", $refs);
        if (false === $refs || count ($parts) < 2)
            return $this->logError ("Cannot parse referees");
        $this->referees["refereeA1"] = trim (strip_tags ($parts[0]));
        $this->referees["refereeA2"] = trim (strip_tags ($parts[1]));

        if (false === $this->setScore ($score))
            return false;

$this->writeLine ("<pre>
$this->date    $this->stadium
$homeTeam $score $awayTeam\n</pre>");

        $parts = explode ('<td valign="top" bgcolor="#BDD3E7" width="50%" style="padding:5px;">', $content);
        if (count ($parts) < 3)
            return $this->logError ("Cannot parse events");

        if (false === $this->parseTeamEvents ($parts[1], true) || false === $this->parseTeamEvents ($parts[2], false))
            return false;

        return true;
        }

    public function parseTeamEvents ($content, $isHomeTeam)
        {
        $parts = explode ('</table', $content);
        foreach ($parts as $part)
            {
            $strip = trim (strip_tags ($part), "/ <>\t\n\r");
            if (empty ($strip))
                continue;
            
            $lines = explode ('</tr>', $part);
            if (count ($parts) < 2)
                return $this->logError ("Cannot parse events chunk");
            
            $eventType = cutTextPiece ($lines[0], '<img src="/images/ico_', '.gif', false);
            if (false === $eventType)
                return $this->logError ("Cannot parse event type ".htmlspecialchars ($lines[0])."");

            for ($i = 1; $i < count ($lines); $i++)
                {
                $line = trim ($lines[$i]);
                if (empty ($line))
                    continue;
                $splitLine = explode ("</a>", $line);
                if (count ($splitLine) < 2)
                    return $this->logError ("Cannot parse single event {$lines[$i]}");
                $player = trim (strip_tags ($splitLine[0]));
                $count = trim (strip_tags ($splitLine[1]));
                for ($e = 0; $e < $count; $e++)
                    $this->addEvent ($isHomeTeam, $eventType, $player);
                }
            }
        }

    public function addEvent ($home, $eventType, $player)
        {
        $event = new VaffEvent ($eventType, $player, NULL);

        if ($home)
            $this->homeEvents[] = $event;
        else
            $this->awayEvents[] = $event;
        }
    }

<?php
require_once (PATH."pages/contentpreview.php");
require_once (PATH."inc/morelinkfieldtemplate.php");

class MatchFlow extends ContentPreview
    {
    protected $cachedRows = NULL;

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $context->addStyleSheet ("sports");
        }

    public function getTemplateName ()
        {
        return "sports/matchflow";
        }

    public function getPageSize ()
        {
        return -1;
        }

    public function getFields ()
        {
        return parent::getTemplate ();
        }

    protected function addMoreLink ($idColumns, $hiddenFields)
        {
        return new TinyMoreLinkFieldTemplate ($this->context, $this->dbtable->getId (),
                                          $idColumns, $hiddenFields, "i");
        }

    public function select ($context, $criteria = NULL)
        {
        if (NULL === $this->cachedRows)
            $this->cachedRows = $this->selectNoCache ($context, $criteria);
        return $this->cachedRows;
        }

    public function selectNoCache ($context, $criteria)
        {
        $rows = parent::select ($context, $criteria);
        if (empty ($rows))
            return $rows;

        $outcomeColumn = $this->dbtable->findColumn (Sports::COL_STAGE_OUTCOME);

        $extraTimePlayed = false;
        foreach ($rows as $row)
            {
            if ($row[$outcomeColumn->columnDef->name] == MatchConstants::STAGE_EXTRA_TIME)
                {
                $extraTimePlayed = true;
                break;
                }
            }

        $result = array ();
        foreach ($rows as $row)
            {
            if (!isset ($row["c_".Sports::COL_STAGE_HOME]) || !isset ($row["c_".Sports::COL_STAGE_AWAY]))
                continue;

            $outcome = $row[$outcomeColumn->columnDef->name];
            if (!$extraTimePlayed && $outcome == MatchConstants::STAGE_FULL_TIME)
                continue;

            $entry = array ();
            $id = array ($row[Sports::TABLE_MATCH."_id"], $row[Sports::TABLE_MATCHFLOW."_id"]);
            $entry["url"] = LabelContentLinkFieldTemplate::createContentViewLink ($context, $this->dbtable,
                                                                     $this->dbtable->getId (), $id);

            $entry["result"] = $context->getText ("[_0]:[_1]|results", $row["c_".Sports::COL_STAGE_HOME], $row["c_".Sports::COL_STAGE_AWAY]);
            $entry["outcome"] = NamedIntColumn::getItem ($outcomeColumn, $outcome);
            $result[] = $entry;
            }

        return $result;
        }

    public function isVisible ()
        {
        $rows = $this->select ($this->context);
        return !empty ($rows);
        }
        
    }

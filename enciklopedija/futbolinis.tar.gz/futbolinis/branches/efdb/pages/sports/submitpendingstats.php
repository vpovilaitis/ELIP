<?php
require_once (PATH.'pages/sports/submitgame.php');

class SubmitPendingStats extends SubmitGame
    {
    protected $preparedMatch;
    protected $detailsId;

    public function __construct ($context, $request)
        {
        parent::__construct ($context, $request);
        $context->addScriptFile ("sports");
        $this->canCreateMatch = false;
        $this->showSourceFields = false;
        }

    protected function updateSourceDetails ($match, $id, $fullLabel)
        {
        return true;
        }

    protected function onSuccess ($match, $id, $fullLabel)
        {
        if (!empty ($this->detailsId))
            {
            $detailsTable = new SourcesDetailTable ($this->context);
            $criteria = array (new EqCriterion (SourcesDetailTable::COL_ID, $this->detailsId));
            $values = array (SourcesDetailTable::COL_STATE => SourcesDetailTable::STATE_PROCESSED);
            if (1 !== $detailsTable->updateRecord ($criteria, $values, 1))
                {
                $this->writeLine ($this->getText ("Error updating source details for match [_0].", $fullLabel));
                return false;
                }
            }

        $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                     $this->dbtable->getId (), $id);
        $this->redirect ($url);
        return parent::onSuccess ($match, $id, $fullLabel);
        }

    public function processInput ($context, &$request)
        {
        if (empty ($request["id"]))
            {
            $this->logError ("Identifier not found");
            }
        else
            {
            $this->detailsId = $id = $request["id"];
            
            $detailsTable = new SourcesDetailTable ($context);
            $columns = array (SourcesDetailTable::COL_CUSTOM, SourcesDetailTable::COL_CONTEXTID, SourcesDetailTable::COL_STATE, DBTable::COL_SOURCE, DBTable::COL_SOURCEDATE);
            $detailsRow = $detailsTable->selectSingleBy ($columns, array (new EqCriterion (SourcesDetailTable::COL_ID, $id)));
            if (empty ($detailsRow))
                $this->addError ("Source details not found");
            else if (SourcesDetailTable::STATE_PROCESSED == $detailsRow[SourcesDetailTable::COL_STATE])
                $this->addError ("Source details already processed");
            else if (SourcesDetailTable::STATE_OUTDATED == $detailsRow[SourcesDetailTable::COL_STATE])
                $this->addError ("Source details are marked as out of date");
            else if (!empty ($request["action"]) && $request["action"] == "outdate")
                {
                if (false === $detailsTable->updateRecord (array (new EqCriterion (SourcesDetailTable::COL_ID, $id)), array (SourcesDetailTable::COL_STATE => SourcesDetailTable::STATE_OUTDATED)))
                    $this->addError ("Source details cannot be marked as out of date");
                else
                    {
                    $this->dbtable->cleanCache ();
                    return false;
                    }
                }
            else
                {
                $this->matchId = $detailsRow[SourcesDetailTable::COL_CONTEXTID];
                $this->displayCurrentMatchLine ($context, $this->matchId);
                $serialized = $detailsRow[SourcesDetailTable::COL_CUSTOM];
                $this->preparedMatch = 'a' == $serialized[0] ? unserialize ($serialized) : $this->objectToArray (json_decode ($serialized));
                $this->preparedMatch["id"] = $this->matchId;
                $this->source = $detailsRow[DBTable::COL_SOURCE];
                SportsHelper::$KnownSourceList[DBTable::COL_SOURCE] = $this->source;
                $this->sourceDate = $detailsRow[DBTable::COL_SOURCEDATE];
                $this->writeLine ($this->getText ("Retrieved from [_0].", "<a href=\"{$this->source}\">{$this->source}</a>"));
                }
            }

        return parent::processInput ($context, $request);
        }

    public static function objectToArray ($obj)
        {
        if (is_object ($obj))
            $obj = get_object_vars ($obj);

        if (!is_array ($obj))
            return $obj;

        $ret = array ();
        foreach ($obj as $key => $val)
            {
            $ret[$key] = self::objectToArray ($val);
            }

        return $ret;
        }

    public function collectInputData ($context, &$request)
        {
        if (empty ($this->preparedMatch))
            return false;

        return array ($this->preparedMatch);
        }
    public function getParserFields ()
        {
        return array ();
        }

    protected function printRecognizedMatchDetails ($match, $texts, $existing)
        {
        $ret = parent::printRecognizedMatchDetails ($match, $texts, $existing);

        $similarSaved = true;
        $anythingSaved = false;
        foreach ($existing as $type => $val)
            {
            $new = empty ($match[$type]) ? array () : $match[$type];
            if (!empty ($val))
                $anythingSaved = true;
            if (abs (count ($val) - count ($new)) > 2)
                $similarSaved = false;
            }

        if ($anythingSaved && $similarSaved)
            {
            $buttonText = $this->getText ("outdate the details");
            $confirm = $this->getText ("Are you sure you wish to mark these prepared match details as outdated?");
            $buttonUrl = $this->context->processUrl ("index.php?c=sports/SubmitPendingStats&action=outdate&id={$this->detailsId}", true);
            $redirectUrl = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                         $this->dbtable->getId (), $this->matchId);
            $this->writeLine ($this->getText ("Similar information is already saved for the match, you can [_0].", "<a href=\"javascript:outdateSourceDetails('$buttonUrl', '$redirectUrl', '$confirm')\" class=\"linkbutton\">$buttonText</a>"));
            }

        return $ret;
        }

    }

<?php
require_once (PATH."pages/contentview.php");
require_once (PATH."pages/navigationbox.php");
require_once (PATH."pages/sports/stadiummatches.php");

class StadiumView extends ContentView
    {
    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $context->addStyleSheet ("sports");
        }

    public function ensureChildren ($context, $request)
        {
        if (isset ($request["id"]))
            $stadiumId = $request["id"];

        if (empty ($stadiumId))
            {
            $this->log ("ERROR: stadium id not found");
            $this->displayErrorPage ("Invalid arguments passed.");
            return false;
            }

        $this->setMode (false, $stadiumId);

        $this->addComponent ($request, "announce", new StadiumMatches ($context, $stadiumId));
        return parent::ensureChildren ($context, $request);
        }
    }

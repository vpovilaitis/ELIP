<?php
require_once (PATH.'inc/sports/constants.php');

class HistoricalEvents extends Page
    {
    protected $childrenCreated = false;

    public function __construct ($context, $request)
        {
        parent::__construct ($context, $context->getText ("List todays events"));
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        }

    public function ensureChildren ($context, $request)
        {
        if ($this->childrenCreated)
            return true;

        if (empty ($request["month"]) || empty ($request["day"]))
            {
            $date = getdate ();
            $month = $date["mon"];
            $day = $date["mday"];
            }
        else
            {
            $month = $request["month"];
            $day = $request["day"];
            }

        $personsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_PERSON);
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);

        $personPreview = ComponentFactory::createPreview ($context, "preview", $personsTable, DefaultFactory::PREVIEW_ALL);
        $personsFilter[] = new MonthCriteria ("c_".Sports::COL_PERSON_BIRTHDATE, $month);
        $personsFilter[] = new DayCriteria ("c_".Sports::COL_PERSON_BIRTHDATE, $day);
        $personPreview->setCriteria ($personsFilter);
        $personPreview->setOrderByCriterion (OrderBy::create ("c_".Sports::COL_PERSON_BIRTHDATE, true));
        $this->addComponent ($request, "persons", $personPreview);

        $matchesPreview = ComponentFactory::createPreview ($context, "preview", $matchesTable, DefaultFactory::PREVIEW_ALL);
        $matchesFilter[] = new MonthCriteria ("c_".Sports::COL_MATCH_DATE, $month);
        $matchesFilter[] = new DayCriteria ("c_".Sports::COL_MATCH_DATE, $day);
        $matchesPreview->setCriteria ($matchesFilter);
        $matchesPreview->setOrderByCriterion (OrderBy::create ("c_".Sports::COL_MATCH_DATE, true));
        $this->addComponent ($request, "matches", $matchesPreview);
        $this->childrenCreated = true;
        return true;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function getTemplateName ()
        {
        return "simplepage";
        }

    }

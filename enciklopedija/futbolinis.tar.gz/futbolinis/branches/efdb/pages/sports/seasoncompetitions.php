<?php
require_once (PATH."pages/contentview.php");

class SeasonCompetitions extends ContentView
    {
    protected $title;
    protected $description;

    public function __construct ($context, $prefix, $dbtable, $title = NULL, $description = NULL)
        {
        $this->title = $title;
        $this->description = $description;
        parent::__construct ($context, $prefix, $dbtable);
        }

    public function getTitle ()
        {
        return $this->title;
        }

    public function ensureChildren ($context, $request)
        {
        if (isset ($request["year"]))
            {
            $year = $request["year"];
            $separatorPos = strpos ($year, "-");
 
            $yearStart = $year;
            if (false != $separatorPos)
                list ($yearStart, $yearEnd) = explode ("-", $year);
 
            $criteria = array
                            (
                            new GtEqCriterion ("c_start", $yearStart),
                            new LtCriterion ("c_start", "$yearStart-12-31")
                            );
                
            if (!empty ($yearEnd))
                {
                $criteria[] = new GtEqCriterion ("c_end", $yearEnd);
                $criteria[] = new LtCriterion ("c_end", "$yearEnd-12-31");
                }
            else
                {
                $criteria[] = new LogicalOperatorOr
                                    (
                                    new IsNullCriterion ("c_end", $year),
                                    new LtCriterion ("c_end", "$year-12-31")
                                    );
                }
 
            $resultColumns = array ("seasons_id");
            $rows = $this->dbtable->selectBy ($resultColumns, $criteria);
            if (!empty ($rows))
                $id = $rows[0]["seasons_id"];
            }
 
        if (empty ($id))
            {
            $this->log ("ERROR: id not found (SeasonCompetitions)");
            $this->displayErrorPage ("Invalid arguments passed.");
            return false;
            }
 
        $this->setMode (false, $id);
        parent::ensureChildren ($context, $request);
        }

    }

?>

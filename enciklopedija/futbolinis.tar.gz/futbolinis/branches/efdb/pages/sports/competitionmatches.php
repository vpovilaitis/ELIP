<?php
require_once (PATH.'pages/sports/matchannouncement.php');

class CompetitionMatches extends MatchAnnouncement
    {
    protected $competitionId;

    public function __construct ($context, $competitionId)
        {
        parent::__construct ($context, "announce", NULL);
        $this->competitionId = $competitionId;
        }

    protected function selectMatches ($now)
        {
        $collector = new MatchCollector ($this->context, true);
        return $collector->selectCompetitionMatches ($now, $this->competitionId, 15);
        }

    public function isVisible ($inline = false)
        {
        $parts = $this->getDisplayableParts ();
        return !empty ($parts);
        }

    public function getRssLink ($pastResults, $additionalQueryParams = NULL)
        {
        return parent::getRssLink ($pastResults, "leagueid=$this->competitionId");
        }

    }

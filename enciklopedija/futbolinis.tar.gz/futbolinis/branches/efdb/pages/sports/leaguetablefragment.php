<?php
require_once (PATH.'pages/sports/baseleaguefragment.php');
require_once (PATH.'pages/sports/lightweightleaguetable.php');

class LeagueTableFragment extends BaseLeagueFragment
    {
    protected function createLeagueDependentComponent ($context, $prefix, $dbtable, $leagueId)
        {
        $criteria = array (new EqCriterion ($dbtable->getIdColumn (), $leagueId));
        $columns = array ($dbtable->getIdColumn (), Sports::COL_COMPETITION_SYSTEM);
        $rows = $dbtable->selectBy ($columns, $criteria);
        if (empty ($rows))
            return new ErrorComponent ($prefix, $context,
                                       $context->getText ("Competition was not found"));

        return new LightweightLeagueTable ($context, $dbtable, $leagueId, $rows[0]["c_".Sports::COL_COMPETITION_SYSTEM]);
        }
    }

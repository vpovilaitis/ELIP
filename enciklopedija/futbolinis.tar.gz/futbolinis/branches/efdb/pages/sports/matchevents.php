<?php
require_once (PATH."pages/sports/matchplayers.php");

class MatchEvents extends MatchPlayersBase
    {
    protected function getIsHomeColumnName ()
        {
        return "ishome";
        }

    protected function createEventRow ($row, $time, $player, $playerUrl, $playerField = null, $captain = false)
        {
        $event = parent::createEventRow ($row, $time, $player, $playerUrl, $playerField, $captain);
        $event["time"] = $row["c_time"];
        if (empty ($event["time"]))
            $event["time"] = $this->formatText ($event["link"], "...", "transparentlink");
        else
            $event["time"] = $this->formatText ($event["link"], $event["time"], "nounderline");

        $eventColumn = $this->dbtable->findColumn ("event");
        $eventId = $row[$eventColumn->columnDef->name];
        $eventLabel = NamedIntColumn::getItem ($eventColumn, $eventId);

        switch ($eventId)
            {
            case 1:
                $img = "yellow";
                $alt = $this->getText ("(yel)|yellow card");
                break;
            case 2:
                $img = "yellow-red";
                $alt = $this->getText ("(2nd yel)|second yellow card");
                break;
            case 4:
                $img = "red";
                $alt = $this->getText ("(red)|red card");
                break;
            case 3:
                $img = "miss";
                $alt = $this->getText ("(miss)|penalty kick miss");
                if ($row["c_time"] >= 150)
                    $shootout = true;
                break;
            case 5:
                $img = "goal";
                $alt = $this->getText ("(pen)|image alt descr for scored during penalty shootout");
                $shootout = true;
                break;
            }

        if ($shootout)
            {
            $penaltyImg = $this->context->getSmallIconPath ("penalty");
            $label = $this->getText ("Penalty shootout");
            $event["time"] = "<img src='$penaltyImg' title='$label' alt='11m'>";
            $event["timeClass"] = "eventtimeimg";
            }
            
        if ($img)
            {
            $img = $this->context->getSmallIconPath ($img);
            $event["img"] = $this->formatText ($event["link"], "<img src='$img' border='0' title='$eventLabel' alt='$alt'>", "");
            }
        else
            $event["modifier"] = "$eventLabel";
        return $event;
        }

    public function getAdditionalActions ()
        {
        $ret = parent::getAdditionalActions ();
        if (NULL != $this->dbtable && ($this->dbtable->canCreate () || $this->dbtable->canEdit ()) && NULL != $this->parentId)
            {
            $idparam = "&id=".implode ("_", $this->parentId);

            $url = "index.php?c=ContentPage&action=".Constants::MODE_EDIT."&tid={$this->dbtable->getParentTable()->getId()}$idparam&parts=".MatchEditorMode::EVENTS;
            $ret[] = new AdditionalURLIcon ($this, "edit", $this->_("Edit events"), $url);
            }

        return $ret;
        }
    }

<?php
require_once (PATH.'pages/sports/submitgame.php');

class SubmitGameResult extends SubmitGame
    {
    public function __construct ($context, $request)
        {
        parent::__construct ($context, $request);
        $this->canCreateMatch = false;
        }
    }

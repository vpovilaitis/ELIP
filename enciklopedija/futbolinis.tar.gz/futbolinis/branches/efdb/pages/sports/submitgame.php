<?php
require_once (PATH.'pages/submit.php');
require_once (PATH.'pages/sports/seasonresultsbase.php');
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/relationfields.php');
require_once (PATH.'inc/language.php');

/*
please run the automated tests if changing/fixing anything:
    http://localhost/index.php?c=tools/AutomatedTests&test=SubmitGameTests
*/
class SubmitGame extends Submit
    {
    protected $refereetable;
    protected $eventtable;
    protected $matchflowtable;
    protected $goaltable;
    protected $playerstable;
    
    protected $competitionField;
    protected $roundField;
    protected $teams = array ();
    protected $persons = array ();
    protected $stadiums = array ();
    protected $rounds = array ();
    protected $cities = array ();
    protected $canCreateMatch = true;
    protected $savePrepared = false;
    protected $showSourceFields = true;
    protected $matchId = NULL;

    const OUTCOME_CANCELLED = 2;
    const OUTCOME_HALFTIME = 3;
    const OUTCOME_NORMAL = 4;

    const EVENT_YELLOW = 1;
    const EVENT_YELLOWRED = 2;
    const EVENT_PENALTYMISS = 3;
    const EVENT_RED = 4;

    const FORMAT_FULL = 1;
    const FORMAT_NATIONAL = 5;
    const FORMAT_TABLE = 6;
    const FORMAT_SCHEDULE = 7;

    const TEAMFORMAT_FIELD = "treatnames";
    const TEAMFORMAT_EXISTING = 0;
    const TEAMFORMAT_ANY = 1;
    const TEAMFORMAT_RESERVES = 2;

    const MATCH_DATE = "date";
    const MATCH_OUTCOME = "c_outcome";
    const MATCH_ROUND = "round";
    const MATCH_SPECTATORS = "spectators";
    const MATCH_STADIUM = "stadium";
    const MATCH_REFEREE = "referee";
    const MATCH_REFEREE_CITY = "refereeCity";

    public function __construct ($context, $request)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, "match");
        $this->refereetable = ContentTable::createInstanceByName ($context, "matchreferee");
        $this->eventtable = ContentTable::createInstanceByName ($context, "matchevent");
        $this->matchflowtable = ContentTable::createInstanceByName ($context, "matchflow");
        $this->goaltable = ContentTable::createInstanceByName ($context, "matchgoal");
        $this->playerstable = ContentTable::createInstanceByName ($context, "matchplayers");

        if (empty ($this->dbtable) || empty ($this->refereetable) ||
            empty ($this->eventtable) || empty ($this->matchflowtable) ||
            empty ($this->goaltable) || empty ($this->playerstable))
            {
            $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            $this->allTablesLoaded = false;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        $context->addScriptFile ("autosuggest");
        $context->addStyleSheet ("sports");
        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ($this->getText ("Submit match result(s)"));
        return true;
        }

    protected function onInputFieldCollected ($context, &$request, $type, $key, $val)
        {
        if (!empty ($val))
            {
            switch ($type)
                {
                case "hometeam":
                    $this->teams[$key] = $val;
                    break;
                case "stadium":
                    $this->stadiums[$key] = $val;
                    break;
                case Sports::COL_MATCH_STAGE:
                    $this->rounds[$key] = $val;
                    break;
                case "person":
                    $this->persons[$key] = $val;
                    break;
                }
            }
        }

    protected function processInputFieldLabel ($context, $field)
        {
        $label = $this->beautifyName ($field->label);
        if (!empty ($year) && false !== strpos ($field->key, "_hometeam_"))
            $label .= " $year";
        return $label;
        }
        
    public function collectInputData ($context, &$request)
        {
        $year = !empty ($request["year"]) ? $request["year"] : NULL;

        $this->createSourceFields ();
        $this->source = $this->sourcesField->getValueForDB ($context, $request);
        SportsHelper::$KnownSourceList[DBTable::COL_SOURCE] = $this->source;
        $this->sourceDate = $this->sourcesDateField->getValueForDB ($context, $request);

        $format = !empty ($request["format"]) ? $request["format"] : NULL;
        switch ($format)
            {
            case self::FORMAT_NATIONAL:
                $matches = $this->collectNational1940Matches ($year, $request["parse"]);
                break;
            case self::FORMAT_TABLE:
                $matches = $this->collectMatchesTableFormat ($year, $request["cstage"], $request["parse"]);
                break;
            case self::FORMAT_SCHEDULE:
                $matches = $this->collectSchedule ($year, $request["cstage"], $request["parse"]);
                break;
            
            default:
                $matches = $this->collectMatches ($year, $request["parse"], !empty ($request[self::TEAMFORMAT_FIELD]) ? $request[self::TEAMFORMAT_FIELD] : self::TEAMFORMAT_EXISTING);
                break;
            }
//print json_encode ($matches[0]);

        return $matches;
        }
        
    public function validateInput ($context, &$input)
        {
        return $this->prepareMatches ($input);
        }

    public function saveInput ($context, &$request, &$input)
        {
        $round = empty ($request["round"]) ? NULL : $request["round"];
        $season = !empty ($request["cstage"]) ? $request["cstage"] : NULL;
        return $this->storeMatches ($season, $round, $input, !empty ($request["excl"]) ? $request["excl"] : NULL);
        }

    public function storeMatches ($season, $round, $matches, $excludedKeys = NULL)
        {
        foreach ($matches as $match)
            {
            if (1 == count ($matches) && $this->matchId > 0)
                $match["id"] = $this->matchId;

            if (false === $this->saveMatch ($season, $round, $match, $excludedKeys))
                return false;
            }

        return true;
        }

    protected function displayCurrentMatchLine ($context, $id)
        {
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $columns = array ($matchesTable->getIdColumn ());
        $criteria = array (new EqCriterion ($matchesTable->getIdColumn (), $id));
        $rows = $matchesTable->selectWithDisplayName ($columns, $criteria);
        if (empty ($rows))
            {
            $this->addError ("Specified match not found");
            return false;
            }

        $row = $rows[0];
        $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $matchesTable,
                                                                     $matchesTable->getId (), $id);
        $this->writeLine ("<h3 class=\"submittedmatch\">".$this->getText ("Submitting statistics for match [_0]", "<a href=\"$url\">".$row[ContentTable::COL_DISPLAY_NAME]."</a>")."</h3>");
        return true;
        }

    public function processInput ($context, &$request)
        {
        if (!empty ($request["matchId"]))
            {
            $this->matchId = $request["matchId"];
            $this->displayCurrentMatchLine ($context, $this->matchId);
            }

        return parent::processInput ($context, $request);
        }

    protected function onSuccess ($match, $id, $fullLabel)
        {
        $this->writeLine ("OK\n");
        return true;
        }

    protected function updateSourceDetails ($match, $id, $fullLabel)
        {
        return self::updateSourceDetailsTable ($this->context, $this->dbtable, $match, $id, $fullLabel, $this->source, $this->sourceDate, $this->savePrepared, $this);
        }

    public static function updateSourceDetailsTable ($context, $dbtable, $match, $id, $fullLabel, $sources, $sourceDate, $savePrepared, $logger)
        {
        $ret = true;
        if (!empty ($match["sourceDetails"]))
            {
            $existingDetails = SourcesDetailTable::selectExistingDetails ($context, $dbtable, $id);
            $copiedMatch = $match;
            unset ($copiedMatch["sourceDetails"]);

            if (!empty ($existingDetails))
                {
                $identical = $updated = false;
                foreach ($existingDetails as $row)
                    {
                    if (SourcesDetailTable::STATE_PROCESSED == $row[SourcesDetailTable::COL_STATE])
                        {
                        $logger->writeLine ($context->getText ("Source details of match [_0] are already marked as updated.", $fullLabel));
                        continue;
                        }

                    if ($row[SourcesDetailTable::COL_DETAILS] == $match["sourceDetails"])
                        {
                        $serialized = json_encode ($copiedMatch);
                        if ($row[SourcesDetailTable::COL_CUSTOM] == $serialized)
                            $identical = true;
                        else if ($row[DBTable::COL_SOURCE] == $sources)
                            {
                            $sourcesTable = new SourcesDetailTable ($context);
                            $sourceDetailsCriteria = array (new EqCriterion (SourcesDetailTable::COL_ID, $row[SourcesDetailTable::COL_ID]));
                            $sourceDetailValues = array (SourcesDetailTable::COL_CUSTOM => $serialized);
                            if (1 === $sourcesTable->updateRecord ($sourceDetailsCriteria, $sourceDetailValues, 1))
                                $updated = true;
                            else
                                {
                                $logger->writeLine ($context->getText ("Error updating source details for match [_0].", $fullLabel));
                                $ret = false;
                                }
                            }
                        }
                    }

                if ($identical)
                    {
                    $logger->writeLine ($context->getText ("Existing source details found for match [_0].", $fullLabel).
                                      " ".
                                      ($updated ? $context->getText ("Updated...") : $context->getText ("Skipping...")));
                    }
                else if ($ret && !$updated)
                    {
                    $logger->writeLine ($context->getText ("Existing source details found for match [_0].", $fullLabel).
                                      " ".$context->getText ("Marking as out of date..."));

                    $sourcesTable = new SourcesDetailTable ($context);
                    $sourceDetailsCriteria = array (new EqCriterion (SourcesDetailTable::COL_SCOPE, $dbtable->getTableName ()));
                    $sourceDetailsCriteria[] = new EqCriterion (SourcesDetailTable::COL_CONTEXTID, $id);
                    $sourceDetailsCriteria[] = new EqCriterion (SourcesDetailTable::COL_STATE, SourcesDetailTable::STATE_PENDING);
                    $sourceDetailValues = array (SourcesDetailTable::COL_STATE => SourcesDetailTable::STATE_OUTDATED);
                    // update all as outdated
                    if (false === $sourcesTable->updateRecord ($sourceDetailsCriteria, $sourceDetailValues, count ($existingDetails)))
                        {
                        $logger->writeLine ($context->getText ("Error outdating source details for match [_0].", $fullLabel));
                        $ret = false;
                        }
                    else
                        $existingDetails = NULL;
                    }
                }

            if (empty ($existingDetails))
                {
                if (false === SourcesDetailTable::storeDetails ($context, $dbtable, $id, $match["sourceDetails"], $sources, $sourceDate, $savePrepared, $copiedMatch))
                    {
                    $context->addError ("Could not save source details");
                    $ret = false;
                    }
                else
                    $logger->writeLine ($context->getText ("Wrote source details for match [_0]...", $fullLabel));
                }
            }
        return $ret;
        }

    public function saveMatch ($season, $round, $match, $excludedKeys)
        {
        // try to find existing game (update if found)
        $values = array ();
        $date = NULL;
        
        $existing = false;

        if (!empty ($season))
            $values["cstage"] = $season;
        if (!empty ($round))
            $values["round"] = $round;
        if (!empty ($match["roundId"]))
            $values["round"] = $match["roundId"];
        if (!empty ($match["round"]))
            $values["c_no"] = $match["round"];
        if (!empty ($match["number"]))
            $values["c_".Sports::COL_MATCH_NUMBER] = $match["number"];

        if (!empty ($match["id"]))
            {
            $id = $match["id"];
            $existing = true;
            }
        else if ("X" != $excludedKeys)
            {
            $values["hometeam"] = explode ("_", $match["homeTeamId"]);
            $values["awayteam"] = explode ("_", $match["awayTeamId"]);
            if (!is_array ($excludedKeys))
                $excludedKeys = explode (",", $excludedKeys);

            $criteria = array ();
            foreach ($values as $field => $val)
                {
                if (false !== array_search ($field, $excludedKeys))
                    continue;

                if ("round" == $field)
                    $criteria[] = new LogicalOperatorOr (new EqCriterion ($field, $val), new IsNullCriterion ($field));
                else
                    $criteria[] = new EqCriterion ($field, $val);
                }

            if (false === array_search ("date", $excludedKeys) && !empty ($match["date"]) && strlen ($match["date"]) >= strlen ('2006-06-06'))
                {
                $criteria[] = new LikeCriterion ("c_time", substr ($match["date"], 0, strlen ('2006-06-06')));
                }

            $row = $this->dbtable->selectSingleBy (array ("match_id", "time"), $criteria);
            if (!empty ($row))
                {
                $id = $row["match_id"];
                $existing = true;

                if (!empty ($match["date"]) && 0 == strncasecmp ($match["date"], $row["c_time"], strlen ($match["date"])))
                    unset ($match["date"]); // no need to overwrite existing more precise date
                }
            }

        if (!empty ($match["date"]))
            $values["c_time"] = $date = Language::getInstance($this->context)->parseDate ($match["date"]);

        $matchLabel = NULL;
        if ($existing)
            {
            $criteria = array (new EqCriterion ("match_id", $id));
            $values = array ();
            if (!isset ($values["hometeam"]))
                $matchLabel = "match $id";

            if (!empty ($match["date"]))
                $values["c_time"] = $date = Language::getInstance($this->context)->parseDate ($match["date"]);
            if (!empty ($match["number"]))
                $values["c_".Sports::COL_MATCH_NUMBER] = $match["number"];
            if (!empty ($round))
                $values["round"] = $round;
            }
        else
            {
            $values["hometeam"] = explode ("_", $match["homeTeamId"]);
            $values["awayteam"] = explode ("_", $match["awayTeamId"]);
            }

        if (isset ($match["c_outcome"]))
            $values["c_outcome"] = $match["c_outcome"];
        else if (!empty ($match["resultPenalty"]))
            $values["c_outcome"] = $match["resultPenalty"][0] > $match["resultPenalty"][1] ? MatchConstants::OUTCOME_PENALTIES_HOME : MatchConstants::OUTCOME_PENALTIES_AWAY;
        else if (!empty ($match["resultET"]))
            $values["c_outcome"] = MatchConstants::OUTCOME_EXTRA_TIME;
        else if (!empty ($match["result"]))
            $values["c_outcome"] = self::OUTCOME_NORMAL;
        else if (!$existing)
            $values["c_outcome"] = 1;

        if (!empty ($match["resultET"]))
            {
            $values["c_homeresult"] = $match["resultET"][0];
            $values["c_awayresult"] = $match["resultET"][1];
            }
        else if (!empty ($match["result"]))
            {
            $values["c_homeresult"] = $match["result"][0];
            $values["c_awayresult"] = $match["result"][1];
            }

        if (!empty ($match["stadiumId"]))
            $values["stadium"] = $match["stadiumId"];
        if (!empty ($match["spectators"]))
            $values["c_attendance"] = $match["spectators"];

        if (!empty ($match["homeCoachId"]))
            $values["homecoach"] = $match["homeCoachId"];
        if (!empty ($match["awayCoachId"]))
            $values["awaycoach"] = $match["awayCoachId"];

        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;

        if (!empty ($id))
            {
            if (false === $this->dbtable->updateRecord ($criteria, $values))
                return false;
            $status = "updating";
            }
        else if ($this->canCreateMatch)
            {
            $id = $this->dbtable->insertRecord ($values);

            if (false === $id)
                return false;

            $status = "inserted";
            }
        else
            return $this->logError ("Did not found a match which should be updated, nothing is saved - ".$this->getMatchLabel ($match));

        $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                     $this->dbtable->getId (),
                                                                     $id);

        if (empty ($matchLabel))
            {
            $matchLabel = $this->getMatchLabel ($match);
            }

        $fullLabel = "<a href=\"$url\">$date $matchLabel</a>";

        $this->updateSourceDetails ($match, $id, $fullLabel);

        if ($this->savePrepared)
            {
            $this->onSuccess ($match, $id, $fullLabel);
            return true;
            }

        $this->writeLine ("$status $fullLabel...");

        if (false === $this->updateOrInsertReferee ($match, $id, $existing))
            return false;
        if (false === $this->updateOrInsertFullTimeResult ($match, $id, $existing))
            return false;
        if (false === $this->updateOrInsertHalfTimeResult ($match, $id, $existing))
            return false;
        if (false === $this->updateOrInsertExtraTimeResult ($match, $id, $existing))
            return false;
        if (false === $this->updateOrInsertPenaltyResult ($match, $id, $existing))
            return false;

        $existingEvents = $this->retrieveExistingMatchEvents ($existing ? $criteria : false);

        $eventTypes = array ("goal", "book", "sent", "miss");
        foreach ($eventTypes as $type)
            {
            if (false === $this->updateOrInsertEvents ($match, $type, $id, $existingEvents[$type]))
                return false;
            }

        foreach (array ("homePlayers", "awayPlayers") as $type)
            {
            $this->updateOrInsertTeamPlayers ($match, $type, $id, $existing);
            }
            
        $this->onSuccess ($match, $id, $fullLabel);
        }

    protected function getMatchLabel ($match)
        {
        if (!empty ($match["homeTeam"]) && !empty ($match["awayTeam"]))
            return (!empty ($match["date"]) ? $match["date"]." " : "").$match["homeTeam"]." - ".$match["awayTeam"];
        else
            return (!empty ($match["date"]) ? $match["date"]." " : "").$match["homeTeamId"]." - ".$match["awayTeamId"];
        }

    protected function updateOrInsertTeamPlayers ($match, $type, $id, $existing)
        {
        $isHome = "homePlayers" == $type;
        if (empty ($match[$type]))
            return true;

        foreach ($match[$type] as $player)
            {
            if (false === $this->updateOrInsertTeamPlayer ($player, $isHome, $id, $existing))
                return false;
            }

        return true;
        }

    protected function updateOrInsertTeamPlayer ($player, $home, $id, $existing)
        {
        $values = array ("match_id" => $id, "player" => $player["id"], "c_hometeam" => $home);
        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;

        if (!empty ($player["name"]))
            $values[Sports::COL_PLAYER_ORIGINAL_NAME] = $player["name"];
        if (isset ($player["from"]))
            $values["c_entered"] = $player["from"];
        if (isset ($player["to"]))
            $values["c_left"] = $player["to"];
        if (isset ($player["captain"]))
            $values["c_captain"] = $player["captain"];
        if (isset ($player["no"]))
            $values["c_number"] = $player["no"];

        if (isset ($player["unused"]))
            $values["c_unused"] = $player["unused"];
        else
            $values["c_unused"] = false;

        if (isset ($player["pos"]))
            {
            switch ($player["pos"])
                {
                case "GK":
                    $values["position"] = 3;
                    break;
                }
            }

        if (isset ($player["substituteId"]))
            {
            $values["substitute"] = $player["substituteId"];
            }
        else if (isset ($player["substitute"]))
            {
            $substitute = $player["substitute"];
            $values["substitute"] = $substitute["id"];
            }
 
        /* try to update first */
        $criteria = array (new EqCriterion ("match_id", $id), new EqCriterion ("player", $player["id"]));
        $updateValues = $values;
        unset ($updateValues["match_id"]);
        unset ($updateValues["player"]);

        if (1 != $this->playerstable->updateRecord ($criteria, $updateValues, 1) &&
            false === $this->playerstable->insertRecord ($values))
            {
            return false;
            }

        if (isset ($substitute) && false == $this->updateOrInsertTeamPlayer ($substitute, $home, $id, $existing))
            return false;

        return true;
        }

    protected function updateOrInsertEvents ($match, $type, $id, $existing)
        {
        if (!isset ($match[$type]))
            return true;

        if (!empty ($existing))
            {
            $homeFlagSet = true;
            $homeCount = 0;
            $awayCount = 0;
            foreach ($match[$type] as $player)
                {
                if (!isset ($player["home"]))
                    {
                    $homeFlagSet = false;
                    break;
                    }
    
                if ($player["home"])
                    $homeCount++;
                else
                    $awayCount++;
                }
    
            $existingHomeEvents = array ();
            $existingAwayEvents = array ();
            if ($homeFlagSet)
                {
                foreach ($existing as $evnt)
                    {
                    if ($evnt["c_ishome"])
                        $existingHomeEvents[] = $evnt;
                    else
                        $existingAwayEvents[] = $evnt;
                    }
                }

            if (count ($existingHomeEvents) > 0 && count ($existingHomeEvents) > $homeCount)
                print $this->getText ("More stored '[_0]' records than defined in current protocol", $type);
            else if (count ($existingAwayEvents) > 0 && count ($existingAwayEvents) > $awayCount)
                print $this->getText ("More stored '[_0]' records than defined in current protocol", $type);
            }

        $homeCount = $awayCount = 0;
        foreach ($match[$type] as $player)
            {
            $existingEntry = NULL;
            if (!empty ($existing))
                {
                if ($homeFlagSet)
                    {
                    if ($player["home"])
                        {
                        if (count ($existingHomeEvents) >= $homeCount)
                            $existingEntry = $existingHomeEvents[$homeCount++];
                        }
                    else if (count ($existingAwayEvents) >= $awayCount)
                        $existingEntry = $existingAwayEvents[$awayCount++];
                    }
                else if (count ($existing) == count ($match[$type]))
                    $existingEntry = $existing[$homeCount++];
                }

            if (false === $this->updateOrInsertEvent ($player, $type, $id, $existingEntry, $match))
                return false;
            }

        return true;
        }

    protected function updateOrInsertEvent ($player, $type, $id, $existing, $match)
        {
        $values = array ("match_id" => $id);
        if (!empty ($player["id"]))
            $values["player"] = $player["id"];

        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;

        if ("goal" == $type)
            {
            $dbtable = $this->goaltable;
            $values["c_penalty"] = !empty ($player["pk"]);
            $values["c_own"] = !empty ($player["og"]);

            if (!empty ($existing) && $existing["player"][0] != $player["id"] && $existing["c_min"] != $player["min"])
                $values["assist"] = NULL;
            if (!empty ($player["name"]))
                $values[Sports::COL_GOAL_ORIGINAL_NAME] = $player["name"];
            }
        else
            {
            $dbtable = $this->eventtable;
            switch ($type)
                {
                case "book":
                    $typeId = MatchConstants::EVENT_YELLOW;
                    break;
                case "miss":
                    $typeId = MatchConstants::EVENT_MISS;
                    break;
                case "sent":
                    $typeId = (empty ($player["yellow"])) ? MatchConstants::EVENT_RED : MatchConstants::EVENT_YELLOW_RED;
                    if (!isset ($player["yellow"]) && !empty ($existing) && ($existing["player"][0] == $player["id"] || $existing["c_min"] == $player["min"]))
                        $typeId = $existing["c_event"];
                    break;
                }

            if (!empty ($existing) && $existing["player"][0] != $player["id"] && $existing["c_min"] != $player["min"])
                $values[Sports::COL_EVENT_CAUSE] = NULL;
            if (!empty ($player["name"]))
                $values[Sports::COL_EVENT_ORIGINAL_NAME] = $player["name"];
            }

        if (isset ($player["min"]))
            $values["c_min"] = $player["min"];
        if (isset ($player["extra"]))
            $values["c_extra"] = $player["extra"];
        else
            $values["c_extra"] = NULL;

        if (isset ($typeId))
            $values["c_event"] = $typeId;
 
        if (isset ($player["home"]))
            $home = $player["home"];

        if (isset ($home))
            $values["c_ishome"] = $home;

        if (!empty ($existing))
            {
            $criteria = array (new EqCriterion ("match_id", $id), new EqCriterion ($dbtable->getIdColumn (), $existing[$dbtable->getIdColumn ()]));
            if (false === $dbtable->updateRecord ($criteria, $values))
                return false;
            }
        else if (false === $dbtable->insertRecord ($values))
            return false;

        return true;
        }

    protected function findTeamPlayer ($players, $name)
        {
        foreach ($players as $player)
            {
            if ($player["name"] == $name)
                {
                return true;
                break;
                }

            if (isset ($player["substitute"]))
                {
                $found = $this->findTeamPlayer (array ($player["substitute"]), $name);
                if ($found)
                    return true;
                }
            }

        return false;
        }
        
    protected function updateOrInsertReferee ($match, $id, $existing)
        {
        if (false === $this->updateOrInsertReferee2 ($match, "referee", self::MATCH_REFEREE_CITY, 1, $id, $existing) ||
            false === $this->updateOrInsertReferee2 ($match, "refereeA1", "refereeA1City", 2, $id, $existing) ||
            false === $this->updateOrInsertReferee2 ($match, "refereeA2", "refereeA2City", 3, $id, $existing) ||
            false === $this->updateOrInsertReferee2 ($match, "refereeR", "refereeRCity", 4, $id, $existing))
            {
            return false;
            }

        return true;
        }

    protected function updateOrInsertReferee2 ($match, $nameKey, $cityKey, $refereeType, $id, $existing)
        {
        $key = $nameKey."Id";
        if (empty ($match[$key]))
            return true;

        $values = array ("referee" => $match[$key]);
        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;

        if (!empty ($match[$nameKey]))
            $values[Sports::COL_REFEREE_ORIGINAL_NAME] = $match[$nameKey];

        if ($existing)
            {
            $criteria = array (new EqCriterion ("match_id", $id), new EqCriterion ("type", $refereeType));

            if (isset ($match[$cityKey]))
                $values["c_from"] = $match[$cityKey];

            $res = $this->refereetable->updateRecord ($criteria, $values);
            if ($res > 0)
                return true;
            }

        $values = array_merge (array ("match_id" => $id, "type" => $refereeType), $values);

        if (isset ($match[$cityKey]))
            $values["c_from"] = $match[$cityKey];

        if (false === $this->refereetable->insertRecord ($values))
            {
            $this->logError ("Cannot insert a referee record");
            return true;
            }

        return true;
        }

    protected function updateOrInsertHalfTimeResult ($match, $id, $existing)
        {
        if (!isset ($match["resultHalfTime"]))
            return true;

        $values = array ("c_home" => $match["resultHalfTime"][0], "c_away" => $match["resultHalfTime"][1]);
        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;

        if ($existing)
            {
            $criteria = array (new EqCriterion ("match_id", $id), new EqCriterion ("c_stage", self::OUTCOME_HALFTIME));

            $res = $this->matchflowtable->updateRecord ($criteria, $values);

            if ($res > 0)
                return true;
            }

        $values["match_id"] = $id;
        $values["c_stage"] = self::OUTCOME_HALFTIME;

        if (false === $this->matchflowtable->insertRecord ($values))
            return false;

        return true;
        }

    protected function updateOrInsertFullTimeResult ($match, $id, $existing)
        {
        if (!isset ($match["result"]))
            return true;

        $values = array ("c_home" => $match["result"][0], "c_away" => $match["result"][1]);
        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;

        if ($existing)
            {
            $criteria = array (new EqCriterion ("match_id", $id), new EqCriterion ("c_stage", MatchConstants::STAGE_FULL_TIME));

            $res = $this->matchflowtable->updateRecord ($criteria, $values);

            if ($res > 0)
                return true;
            }

        $values["match_id"] = $id;
        $values["c_stage"] = MatchConstants::STAGE_FULL_TIME;

        if (false === $this->matchflowtable->insertRecord ($values))
            return false;

        return true;
        }

    protected function updateOrInsertPenaltyResult ($match, $id, $existing)
        {
        if (!isset ($match["resultPenalty"]))
            return true;

        $values = array ("c_home" => $match["resultPenalty"][0], "c_away" => $match["resultPenalty"][1]);
        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;

        if ($existing)
            {
            $criteria = array (new EqCriterion ("match_id", $id), new EqCriterion ("c_stage", MatchConstants::STAGE_PENALTIES));

            $res = $this->matchflowtable->updateRecord ($criteria, $values);

            if ($res > 0)
                return true;
            }

        $values["match_id"] = $id;
        $values["c_stage"] = MatchConstants::STAGE_PENALTIES;

        if (false === $this->matchflowtable->insertRecord ($values))
            return false;

        return true;
        }

    protected function updateOrInsertExtraTimeResult ($match, $id, $existing)
        {
        if (!isset ($match["resultET"]))
            return true;

        $values = array ("c_home" => $match["resultET"][0], "c_away" => $match["resultET"][1]);
        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;

        if ($existing)
            {
            $criteria = array (new EqCriterion ("match_id", $id), new EqCriterion ("c_stage", MatchConstants::STAGE_EXTRA_TIME));

            $res = $this->matchflowtable->updateRecord ($criteria, $values);

            if ($res > 0)
                return true;
            }

        $values["match_id"] = $id;
        $values["c_stage"] = MatchConstants::STAGE_EXTRA_TIME;

        if (false === $this->matchflowtable->insertRecord ($values))
            return false;

        return true;
        }

    public function prepareMatches (&$matches)
        {
        foreach ($matches as &$match)
            {
            $this->prepareMatch ($match, $this->matchId > 0 && 1 == count ($matches));
            }
        }

    public function prepareMatch (&$match, $skipTeamNames = false)
        {
        if (!$this->savePrepared)
            {
            // check if "homeTeam" and "awayTeam" values are recognized
            if (!$skipTeamNames)
                {
                $this->checkTeam ($match, "homeTeam");
                $this->checkTeam ($match, "awayTeam");
                }

            // "stadium"
            $this->checkStadium ($match);

            // "referee", "refereeCity"
            $this->checkPerson ($match, "referee", "refereeId", true);
            $this->checkPerson ($match, "refereeA1", "refereeA1Id", true);
            $this->checkPerson ($match, "refereeA2", "refereeA2Id", true);
            $this->checkPerson ($match, "refereeR", "refereeRId", true);
            $this->checkCity ($match);

            $this->checkPerson ($match, "homeCoach", "homeCoachId", true);
            $this->checkPerson ($match, "awayCoach", "awayCoachId", true);

            foreach (array ("goal", "book", "sent", "miss") as $type)
                $this->checkEvents ($match, $type);

            foreach (array ("homePlayers", "awayPlayers") as $type)
                $this->checkPlayers ($match, $type);
            }

        $this->printRecognizedMatch ($match);
        }

    protected function retrieveExistingMatchEvents ($criteria)
        {
        $eventTypes = array ("goal", "book", "sent", "miss");
        $existingEvents = array ();
        foreach ($eventTypes as $type)
            $existingEvents[$type] = array ();

        if (false === $criteria)
            return $existingEvents;

        $columns = array (Sports::COL_GOAL_SCORER, Sports::COL_GOAL_PENALTY,
                          Sports::COL_GOAL_OWN, Sports::COL_GOAL_TIME_MIN,
                          Sports::COL_GOAL_TIME_EXTRA, Sports::COL_GOAL_HOME,
                          Sports::COL_GOAL_ASSIST, $this->goaltable->getIdColumn ());
        $existingEvents["goal"] = $this->goaltable->selectBy ($columns, $criteria);

        $columns = array (Sports::COL_EVENT_TYPE, Sports::COL_EVENT_CAUSE,
                          Sports::COL_EVENT_PLAYER, Sports::COL_EVENT_TIME_MIN,
                          Sports::COL_EVENT_TIME_EXTRA, Sports::COL_EVENT_ISHOME,
                          $this->eventtable->getIdColumn ());
        $events = $this->eventtable->selectBy ($columns, $criteria);
        if (!empty ($events))
            {
            foreach ($events as $event)
                {
                switch ($event["c_".Sports::COL_EVENT_TYPE])
                    {
                    case MatchConstants::EVENT_YELLOW:
                        $existingEvents["book"][] = $event;
                        break;
                    case MatchConstants::EVENT_YELLOW_RED:
                        $existingEvents["sent"][] = $event;
                        break;
                    case MatchConstants::EVENT_RED:
                        $existingEvents["sent"][] = $event;
                        break;
                    case MatchConstants::EVENT_MISS:
                        $existingEvents["miss"][] = $event;
                        break;
                    }
                }
            }
        
        return $existingEvents;
        }
    protected function retrieveExistingMatchInfo ()
        {
        if ($this->matchId <= 0)
            return array ();

        $criteria = array (new EqCriterion ($this->dbtable->getIdColumn (), $this->matchId));
        $existingEvents = $this->retrieveExistingMatchEvents ($criteria);
        $existing = array ();
        foreach ($existingEvents as $type => $rows)
            {
            $prepared = array ();
            if (empty ($rows))
                {
                $existing[$type] = $rows;
                continue;
                }

            foreach ($rows as $row)
                {
                $min = $row["c_min"];
                $extra = $row["c_extra"];
                $home = $row["c_ishome"];
                $name = $row["player.displayname"];
                $own = $penalty = false;
                if ("goal" == $type)
                    {
                    $own = $row["c_own"];
                    $penalty = $row["c_penalty"];
                    }

                $prepared[] = array ("min" => $min, "extra" => $extra, "home" => $home, "name" => $name, "og" => $own, "pk" => $penalty, );
                }
            $existing[$type] = $prepared;
            }

        return $existing;
        }

    protected function printRecognizedMatch ($match)
        {
        $texts = array
            (
            "result" => $this->getText ("Match result"),
            "players" => $this->getText ("Match players"),
            "goals" => $this->getText ("Match goals"),
            "events" => $this->getText ("Match events"),
            "coach" => $this->getText ("Coach"),
            "referees" => $this->getText ("Referees"),
            "stadium" => $this->getText ("Stadium"),
            "proposed" => $this->getText ("Proposed changes:"),
            "existing" => $this->getText ("Already saved:"),
            "spectators" => $this->getText ("Attendance:"),
            );

        return $this->printRecognizedMatchDetails ($match, $texts, $this->retrieveExistingMatchInfo());
        }

    public function compareByMin ($row1, $row2)
        {
        return $row1["min"] - $row2["min"];
        }

    protected function printRecognizedMatchDetails ($match, $texts, $existing)
        {
        $matchCopy = $match;
        foreach (array ("goal", "book", "sent", "miss") as $type)
            {
            if (isset ($match[$type]))
                {
                $matchCopy[$type] = $match[$type];
                usort ($matchCopy[$type], array ($this, "compareByMin"));
                }
            }

        $result = displayFromTemplate ($this->context, "sports", "recognizedgame", array ("match" => $matchCopy, "text" => $texts, "existing" => $existing), true);
        $this->writeLine ($result);
        }

    public function checkTeam (&$match, $key)
        {
        if (!empty ($match[$key."Id"]))
            return true;

        if (empty ($match[$key]))
            return $this->logError ("No $key set");

        $team = $match[$key];
        $requestKey = $this->encodeKey ($team);
        if (array_key_exists ($requestKey, $this->teams))
            {
            $match[$key."Id"] = $this->teams[$requestKey];
            }
        else
            {
            $this->hasUnrecognizedItems = true;
            if (false === array_search ("team", $this->fieldsNotReady))
                {
                $this->logError ("Unrecognized teams ('$team', ...)");
                $this->fieldsNotReady[] = "team";
                }
            }

        $this->updateField ("hometeam", "hometeam", $requestKey, $team);
        }
    
    protected function translateCountry ($country)
        {
        $translations = array
            (
            "ukraine" => "Ukraina",
            "lithuania" => "Lietuva",
            "russia" => "Rusija",
            "sweden" => "Švedija",
            "netherlands" => "Olandija",
            "slovenia" => "Slovėnija",
            "slovakia" => "Slovakija",
            "netherlands antilles" => "Nyderlandų Antilai",
            "croatia" => "Kroatija",
            "latvia" => "Latvija",
            "portugal" => "Portugalija",
            "germany" => "Vokietija",
            "belgium" => "Belgija",
            "england" => "Anglija",
            "china" => "Kinija",
            "denmark" => "Danija",
            "australia" => "Australija",
            "serbia" => "Serbija",
            "malta" => "Malta",
            "brazil" => "Brazilija",
            "nigeria" => "Nigerija",
            "italy" => "Italija",
            "burkina faso" => "Burkina Fasas",
            "belarus" => "Baltarusija",
            "finland" => "Suomija",
            "turkey" => "Turkija",
            "azerbaijan" => "Azerbaidžanas",
            "bosnia-herzegovina" => "Bosnija ir Herc",
            "romania" => "Rumunija",
            "usa" => "JAV",
            "israel" => "Izraelis",
            "côte d'ivoire" => "Dramblio kaulo krantas",
            "armenia" => "Armėnija",
            "south africa" => "Pietų Afrik",
            "liechtenstein" => "Lichtenšteinas",
            "scotland" => "Škotija",
            "czech republic" => "Čekija",
            "spain" => "Ispanija",
            "northern ireland" => "Šiaurės Airija",
            "norway" => "Norvegija",
            "wales" => "Velsas",
            );
        $country = trim ($country);
        $key = utf8_strtolower ($country);
        if (empty ($translations[$key]))
            {
            $this->logError ("Country '$country' was not recognized");
            return $country;
            }
        return $translations[$key];
        }

    protected function parsePlayerFromUrlContent ($content, $url, &$nameValue)
        {
        if (false != strpos ($url, "uefa.com"))
            {
            /* <div id="PlayerHeader" class="HeaderProfile">
                <div class="HeaderDetails"><h1 class="bigTitle">Oleksandr Borysenko</h1>
                <ul><li>Date of birth : 21/07/1987</li>
                    <li>Position : Goalkeeper</li>
                    <li><span>Country : </span><span><img height="18" width="18" alt="Ukraine" title="Ukraine" src="http://img.uefa.com/imgml/flags/18x18/UKR.png" /></span><span> Ukraine</span></li>
                </ul></div>
            */
            $inner = cutTextPiece ($content, '<div id="PlayerHeader" class="HeaderProfile">', '</div>');
            
            if (empty ($inner) || preg_match ('#<h1 class="bigTitle">(.+)</h1>#um', $inner, $nameMatch) < 1 ||
                preg_match ('#<li>Date of birth : ([0-9]{2})/([0-9]{2})/([0-9]{4})#um', $inner, $dateMatch) < 1)
                {
                return false;
                }

            $name = $nameMatch[1];
            $date = $dateMatch[3]."-".$dateMatch[2]."-".$dateMatch[1];
            if (preg_match ('#<span>Country : </span><span><img[^<]+/></span><span>(.+)</span>#um', $inner, $match) > 0)
                $country = $this->translateCountry ($match[1]);
            }
        else if (false != strpos ($url, "sfl.lt"))
            {
            /* <div class="infos">
                 <h3>Vytautas Dragūnevičius</h3>
                 <strong>Pozicija:</strong> Saugas<br />
                 <strong>Gimimo data:</strong> 1986-07-09 [25]<br />
                 <br />
                 <strong>Ūgis:</strong> 192 cm<br />
                 <strong>Svoris:</strong> 82 kg<br />
            </div>*/
            $inner = cutTextPiece ($content, '<div class="infos">', '</div>');
            
            if (empty ($inner) || preg_match ('#<h3>(.+)</h3>#um', $inner, $nameMatch) < 1 ||
                preg_match ('#<strong>Gimimo data:</strong>\s*([0-9-]+)#um', $inner, $dateMatch) < 1)
                {
                return false;
                }

            $name = $nameMatch[1];
            $date = $dateMatch[1];
            $country = "Lietuva";
            if (preg_match ('#<strong>Ūgis:</strong>\s*([0-9]+)#um', $inner, $match) > 0)
                $height = $match[1];
            if (preg_match ('#<strong>Svoris:</strong>\s*([0-9]+)#um', $inner, $match) > 0)
                $weigth = $match[1];
            }

        /*
        $table = ContentTable::createInstanceByName ($context, Sports::TABLE_PERSON);
        $a = $table->getExtentedPickList (2, "Andrius P");
        */
        $nameValue = trim ($name)."*".$date;
        if (!empty ($height))
            $nameValue .= "*{$height}cm";
        if (!empty ($weigth))
            $nameValue .= "*{$weigth}kg";
        if (!empty ($country))
            $nameValue .= '*'.$country;

        SportsHelper::$KnownSourceList[utf8_strtolower ($nameValue)] = $url;
        return true;
        }
    
    public function checkPerson (&$array, $key, $idKey, $optional = false, $urlKey = null)
        {
        if ($optional && !isset ($array[$key]))
            return;

        $name = trim ($array[$key], " ?");
        if (empty ($name))
            return;

        $requestKey = $this->encodeKey ($name);
        if (array_key_exists ($requestKey, $this->persons))
            {
            $array[$idKey] = $this->persons[$requestKey];
            }
        else if (!empty ($urlKey) && !empty ($array[$urlKey]))
            {
            $response = $this->retrieveHtml ($array[$urlKey]);
            if (empty ($response))
                $this->logError ("Cannot retrieve content from given player URL {$array[$urlKey]}");
            else
                {
                $id = $this->parsePlayerFromUrlContent ($response, $array[$urlKey], $name);
                if (false === $id)
                    $this->logError ("Cannot parse player URL content ({$array[$urlKey]})");
                /*else
                    $array[$idKey] = $id;*/
                }
            }

        if (empty ($array[$idKey]) && !$this->savePrepared)
            {
            $this->hasUnrecognizedItems = true;
            if (false === array_search ("person", $this->fieldsNotReady))
                {
                $this->logError ("Unrecognized persons ('$name', ...)");
                $this->fieldsNotReady[] = "person";
                }
            }

        $parts = preg_split ("/\./", $name, 2);
        if (2 == count ($parts))
            $name = $parts[0].". ".trim ($parts[1]);
        $this->updateField ("person", "person", $requestKey, $name);
        }

    public function checkEvents (&$match, $key)
        {
        if (!isset ($match[$key]))
            return;

        foreach ($match[$key] as &$player)
            {
            $this->checkPerson ($player, "name", "id", true, "url");
            }
        }

    public function checkPlayers (&$match, $key)
        {
        if (!isset ($match[$key]))
            return;

        foreach ($match[$key] as &$player)
            {
            $current = &$player;
            while (!empty ($current))
                {
                $this->checkPerson ($current, "name", "id", false, "url");
                if (!isset ($current["substitute"]))
                    break;
                $current = &$current["substitute"];
                }

            $this->checkPerson ($player, "substituteName", "substituteId", true);
            }
        }
        
    public function checkCity (&$match)
        {
        if (!isset ($match["refereeCity"]))
            return;

        $name = $match["refereeCity"];
        $validNames = array
            (
            "Vilnius", "Kaunas", "Alytus", "Jonava", "Palanga", "Veisiejai",
            "LVA", "ITA", "EST", "CZE", "SWE", "GER", "FIN", "DEN", "AUT", "LTU", "RUS"
            );
        if (false !== array_search ($name, $validNames))
            return;

        $invalidNames = array
            (
            "Marijampole" => "Marijampolė",
            "Klaipeda" => "Klaipėda",
            "Telsiai" => "Telšiai",
            "Riga, Latvia" => "Ryga",
            "Panevezys" => "Panevėžys",
            "Siauliai" => "Šiauliai",
            "Birstonas" => "Birštonas",
            "Ukmerge" => "Ukmergė",
            "Silute" => "Šilutė",
            "Joniskis" => "Joniškis",
            "Kupiskis" => "Kupiškis",
            );

        if (false !== array_search ($name, $invalidNames))
            return;

        if (isset ($invalidNames[$name]))
            {
            $match["refereeCity"] = $invalidNames[$name];
            return;
            }

        $this->logError ("Unrecognized city '$name'");
        }
    
    public function checkStadium (&$match)
        {
        if (empty ($match["stadium"]))
            return;

        $stadium = $match["stadium"];
        $requestKey = $this->encodeKey ($stadium);
        if (array_key_exists ($requestKey, $this->stadiums))
            {
            $match["stadiumId"] = $this->stadiums[$requestKey];
            }
        else
            {
            $this->hasUnrecognizedItems = true;
            if (false === array_search ("stadium", $this->fieldsNotReady))
                {
                $this->logError ("Unrecognized stadiums ('$stadium', ...)");
                $this->fieldsNotReady[] = "stadium";
                }
            }

        $this->updateField ("stadium", "stadium", $requestKey, $stadium);
        }

    public function checkStage (&$match, $round)
        {
        $requestKey = $this->encodeKey ($round);
        if (array_key_exists ($requestKey, $this->rounds))
            {
            $match["roundId"] = $this->rounds[$requestKey];
            }
        else
            {
            $this->hasUnrecognizedItems = true;
            if (false === array_search ("round", $this->fieldsNotReady))
                {
                $this->logError ("Unrecognized round ('$round', ...)");
                $this->fieldsNotReady[] = "round";
                }
            }

        $this->updateField (Sports::COL_MATCH_STAGE, Sports::COL_MATCH_STAGE, $requestKey, $round);
        }

    protected function collectMatchesOldFormat ($year, $plainResults)
        {
        /*
05.07
Panerys Vilnius - Vytis-Inkaras Kaunas 2:0. g. T.Ramelis, T.Graziunas.
Jovaras Mazeikiai - FK Neris Vilnius 1:4. g. S.Beniusis; S.Vitkovskis, G.Kalvaitis, J.Krasavcevas, K.Klisauskas.
        */

        $chunks = split("[\n\r]{3,6}", $plainResults);
        $matches = array ();
        $round = NULL;

        foreach ($chunks as $chunk)
            {
            $chunk = trim ($chunk);
            if (empty ($chunk))
                continue;

            $lines = split("[\n\r]+", $chunk);
            if (count ($lines) < 2)
                return $this->logError ("Cannot process match - '$chunk'");

            $date = $this->parseDate ($year, array_shift ($lines));
            if (false === $date)
                return $this->logError ("Cannot parse date - '$chunk'");

            $parsed = $this->collectMatchesFromArrayOldFormat ($date, $lines, $round);
            $matches = array_merge ($matches, $parsed);
            }

        return $matches;
        }

    public function getDBTable ($context, $name)
        {
        $table = ContentTable::createInstanceByName ($context, $name);
        if (empty ($table))
            {
            return $this->logError ("\"$name\" content table not found");
            }
        return $table;
        }

    public function getTeamLeagueSeasonsTable ($context)
        {
        return $this->getDBTable ($context, "teamleagueseasons");
        }

    protected function collectSchedule ($year, $season, $plainResults)
        {
        /*
1 	FK LiCS 	FK Fortūna 	2009 04 26 14:00 	Žalgirio baz. 	

2009-05-01  	12:00  	FK "ALEKSOTAS" Kaunas - "Triobet" Kaunas  	KFMDDA
        */

        $lines = preg_split ("#[\n\r]+#", $plainResults);
        $matches = array ();
        $lang = Language::getInstance ($this->context);

        foreach ($lines as $line)
            {
            $line = trim ($line);
            if (empty ($line))
                continue;

            $parts = preg_split ("#\t#", $line);
            $stadium = NULL;
            $round = NULL;
            $gameNumber = NULL;
            if (6 == count ($parts) && is_numeric (trim ($parts[0])) && is_numeric (trim ($parts[1])))
                {
                list ($gameNumber, $round, $hometeam, $visitors, $date, $stadium) = $parts;
                }
            if ((7 == count ($parts) || 8 == count ($parts)) && is_numeric (trim ($parts[0])) && is_numeric (trim ($parts[1])))
                {
                list ($gameNumber, $round, $hometeam, $visitors, $date, $time, $stadium) = $parts;
                $date .= " ".$time;
                }
            else if (5 == count ($parts))
                {
                if (is_numeric (trim ($parts[0])) && is_numeric (trim ($parts[1])))
                    list ($gameNumber, $round, $hometeam, $visitors, $date) = $parts;
                else if (is_numeric (trim ($parts[0])))
                    list ($round, $hometeam, $visitors, $date, $stadium) = $parts;
                else
                    return $this->logError ("Line $line not recognized");
                }
            else if (4 == count ($parts) && is_numeric (trim ($parts[0])))
                {
                list ($round, $hometeam, $visitors, $date) = $parts;
                $stadium = NULL;
                }
            else if (4 == count ($parts))
                {
                list ($date, $time, $teams, $stadium) = $parts;
                $patterns = array
                    (
                    '/^(.*".+".*|[^"]+) - (.*".+".*|[^"]+)$/uU',
                    '/^([^"]+) - (.*".+".*)$/uU',
                    '/^(.*".+".*) - (.*".+".*)$/uU',
                    );
                preg_match ('/^(.*".+".*|[^"]+) - (.*".+".*|[^"]+)$/uU', trim ($teams), $m);

                $round = $hometeam = $visitors = NULL;
                if (count ($m) > 2)
                    {
                    $hometeam = str_replace ('"', "", $m[1]);
                    $visitors = str_replace ('"', "", $m[2]);
                    }
                else
                    return $this->logError ("Cannot parse teams - '$teams'");
                $date .= " ".$time;
                }
            else
                return $this->logError ("Line $line not recognized");

            if (!empty ($date))
                {
                $date = $lang->parseDate ($date);
                if (false === $date)
                    return $this->logError ("Cannot parse date - '$date'");
                }

            $match = array ();
            $match["date"] = isset ($date) ? $date : $year;
            if (!empty ($round))
                $match["round"] = trim ($round);

            $match["homeTeam"] = trim ($hometeam);
            $match["awayTeam"] = trim ($visitors);
            if (!empty ($stadium))
                $match["stadium"] = trim ($stadium);
            if (!empty ($gameNumber))
                $match["number"] = trim ($gameNumber);

            $matches[] = $match;
            }

        return $matches;
        }

    protected function collectMatchesTableFormat ($year, $season, $plainResults)
        {
        $resultsTable = $this->getTeamLeagueSeasonsTable ($this->context);
        if (false === $resultsTable)
            return false;
        $columns = array ("team_id", "place");
        $criteria = array (new EqCriterion ("f_season_competitionstage_id", $season));
        $rows = $resultsTable->selectBy ($columns, $criteria);
        if (empty ($rows))
            return $this->logError ("Season results not found");

        $teams = array ();
        $startAt = NULL;
        $i = 0;
        foreach ($rows as $row)
            {
            ++$i;
            if (NULL === $startAt)
                $startAt = $row["c_place"];
            else if ($row["c_place"] != $startAt + $i - 1)
                return $this->logError ("Inconsistent results");
            $teams[$i] = $row["team_id"];
            }

        $lines = preg_split ("/[\n\r]+/", trim ($plainResults, "\n\r "));

        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $teamLabels = SportsHelper::getTeamLabels ($this->context, $teams);
        $explicitRowMapping = array ();

        $i = 0;
        $correctedLines = array ();
        foreach ($lines as $line)
            {
            if (preg_match ("/^([^0-9:][^:]+): (.+)$/", $line, $pregmatches) > 0)
                {
                $label = $pregmatches[1];
                $line = $pregmatches[2];
                }
            else
                break;
            ++$i;

            $correctedLines[] = $line;

            $matchingTeamId = NULL;
            foreach ($teams as $idx => $teamId)
                {
                $thisTeamLabel = $teamLabels[$teamId];
                if (false !== stripos ($thisTeamLabel, $label))
                    {
                    if (NULL !== $matchingTeamId)
                        return $this->logError ("Ambiguous team label ($label)");
                    $matchingTeamId = $teamId;
                    unset ($teams[$idx]);
                    }
                }
            if (NULL === $matchingTeamId)
                return $this->logError ("Incorrect team label ($label)");

            $explicitRowMapping[$i] = $matchingTeamId;
            }

        $reverse = false;

        if (!empty ($explicitRowMapping))
            {
            if ($i != count ($lines))
                return $this->logError ("Please specify all team names or do not explicitly specify any name");
            if (1 == count ($teams))
                {
                foreach ($teams as $teamId)
                    $explicitRowMapping[++$i] = $teamId;
                }
            $teams = $explicitRowMapping;
            $lines = $correctedLines;
            }
        else if (count ($lines) > 1)
            {
            // check if reverse table was provided (lower left part)
            $results = explode (" ", trim ($lines[0]));
            if (1 == count ($results))
                {
                $reverse = true;
                $lines = array_reverse ($lines);
                $teams = array_combine (array_keys ($teams), array_reverse (array_values ($teams)));
                }
            }

        $i = 0;
        $teamCount = count ($teams);
        $matches = array ();
        $status = true;
        $gameStatus = array ();
        $isFullLineProvided = $teamCount == count ($lines);

        foreach ($lines as $line)
            {
            ++$i;
            $results = preg_split ("#\s+#", trim ($line));
            
            $validFullResult = $isFullLineProvided && ($teamCount != count ($results));
            $validPartialResult = !$isFullLineProvided && $teamCount == ($i + count ($results));
            if ($validFullResult || $validPartialResult)
                {
                $status = $this->logError ("Incomplete results entered (line $i - '$line')");
                continue;
                }

            if ($reverse)
                $results = array_reverse ($results);

            for ($j = $isFullLineProvided ? 1 : $i + 1; $j <= $teamCount; $j++)
                {
                $currentResult = $results[$isFullLineProvided ? $j - 1 : $j-$i-1];
                if ($i == $j || "X" == $currentResult)
                    continue;

                $currentResult = str_replace ("+:–", "W:0", $currentResult);
                $currentResult = str_replace ("–:+", "0:W", $currentResult);

                $matchResult = preg_split ("/[:-]/", $currentResult);
                if (count ($matchResult) != 2)
                    {
                    $status = $this->logError ("Unrecognized result '{$currentResult}' (line $i - '$line')");
                    continue;
                    }

                if ("W" == $matchResult[0])
                    {
                    $match = array ("homeTeamId" => $teams[$i],
                                    "awayTeamId" => $teams[$j],
                                    "c_outcome" => MatchConstants::OUTCOME_NO_VISITORS);
                    }
                else if ($isFullLineProvided && "W" == $matchResult[1])
                    {
                    $match = array ("homeTeamId" => $teams[$i],
                                    "awayTeamId" => $teams[$j],
                                    "c_outcome" => MatchConstants::OUTCOME_NO_HOME_TEAM);
                    }
                else if ("W" == $matchResult[1])
                    {
                    $match = array ("homeTeamId" => $teams[$j],
                                    "awayTeamId" => $teams[$i],
                                    "c_outcome" => MatchConstants::OUTCOME_NO_VISITORS);
                    }
                else
                    $match = array
                            (
                            "homeTeamId" => $teams[$i],
                            "awayTeamId" => $teams[$j],
                            "result" => $matchResult,
                            );
                $status = "";
                if (!empty ($year))
                    {
                    $match["date"] = "$year-00-00";
                    $status = $match["date"].": ";
                    }

                $status .= $teamLabels[$match["homeTeamId"]]." - ".$teamLabels[$match["awayTeamId"]]." ";
                if ($match["c_outcome"] == MatchConstants::OUTCOME_NO_VISITORS)
                    $status .= "+:-";
                else
                    $status .= implode (":", $match["result"]);
                $gameStatus[] = $status;

                $matches[] = $match;
                }
            }

        if ($i != $teamCount - ($isFullLineProvided ? 0 : 1))
            return $this->logError ("Not all the lines entered");

        if (!$status)
            return false;

        $this->writeLine ("<pre>".implode ("\n", $gameStatus)."</pre>");
        return $matches;
        }

    protected function collectNational1940Matches ($year, $plainResults)
        {
        $chunks = preg_split ("/[\n\r]{3,6}/", $plainResults);
        $matchArray = array ();

        foreach ($chunks as $chunk)
            {
            $chunk = trim ($chunk);
            if (empty ($chunk))
                continue;

            $lines = preg_split ("/[\n\r]+/", $chunk);
            $l = 0;
            $headerLine = $lines[$l++];
            if (count ($lines) == $l)
                return $this->logError ("Teams and result not found '{$plainResults}'");
            $resultLine = $lines[$l++];
            if (count ($lines) == $l)
                return $this->logError ("Teams and result not found '{$plainResults}'");

            $goalsLine = NULL;
            foreach (array ("g.", "Goal:", "Goals:") as $goalsLinePrefix)
                {
                if (0 == strncasecmp ($lines[$l], $goalsLinePrefix, strlen ($goalsLinePrefix)))
                    {
                    $goalsLine = trim (substr ($lines[$l++], strlen ($goalsLinePrefix)), " .");
                    break;
                    }
                }

            $homeTeam = NULL;
            $homeCoach = NULL;
            $homeCaptain = NULL;
            $awayTeam = NULL;
            $awayCoach = NULL;
            $awayCaptain = NULL;
            $homeSubstitutes = NULL;
            $awaySubstitutes = NULL;
            $additionalLines = array();
            while ($l < count ($lines))
                {
                $line = $lines[$l++];
                if (0 == strncasecmp ($line, "Coach", 5))
                    {
                    foreach (array ("Substitutes:", "Substitute(s):") as $pattern)
                        {
                        if (false !== strpos ($line, $pattern))
                            {
                            list ($line, $substitutes) = explode ($pattern, $line);
                            if (NULL === $awayTeam)
                                $homeSubstitutes = $substitutes;
                            else
                                $awaySubstitutes = $substitutes;
                            break;
                            }
                        }

                    preg_match ('/^Coach: (.+)(\.|,) Captain: (.+)( \([0-9]+\))?$/u', trim ($line, " ."), $matches);
                    if (count ($matches) < 3)
                        {
                        preg_match ('/^Coach: (.+)$/u', trim ($line, " ."), $matches);
                        if (count ($matches) < 1)
                            return $this->logError ("Cannot parse coach and captain - '$line'");
                        }

                    if (NULL === $awayTeam)
                        {
                        $homeCoach = trim ($matches[1], "?- ");
                        preg_match ('/^(.+) \([0-9]+\)$/U', $homeCoach, $m);
                        if (count ($m) == 2)
                            $homeCoach = $m[1];

                        if (count ($matches) > 3)
                            {
                            $homeCaptain = trim ($matches[3], "?- ");
                            preg_match ('/^(.+) \([0-9]+\)$/U', $homeCaptain, $m);
                            if (count ($m) == 2)
                                $homeCaptain = $m[1];
                            }
                        }
                    else
                        {
                        $awayCoach = trim ($matches[1], "?- ");
                        preg_match ('/^(.+) \([0-9]+\)$/U', $awayCoach, $m);
                        if (count ($m) == 2)
                            $awayCoach = $m[1];

                        if (count ($matches) > 3)
                            {
                            $awayCaptain = trim ($matches[3], "?- ");
                            preg_match ('/^(.+) \([0-9]+\)$/U', $awayCaptain, $m);
                            if (count ($m) == 2)
                                $awayCaptain = $m[1];
                            }
                        }

                    continue;
                    }

                $recognized = false;
                foreach (array ("Missed pk", "Booket", "Sent") as $key)
                    {
                    if (0 == strncasecmp ($line, $key, strlen ($key)))
                        {
                        //$line = str_replace ($key." ", $key.": ", $line);
                        $recognized = true;
                        break;
                        }
                    }

                if ($recognized)
                    {
                    $additionalLines[] = $line;
                    continue;
                    }

                if (preg_match ("/([A-Z ]+)\:(.+)/", $line, $teamMatch) <= 0)
                    return $this->logError ("Team players line unrecognized - '$line'");
                $line = trim ($teamMatch[2], ". ");
                if (NULL === $homeTeam)
                    $homeTeam = $line;
                else if (NULL === $awayTeam)
                    $awayTeam = $line;
                else
                    return $this->logError ("Too many team player lines - '$line'");
                }

            $match = $this->parseNationalMatch ($headerLine, $resultLine, $goalsLine,
                                                $homeTeam, $homeCoach, $homeCaptain,
                                                $awayTeam, $awayCoach, $awayCaptain,
                                                $additionalLines, $homeSubstitutes, 
                                                $awaySubstitutes);
            if (false === $match)
                return false;

            $matchArray[] = $match;
            }

        return $matchArray;
        }

    protected function parseNationalMatch ($headerLine, $resultLine, $goalsLine,
                                           $homeTeam, $homeCoach, $homeCaptain,
                                           $awayTeam, $awayCoach, $awayCaptain,
                                           $additionalLines, $homeSubstitutes,
                                           $awaySubstitutes)
        {
        $match = array ();

        $shortDatePattern = "([0-9]{1,2})\.([0-9]{1,2})\.([0-9]{4})";
        $longDatePatternWithoutWeekday = "([0-9]{1,2}) (Jan|January|Feb|February|Mar|March|Apr|April|May|Jun|June|Jul|July|Aug|August|Sep|September|Oct|October|Nov|November|Dec|December)[,]? ([0-9]{4})";
        $longDatePattern = "$longDatePatternWithoutWeekday(\, (Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday))?";
        $timePattern = "[0-9]{1,2}\:[0-9]{2}";

        $headerLine = preg_replace ("/( [A-Z])\./", "\\1˷", $headerLine);

        // First parse thew header line - "24.06.1923. Kaunas. LFLS. 3000 A.HAHNE (LVA)"
        $patterns = array ("/^($shortDatePattern|$longDatePattern)([.,]? ($timePattern))?[.,] (.+)\. Att. ([0-9?]+)\.? Rf. ([^0]+) (\((.+)\))?$/u" => array (1, 11, 12, 13, 14, 16),
                           "/^($shortDatePattern|$longDatePattern)([.,]? ($timePattern))?[.,] (.+)\. ([0-9]+)\.? ([^0]+) (\((.+)\))?$/u" => array (1, 11, 12, 13, 14, 16),
                           "/^($shortDatePattern|$longDatePattern)([.,]? ($timePattern))?[.,] (.+)\. Rf. ([^0]+) (\((.+)\))?$/u" => array (1, 11, 12, NULL, 13, 15),
                           "/^($shortDatePattern|$longDatePattern)([.,]? ($timePattern))?[.,] (.+)\. (.+) (\((.+)\))?$/u" => array (1, 11, 12, NULL, 13, 15),
                           );

        $found = false;
        foreach ($patterns as $pattern => $indexes)
            {
            if (0 == preg_match ($pattern, trim ($headerLine, ". "), $matches))
                continue;

            list ($dateIndex, $timeIndex, $stadiumIndex, $spectatorsIndex, $refereeIndex, $refereeCityIndex) = $indexes;
            $found = true;
            break;
            }

        if (!$found)
            return $this->logError ("Cannot parse the header line - '$headerLine'");

        foreach ($matches as &$matchEntry)
            {
            $matchEntry = preg_replace ("/( [A-Z])˷/U", "\\1.", $matchEntry);
            }

        $unformattedDate = preg_replace ("/^$longDatePatternWithoutWeekday/", "\\1 \\2 \\3", $matches[$dateIndex]);
        $parsedDate = strtotime ($unformattedDate);
        if (false === $parsedDate)
            return $this->logError ("Cannot parse the date - '{$matches[$dateIndex]}'");

        $match["date"] = date ("Y-m-d", $parsedDate);
        if (NULL !== $timeIndex && !empty ($matches[$timeIndex]))
            $match["date"] = $match["date"]." ".$matches[$timeIndex];

        if (NULL !== $stadiumIndex)
            $match["stadium"] = trim ($matches[$stadiumIndex]);
        if (NULL !== $spectatorsIndex && "?" != $matches[$spectatorsIndex])
            $match["spectators"] = $matches[$spectatorsIndex];
        
        if (NULL !== $refereeIndex)
            {
            $referee = trim ($matches[$refereeIndex], " ?");
            if (!empty ($referee))
                {
                $match["referee"] = $referee;
                if (NULL !== $refereeCityIndex && !empty ($matches[$refereeCityIndex]))
                    $match["refereeCity"] = trim ($matches[$refereeCityIndex]);
                }
            }

        // Now the result
        if (false === $this->parseMatchResult (trim ($resultLine, ". "), $match, $error))
            return $this->logError ($error);

        $result = $match["result"];
        $home = NULL;
        if (0 == $result[0] || 0 == $result[1])
            $home = $result[0] > 0;

        if (!empty ($goalsLine))
            {
            $players = $this->parseMatchPlayerEvents ($goalsLine, $home, true, $match, true);
            if (false === $players)
                return false;

            $match["goal"] = $players;
            }

        if (!empty ($homeTeam))
            {
            // $homeTeam, $homeCoach, $homeCaptain
            $homeTeam = str_replace ('; ', ', ', $homeTeam);
            $players = $this->parseTeamPlayers ($homeTeam);
            if (false === $players)
                return false;

            if (!empty ($homeCoach))
                $match["homeCoach"] = $homeCoach;

            if (!empty ($homeCaptain))
                {
                $found = false;
                foreach ($players as &$player)
                    {
                    if (0 === strcasecmp ($player["name"], $homeCaptain))
                        {
                        $player["captain"] = true;
                        $found = true;
                        break;
                        }
                    }
                if (!$found)
                    $this->logError ("Captain not found ($homeCaptain)");
                }

            if (!empty ($homeSubstitutes))
                $players = array_merge ($players, $this->parseMatchSubstitutes ($homeSubstitutes));

            $match["homePlayers"] = $players;
            }

        if (!empty ($awayTeam))
            {
            $awayTeam = str_replace ('; ', ', ', $awayTeam);
            $players = $this->parseTeamPlayers ($awayTeam);
            if (false === $players)
                return false;

            if (!empty ($awayCoach))
                $match["awayCoach"] = $awayCoach;

            if (!empty ($awayCaptain))
                {
                $found = false;
                foreach ($players as &$player)
                    {
                    if (0 === strcasecmp ($player["name"], $awayCaptain))
                        {
                        $player["captain"] = true;
                        $found = true;
                        break;
                        }
                    }
                if (!$found)
                    $this->logError ("Captain not found ($awayCaptain)");
                }

            if (!empty ($awaySubstitutes))
                $players = array_merge ($players, $this->parseMatchSubstitutes ($awaySubstitutes));

            $match["awayPlayers"] = $players;
            }

        $parserCache = array ();
        foreach ($additionalLines as $line)
            {
            if (false === $this->processSingleMatchPart ($match, $parserCache, $line))
                return false;
            }

        return $this->postProcessSingleMatch ($match);
        }

    protected function parseMatchSubstitutes ($substitutes)
        {
        $players = $this->parseTeamPlayers ($substitutes);
        foreach ($players as &$player)
            {
            $player["from"] = NULL;
            $player["to"] = NULL;
            $player["unused"] = true;
            if (!empty ($player["substitute"]))
                $this->logError ("Substituted unused player");
            $player["substitute"] = NULL;
            }

        return $players;
        }
        
    protected function collectMatchesFromArrayOldFormat ($date, $lines, $round)
        {
        $matches = array ();
        foreach ($lines as $line)
            {
            $match = NULL;
            $parts = explode (" g. ", $line);
            $header = $parts[0];

            $match = $this->parseMatchHeaderShort ($header, $date, $round);
            if (false === $match)
                return false;

            if (2 == count ($parts))
                {
                $goals = $parts[1];
                $result = $match["result"];
                $home = NULL;
                if (0 == $result[0] || 0 == $result[1])
                    {
                    $home = $result[0] > 0;
                    }

                $players = $this->parseMatchPlayerEvents ($goals, $home, true);
                if (false === $players)
                    return false;

                $match["goal"] = $players;
                }

            $matches[] = $match;
            }

        return $matches;
        }

    public function parseDate ($year, $line)
        {
        preg_match ('/^([0-9]{2})\.([0-9]{2})$/u', trim ($line), $matches);
        if (3 != count ($matches))
            return $this->logError ("Cannot parse date - '$plainData'");

        return sprintf ("%04d-%02d-%02d", $year, $matches[1], $matches[2]);
        }

    public function collectMatches ($year, $plainResults, $treatTeamAs = 0)
        {
        /*
Round 1   (or "from Round 21")

[Mar 29, Sat]
15.00  FBK Kaunas - FK Silute  3:0 (1:0). V.Chileckis (Kaunas). Kaunas. S.Darius ir S.Girenas SK. 660.
Goals: 34 R.Ledesma, 88 (pk) M.Grigalevicius, 90 M.Grigalevicius.
KAU: L.Vertelis, N.Radzius, P.Mendy, V.Zubavicius (70 A.Laurisas), A.Khubutia, N.Manchkhava, G.Kvaratskhelia, E.Pehlic (55 A.Mrowiec), L.Pilibaitis, R.Ledesma, A.Jersovas (46 M.Grigalevicius).
SIL: M.Malinauskas, G.Klevinskas, D.Sanajevas, A.Juozaitis, P.Vaikasas, N.Valskis (69 P.Kovacev), I.Fattakhov, V.Birksys, M.Sirvidas, G.Podelis (33 I.Brezina), E.Marozas (46 T.Straleckas).
Booket: 76 A.Khubutia; 87 M.Malinauskas.
Sent Off: 60 D.Sernas.        
        */
        
        // check if every other line is empty (in this case remove empty lines)
        $chunks = preg_split ("/[\\n\\r]{1,2}/", trim ($plainResults));
        $tooManyLines = true;
        for ($i = 1; $i < count ($chunks); $i+=2)
            {
            if (!empty ($chunks[$i]))
                {
                $tooManyLines = false;
                break;
                }
            }
            
        if ($tooManyLines)
            {
            $initialCount = count ($chunks);
            for ($i = 1; $i < $initialCount; $i+=2)
                {
                unset ($chunks[$i]);
                }
            $plainResults = implode ("\n", $chunks);
            }

        $round = NULL;
        $chunk = trim ($plainResults);
        if (empty ($chunk))
            return array ();

        $matches = $this->processSingleMatch ($year, $chunk, $date, $round, $treatTeamAs);
        return $matches;
        }

    protected function extractHeaderPartsAfterGoals ($line, &$goals)
        {
        if (preg_match ("/^(.*)((Booke[dt]\:?|Missed pk\:?|Sent\:|Sent [oO]ff\:)(.+))$/U", $line, $matches) > 0)
            {
            $goals = $matches[1];
            return $matches[2];
            }

        $goals = $line;
        return NULL;
        }

    protected function preprocessMatchLine ($line)
        {
        $line = preg_replace ('/([:,;]) ([^,]+) \(([0-9]+)\) - penalty/', '$1 $3 (pk) $2', $line);
        $line = preg_replace ("/([:-][0-9]+[)]?[.]) ([A-Z]\.[A-Za-z\- ]+ \([0-9])/m", "\\1 g. \\2", trim ($line, " ."));
        $line = preg_replace ("/^([0-9]+\.)\s*([^.,;]+) ([0-9]+:[0-9]+\s*\([0-9]+:[0-9]+\)) ([^.,;]+)$/m", "\\1 \\2 - \\4 \\3", trim ($line, " ."));
        $line = preg_replace ("/(\.) (g\.|Sent off) (.+)\. Rf\. ([^()]+ \([^()]+\))/m", "\\1 Rf. \\4. \\2 \\3", trim ($line, " ."));
        $line = preg_replace ("/([0-9]+) sent off ([A-Z]\.[A-Za-z]+)/m", "Sent off: \\1 \\2", trim ($line, " ."));
        $line = preg_replace ("/(\.) (g\.|Sent off:|Booke[dt]) (.+)\. Att\. ([0-9]+)/m", "\\1 Att. \\4. \\2 \\3", trim ($line, " ."));

        $line = preg_replace ("/Sent (o|O)ff(\: | )/", "Sent off: ", $line);
        $line = preg_replace ("/\. 1st game( -|:)? [0-9]+[:-][0-9]+\.?$/", "", $line);
        $line = preg_replace ("/^g[.:] /", "Goals: ", $line);
        $line = preg_replace ("/^b[.:] /", "Booked: ", $line);
        $line = preg_replace ("/\. b[.:] /", ". Booked: ", $line);
        $line = preg_replace ("/^so[.:] /", "Sent: ", $line);
        $line = preg_replace ("/(Booke[td]|Missed pk|Sent [oO]ff) /", "$1: ", $line);
        $line = preg_replace ("/^Yellow cards*:/", "Book:", $line);
        $line = preg_replace ('/o\.g\./', 'og', $line);
        $line = preg_replace ('/p\.k\./', 'pk', $line);
        $line = preg_replace ('/\. ([0-9]+ [A-Z.a-z]+ \([A-Za-z ]+\)) missed pk/', '. Missed pk: $1', $line);
        $line = preg_replace ('/^([0-9]+)\s+spectators\s*$/', 'Att.: $1', $line);

        // fix missing dot in person names
        $line = preg_replace ("/ ([A-Z]) ([A-Z][a-z]{1,3})/", " $1. $2", $line);
        // missing space
        $line = preg_replace ("/([0-9]+)( min\.)?([A-Z]\.)/", " $1$2 $3", $line);

        $line = preg_replace ("/`([0-9]+) min /", "$1 min. ", $line);
        
        $line = preg_replace ("/([0-9]+) - ([A-Z]\.)/", " $1 $2", $line);

        $line = preg_replace ("/([a-z])\(([0-9]{1,2})\)/", "$1 ($2)", $line);

        // replace "7 min. R.Bakus (2:0, į savo vartus)" with "56 (og) D.Tomašauskas (2:0)"
        $line = preg_replace ("/([0-9]+)( min\.)? ([A-ZĄČŠŪŽÄÖÜÕÅ]\.\s?[A-Za-zĄČĘĖĮŠŲŪŽÄÖÜÕÅąčęėįšųūžäöüõå]+) \([0-9:]+,? į savo vartus\)/u", "$1 (og) $3", $line);

        // replace "7 min. R.Bakus (2:0, iš 6 m.)" with "56 (pk) D.Tomašauskas (2:0)"
        $line = preg_replace ("/([0-9]+)( min\.)? ([A-ZĄČŠŪŽÄÖÜÕÅ]\.\s?[A-Za-zĄČĘĖĮŠŲŪŽÄÖÜÕÅąčęėįšųūžäöüõå]+) \([0-9:]+,? iš [61]+\s*m\.?\)/u", "$1 (pk) $3", $line);

        // replace "56 min. D.Tomašauskas („Kruoja“ į savo vartus)" with "56 (og) D.Tomašauskas"
        $line = preg_replace ("/([0-9]+)( min\.)? ([A-ZĄČŠŪŽÄÖÜÕÅ]\.\s?[A-Za-zĄČĘĖĮŠŲŪŽÄÖÜÕÅąčęėįšųūžäöüõå]+) \(„[^„“]+“,? į savo vartus\)/u", "$1 (!og) $3", $line);

        // some Lithuanian translations
        $line = preg_replace ('/([^:,;]+) - po rungtynių už teisėjo įžeidimą/uU', '150 $1', $line);
        $line = preg_replace ("/Įvar(čiai|tis)/", "Goals", $line);
        $line = preg_replace ("/(Įspėjima[is]|Įspėt(i|as))/", "Booked", $line);
        $line = preg_replace ("/Įspėjimų nėra/", "No bookings", $line);
        $line = preg_replace ("/Pašalin(ima[is]|t(i|as))/", "Sent Off", $line);
        $line = preg_replace ("/už 2-ą įspėjimą( [-])?/", "(2nd)", $line);
        $line = preg_replace ("/už 2-ą geltoną( [-])?/", "(2nd)", $line);
        $line = preg_replace ("/min. ([^,():;]+) \(į sav(o|us) vartus, ([0-9]+:[0-9]+)\)/U", "min. (og) $1 ($3)", $line);
        $line = preg_replace ("/į sav(o|us) vartus/", "(og)", $line);
        $line = preg_replace ("/neįmušė 11 m.( baudinio)?/", "(miss)", $line);
        $line = preg_replace ("/- įvartis/iu", "-", $line);
        $line = preg_replace ("/(\- )?iš 11 m\.b\./iu", "(pk)", $line);
        $line = preg_replace ("/\(?iš 11\s?m\.\)?/i", "(pk)", $line);
        $line = preg_replace ("/\(?iš 11\s?m\.\)?/i", "(pk)", $line);
        $line = preg_replace ("/^Teisėja[is]?(\: | - | )([^(,;]+)[,;]([^(;,]+)\((.+)\)$/u", "Referee: $2 ($4), $3 ($4)", $line);
        $line = preg_replace ("/^Teisėja[is]?(\: | - | )(.+)\, asistentai\s?[-]? (.+)( ir|,) (.+)$/m", "Referees: \\2, \\3, \\5", $line);
        $line = preg_replace ("/^Teisėja[is]?(\: | - | )(.+)\, ([0-9]+) žiūrov(ų|ai)$/m", "Referee: \\2. Att. \\3", $line);
        $line = preg_replace ("/^Teisėja[is]?(\: | - | )/m", "Referee:", $line);
        $line = preg_replace ("/^Žiūrov(ų|ai|ų skaičius|ų sk\.)\s*[-:]/uU", "Att.:", $line);
        $line = preg_replace ("/\(\(2nd\)\)/", "(2nd)", $line);
        $line = preg_replace ("/Kov(as|o)/", "Mar", $line);
        $line = preg_replace ("/Baland(is|žio) (mėn.\s)?([0-9])/", "Apr \\3", $line);
        $line = preg_replace ("/Gegužė[s]?/", "May", $line);
        $line = preg_replace ("/Birželi[os]/", "Jun", $line);
        $line = preg_replace ("/Liep(a|os) (mėn.\s)?([0-9])/", "Jul \\3", $line);
        $line = preg_replace ("/Rugpjū(tis|čio)/", "Aug", $line);
        $line = preg_replace ("/Rugsėj(is|o)/", "Sep", $line);
        $line = preg_replace ("/Spali[so]/", "Oct", $line);
        $line = preg_replace ("/Lapkri(tis|čio)/", "Nov", $line);
        $line = preg_replace ("/nėra/", "none", $line);
        $line = preg_replace ("/(d\. )?\((pirmadienis|antradienis|trečiadienis|ketvirtadienis|penktadienis|šeštadienis|sekmadienis)\)/", "", $line);

        // some Estonian translations
        $line = preg_replace ("/ koondis:/", ":", $line);
        $line = preg_replace ("/puudus/", "none", $line);
        $line = preg_replace ("/Treener/", "Coach", $line);
        $line = preg_replace ("/Pealtvaatajaid/", "Att.", $line);
        $line = preg_replace ("/Peakohtunik/", "Referee", $line);
        $line = preg_replace ("/Väravad/", "Goal", $line);
        $line = preg_replace ("/Hoiatused/", "Book", $line);
        $line = preg_replace ("/Eemaldamine/", "Sent", $line);

        // " G. " is treated as "Goals:", so make sure that first name "G." is still a first name
        $line = preg_replace ("/(([0-9]+)( min\.)?|:|,) G\.\s+/", " $1 G.", $line);

        // "15 min. ir 16 min. R. Kudyte" replaced with "15, 16 R. Kudyte"
        $line = preg_replace ("/([0-9]+)( min\.)? ir ([0-9]+)( min\.)?/", " $1, $3", $line);

        return $line;
        }

    protected function postProcessSingleMatch (&$match, $stadium = NULL, &$collectedLines = NULL)
        {
        if (!empty ($stadium) && empty ($match["stadium"]))
            $match["stadium"] = $stadium;

        if (!empty ($collectedLines))
            {
            $match["sourceDetails"] = implode ("\n", $collectedLines);
            $collectedLines = NULL;
            }

        if (!empty ($match['homePlayers']) || !empty ($match['awayPlayers']))
            {
            foreach (array ("goal", "book", "sent", "miss") as $key)
                {
                if (empty ($match[$key]))
                    continue;
                foreach ($match[$key] as &$player)
                    {
                    if (array_key_exists ('home', $player))
                        continue;

                    foreach (array ("homePlayers", "awayPlayers") as $isHome)
                        {
                        if (empty ($match[$isHome]))
                            continue;
                        $found = $this->findTeamPlayer ($match[$isHome], $player["name"]);
                        if ($found)
                            {
                            $home = ("homePlayers" == $isHome);
                            if (!empty ($values["c_own"]))
                                $home = !$home;
                            $player['home'] = $home;
                            break;
                            }
                        }

                    if (!array_key_exists ('home', $player) && 'goal' != $key)
                        $this->addError ("Player ".$player["name"]." ($key) was not found in the player list");
                    }
                }
            }

        if (empty ($match['goal']))
            return $match;

        $result = !empty ($match['resultET']) ? $match['resultET'] : (!empty ($match['result']) ? $match['result'] : NULL);
        if (!empty ($result))
            {
            if ($result[0] + $result[1] != count ($match['goal']))
                {
                // sometimes goal count is included in brackets - "G. Scorer (5)", it might be misinterpreted
                $candidateForMisinterpretation = true;
                $newGoalCollection = array ();

                foreach ($match['goal'] as $goalEntry)
                    {
                    $alteredEntry = $goalEntry;
                    if (!empty ($goalEntry["min"]))
                        {
                        if ($goalEntry["min"] >= 10)
                            {
                            $candidateForMisinterpretation = false;
                            break;
                            }
                        $cnt = $goalEntry["min"];
                        unset ($alteredEntry["min"]);
                        for ($i = $cnt; $i > 0; $i--)
                            $newGoalCollection[] = $alteredEntry;
                        }
                    else
                        $newGoalCollection[] = $alteredEntry;
                    }
                if ($candidateForMisinterpretation)
                    $match['goal'] = $newGoalCollection;
                }

            if ($result[0] + $result[1] != count ($match['goal']))
                $this->logError ("Goal scorer count ".count ($match['goal'])." does not match the game result ".$result[0].":".$result[1]." (".$match['homeTeam']." - ".$match['awayTeam']."})");
            else
                {
                for ($i = 0; $i < count ($match['goal']); $i++)
                    {
                    if (!array_key_exists ('home', $match['goal'][$i]))
                        $match['goal'][$i]['home'] = $i < $result[0];
                    }
                }

            $calculatedHome = 0;
            $calculatedAway = 0;
            foreach ($match['goal'] as &$player)
                {
                if (!array_key_exists ('home', $player))
                    continue;
                if ($player['home'])
                    $calculatedHome++;
                else
                    $calculatedAway++;
                }

            $result = !empty ($match['resultET']) ? $match['resultET'] : (!empty ($match['result']) ? $match['result'] : NULL);
            if ($result[0] != $calculatedHome || $result[1] != $calculatedAway)
                $this->logError ("Goal home information incomplete - ".$this->getMatchLabel ($match));
            }

        return $match;
        }

    protected static function parseRomanNumber ($singleChar)
        {
        switch ($singleChar)
            {
            case 'M':
                return 1000;
            case 'D':
                return 500;
            case 'C':
                return 100;
            case 'L':
                return 50;
            case 'X':
                return 10;
            case 'V':
                return 5;
            case 'I':
                return 1;
            }
        return 0;
        }

    public static function parseRoundNumber ($round)
        {
        if (is_numeric ($round))
            return $round;

        $round = strtoupper ($round);
        $value = 0;
        for ($i=0; $i < strlen ($round); $i++)
            {
            $thisNumber = self::parseRomanNumber ($round[$i]);
            $nextNumber = 0;
            if ($i < strlen ($round) - 1)
                $nextNumber = self::parseRomanNumber ($round[$i+1]);
            if ($nextNumber > $thisNumber)
                $value -= $thisNumber;
            else
                $value += $thisNumber;
            }

        return $value;
        }

    protected function processSingleMatch ($year, $plainData, &$date, &$round, $treatTeamAs = 0)
        {
        $originalData = $plainData;

        $plainData = preg_replace ("/[–]/u", "-", $plainData);
        $plainData = preg_replace ("/([,;])[\\r\\n]{1,2}([0-9]{1,2}['`, ]|[A-ZŠČŽĄÄÖÜÕÅ]\.)/m", "$1 $2", $plainData);
        $plainData = preg_replace ("/\)[\\r\\n]{1,2}([0-9]{1,2}['`, ]|[A-ZŠČŽĄÄÖÜÕÅ]\.)/m", "), $1", $plainData);
        $plainData = preg_replace ("/[\\r\\n]{1,2}Rf\. /m", ". Rf. ", $plainData);
        $plainData = preg_replace ("/[\\r\\n]{1,2}\s+([0-9]+:[0-9]+ \([0-9]+:[0-9]+\))/m", " $1", $plainData);
        // if teams and result are in the different lines
        $plainData = preg_replace ("#([\\r\\n][0-9]+\.[^\\r\\n]+)[\\r\\n]{1,4}([0-9\-)(]+)[\\r\\n]{1,2}#m", "$1 $2", "\n".$plainData."\n");

        // if team players are given on separate lines
        $chars = "a-ząčęėįšųūžäöüõšžåíA-ZĄČĘĖĮŠŲŪŽÄÖÜÕŠŽÅÍ";
        $w = "[{$chars}][$chars\-]*[$chars]";
        $plainData = preg_replace ("#:[\\r\\n]+($w\s+$w(\s*\([0-9.]+\s+$w\s+$w\))?[\\r\\n])#mu", ": $1", $plainData);
        $original = NULL;
        while ($original != $plainData)
            {
            $original = $plainData;
            $plainData = preg_replace ("#[\\r\\n]+($w\s+$w(\s*\([0-9.]+\s+$w\s+$w\))?[\\r\\n])#mu", ", $1", $plainData, 1);
            }

        $lines = preg_split ("/[\n\r]+/", $plainData);
        $parsedGames = NULL;
        $match = NULL;
        $collectedLines = NULL;
        $parserCache = array ();
        $stadium = NULL;

        foreach ($lines as $line)
            {
            $line = trim ($line);
            if (empty ($line))
                continue;

            // check for round number
            if (preg_match ("/^(from )?Round ([0-9]+|\?|[XIV]+)$/i", $line, $roundMatch) > 0)
                {
                if ("?" == $roundMatch[2])
                    $round = NULL;
                else
                    $round = $this->parseRoundNumber ($roundMatch[2]);

                continue;
                }

            $originalLine = $line;
            $line = $this->preprocessMatchLine ($line);
            $dateMatch = NULL;
            $textualDateMatch = NULL;
            $monthNames = "(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)";
            if (preg_match ("/^[\[{]?($monthNames [0-9]+|[0-9]+ $monthNames)[\]}]?,?( ([1-2][0-9]{3}))?/", $line, $textualDateMatch) > 0 ||
                preg_match ("/^(([1-2][09][0-9][0-9])[.-])?(0[0-9]|1[0-2])[.-]([0-3][0-9])(.+)?$/", $line, $dateMatch) > 0 ||
                preg_match ("/^(([1-2][09][0-9][0-9]) )?(0[0-9]|1[0-2]) ([0-3][0-9])$/", $line, $dateMatch) ||
                preg_match ("/^(([0-2][0-9]|3[01]|[1-9])[.-]$monthNames)$/", $line, $textualDateMatch) > 0)
                {
                // flush the last match
                if (!empty ($match))
                    $parsedGames[] = $this->postProcessSingleMatch ($match, $stadium, $collectedLines);

                $collectedLines[] = trim ($originalLine);
                $match = NULL;
                $stadium = NULL;

                // parse the date
                if (!empty ($textualDateMatch))
                    {
                    if (!empty ($textualDateMatch[5]))
                        $year = $textualDateMatch[5];
                    $line = $textualDateMatch[1];
                    if (false !== strpos ($line, ","))
                        $line = substr ($line, 0, strpos ($line, ","));
                    $date = strtotime ($line." $year");
                    if (false === $date)
                        {
                        $this->logError ("Unrecognized date $line");
                        $date = "$year-00-00";
                        }
                    else
                        $date = strftime ("%Y-%m-%d", $date);
                    }
                else
                    {
                    $parsedYear = substr ($year, 0, 4);
                    if (!empty ($dateMatch[2]))
                        $parsedYear = $dateMatch[2];
                    $date = "$parsedYear-{$dateMatch[3]}-{$dateMatch[4]}";
                    
                    if (!empty ($dateMatch[5]) && preg_match ("/^([0-2][0-9]\:[0-5][05])( val\.)?\-?(.+)?$/", trim ($dateMatch[5]), $timeMatch) > 0)
                        {
                        $date .= " {$timeMatch[1]}:00";
                        $stadium = $timeMatch[3];
                        }
                    }
                continue;
                }

            if ("No bookings" == $line)
                {
                $collectedLines[] = trim ($originalLine);
                continue;
                }

            $parts = preg_split ("#( g\. | G\. | Goals: | Goal: )#", $line);
            if (1 == count ($parts))
                {
                $parts = preg_split ("/(Booke[td]\:|Missed pk\:|Sent\:|Sent [oO]ff\:)/", $line);
                if (count ($parts) > 1)
                    $parts = array ($parts[0], substr ($line, strlen ($parts[0])));

                if (empty ($parts[0]))
                    array_shift ($parts);
                }

            $header = $parts[0];

            $error = NULL;
            $nextMatch = $this->parseMatchHeader ($header, empty ($date) ? $year : $date, $round, $error, $treatTeamAs);
            if (false === $nextMatch)
                {
                if (empty ($match))
                    {
//var_dump ($error);
                    return $this->addError ($error);
                    }

                $collectedLines[] = trim ($originalLine);
                if (false === $this->processSingleMatchPart ($match, $parserCache, $header, true))
                    {
//var_dump ($error);
                    return $this->addError ($error);
                    }
                continue;
                }

            // next match is found
            if (!empty ($match))
                $parsedGames[] = $this->postProcessSingleMatch ($match, $stadium, $collectedLines);
            $match = $nextMatch;
            $collectedLines[] = trim ($originalLine);

            if (2 == count ($parts))
                {
                $goals = NULL;
                $additionalLines = $this->extractHeaderPartsAfterGoals (trim ($parts[1], " ."), $goals);
                $result = $match["result"];
                $home = NULL;
                if (0 == $result[0] || 0 == $result[1])
                    {
                    $home = $result[0] > 0;
                    }
                $players = $this->parseMatchPlayerEvents ($goals, $home, true, $match, true);
                if (false === $players)
                    {
var_dump ("players");
                    return false;
                    }

                $match["goal"] = $players;
                
                if (!empty ($additionalLines) && false === $this->processSingleMatchPart ($match, $parserCache, $additionalLines))
                    {
var_dump ("additionalLines");
                    return $this->logError ("cannot process single match part '$additionalLines'");
                    }
                }
            }

        if (!empty ($match))
            $parsedGames[] = $this->postProcessSingleMatch ($match, $stadium, $collectedLines);

        if (1 == count ($parsedGames))
            {
            // single game was found - use original text
            $parsedGames[0]["sourceDetails"] = trim (preg_replace ("/[\n\r]+/", "\n", $originalData));
            }
        
        return $parsedGames;
        }

    protected function processSingleMatchPart (&$match, &$parserCache, $line, $expectMultiplier = false)
        {
        // minutes in Estonian sites - "5. Öhman, 10., 68. Eklöf, 15. Österholm, 42., 80. Tanner"
        $line = preg_replace ("/([ (])([0-9]{1,2})\.([ ,])/", "$1$2 min.$3", $line);

        if (preg_match ("/^(.+)\. ((Booke[td]\:|Missed pk\:|Sent\:|Sent [oO]ff\:) (.+))( \(all ([A-Za-z]+)\))?$/U", $line, $matches) > 0)
            {
            $postfix = !empty ($matches[6]) ? " ({$matches[6]})" : "";
            if (false === $this->processSingleMatchPart ($match, $parserCache, $matches[2].$postfix, $expectMultiplier))
                {
                return false;
                }

            $line = $matches[1].$postfix;
            }

        if (preg_match ('/^([A-ZĖ]+) - (.+)$/ui', $line, $matches) > 0)
            $arr = array ($matches[1], $matches[2]);
        else
            $arr = explode (":", $line, 2);

        if (2 != count ($arr))
            {
            if (0 === strncmp ("Missed pk", $line, strlen ("Missed pk")))
                {
                $title = "miss";
                $content = substr ($line, strlen ("Missed pk"));
                }
            else if (preg_match ("#(stadionas|maniežas|aikštė|arena)$#uU", $line, $m) > 0)
                {
                $match["stadium"] = trim ($line);
                return true;
                }
            else
                return $this->logError ("Unrecognized line '$line'");
            }
        else
            list ($title, $content) = $arr;

        $title = utf8_strtolower (substr ($title, 0, 4));
        if ($title == "snt ")
            $title = "sent";

        if ($title == "goal" || $title == "book" || $title == "sent" || $title == "miss")
            {
            $home = NULL;
            if ($title == "goal" && !empty ($match["result"]) && $match["result"][0] != $match["result"][1] && (0 == $match["result"][0] || 0 == $match["result"][1]))
                $home = $match["result"][0] > $match["result"][1];

            $none = 0 == strcasecmp ("none", trim ($content)) || 0 == strcasecmp ("-", trim ($content));
            $content = $none ? NULL : $content;
            $players = $this->parseMatchPlayerEvents ($content, $home, $expectMultiplier, $match, $title == "goal");
            if (false === $players)
                return false;

            if (!empty ($players))
                $match[$title] = $players;
            }
        else if (preg_match ('/^refe?$/', $title, $matches) > 0)
            {
            if (preg_match ('/^(.+)\. Att\. ([0-9]+)$/', $content, $matches) > 0)
                {
                $content = $matches[1];
                $match["spectators"] = trim ($matches[2]);
                }

            $referees = explode (",", $content);
            $this->setMatchReferee ($match, self::MATCH_REFEREE, self::MATCH_REFEREE_CITY, $referees[0]);

            if (count ($referees) >= 2)
                $this->setMatchReferee ($match, "refereeA1", "refereeA1City", $referees[1]);
            if (count ($referees) >= 3)
                $this->setMatchReferee ($match, "refereeA2", "refereeA2City", $referees[2]);
            }
        else if ("subs" == $title && !empty ($parserCache["lastParsed"]))
            {
            $match[$parserCache["lastParsed"]] = array_merge ($match[$parserCache["lastParsed"]], $this->parseMatchSubstitutes ($content));
            }
        else if ("coac" == $title && !empty ($parserCache["lastParsed"]))
            {
            if ("none" != trim ($content))
                $match[substr ($parserCache["lastParsed"],0,4)."Coach"] = $content;
            }
        else if ("att." == $title)
            {
            $match[self::MATCH_SPECTATORS] = trim ($content);
            }
        else
            {
            $players = $this->parseTeamPlayers ($content);
            if (false === $players)
                return false;

            $isHome = $this->checkIfHomeByLabel ($match, $title);
            if (NULL !== $isHome)
                $parsedKey = $isHome ? "homePlayers" : "awayPlayers";
            else if (empty ($match["homePlayers"]))
                $parsedKey = "homePlayers";
            else if (empty ($match["awayPlayers"]))
                $parsedKey = "awayPlayers";
            else
                return $this->logError ("Unrecognized line - '$line'");

            $match[$parsedKey] = $players;
            $parserCache["lastParsed"] = $parsedKey;
            }

        return true;
        }

    protected function setMatchReferee (&$match, $key, $cityKey, $referee)
        {
        $referee = trim ($referee);
        if (preg_match ('/^(.+) \((.+)\)$/', $referee, $matches) > 0)
            {
            $match[$key] = trim ($matches[1]);
            $match[$cityKey] = trim ($matches[2]);
            }
        else
            $match[$key] = $referee;
        }

    protected function checkIfHomeByLabel ($match, $label)
        {
        if (empty ($match['homeTeam']) || empty ($match['awayTeam']))
            return NULL;

        if (preg_match ("#^[A-Z]\.(.+)$#u", $label, $matches) > 0)
            {
            $res = $this->checkIfHomeByLabel ($match, $matches[1]);
            if (NULL !== $res)
                return $res;
            }

        if (preg_match ("#^(.+)[ -](.+)$#", $label, $matches) > 0)
            {
            $res = $this->checkIfHomeByLabel ($match, $matches[1]);
            if (NULL !== $res)
                return $res;
            $res = $this->checkIfHomeByLabel ($match, $matches[2]);
            if (NULL !== $res)
                return $res;
            }

        $homeTeam = $match['homeTeam'];
        $awayTeam = $match['awayTeam'];
        $processed = false;
        if (strlen ($label) == 2 && $label == utf8_strtoupper ($label))
            {
            $pattern = "/^".$label[0].".+".$label[1]."/";
            $homePos = preg_match ($pattern, $homeTeam, $matches) > 0 ? 0 : NULL;
            $awayPos = preg_match ($pattern, $awayTeam, $matches) > 0 ? 0 : NULL;
            if (0 === $homePos || 0 === $awayPos)
                $processed = true;
            }

        if (!$processed)
            {
            $label = utf8_strtolower ($label);
            $homePos = strpos (utf8_strtolower ($homeTeam), $label);
            $awayPos = strpos (utf8_strtolower ($awayTeam), $label);
            }

        if (0 === $homePos && 0 !== $awayPos)
            return true;
        else if (0 === $awayPos && 0 !== $homePos)
            return false;
        else if ($homePos > 0 && false === $awayPos)
            return true;
        else if ($awayPos > 0 && false === $homePos)
            return false;
        return NULL;
        }

    protected function parseMatchHeaderShort ($line, $date, $round = NULL)
        {
        $match = array ();
        $match["date"] = isset ($date) ? $date : "";
        if (!empty ($round))
            $match["round"] = $round;
        
        $error = NULL;
        if (false === $this->parseMatchResult (trim ($line, ". "), $match, $error))
            return $this->logError ($error);

        return $match;
        }

    protected function parseMatchHeaderStadiumAndReferee (&$match, $line, $date, &$error)
        {
        $line = trim ($line, ". ");
        if ("?" == $line)
            return $match;

        if (is_numeric ($line))
            {
            $match["spectators"] = $line;
            return $match;
            }

        if (preg_match ('/^Rf\. ([^(]+) \((.+)\)\. (.+)[,.] Att\. ([0-9]{1,5})$/u', $line, $matches) > 0)
            {
            if (!empty ($matches[4]))
                $match["spectators"] = $matches[4];
            $match[self::MATCH_REFEREE] = trim ($matches[1]);
            $match[self::MATCH_REFEREE_CITY] = trim ($matches[2]);
            $match[self::MATCH_STADIUM] = trim ($matches[3]);
            return $match;
            }

        if (preg_match ('/^(.+)\. (Att. )?([0-9]{2,5})\.(.+) (\((.+)\))?$/uU', $line, $matches) > 0)
            {
            $match[self::MATCH_STADIUM] = trim ($matches[1]);
            $match["spectators"] = $matches[3];
            $match[self::MATCH_REFEREE] = trim ($matches[4]);
            $city = trim ($matches[6]);
            if (!empty ($city))
                $match[self::MATCH_REFEREE_CITY] = $city;
            return $match;
            }

        if (preg_match ('/^Rf\. ([^(]+)( \((.+)\))?([,.] Att\. ([0-9]{1,5}))?$/u', $line, $matches) > 0)
            {
            if (count ($matches) > 5)
                $match["spectators"] = $matches[5];
            $match[self::MATCH_REFEREE] = trim ($matches[1]);
            if (!empty ($matches[3]))
                $match[self::MATCH_REFEREE_CITY] = trim ($matches[3]);
            return $match;
            }

        preg_match ('/^([^(]+) \((.+)\)[,.] (.+)\. ([0-9]{1,5})$/u', $line, $matches);
        if (!empty ($matches))
            {
            $match[self::MATCH_STADIUM] = trim ($matches[3]);
            $match["spectators"] = $matches[4];
            $match[self::MATCH_REFEREE] = trim ($matches[1]);
            if (!empty ($matches[2]))
                $match[self::MATCH_REFEREE_CITY] = trim ($matches[2]);
            return $match;
            }

        preg_match ('/^Att\. ([0-9]{1,5})$/u', $line, $matches);

        if (2 == count ($matches))
            {
            $match["spectators"] = $matches[1];
            return $match;
            }

        if (preg_match ('/^([^()0-9]+)(\. ([0-9]{1,5}))?$/u', $line, $matches) > 0)
            {
            $match[self::MATCH_STADIUM] = trim ($matches[1]);
            if (!empty ($matches[3]))
                $match["spectators"] = $matches[3];
            return $match;
            }

        $refereeWithCityPattern = '([A-ZĄČĖŠŽÄÖÜÕÅ][a-z]*\.[^(]+)( \((.+)\))?';
        if (preg_match ("/^([^(]+)\. $refereeWithCityPattern$/u", $line, $matches) > 0)
            {
            $stadium = trim ($matches[1]);
            if (is_numeric ($stadium))
                $match[self::MATCH_SPECTATORS] = $stadium;
            else
                $match[self::MATCH_STADIUM] = $stadium;
            $match[self::MATCH_REFEREE] = trim ($matches[2]);
            if (!empty ($matches[4]))
                $match[self::MATCH_REFEREE_CITY] = trim ($matches[4]);
            return $match;
            }

        if (preg_match ("/^$refereeWithCityPattern. ([^(]+)$/u", $line, $matches) > 0)
            {
            $stadium = trim ($matches[4]);
            if (is_numeric ($stadium))
                $match[self::MATCH_SPECTATORS] = $stadium;
            else
                $match[self::MATCH_STADIUM] = $stadium;

            $match[self::MATCH_REFEREE] = trim ($matches[1]);
            if (!empty ($matches[3]))
                $match[self::MATCH_REFEREE_CITY] = trim ($matches[3]);
            return $match;
            }

        if (preg_match ("/^$refereeWithCityPattern$/u", $line, $matches) > 0)
            {
            $match[self::MATCH_REFEREE] = trim ($matches[1]);
            if (!empty ($matches[3]))
                $match[self::MATCH_REFEREE_CITY] = trim ($matches[3]);
            return $match;
            }

        if (preg_match ("/^([A-ZĄČĖŠŽÄÖÜÕÅ][a-z]*) \((.+)\)$/u", $line, $matches) > 0)
            {
            $match[self::MATCH_REFEREE] = trim ($matches[1]);
            $match[self::MATCH_REFEREE_CITY] = trim ($matches[2]);
            return $match;
            }

        $error = "Error parsing match '$line' ($date) referee and stadium";
        return false;
        }

    protected function parseMatchHeader ($line, $date, $round, &$error, $treatTeamAs = 0)
        {
        $match = array ();
        
        if (NULL !== $treatTeamAs)
            $match[self::TEAMFORMAT_FIELD] = $treatTeamAs;

        $hour = substr ($line, 0, 2);
        $min = substr ($line, 3, 2);
        $matchDate = isset ($date) ? $date : "";
        if (is_numeric ($hour) && is_numeric ($min))
            {
            $matchDate .= " $hour:$min";
            $line = trim (substr ($line, 5));
            }

        $match[self::MATCH_DATE] = $matchDate;
        if (!empty ($round))
            $match[self::MATCH_ROUND] = $round;
        
        $line = preg_replace ("/\.\s+Aggregate( [--])? [0-9]+[:-][0-9]+/", "", $line);

        $line = str_replace (". Aggregate", " Aggregate", $line);
        // replace "9:0 (5:0). (I - 0:0)." with "9:0 (5:0) Aggregate 0:0"
        $line = preg_replace ("/\. \(I - ([0-9]+[:-][0-9]+)\)\./", " Aggregate $1.", $line);
        // move extra time marker - "9:0 aet (5:0, 0:2)" to "9:0 (5:0, 0:2) aet"
        $line = preg_replace ("/([0-9]+[:-][0-9]+) aet \((([0-9:-]+|\, )+)\)/", "$1 ($2) aet", $line);
        // cup competition matches might have "(4-5 pk)" or "2:4 (pk)" in the result part
        $line = preg_replace ("/\. \(([0-9]+)[:-]([0-9]+) pk\)/", " (\\1:\\2 pk)", $line);
        $line = preg_replace ("/\. ([0-9]+)[:-]([0-9]+) \(pk\)/", " (\\1:\\2 pk)", $line);

        if (preg_match ("#(\(?(without|w/o) game\)?|\*?w/o game|[tT]echnical win|\(?Result ([0-9]+[:-][0-9]+ )?annuled\)?)#", trim ($line), $nMatch) > 0)
            {
            $match[self::MATCH_OUTCOME] = MatchConstants::OUTCOME_TECHNICAL_WIN;
            $line = trim (str_replace ($nMatch[0], ".", $line), " .");
            }

        $len = $this->parseMatchResult ($line, $match, $error);
        if (false === $len)
            return false;

        $line = trim (substr ($line, $len), " .");
        if (empty ($line))
            return $match;

        return $this->parseMatchHeaderStadiumAndReferee ($match, $line, $match[self::MATCH_DATE], $error);
        }

    public static function cleanTeamName ($name, $home, &$match = NULL)
        {
        if ($home && preg_match ('/^(Nr\.\s?([0-9]{1,4})\.?|([0-9]{1,4})\s*\.)\s*(.+)$/u', $name, $teamWithNumber) > 0)
            {
            $name = $teamWithNumber[4];
            if (!empty ($match))
                $match["number"] = empty ($teamWithNumber[2]) ? $teamWithNumber[3] : $teamWithNumber[2];
            }
        $name = trim ($name);
        $name = preg_replace ("/[“”„\"]/", "", $name);
        $name = preg_replace ("/([A-Za-z])[\-]\s*([A-Za-z])/", "$1-$2", $name);

        if (!empty ($match) && isset ($match[self::TEAMFORMAT_FIELD]))
            {
            switch ($match[self::TEAMFORMAT_FIELD])
                {
                case self::TEAMFORMAT_EXISTING:
                    if (preg_match ("#(.+)\s*\((.+)\)#", $name, $pregMatch) > 0)
                        {
                        $name1 = utf8_strtolower (trim ($pregMatch[1]));
                        $name2 = utf8_strtolower (trim ($pregMatch[2]));
                        if ($name1 == $name2)
                            $name = $name1;
                        }

                    $name .= " ".date ('Y');
                    
                    break;
                case self::TEAMFORMAT_RESERVES:
                    $name = trim (preg_replace ("#(.+)\s*\(.+\)#", "$1", $name))."-2";
                    $name .= " ".date ('Y');
                    break;
                }
            }

        return $name;
        }

    protected function parseMatchResult ($line, &$match, &$error)
        {
        preg_match ('/^((?U:.*)) [\-|–] ((?U:.*))\s+'           // [1],[2]       'TEAM1 - TEAM1'
                    .'([0-9\+\-]+)\s?[:-]\s?([0-9\+\-]+)[*]?'         // [3],[4]       result ('1:2' or '10-2*' or '+:-')
                    .'(\s*\('
                        .'([0-9]+)[:-]([0-9]+)'                 // [6],[7]       optionally, half time result ('1:2')
                        .'(\,?\s*([0-9]+)[:-]([0-9]+))?'        // [9],[10]      optionally, full time result ('2:2')
                    .'\))?'
                    .'(\s*aet[.;,]?)?'                             // [11]          optionally, extra time marker
                    .'(\.? Aggregate [0-9]+[\:-][0-9]+)?'       // [12]          optionally, 'Aggregate 2:3' (ignored)
                    .'\.?'
                    .'('
                        .' \(?([0-9]+)[\:-]([0-9]+) pk\)?'      // [14],[15]     optionally, '4:2 pk'
                        .'| pk ([0-9]+)[\:-]([0-9]+)'           // [17],[18]              or 'pk 4:2'
                    .')?'
                    .'/u', trim ($line), $matches);

        if (count ($matches) < 5)
            {
            if (preg_match ('/^(.*) ([0-9]+)[:\-–]([0-9]+)( \(([0-9]+)[:\-–]([0-9]+)\))? (.*)$/u', trim ($line), $matches) > 0)
                {
                $match["homeTeam"] = $this->cleanTeamName ($matches[1], true, $match);
                $match["awayTeam"] = $this->cleanTeamName ($matches[7], false, $match);
                $match["result"] = array ($matches[2], $matches[3]);
                if (!empty ($matches[4]))
                    $match["resultHalfTime"] = array ($matches[5], $matches[6]);
                return strlen ($matches[0]);
                }

            $error = "Error parsing match teams and result ('$line')";
            return false;
            }

        $match["homeTeam"] = $this->cleanTeamName ($matches[1], true, $match);
        $match["awayTeam"] = $this->cleanTeamName ($matches[2], false, $match);

        if (("+" == $matches[3] && "-" == $matches[4]) || ("W" == $matches[3] && "0" == $matches[4]))
            $match["c_outcome"] = MatchConstants::OUTCOME_NO_VISITORS;
        else if ("-" == $matches[3] && "+" == $matches[4])
            $match["c_outcome"] = MatchConstants::OUTCOME_NO_HOME_TEAM;
        else
            {
            $match["result"] = array ($matches[3], $matches[4]);

            if (count ($matches) > 11 && 0 == strcasecmp ("aet", trim ($matches[11], " .")))
                {
                $match["resultET"] = $match["result"];
                // if draw after extra time, by default leave full time result equal to ET result (it might be overwritten later) 
                if ($match["resultET"][0] != $match["resultET"][1])
                    unset ($match["result"]);
                }
            if (count ($matches) > 7 && "" !== $matches[6] && "" !== $matches[7])
                $match["resultHalfTime"] = array ($matches[6], $matches[7]);
            if (count ($matches) > 10 && "" !== $matches[9] && "" !== $matches[10])
                {
                if (empty ($match["resultET"]))
                    $match["resultET"] = $match["result"];
                $match["result"] = array ($matches[9], $matches[10]);
                if (!empty ($match["resultHalfTime"]) && ($match["result"][0] < $match["resultHalfTime"][0] || $match["result"][1] < $match["resultHalfTime"][1]))
                    {
                    $halfTime = $match["result"];
                    $match["result"] = $match["resultHalfTime"];
                    $match["resultHalfTime"] = $halfTime;
                    }
                }

            if (!empty ($matches[13]))
                {
                $match["resultPenalty"] = !empty ($matches[14]) ? array ($matches[14], $matches[15]) : array ($matches[16], $matches[17]);
                if ($match["resultPenalty"][0] > $match["resultPenalty"][1])
                    $match["c_outcome"] = MatchConstants::OUTCOME_PENALTIES_HOME;
                else if ($match["resultPenalty"][0] < $match["resultPenalty"][1])
                    $match["c_outcome"] = MatchConstants::OUTCOME_PENALTIES_AWAY;
                }
            }
        return strlen ($matches[0]);
        }

    protected function postProcessParsedEvents (&$match, $players, $parsingGoals, $labelIncluded = false)
        {
        if (!$parsingGoals)
            return $players;

        foreach ($players as &$player)
            {
            $fromLabel = $labelIncluded;
            if (!empty ($player['fromLabel']))
                {
                unset ($player['fromLabel']);
                $fromLabel = true;
                }

            if ($fromLabel && !empty ($player['og']))
                {
                $player['home'] = !$player['home'];
                }
            }

        return $players;
        }

    protected function parseMatchPlayerEvents ($line, $home = NULL, $expectMultiplier = false, &$match = NULL, $parsingGoals = false, $recursive = false)
        {
        $subpattern = "([^()]|\((pk|og|2nd|miss)\))+";
        $pattern = "/^("
                        ."($subpattern)"
                        ."\(([^()]+)\)"
                     .")([,;])("
                     ."(.+)"
                     .")$/u";
        if (preg_match ($pattern, trim ($line, " .;,"), $matches) > 0 &&
            !array_key_exists ($matches[5], $this->possibleModifiers) && !is_numeric ($matches[5]) &&
            0 === preg_match ("#\([0-9]+[-:][0-9]+\)#", $matches[0], $matchX))
            {
            $hardSeparator = NULL === $home && ";" == $matches[6];
            $homePlayers = $this->parseMatchPlayerEvents ($matches[1], $hardSeparator ? true : $home, $expectMultiplier, $match, $parsingGoals, true);
            $awayPlayers = $this->parseMatchPlayerEvents ($matches[7], $hardSeparator ? false : $home, $expectMultiplier, $match, $parsingGoals, true);
            return $this->postProcessParsedEvents ($match, array_merge ($homePlayers, $awayPlayers), $parsingGoals);
            }

        if (NULL === $home)
            {
            $arr = explode (";", trim ($line, " .;,"));
            if (count ($arr) == 2)
                {
                list ($homeList, $awayList) = $arr;
                $homePlayers = $this->parseMatchPlayerEvents ($homeList, true, $expectMultiplier, $match, $parsingGoals, true);
                $awayPlayers = $this->parseMatchPlayerEvents ($awayList, false, $expectMultiplier, $match, $parsingGoals, true);
                return $this->postProcessParsedEvents ($match, array_merge ($homePlayers, $awayPlayers), $parsingGoals);
                }
            }

        $homeInformationSpecified = NULL !== $home;
        $homeInformationFromLabel = false;
        $line = trim ($line, " .?");
        if (empty ($line))
            return array ();

        // preprocess lines like "R.Mazukelyte (8, 16, 55, 60, 66, 75), J.Lavrenovaite (19, 70, 89)"
        // by transforming them to the "8, 16, 55, 60, 66, 75 R.Mazukelyte, 19, 70, 89 J.Lavrenovaite"
        $line = preg_replace ('/([A-ZĄČĖŠŽ][^,;]+) \(((,?\s*([0-9]+([\- ]?(og|pk))?))+)\)/', '$2 $1', $line);
        $line = preg_replace ('/([0-9]) (og|pk)([, ])/', '$1 ($2)$3', $line);

        preg_match ('/\(([^()]+)\)$/u', $line, $matches);
        if (count ($matches) == 2 && !array_key_exists ($matches[1], $this->possibleModifiers)
            && 0 === preg_match ("#\([0-9]+[-:][0-9]+\)#", $matches[0], $matchX))
            {
            $line = substr ($line, 0, -strlen ($matches[0]));

            $isHome = $this->checkIfHomeByLabel ($match, $this->cleanTeamName ($matches[1], false));
            if (NULL !== $isHome)
                {
                $home = $isHome;
                $homeInformationFromLabel = true;
                }
            else if (strtolower ($matches[1]) == "home")
                $homeInformationFromLabel = $home = true;
            }

        // preprocess "." or ";" entered by mistake
        $line = preg_replace ('/[.;]\s*([0-9]+)/', ', $1', $line);
        $line = preg_replace ('/;/', ',', $line);

        if ($parsingGoals)
            $line = preg_replace ("/ ir /", ", ", $line);

        $list = explode (",", $line);
        $players = array ();
        $unusedTimes = array ();
        $homeInformationFound = NULL !== $home;
        $lastResult = array (0, 0);
        $indexesWithoutMultipliers = array ();

        foreach ($list as $item)
            {
            // preprocess "80-og" or "45pk" into "80 (og)" and "45 (pk)"
            $item = preg_replace ('/([0-9]+)\-?(og|pk)/', '$1 ($2)', $item);

            if (preg_match ("/^([0-9]+)( min\.)?( \((og|pk)\))?$/", trim ($item), $m) > 0)
                {
                $unusedEntry = array ('min' => $m[1]);
                if (!empty ($m[4]))
                    $unusedEntry[$m[4]] = true;
                $unusedTimes[] = $unusedEntry;
                continue;
                }

            $isHome = $home;
            // sometimes intermediate result is written just after the goal scorer, so use this information to set "ishome" flag
            if ($parsingGoals)
                {
                if (preg_match ('/^(.+)\s+\(?([0-9]{1,2})[:\-]([0-9]{1,2})\)?$/u', $item, $matches) > 0)
                    {
                    $item = $matches[1];
                    $resultHome = $matches[2];
                    $resultAway = $matches[3];
                    if ($resultHome > $lastResult[0] && $resultAway == $lastResult[1])
                        $isHome = true;
                    else if ($resultHome == $lastResult[0] && $resultAway > $lastResult[1])
                        $isHome = false;
                    else
                        $this->logError ("Intermediate result sequence broken");
                    $lastResult = array ($resultHome, $resultAway);
                    $homeInformationFound = true;
                    }
                }

            $player = $this->parsePlayer ($item, $isHome);
            $multiply = 1;
            if ($parsingGoals && !empty ($match) && !empty ($player["miss"]))
                {
                unset ($player["miss"]);
                $match["miss"][] = $player;
                continue;
                }

            if ($parsingGoals && $expectMultiplier)
                {
                if (preg_match ('/^(.+)\s?\-(\s?po)?\s?([0-9]+)$/u', $player["name"], $matches) > 0)
                    {
                    $player["name"] = trim ($matches[1]);
                    $multiply = $matches[3];
                    
                    // if "PlayerX, PlayerY - po 2" or "PlayerX, PlayerY - each 2" is found, apply multiplier to previous items
                    if ($multiply > 1 && !empty ($matches[2]))
                        {
                        for ($i = count ($indexesWithoutMultipliers) - 1; $i >= 0; $i--)
                            {
                            $index = $indexesWithoutMultipliers[$i];
                            $playerClones = array ();
                            for ($m = 1; $m < $multiply; $m++)
                                $playerClones[] = $players[$index];

                            $ending = NULL;
                            if ($index < count ($players) - 1)
                                {
                                $ending = array_slice ($players, $index + 1);
                                $players = array_slice ($players, 0, $index + 1);
                                }

                            $players = array_merge ($players, $playerClones);
                            if (!empty ($ending))
                                $players = array_merge ($players, $ending);
                            }
                        }

                    $indexesWithoutMultipliers = array ();
                    }
                else
                    $indexesWithoutMultipliers[] = count ($players);
                }

            foreach ($unusedTimes as $time)
                {
                $time['name'] = $player['name'];
                if (array_key_exists ('home', $player))
                    $time['home'] = $player['home'];
                $players[] = $time;
                }

            $unusedTimes = array ();

            for ($i = 0; $i < $multiply; $i++)
                $players[] = $player;
            }

        if (!empty ($unusedTimes))
            {
            foreach ($unusedTimes as $time)
                {
                $players[] = $time;
                }

            $this->logError ("Error parsing goals (unused goal times at '$line')");
            }

        if (!$recursive)
            return $this->postProcessParsedEvents ($match, $players, $parsingGoals, $homeInformationFromLabel);

        if ($parsingGoals && $homeInformationFromLabel)
            {
            foreach ($players as &$player)
                $player['fromLabel'] = true;
            }

        return $players;
        }

    const PLAYER_PATTERN = '/^([0-9]+)(\+[0-9]+)?([\'‘`’′]|\s*min\.)?(\s*\((.+)\))?\s+(([0-9]+\-)?([A-ZĄČĘĖĮŠŲŪŽÄÖÜÕŠŽÅ].+))(\s*\(.+\))?$/uU';
    protected $possibleModifiers = array ("pk" => "pk", "11 m." => "pk", "og" => "og", "!og" => "og", "2nd" => "yellow", "miss" => "miss");

    protected function applyPlayerModifier (&$player, $modifier)
        {
        if (empty ($modifier))
            return;
        if (array_key_exists ($modifier, $this->possibleModifiers))
            $player[$this->possibleModifiers[$modifier]] = true;
        else
            $this->logError ("Unrecognized goal modifier ('$modifier')");
        }

    protected function parsePlayer ($line, $home)
        {
        $player = array ();
        $line = trim ($line, " .;");

        preg_match (self::PLAYER_PATTERN, $line, $matches);
        if (count ($matches) > 2)
            {
            $player["min"] = $matches[1];
            $player["name"] = $matches[6];
            $modifier = $matches[5];
            if (empty ($modifier) && count ($matches) > 9)
                $modifier = trim ($matches[9], " ()");

            $this->applyPlayerModifier ($player, $modifier);
            if (!empty ($modifier) && $modifier[0] == "!" && NULL !== $home)
                $home = !$home;

            if (!empty ($matches[2]))
                {
                $player["extra"] = trim ($matches[2], "+");
                }
            }
        else if (preg_match ('/^([0-9]+)\s+(.*)$/uU', $line, $matches) > 0)
            {
            $player["min"] = $matches[1];
            $player["name"] = $matches[2];
            }
        else if (preg_match ('/^([^(]+)(\s*\((.+)\))$/uU', $line, $matches) > 0)
            {
            $player["name"] = $matches[1];
            $this->applyPlayerModifier ($player, $matches[3]);
            }
        else if (preg_match ('/^\((.+)\) (.+)$/uU', $line, $matches) > 0)
            {
            $player["name"] = $matches[2];
            $this->applyPlayerModifier ($player, $matches[1]);
            }
        else
            {
            $player["name"] = $line;
            }

        if (NULL !== $home)
            $player["home"] = $home;

        return $player;
        }

    protected function parseTeamPlayers ($line)
        {
        $initialLine = $line;
        $i = 0;
        while ($i++ < 100)
            {
            $line = preg_replace ('/\[[^\]]+\]/U', '', $initialLine);
            $line = preg_replace ('/\(([^)]+)\,(.+)\)/U', '($1|$2)', $line);
            $line = preg_replace ('/\s*\)\s*\(/U', ', ', $line);
            $line = preg_replace ('/\(([^)]+)\(/U', '($1, ', $line);
            if ($line == $initialLine)
                break;
            $initialLine = $line;
            }

        $line = str_replace ('))', ')', $line);
        $line = str_replace ('((', '(', $line);

        $list = explode (",", $line);

        $players = array ();
        foreach ($list as $item)
            {
            $item = str_replace ("|", ",", $item);
            $player = $this->parseTeamPlayer ($item);
            $this->collectPlayerNumbers ($player);
            $players[] = $player;
            }

        return $players;
        }

    protected function collectPlayerNumbers (&$player)
        {
        if (!empty ($player["name"]))
            {
            preg_match ('/^([0-9]+)\-(.+)$/uU', $player["name"], $matches);
            if (3 == count ($matches))
                {
                $player["name"] = $matches[2];
                $player["no"] = $matches[1];
                }
            }

        if (!empty ($player["substitute"]))
            $this->collectPlayerNumbers ($player["substitute"]);
        }

    protected function parseTeamPlayer ($line)
        {
        $player = array ();
        $line = trim ($line, " .");

        preg_match ('/^(.+)(\s*\((.+)\))?$/uU', $line, $matches);
        if (count ($matches) == 4)
            {
            $player["name"] = $matches[1];
            $substitutes = $this->parseMatchPlayerEvents ($matches[3]);
            $current = &$player;
            $current["from"] = 0;
            foreach ($substitutes as $subst)
                {
                if (empty ($subst["name"]))
                    $this->logError ("Unrecognized substitute ('$line')");
                else
                    {
                    if (!empty ($subst["min"]))
                        $current["to"] = $subst["min"];
                    $current["substitute"] = array ("name" => $subst["name"]);
                    $current = &$current["substitute"];
                    if (!empty ($subst["min"]))
                        $current["from"] = $subst["min"];
                    }
                }
            $current["to"] = 90;
            }
        else
            {
            $player["name"] = $line;
            $player["from"] = 0;
            $player["to"] = 90;
            }

        return $player;
        }

    protected function findDBTableColumn ($type, $columnName)
        {
        $dbtable = $this->dbtable;
        if ("person" == $columnName)
            {
            $dbtable = $this->refereetable;
            $columnName = "referee";
            }
        return $dbtable->findColumn ($columnName);
        }

    public function createSourceFields ()
        {
        parent::createSourceFields ();
        if (empty ($this->competitionField))
            {
            $seasonColumn = $this->dbtable->findColumn ("cstage");
            $this->competitionField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $seasonColumn);
            }
        if (empty ($this->roundField))
            {
            $roundColumn = $this->dbtable->findColumn ("round");
            $this->roundField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $roundColumn);
            }
        }

    public function retrieveHtml ($url)
        {
        $h = @fopen ($url, "r");
        if (empty ($h))
            return false;

        $response = "";
        while (!feof ($h))
            $response .= fread ($h, 8192);

        fclose ($h);
        return $response;
        }

    protected function processInputFields ($context, &$request)
        {
        $this->createSourceFields ();
        SportsHelper::$KnownSourceList[DBTable::COL_SOURCE] = $this->sourcesField->getValueForDB ($context, $request);
        parent::processInputFields ($context, $request);
        $this->competitionField->processInput ($context, $request);
        $this->roundField->processInput ($context, $request);
        }

    public function getParserFields ()
        {
        $this->createSourceFields ();
        
        if ($this->matchId > 0)
            return array (new LongTextFieldTemplate ("", "parse", $this->getText ("Results:"), $this->getText ("Enter results")));

        $format = new DropDownFieldTemplate ("", "format", $this->getText ("Format:"), $this->getText ("How matches should be parsed"),
                                             array (self::FORMAT_FULL => $this->getText ("Extended"),
                                                    self::FORMAT_NATIONAL => $this->getText ("National (pre 1940)"),
                                                    self::FORMAT_TABLE => $this->getText ("Table"),
                                                    self::FORMAT_SCHEDULE => $this->getText ("Schedule"),
                                                    ));
        $treatNamesAs = new DropDownFieldTemplate ("", self::TEAMFORMAT_FIELD, $this->getText ("Treat names as:"), $this->getText ("Hints how to correctly match parsed teams to database"),
                                             array (self::TEAMFORMAT_EXISTING => $this->getText ("Existing"),
                                                    self::TEAMFORMAT_ANY => $this->getText ("Any historical team"),
                                                    self::TEAMFORMAT_RESERVES => $this->getText ("Reserves"),
                                                    ));

        $arr = array
            (
            $this->competitionField,
            $this->roundField,
            new DateFieldTemplate ("", "year", $this->getText ("Year:"), $this->getText ("Enter match year")),
            $format,
            $treatNamesAs,
            new LongTextFieldTemplate ("", "parse", $this->getText ("Results:"), $this->getText ("Enter results")),
            new DropDownFieldTemplate ("", "excl", $this->getText ("Update if:"), "",
                                       array ("" => $this->getText ("All fields (match number, teams, date, etc)"),
                                              "c_number" => $this->getText ("Teams, date, round and match day match"),
                                              "round,c_no,c_number" => $this->getText ("Teams and date match"),
                                              "date,c_number" => $this->getText ("Teams and round match"),
                                              "X" => $this->getText ("Do not update"),
                                              )),
            );

        return $arr;
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $arr = $this->getParserFields ();

        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));

        if ($this->showSourceFields && !empty ($this->sourcesField))
            $arr[] = $this->sourcesField;
        if ($this->showSourceFields && !empty ($this->sourcesDateField))
            $arr[] = $this->sourcesDateField;
        return $arr;
        }

    }

function cutTextPiece (&$text, $startMarker, $endMarker = NULL, $alterText = false, $try = false)
    {
    $pos = strpos ($text, $startMarker);
    if (NULL !== $endMarker)
        {
        if ($pos + strlen ($startMarker) >= strlen ($text))
            $posEnd = false;
        else
            $posEnd = strpos ($text, $endMarker, $pos + strlen ($startMarker));
        }
    else
        $posEnd = strlen ($text);

    if (false === $pos || false === $posEnd)
        {
        if (!$try)
            print "Cannot parse given URL content (". htmlspecialchars ("$startMarker ... $endMarker").")<br>\n";
        return false;
        }

    $pos += strlen ($startMarker);
    $result = trim (substr ($text, $pos, $posEnd - $pos));
    if ($alterText)
        $text = substr ($text, $posEnd + strlen ($endMarker));
    return $result;
    }


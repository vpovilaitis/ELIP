<?php
require_once (PATH.'pages/submit.php');
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'inc/sports/common.php');
require_once (PATH.'pages/sports/teamview.php');

/*
After changing anything please run automated tests:
    http://localhost/index.php?c=tools/AutomatedTests&test=GenerateAnnouncementTests
*/
class GenerateMatchAnnouncement extends Submit
    {
    protected $dbtable;
    protected $teamsTable;
    protected $competitionsTable;
    protected $output = array ();
    protected $lng;
    protected $competitionLabels = array ();
    protected $leagueLabels = array ();
    protected $stadiumLabels = array ();

    protected $matchField = NULL;
    protected $team1Field = NULL;
    protected $team2Field = NULL;
    
    public function __construct ($context, $request)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $this->teamsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        $this->competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);

        if (empty ($this->dbtable) || empty ($this->teamsTable) || empty ($this->competitionsTable))
            {
            $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            $this->allTablesLoaded = false;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        $context->addScriptFile ("autosuggest");
        $context->addStyleSheet ("sports");
        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        $this->lng = Language::getInstance ($this->context);
        }

    public function ensureTitle ($context, &$request)
        {
        $title = $this->getText ("Generate match announcement text");
        $context->setTitle ($title);
        return true;
        }

    protected function processInputFields ($context, &$request)
        {
        parent::processInputFields ($context, $request);
        $this->createSourceFields ();
        $this->matchField->processInput ($context, $request);
        $this->team1Field->processInput ($context, $request);
        $this->team2Field->processInput ($context, $request);
        }

    public function createSourceFields ()
        {
        parent::createSourceFields ();
        if (empty ($this->matchField))
            $this->matchField = new RelationAutocompleteField ("", $this->dbtable, "match", "Match id:", $this->getText ("Enter id of the existing match"), true);

        if (empty ($this->team1Field))
            {
            $column = clone $this->dbtable->findColumn ("hometeam");
            $column->label = "Team 1";
            $this->team1Field = RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
            }

        if (empty ($this->team2Field))
            {
            $column = clone $this->dbtable->findColumn ("awayteam");
            $column->label = "Team 2";
            $this->team2Field = RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
            }
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();
        $arr[] = $this->matchField;
        $arr[] = new LabelTemplate ($this->getText ("Or, optionally enter both teams:"), "----");

        $arr[] = $this->team1Field;
        $arr[] = $this->team2Field;
        $arr[] = new IntFieldTemplate ("", "includeResults", $this->getText ("Show last games:"), $this->getText ("Count of last games to show."));
        $arr[] = new CheckBoxFieldTemplate ("", "rawFormat", $this->getText ("Raw format:"), $this->getText ("Show unformatted text to be pasted as a news item."));
        $arr[] = new CheckBoxFieldTemplate ("", "preSeason", $this->getText ("Preseason totals:"), $this->getText ("Show pre-season game totals."));
        $arr[] = new CheckBoxFieldTemplate ("", "players", $this->getText ("Show players:"), $this->getText ("Show registered player statistics."));
        $arr[] = new CheckBoxFieldTemplate ("", "unofficial", $this->getText ("Unofficial?"), $this->getText ("Include unofficial competitions' games."));
        $arr[] = new IntFieldTemplate ("", "dismissAfter", $this->getText ("Dismiss after:"), $this->getText ("Do not count match results if there is a gap greater than defined number of years."));
        return $arr;
        }

    public function collectInputData ($context, &$request)
        {
        $input = array ("includeResults" => $request["includeResults"],
                        "preSeason" => !empty ($request["preSeason"]),
                        "dismissAfter" => $request["dismissAfter"],
                        "unofficial" => !empty ($request["unofficial"]));
        $this->rawFormat = !empty ($request["rawFormat"]);
        if (!empty ($request["match"]))
            return array_merge ($input, array ("match" => $request["match"], "players" => !empty ($request["players"])));

        if (empty ($request["hometeam"]) || empty ($request["awayteam"]))
            return array ();
        return array_merge ($input, array ("team1" => $request["hometeam"], "team2" => $request["awayteam"]));
        }

    public function validateInput ($context, &$input)
        {
        return !empty ($input);
        }

    public function generateAnnouncementForMatch ($context, $matchId, $includeResults, $includePreseason, $includePlayers, $dismissAfter = 0, $unofficial = false)
        {
        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, $this->competitionsTable->getIdColumn ());
        $stadiumIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STADIUM, Sports::TABLE_STADIUM."_id");

        // select the requested match to retrieve team ids, labels, competition, date and stadium
        $columns = array (Sports::COL_MATCH_HOMETEAM.".c_".Sports::COL_TEAM_SHORTNAME,
                          Sports::COL_MATCH_AWAYTEAM.".c_".Sports::COL_TEAM_SHORTNAME,
                          Sports::COL_MATCH_DATE, Sports::COL_MATCH_COMPETITION,
                          Sports::COL_MATCH_STADIUM);
        $criteria[] = new EqCriterion ($this->dbtable->getIdColumn (), $matchId);
        $row = $this->dbtable->selectSingleBy ($columns, $criteria);
        if (empty ($row))
            return false;

        $homeTeamId = $row[Sports::COL_MATCH_HOMETEAM][0];
        $awayTeamId = $row[Sports::COL_MATCH_AWAYTEAM][0];
        SportsHelper::cacheTeamLabel ($homeTeamId, $row[Sports::COL_MATCH_HOMETEAM.".c_".Sports::COL_TEAM_SHORTNAME]);
        SportsHelper::cacheTeamLabel ($awayTeamId, $row[Sports::COL_MATCH_AWAYTEAM.".c_".Sports::COL_TEAM_SHORTNAME]);
        $homeTeam = $this->getTeamLabel ($homeTeamId);
        $awayTeam = $this->getTeamLabel ($awayTeamId);

        $date = $this->lng->dateToLongString ($row["c_".Sports::COL_MATCH_DATE]);
        $preseasonStartDate = $includePreseason ? substr ($date, 0, 4)."-01-01 00:00:00" : NULL;
        $dateCriterion = new LtCriterion ("c_".Sports::COL_MATCH_DATE, $row["c_".Sports::COL_MATCH_DATE]);
        $competitionId = $row[$competitionIdColumn];
        $competition = $row[Sports::COL_MATCH_COMPETITION.".c_".Sports::COL_COMPETITION_NAME];
        
        // generate first statement to print
        $teams = array ($homeTeamId, $homeTeam, $awayTeamId, $awayTeam);

        $stadiumId = $row[$stadiumIdColumn];
        $stadium = $row[Sports::COL_MATCH_STADIUM.".".ContentTable::COL_DISPLAY_NAME];

        $initialStatement = $this->getMatchAnnouncementStatement ($context, $date, $teams, $competition, $competitionId, $stadium, $stadiumId);
        $initialStatement = $this->getText ("<b>[_1]-[_3]</b>\n\n", $teams).$initialStatement;
        $this->output = array ($initialStatement);

        return $this->generateTeamAnalysis ($context, $homeTeamId, $awayTeamId, $includeResults, $dismissAfter, $unofficial, $preseasonStartDate, $dateCriterion, $competitionId, $stadiumId, $includePlayers);
        }

    protected function getMatchAnnouncementStatement ($context, $date, $teams, $competition, $competitionId, $stadium, $stadiumId)
        {
        $params = $teams;
        array_push ($params, $date, Sports::TABLE_STADIUM.":$stadiumId", $stadium, "{$this->competitionsTable->getName ()}:$competitionId", $competition);

        $params[0] = $this->teamsTable->getName ().":".$params[0];
        $params[2] = $this->teamsTable->getName ().":".$params[2];

        if (!empty ($stadium))
            {
            if (empty ($competition))
                return $this->getText ("On [_4] a friendly game is planned between [[[_0]|[_1]]] and [[[_2]|[_3]]] in the [[[_5]|[_6]]].|match announcement", $params);
            else
                return $this->getText ("On [_4] a [[[_7]|[_8]]] game is planned between [[[_0]|[_1]]] and [[[_2]|[_3]]] in the [[[_5]|[_6]]].|match announcement", $params);
            }
        else if (empty ($competition))
            return $this->getText ("On [_4] a friendly game is planned between [[[_0]|[_1]]] and [[[_2]|[_3]]].|match announcement", $params);
        else
            return $this->getText ("On [_4] a [[[_7]|[_8]]] game is planned between [[[_0]|[_1]]] and [[[_2]|[_3]]].|match announcement", $params);
        }

    public function generateTeamAnalysis ($context, $homeTeamId, $awayTeamId, $includeResults, $dismissAfter, $unofficial, $preseasonStartDate, $dateCriterion = NULL, $competitionId = NULL, $stadiumId = NULL, $includePlayers = false)
        {
        if ($dismissAfter <= 0)
            $dismissAfter = 5;

        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, $this->competitionsTable->getIdColumn ());
        $stadiumIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STADIUM, Sports::TABLE_STADIUM."_id");

        $homeTeamIds = $this->getPredecessorTeamIds ($homeTeamId);
        $awayTeamIds = $this->getPredecessorTeamIds ($awayTeamId);

        // select last N games between those same teams
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn ());
        $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $this->teamsTable->getIdColumn ());
        $columns = array ($this->dbtable->getIdColumn (), $homeTeamIdColumn, $awayTeamIdColumn,
                          Sports::COL_MATCH_DATE, $competitionIdColumn,
                          Sports::COL_MATCH_STADIUM, Sports::COL_MATCH_RESULT,
                          Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT);
        $criteria = array ();
        $criteria[] = new LogicalOperatorOr
                            (
                            new LogicalOperatorAnd
                                (
                                new InCriterion ($homeTeamIdColumn, $homeTeamIds),
                                new InCriterion ($awayTeamIdColumn, $awayTeamIds)
                                ),
                            new LogicalOperatorAnd
                                (
                                new InCriterion ($homeTeamIdColumn, $awayTeamIds),
                                new InCriterion ($awayTeamIdColumn, $homeTeamIds)
                                )
                            );
        if (!empty ($dateCriterion))
            $criteria[] = $dateCriterion;

        $params = array ();
        $params[] = OrderBy::create (Sports::COL_MATCH_DATE, false);
        $joins = NULL;

        if (!$unofficial)
            {
            $competitionsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
            $competitionColumn = "f_".Sports::COL_MATCH_COMPETITION."_".$competitionsTable->getIdColumn ();
            $competitionsCriteria[] = new JoinColumnsCriterion ($competitionColumn, $competitionsTable->getIdColumn ());
            $competitionsCriteria[] = new NotEqCriterion (Sports::COL_COMPETITION_UNOFFICIAL, 1);
            $competitionColumns[] = new ConditionalResultColumn ("official", $competitionsTable->getIdColumn ()." IS NULL", 0, 1);
            $competitionJoin = $competitionsTable->createQuery (array (), $competitionsCriteria);
            $competitionJoin->joinType = Constants::JOIN_LEFT_OUTER;
            $joins[] = $competitionJoin;
            }

        $rows = $this->dbtable->selectBy ($columns, $criteria, $joins);
        if (!empty ($rows))
            {
            for ($i = 0; $i < count($rows) && $i < $includeResults; $i++)
                {
                $row = $rows[count($rows)-$i-1];
                $competition = NULL;
                if (!empty ($row[$competitionIdColumn]))
                    $competition = $this->getCompetitionLabel ($row[$competitionIdColumn]);
                $this->output[] = "\n* ".$this->getLastGameOutcome ($row, $homeTeamIds, $homeTeamIdColumn, $awayTeamIdColumn, $competition);
                }

            $totalGameCount = 0;
            $totals = $this->getTotalGamesDescription ($rows, $homeTeamIds, $totalGameCount, $dismissAfter);
            if (!empty ($totals))
                {
                $this->output[] = "";
                $this->output = array_merge ($this->output, $totals);
                }

            if (!empty ($competitionId))
                {
                $filteredGameCount = 0;
                $competitionTotals = $this->getTotalGamesDescription ($rows, $homeTeamIds, $filteredGameCount, $dismissAfter, $competitionIdColumn, $competitionId);
                if (!empty ($competitionTotals) && $filteredGameCount != $totalGameCount)
                    {
                    $this->output[] = "\n".$this->getText ("Statistics of the games played in the [_0]:|competition", $this->getCompetitionLabel ($competitionId));
                    $this->output = array_merge ($this->output, $competitionTotals);
                    }
                }

            if (!empty ($stadiumId))
                {
                $filteredGameCount = 0;
                $stadiumTotals = $this->getTotalGamesDescription ($rows, $homeTeamIds, $filteredGameCount, $dismissAfter, $stadiumIdColumn, $stadiumId);
                if (!empty ($stadiumTotals) && $filteredGameCount != $totalGameCount)
                    {
                    $this->output[] = "\n".$this->getText ("Statistics of the games played in the [_0]:|stadium", $this->getStadiumLabel ($stadiumId));
                    $this->output = array_merge ($this->output, $stadiumTotals);
                    }
                }
            // now filter rows by stadium/competition to collect stadium and competition statistics (if there is something to filter)
            }
        
        if (!empty ($competitionId))
            {
            $competitionIds = $this->getSimilarCompetitionIds ($competitionId);
            $this->generateCompetitionStreakAnalysis ($context, $homeTeamId, $homeTeamIds, $competitionId, $competitionIds, $dateCriterion);
            $this->generateCompetitionStreakAnalysis ($context, $homeTeamId, $homeTeamIds, $competitionId, $competitionIds, $dateCriterion, true);
            $this->generateCompetitionStreakAnalysis ($context, $awayTeamId, $awayTeamIds, $competitionId, $competitionIds, $dateCriterion);
            $this->generateCompetitionStreakAnalysis ($context, $awayTeamId, $awayTeamIds, $competitionId, $competitionIds, $dateCriterion, false);
            }

        if (!empty ($preseasonStartDate))
            {
            $this->generateRecentMatchAnalysis ($context, $homeTeamId, $preseasonStartDate, $dateCriterion);
            $this->generateRecentMatchAnalysis ($context, $awayTeamId, $preseasonStartDate, $dateCriterion);
            }

        if ($includePlayers)
            {
            $this->generateTeamPlayerAnalysis ($context, $homeTeamId, $competitionId, $dateCriterion, $this->getText ("Home team players:"));
            $this->generateTeamPlayerAnalysis ($context, $awayTeamId, $competitionId, $dateCriterion, $this->getText ("Visiting team players:"));
            }
        /* additionaly might include interesting facts:
            * Team X are unbeaten in their last four matches against Team Y in all competitions, winning three. 
            * Team X have not won in their last 15 league visits to Sportima stadium dating back to August 1963. It is over 55 years since TeamX last won a top-flight match at Sportima
            * Team Y are unbeaten in their last 13 home league matches since a 3-1 defeat by Team Z in April 2009. If they avoid defeat it will be their longest unbeaten top-flight run since an 14-match streak ended in September 1981
            * Team Y have scored in their last 5 league matches at the Sportima Stadium. If they score against Team Y it will be their longest goal-scoring run since 1958
            * Team X have won just one of their last six league games 
            * Team X have scored 19 league goals this season - only Team Z had managed fewer prior to this weekend's fixtures
            * Leading goalscorers of each team
            * Team Y have taken 13 points from their last five games, with Peter Peterson scoring seven goals in those matches. 
            * LAST LEAGUE MATCH LINE-UPS
        */
        return true;
        }

    protected function selectMatches ($context, $criteria, $startAt = 0, $limit = 20, $count = false, $teamIds = NULL)
        {
        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, $this->competitionsTable->getIdColumn ());
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn ());
        $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $this->teamsTable->getIdColumn ());
        
        $params = array ();
        if ($count)
            {
            $columns = array ();
            $teamIdsString = implode (",", $teamIds);
            $columns[] = new ConditionalSumColumn ("cnt", "c_".Sports::COL_MATCH_HOMERESULT." is NULL", 0, 1);
            $columns[] = new ConditionalSumColumn ("scored", "$homeTeamIdColumn in ($teamIdsString)", "c_".Sports::COL_MATCH_HOMERESULT, "c_".Sports::COL_MATCH_AWAYRESULT);
            $columns[] = new ConditionalSumColumn ("conceded", "$homeTeamIdColumn in ($teamIdsString)", "c_".Sports::COL_MATCH_AWAYRESULT, "c_".Sports::COL_MATCH_HOMERESULT);
            }
        else
            {
            $columns = array ($this->dbtable->getIdColumn (), $homeTeamIdColumn, $awayTeamIdColumn,
                              Sports::COL_MATCH_DATE, $competitionIdColumn,
                              Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT);
            $params[] = OrderBy::create ("c_".Sports::COL_MATCH_DATE, false);
            $params[] = new LimitResults ($startAt, $startAt + $limit);
            $criteria[] = new IsNotNullCriterion ("c_".Sports::COL_MATCH_HOMERESULT);
            }

        $criteria[] = new InCriterion ("c_".Sports::COL_MATCH_OUTCOME,
                               array (MatchConstants::OUTCOME_NOT_STARTED, MatchConstants::OUTCOME_FULL_TIME,
                                      MatchConstants::OUTCOME_EXTRA_TIME, MatchConstants::OUTCOME_PENALTIES,
                                      MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                      MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $criteria[] = new LogicalOperatorOr (new EqCriterion ("c_".Sports::COL_MATCH_EXCLUDED, 0), new IsNullCriterion ("c_".Sports::COL_MATCH_EXCLUDED));

        return $this->dbtable->selectBy ($columns, $criteria, NULL, $params);
        }

    protected function calculateCompetitionStreak ($context, $teamIds, $criteria, &$gameList, $limit, $predicate, $treshold, $resumeAt = 0)
        {
        $gameCount = count ($gameList);
        if ($resumeAt == $gameCount)
            {
            $additionalRows = ($gameCount % $limit != 0) ? NULL : $this->selectMatches ($context, $criteria, $gameCount, $limit);
            if (empty ($additionalRows))
                return $resumeAt;
            $gameList = array_merge ($gameList, $additionalRows);
            $gameCount = count ($gameList);
            }

        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn ());

        for ($i = $resumeAt; $i < $gameCount; $i++)
            {
            $row = $gameList[$i];
            $result = array ($row["c_".Sports::COL_MATCH_HOMERESULT], $row["c_".Sports::COL_MATCH_AWAYRESULT]);
            $gameHomeTeamId = $row[$homeTeamIdColumn];
            if (false === array_search ($gameHomeTeamId, $teamIds))
                $result = array ($result[1], $result[0]);
            
            if (!$predicate ($result))
                return $i >= $treshold ? $i : 0;
            }
        
        if ($gameCount % $limit != 0)
            return $gameCount >= $treshold ? $gameCount : 0;

        return $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $gameList, $limit, $predicate, $treshold, $gameCount);
        }

    protected function generateCompetitionStreakAnalysis ($context, $teamId, $teamIds, $competitionId, $competitionIds, $dateCriterion, $filterByHome = NULL, $limit = 20)
        {
        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, $this->competitionsTable->getIdColumn ());
        $stadiumIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STADIUM, Sports::TABLE_STADIUM."_id");
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn ());
        $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $this->teamsTable->getIdColumn ());
        $criteria = array ();
        if (true === $filterByHome)
            $criteria[] = new InCriterion ($homeTeamIdColumn, $teamIds);
        else if (false === $filterByHome)
            $criteria[] = new InCriterion ($awayTeamIdColumn, $teamIds);
        else
            $criteria[] = new LogicalOperatorOr
                            (
                            new InCriterion ($homeTeamIdColumn, $teamIds),
                            new InCriterion ($awayTeamIdColumn, $teamIds)
                            );
        if (!empty ($dateCriterion))
            $criteria[] = $dateCriterion;

        $criteria[] = new InCriterion ($competitionIdColumn, $competitionIds);

        $teamLabel = $this->getTeamLabel ($teamId);
        $teamIdPrefix = "{$this->teamsTable->getName ()}:$teamId";
        $competitionLabel = $this->getCompetitionLabel ($competitionId);
        $showDateAfter = 10;

        $totals = $this->selectMatches ($context, $criteria, 0, NULL, true, $teamIds);
        $totalGames = $totals[0]["cnt"];
        $totalGoals = $totals[0]["scored"];
        $totalConceded = $totals[0]["conceded"];
        $statements = array ();
        if ($totalGames > 0)
            {
            if (NULL === $filterByHome)
                $statements[] = $this->ngettext ("played [_0] game", "played [_0] games", $totalGames);
            else if ($filterByHome)
                $statements[] = $this->ngettext ("played [_0] home game", "played [_0] home games", $totalGames);
            else
                $statements[] = $this->ngettext ("played [_0] away game", "played [_0] away games", $totalGames);

            $goals = $totalGoals % 500;
            $important = (0 == $goals || $goals > 495);
            if ($totalGoals > 0 && (NULL === $filterByHome || $important))
                $statements[] = ($important ? "<b>" : "").$this->ngettext ("scored [_0] goal", "scored [_0] goals", $totalGoals).($important ? "</b>" : "");

            $goals = $totalConceded % 500;
            $important = (0 == $goals || $goals > 495);
            if ($totalConceded > 0 && (NULL === $filterByHome || $important))
                $statements[] = $this->ngettext ("conceded [_0] goal", "conceded [_0] goals", $totalConceded);
            }

        $initial = count ($statements);
        
        $homePrefix = NULL === $filterByHome ? "" : ($filterByHome ? $this->context->getText ("home") : $this->context->getText ("away"))." ";

        $rows = array ();
        $winStreak = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                        function ($result) { return $result[0] > $result[1]; },
                                                        2);
        if ($winStreak > 0)
            {
            $statement = $this->context->ngettext ("won [_0] last [_1]game", "won [_0] last [_1]games", $winStreak, $homePrefix);
            if ($winStreak > $showDateAfter && $winStreak < count ($rows))
                $statement .= $this->getText (" (from [_0])", $this->lng->dateToLongString ($rows[$winStreak]["c_".Sports::COL_MATCH_DATE], "day"));
            $statements[] = $statement;
            }

        $lostStreak = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[0] < $result[1]; },
                                                     2);
        if ($lostStreak > 0)
            {
            $statement = $this->context->ngettext ("lost [_0] last [_1]game", "lost [_0] last [_1]games", $lostStreak, $homePrefix);
            if ($lostStreak > $showDateAfter && $lostStreak < count ($rows))
                $statement .= $this->getText (" (from [_0])", $this->lng->dateToLongString ($rows[$lostStreak]["c_".Sports::COL_MATCH_DATE], "day"));
            $statements[] = $statement;
            }

        $drawStreak = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[0] == $result[1]; },
                                                     2);
        if ($drawStreak > 0)
            $statements[] = $this->context->ngettext ("drew [_0] last [_1]game", "drew [_0] last [_1]games", $drawStreak, $homePrefix);

        $streak = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[0] >= $result[1]; },
                                                     3);
        if ($streak > $winStreak && $streak > $drawStreak)
            {
            $statement = $this->context->ngettext ("did not loose in the [_0] last [_1]game",
                                                   "did not loose in the [_0] last [_1]games", $streak, $homePrefix);
            if ($streak > $showDateAfter && $streak < count ($rows))
                $statement .= $this->getText (" (from [_0])", $this->lng->dateToLongString ($rows[$streak]["c_".Sports::COL_MATCH_DATE], "day"));
            $statements[] = $statement;
            }

        $streak = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[0] <= $result[1]; },
                                                     3);
        if ($streak > $lostStreak && $streak > $drawStreak)
            {
            if ($streak == $totalGames)
                $statement = $this->context->getText ("did not win in any game");
            else
                $statement = $this->context->ngettext ("did not win in the [_0] last [_1]game",
                                                       "did not win in the [_0] last [_1]games", $streak, $homePrefix);
            if ($streak > $showDateAfter && $streak < count ($rows))
                $statement .= $this->getText (" (from [_0])", $this->lng->dateToLongString ($rows[$streak]["c_".Sports::COL_MATCH_DATE], "day"));
            $statements[] = $statement;
            }

        $streak2 = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[0] > 2; },
                                                     2);
        if ($streak2 > 0)
            {
            $statements[] = $this->context->ngettext ("scored more than 2 goals in the [_0] last [_1]game",
                                                      "scored more than 2 goals in the [_0] last [_1]games", $streak2, $homePrefix);
            }

        $streak1 = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[0] > 1; },
                                                     2);
        if ($streak1 > $streak2)
            {
            $statements[] = $this->context->ngettext ("scored more than 1 goal in the [_0] last [_1]game",
                                                      "scored more than 1 goal in the [_0] last [_1]games", $streak1, $homePrefix);
            }

        $streak = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[0] > 0; },
                                                     5);
        if ($streak > $streak1)
            {
            $statements[] = $this->context->ngettext ("scored at least one goal in the [_0] last [_1]game",
                                                      "scored at least one goal in the [_0] last [_1]games", $streak, $homePrefix);
            }

        $streak = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[1] > 0; },
                                                     5);
        if ($streak > 0)
            {
            $statements[] = $this->context->ngettext ("conceded at least one goal in the [_0] last [_1]game",
                                                      "conceded at least one goal in the [_0] last [_1]games", $streak, $homePrefix);
            }

        $noScoreStreak = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[0] == 0; },
                                                     2);
        if ($noScoreStreak > 0)
            {
            $statements[] = $this->context->ngettext ("did not scored a goal in the [_0] last [_1]game",
                                                      "did not score a goal in the [_0] last [_1]games", $noScoreStreak, $homePrefix);
            }

        $streak = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[0] <= 1; },
                                                     5);
        if ($streak > 0 && $noScoreStreak != $streak)
            {
            $statements[] = $this->context->ngettext ("did not score more than 1 goal in the [_0] last [_1]game",
                                                      "did not score more than 1 goal in the [_0] last [_1]games", $streak, $homePrefix);
            }

        $noConcedeStreak = $this->calculateCompetitionStreak ($context, $teamIds, $criteria, $rows, 25,
                                                     function ($result) { return $result[1] == 0; },
                                                     2);
        if ($noConcedeStreak > 0)
            {
            $statements[] = $this->context->ngettext ("did not concede in the [_0] last [_1]game",
                                                      "did not concede in the [_0] last [_1]games", $noConcedeStreak, $homePrefix);
            }

        if (NULL !== $filterByHome && $initial === count ($statements))
            return;

        if (!empty ($statements))
            {
            // exception for lithuanian
            foreach ($statements as $statement)
                $statement = str_replace ("ne nam� rungtyn�se", "i�vykose", $statement);

            if (NULL === $filterByHome)
                $this->output[] = "\n".$this->getText ("In the [_0] [[[_1]|[_2]]] [_3].", $competitionLabel, $teamIdPrefix, $teamLabel, implode (", ", $statements));
            else
                $this->output[] = "\n".$this->getText ("In this competition team [_3].", $competitionLabel, $teamIdPrefix, $teamLabel, implode (", ", $statements));
            }
        }

    public function generateRecentMatchAnalysis ($context, $teamId, $preseasonStartDate, $dateCriterion = NULL)
        {
        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, $this->competitionsTable->getIdColumn ());
        $stadiumIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STADIUM, Sports::TABLE_STADIUM."_id");

        // select games played by this team this year
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn ());
        $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $this->teamsTable->getIdColumn ());
        $columns = array ($this->dbtable->getIdColumn (), $homeTeamIdColumn, $awayTeamIdColumn,
                          Sports::COL_MATCH_DATE, $competitionIdColumn,
                          Sports::COL_MATCH_STADIUM, Sports::COL_MATCH_RESULT,
                          Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT);
        $criteria = array ();
        $criteria[] = new LogicalOperatorOr
                            (
                            new EqCriterion ($homeTeamIdColumn, $teamId),
                            new EqCriterion ($awayTeamIdColumn, $teamId)
                            );
        if (!empty ($dateCriterion))
            $criteria[] = $dateCriterion;

        $criteria[] = new GtCriterion ("c_".Sports::COL_MATCH_DATE, $preseasonStartDate);

        $params = array ();
        $params[] = OrderBy::create ("c_".Sports::COL_MATCH_DATE, false);
        $rows = $this->dbtable->selectBy ($columns, $criteria, NULL, $params);
        if (!empty ($rows))
            $this->output = array_merge ($this->output, $this->getRecentGamesDescription ($rows, $teamId));
        }

    public function saveInput ($context, &$request, &$input)
        {
        $dateCriterion = NULL;
        if (!empty ($input["match"]))
            return $this->generateAnnouncementForMatch ($context, $input["match"], $input["includeResults"], !empty ($input["preSeason"]), !empty ($input["players"]), $input["dismissAfter"], $input["unofficial"]);
        else
            {
            $now = getdate ();
            $preseasonStartDate = !empty ($input["preSeason"]) ? "{$now["year"]}-01-01 00:00:00" : NULL;
            return $this->generateTeamAnalysis ($context, $input["team1"], $input["team2"], $input["includeResults"], $input["dismissAfter"], $input["unofficial"], $preseasonStartDate);
            }
        }

    protected function getPredecessorTeamIds ($teamId)
        {
        // retrieve teams of the same club
        $ids = SportsHelper::getPredecessorTeamIds ($this->context, $teamId);
        return $ids;
        }

    protected function getCompetitionLabel ($competitionId)
        {
        if (empty ($this->competitionLabels[$competitionId]))
            {
            $colName = "f_".Sports::COL_COMPETITION_LEAGUE."_".Sports::TABLE_LEAGUE."_id";
            $row = $this->competitionsTable->selectSingleBy (array ($colName),
                                                             array (new EqCriterion ($this->competitionsTable->getIdColumn (), $competitionId)));
            if (empty ($row))
                return "L$competitionId";

            $this->competitionLabels[$competitionId] = $this->getLeagueLabel ($row[$colName]);
            }
        return $this->competitionLabels[$competitionId];
        }

    protected function getSimilarCompetitionIds ($competitionId)
        {
        $colName = "f_".Sports::COL_COMPETITION_LEAGUE."_".Sports::TABLE_LEAGUE."_id";
        $row = $this->competitionsTable->selectSingleBy (array ($colName),
                                                         array (new EqCriterion ($this->competitionsTable->getIdColumn (), $competitionId)));
        if (empty ($row))
            return array ($competitionId);

        $leagueId = $row[$colName];
        $rows = $this->competitionsTable->selectBy (array ($this->competitionsTable->getIdColumn ()),
                                                    array (new EqCriterion ($colName, $leagueId)));
        if (empty ($rows))
            return array ($competitionId);

        $competitionIds = array ();
        foreach ($rows as $row)
            $competitionIds[] = $row[$this->competitionsTable->getIdColumn ()];
        return $competitionIds;
        }

    protected function getLeagueLabel ($leagueId)
        {
        if (empty ($this->leagueLabels[$leagueId]))
            {
            $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_LEAGUE);
            $this->leagueLabels[$leagueId] = $dbtable->getDisplayNameById ($leagueId);
            }
        return $this->leagueLabels[$leagueId];
        }

    protected function getStadiumLabel ($stadiumId)
        {
        if (empty ($this->stadiumLabels[$stadiumId]))
            {
            $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_STADIUM);
            $this->stadiumLabels[$stadiumId] = $dbtable->getDisplayNameById ($stadiumId);
            }
        return $this->stadiumLabels[$stadiumId];
        }

    protected function getTeamLabel ($teamId, $includeUrl = false)
        {
        $ids = SportsHelper::getTeamLabels ($this->context, array ($teamId));
        $label = $ids[$teamId];
        if (!$includeUrl)
            return $label;
        return "[[{$this->teamsTable->getName ()}:$teamId|$label]]";
        }

    protected function getTotalGamesDescription ($rows, $homeTeamIds, &$totalGameCount, $dismissAfter, $filterByColumn = NULL, $filterId = NULL)
        {
        $totalGameCount = 0;
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn ());
        $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $this->teamsTable->getIdColumn ());
        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, $this->competitionsTable->getIdColumn ());
        $drawCount = $homeTeamWon = $awayTeamWon = 0;
        $homeTeamGoals = $awayTeamGoals = 0;
        $homeTeamId = $awayTeamId = NULL;
        $lastGame = NULL;
        $firstDate = NULL;
        if ($competitionIdColumn == $filterByColumn)
            $filterBy = $this->getCompetitionLabel ($filterId);

        foreach ($rows as $row)
            {
            $resultHome = $row["c_".Sports::COL_MATCH_HOMERESULT];
            $resultAway = $row["c_".Sports::COL_MATCH_AWAYRESULT];

            if (NULL === $resultHome || NULL === $resultAway)
                continue;

            if (NULL != $filterByColumn)
                {
                if ($competitionIdColumn == $filterByColumn)
                    {
                    // special exception for competition id (filter by league id)
                    $rowCompetitionId = $row[$filterByColumn];
                    if (empty ($rowCompetitionId) || $this->getCompetitionLabel ($rowCompetitionId) != $filterBy)
                        continue;
                    }
                else if ($filterId != $row[$filterByColumn])
                    continue;
                }

            $lastGame = $row;
            $year = substr ($row["c_".Sports::COL_MATCH_DATE], 0, 4);

            if (NULL === $firstDate || $year - $lastYear > $dismissAfter)
                {
                $homeTeamWon = $awayTeamWon = 0;
                $homeTeamGoals = $awayTeamGoals = 0;
                $drawCount = 0;
                $firstGameYear = substr ($row["c_".Sports::COL_MATCH_DATE], 0, 4);
                $firstDate = $this->lng->dateToLongString ($row["c_".Sports::COL_MATCH_DATE], "year");
                }
            $lastYear = $year;

            $gameHomeTeamId = $row[$homeTeamIdColumn];
            if (false !== array_search ($gameHomeTeamId, $homeTeamIds))
                {
                $homeTeamGoals += $resultHome;
                $awayTeamGoals += $resultAway;
                }
            else
                {
                $homeTeamGoals += $resultAway;
                $awayTeamGoals += $resultHome;
                }

            // remember last encountered team ids
            $homeTeamId = $gameHomeTeamId;
            $awayTeamId = $row[$awayTeamIdColumn];
            if (false === array_search ($homeTeamId, $homeTeamIds))
                list ($homeTeamId, $awayTeamId) = array ($awayTeamId, $homeTeamId); 

            if ($resultHome == $resultAway)
                {
                $drawCount++;
                continue;
                }

            $winnerId = $resultHome > $resultAway ? $gameHomeTeamId : $row[$awayTeamIdColumn];
            if (false !== array_search ($winnerId, $homeTeamIds))
                $homeTeamWon++;
            else
                $awayTeamWon++;
            }

        if (empty ($lastGame))
            return NULL;

        $totalGameCount = $gamesPlayed = $homeTeamWon + $awayTeamWon + $drawCount;

        $output[] = $this->generateLastGameStatement ($lastGame, $gamesPlayed, $homeTeamIdColumn, $awayTeamIdColumn);
        if (1 == $gamesPlayed)
            return $output;

        $statementParts[] = $this->context->ngettext ("[_0] game played starting [_1]", "Total [_0] games played starting [_1]", $gamesPlayed, $firstDate);

        if ($homeTeamWon == $awayTeamWon)
            $statementParts[] = $this->context->ngettext ("each team won [_0] time", "each team won [_0] times", $homeTeamWon);
        else
            {
            $won = $homeTeamWon > $awayTeamWon ? $homeTeamWon : $awayTeamWon;
            $winningTeamId = $homeTeamWon > $awayTeamWon ? $homeTeamId : $awayTeamId;
            $label = $this->getTeamLabel ($winningTeamId);
            $statementParts[] = $this->context->ngettext ("[[[_1]|[_2]]] won on [_0] ocasion", "[[[_1]|[_2]]] won on [_0] ocasions", $won, "{$this->teamsTable->getName ()}:$winningTeamId", $label);
            }
    
        if ($drawCount > 0)
            $statementParts[] = $this->context->ngettext ("[_0] game was drawn", "[_0] games were drawn", $drawCount);

        if ($homeTeamGoals + $awayTeamGoals == 0)
            $statementParts[] = $this->context->getText ("No goals scored");
        else
            {
            if ($homeTeamGoals == $awayTeamGoals)
                $statementParts[] = $this->context->ngettext ("each team scored [_0] goal", "each team scored [_0] goals", $homeTeamGoals);
            else if ($homeTeamGoals > $awayTeamGoals)
                $statementParts[] = $this->context->getText ("[_0] scored [_1], [_2] scored [_3] goals",
                                                            $this->getTeamLabel ($homeTeamId), $homeTeamGoals,
                                                            $this->getTeamLabel ($awayTeamId), $awayTeamGoals);
            else
                $statementParts[] = $this->context->getText ("[_0] scored [_1], [_2] scored [_3] goals",
                                                            $this->getTeamLabel ($awayTeamId), $awayTeamGoals,
                                                            $this->getTeamLabel ($homeTeamId), $homeTeamGoals);
            }

        $output[] = implode (", ", $statementParts).".";
        return $output;
        }

    protected function getRecentGamesDescription ($rows, $teamId, $filterByColumn = NULL, $filterId = NULL)
        {
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn ());
        $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $this->teamsTable->getIdColumn ());
        $drawCount = $winCount = $lostCount = 0;
        $goalsFor = $goalsAgainst = 0;
        $lastGame = NULL;
        foreach ($rows as $row)
            {
            $lastGame = $row;

            $resultHome = $row["c_".Sports::COL_MATCH_HOMERESULT];
            $resultAway = $row["c_".Sports::COL_MATCH_AWAYRESULT];
            if (NULL === $resultHome || NULL === $resultAway || (NULL != $filterByColumn && $filterId != $row[$filterByColumn]))
                continue;

            $gameHomeTeamId = $row[$homeTeamIdColumn];
            if ($gameHomeTeamId != $teamId)
                list ($resultHome, $resultAway) = array ($resultAway, $resultHome);

            $goalsFor += $resultHome;
            $goalsAgainst += $resultAway;

            if ($resultHome == $resultAway)
                $drawCount++;
            else if ($resultHome > $resultAway)
                $winCount++;
            else
                $lostCount++;
            }

        $gamesPlayed = $winCount + $lostCount + $drawCount;
        if (0 == $gamesPlayed)
            return array ();

        $teamLabel = $this->getTeamLabel ($teamId);

        if (1 == $gamesPlayed)
            {
            $output[] = "\n".$this->generateLastSingleTeamGameStatement ($lastGame, $teamId, $teamLabel);
            return $output;
            }

        $statementParts[] = $this->context->ngettext ("[_1] played [_0] pre-season game", "[_1] played [_0] pre-season games", $gamesPlayed, $teamLabel);

        if ($gamesPlayed == $winCount)
            $statementParts[] = $this->context->ngettext ("winning on this single occasion", "won all games", $winCount);
        else if ($gamesPlayed == $winCount)
            $statementParts[] = $this->context->ngettext ("loosing on this single occasion", "loosing all games", $winCount);
        else if ($gamesPlayed == $winCount)
            $statementParts[] = $this->context->ngettext ("a single game drawn", "drawn all games", $winCount);
        else
            {
            if ($winCount == $lostCount && $winCount > 0)
                $statementParts[] = $this->context->ngettext ("won and lost in [_0] game", "won and lost in [_0] games", $lostCount);
            else
                {
                if ($winCount > 0)
                    $statementParts[] = $this->context->ngettext ("[_0] game was won", "[_0] games were lost", $winCount);
                if ($lostCount > 0)
                    $statementParts[] = $this->context->ngettext ("[_0] game was lost", "[_0] games were lost", $lostCount);
                }
    
            if ($drawCount > 0)
                $statementParts[] = $this->context->ngettext ("[_0] game was drawn", "[_0] games were drawn", $drawCount);
            }

        if ($goalsFor + $goalsAgainst == 0)
            $statementParts[] = $this->context->getText ("no goals were scored or conceded");
        else
            {
            $statementParts[] = 0 == $goalsFor ? $this->getText ("no goals scored") : $this->ngettext ("scored [_0] goal", "scored [_0] goals", $goalsFor);
            $statementParts[] = 0 == $goalsAgainst ? $this->getText ("no goals conceeded") : $this->ngettext ("conceeded [_0] goal", "conceeded [_0] goals", $goalsAgainst);
            }

        $output[] = "\n".implode (", ", $statementParts).".";
        return $output;
        }

    protected function generateLastGameStatement ($lastGame, $gamesPlayed, $homeTeamIdColumn, $awayTeamIdColumn)
        {
        // generate last game statement
        $stadiumIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STADIUM, Sports::TABLE_STADIUM."_id");
        $stadiumId = $lastGame[$stadiumIdColumn];
        $stadium = $lastGame[Sports::COL_MATCH_STADIUM.".".ContentTable::COL_DISPLAY_NAME];
        $date = $this->lng->dateToLongString ($lastGame["c_".Sports::COL_MATCH_DATE], "day");
        $lastGameResult = array ($lastGame["c_".Sports::COL_MATCH_HOMERESULT], $lastGame["c_".Sports::COL_MATCH_AWAYRESULT]);
        if ($lastGameResult[0] == $lastGameResult[1])
            {
            $lastTeamId = 0;
            $label = NULL;
            }
        else
            {
            $lastTeamId = $lastGameResult[0] > $lastGameResult[1] ? $lastGame[$homeTeamIdColumn] : $lastGame[$awayTeamIdColumn];
            $label = $this->getTeamLabel ($lastTeamId);
            }

        return $this->getTotalForLastGame ($date, $lastTeamId, $label, $lastGameResult[0], $lastGameResult[1], $stadiumId, $stadium, 1 == $gamesPlayed);
        }

    protected function getTotalForLastGame ($date, $teamId, $teamLabel, $homeTeamGoals, $awayTeamGoals, $stadiumId, $stadium, $singleGame)
        {
        if (empty ($teamId))
            {
            if ($singleGame)
                {
                if (!empty ($stadium))
                    return $this->context->getText ("A single game on [_2] at [[[_3]|[_4]]] ended [_0]:[_1]",
                                                    array ($homeTeamGoals, $awayTeamGoals, $date, Sports::TABLE_STADIUM.":$stadiumId", $stadium));
                return $this->context->getText ("A single game on [_2] ended [_0]:[_1]",
                                                array ($homeTeamGoals, $awayTeamGoals, $date));
                }
            else if (!empty ($stadium))
                return $this->context->getText ("Last game between those team was played [_2] at [[[_3]|[_4]]] ended [_0]:[_1]",
                                                array ($homeTeamGoals, $awayTeamGoals, $date, Sports::TABLE_STADIUM.":$stadiumId", $stadium));
            else
                return $this->context->getText ("Last game between those team was played [_2] ended [_0]:[_1]",
                                                array ($homeTeamGoals, $awayTeamGoals, $date));
            }
        else
            {
            $teamId = "{$this->teamsTable->getName ()}:$teamId";
            $result = $homeTeamGoals > $awayTeamGoals ? array ($homeTeamGoals, $awayTeamGoals) : array ($awayTeamGoals, $homeTeamGoals);
            if ($singleGame)
                {
                if (!empty ($stadium))
                    return $this->context->getText ("A single game on [_4] at [[[_5]|[_6]]] was won by the [[[_0]|[_1]]] with result [_2]:[_3]",
                                                    array ($teamId, $teamLabel, $result[0], $result[1], $date, Sports::TABLE_STADIUM.":$stadiumId", $stadium));
                return $this->context->getText ("A single game on [_4] was won by the [[[_0]|[_1]]] with result [_2]:[_3]",
                                                array ($teamId, $teamLabel, $result[0], $result[1], $date));
                }
            else if (!empty ($stadium))
                return $this->context->getText ("Last game between those team played [_4] at [[[_5]|[_6]]] was won by the [[[_0]|[_1]]] with result [_2]:[_3]",
                                                array ($teamId, $teamLabel, $result[0], $result[1], $date, Sports::TABLE_STADIUM.":$stadiumId", $stadium));
            else
                return $this->context->getText ("Last game between those team played on [_4] was won by the [[[_0]|[_1]]] with result [_2]:[_3]",
                                                array ($teamId, $teamLabel, $result[0], $result[1], $date));
            }
        }

    protected function getLastPreseasonGameStatement ($date, $teamId, $teamLabel, $opponentLabel, $homeTeamGoals, $awayTeamGoals, $stadiumId, $stadium)
        {
        if (!empty ($stadium))
            $stadiumId = Sports::TABLE_STADIUM.":$stadiumId";
        $teamId = "{$this->teamsTable->getName ()}:$teamId";

        if ($homeTeamGoals == $awayTeamGoals)
            {
            return $this->context->getText ("[[[_0]|[_1]]] played a single pre-season game against [_7] on [_4] at \[\[[_5]|[_6]\]\] which ended [_2]:[_3].",
                                            array ($teamId, $teamLabel, $homeTeamGoals, $awayTeamGoals, $date, $stadiumId, $stadium, $opponentLabel));
            }
        else
            {
            if ($homeTeamGoals > $awayTeamGoals)
                {
                return $this->context->getText ("[[[_0]|[_1]]] won a single pre-season game against [_7] on [_4] at \[\[[_5]|[_6]\]\], game ended [_2]:[_3].",
                                                array ($teamId, $teamLabel, $homeTeamGoals, $awayTeamGoals, $date, $stadiumId, $stadium, $opponentLabel));
                }
            else
                {
                return $this->context->getText ("[[[_0]|[_1]]] lost a single pre-season game against [_7] on [_4] at \[\[[_5]|[_6]\]\], game ended [_2]:[_3].",
                                                array ($teamId, $teamLabel, $homeTeamGoals, $awayTeamGoals, $date, $stadiumId, $stadium, $opponentLabel));
                }
            }
        }

    protected function generateLastSingleTeamGameStatement ($lastGame, $teamId, $teamLabel)
        {
        // generate last game statement
        $stadiumIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STADIUM, Sports::TABLE_STADIUM."_id");
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn ());
        $stadiumId = $lastGame[$stadiumIdColumn];
        $stadium = $lastGame[Sports::COL_MATCH_STADIUM.".".ContentTable::COL_DISPLAY_NAME];
        $date = $this->lng->dateToLongString ($lastGame["c_".Sports::COL_MATCH_DATE], "day");

        $lastGameResult = array ($lastGame["c_".Sports::COL_MATCH_HOMERESULT], $lastGame["c_".Sports::COL_MATCH_AWAYRESULT]);
        $gameHomeTeamId = $lastGame[$homeTeamIdColumn];
        if ($gameHomeTeamId != $teamId)
            {
            $lastGameResult = array ($lastGameResult[1], $lastGameResult[0]);
            $opponentLabel = $this->getTeamLabel ($gameHomeTeamId);
            }
        else
            $opponentLabel = $this->getTeamLabel ($lastGame[ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $this->teamsTable->getIdColumn ())]);

        return $this->getLastPreseasonGameStatement ($date, $teamId, $teamLabel, $opponentLabel, $lastGameResult[0], $lastGameResult[1], $stadiumId, $stadium);
        }

    public function getLastGameOutcome ($gameRow, $homeTeamIds, $homeTeamIdColumn, $awayTeamIdColumn, $competition)
        {
        if (!empty ($competition))
            $competition = " ($competition)";
        $resultHome = $gameRow["c_".Sports::COL_MATCH_HOMERESULT];
        $resultAway = $gameRow["c_".Sports::COL_MATCH_AWAYRESULT];
        $result = $gameRow["c_".Sports::COL_MATCH_RESULT];
        $stadium = $gameRow[Sports::COL_MATCH_STADIUM.".".ContentTable::COL_DISPLAY_NAME];
        if (empty ($stadium))
            $stadium = $this->getText ("unknown stadium");

        $date = $this->lng->dateToLongString ($gameRow["c_".Sports::COL_MATCH_DATE], "day");
        if (NULL === $resultHome && NULL === $resultAway)
            return $this->getText ("Game played on [_0] and outcome is unknown.", $date).$competition;
        else if ($resultHome == $resultAway)
            return $this->getText ("On [_0] game between those teams ended [_2] in [_1].", $date, $stadium, $result).$competition;

        $winnerId = $resultHome > $resultAway ? $gameRow[$homeTeamIdColumn] : $gameRow[$awayTeamIdColumn];
        $winnerLabel = $this->getTeamLabel ($winnerId);
        return $this->getText ("On [_0] game was won by [_2] in [_1] (result [_3]).", $date, $stadium, $winnerLabel, $result).$competition;
        }

    protected function generateTeamPlayerAnalysis ($context, $teamId, $competitionId, $dateCriterion, $title)
        {
        $playersTable = ContentTable::createInstanceByName ($context, Sports::TABLE_PERSON);
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $registrationsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_REGISTRATIONS);
        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_REGISTRATION_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $teamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_REGISTRATION_TEAM, Sports::TABLE_TEAM."_id");
        $playerIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_REGISTRATION_PLAYER, $playersTable->getIdColumn ());

        $criteria = array (new EqCriterion ($competitionIdColumn, $competitionId), new EqCriterion ($teamIdColumn, $teamId));
        $rows = $registrationsTable->selectBy (array ($playerIdColumn), $criteria);
        $playerIds = array ();
        if (!empty ($rows))
            {
            foreach ($rows as $row)
                $playerIds[] = $row[$playerIdColumn];
            }

        $playerIds = array_merge ($playerIds, $this->selectTeamSeasonPlayerIds ($matchesTable, $competitionId, $teamId));
        if (empty ($playerIds))
            return;

        $this->output[] = "\n$title\n<table border=\"1\">";
        $tableRow = "<tr>";
        $tableRow .= "<th>".$this->getText ("Player")."</td>";
        $tableRow .= "<th class=\"numbercell\">".$this->getText ("Competition matches")."</td>";
        $tableRow .= "<th class=\"numbercell\">".$this->getText ("Competition goals")."</td>";
        $tableRow .= "<th class=\"numbercell\">".$this->getText ("Team matches")."</td>";
        $tableRow .= "<th class=\"numbercell\">".$this->getText ("Team goals")."</td>";
        $tableRow .= "<th class=\"numbercell\">".$this->getText ("Team competition matches")."</td>";
        $tableRow .= "<th class=\"numbercell\">".$this->getText ("Team competition goals")."</td>";
        $tableRow .= "<th class=\"numbercell\">".$this->getText ("Season matches")."</td>";
        $tableRow .= "<th class=\"numbercell\">".$this->getText ("Season goals")."</td>";
        $tableRow .= "</tr>";
        $this->output[] = "\n".$tableRow;

        $playerLabels = SportsHelper::getPlayerLabels ($playersTable, $playerIds);
        $playerMatches = $this->selectPlayerInformation ($matchesTable, Sports::TABLE_MATCHPLAYER, $competitionId, $playerIds);
        $playerGoals = $this->selectPlayerInformation ($matchesTable, Sports::TABLE_MATCHGOAL, $competitionId, $playerIds);
        $matchesByTeam = $this->selectPlayerInformation ($matchesTable, Sports::TABLE_MATCHPLAYER, NULL, $playerIds, NULL, $teamId);
        $goalsByTeam = $this->selectPlayerInformation ($matchesTable, Sports::TABLE_MATCHGOAL, NULL, $playerIds, NULL, $teamId);
        $matchesByTeamAndCompetition = $this->selectPlayerInformation ($matchesTable, Sports::TABLE_MATCHPLAYER, $competitionId, $playerIds, false, $teamId);
        $goalsByTeamAndCompetition = $this->selectPlayerInformation ($matchesTable, Sports::TABLE_MATCHGOAL, $competitionId, $playerIds, false, $teamId);
        $seasonMatches = $this->selectPlayerInformation ($matchesTable, Sports::TABLE_MATCHPLAYER, $competitionId, $playerIds, true);
        $seasonGoals = $this->selectPlayerInformation ($matchesTable, Sports::TABLE_MATCHGOAL, $competitionId, $playerIds, true);
        foreach ($playerLabels as $id => $label)
            {
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $playersTable,
                                                                         $playersTable->getId (), $id);
            $tableRow = "<tr>";
            $tableRow .= "<td><a href=\"$url\">$label</a></td>";
            
            foreach (array ($playerMatches, $playerGoals, $matchesByTeam, $goalsByTeam, 
                            $matchesByTeamAndCompetition, $goalsByTeamAndCompetition,
                            $seasonMatches, $seasonGoals) as $collection)
                {
                $val = array_key_exists ($id, $collection) ? $collection[$id] : "&nbsp;";
                $tableRow .= "<td class=\"numbercell\">$val</td>";
                }
            $tableRow .= "</tr>";
            $this->output[] = "\n".$tableRow;
            }

        $this->output[] = "\n</table>";
        }

    protected function createIdCriterion ($id, $singleCompetition)
        {
        $competitionIds = $singleCompetition ? array ($id) : $this->getSimilarCompetitionIds ($id);
        $arr[] = new InCriterion (ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id"), $competitionIds);
        $arr[] = new InCriterion ("c_".Sports::COL_MATCH_OUTCOME,
                               array (MatchConstants::OUTCOME_NOT_STARTED, MatchConstants::OUTCOME_FULL_TIME,
                                      MatchConstants::OUTCOME_EXTRA_TIME, MatchConstants::OUTCOME_PENALTIES,
                                      MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                      MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $arr[] = new LogicalOperatorOr (new EqCriterion ("c_".Sports::COL_MATCH_EXCLUDED, 0), new IsNullCriterion ("c_".Sports::COL_MATCH_EXCLUDED));
        return $arr;
        }

    protected function selectPlayerInformation ($matchesTable, $tableName, $competitionId, $playerIds, $singleCompetition = false, $teamId = NULL)
        {
        $playersTable = ContentTable::createInstanceByName ($this->context, $tableName);
        $playerIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_PLAYER_PERSON, Sports::TABLE_PERSON."_id");
        $matchesTableJoins = NULL;

        if (!empty ($competitionId))
            $joinCriteria = $this->createIdCriterion ($competitionId, $singleCompetition);
        else if (!empty ($teamId))
            {
            $competitionsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
            $competitionColumn = "f_".Sports::COL_MATCH_COMPETITION."_".$competitionsTable->getIdColumn ();
            $competitionsCriteria[] = new JoinColumnsCriterion ($competitionColumn, $competitionsTable->getIdColumn ());
            $competitionsCriteria[] = new NotEqCriterion (Sports::COL_COMPETITION_UNOFFICIAL, 1);
            $matchesTableJoins[] = $competitionsTable->createQuery (array (), $competitionsCriteria);
            }

        $joinCriteria[] = new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ());
        $joins[] = $matchesTable->createQuery (array (), $joinCriteria, $matchesTableJoins);
        $criteria = array (new InCriterion ($playerIdColumn, $playerIds));
        if (Sports::TABLE_MATCHGOAL == $tableName)
            $criteria[] = new EqCriterion (Sports::COL_GOAL_OWN, 0);
        else
            $criteria[] = new EqCriterion (Sports::COL_PLAYER_UNUSED, 0);

        if (!empty ($teamId))
            {
            $teamIds = $this->getPredecessorTeamIds ($teamId);
            $homeColumn = "c_".(Sports::TABLE_MATCHGOAL == $tableName ? Sports::COL_GOAL_HOME : Sports::COL_PLAYER_ISHOME);

            $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn ());
            $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $this->teamsTable->getIdColumn ());
            $criteria[] = new LogicalOperatorOr
                                (
                                new LogicalOperatorAnd
                                    (
                                    new InCriterion ($homeTeamIdColumn, $teamIds, true),
                                    new EqCriterion ($homeColumn, 1)
                                    ),
                                new LogicalOperatorAnd
                                    (
                                    new EqCriterion ($homeColumn, 0),
                                    new InCriterion ($awayTeamIdColumn, $teamIds, true)
                                    )
                                );
            }

        $params[] = new GroupBy (array ($playerIdColumn));
        $rows = $playersTable->selectBy (array ($playerIdColumn, new FunctionCount ("*", "cnt")), $criteria, $joins, $params);
        if (empty ($rows))
            return array ();
        $result = array ();
        foreach ($rows as $row)
            {
            $result[$row[$playerIdColumn]] = $row["cnt"];
            }

        return $result;
        }

    protected function selectTeamSeasonPlayerIds ($matchesTable, $competitionId, $teamId)
        {
        $playersTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCHPLAYER);
        $playerIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_PLAYER_PERSON, Sports::TABLE_PERSON."_id");
        $joinCriteria = $this->createIdCriterion ($competitionId, true);
        $joinCriteria[] = new JoinColumnsCriterion ($matchesTable->getIdColumn (), $matchesTable->getIdColumn ());
        $joins[] = $matchesTable->createQuery (array (), $joinCriteria);

        $homeColumn = "c_".Sports::COL_PLAYER_ISHOME;
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $this->teamsTable->getIdColumn ());
        $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $this->teamsTable->getIdColumn ());
        $criteria[] = new LogicalOperatorOr
                            (
                            new LogicalOperatorAnd
                                (
                                new EqCriterion ($homeTeamIdColumn, $teamId, true),
                                new EqCriterion ($homeColumn, 1)
                                ),
                            new LogicalOperatorAnd
                                (
                                new EqCriterion ($homeColumn, 0),
                                new EqCriterion ($awayTeamIdColumn, $teamId, true)
                                )
                            );

        $params[] = new GroupBy (array ($playerIdColumn));
        $params[] = OrderBy::createByAlias ("cnt", false);
        $rows = $playersTable->selectBy (array ($playerIdColumn, new FunctionCount ("*", "cnt")), $criteria, $joins, $params);
        if (empty ($rows))
            return array ();
        $result = array ();
        foreach ($rows as $row)
            {
            $result[] = $row[$playerIdColumn];
            }

        return $result;
        }

    public function getResultOutput ($rawFormat = NULL)
        {
        if (empty ($this->output))
            return parent::getResultOutput ();
        $output = implode ("\n", $this->output);
        if (NULL === $rawFormat)
            $rawFormat = $this->rawFormat;
        return $rawFormat ? str_replace (array ("<", "\n"), array ("&lt;", "\n<br>\n"), $output) : $this->context->applyFormat ($output);
        }

    }

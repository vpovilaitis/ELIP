<?php
require_once (PATH.'pages/contentinstanceeditor.php');
require_once (PATH.'inc/sports/constants.php');

class CDSeasonEditor extends ContentInstanceEditor
    {
    protected function canEditParent ()
        {
        return true;
        }
    }

<?php
require_once (PATH.'pages/submit.php');
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/relationfields.php');

class ListMatches extends Submit
    {
    public function __construct ($context, $request)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, "match");

        if (empty ($this->dbtable))
            {
            $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            $this->allTablesLoaded = false;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        $context->addScriptFile ("autosuggest");
        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ("Match list");
        return true;
        }

    public function collectInputData ($context, &$request)
        {
        $teamId = $request["res_team_x"];
        $criteria = array
            (
            new LogicalOperatorOr (new EqCriterion ("hometeam", $teamId), new EqCriterion ("awayteam", $teamId)),
            new GtEqCriterion ("c_time", $request["from"]),
            new LtEqCriterion ("c_time", $request["to"]),
            );
        $idColumn = $this->dbtable->getIdColumn ();
        $rows = $this->dbtable->selectBy (array ($idColumn, "time", "stadium", "hometeam.shortname", "awayteam.shortname", "result", "c_outcome"), $criteria);

        foreach ($rows as $row)
            {
            $homeResult = $row["c_homeresult"];
            $awayResult = $row["c_awayresult"];
            $homeTeamId = $row["hometeam"][0];
            $awayTeamId = $row["hometeam"][0];
            if ($homeTeamId == $teamId)
                $opponent = $row["awayteam.c_shortname"];
            else
                {
                list ($homeResult, $awayResult) = array ($awayResult, $homeResult);
                $opponent = $row["hometeam.c_shortname"];
                }

            $matchId = $row[$idColumn];
            $time = substr ($row["c_time"], 0, 10);
            $stadium = $row["stadium.displayname"];
            $outcome = NULL;
            if ($homeResult > $awayResult)
                $outcome = "pergalė";
            else if ($homeResult < $awayResult)
                $outcome = "pralaimėjimas";
            else
                $outcome = "lygiosios";

            print <<<EOT
            <p><a href="http://www.futbolinis.lt/content/match/$matchId/lt">$time</a> $outcome $homeResult:$awayResult prieš $opponent ($stadium)
            </p>
EOT;
            }

        return array ();
        }

    public function saveInput ($context, &$request, &$input)
        {
        return true;
        }

    public function validateInput ($context, &$input)
        {
        return true;
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();
        $arr = array
            (
            );

        $field = $this->createField ("team", "hometeam", "x");
        $field->label = "Team";
        $arr[] = $field;

        $arr[] = new DateFieldTemplate ("", "from", "From date:", "Enter date");
        $arr[] = new DateFieldTemplate ("", "to", "To date:", "Enter date");
            
        return $arr;
        }
        
    }

<?php
require_once (PATH."pages/contentview.php");
require_once (PATH."pages/sports/seasonsbox.php");

class SeasonsView extends ContentView
    {
    protected $navigationBox = NULL;

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $context->addStyleSheet ("sports");
        }

    public function ensureChildren ($context, $request)
        {
        parent::ensureChildren ($context, $request);

        $this->navigationBox = new SeasonsBox ($this->context, $this->dbtable, $this->getIds ());
        $this->addComponent ($request, "seasons", $this->navigationBox);
        }

    public function getNavigationBox ()
        {
        return $this->navigationBox;
        }

    public function getTemplateName ()
        {
        return "viewwithnavbox";
        }
    }


<?php
require_once (PATH.'pages/sports/submitgame.php');

class SubmitSchedule extends SubmitGame
    {
    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ("Create simple competition schedule");
        $context->addScriptFile ('sports');
        return true;
        }

    public function collectInputData ($context, &$request)
        {
        $this->createSourceFields ();
        $this->source = $this->sourcesField->getValueForDB ($context, $request);
        $this->sourceDate = $this->sourcesDateField->getValueForDB ($context, $request);

        $matches = $this->createSchedule ($request);
        return $matches;
        }
        
    public function validateInput ($context, &$input)
        {
        if (empty ($_REQUEST["teams"]))
            return $this->logError ("Please enter team count (&teams=8)");
        return parent::validateInput ($context, $input);
        }

    protected function createSchedule ($request)
        {
        $insertAtMiddle = !empty ($request["middle"]);
        $teams = array ();
        $teamLabels = array ();
        $teamCount = $_REQUEST["teams"];
        for ($i = 0; $i <= $teamCount / 2; $i++)
            {
            $teams[] = $request["res_team_$i"];
            $teamLabels[] = $request["res_team_{$i}_label"];
            }

        if ($insertAtMiddle && $teamCount % 2 == 1)
            {
            $teams[] = NULL;
            $teamLabels[] = NULL;
            }

        for ($i = floor ($teamCount / 2 + 1); $i < $teamCount; $i++)
            {
            $teams[] = $request["res_team_$i"];
            $teamLabels[] = $request["res_team_{$i}_label"];
            }

        if (!$insertAtMiddle && $teamCount % 2 == 1)
            {
            $teams[] = NULL;
            $teamLabels[] = NULL;
            }

        $roundNo = !empty ($request["roundno"]) ? $request["roundno"] : NULL;
        $skipRounds = !empty ($request["skipRounds"]) ? explode (",", $request["skipRounds"]) : array ();
        $matches = array();
        for ($i = 1; $i < $teamCount; $i++)
            {
            $matchDay = $request["round$i"];
            
            if (false === $this->calculateMatchDay ($matchDay, $teams, $i, $matches, $roundNo, $teamLabels, $pairs, $skipRounds))
                return false;
            }

        return $matches;
        }

    protected function printRecognizedMatch ($match)
        {
        return true;
        }

    protected function calculateMatchDay ($matchDay, $teams, $matchDayNo, &$matches, $roundNo, $labels, &$pairs, $skipRounds)
        {
        // Berger tables - http://en.wikipedia.org/wiki/Round-robin_tournament#Scheduling_algorithm
        $teamCount = count ($teams);

        if (!empty ($roundNo))
            $number = ($roundNo - 1) * ($teamCount - 1) * $teamCount / 2 + ($matchDayNo - 1) * $teamCount / 2 + 1;

        $usedTeams = array ();
        $pairCount = ceil ($teamCount / 2);
        if (empty ($pairs))
            {
            for ($i = 0; $i < $pairCount; $i++)
                $pairs[] = array ($i, $pairCount * 2 - $i - 1);
            }
        else
            {
            $oldPairs = $pairs;
            $pairs = array ();
            for ($i = 0; $i < $pairCount; $i++)
                {
                $homeTeam = $oldPairs[$pairCount - $i - 1][1]; // take away teams from last round in reversed order
                if ($i == $pairCount - 1 && 0 == $matchDayNo % 2) // first pair should always contain last team, soevery other round we need to take ahome team from previous round
                    $homeTeam = $oldPairs[$pairCount - $i - 1][0];

                if (0 == $i)
                    {
                    $awayTeam = $pairCount * 2 - 1;
                    if (0 === $matchDayNo % 2)
                        list ($homeTeam, $awayTeam) = array ($awayTeam, $homeTeam);
                    }
                else
                    $awayTeam = ($matchDayNo - $homeTeam + $pairCount * 2 - 2) % ($pairCount * 2 - 1);
                
                $usedTeams[] = $homeTeam;
                $usedTeams[] = $awayTeam;
                $pairs[] = array ($homeTeam, $awayTeam);
                }
            }

        $roundNumber = ($roundNo - 1) * ($teamCount - 1) + $matchDayNo;
        if (false !== array_search ($roundNumber, $skipRounds))
            {
            $this->writeLine ("<h3>Skipping round $roundNumber ({$matchDayNo} - $matchDay)...</h3>", false);
            return true;
            }

        $this->writeLine ("<h3>Round $roundNumber ({$matchDayNo} - $matchDay):</h3><table>", false);

        if (count ($usedTeams) != count (array_unique ($usedTeams)))
            {
            $this->logError ("Not all teams used in this round");
            $this->writeLine ($pairs);
            return false;
            }

        foreach ($pairs as $pair)
            {
            if (NULL != $roundNo && 0 === $roundNo % 2)
                list ($awayTeam, $homeTeam) = $pair;
            else
                list ($homeTeam, $awayTeam) = $pair;

            if ($homeTeam >= $teamCount || $awayTeam >= $teamCount)
                {
                if ($homeTeam >= $teamCount)
                    $this->writeLine ("<tr><td></td><td>-</td><td>{$labels[$awayTeam]}</td></tr>", false);
                else
                    $this->writeLine ("<tr><td>{$labels[$homeTeam]}</td><td>-</td><td></td></tr>", false);
                continue;
                }

            $this->writeLine ("<tr><td>{$labels[$homeTeam]}</td><td>-</td><td>{$labels[$awayTeam]}</td></tr>", false);
            
            $match = array
                (
                SubmitGame::MATCH_DATE => $matchDay,
                "homeTeamId" => $teams[$homeTeam],
                "awayTeamId" => $teams[$awayTeam],
                );

            if (NULL !== $roundNo)
                {
                $match["round"] = $roundNumber;
                $match["number"] = $number++;
                }
            $matches[] = $match;
            }
        $this->writeLine ("</table>", false);
        }

    public function createSourceFields ()
        {
        parent::createSourceFields ();
        if (empty ($this->competitionField))
            {
            $seasonColumn = $this->dbtable->findColumn ("cstage");
            $this->competitionField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $seasonColumn);
            }
        if (empty ($this->roundField))
            {
            $roundColumn = $this->dbtable->findColumn ("round");
            $this->roundField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $roundColumn);
            }
        }

    protected function processInputFields ($context, &$request)
        {
        parent::processInputFields ($context, $request);
        $this->competitionField->processInput ($context, $request);
        $this->roundField->processInput ($context, $request);
        }

    public function getStartupScript ()
        {
        return "attachSubmitSchedule()";
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();
        $arr = array
            (
            $this->competitionField,
            $this->roundField,
            new IntFieldTemplate ("", "roundno", "Round No", "1, 2, 3, 4")
            );

        for ($i = 0; $i < $_REQUEST["teams"]; $i++)
            {
            $field = $this->createField ("team", "hometeam", $i);
            $field->label = "Team ranked ".($i+1);
            $arr[] = $field;
            }

        for ($i = 1; $i < $_REQUEST["teams"]; $i++)
            {
            $arr[] = new DateFieldTemplate ("", "round$i", "Round $i:", "Enter round date");
            }
            
        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }
    }

<?php
require_once (PATH.'pages/submit.php');
require_once (PATH.'inc/sports/constants.php');

class SubmitRegistration extends Submit
    {
    protected $competitionField;
    protected $teamField;
    protected $persons = array ();

    public function __construct ($context, $request)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_REGISTRATIONS);

        if (empty ($this->dbtable))
            {
            $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            $this->allTablesLoaded = false;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        $context->addScriptFile ("autosuggest");
        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        }

    public function collectInputData ($context, &$request)
        {
        if (empty ($request["hometeam"]) || empty ($request["cstage"]) || empty ($request["parse"]))
        $this->createSourceFields ();
        $this->source = $this->sourcesField->getValueForDB ($context, $request);
        $this->sourceDate = $this->sourcesDateField->getValueForDB ($context, $request);

        return $this->collectEntries ($request["cstage"], $request["hometeam"], $request["type"],
                                      $this->dateField->getValueForDB ($context, $request),
                                      !empty ($request[Sports::COL_REGISTRATION_NUMBERFIXED]),
                                      $request["parse"]);
        }

    protected function createRegistrationEntry ($number, $firstName, $familyName, $position, $birthDate, $height, $weight)
        {
        $playerRegistration = array ();
        $playerRegistration[Sports::COL_REGISTRATION_NUMBER] = "-" == $number ? NULL : $number;
        $playerRegistration["name"] = trim ($firstName)." ".trim ($familyName);
        $this->checkPerson ($playerRegistration, "name", Sports::COL_REGISTRATION_PLAYER);
        
        $position = utf8_strtolower (trim ($position));
        switch ($position)
            {
            case "vartininkas":
                $playerRegistration[Sports::COL_REGISTRATION_POSITION] = SportsConstants::REG_POSITION_GOALKEEPER;
                break;
            case "gynejas":
            case "gynėjas":
                $playerRegistration[Sports::COL_REGISTRATION_POSITION] = SportsConstants::REG_POSITION_DEFENDER;
                break;
            case "saugas":
                $playerRegistration[Sports::COL_REGISTRATION_POSITION] = SportsConstants::REG_POSITION_MIDFIELD;
                break;
            case "puolėjas":
            case "puolejas":
                $playerRegistration[Sports::COL_REGISTRATION_POSITION] = SportsConstants::REG_POSITION_SRIKER;
                break;

            default:
                $playerRegistration[Sports::COL_REGISTRATION_POSITION] = NULL;
                if (!empty ($position))
                    $this->logError ("Position $position not recognized");
                break;
            }

        $playerRegistration["birthdate"] = $birthDate;
        $playerRegistration["height"] = $height;
        $playerRegistration["weigth"] = $weight;
        return $playerRegistration;
        }

    public function collectEntries ($competitionId, $teamId, $listId, $registrationDate, $fixed, $content)
        {
        $players = array ();
        $content = str_replace ("\t", ";", $content);
        if (preg_match_all ("#^.+$#m", $content, $matches, PREG_SET_ORDER) > 0)
            {
            $dump = ""; 
            foreach ($matches as $match)
                {
                if (preg_match ('#^\s*'.
                                '([0-9]+\.?)\s+'.   // 1 - number
                                '(.+)\s+(.+)\s+'.   // 2 3 - first/last name
                                '([0-9.-]{10})\s+'. // 4 - date of birth
                                '(.+)\s+'.          // 5 - position
                                '([0-9]{3})\s+'.    // 6 - height
                                '([0-9]{2})\s*'.    // 7 - weight
                                '([0-9]{1,2})?'.      // 8 - number
                                '\s*$#', $match[0], $lineMatches) > 0)
                    {
                    $date = $lineMatches[4];
                    $date = substr ($date, 0, 4)."-".substr ($date, 5, 2)."-".substr ($date, 8, 2);
                    $players[] = $this->createRegistrationEntry ($lineMatches[8], /* number */
                                                                 $lineMatches[2], /* first name */
                                                                 $lineMatches[3], /* surname */
                                                                 $lineMatches[5], /* position */
                                                                 $date, /* birth date */
                                                                 $lineMatches[6], /* height */
                                                                 $lineMatches[7]  /* weight */
                                                                 );
                    }
                else if (preg_match ("#^\s*([0-9]+\.)\s+(.+)\s+(.+)\s+3([0-9]{6})[0-9]*\s+.+\s+([0-9]+)\s+(.+)\s+([0-9]+)?\s+([0-9]+)\s*$#", $match[0], $lineMatches) > 0)
                    {
                    $code = $lineMatches[4];
                    $date = "19".substr ($code, 0, 2)."-".substr ($code, 2, 2)."-".substr ($code, 4, 2);
                    $players[] = $this->createRegistrationEntry ($lineMatches[5], /* number */
                                                                 $lineMatches[2], /* first name */
                                                                 $lineMatches[3], /* surname */
                                                                 $lineMatches[6], /* position */
                                                                 $date, /* birth date */
                                                                 $lineMatches[7], /* height */
                                                                 $lineMatches[8]  /* weight */
                                                                 );
                    }
                else if (preg_match ("#^([0-9]*);(.+)\s+(.+);;(.*);([0-9]*);([0-9]*);(3([0-9]{6})[0-9]*)?\s*$#", $match[0], $lineMatches) > 0)
                    {
                    $date = NULL;
                    $code = $lineMatches[8];
                    if (!empty ($code))
                        $date = "19".substr ($code, 0, 2)."-".substr ($code, 2, 2)."-".substr ($code, 4, 2);
                    $players[] = $this->createRegistrationEntry ($lineMatches[1], /* number */
                                                                 $lineMatches[2], /* first name */
                                                                 $lineMatches[3], /* surname */
                                                                 $lineMatches[4], /* position */
                                                                 $date, /* birth date */
                                                                 $lineMatches[5], /* height */
                                                                 $lineMatches[6]  /* weight */
                                                                 );
                    }
                else if (preg_match ("#^\s*([0-9]+|-)?;(.+);(.+);([0-9]{4}[- .][0-9]{2}[- .][0-9]{2})?;([0-9]+)?;(.+)?;([0-9]+)?;([0-9]+)?;(.+);([0-9]+|.+)?\s*$#", $match[0], $lineMatches) > 0)
                    {
                    $players[] = $this->createRegistrationEntry ($lineMatches[1], /* number */
                                                                 $lineMatches[2], /* first name */
                                                                 $lineMatches[3], /* surname */
                                                                 $lineMatches[6], /* position */
                                                                 $lineMatches[4], /* birth date */
                                                                 $lineMatches[7], /* height */
                                                                 $lineMatches[8]  /* weight */
                                                                 );
                    }
                else if (preg_match ("#^\s*([0-9]+|-)?;(.+);(.+);(.+)?;([0-9]{4}[- .][0-9]{2}[- .][0-9]{2})?;([0-9]+)?;([0-9]+)?\s*$#", $match[0], $lineMatches) > 0)
                    {
                    $players[] = $this->createRegistrationEntry ($lineMatches[1], /* number */
                                                                 $lineMatches[2], /* first name */
                                                                 $lineMatches[3], /* surname */
                                                                 $lineMatches[4], /* position */
                                                                 $lineMatches[5], /* birth date */
                                                                 $lineMatches[6], /* height */
                                                                 $lineMatches[7]  /* weight */
                                                                 );
                    }
                else if (preg_match ("#^\s*([0-9]+)[.]?\s+(.+)\s+(.+)\s+(19[0-9]{2}[-. ][0-9]{2}[-. ][0-9]{2}|19[0-9]{2})\s*(.+\s*)?$#", $match[0], $lineMatches) > 0 ||
                         preg_match ("#^\s*([0-9]+)[.]?\s*;\s*(.+)\s+(.+)\s*;\s*(19[0-9]{2}[-. ][0-9]{2}[-. ][0-9]{2}|19[0-9]{2})\s*;\s*(.+\s*)?$#", $match[0], $lineMatches) > 0)
                    {
                    $players[] = $this->createRegistrationEntry ($lineMatches[1], /* number */
                                                                 $lineMatches[2], /* first name */
                                                                 $lineMatches[3], /* surname */
                                                                 !empty ($lineMatches[5]) ? $lineMatches[5] : NULL, /* position */
                                                                 $lineMatches[4], /* birth date */
                                                                 NULL, NULL);
                    }
                else if (preg_match ("#^\s*([0-9]+)\s+(.+)\s+(.+)\s+([GgVvSsPp].+)\s*$#", $match[0], $lineMatches) > 0)
                    {
                    $players[] = $this->createRegistrationEntry ($lineMatches[1], /* number */
                                                                 $lineMatches[2], /* first name */
                                                                 $lineMatches[3], /* surname */
                                                                 $lineMatches[4], /* position */
                                                                 NULL, /* birth date */
                                                                 NULL, NULL);
                    }
                else if (preg_match ("#^\s*([^0-9].+)\s+(.+)\s+(19[0-9]{2}[- ][0-9]{2}[- ][0-9]{2}|19[0-9]{2})\s*$#", $match[0], $lineMatches) > 0)
                    {
                    $players[] = $this->createRegistrationEntry (NULL, /* number */
                                                                 $lineMatches[1], /* first name */
                                                                 $lineMatches[2], /* surname */
                                                                 NULL, /* position */
                                                                 $lineMatches[3], /* birth date */
                                                                 NULL, NULL);
                    }
                else if (preg_match ("#^\s*([^0-9].+)\s+([^0-9].+)\s*;\s*(19[0-9]{2}[- ][0-9]{2}[- ][0-9]{2}|19[0-9]{2})\s*$#", $match[0], $lineMatches) > 0)
                    {
                    $players[] = $this->createRegistrationEntry (NULL, /* number */
                                                                 $lineMatches[1], /* first name */
                                                                 $lineMatches[2], /* surname */
                                                                 NULL, /* position */
                                                                 $lineMatches[3], /* birth date */
                                                                 NULL, NULL);
                    }
                else if (preg_match ("#^([0-9]+)\.?;(.+);(.+)$#", $match[0], $lineMatches) > 0)
                    {
                    $players[] = $this->createRegistrationEntry ($lineMatches[1], /* number */
                                                                 $lineMatches[2], /* first name */
                                                                 $lineMatches[3], /* surname */
                                                                 NULL, /* position */
                                                                 NULL, /* birth date */
                                                                 NULL, NULL);
                    }
                else if (preg_match ("#^([0-9]+)\.?;([a-ząčęėįšųūž.]+) ([a-ząčęėįšųūž]+)$#ui", trim ($match[0]), $lineMatches) > 0)
                    {
                    $players[] = $this->createRegistrationEntry ($lineMatches[1], /* number */
                                                                 $lineMatches[2], /* first name */
                                                                 $lineMatches[3], /* surname */
                                                                 NULL, /* position */
                                                                 NULL, /* birth date */
                                                                 NULL, NULL);
                    }
                else
                    $this->logError ("Line '{$match[0]}' was not recognized");
                }
            }

        print "<pre>";
        foreach ($players as $p)
            {
            print $p["no"].". ";
            print $p["name"]." \t";
            print $p["birthdate"]." ";
            print "pos:".$p["position"]." ";
            print $p["height"]."/".$p["weigth"];
            print "\n";
            }
        print "</pre>";
        return array ($competitionId, $teamId, $listId, $registrationDate, $fixed, $players);
        }

    protected function onInputFieldCollected ($context, &$request, $type, $key, $val)
        {
        if (!empty ($val))
            {
            switch ($type)
                {
                case Sports::COL_REGISTRATION_PLAYER:
                    $this->persons[$key] = $val;
                    break;
                }
            }
        }

    public function checkPerson (&$array, $key, $idKey, $optional = false)
        {
        if ($optional && !isset ($array[$key]))
            return;

        $name = trim ($array[$key], " ?");
        if (empty ($name))
            return;

        $requestKey = $this->encodeKey ($name);
        if (array_key_exists ($requestKey, $this->persons))
            {
            $array[$idKey] = $this->persons[$requestKey];
            }
        else
            {
            $this->hasUnrecognizedItems = true;
            if (false === array_search ("person", $this->fieldsNotReady))
                {
                $this->logError ("Unrecognized persons ('$name', ...)");
                $this->fieldsNotReady[] = "person";
                }
            }

        $parts = preg_split ("/\./", $name, 2);
        if (2 == count ($parts))
            $name = $parts[0].". ".trim ($parts[1]);
        $this->updateField (Sports::COL_REGISTRATION_PLAYER, Sports::COL_REGISTRATION_PLAYER, $requestKey, $name);
        }

    public function validateInput ($context, &$input)
        {
        return true;
        }
    public function saveInput ($context, &$request, &$input)
        {
        if (empty ($input))
            return;

        list ($competitionId, $teamId, $listId, $date, $numberFixed, $players) = $input;
        $playersTable = ContentTable::createInstanceByName ($context, Sports::TABLE_PERSON);
        $additionalPlayersData = array ();
        $cnt = 0;
        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_REGISTRATION_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $teamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_REGISTRATION_TEAM, Sports::TABLE_TEAM."_id");
        $playerIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_REGISTRATION_PLAYER, $playersTable->getIdColumn ());

        foreach ($players as $player)
            {
            $entry = array ();
            $entry[Sports::COL_REGISTRATION_COMPETITION] = $competitionId;
            $entry[Sports::COL_REGISTRATION_TEAM] = $teamId;
            $entry[Sports::COL_REGISTRATION_LIST] = $listId;
            $entry[Sports::COL_REGISTRATION_PLAYER] = $player[Sports::COL_REGISTRATION_PLAYER];
            $entry[Sports::COL_REGISTRATION_NUMBER] = $player[Sports::COL_REGISTRATION_NUMBER];
            $entry[Sports::COL_REGISTRATION_POSITION] = $player[Sports::COL_REGISTRATION_POSITION];
            $entry[Sports::COL_REGISTRATION_DATE] = $date;
            $entry[Sports::COL_REGISTRATION_NUMBERFIXED] = $numberFixed;

            if (!empty ($player["birthdate"]) || !empty ($player["height"]) || !empty ($player["weigth"]))
                $additionalPlayersData[$player[Sports::COL_REGISTRATION_PLAYER]] = $player;

            $entry[DBTable::COL_SOURCE] = $this->source;
            $entry[DBTable::COL_SOURCEDATE] = $this->sourceDate;

            if (false === $this->dbtable->insertRecord ($entry))
                $this->logError ("Error creating player registration instance");
            else
                $cnt++;
            }

        printf ("Registered %d players\n<br>", $cnt);

        $playerIds = array_keys ($additionalPlayersData);
        if (empty ($playerIds))
            return true;

        $columns = array ($playersTable->getIdColumn (), Sports::COL_PERSON_BIRTHDATE, Sports::COL_PERSON_HEIGHT, Sports::COL_PERSON_WEIGHT);
        $rows = $playersTable->selectBy ($columns, array (new InCriterion ($playersTable->getIdColumn (), $playerIds)));

        if (empty ($rows))
            return $this->logError ("Players not found");
        foreach ($rows as $row)
            {
            $player = $additionalPlayersData[$row[$playersTable->getIdColumn ()]];
            $nameValuePairs = array ();
            $birthDate = $row["c_".Sports::COL_PERSON_BIRTHDATE];
            if (preg_match ("/^([0-9]{4})-([0-9]{2})-00/", $birthDate, $matches) > 0)
                $birthDate = "00" == $matches[2] ? $matches[1] : "{$matches[1]}-{$matches[2]}";
            if (strlen ($player["birthdate"]) > strlen ($birthDate))
                $nameValuePairs[Sports::COL_PERSON_BIRTHDATE] = Language::getInstance($context)->parseDate ($player["birthdate"]);

            if (!empty ($player["height"]) && empty ($row["c_".Sports::COL_PERSON_HEIGHT]))
                $nameValuePairs[Sports::COL_PERSON_HEIGHT] = $player["height"];
            if (!empty ($player["weigth"]) && empty ($row["c_".Sports::COL_PERSON_WEIGHT]))
                $nameValuePairs[Sports::COL_PERSON_WEIGHT] = $player["weigth"];

            if (empty ($nameValuePairs))
                continue;

            $nameValuePairs[DBTable::COL_SOURCE] = $this->source;
            $nameValuePairs[DBTable::COL_SOURCEDATE] = $this->sourceDate;
            
            $affected = $playersTable->updateRecord (array (new EqCriterion ($playersTable->getIdColumn (), $row[$playersTable->getIdColumn ()])),
                                                     $nameValuePairs);
            if (1 !== $affected)
                $this->logError ("Error modifying player instance");
            else
                {
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $playersTable, $playersTable->getId (), $row[$playersTable->getIdColumn ()]);
                printf ("Updated <a href=\"%s\">%s</a>\n<br>", $url, $player["name"]);
                }
            }
        }

    public function createSourceFields ()
        {
        parent::createSourceFields ();
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        if (empty ($this->competitionField))
            {
            $seasonColumn = $dbtable->findColumn ("cstage");
            $this->competitionField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $seasonColumn);
            }
        if (empty ($this->teamField))
            {
            $teamColumn = $dbtable->findColumn ("hometeam");
            $this->teamField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $teamColumn);
            }
        if (empty ($this->dateField))
            {
            $this->dateField = new DateFieldTemplate ("", Sports::COL_REGISTRATION_DATE, $this->getText ("Registration date:"), $this->getText ("Player registration date"));
            }
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ($this->getText ("Competition player registration"));
        return true;
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();

        $listType = new DropDownFieldTemplate ("", "type", $this->getText ("Type:"), $this->getText ("List type"),
                                             array (SportsConstants::REGISTRATION_A => $this->getText ("Primary list|registration"),
                                                    SportsConstants::REGISTRATION_B => $this->getText ("Youth team|registration"),
                                                    ));

        $arr = array
            (
            $this->competitionField,
            $this->teamField,
            $listType,
            new LabelTemplate ($this->getText ('Enter the list of registered players'), "", true),
            new LongTextFieldTemplate ("", "parse", $this->getText ("Registration list:"), $this->getText ("Registration list")),
            new DateFieldTemplate ("", Sports::COL_REGISTRATION_DATE, $this->getText ("Registration date:"), $this->getText ("Player registration date")),
            new CheckBoxFieldTemplate ("", Sports::COL_REGISTRATION_NUMBERFIXED, $this->getText ("Fixed numbers:"), $this->getText ("Same number will be used in all competition games")),
            );

        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));
        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }
    }

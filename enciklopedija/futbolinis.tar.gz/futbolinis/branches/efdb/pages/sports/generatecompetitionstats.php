<?php
require_once (PATH.'pages/submit.php');
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'inc/sports/common.php');

class GenerateCompetitionStats extends Submit
    {
    protected $dbtable;
    protected $cachedFields = NULL;
    
    public function __construct ($context, $request)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $context->addScriptFile ("autosuggest");
        parent::__construct ($context, NULL, Constants::TABLES_USER, Sports::TABLE_MATCH);
        }

    protected function checkAccess ($request)
        {
        if (!empty ($this->dbtable))
            return $this->dbtable->canCreate ();
        return true;
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ("Advanced competition statistics");
        return true;
        }

    public function collectInputData ($context, &$request)
        {
        if (empty ($request[Sports::COL_MATCH_COMPETITION]) && empty ($request[Sports::COL_MATCH_HOMETEAM]))
            return array ();

        return array ("check" => isset ($request["skip"]), "full" => isset ($request["full"]),
                      Sports::COL_MATCH_COMPETITION => $request[Sports::COL_MATCH_COMPETITION],
                      Sports::COL_MATCH_HOMETEAM => $request[Sports::COL_MATCH_HOMETEAM]);
        }

    public function validateInput ($context, &$input)
        {
        if (empty ($input["check"]))
            return true;

        $competitionsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        if (empty ($competitionsTable))
            return false;

        $competitionCriteria = array();
        if (!empty ($input[Sports::COL_MATCH_COMPETITION]))
            {
            $competitionId = array ($input[Sports::COL_MATCH_COMPETITION]);
            $competitionIdColumn = "f_".Sports::COL_MATCH_COMPETITION."_".$competitionsTable->getIdColumn();
            $ids = SportsHelper::selectCompetitionHierarchyIds ($context, $competitionsTable, $competitionId);
            $competitionCriteria[] = new InCriterion ($competitionIdColumn, $ids);
            }

        $teamId = NULL;
        if (!empty ($input[Sports::COL_MATCH_HOMETEAM]))
            {
            $teamId = $input[Sports::COL_MATCH_HOMETEAM];
            $criterion = new LogicalOperatorOr (new EqCriterion (Sports::COL_MATCH_HOMETEAM, $teamId),
                                                new EqCriterion (Sports::COL_MATCH_AWAYTEAM, $teamId));
            $competitionCriteria[] = $criterion;
            }

        $rows = $this->checkIncompleteGoals ($context, $competitionCriteria);
        $this->printGamesList ($context, $rows, $this->getText ("Matches with incomplete or incorrect goal scorers"));

        $rows = $this->checkStadiums ($context, $competitionCriteria, true);
        $this->printGamesList ($context, $rows, $this->getText ("Matches with stadium information not set"));

        $rows = $this->checkStadiums ($context, $competitionCriteria, false);
        $this->printGamesList ($context, $rows, $this->getText ("Matches with attendance information not set"));

        $rows = $this->checkAbnormalOutcome ($context, $competitionCriteria);
        $this->printGamesList ($context, $rows, $this->getText ("Matches with abnormal outcome"));

        if (!empty ($input["full"]))
            {
            $rows = $this->checkIncompleteCards ($context, $competitionCriteria);
            $this->printGamesList ($context, $rows, $this->getText ("Matches with incomplete yellow card cause information"));

            $rows = $this->checkIncompleteReferees ($context, $competitionCriteria);
            $this->printGamesList ($context, $rows, $this->getText ("Matches with missing or incomplete referee information"));

            $rows = $this->checkIncompletePlayers ($context, $competitionCriteria);
            $this->printGamesList ($context, $rows, $this->getText ("Matches with incomplete player information"));

            $rows = $this->checkPlayersWithoutBirthDate ($context, $competitionCriteria, $teamId);
            $this->printPersonList ($context, $rows, $this->getText ("Players without a birth date set"));

            // check goal scorers who did not play in the match
            $rows = $this->checkScorersNotRegisteredInMatch ($context, $competitionCriteria, false);
            $this->printGamesList ($context, $rows, $this->getText ("Matches with incorrect goal scorers information"));
            $rows = $this->checkScorersNotRegisteredInMatch ($context, $competitionCriteria, true);
            $this->printGamesList ($context, $rows, $this->getText ("Matches with incorrect goal assist information"));
            $rows = $this->checkEventsOfPlayerNotRegisteredInMatch ($context, $competitionCriteria, false);
            $this->printGamesList ($context, $rows, $this->getText ("Matches with incorrect event information (cards recieved by player which was not on the field)"));
            $rows = $this->checkEventsOfPlayerNotRegisteredInMatch ($context, $competitionCriteria, true);
            $this->printGamesList ($context, $rows, $this->getText ("Matches with incorrect event information (event time not entered)"));

            // check card recievers who did not play in the match
            }

        return true;
        }

    public function saveInput ($context, &$request, &$results)
        {
        if (empty ($results[Sports::COL_MATCH_COMPETITION]))
            return true;
        $competitionId = $results[Sports::COL_MATCH_COMPETITION];
        $teamId = NULL;
        if (!empty ($results[Sports::COL_MATCH_HOMETEAM]))
            $teamId = $results[Sports::COL_MATCH_HOMETEAM];

        echo $this->getText ("Competition statistics:")."<br><ul>";
        $statsTypes = array ();
        $statsTypes["playercards"] = $this->getText ("Cards by player");
        $statsTypes["goals"] = $this->getText ("Goal scorers and statistis");
        $statsTypes["teamcards"] = $this->getText ("Cards by team");
        $statsTypes["referees"] = $this->getText ("Referees");
        $statsTypes["players"] = $this->getText ("All players");
        $statsTypes["playerssorted"] = $this->getText ("Players by time, games, etc.");
        $statsTypes["teamplayers"] = $this->getText ("Team players (totals, youngest, oldest)");
        $statsTypes["stadia"] = $this->getText ("Attendance and stadium statistics");

        foreach ($statsTypes as $statsKey => $label)
            {
            $params = "stats=$statsKey";
            if (!empty ($teamId))
                $params .= "&teamid=$teamId";
            echo "<li><a href=\"".$context->chooseUrl ("stats/competitionstage/{$competitionId}", "index.php?c=ContentPage&mode=stats&tn=".Sports::TABLE_COMPETITIONSTAGE."&id={$competitionId}", $params)."\">$label</a></li>";
            }
        echo "</ul>";
        }


    public function printGamesList ($context, $rows, $label)
        {
        if (empty ($rows))
            {
            if (false === $rows)
                echo $this->getText ("Error selecting [_0].", $label)."<br>\n";
            else
                echo $this->getText ("No [_0].", $label), "<br>\n";
            }
        else
            {
            echo $label." (".$this->ngettext ("[_0] match", "[_0] matches", count ($rows))."):<br><ul>\n";
            $outcomeColumn = $this->dbtable->findColumn (Sports::COL_MATCH_OUTCOME);
            $cnt = 0;
            foreach ($rows as $row)
                {
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                             $this->dbtable->getId (),
                                                                             $row[$this->dbtable->getIdColumn ()]);
                $label = $row[ContentTable::COL_DISPLAY_NAME];
                $outcome = NamedIntColumn::getItem ($outcomeColumn, $row["c_".Sports::COL_MATCH_OUTCOME]);
                echo "<li><a href=\"$url\">$label</a> ($outcome)</li>\n";
                if (++$cnt >= 50)
                    {
                    echo "<li>...</li>\n";
                    break;
                    }
                }
            echo "</ul>\n";
            }
        }

    public function printPersonList ($context, $rows, $label)
        {
        if (empty ($rows))
            {
            if (false === $rows)
                echo $this->getText ("Error selecting [_0].", $label)."<br>\n";
            else
                echo $this->getText ("No [_0].", $label), "<br>\n";
            }
        else
            {
            $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
            echo $label." (".$this->ngettext ("[_0] person", "[_0] persons", count ($rows))."):<br><ul>\n";
            $cnt = 0;
            foreach ($rows as $row)
                {
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $personsTable,
                                                                             $personsTable->getId (),
                                                                             $row[$personsTable->getIdColumn ()]);
                $label = $row[ContentTable::COL_DISPLAY_NAME];
                echo "<li><a href=\"$url\">$label</a></li>\n";
                if (++$cnt >= 50)
                    {
                    echo "<li>...</li>\n";
                    break;
                    }
                }
            echo "</ul>\n";
            }
        }

    protected function checkIncompleteGoals ($context, $competitionCriteria)
        {
        $goalsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHGOAL);
        if (empty ($goalsTable))
            return false;

        $criteria = array (new JoinColumnsCriterion ($this->dbtable->getIdColumn (), $this->dbtable->getIdColumn ()));
        $columns = array (new ConditionalSumColumn ("cntH", "c_".Sports::COL_GOAL_HOME." IS NOT NULL AND c_".Sports::COL_GOAL_HOME." = 1", 1, 0),
                          new ConditionalSumColumn ("cntA", "c_".Sports::COL_GOAL_HOME." IS NOT NULL AND c_".Sports::COL_GOAL_HOME." = 0", 1, 0));
        $goalsQuery = $goalsTable->createQuery ($columns, $criteria);
        $goalsQuery->joinType = Constants::JOIN_LEFT_OUTER;
        $joins = array ($goalsQuery);
        
        $criteria = $competitionCriteria;
        $columns = array ($this->dbtable->getIdColumn (), Sports::COL_MATCH_DATE,
                          Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT, Sports::COL_MATCH_OUTCOME);
        $params = array (new GroupByAll (), new HavingCriteria ("cntH <> `c_homeresult` OR cntA <> `c_awayresult`"));
        $rows = $this->dbtable->selectWithDisplayName ($columns, $criteria, $joins, $params);

        return $rows;
        }

    protected function checkAbnormalOutcome ($context, $competitionCriteria)
        {
        $criteria = $competitionCriteria;
        $columns = array ($this->dbtable->getIdColumn (), Sports::COL_MATCH_DATE,
                          Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT, Sports::COL_MATCH_OUTCOME);
        $criteria[] = new LogicalOperatorOr (new EqCriterion ("c_".Sports::COL_MATCH_EXCLUDED, 1),
                                                 new NotInCriterion ("c_".Sports::COL_MATCH_OUTCOME, array (MatchConstants::OUTCOME_FULL_TIME,
                                                                  MatchConstants::OUTCOME_EXTRA_TIME, MatchConstants::OUTCOME_PENALTIES,
                                                                  MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                                                  MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT)));
        $rows = $this->dbtable->selectWithDisplayName ($columns, $criteria);

        return $rows;
        }

    protected function checkStadiums ($context, $competitionCriteria, $stadiumSet)
        {
        $criteria = $competitionCriteria;
        $columns = array ($this->dbtable->getIdColumn (), Sports::COL_MATCH_DATE,
                          Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT, Sports::COL_MATCH_OUTCOME);
        if ($stadiumSet)
            $criteria[] = new IsNullCriterion ("f_".Sports::COL_MATCH_STADIUM."_".Sports::TABLE_STADIUM."_id");
        else
            $criteria[] = new IsNullCriterion ("c_".Sports::COL_MATCH_SPECTATORS);
        $rows = $this->dbtable->selectWithDisplayName ($columns, $criteria);

        return $rows;
        }

    protected function checkIncompleteCards ($context, $competitionCriteria)
        {
        $eventsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHEVENT);
        if (empty ($eventsTable))
            return false;

        $criteria = array (new JoinColumnsCriterion ($this->dbtable->getIdColumn (), $this->dbtable->getIdColumn ()),
                           new InCriterion ("c_".Sports::COL_EVENT_TYPE, array (MatchConstants::EVENT_YELLOW, MatchConstants::EVENT_YELLOW_RED)),
                           new LogicalOperatorOr (new IsNullCriterion (Sports::COL_EVENT_CAUSE), new EqCriterion (Sports::COL_EVENT_CAUSE, 0)),
                           );
        $eventsQuery = $eventsTable->createQuery (array (new FunctionCount ("*", "cnt")), $criteria);
        $eventsQuery->joinType = Constants::JOIN_LEFT_OUTER;
        $joins = array ($eventsQuery);
        
        $criteria = $competitionCriteria;
        $columns = array ($this->dbtable->getIdColumn (), Sports::COL_MATCH_DATE,
                          Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT, Sports::COL_MATCH_OUTCOME);
        $params = array (new GroupByAll ());
        $rows = $this->dbtable->selectWithDisplayName ($columns, $criteria, $joins, $params);
        return $rows;
        }
        
    protected function checkIncompleteReferees ($context, $competitionCriteria)
        {
        $refereesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHREFEREE);
        if (empty ($refereesTable))
            return false;

        $criteria = array (new JoinColumnsCriterion ($this->dbtable->getIdColumn (), $this->dbtable->getIdColumn ()));
        $columns = array (new FunctionCount ("*", "cnt"),
                          new ConditionalSumColumn ("cntCat", "tbl2.c_".Sports::COL_REFEREE_CATEGORY." IS NOT NULL AND tbl2.c_".Sports::COL_REFEREE_CATEGORY." > 0", 1, 0));
        $refereeQuery = $refereesTable->createQuery ($columns, $criteria);
        $refereeQuery->joinType = Constants::JOIN_LEFT_OUTER;
        $joins = array ($refereeQuery);
        
        $criteria = $competitionCriteria;
        $criteria[] = new NotInCriterion ("c_".Sports::COL_MATCH_OUTCOME, array (MatchConstants::OUTCOME_NOT_STARTED));
        $columns = array ($this->dbtable->getIdColumn (), Sports::COL_MATCH_DATE,
                          Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT, Sports::COL_MATCH_OUTCOME);
        $params = array (new GroupByAll (), new HavingCriteria ("cnt < 4 OR cntCat < 4"));
        $rows = $this->dbtable->selectWithDisplayName ($columns, $criteria, $joins, $params);
        return $rows;
        }

    protected function checkIncompletePlayers ($context, $competitionCriteria)
        {
        $playersTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHPLAYER);
        if (empty ($playersTable))
            return false;

        $criteria = array (new JoinColumnsCriterion ($this->dbtable->getIdColumn (), $this->dbtable->getIdColumn ()));
        $columns = array (new ConditionalSumColumn ("noEntered", "c_".Sports::COL_PLAYER_UNUSED."=0 AND c_".Sports::COL_PLAYER_FROM." IS NULL", 1, 0),
                          new ConditionalSumColumn ("noLeft", "c_".Sports::COL_PLAYER_UNUSED."=0 AND c_".Sports::COL_PLAYER_TO." IS NULL", 1, 0),
                          new ConditionalSumColumn ("startingSquad", "c_".Sports::COL_PLAYER_FROM."=0", 1, 0));
        $playersQuery = $playersTable->createQuery ($columns, $criteria);
        $playersQuery->joinType = Constants::JOIN_LEFT_OUTER;
        $joins = array ($playersQuery);
        
        $criteria = $competitionCriteria;
        $criteria[] = new InCriterion ("c_".Sports::COL_MATCH_OUTCOME, array (MatchConstants::OUTCOME_FULL_TIME,
                                                                              MatchConstants::OUTCOME_EXTRA_TIME, MatchConstants::OUTCOME_PENALTIES,
                                                                              MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                                                              MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $columns = array ($this->dbtable->getIdColumn (), Sports::COL_MATCH_DATE,
                          Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT, Sports::COL_MATCH_OUTCOME);
        $params = array (new GroupByAll (), new HavingCriteria ("startingSquad <>22 OR noEntered > 0 OR noLeft > 0"));
        $rows = $this->dbtable->selectWithDisplayName ($columns, $criteria, $joins, $params);
        return $rows;
        }

    protected function checkPlayersWithoutBirthDate ($context, $competitionCriteria, $teamId)
        {
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        $playersTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHPLAYER);
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        if (empty ($playersTable) || empty ($personsTable) || empty ($teamsTable))
            return false;

        $invert = false;
        $homeTeamColumn = "f_".Sports::COL_MATCH_HOMETEAM."_".$teamsTable->getIdColumn ();
        $awayTeamColumn = "f_".Sports::COL_MATCH_AWAYTEAM."_".$teamsTable->getIdColumn ();
        $isHomeCondition = "c_".Sports::COL_PLAYER_ISHOME."=".($invert ? 0 : 1);

        $criteria = $competitionCriteria;
        $criteria[] = new InCriterion ("c_".Sports::COL_MATCH_OUTCOME, array (MatchConstants::OUTCOME_FULL_TIME,
                                                                              MatchConstants::OUTCOME_EXTRA_TIME, MatchConstants::OUTCOME_PENALTIES,
                                                                              MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                                                              MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $criteria[] = new JoinColumnsCriterion ($this->dbtable->getIdColumn (), $this->dbtable->getIdColumn ());
        $columns = array ();
        if ($teamId > 0)
            $columns[] = new ConditionalResultColumn ("teamid", $isHomeCondition, $homeTeamColumn, $awayTeamColumn);
        $matchQuery = $this->dbtable->createQuery ($columns, $criteria);
        
        $criteria = array ();
        $personColumn = "f_".Sports::COL_PLAYER_PERSON."_".$personsTable->getIdColumn ();
        $criteria[] = new JoinColumnsCriterion ($personsTable->getIdColumn (), $personColumn);
        $criteria[] = new EqCriterion (Sports::COL_PLAYER_UNUSED, 0);
        $columns = array ();
        $playersQuery = $playersTable->createQuery ($columns, $criteria, array ($matchQuery));
        $joins = array ($playersQuery);

        $criteria = array ();
        $criteria[] = new DayIsEmptyCriteria ("c_".Sports::COL_PERSON_BIRTHDATE);

        $columns = array ($personsTable->getIdColumn ());
        $params = array (new GroupByAll ());
        if ($teamId > 0)
            $params[] = new HavingCriteria ("teamid = $teamId");
        $rows = $personsTable->selectWithDisplayName ($columns, $criteria, $joins, $params);        
        return $rows;
        }

    protected function checkPlayersNotRegisteredInMatch ($context, $tableName, $columnName, $competitionCriteria, $joinCriteria, $additionalCriterion, $filterByEmptyRightSide = true)
        {
        $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
        $playersTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHPLAYER);
        $scorersTable = ContentTable::createInstanceByName ($this->context, $tableName);
        if (empty ($playersTable) || empty ($personsTable) || empty ($scorersTable))
            return false;

        $personColumn = "f_".Sports::COL_PLAYER_PERSON."_".$personsTable->getIdColumn ();
        $scorerColumn = "f_{$columnName}_".$personsTable->getIdColumn ();
        $criteria = $joinCriteria;
        $criteria[] = new JoinColumnsCriterion ($this->dbtable->getIdColumn (), $this->dbtable->getIdColumn ());
        $criteria[] = new JoinColumnsCriterion ($scorerColumn, $personColumn);
        if ($filterByEmptyRightSide)
            $criteria[] = new IsNullCriterion ($personColumn);
        $columns = array ();
        $playersQuery = $playersTable->createQuery ($columns, $criteria);
        $playersQuery->joinType = Constants::JOIN_LEFT_OUTER;

        $criteria = $additionalCriterion;
        $criteria[] = new JoinColumnsCriterion ($this->dbtable->getIdColumn (), $this->dbtable->getIdColumn ());
        
        $columns = array ();
        $goalsQuery = $scorersTable->createQuery ($columns, $criteria, array ($playersQuery));
        $joins[] = $goalsQuery;
        
        $criteria = $competitionCriteria;
        $criteria[] = new InCriterion ("c_".Sports::COL_MATCH_OUTCOME, array (MatchConstants::OUTCOME_FULL_TIME,
                                                                              MatchConstants::OUTCOME_EXTRA_TIME, MatchConstants::OUTCOME_PENALTIES,
                                                                              MatchConstants::OUTCOME_PENALTIES_HOME, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                                                              MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $columns = array ($this->dbtable->getIdColumn (), Sports::COL_MATCH_DATE,
                          Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT, Sports::COL_MATCH_OUTCOME);
        $params = array (new GroupByAll ());
        $rows = $this->dbtable->selectWithDisplayName ($columns, $criteria, $joins, $params);
        return $rows;
        }

    protected function checkScorersNotRegisteredInMatch ($context, $competitionCriteria, $assists = false)
        {
        $joinCriteria[] = new JoinBetweenCriterion ("c_".Sports::COL_GOAL_TIME_MIN, "c_".Sports::COL_PLAYER_FROM, "c_".Sports::COL_PLAYER_TO, true);
        if ($assists)
            $joinCriteria[] = new JoinColumnsCriterion ("c_".Sports::COL_GOAL_HOME, "c_".Sports::COL_PLAYER_ISHOME);
        else
            $joinCriteria[] = new JoinHomeColumnsCriterion ("c_".Sports::COL_GOAL_HOME, "c_".Sports::COL_PLAYER_ISHOME);

        $columnName = $assists ? Sports::COL_GOAL_ASSIST : Sports::COL_GOAL_SCORER;
        $additionalCriteria = NULL;
        if ($assists)
            {
            $scorerColumn = "f_{$columnName}_".Sports::TABLE_PERSON."_id";
            $additionalCriteria[] = new IsNotNullCriterion ($scorerColumn);
            }

        return $this->checkPlayersNotRegisteredInMatch ($context, Sports::TABLE_MATCHGOAL,
                                                        $columnName, $competitionCriteria,
                                                        $joinCriteria, $additionalCriteria);
        }

    protected function checkEventsOfPlayerNotRegisteredInMatch ($context, $competitionCriteria, $emptyTime)
        {
        $criteria = NULL;
        if ($emptyTime)
            $criteria[] = new IsNullCriterion ("c_".Sports::COL_EVENT_TIME_MIN);
        else
            $joinCriteria[] = new JoinBetweenCriterion ("c_".Sports::COL_EVENT_TIME_MIN, "c_".Sports::COL_PLAYER_FROM, "c_".Sports::COL_PLAYER_TO, true);
        $joinCriteria[] = new JoinColumnsCriterion ("c_".Sports::COL_EVENT_ISHOME, "c_".Sports::COL_PLAYER_ISHOME);
        return $this->checkPlayersNotRegisteredInMatch ($context, Sports::TABLE_MATCHEVENT,
                                                        Sports::COL_EVENT_PLAYER, $competitionCriteria,
                                                        $joinCriteria, $criteria, !$emptyTime);
        }


    public function getSaveButtonLabel ()
        {
        return $this->getText ("Statistics|generate");
        }

    protected function processInputFields ($context, &$request)
        {
        $fields = $this->getFields ();
        foreach ($fields as $field)
            $field->processInput ($context, $request);
        parent::processInputFields ($context, $request);
        }

    public function getFields ()
        {
        if (!empty ($this->cachedFields))
            return $this->cachedFields;
        if (empty ($this->dbtable))
            return NULL;

        $column = clone $this->dbtable->findColumn (Sports::COL_MATCH_COMPETITION);
        $column->label = $this->getText ("Target competition:");
        $competitionField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
        $column = clone $this->dbtable->findColumn (Sports::COL_MATCH_HOMETEAM);
        $column->label = $this->getText ("Target team:");
        $teamField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
        $description = $this->getText ('Select a competition and click "Check" to check for common error or click "Save" to generate advanced statistics');
        $this->cachedFields = array
            (
            new LabelTemplate ($description, "", true),
            $competitionField,
            $teamField,
            new CheckBoxFieldTemplate ("", "full", $this->getText ("Full protocols:"), $this->getText ("Full protocols (with yellow card cause, etc) are expected to be filed for the competition matches.")),
            );
        return $this->cachedFields;
        }
        
    }

class JoinBetweenCriterion extends JoinCriterion
    {
    public $parentColumn;
    public $childColumnMin;
    public $childColumnMax;
    protected $allowNull;

    public function __construct ($parentColumn, $childColumnMin, $childColumnMax, $allowNull = false)
        {
        $this->parentColumn = $parentColumn;
        $this->childColumnMin = $childColumnMin;
        $this->childColumnMax = $childColumnMax;
        $this->allowNull = $allowNull;
        }

    public function formatForDB ($dbconnection, $parentTableAlias, $childTableAlias)
        {
        if (NULL != $childTableAlias)
            $childTableAlias .= ".";
        if (NULL != $parentTableAlias)
            $parentTableAlias .= ".";
        $parentColumn = $parentTableAlias.$dbconnection->prepareColumnName ($this->parentColumn);
        $childColumnMin = $childTableAlias.$dbconnection->prepareColumnName ($this->childColumnMin);
        $childColumnMax = $childTableAlias.$dbconnection->prepareColumnName ($this->childColumnMax);
        if ($this->allowNull)
            return "($parentColumn IS NULL OR $parentColumn between {$childColumnMin} and {$childColumnMax})";
        return "$parentColumn between {$childColumnMin} and {$childColumnMax}";
        }
    }

class JoinHomeColumnsCriterion extends JoinColumnsCriterion
    {
    public $parentColumn;
    public $childColumn;

    public function __construct ($goalsTableColumn, $playersTableColumn)
        {
        $this->parentColumn = $goalsTableColumn;
        $this->childColumn = $playersTableColumn;
        }

    public function formatForDB ($dbconnection, $parentTableAlias, $childTableAlias)
        {
        if (NULL != $parentTableAlias)
            $parentTableAlias .= ".";
        if (NULL != $childTableAlias)
            $childTableAlias .= ".";
            
        $parentColumn = $parentTableAlias.$dbconnection->prepareColumnName ($this->parentColumn);
        $childColumn = $childTableAlias.$dbconnection->prepareColumnName ($this->childColumn);
        $ownGoalColumn = $parentTableAlias.$dbconnection->prepareColumnName ("c_".Sports::COL_GOAL_OWN);

        return "(($ownGoalColumn=1 and $parentColumn<>$childColumn) or ($ownGoalColumn=0 and $parentColumn=$childColumn))";
        }
    }

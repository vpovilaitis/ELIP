<?php
require_once (PATH."pages/sports/leagueplayerstats.php");

class RefereeRatings extends LeaguePlayerStats
    {
    protected $maxItems;

    public function __construct ($context, $leagueId, $maxItems = NULL)
        {
        $this->maxItems = $maxItems;
        parent::__construct ($context, Sports::TABLE_MATCHREFEREE, $leagueId, true);
        }

    protected function getColumnName ()
        {
        return Sports::COL_REFEREE_PERSON;
        }

    public function getTitle ()
        {
        return $this->getText ("Referee ratings");
        }

    protected function getHomeTeamColumnName ()
        {
        return NULL;
        }

    protected function getDisplayTemplate ()
        {
        $playerColumn = $this->dbtable->findColumn (Sports::COL_REFEREE_PERSON);
        return array
            (
            new LabelRelationFieldTemplate ($this->context, "i", $playerColumn),
            new RefereeRatingField ($this->context, "i")
            );
        }

    public function getFullListUrl ()
        {
        $leagueId = $this->leagueId[0];
        return $this->context->chooseUrl ("stats/".Sports::TABLE_COMPETITIONSTAGE."/$leagueId",
                                          "index.php?c=ContentPage&mode=stats&tn=".Sports::TABLE_COMPETITIONSTAGE."&id=$leagueId",
                                          "stats=refrating");
        }

    protected function getMaxItemCount ()
        {
        return 200;
        }

    public function select ($context, $criteria = NULL)
        {
        $rows = parent::select ($context, $criteria);
        if (!empty ($rows))
            {
            uasort ($rows, array("RefereeRatings", "compareByRating"));
            foreach ($rows as &$row)
                {
                if (!empty ($row["referee.c_".Sports::COL_PERSON_FIRST_NAME]) && !empty ($row["referee.c_".Sports::COL_PERSON_SURNAME]))
                    $row["referee.".ContentTable::COL_DISPLAY_NAME] = $row["referee.c_".Sports::COL_PERSON_FIRST_NAME]." ".$row["referee.c_".Sports::COL_PERSON_SURNAME];
                }
            if (count ($rows) > $this->maxItems)
                return array_slice ($rows, 0, $this->maxItems);
            }

        return $rows;
        }

    public static function compareByRating ($a, $b)
        {
        $ratingA = $a["homeCnt"] + $a["awayCnt"] > 0 ? ($a["homeSum"] + $a["awaySum"]) / ($a["homeCnt"] + $a["awayCnt"]) : 0;
        $ratingB = $b["homeCnt"] + $b["awayCnt"] > 0 ? ($b["homeSum"] + $b["awaySum"]) / ($b["homeCnt"] + $b["awayCnt"]) : 0;
        return $ratingB > $ratingA ? 1 : ($ratingB < $ratingA ? -1 : 0);
        }

    }

class RefereeRatingField extends LabelIntFieldTemplate
    {
    public function __construct ($context, $prefix)
        {
        parent::__construct ($prefix, "cnt", $context->getText ("Goals"));
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        $resultColumns[] = new ConditionalSumColumn ("homeSum", "c_".Sports::COL_REFEREE_RATED_BY_HOME." > 0", "c_".Sports::COL_REFEREE_RATED_BY_HOME, 0);
        $resultColumns[] = new ConditionalSumColumn ("homeCnt", "c_".Sports::COL_REFEREE_RATED_BY_HOME." > 0", 1, 0);
        $resultColumns[] = new ConditionalSumColumn ("awaySum", "c_".Sports::COL_REFEREE_RATED_BY_AWAY." > 0", "c_".Sports::COL_REFEREE_RATED_BY_AWAY, 0);
        $resultColumns[] = new ConditionalSumColumn ("awayCnt", "c_".Sports::COL_REFEREE_RATED_BY_AWAY." > 0", 1, 0);
        $resultColumns[] = new ConditionalSumColumn ("cnt", "c_".Sports::COL_REFEREE_RATED_BY_AWAY." > 0 OR c_".Sports::COL_REFEREE_RATED_BY_HOME." > 0", 1, 0);
        }

    public function getValueForDisplay ($context, $row)
        {
        $lng = Language::getInstance ($context);
        if ($row["homeCnt"] + $row["awayCnt"] > 0)
            return $lng->decimalToString (($row["homeSum"] + $row["awaySum"]) / ($row["homeCnt"] + $row["awayCnt"]), 1);
        else
            return NULL;
        }

    }
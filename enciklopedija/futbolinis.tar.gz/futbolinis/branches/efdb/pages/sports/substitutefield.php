<?php
require_once (PATH.'pages/sports/relatedrecordfield.php');

class SubstituteField extends RelatedRecordField
    {
    protected $isHomePlayer;
    protected $rowIndex;
    const COL_PLAYER_NO_SUBST = "substitute_no";

    public function __construct ($context, $prefix, $label, $tooltip, $isHome, $index)
        {
        $key = self::getKey ($isHome, $index);

        parent::__construct ($context, $prefix, $key, Sports::TABLE_MATCHPLAYER, $label, $tooltip);

        $this->columns = array (Sports::COL_PLAYER_FROM, Sports::COL_PLAYER_NO, self::COL_PLAYER_NO_SUBST);
        $this->tableName = $context->getText ("Match players");
        $this->isHomePlayer = $isHome;
        $this->rowIndex = $index;
        }

    public static function getKey ($isHome, $index)
        {
        return "subst_".($isHome ? "home" : "away")."_".$index;
        }

    public function prepareSubstitutes ($playerRows)
        {
        $homeColumn = ContentTable::prepareUserColumnName (Sports::COL_PLAYER_ISHOME);
        $numberColumn = ContentTable::prepareUserColumnName (Sports::COL_PLAYER_NO);
        $toColumn = ContentTable::prepareUserColumnName (Sports::COL_PLAYER_TO);
        $fromColumn = ContentTable::prepareUserColumnName (Sports::COL_PLAYER_FROM);
        $extraColumn = ContentTable::prepareUserColumnName (Sports::COL_PLAYER_EXTRA);

        $homePlayers = array ();
        $awayPlayers = array ();
        $rowById = array ();
        foreach ($playerRows as $rows)
            {
            foreach ($rows as $singleRow)
                {
                $number = $singleRow[$numberColumn];
                if (0 == $number)
                    $number = $singleRow[Sports::COL_PLAYER_PERSON][0];
    
                if ($singleRow[$homeColumn])
                    {
                    $homePlayers[$singleRow[Sports::COL_PLAYER_PERSON][0]] = $number;
                    }
                else
                    {
                    $awayPlayers[$singleRow[Sports::COL_PLAYER_PERSON][0]] = $number;
                    }
    
                $rowById[$singleRow[Sports::COL_PLAYER_PERSON][0]] = $singleRow;
                }
            }

        $homeSubstitutions = array ();
        $awaySubstitutions = array ();
        foreach ($playerRows as $rows)
            {
            foreach ($rows as $singleRow)
                {
                $substitutedBy = $singleRow[Sports::COL_PLAYER_SUBSTITUTED_BY];
                if (empty ($substitutedBy))
                    continue;
    
                $number = $singleRow[$numberColumn];
                $to = $singleRow[$toColumn];
                $row = array (Sports::COL_PLAYER_FROM => $to, Sports::COL_PLAYER_NO => $number);
    
                $substituteRow = $rowById[$substitutedBy[0]];
                if (!empty ($substituteRow[$fromColumn]) && !empty ($substituteRow[$extraColumn]))
                    $row[Sports::COL_PLAYER_FROM] = $substituteRow[$fromColumn]."+".$substituteRow[$extraColumn];
                
                if ($singleRow[$homeColumn])
                    {
                    if (empty ($homePlayers[$substitutedBy[0]]))
                        continue;
                    $row[Sports::COL_PLAYER_NO] = $homePlayers[$singleRow[Sports::COL_PLAYER_PERSON][0]];
                    $row[self::COL_PLAYER_NO_SUBST] = $homePlayers[$substitutedBy[0]];
                    $homeSubstitutions[] = $row;
                    }
                else
                    {
                    if (empty ($awayPlayers[$substitutedBy[0]]))
                        continue;
                    $row[Sports::COL_PLAYER_NO] = $awayPlayers[$singleRow[Sports::COL_PLAYER_PERSON][0]];
                    $row[self::COL_PLAYER_NO_SUBST] = $awayPlayers[$substitutedBy[0]];
                    $awaySubstitutions[] = $row;
                    }
                }
            }

        uasort ($homeSubstitutions, array("SubstituteField", "compare"));
        uasort ($awaySubstitutions, array("SubstituteField", "compare"));

        return array ($homeSubstitutions, $awaySubstitutions);
        }

    static function compare ($a, $b)
        {
        if ($b[Sports::COL_PLAYER_FROM] != $a[Sports::COL_PLAYER_FROM])
            return $a[Sports::COL_PLAYER_FROM] - $b[Sports::COL_PLAYER_FROM];

        return $a[Sports::COL_PLAYER_NO] - $b[Sports::COL_PLAYER_NO];
        }

    public function retrieveRecord ($context, $criteria, &$row, &$cache)
        {
        $row[$this->key] = NULL;

        if (!array_key_exists ("substitutes", $cache))
            {
            if (!array_key_exists (Sports::TABLE_MATCHPLAYER, $cache))
                return false;

            $playerRows = $cache[Sports::TABLE_MATCHPLAYER];
            if (empty ($playerRows))
                return;
            $cache["substitutes"] = $this->prepareSubstitutes ($playerRows);
            }

        list ($home, $away) = $cache["substitutes"];
        
        $arr = $this->isHomePlayer ? $home : $away;
        $i = 0;
        foreach ($arr as $singleRow)
            {
            if ($this->rowIndex != $i++)
                continue;

            $row[$this->key] = $singleRow;
            return;
            }
        }

    public function prepareForStoring ($context, &$values, $initialValues, &$prepared)
        {
        $initialValue = !empty ($initialValues) ? $initialValues[$this->key] : NULL;
        $record = $values[$this->key];
        if (!empty ($record[Sports::COL_PLAYER_NO]))
            {
            if (empty ($record[self::COL_PLAYER_NO_SUBST]))
                {
                $context->addError ("Substitute player not defined");
                return false;
                }

            $number = $record[Sports::COL_PLAYER_NO];
            $key = $this->isHomePlayer ? "home" : "away";
            $key .= "_p_$number";
            if (!array_key_exists ($key, $prepared))
                {
                $context->addError ("Specified substitute number [_0] does not exist in the list", $number);
                return false;
                }
            $outKey = $prepared[$key];

            $number = $record[self::COL_PLAYER_NO_SUBST];
            $key = $this->isHomePlayer ? "home" : "away";
            $key .= "_p_$number";
            if (!array_key_exists ($key, $prepared))
                {
                $context->addError ("Specified substitute number [_0] does not exist in the list", $number);
                return false;
                }
            $inKey = $prepared[$key];

            if (!empty ($record[Sports::COL_PLAYER_FROM]))
                {
                $parts = explode ("+", $record[Sports::COL_PLAYER_FROM]);
                if (2 == count ($parts))
                    list ($record[Sports::COL_PLAYER_FROM], $prepared[$inKey][Sports::COL_PLAYER_EXTRA]) = $parts;
                }

            $prepared[$inKey][Sports::COL_PLAYER_TO] = $prepared[$outKey][Sports::COL_PLAYER_TO];
            $prepared[$outKey][Sports::COL_PLAYER_TO] = $record[Sports::COL_PLAYER_FROM];
            $prepared[$inKey][Sports::COL_PLAYER_FROM] = $record[Sports::COL_PLAYER_FROM];
            $prepared[$inKey][Sports::COL_PLAYER_UNUSED] = false;
            $prepared[$outKey][Sports::COL_PLAYER_SUBSTITUTED_BY] = $prepared[$inKey][Sports::COL_PLAYER_PERSON];
            }

        unset ($values[$this->key]);
        }

    public function createFields ()
        {
        $prefix = $this->getPrefix().$this->key;
        $context = $this->dbtable->getContext();

        $arr = array ();

        $minField = new IntFieldTemplate ($prefix, Sports::COL_PLAYER_FROM, "", $context->getText ("Minute"));
        $minField->cssClass = "playerno substitute-minute";
        $minField->size = 2;
        $arr[] = $minField;
        $arr[] = new LabelTemplate ($context->getText ("min."));

        $arr[] = new LabelTemplate ($context->getText ("Off:|player leaving the pitch"));
        $numberField = new IntFieldTemplate ($prefix, Sports::COL_PLAYER_NO, "", $context->getText ("Number of player leaving the pitch"));
        $numberField->cssClass = "playerno substitute-off";
        $numberField->size = 2;
        $arr[] = $numberField;

        $arr[] = new LabelTemplate ($context->getText ("On:|substitute"));
        $numberField = new IntFieldTemplate ($prefix, self::COL_PLAYER_NO_SUBST, "", $context->getText ("Number of player entering the pitch"));
        $numberField->cssClass = "playerno substitute-on";
        $numberField->size = 2;
        $arr[] = $numberField;

        return $arr;
        }

    }

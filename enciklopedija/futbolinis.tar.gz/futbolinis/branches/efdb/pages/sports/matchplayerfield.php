<?php
require_once (PATH.'pages/sports/relatedrecordfield.php');

class MatchPlayerField extends RelatedRecordField
    {
    protected $isHomePlayer;
    protected $isSubstitute;
    protected $rowIndex;
    const KEY_PLAYER_HOME = "home_player_";
    const KEY_PLAYER_HOME_SUBST= "home_splayer_";
    const KEY_PLAYER_AWAY = "away_player_";
    const KEY_PLAYER_AWAY_SUBST= "away_splayer_";

    public function __construct ($context, $prefix, $label, $tooltip, $isHome, $substitute, $index)
        {
        $key = self::getKey ($isHome, $substitute, $index);

        parent::__construct ($context, $prefix, $key, Sports::TABLE_MATCHPLAYER, $label, $tooltip);

        $this->columns = self::getColumns ();
        $this->tableName = $context->getText ("Match players");
        $this->isHomePlayer = $isHome;
        $this->isSubstitute = $substitute;
        $this->rowIndex = $index;
        }

    public static function getKey ($isHome, $substitute, $index)
        {
        if ($isHome)
            $key = $substitute ? self::KEY_PLAYER_HOME_SUBST : self::KEY_PLAYER_HOME;
        else
            $key = $substitute ? self::KEY_PLAYER_AWAY_SUBST : self::KEY_PLAYER_AWAY;

        return $key.$index;
        }

    public static function getColumns ()
        {
        return array (Sports::COL_PLAYER_NO, Sports::COL_PLAYER_PERSON,
                      Sports::COL_PLAYER_FROM, Sports::COL_PLAYER_TO, Sports::COL_PLAYER_ISHOME,
                      Sports::COL_PLAYER_CAPTAIN, Sports::COL_PLAYER_SUBSTITUTED_BY,
                      Sports::COL_PLAYER_UNUSED, Sports::COL_PLAYER_PRIORITY, Sports::COL_PLAYER_EXTRA);
        }

    public function prepareRow ($row, $additional = NULL)
        {
        $column = $this->dbtable->findColumn (Sports::COL_PLAYER_CAPTAIN);
        if ($row[$column->columnDef->name] == '')
            $row[$column->columnDef->name] = 0;
        $prepared = parent::prepareRow ($row);

        RelationAutocompleteField::cacheLabel ($prepared[Sports::COL_PLAYER_PERSON], $row[Sports::COL_PLAYER_PERSON.".".ContentTable::COL_DISPLAY_NAME]);
        return $prepared;
        }

    protected function addCriterionForUpdate (&$criteria, $column, $value, $deleting)
        {
        if (0 == $value && (Sports::COL_PLAYER_NO == $column || Sports::COL_PLAYER_POSITION == $column || Sports::COL_PLAYER_CAPTAIN == $column ||
                            Sports::COL_PLAYER_SUBSTITUTED_BY == $column || Sports::COL_PLAYER_UNUSED == $column ||
                            Sports::COL_PLAYER_FROM == $column || Sports::COL_PLAYER_TO == $column || Sports::COL_PLAYER_EXTRA == $column))
            {
            $criteria[] = new LogicalOperatorOr (new IsNullCriterion ($column), new EqCriterion ($column, 0));
            return false;
            }

        return parent::addCriterionForUpdate ($criteria, $column, $value, $deleting);
        }

    protected function isEmptyRecord ($context, $request)
        {
        return empty ($request[Sports::COL_PLAYER_PERSON]);
        }

    public function retrieveRecord ($context, $criteria, &$row, &$cache)
        {
        $row[$this->key] = NULL;

        if (!array_key_exists (Sports::TABLE_MATCHPLAYER, $cache))
            {
            self::getCount ($context, $row, $criteria, $cache);
            }

        list ($homePlayers, $homeSubstitutes, $awayPlayers, $awaySubstitutes) = $cache[Sports::TABLE_MATCHPLAYER];
        if ($this->isHomePlayer && $this->isSubstitute)
            $playerRows = $homeSubstitutes;
        else if ($this->isHomePlayer)
            $playerRows = $homePlayers;
        else if ($this->isSubstitute)
            $playerRows = $awaySubstitutes;
        else
            $playerRows = $awayPlayers;

        if (empty ($playerRows))
            return;

        $i = 0;
        foreach ($playerRows as $singleRow)
            {
            if ($this->rowIndex != $i++)
                continue;

            $row[$this->key] = $this->prepareRow ($singleRow);
            return;
            }
        }

    public function mapPlayerRecord (&$prepared, &$orphanPlayerMap, $playerNo, $initialPlayerNo)
        {
        $currentKey = $this->key;
        if ($playerNo > 0 && isset ($orphanPlayerMap[$playerNo]))
            {
            // found original record, lets steal it's ticket
            list ($targetPlayerNo, $key) = $orphanPlayerMap[$playerNo];
            $ticket = $prepared[$currentKey][self::KEY_TICKET];
            $prepared[$currentKey][self::KEY_TICKET] = $prepared[$key][self::KEY_TICKET];
            $prepared[$key][self::KEY_TICKET] = $ticket;

            unset ($orphanPlayerMap[$playerNo]);

            if ($initialPlayerNo == $targetPlayerNo) // perfect exchange - both tickets match altered players
                return;

            $playerNo = $targetPlayerNo;
            $currentKey = $key;
            }

        foreach ($orphanPlayerMap as $no => $mapRecord)
            {
            list ($targetPlayerNo, $key) = $mapRecord;
            if ($initialPlayerNo == $targetPlayerNo)
                {
                $ticket = $prepared[$currentKey][self::KEY_TICKET];
                $prepared[$currentKey][self::KEY_TICKET] = $prepared[$key][self::KEY_TICKET];
                $prepared[$key][self::KEY_TICKET] = $ticket;

                unset ($orphanPlayerMap[$no]);

                if ($playerNo == $no)
                    return;
                $initialPlayerNo = $no;
                break;
                }
            }

        if ($initialPlayerNo > 0)
            $orphanPlayerMap[$initialPlayerNo] = array ($playerNo, $currentKey);
        }

    public function prepareForStoring ($context, &$values, $initialValues, &$prepared)
        {
        $initialValue = !empty ($initialValues) ? $initialValues[$this->key] : NULL;
        $record = $values[$this->key];

        $record[Sports::COL_PLAYER_ISHOME] = $this->isHomePlayer;
        if (!$this->isSubstitute)
            {
            $record[Sports::COL_PLAYER_FROM] = 0;
            $record[Sports::COL_PLAYER_TO] = 90;
            }
        else
            $record[Sports::COL_PLAYER_FROM] = $record[Sports::COL_PLAYER_TO] = NULL;

        $record[Sports::COL_PLAYER_EXTRA] = NULL;
        $record[Sports::COL_PLAYER_SUBSTITUTED_BY] = NULL;
        $record[Sports::COL_PLAYER_UNUSED] = $this->isSubstitute;
        if (empty ($record[Sports::COL_PLAYER_CAPTAIN]))
            $record[Sports::COL_PLAYER_CAPTAIN] = 0;

        // set the prepared record to be stored later
        $prepared[$this->key] = $record;
        $prepared[$this->key."_initial"] = $record;

        // retrieve original and altered player ids
        $playerNo = $record[Sports::COL_PLAYER_PERSON];
        $initialPlayerNo = 0;
        $ticket = explode (self::TICKET_SEPARATOR, $record[self::KEY_TICKET]);
        if (count ($ticket) > 1)
            $initialPlayerNo = $ticket[1];

        if ($initialPlayerNo != $playerNo)
            {
            /* if player was moved to another spot, need to map records
                (not to mess the change history and to avoid "duplicate key"
                 database errors) */
            if (!isset ($prepared["orphanPlayerMap"]))
                $prepared["orphanPlayerMap"] = array ();

            $this->mapPlayerRecord ($prepared, $prepared["orphanPlayerMap"], $playerNo, $initialPlayerNo);
            }

        // store additional information, so substitution fields will be able to alter record
        $number = $record[Sports::COL_PLAYER_NO];
        $key = $this->isHomePlayer ? "home" : "away";
        $key .= "_p_".(empty ($number) ? $record[Sports::COL_PLAYER_PERSON] : $number);
        $prepared[$key] = $this->key;

        unset ($values[$this->key]);
        }

    protected function savePreparedRecord ($handler, &$request, &$prepared, $sourceValues)
        {
        $currentValue = $prepared[$this->key];
        $initialValue = $prepared[$this->key."_initial"];
        if (!$this->areValuesModified ($initialValue, $currentValue))
            return true;

        return parent::savePreparedRecord ($handler, $request, $prepared, $sourceValues);
        }

    public function createFields ()
        {
        $prefix = $this->getPrefix().$this->key;
        $context = $this->dbtable->getContext ();

        $arr = array ();

        $numberField = new IntFieldTemplate ($prefix, Sports::COL_PLAYER_NO, "", $context->getText ("Player number"));
        $numberField->cssClass = "playerno player-number";
        $numberField->size = 2;
        if ($this->isSubstitute)
            $numberField->cssClass .= " substitute";
        $arr[] = $numberField;

        $col = $this->dbtable->findColumn (Sports::COL_PLAYER_PERSON);
        $relatedTable = ContentTable::createInstanceById ($context, $col->relatedTableId);
        $personField = new RelationAutocompleteField ($prefix, $relatedTable,
                                                      Sports::COL_PLAYER_PERSON,
                                                      $col->label, $col->description, $col->required);
        $personField->cssClass = "player";
        $personField->size = 5;
        if ($this->isSubstitute)
            $personField->cssClass .= " substitute";
        $arr[] = $personField;

        // captain field Sports::COL_PLAYER_CAPTAIN
        $arr[] = new CheckBoxFieldTemplate ($prefix, Sports::COL_PLAYER_CAPTAIN, "", $context->getText ("On if captain"));
        $arr[] = new LabelTemplate ($context->getText ("C|captain"));

        $arr[] = new HiddenFieldTemplate ($prefix, Sports::COL_PLAYER_PRIORITY);
        return $arr;
        }

    public static function getCount ($context, $request, $criteria, &$cache)
        {
        if (!array_key_exists (Sports::TABLE_MATCHPLAYER, $cache))
            {
            $dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHPLAYER);
            $playerRows = self::selectRecords ($context, $dbtable, self::getColumns (), $context->getText ("Match players"), $criteria);
            $homePlayers = array ();
            $homeSubstituteIds = array ();
            $homeSubstitutes = array ();
            $awayPlayers = array ();
            $awaySubstitutes = array ();
            $awaySubstituteIds = array ();

            if (!empty ($playerRows))
                {
                $substitutes = array ();
                foreach ($playerRows as $singleRow)
                    {
                    if (empty ($singleRow[Sports::COL_PLAYER_SUBSTITUTED_BY]))
                        continue;

                    if ($singleRow["c_".Sports::COL_PLAYER_ISHOME])
                        $homeSubstituteIds[] = $singleRow[Sports::COL_PLAYER_SUBSTITUTED_BY][0];
                    else
                        $awaySubstituteIds[] = $singleRow[Sports::COL_PLAYER_SUBSTITUTED_BY][0];
                    }
        
                $i = 0;
                foreach ($playerRows as $singleRow)
                    {
                    if ($singleRow["c_".Sports::COL_PLAYER_ISHOME])
                        {
                        $isSubstitute = $singleRow["c_".Sports::COL_PLAYER_UNUSED] || false !== array_search ($singleRow[Sports::COL_PLAYER_PERSON][0], $homeSubstituteIds);
                        if ($isSubstitute)
                            $homeSubstitutes[] = $singleRow;
                        else
                            $homePlayers[] = $singleRow;
                        }
                    else
                        {
                        $isSubstitute = $singleRow["c_".Sports::COL_PLAYER_UNUSED] || false !== array_search ($singleRow[Sports::COL_PLAYER_PERSON][0], $awaySubstituteIds);
                        if ($isSubstitute)
                            $awaySubstitutes[] = $singleRow;
                        else
                            $awayPlayers[] = $singleRow;
                        }
                    }
                }
            $cache[Sports::TABLE_MATCHPLAYER] = array ($homePlayers, $homeSubstitutes, $awayPlayers, $awaySubstitutes);
            $cache["substituteids"] = array ($homeSubstituteIds, $awaySubstituteIds);
            }

        list ($homePlayers, $homeSubstitutes, $awayPlayers, $awaySubstitutes) = $cache[Sports::TABLE_MATCHPLAYER];
        list ($homeSubstituteIds, $awaySubstituteIds) = $cache["substituteids"];
        return array (
                    count ($homePlayers),
                    count ($homeSubstitutes),
                    count ($homeSubstituteIds),
                    count ($awayPlayers),
                    count ($awaySubstitutes),
                    count ($awaySubstituteIds),
                    );
        }
    }

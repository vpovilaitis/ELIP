<?php
require_once (PATH."pages/sports/seasonresultsbase.php");
require_once (PATH."inc/sports/leaguetablerow.php");

class CupResultsComponent extends SeasonResultsBase
    {
    protected $hasCupResults = false;
    protected $allRounds = array ();
    protected $roundMatches = array ();
    protected $cupWinnerRoundId = NULL;
    protected $renamedTeamIds = array ();

    public function getTitle ()
        {
        if (empty ($this->title))
            return $this->getText ("Play-off");
        else
            return $this->title;
        }

    public function isVisible ()
        {
        return $this->hasCupResults || ($this->explicitlySpecified && $this->hasMatches);
        }

    public function processInput ($context, &$request)
        {
        $this->teams = array ();
        if (false === $this->retrieveTeamsWithFixedStats ($context) ||
            false === $this->recalculateByMatches ($context))
            {
            return false;
            }

        return true;
        }

    public function retrieveTeamsWithFixedStats ($context)
        {
        $resultsTable = $this->getTeamCupSeasonsTable ($context);
        if (empty ($resultsTable))
            return false;

        $altNameColumn = ContentTable::generateForeignKeyColumn ("altname", Sports::TABLE_TEAM."_id");
        $criteria = array (new EqCriterion (ContentTable::generateForeignKeyColumn (Sports::COL_TEAMLEAGUESEASON_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id"), $this->leagueId));
        $columns = array ("team_id", "achievement", "entered", $altNameColumn);
        $rows = $resultsTable->selectBy ($columns, $criteria);
        if (empty ($rows))
            return true;

        $criteria = array ();

        foreach ($rows as $row)
            {
            $this->hasCupResults = true;
            $parentId = array ($row["team_id"]);
            $teamId = implode ("_", $parentId);

            if (!isset ($this->teams[$teamId]))
                $this->teams[$teamId] = new CupResultsRow ($parentId);
            $team = &$this->teams[$teamId];

            if (!empty ($row["achievement"]))
                {
                $team->achievement = implode ("_", $row["achievement"]);
                if (!array_key_exists ($team->achievement, $this->allRounds))
                    $this->allRounds[$team->achievement] = $row["achievement.displayname"];
                }

            if (!empty ($row["entered"]))
                {
                $team->enteredRound = implode ("_", $row["entered"]);
                if (!array_key_exists ($team->enteredRound, $this->allRounds))
                    $this->allRounds[$team->enteredRound] = $row["entered.displayname"];
                }

            if (!empty ($row[$altNameColumn]))
                $this->renamedTeamIds[$row[$altNameColumn]] = $teamId;
            }
        }

    public function recalculateByMatches ($context)
        {
        if (!$this->explicitlySpecified && !$this->hasCupResults)
            return true;

        $matchesTable = $this->getMatchesTable ($context);
        if (empty ($matchesTable))
            return false;

        $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id");
        $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id");
        $criteria = array (new EqCriterion ("cstage", $this->leagueId));
        $columns = array ("match_id", "time", $homeTeamColumn, $awayTeamColumn, "result", "outcome", "round", "no");
        $params[] = OrderBy::create ("c_".Sports::COL_MATCH_DATE, "c_".Sports::COL_MATCH_NUMBER);
        $rows = $matchesTable->selectBy ($columns, $criteria, NULL, $params);

        if (empty ($rows))
            return true;

        foreach ($rows as $row)
            {
            if (empty ($row[$homeTeamColumn]) || empty ($row[$awayTeamColumn]))
                continue;

            $this->hasMatches = true;

            $homeId = $row[$homeTeamColumn];
            $awayId = $row[$awayTeamColumn];

            if (!isset ($this->teams[$homeId]))
                {
                $teamRow = new CupResultsRow ($homeId);
                if (array_key_exists ($homeId, $this->renamedTeamIds))
                    $teamRow->setRecordedId ($this->renamedTeamIds[$homeId]);

                $this->teams[$homeId] = $teamRow;
                }
            if (!isset ($this->teams[$awayId]))
                {
                $teamRow = new CupResultsRow ($awayId);
                if (array_key_exists ($awayId, $this->renamedTeamIds))
                    $teamRow->setRecordedId ($this->renamedTeamIds[$awayId]);

                $this->teams[$awayId] = $teamRow;
                }

            $homeTeam = &$this->teams[$homeId];
            $awayTeam = &$this->teams[$awayId];

            $homeResult = $row["c_homeresult"];
            $awayResult = $row["c_awayresult"];
            $outcome = $row["c_outcome"];

            $hasResult = (NULL !== $homeResult && NULL !== $awayResult);
            $matchIdString = $row["match_id"];
            $result = $hasResult ? $row["c_result"] : $this->createMatchDateLabel ($row["c_time"]);

            $homeWin = NULL;
            switch ($outcome)
                {
                case MatchConstants::OUTCOME_NO_HOME_TEAM:
                case MatchConstants::OUTCOME_AWAY_WIN:
                case MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT:
                    if (!$hasResult)
                        {
                        $awayResult = 1;
                        $result = "- : +";
                        if (MatchConstants::OUTCOME_AWAY_WIN == $outcome)
                            $result = "- ? +";
                        }
                    break;
                case MatchConstants::OUTCOME_NO_VISITORS:
                case MatchConstants::OUTCOME_HOME_WIN:
                case MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT:
                    if (!$hasResult)
                        {
                        $homeResult = 1;
                        $result = "+ : -";
                        if (MatchConstants::OUTCOME_HOME_WIN == $outcome)
                            $result = "+ ? -";
                        }
                    break;
                case MatchConstants::OUTCOME_PENALTIES_HOME:
                    $homeWin = true;
                    break;
                case MatchConstants::OUTCOME_PENALTIES_AWAY:
                    $homeWin = false;
                    break;
                default:
                    break;
                }

            $round = implode ("_", $row["round"]);

            $match = new CupCompetitionMatch ($matchIdString, $row["c_time"], $result, $homeTeam, $awayTeam, $homeResult, $awayResult, $homeWin);
            if (!isset ($this->roundMatches[$round]))
                $this->roundMatches[$round] = array ($match);
            else
                $this->roundMatches[$round][] = $match;

            if (!array_key_exists ($round, $this->allRounds))
                $this->allRounds[$round] = $row["round.displayname"];
            }
        }

    public function getTemplateName ()
        {
        return "sports/cupteams";
        }

    public function getRounds ()
        {
        $row = $this->getCompetitionRow ();
        self::ensureTeamLabels ($this->context, $this->teams, $row["c_".Sports::COL_COMPETITION_STARTS]);

        $roundsTable = $this->getRoundsTable ($this->context);
        $singleTeamRounds = array ();
        $roundInfo = array ();
        if (!empty ($this->allRounds) && !empty ($roundsTable))
            {
            // get rounds in a correct order
            $ids = array_keys ($this->allRounds);
            $criteria = array (new InCriterion ("round_id", array_keys ($this->allRounds)));
            $columns = array ("round_id", "priority", "subpriority");
            $rows = $roundsTable->selectBy ($columns, $criteria);

            if (!empty ($rows))
                {
                $ids = array ();
                foreach ($rows as $row)
                    {
                    $id = $row["round_id"];
                    if ($row["c_subpriority"] == 1)
                        $singleTeamRounds[] = $id;
                    if ($row["c_priority"] == 1)
                        $this->cupWinnerRoundId = $id;
                    $ids[] = $id;
                    $teamCount = empty ($row["c_subpriority"]) ? $row["c_priority"] : $row["c_subpriority"];
                    $roundInfo[$id] = array ($row["c_priority"], $teamCount);
                    }
                }
            }

        if (empty ($ids))
            $ids = array_keys ($this->allRounds);

        $rounds = array ();
        foreach ($ids as $idx => $key)
            {
            if (false !== array_search ($key, $singleTeamRounds))
                continue;

            if (!empty ($roundInfo[$key]))
                list ($roundPriority, $roundTeams) = $roundInfo[$key];
            else
                $roundPriority = NULL;

            $round = new CupRound ($this->context, $this->allRounds[$key], $key, $key == $this->cupWinnerRoundId);
            $round->setLogos ($this->teams);

            if (isset ($this->roundMatches[$key]))
                {
                foreach ($this->roundMatches[$key] as $match)
                    {
                    $round->addMatch ($match);
                    }
                }

            foreach ($this->teams as $team)
                {
                if ($team->achievement == $key || $team->enteredRound == $key)
                    {
                    $winner = $team->achievement != $key;
                    $round->addTeam ($team, $winner);
                    continue;
                    }

                if (empty ($roundPriority))
                    continue;

                // if entered in later stage, skip
                if (!empty ($team->enteredRound) && array_search ($team->enteredRound, $ids) > $idx)
                    continue;

                // if results are not filed (or team did not finish competition yet), skip
                if (empty ($team->achievement) || empty ($roundInfo[$team->achievement]))
                    continue;

                // check if team was potentially competing in this round
                list ($p, $teamCount) = $roundInfo[$team->achievement];

                if ($p <= $roundPriority && $p > $roundPriority - $roundTeams)
                    $round->addTeam ($team, true);
                }
            $rounds[$key] = $round;
            }

        return $rounds;
        }

    public function getScheduleLinkLabel ()
        {
        return $this->getText ("Competition schedule");
        }

    public function getScheduleUrl ()
        {
        return $this->context->processUrl ("index.php?c=sports/MatchList&leagueid=$this->leagueId");
        }
    }

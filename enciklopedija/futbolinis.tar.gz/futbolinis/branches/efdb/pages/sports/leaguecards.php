<?php
require_once (PATH."pages/sports/leagueplayerstats.php");

class LeagueCards extends LeaguePlayerStats
    {
    const ITEMS_SHOWN = 5;

    public function __construct ($context, $dbtable, $leagueId, $maxItems = self::ITEMS_SHOWN)
        {
        parent::__construct ($context, Sports::TABLE_MATCHEVENT, $leagueId);
        $this->maxItems = $maxItems;
        }

    protected function getColumnName ()
        {
        return Sports::COL_EVENT_PLAYER;
        }

    protected function getHomeTeamColumnName ()
        {
        return Sports::COL_EVENT_ISHOME;
        }

    protected function getMaxItemCount ()
        {
        return $this->maxItems;
        }

    public function getTitle ()
        {
        return $this->getText ("Most yellow cards");
        }

    protected function prepareRowCountQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        parent::prepareRowCountQuery ($resultColumns, $criteria, $joins, $params);
        $criteria[] = new InCriterion ("c_".Sports::COL_EVENT_TYPE, array (MatchConstants::EVENT_YELLOW, MatchConstants::EVENT_YELLOW_RED));
        }

    public function getFullListUrl ()
        {
        $leagueId = is_array ($this->leagueId) ? $this->leagueId[0] : $this->leagueId;
        return $this->context->chooseUrl ("stats/".Sports::TABLE_COMPETITIONSTAGE."/$leagueId",
                                          "index.php?c=ContentPage&mode=stats&tn=".Sports::TABLE_COMPETITIONSTAGE."&id=$leagueId",
                                          "stats=playercards");
        }

    }

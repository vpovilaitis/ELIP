<?php
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'pages/submit.php');

class SubmitCareerChange extends Submit
    {
    protected $playerField;
    protected $teamField;
    protected $joinedField;
    protected $positionField;
    protected $expiresField;

    public function __construct ($context, $request)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMPLAYER);

        if (empty ($this->dbtable))
            {
            $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            $this->allTablesLoaded = false;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        $context->addScriptFile ("autosuggest");
        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ($this->getText ("Register player transfer"));
        return true;
        }

    protected function onInputFieldCollected ($context, &$request, $type, $key, $val)
        {
        if (!empty ($val))
            {
            switch ($type)
                {
                default:
                    break;
                }
            }
        }

    public function collectInputData ($context, &$request)
        {
        $this->createSourceFields ();
        $this->source = $this->sourcesField->getValueForDB ($context, $request);
        $this->sourceDate = $this->sourcesDateField->getValueForDB ($context, $request);
        $playerId = $this->playerField->getValueForDB ($context, $request);
        $teamId = $this->teamField->getValueForDB ($context, $request);
        $dateJoined = $this->joinedField->getValueForDB ($context, $request);
        $positionId = $this->positionField->getValueForDB ($context, $request);
        $expires = $this->expiresField->getValueForDB ($context, $request);

        $data = $this->retrieveCareerData ($playerId);
        if (!empty ($data) && !empty ($teamId))
            {
            $data[Sports::COL_TEAMPLAYER_TEAM] = $teamId;
            $data[Sports::COL_TEAMPLAYER_STARTED] = $dateJoined;
            }

        if (!empty ($data))
            {
            $data[Sports::COL_TEAMPLAYER_POSITION] = $positionId;
            $data[Sports::COL_TEAMPLAYER_EXPIRES] = $expires;
            }

        if (!empty ($data) && !empty ($data["career"]))
            {
            for ($i = count($data["career"]) - 1; $i >= 0; $i--)
                {
                $lastTeam = $data["career"][$i];
                if (empty ($lastTeam[Sports::COL_TEAMPLAYER_ENDED]))
                    {
                    $field = new DateFieldTemplate ($this->getPrefix (), Sports::COL_TEAMPLAYER_ENDED,
                                                    $this->getText ("Left [_0]:", $lastTeam[Sports::COL_TEAMPLAYER_TEAM]),
                                                    $this->getText ("Optional date to set for last carrer point."));
                    $this->fields[Sports::COL_TEAMPLAYER_ENDED] = $field;
                    // set initial position $positionId
                    $data[Sports::COL_TEAMPLAYER_ENDED] = $field->getValueForDB ($context, $request);
                    $data["lastTeam"] = $lastTeam[$this->dbtable->getIdColumn ()];
                    }
                }
            }

        return $data;
        }
        
    public function validateInput ($context, &$input)
        {
        if (empty ($input))
            return false;

        if (!empty ($input[Sports::COL_TEAMPLAYER_TEAM]) && empty ($input[Sports::COL_TEAMPLAYER_STARTED]))
            return $this->logError ("Team was entered, but join date was not");

        $lng = Language::getInstance ($context);
        $lines = NULL;
        foreach (empty ($input["career"]) ? array () : $input["career"] as $row)
            {
            $team = $row[Sports::COL_TEAMPLAYER_TEAM];
            $from = $lng->dateToLongString ($row[Sports::COL_TEAMPLAYER_STARTED], "month");
            $to = $lng->dateToLongString ($row[Sports::COL_TEAMPLAYER_ENDED], "month");
            $lines[] = "&nbsp;- $team ($from - $to)";
            }

        if (!empty ($input["id"]))
            {
            $personsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_PERSON);
            $playerId = $input["id"];
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $personsTable,
                                                                         $personsTable->getId (),
                                                                         $playerId);
            $url = "<a href=\"$url\">{$playerId[0]}</a>";
            }
        else
            $url = "";

        if (!empty ($lines))
            {
            $this->writeLine ($this->getText ("Player [_0] career:", $url));
            $this->writeLine (implode ("<br>", $lines)."<br>");
            }
        else
            $this->writeLine ($this->getText ("Player [_0] has no career records.", $url));

        return true;
        }

    public function saveInput ($context, &$request, &$input)
        {
        if (empty ($input))
            return false;
        $playerId = $input["id"];

        if (!empty ($input[Sports::COL_TEAMPLAYER_TEAM]))
            {
            $id = $this->insertNewEntry ($input[Sports::COL_TEAMPLAYER_TEAM], $playerId, $input[Sports::COL_TEAMPLAYER_STARTED],
                                         $input[Sports::COL_TEAMPLAYER_POSITION], $input[Sports::COL_TEAMPLAYER_EXPIRES]);
            if ($id > 0)
                {
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $this->dbtable,
                                                                             $this->dbtable->getId (),
                                                                             $id);
                $this->writeLine ("<a href=\"$url\">New record</a> was created<br>");
                }
            else
                return false;
            }

        if (!empty ($input[Sports::COL_TEAMPLAYER_ENDED]))
            {
            if (!$this->updateEntry ($input["lastTeam"], $input[Sports::COL_TEAMPLAYER_ENDED]))
                return false;
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($context, $this->dbtable,
                                                                         $this->dbtable->getId (),
                                                                         $input["lastTeam"]);
            $this->writeLine ("End date for last team <a href=\"$url\">recorded</a> (".$input[Sports::COL_TEAMPLAYER_ENDED].")<br>");
            }

        $cache = Cache::getInstance (Sports::TABLE_MATCH, 6*60*60);
        $cache->clean ();

        return true;
        }

    protected function insertNewEntry ($teamId, $playerId, $dateFrom, $position, $expires)
        {
        $values = array (Sports::COL_TEAMPLAYER_TEAM => $teamId, Sports::COL_TEAMPLAYER_PLAYER => $playerId,
                         Sports::COL_TEAMPLAYER_STARTED => $dateFrom, Sports::COL_TEAMPLAYER_POSITION => $position,
                         Sports::COL_TEAMPLAYER_EXPIRES => $expires);
        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;
        $ret = $this->dbtable->insertRecord ($values);
        return $ret;
        }

    protected function updateEntry ($entryId, $dateTo)
        {
        $values = array (Sports::COL_TEAMPLAYER_ENDED => $dateTo);
        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;
        $criteria[] = new EqCriterion ($this->dbtable->getIdColumn (), $entryId);
        return false !== $this->dbtable->updateRecord ($criteria, $values);
        }

    protected function retrieveCareerData ($playerId)
        {
        if (empty ($playerId))
            return NULL;
        $criteria[] = new EqCriterion (Sports::COL_TEAMPLAYER_PLAYER, $playerId);
        $columns = array ($this->dbtable->getIdColumn (), Sports::COL_TEAMPLAYER_TEAM.".".Sports::COL_TEAM_SHORTNAME, Sports::COL_TEAMPLAYER_STARTED, Sports::COL_TEAMPLAYER_ENDED);
        $rows = $this->dbtable->selectBy ($columns, $criteria);

        $career = NULL;
        if (!empty ($rows))
            {
            $idColumn = $this->dbtable->getIdColumn ();
            foreach ($rows as $row)
                {
                $career[] = array ($idColumn => $row[$idColumn],
                                   Sports::COL_TEAMPLAYER_TEAM => $row[Sports::COL_TEAMPLAYER_TEAM.".c_".Sports::COL_TEAM_SHORTNAME],
                                   Sports::COL_TEAMPLAYER_STARTED => $row["c_".Sports::COL_TEAMPLAYER_STARTED],
                                   Sports::COL_TEAMPLAYER_ENDED => $row["c_".Sports::COL_TEAMPLAYER_ENDED]);
                }
            }

        return array ("id" => $playerId, "career" => $career);
        }

    public function createSourceFields ()
        {
        parent::createSourceFields ();
        if (empty ($this->playerField))
            {
            $column = $this->dbtable->findColumn (Sports::COL_TEAMPLAYER_PLAYER);
            $this->playerField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
            }
        if (empty ($this->teamField))
            {
            $column = $this->dbtable->findColumn (Sports::COL_TEAMPLAYER_TEAM);
            $this->teamField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
            }
        if (empty ($this->positionField))
            {
            $column = $this->dbtable->findColumn (Sports::COL_TEAMPLAYER_POSITION);
            $this->positionField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
            }
        if (empty ($this->joinedField))
            {
            $this->joinedField = new DateFieldTemplate ($this->getPrefix (), Sports::COL_TEAMPLAYER_STARTED,
                                                                    $this->getText ("Joined on:"),
                                                                    $this->getText ("Date on which contract with new team was signed."));
            }
        if (empty ($this->expiresField))
            {
            $this->expiresField = new DateFieldTemplate ($this->getPrefix (), Sports::COL_TEAMPLAYER_EXPIRES,
                                                                    $this->getText ("Expiration date:"),
                                                                    $this->getText ("Date on which contract will expire."));
            }
        }

    protected function processInputFields ($context, &$request)
        {
        $this->createSourceFields ();
        parent::processInputFields ($context, $request);
        $this->playerField->processInput ($context, $request);
        $this->teamField->processInput ($context, $request);
        $this->joinedField->processInput ($context, $request);
        $this->positionField->processInput ($context, $request);
        $this->expiresField->processInput ($context, $request);
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();

        $arr = array
            (
            $this->playerField,
            $this->teamField,
            $this->positionField,
            );

        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));
        $arr[] = $this->joinedField;
        $arr[] = $this->expiresField;
        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }

    }

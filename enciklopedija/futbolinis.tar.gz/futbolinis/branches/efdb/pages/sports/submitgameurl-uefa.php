<?php

class PreprocessedMatchUrlContentUefa extends PreprocessedMatchUrlContent
    {
    protected function initialize ($content)
        {
        $header = cutTextPiece ($content, '<div class="d3cmsTopContent">', '<div class="mpmenu row');
        if (false === $header)
            return $this->logError ("Cannot parse given URL content");
        
        $description = cutTextPiece ($content, '<div id="VenueDetails">', "</div>", true);
        if (false === $description || preg_match ("#([0-9]{2})/([0-9]{2})/([0-9]{4}) \- ([0-9]{2}):([0-9]{2})CET([^-]+)? \- (.+)$#", $description, $matches) <= 0)
            return $this->logError ("Cannot parse given URL description");

        $hour = $matches[4]+1;
        $this->date = "{$matches[3]}-{$matches[2]}-{$matches[1]} {$hour}:{$matches[5]}";
        $this->stadium = trim (strip_tags ($matches[7]));

        // <table class="pname noboder"><tr><td class="w18"><a href="/index.html" title="Miha Mevlja"><img ... /></a></td><td class="l"><a class="pllinehe" href="/under21/season=2013/teams/player=250008512/index.html">Miha Mevlja</a></td></tr></table>
        $content = preg_replace ('#<table class="pname.+><tr><td class="w18">(.+)</td><td class="l">(.+)</td></tr></table>#uU', "\\1 \\2", $content);
        if (preg_match_all ("#<tr class=\"(people|people b|people noborder|h34 noborder|h34)\">(.+(<table class=\"pname.+</table>.+(<table class=\"pname.+</table>.+|<td /><td /><td />))?)</tr>#uU", $content, $matches) <= 0 &&
            preg_match_all ("#<tr class=\"(people|people b|people noborder|h34 noborder|h34)\">(.+)</tr>#uU", $content, $matches) <= 0)
            {
            return $this->logError ("Cannot parse given URL players");
            }

        $lineIndex = 0;
        foreach ($matches[2] as $tr)
            {
            if (preg_match_all ("#<td( class=\"(.+)\")?(>(.*)</td>|( )/>)#uU", $tr, $tdParts) <= 0)
                {
                $this->logError ("Cannot parse given URL player line ".$tr);
                continue;
                }

            $classNames = $tdParts[2];
            $lineContent = $tdParts[4];
            if (6 == count ($classNames) && ("c w18" == $classNames[0] || "c w18" == $classNames[3]))
                {
                $lineIndex++;
                if ("c w18" == $classNames[0])
                    $this->homePlayers[] = $this->parsePlayer ($lineContent[0], $lineContent[1], $lineContent[2], $lineIndex, true);
                if ("c w18" == $classNames[3])
                    $this->awayPlayers[] = $this->parsePlayer ($lineContent[3], $lineContent[4], $lineContent[5], $lineIndex, false);
                }
            else if ((3 == count ($classNames) || 7 == count ($classNames) || 8 == count ($classNames)) && ("c w18" == $classNames[0] || (count ($classNames) >= 4 && "c w18" == $classNames[4])))
                {
                $lineIndex++;
                if ("c w18" == $classNames[0])
                    $this->homePlayers[] = $this->parsePlayer ($lineContent[0], $lineContent[2], $lineContent[3], $lineIndex, true);
                if (count ($classNames) > 4 && "c w18" == $classNames[4])
                    $this->awayPlayers[] = $this->parsePlayer ($lineContent[4], $lineContent[6], $lineContent[7], $lineIndex, false);
                }
            else if (6 == count ($classNames) && ("w18" == $classNames[0] || "w18" == $classNames[3]))
                {
                $this->homeCoach = $this->parseCoach ($lineContent[1]);
                $this->awayCoach = $this->parseCoach ($lineContent[4]);
                }
            else if (1 == count ($classNames) && preg_match ('#<td colspan="5" class="l">(.+)\s*</td>$#u', $tr, $refMatches) > 0)
                {
                $this->parseReferees ($refMatches[1]);
                }
            else
                {
                $this->writeLine ($lineContent);
                $this->logError ("Cannot parse given URL player line.");
                }
            }

        $this->processSubstitutes ($this->homePlayers);
        $this->processSubstitutes ($this->awayPlayers);
        
        if (preg_match ('#<div id="resultsDetails">([0-9]+\s*-\s*[0-9]+)</div>#', $content, $scoreMatch) <= 0 ||
            false === $this->setScore ($scoreMatch[1]))
            {
            return $this->logError ("Cannot parse given URL score");
            }

        $this->writeLine ("<pre>".implode (":", $this->score)."\n</pre>");
        }

    protected function parseReferees ($content)
        {
        $parts = explode (",", $content);
        if (empty ($this->referees["referee"]) && 1 == count ($parts))
            $this->referees["referee"] = $parts[0];
        else if (2 == count ($parts))
            {
            $this->referees["refereeA1"] = $parts[0];
            if (count ($parts) > 1)
                $this->referees["refereeA2"] = $parts[1];
            }
        else if (!empty ($this->referees["referee"]) && !empty ($this->referees["refereeA1"]) && 1 == count ($parts))
            $this->referees["refereeR"] = $parts[0];
        else
            return $this->logError ("Cannot parse given URL referees");
        }

    protected function processSubstitutes (&$players)
        {
        $substitutes = array ();
        foreach ($players as $player)
            {
            if (empty ($player['unused']) && $player['from'] != 0)
                $substitutes[] = $player;
            }

        foreach ($players as &$player)
            {
            if (!empty ($player['unused']) || $player['to'] === 90)
                continue;

            foreach ($substitutes as $key => $val)
                {
                if ($val['from'] == $player['to'])
                    {
                    unset ($substitutes[$key]);
                    $player['substituteName'] = $val['name'];
                    break;
                    }
                }
            }
        }

    protected function parsePlayer ($number, $name, $additional, $lineIndex, $isHome)
        {
        $player = array ("no" => $number);

        if (preg_match ('#<a class="pllinehe" href="(.+)">.+#u', $name, $matches) > 0)
            {
            $url = "http://www.uefa.com".$matches[1];
            $player["url"] = $url;
            }

        $name = strip_tags ($name);
        if (preg_match ('#^(.+)\s+\(GK\)$#u', $name, $matches) > 0)
            {
            $player["pos"] = "GK";
            $name = $matches[1];
            }

        if (preg_match ('#^(.+)\s+\(C\)$#u', $name, $matches) > 0)
            {
            $player["captain"] = true;
            $name = $matches[1];
            }

        $player["name"] = $name;
        if ($lineIndex > 11)
            $player["unused"] = true;
        else
            {
            $player["from"] = 0;
            $player["to"] = 90;
            }

        if (preg_match_all ('#<img ([^>]*)alt="(.+)"([^>]*)><span class="minbymin">(([0-9]+\\\'?|[0-9]+\+[0-9]+|[0-9]+:[0-9]+))</span>#uU', $additional, $eventMatches) > 0)
            {
            $events = $eventMatches[2];
            $minutes = $eventMatches[4];
            for ($i = 0; $i < count ($events); $i++)
                {
                $minute = preg_split ('#:#', $minutes[$i]);
                if (count ($minute) > 1) // futsal minutes with seconds
                    $minute = $minute[0] + 1;
                else
                    $minute = trim ($minute[0], '\\\'');

                $isHomeEvent = $isHome;
                
                $eventType = null;
                switch ($events[$i])
                    {
                    case 'Goal':
                        $eventType = RawEvent::EVENT_GOAL;
                        if (false !== strpos ($eventMatches[0][$i], "goals_P"))
                            $eventType = RawEvent::EVENT_PENALTY;
                        else if (false !== strpos ($eventMatches[0][$i], "goals_O"))
                            {
                            $eventType = RawEvent::EVENT_OWN_GOAL;
                            $isHomeEvent = !$isHomeEvent;
                            }
                        break;

                    case 'Yellow Card':
                        $eventType = RawEvent::EVENT_YELLOW;
                        break;

                    case 'Penalty':
                        $eventType = RawEvent::EVENT_PENALTY;
                        if (false !== strpos ($eventMatches[0][$i], "goals_W"))
                            $eventType = RawEvent::EVENT_PENALTY_MISS;
                        break;

                    case 'Yellow Card':
                        $eventType = RawEvent::EVENT_YELLOW;
                        break;

                    case 'Red Card':
                        $eventType = RawEvent::EVENT_RED;
                        if (false !== strpos ($eventMatches[0][$i], "yell_reds"))
                            $eventType = RawEvent::EVENT_YELLOW_RED;
                        break;

                    case 'Substitution':
                        if (!empty ($player["unused"]))
                            {
                            unset ($player["unused"]);
                            $player["from"] = $minute;
                            $player["to"] = 90;
                            }
                        else
                            $player["to"] = $minute;
                        break;

                    default:
                        $this->logError ("Unrecognized event '{$events[$i]}'");
                        break;
                    }
                if (empty ($eventType))
                    continue;
                $event = new RawEvent ($minute, $eventType, $player["name"], $url);

                if ($isHomeEvent)
                    $this->homeEvents[] = $event;
                else
                    $this->awayEvents[] = $event;
                }
            }

        return $player;
        }

    protected function parseCoach ($name)
        {
        $name = strip_tags ($name);
        if (preg_match ('#^(.+)\s+\(([A-Z]+)\)\s*$#', $name, $matches) > 0)
            return $matches[1]."+".$matches[2];
        return $name;
        }

    protected function parseEvents (&$events, $eventList, $min = NULL)
        {
        $eventLines = explode ("<br>", $eventList);
        foreach ($eventLines as $event)
            {
            $event = trim ($event);
            if (empty ($event))
                continue;
            $name = cutTextPiece ($event, 'class="komanda">', '</a>', false);
            $type = cutTextPiece ($event, '<img src="./images/', '.gif"', false);
            if (false != strpos ($event, "Į savo vartus"))
                $type = RawEvent::EVENT_OWN_GOAL;
            else if (false != strpos ($event, "(11 m.)"))
                $type = RawEvent::EVENT_PENALTY;
            else if ("yellow" == $type && false != strpos ($event, "red.gif"))
                $type = RawEvent::EVENT_YELLOW_RED;
            $events[] = new SflEvent ($type, $name, $min);
            }

        return $events;
        }

    public function setEvents ($events)
        {
        $homeEvents = cutTextPiece ($events, '<td class="right">', '</td>', true);
        if (false === $homeEvents || false === cutTextPiece ($events, '<td>', '</td>', true))
            return $this->logError ("Cannot parse home events");
        $awayEvents = cutTextPiece ($events, '<td>', '</td>', true);
        if (false === $awayEvents)
            return $this->logError ("Cannot parse away events");

        if (!empty ($homeEvents))
            $this->parseEvents ($this->homeEvents, $homeEvents);
        if (!empty ($awayEvents))
            $this->parseEvents ($this->awayEvents, $awayEvents);
        }

    public function setGoals ($text)
        {
        while (false !== ($goalLine = cutTextPiece ($text, '<tr>', "</tr>", true, true)))
            {
            $line = trim ($goalLine);
            $homeEvent = cutTextPiece ($goalLine, '<td>', '</td>', true);
            $eventTime = cutTextPiece ($goalLine, '<td class="center">', '</td>', true);
            $awayEvent = cutTextPiece ($goalLine, '<td class="right">', '</td>', true);

            if (false === $homeEvent || false === $eventTime || false === $awayEvent)
                {
                return $this->logError ("Cannot parse goal '".htmlspecialchars ($line)."'");
                }

            preg_match ('/\[([0-9]{1,3}) min\./u', trim ($eventTime), $matches);
            if (count ($matches) < 2)
                return $this->logError ("Cannot parse event (goal - '$eventTime')");

            $min = $matches[1];
            $homeEvent = trim ($homeEvent);
            $awayEvent = trim ($awayEvent);
            if (empty ($homeEvent) == empty ($awayEvent))
                return $this->logError ("Cannot parse event ($homeEvent $eventTime $awayEvent)");

            if (!empty ($homeEvent))
                $this->parseEvents ($this->homeEvents, $homeEvent, $min);
            else
                $this->parseEvents ($this->awayEvents, $awayEvent, $min);
            }
        

        }
    }

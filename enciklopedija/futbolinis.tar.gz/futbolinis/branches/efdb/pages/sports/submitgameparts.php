<?php
require_once (PATH.'pages/sports/submitgame.php');

class SubmitGameParts extends SubmitGame
    {
    protected $refereeField;

    const FORMAT_SKIP = "skip";
    const FORMAT_LOOSE = "loose";
    const FORMAT_COMMA = "comma";
    const FORMAT_GUESS = "any";
    const FORMAT_TIMELINE = "time";

    const PARAM_MATCH_ID = "matchid";
    const PARAM_RESULT = "result";
    const PARAM_SPECTATORS = "spect";
    const PARAM_DATE = "date";
    const PARAM_REFEREE = "referee";
    const PARAM_REFEREE_CITY = "city";
    const PARAM_STADIUM = "stadium";
    const PARAM_HTEAM_FORMAT = "hformat";
    const PARAM_HTEAM_LIST = "hlist";
    const PARAM_ATEAM_FORMAT = "aformat";
    const PARAM_ATEAM_LIST = "alist";
    const PARAM_EVENT_FORMAT = "eformat";
    const PARAM_EVENTS = "events";

    public function ensureTitle ($context, &$request)
        {
        $title = "Submit results for existing game";
        $context->setTitle ($title);
        return true;
        }

    public function processInput ($context, &$request)
        {
        if (!isset ($request["save"]) && !isset ($request["skip"]))
            return true;

        $this->collectInputFields ($context, $request);

        $match = $this->collectMatchParts ($request);

        if (false === $match)
            $this->logError ("Error parsing the results");
        else if (false === $this->prepareMatch ($match))
            $this->logError ("Error preparing the match");
        else
            {
            if ($this->allTablesLoaded && !$this->hasUnrecognizedItems)
                {
                $title = isset ($request["save"]) ? "Saving" : "Checking";
                print_r ("<h1>$title</h1><pre>");

                if (isset ($request["save"]) && false === $this->storeMatches (NULL, NULL, array ($match)))
                    $this->logError ("Error saving the match");

                print_r ("</pre>");
                }
            }

        $this->processInputFields ($context, $request);
        return true;
        }

    protected function processInputFields ($context, &$request)
        {
        parent::processInputFields ($context, $request);
        $this->refereeField->processInput ($context, $request);
        }

    public function createSourceFields ()
        {
        parent::createSourceFields ();
        if (empty ($this->refereeField))
            {
            $col = $this->refereetable->findColumn (self::PARAM_REFEREE);
            $this->refereeField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $col);
            }
        }

    public function collectMatchParts ($request)
        {
        if (empty ($request[self::PARAM_MATCH_ID]))
            return $this->logError ("Match id not entered");
        $params = array
            (
            self::MATCH_DATE => self::PARAM_DATE,
            self::MATCH_REFEREE."Id" => self::PARAM_REFEREE,
            self::MATCH_REFEREE_CITY => self::PARAM_REFEREE_CITY,
            self::MATCH_SPECTATORS => self::PARAM_SPECTATORS,
            self::MATCH_STADIUM."Id" => self::PARAM_STADIUM,
            );
        $match = array ("id" => $request[self::PARAM_MATCH_ID]);

        foreach ($params as $col => $param)
            {
            if (!empty ($request[$param]))
                $match[$col] = $request[$param];
            }
        
        if (!empty ($request[self::PARAM_RESULT]))
            {
            if ("w/o game" == trim ($request[self::PARAM_RESULT]))
                $match[self::MATCH_OUTCOME] = self::OUTCOME_NORMAL;
            else
                {
                if (false === $this->parseResult ($request[self::PARAM_RESULT], $match))
                    return false;
                $match[self::MATCH_OUTCOME] = self::OUTCOME_NORMAL;
                }
            }

        if (self::FORMAT_SKIP != $request[self::PARAM_HTEAM_FORMAT] && !empty ($request[self::PARAM_HTEAM_LIST]))
            {
            $list = $request[self::PARAM_HTEAM_LIST];
            $list = str_replace (";", ",", $list);
            $players = $this->parseTeamPlayers (trim ($list));
            $match["homePlayers"] = $players;
            }
        else
            $match["homePlayers"] = array ();

        if (self::FORMAT_SKIP != $request[self::PARAM_ATEAM_FORMAT] && !empty ($request[self::PARAM_ATEAM_LIST]))
            {
            $list = $request[self::PARAM_ATEAM_LIST];
            $list = str_replace (";", ",", $list);
            $players = $this->parseTeamPlayers (trim ($list));
            $match["awayPlayers"] = $players;
            }
        else
            $match["awayPlayers"] = array ();

        if (false === $this->prepareExtraData ($match, $request[self::PARAM_EVENTS], $request[self::PARAM_EVENT_FORMAT]))
            return false;

        return $match;
        }

    public function prepareExtraData (&$match, $extra, $format)
        {
        $parserCache = array ();
        $extra = trim ($extra);
        if (empty ($extra))
            return true;

        $lines = split("[\n\r]+", $extra);
        $goals = array ();
        foreach ($lines as $line)
            {
            if (empty ($line))
                continue;

            $line = $this->preprocessMatchLine ($line);

            if ($format != self::FORMAT_TIMELINE)
                {
                // if "1' [1 - 0] Name Surname (11m.)", it is a goal line
                preg_match ('/^([0-9]{1,2})\'\s+\[[0-9]+ [\-–] [0-9]+\] (.+)( \((.+)\))?$/uU', trim ($line), $matches);
                if (count ($matches) > 2)
                    {
                    $player = array ("min" => $matches[1], "name" => $matches[2]);
                    if (count ($matches) > 4)
                        {
                        $modifier = $matches[4];
                        if ("pk" == $modifier || "11" == substr ($modifier, 0, 2))
                            $player["pk"] = true;
                        else if ("og" == $modifier)
                            $player["og"] = true;
                        else
                            $this->logError ("Unrecognized goal modifier ('$modifier')");
                        }
                    // $player["extra"] = trim ($matches[2], "+");
                    $goals[] = $player;
                    continue;
                    }
                // if "Artur Semaško  	 [1:0][7 min.]", it is a goal line
                preg_match ('/^(.+)\s+\[[0-9]+\:[0-9]+\]\[([0-9]{1,3}) min\.\]?$/uU', trim ($line), $matches);
                if (count ($matches) > 2)
                    {
                    $player = array ("min" => $matches[2], "name" => $matches[1]);
                    $goals[] = $player;
                    continue;
                    }
                }
            else if (0 === strncasecmp ($line, "goals:", 6))
                {
                list ($t, $timeline) = explode (":", $line, 2);
                $replaceWith = $this->preprocessTimelinedGoals ($timeline);
                if (false === $replaceWith)
                    return false;
                $line = "Goals: $replaceWith";
                }

            if (false === $this->processSingleMatchPart ($match, $parserCache, $line, true))
                return false;
            }

        if (!empty ($goals))
            $match["goal"] = $goals;
        }

    public function preprocessTimelinedGoals ($line)
        {
        $line = trim ($line, " .");
        $goals = explode (";", $line);
        $resultH = 0;
        $resultA = 0;
        $goalsHome = array ();
        $goalsAway = array ();
        foreach ($goals as $goal)
            {
            preg_match ("/^([0-9 ,]+)('|`| min\.) (.+) ([0-9]+)\:([0-9]+)$/u", trim ($goal), $matches);
            if (6 != count ($matches))
                return $this->logError ("Cannot parse goal - '$goal'");

            $list = array ();
            $times = explode (",", $matches[1]);
            foreach ($times as $time)
                $list[] = "$time {$matches[3]}";

            if (count ($list) == $matches[4] - $resultH)
                $goalsHome = array_merge ($goalsHome, $list);
            else if (count ($list) == $matches[5] - $resultA)
                $goalsAway = array_merge ($goalsAway, $list);
            else
                return $this->logError ("Result inconsistent - '$goal' (after $resultH:$resultA)");

            $resultH = $matches[4];
            $resultA = $matches[5];
            }

        $results = array ();
        if (!empty ($goalsHome))
            $results[] = implode (", ", $goalsHome);
        if (!empty ($goalsAway))
            $results[] = implode (", ", $goalsAway);
        return implode ("; ", $results);
        }

    public function prepareMatch (&$match)
        {
        parent::prepareMatch ($match, true);
        }

    protected function parseResult ($result, &$match)
        {
        preg_match ('/^([0-9]+)\:([0-9]+)(\s*\(([0-9]+)\:([0-9]+)\))?$/uU', trim ($result), $matches);
        if (empty ($matches))
            preg_match ('/([0-9]+)\-([0-9]+)(\s*\(([0-9]+)\-([0-9]+)\))?/uU', $result, $matches);

        if (count ($matches) < 3)
            return $this->logError ("Error parsing match teams and result ('$result')");
            
        $match["result"] = array ($matches[1], $matches[2]);

        if (count ($matches) > 5)
            $match["resultHalfTime"] = array ($matches[4], $matches[5]);
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();

        $teamListOptions = array (self::FORMAT_GUESS => "Guess by content",
                                  self::FORMAT_SKIP => "Do not add players",
                                  self::FORMAT_LOOSE => "Comma or semicolon separated, 30' for substitutions",
                                  self::FORMAT_COMMA => "Comma separated, 30 for substitutions");
        $addPlayers = empty ($_REQUEST["noplayers"]);
        if (!$addPlayers)
            $teamListOptions = array (self::FORMAT_SKIP => "Skipped");

        $eventOptions = array (self::FORMAT_GUESS => "Guess by content",
                               self::FORMAT_TIMELINE => "Goals sorted by time",
                               );

        $arr[] = new RelationAutocompleteField ("", $this->dbtable, self::PARAM_MATCH_ID, "Match id:", "Enter id of the existing match", true);
        //$arr[] = new IntFieldTemplate ("", self::PARAM_MATCH_ID, "Match id:", "Enter id of the existing match");
        $arr[] = new TextFieldTemplate ("", self::PARAM_RESULT, "Result:", "Result - 3:1 (0:0)", 10);
        $arr[] = $this->refereeField;
        $arr[] = new TextFieldTemplate ("", self::PARAM_REFEREE_CITY, "Referee origin:", "", 64);
        $arr[] = new IntFieldTemplate ("", self::PARAM_SPECTATORS, "Spectators:", "Spectators");
        $arr[] = new DateFieldTemplate ("", self::PARAM_DATE, "Match date:", "Enter date and time of the match (if changed)");
        $col = $this->dbtable->findColumn (self::PARAM_STADIUM);
        $arr[] = RelationDropDownFieldTemplate::createInstance ($this->context, "", $col);

        $arr[] = new DropDownFieldTemplate ("", self::PARAM_HTEAM_FORMAT, "Home team:",
                                            "How team list should be parsed", $teamListOptions);
        if ($addPlayers)
            $arr[] = new LongTextFieldTemplate ("", self::PARAM_HTEAM_LIST, "Home players:", "Player list");
        $arr[] = new DropDownFieldTemplate ("", self::PARAM_ATEAM_FORMAT, "Away team:",
                                            "How team list should be parsed", $teamListOptions);
        if ($addPlayers)
            $arr[] = new LongTextFieldTemplate ("", self::PARAM_ATEAM_LIST, "Away players:", "Player list");

        $arr[] = new DropDownFieldTemplate ("", self::PARAM_EVENT_FORMAT, "Events format:",
                                            "How events should be parsed", $eventOptions);
        $arr[] = new LongTextFieldTemplate ("", self::PARAM_EVENTS, "Events:", "goals, bookings, etc (start each event type on a new line, prefix with Goal:, Sent:, Miss:, Book:; multiple goals as N.Name-3; penalties as 89 (pk) N.Name; own as 90+2 (og) N.Name)");

        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));
        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }
    }

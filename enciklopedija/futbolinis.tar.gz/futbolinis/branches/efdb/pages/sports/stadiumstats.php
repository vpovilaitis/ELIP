<?php
require_once (PATH."pages/statisticsview.php");
require_once (PATH."inc/sports/constants.php");
require_once (PATH."inc/sports/scorecollector.php");

class StadiumStats extends StatisticsView
    {
    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        }

    protected function createComponents ($context, $request)
        {
        $id = $this->getIds ();
        $id = $id[0];
        $statistics = array ();

        $criteria[] = new EqCriterion ("f_stadium_stadium_id", $id);
        $scoreCollector = new ScoreCollector (true);
        $result = $scoreCollector->selectStatistics ($context, $request, "stadiumstats", $criteria, $id);
        if (empty ($result))
            return $statistics;

        list ($stats, $competitionStats) = $result;
        if (!empty ($competitionStats))
            {
            $statistics[] = new StatisticsSection ($this, "a2", $this->getText ("By competition"), $competitionStats, ScoreCollector::getColumnNamesByCompetition ($context));
            }

        if (!empty ($stats))
            {
            $statistics[] = new StatisticsEnumeratorComponent ($this, "a1", $this->getText ("Records and totals"), $stats, ScoreCollector::getColumnNames ($context));
            }

        return $statistics;
        }
    }

<?php
require_once (PATH.'pages/sports/relatedrecordfield.php');

class ResultFieldTemplate extends RelatedRecordField
    {
    const KEY_RESULT_HALF_TIME = "r_halftime";
    const KEY_RESULT_FULL_TIME = "r_fulltime";
    const KEY_RESULT_EXTRA_TIME = "r_extratime";
    const KEY_RESULT_PENALTIES = "r_penalties";

    public function __construct ($context, $prefix, $key, $label, $tooltip, $notes = NULL)
        {
        $tooltip = $context->getText ("[_0]. First field - number of goals scored by home team, second field - away team goals.", $tooltip);
        parent::__construct ($context, $prefix, $key, Sports::TABLE_MATCHFLOW, $label, $tooltip, $notes);
        $this->columns = array (Sports::COL_STAGE_HOME, Sports::COL_STAGE_AWAY, Sports::COL_STAGE_OUTCOME);
        $this->tableName = $context->getText ("Match flow");
        }

    protected function isEmptyRecord ($context, $request)
        {
        if (!isset ($request[Sports::COL_STAGE_HOME]) || !isset ($request[Sports::COL_STAGE_AWAY]))
            return true;

        return !is_numeric ($request[Sports::COL_STAGE_HOME]) || !is_numeric ($request[Sports::COL_STAGE_AWAY]);
        }

    public function retrieveRecord ($context, $criteria, &$row, &$cache)
        {
        $row[$this->key] = NULL;

        if ($this->key == self::KEY_RESULT_FULL_TIME)
            $row[$this->key] = array (Sports::COL_STAGE_HOME => $row["c_homeresult"], Sports::COL_STAGE_AWAY => $row["c_awayresult"]);

        if (!array_key_exists ("matchflow", $cache))
            $cache["matchflow"] = $this->retrieveRecords ($context, $criteria);

        $outcomeRows = $cache["matchflow"];
        if (empty ($outcomeRows))
            return;

        $finalResult = $penaltyScore = $extraTimeScore = NULL;
        foreach ($outcomeRows as $singleRow)
            {
            $preparedRow = $this->prepareRow ($singleRow);
            $currentKey = NULL;
            switch ($preparedRow[Sports::COL_STAGE_OUTCOME])
                {
                case MatchConstants::STAGE_HALF_TIME:
                    $currentKey = self::KEY_RESULT_HALF_TIME;
                    break;
                case MatchConstants::STAGE_FULL_TIME:
                    $currentKey = self::KEY_RESULT_FULL_TIME;
                    $finalResult = $preparedRow;
                    break;
                case MatchConstants::STAGE_EXTRA_TIME:
                    $currentKey = self::KEY_RESULT_EXTRA_TIME;
                    $extraTimeScore = $preparedRow;
                    break;
                case MatchConstants::STAGE_PENALTY_SCORE:
                    $penaltyScore = $preparedRow;
                    break;
                case MatchConstants::STAGE_PENALTIES:
                    $currentKey = self::KEY_RESULT_PENALTIES;
                    break;
                }

            if ($currentKey != $this->key)
                continue;

            $row[$this->key] = $preparedRow;
            return;
            }

        if (self::KEY_RESULT_PENALTIES == $this->key && !empty ($penaltyScore))
            {
            // if penalty score is stored (not the total sum of penalties and extra time result), adjust
            if (!empty ($extraTimeScore))
                $finalResult = $extraTimeScore;
            if (empty ($finalResult))
                $finalResult = array (Sports::COL_STAGE_HOME => $row["c_homeresult"], Sports::COL_STAGE_AWAY => $row["c_awayresult"]);
            
            $penaltyScore[Sports::COL_STAGE_HOME] += $finalResult[Sports::COL_STAGE_HOME];
            $penaltyScore[Sports::COL_STAGE_AWAY] += $finalResult[Sports::COL_STAGE_AWAY];
            $penaltyScore[Sports::COL_STAGE_OUTCOME] = MatchConstants::STAGE_PENALTIES;
            $row[$this->key] = $penaltyScore;
            }
        }

    public function prepareForStoring ($context, &$values, $initialValues, &$prepared)
        {
        if (empty ($prepared["scoreSet"]))
            {
            $fullTimeScore = $values[self::KEY_RESULT_FULL_TIME];
            $extraTimeScore = $values[self::KEY_RESULT_EXTRA_TIME];
            $score = NULL;
    
            if (!empty ($extraTimeScore) && is_numeric ($extraTimeScore[Sports::COL_STAGE_AWAY]))
                $score = $extraTimeScore;
            else if (!empty ($fullTimeScore) && is_numeric ($fullTimeScore[Sports::COL_STAGE_AWAY]))
                $score = $fullTimeScore;
    
            if (empty ($score))
                {
                $values["c_homeresult"] = NULL;
                $values["c_awayresult"] = NULL;
                }
            else
                {
                $values["c_homeresult"] = $score[Sports::COL_STAGE_HOME];
                $values["c_awayresult"] = $score[Sports::COL_STAGE_AWAY];
                }

            $prepared["scoreSet"] = true;
            }

        $map = array (self::KEY_RESULT_FULL_TIME => MatchConstants::STAGE_FULL_TIME,
                      self::KEY_RESULT_HALF_TIME => MatchConstants::STAGE_HALF_TIME,
                      self::KEY_RESULT_EXTRA_TIME => MatchConstants::STAGE_EXTRA_TIME,
                      self::KEY_RESULT_PENALTIES => MatchConstants::STAGE_PENALTIES);
        $initialValue = !empty ($initialValues) ? $initialValues[$this->key] : NULL;
        if ($this->areValuesModified ($initialValue, $values[$this->key]))
            {
            $record = $values[$this->key];
            if (!is_numeric ($record[Sports::COL_STAGE_HOME]))
                $record[Sports::COL_STAGE_OUTCOME] = NULL;
            else if (empty ($record[Sports::COL_STAGE_OUTCOME]))
                $record[Sports::COL_STAGE_OUTCOME] = $map[$this->key];

            $prepared[$this->key] = $record;
            }

        unset ($values[$this->key]);
        }

    protected function validateRecord ($context, $values)
        {
        if (is_numeric ($values[Sports::COL_STAGE_HOME]) != is_numeric ($values[Sports::COL_STAGE_AWAY]))
            {
            $context->addError ("Both home and away team score must be entered.");
            return false;
            }

        return true;
        }

    public function createFields ()
        {
        $prefix = $this->getPrefix().$this->key;
        $homeField = new IntFieldTemplate ($prefix, Sports::COL_STAGE_HOME, "", "");
        $homeField->cssClass = "resultfield";
        $homeField->size = 1;
        $awayField = new IntFieldTemplate ($prefix, Sports::COL_STAGE_AWAY, "", "");
        $awayField->cssClass = "resultfield";
        $awayField->size = 1;
        
        $stageField = new HiddenFieldTemplate ($prefix, Sports::COL_STAGE_OUTCOME);
        return array ($homeField, new LabelTemplate (":"), $awayField, $stageField);
        }

    }

<?php
require_once (PATH."inc/sports/common.php");
require_once (PATH."inc/sports/leaguetablecollector.php");

class InlineMatchPreview extends Component
    {
    private $instance;

    public function __construct ($context, $instance)
        {
        parent::__construct ("prev", $context);
        $this->instance = $instance;
        $this->lng = Language::getInstance ($context);
        }

    public function getTemplateName ()
        {
        return "sports/matchpreview";
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getPreviousMeetingsLabel ()
        {
        return $this->getText ("Previous meetings:");
        }

    public function getComparisonLabel ()
        {
        return $this->getText ("Team comparison:");
        }

    public function getNoPreviousMeetingsLabel ()
        {
        return $this->getText ("No meetings.");
        }

    public function getMoreLabel ()
        {
        return $this->getText ("more...|previous meetings");
        }

    public function getHomeLabel ()
        {
        return $this->instance[Sports::COL_MATCH_HOMETEAM.".c_".Sports::COL_TEAM_SHORTNAME];
        }
    public function getAwayLabel ()
        {
        return $this->instance[Sports::COL_MATCH_AWAYTEAM.".c_".Sports::COL_TEAM_SHORTNAME];
        }

    public function isVisible ()
        {
        $date = $this->instance["c_".Sports::COL_MATCH_DATE];

        // check if match started at least 100 minutes ago
        $minTime = strftime ("%Y-%m-%d %H:%M:%S", time ());
        $maxTime = strftime ("%Y-%m-%d %H:%M:%S", time () + 21 * 24 * 60 * 60);

        return $date > $minTime && $date < $maxTime;
        }

    public function getPreviousMatches ()
        {
        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $stadiumTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_STADIUM);
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);

        $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, $teamsTable->getIdColumn ());
        $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, $teamsTable->getIdColumn ());
        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $stadiumIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STADIUM, Sports::TABLE_STADIUM."_id");

        $homeTeamIds = SportsHelper::getPredecessorTeamIds ($context, $this->instance[$homeTeamColumn]);
        $awayTeamIds = SportsHelper::getPredecessorTeamIds ($context, $this->instance[$awayTeamColumn]);

        $criteria = SportsHelper::createMatchTableFilterCriterion ($this->context);
        $columns = array ($matchesTable->getIdColumn (), $homeTeamColumn, $awayTeamColumn,
                          Sports::COL_MATCH_HOMETEAM.".".Sports::COL_TEAM_SHORTNAME,
                          Sports::COL_MATCH_AWAYTEAM.".".Sports::COL_TEAM_SHORTNAME,
                          Sports::COL_MATCH_DATE, $competitionIdColumn,
                          Sports::COL_MATCH_STADIUM, Sports::COL_MATCH_RESULT,
                          Sports::COL_MATCH_HOMERESULT, Sports::COL_MATCH_AWAYRESULT);
        $criteria[] = new LogicalOperatorOr
                            (
                            new LogicalOperatorAnd
                                (
                                new InCriterion ($homeTeamColumn, $homeTeamIds),
                                new InCriterion ($awayTeamColumn, $awayTeamIds)
                                ),
                            new LogicalOperatorAnd
                                (
                                new InCriterion ($homeTeamColumn, $awayTeamIds),
                                new InCriterion ($awayTeamColumn, $homeTeamIds)
                                )
                            );
        $criteria[] = new LtCriterion ("c_".Sports::COL_MATCH_DATE, strftime ("%Y-%m-%d %H:%M:%S", time ()));

        $joins = NULL;
        $unofficial = false;

        if (!$unofficial)
            {
            $competitionsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
            $competitionIdColumn = "f_".Sports::COL_MATCH_COMPETITION."_".$competitionsTable->getIdColumn ();
            $competitionsCriteria[] = new JoinColumnsCriterion ($competitionIdColumn, $competitionsTable->getIdColumn ());
            $competitionsCriteria[] = new JoinChildCriterion ("c_".Sports::COL_COMPETITION_UNOFFICIAL, 1, '<>');
            $competitionColumns[] = new ConditionalResultColumn ("official", "tbl2.".$competitionsTable->getIdColumn ()." IS NULL", 0, 1);
            $competitionJoin = $competitionsTable->createQuery ($competitionColumns, $competitionsCriteria);
            $competitionJoin->joinType = Constants::JOIN_LEFT_OUTER;
            $joins[] = $competitionJoin;
            }
        
        $params[] = OrderBy::create ("c_".Sports::COL_MATCH_DATE, false);
        $rows = $matchesTable->selectBy ($columns, $criteria, $joins, $params);
        if (empty ($rows))
            return false;

        $lng = Language::getInstance ($this->context);
        $prepared = array ();
        foreach ($rows as $row)
            {
            $p = array ();
            foreach (array ("c_".Sports::COL_MATCH_DATE => "date",
                            Sports::COL_MATCH_STADIUM => "stadium",
                            Sports::COL_MATCH_COMPETITION => "league",
                            "c_".Sports::COL_MATCH_RESULT => "result",
                            Sports::COL_MATCH_HOMETEAM => "hometeam",
                            Sports::COL_MATCH_AWAYTEAM => "awayteam") as $key1 => $key2)
                {
                $p[$key2] = $row[$key1];
                }

            $p['hometeam_uri'] = ContentUrl::createViewLink ($this->context, $teamsTable, $p['hometeam']);
            $p['hometeam'] = $row[Sports::COL_MATCH_HOMETEAM.".c_".Sports::COL_TEAM_SHORTNAME];
            $p['awayteam_uri'] = ContentUrl::createViewLink ($this->context, $teamsTable, $p['awayteam']);
            $p['awayteam'] = $row[Sports::COL_MATCH_AWAYTEAM.".c_".Sports::COL_TEAM_SHORTNAME];
            $p['stadium_uri'] = ContentUrl::createViewLink ($this->context, $stadiumTable, $p['stadium']);
            $p['stadium'] = $row[Sports::COL_MATCH_STADIUM.".c_".ContentTable::COL_DISPLAY_NAME];
            $p['date'] = $lng->dateToLongString ($p['date'], "day");
            $p['result_uri'] = ContentUrl::createViewLink ($this->context, $matchesTable, $row[$matchesTable->getIdColumn ()]);
            $prepared[] = $p;
            }

        return $prepared;
        }

    public function getComparisonData ()
        {
        $res = array ();

        $competitionColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        if (!empty ($this->instance[$competitionColumn]))
            {
            $this->instance[$competitionColumn];
            $this->teams = LeagueTableCollector::retrieveSimpleTable ($this->context, $this->instance[$competitionColumn]);

            if (!empty ($this->teams))
                {
                $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id");
                $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id");
                $homePlace = $awayPlace = NULL;
                $homePoints = $awayPoints = NULL;

                foreach ($this->teams as $key => $team)
                    {
                    if ($key == $this->instance[$homeTeamColumn])
                        {
                        $team->checkDefaults ();
                        $homeTeamStats = $team;
                        $homePoints = $team->ptsHome + $team->ptsAway - $team->deduction;
                        $homeMatchesAtHome = $team->getHomeGames ();
                        $homeMatchesAway = $team->getAwayGames ();
                        $homeMatches = $team->getTotalGames ();
                        $homeScored = $team->scoredHome + $team->scoredAway;
                        // conceded
                        // homeMatches, resultsAgainst, scoresAgainst
                        };
                    if ($key == $this->instance[$awayTeamColumn])
                        {
                        $team->checkDefaults ();
                        $awayTeamStats = $team;
                        $awayPoints = $team->ptsHome + $team->ptsAway - $team->deduction;
                        $awayMatchesAtHome = $team->getHomeGames ();
                        $awayMatchesAway = $team->getAwayGames ();
                        $awayMatches = $team->getTotalGames ();
                        $awayScored = $team->scoredHome + $team->scoredAway;
                        };
                    }

                if (!empty ($homeTeamStats) || !empty ($awayTeamStats))
                    {
                    $res[] = array ('label' => $this->getText ('Current place in the league'), 'home' => $homeTeamStats->place, 'away' => $awayTeamStats->place);
                    $res[] = array ('label' => $this->getText ('League points'), 'home' => $homePoints, 'away' => $awayPoints);
                    $res[] = array ('label' => $this->getText ('League matches this season'), 'home' => $homeMatches, 'away' => $awayMatches);

                    if ($homeMatches > 0 || $awayMatches > 0)
                        {
                        $res[] = array ('label' => $this->getText ('League goals this season'),
                                        'home' => $this->getTotalAndAverage ($homeScored, $homeMatches),
                                        'away' => $this->getTotalAndAverage ($awayScored, $awayMatches));
                        }
                    if ($homeMatchesAtHome > 0 || $awayMatchesAtHome > 0)
                        {
                        $res[] = array ('label' => $this->getText ('League home goals this season'),
                                        'home' => $this->getTotalAndAverage ($homeTeamStats->scoredHome, $homeMatchesAtHome),
                                        'away' => $this->getTotalAndAverage ($awayTeamStats->scoredHome, $awayMatchesAtHome));
                        }
                    if ($homeMatchesAway > 0 || $awayMatchesAway > 0)
                        {
                        $res[] = array ('label' => $this->getText ('League away goals this season'),
                                        'home' => $this->getTotalAndAverage ($homeTeamStats->scoredAway, $homeMatchesAway),
                                        'away' => $this->getTotalAndAverage ($awayTeamStats->scoredAway, $awayMatchesAway));
                        }
                    }
                }
            }

        return $res;
        }

    protected function getTotalAndAverage ($total, $games)
        {
        if ($games <= 0)
            return $this->getText ("N/A");
            
        if (0 == $total)
            return "0";
        return $this->getText ("[_0] ([_1] per game)", $total,
                               $this->lng->decimalToString ($total / $games, 2));
        }
    }


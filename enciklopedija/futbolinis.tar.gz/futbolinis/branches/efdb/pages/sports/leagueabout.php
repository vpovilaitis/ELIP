<?php
require_once (PATH."inc/sports/constants.php");
require_once (PATH."inc/sports/common.php");
require_once (PATH."pages/simpletext.php");

class LeagueAbout extends SimpleText
    {
    protected $leagueId;
    protected $instance;

    public function __construct ($context, $table, $leagueId, $instance)
        {
        $this->leagueId = $leagueId;
        $this->instance = $instance;
        parent::__construct ($context, "a", $table->getName ());

        $context->addStyleSheet ("sports");

        $this->title = $this->getText ("About|competition");
        $this->titleInline = true;
        }

    public function isVisible ()
        {
        return true;
        }

    public function getDisplayedText ()
        {
        /* some usefull information about the competition season:
            - generic description ("2010-2011 Premier League - 18th season of 1st England football pyramid tier."; with links to "2010-2011" season, "1st tier", "England")
            - dates ("Season started on June 15, 2010, finished on ...")
            - champion? (including information which time), relegated teams (before and after the season), promoted teams (before the season)
            - managed by association/federation/etc
            - If just a stage of wider competition, mention parent and neighbours
        */

        $leagueId = 0;
        if (SIMPLIFIED_TEAM_LABELS)
            $leagueId = NULL;
        else if (!empty ($this->instance[Sports::COL_COMPETITION_LEAGUE]))
            $leagueId = $this->instance[Sports::COL_COMPETITION_LEAGUE][0];

        if ($leagueId > 0)
            {
            if (UNSPECIFIED_COMPETITION_ID == $leagueId)
                $leagueIds = $previousSeasons = array ();
            else
                {
                $leagueIds = SportsHelper::colectLeaguePredecessors ($this->context, $leagueId);
                $previousSeasons = SportsHelper::selectLeagueCompetitionSeasons ($this->context, $leagueIds, $this->leagueId, $nextSeason);
                if (!empty ($previousSeasons))
                    array_pop ($previousSeasons);
                }
            }
        else
            $nextSeason = $previousSeasons = NULL;

        $statements[] = $this->getGenericDescription ($this->instance, $previousSeasons);
        $startFinishStatement = $this->getStartFinishDescription ($this->instance);
        if (!empty ($startFinishStatement))
            $statements[] = trim ($startFinishStatement, ". ").".";;
        $predecessorStatement = $this->getChangesDescription ($this->instance, $previousSeasons, $nextSeason);
        if (!empty ($predecessorStatement))
            $statements[] = trim ($predecessorStatement, ". ").".";;
        return implode (" ", $statements);
        }

    protected function getLinkWithLabel ($tableName, $row, $propertyName, $displayNameColumn = NULL)
        {
        if (empty ($row[$propertyName]))
            return NULL;

        if (NULL === $displayNameColumn)
            $displayNameColumn = ContentTable::COL_DISPLAY_NAME;
        else
            $displayNameColumn = "c_".$displayNameColumn;

        $id = $row[$propertyName];
        $label = $row[$propertyName.".".$displayNameColumn];
        $dbtable = ContentTable::createInstanceByName ($this->context, $tableName);
        if (empty ($dbtable))
            return $label;

        $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $dbtable,
                                                                     $dbtable->getId (), $id);

        return "<a href=\"$url\">$label</a>";
        }

    protected function getStartFinishDescription ($row)
        {
        $started = $row["c_".Sports::COL_COMPETITION_STARTS];
        $ended = $row["c_".Sports::COL_COMPETITION_ENDS];
        $teamCount = $row["c_".Sports::COL_COMPETITION_TEAM_COUNT];

        if (!empty ($started) && !empty ($ended))
            {
            if (!empty ($_REQUEST["today"]))
                $now = strtotime ($_REQUEST["today"]);
            if (empty ($now))
                $now = time ();

            $lng = Language::getInstance ($this->context);
            $today = date ("Y-m-d", $now);
            $startedLong = $lng->dateToLongString ($started);
            $endedLong = $lng->dateToLongString ($ended);
            
            if (!empty ($teamCount))
                {
                if ($started > $today)
                    return $this->ngettext ("[_0] team competition is planned to start on [_1] and last till [_2].", "[_0] teams competition is planned to start on [_1] and last till [_2].", $teamCount, $startedLong, $endedLong);
                if ($ended > $today)
                    return $this->ngettext ("[_0] team competition has started on [_1] and is planned to last till [_2].", "[_0] teams competition has started on [_1] and is planned to last till [_2].", $teamCount, $startedLong, $endedLong);

                return $this->ngettext ("[_0] team competed from [_1] to [_2].", "[_0] teams competed from [_1] to [_2].", $teamCount, $startedLong, $endedLong);
                }
            else
                {
                if ($started > $today)
                    return $this->getText ("Competition is planned to start on [_0] and last till [_1].", $startedLong, $endedLong);
                if ($ended > $today)
                    return $this->getText ("Competition has started on [_0] and is planned to last till [_1].", $startedLong, $endedLong);

                return $this->getText ("Season lasted from [_0] to [_1].", $startedLong, $endedLong);
                }
            }
        else if (!empty ($teamCount))
            {
            return $this->ngettext ("[_0] team competed this season.", "[_0] teams competed this season.", $teamCount);
            }
        }

    protected function getChangesDescription ($row, $previousSeasons, $nextSeason)
        {
        if (empty ($previousSeasons) && empty ($nextSeason))
            return NULL;
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        if (empty ($dbtable))
            return NULL;

        $previousSeasonLabel = $nextSeasonLabel = NULL;
        if (!empty ($previousSeasons))
            {
            $previousSeason = array_pop ($previousSeasons);
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $dbtable,
                                                                         $dbtable->getId (), $previousSeason["id"]);

            $seasonLabel = empty ($previousSeason["season"]) ? "" : $previousSeason["season"];
            $label = $this->getText ("[_0] [_1]|season and competition name", $seasonLabel, $previousSeason["name"]);
            $previousSeasonLabel = "<a href=\"$url\">$label</a>";
            }

        if (!empty ($nextSeason))
            {
            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $dbtable,
                                                                         $dbtable->getId (), $nextSeason["id"]);

            $label = $this->getText ("[_0] [_1]|season and competition name", $nextSeason["season"], $nextSeason["name"]);
            $nextSeasonLabel = "<a href=\"$url\">$label</a>";
            }

        if (!empty ($previousSeasonLabel) && !empty ($nextSeasonLabel))
            return "<br><br>".$this->getText ("Preceeding season - [_0], succeeding - [_1].", $previousSeasonLabel, $nextSeasonLabel);
        else if (!empty ($previousSeasonLabel))
            return "<br><br>".$this->getText ("Preceeding season - [_0].", $previousSeasonLabel);
        else if (!empty ($nextSeasonLabel))
            return "<br><br>".$this->getText ("Succeeding season - [_0].", $nextSeasonLabel);
        else
            return null;
        }

    protected function getGenericDescription ($row, $previousSeasons)
        {
        $name = $row["c_".Sports::COL_COMPETITION_NAME];
        $level = $row["c_".Sports::COL_COMPETITION_LEVEL];
        $partOf = $this->getLinkWithLabel (Sports::TABLE_COMPETITIONSTAGE, $row, Sports::COL_COMPETITION_PARENT, Sports::COL_COMPETITION_NAME);
        $country = $this->getLinkWithLabel (Sports::TABLE_COUNTRY, $row, Sports::COL_COMPETITION_REGION);
        $season = $this->getLinkWithLabel (Sports::TABLE_SEASON, $row, Sports::COL_COMPETITION_SEASON);

        if (!empty ($partOf))
            {
            $statement = $this->getText ("[_0] <b>[_1]</b> - part of [_2].|0 - season, 1 - competition name", $season, $name, $partOf);
            // TODO: enumerate neighbouring stages
            }
        else
            {
            $parentCompetitionId = UNSPECIFIED_COMPETITION_ID;
            if (!SIMPLIFIED_TEAM_LABELS)
                $parentCompetitionId = $row[Sports::COL_COMPETITION_LEAGUE][0];
            
            if (UNSPECIFIED_COMPETITION_ID == $parentCompetitionId)
                $leagueName = $this->getText ("unspecified competition");
            else
                {
                $leagueName = $this->getLinkWithLabel (Sports::TABLE_LEAGUE, $row, Sports::COL_COMPETITION_LEAGUE);

                if (!empty ($leagueName))
                    $seasonNumber = count ($previousSeasons) + 1;
                }

            if (!empty ($season) && !empty ($level) && !empty ($country))
                {
                $statement = $this->getText ("[_0] <b>[_1]</b> - [_2] level competition organized in [_3]|0 - season, 1 - competition name", $season, $name, $level, $country);

                if (!empty ($seasonNumber));
                    $statement = $this->getText ("[_0], [_1] season of [_2]", $statement, $seasonNumber, $leagueName);
                }
            else if (!empty ($season))
                {
                $statement = $this->getText ("[_0] <b>[_1]</b>|0 - season, 1 - competition name", $season, $name);

                if (!empty ($seasonNumber));
                    $statement = $this->getText ("[_0] - [_1] season of [_2]", $statement, $seasonNumber, $leagueName);
                }
            }

        return trim ($statement, ". ").".";
        }

    public function getMoreInformationUrl ()
        {
        $params = array ("view" => "about");
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        return LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $dbtable,
                                                                     $dbtable->getId (),
                                                                     $this->leagueId, Constants::MODE_VIEW, $params);
        }
    }

<?php
require_once (PATH.'inc/sports/predictortable.php');
require_once (PATH.'pages/sports/generatematchannouncement.php');

class ManagePrediction extends Submit
    {
    protected $dbtable;
    protected $output;
    protected $existing = false;
    protected $matchId = NULL;
    protected $announcedMatches = NULL;

    public function __construct ($context, $request)
        {
        $this->dbtable = new PredictorGameTable ($context);
        $context->addScriptFile ("autosuggest");
        $context->addStyleSheet ("sports");
        parent::__construct ($context, NULL, PredictorGameTable::TABLE_SCOPE, PredictorGameTable::TABLE_NAME);
        $this->submitScores = false;
        if (!empty ($_REQUEST["scores"]) && defined ("MATCH_PREDICTOR_ADMINISTRATORS"))
            {
            $administrators = preg_split ("/[,; ]/", MATCH_PREDICTOR_ADMINISTRATORS);
            $this->submitScores = false !== array_search ($context->getCurrentUser (), $administrators);
            }
        }

    public function ensureTitle ($context, &$request)
        {
        $title = $this->getText ("Manage predictions");
        $context->setTitle ($title);
        return true;
        }

    protected function checkAccess ($request)
        {
        if (defined ("MATCH_PREDICTOR_ADMINISTRATORS"))
            {
            $administrators = preg_split ("/[,; ]/", MATCH_PREDICTOR_ADMINISTRATORS);
            if (false !== array_search ($this->context->getCurrentUser (), $administrators))
                return true;
            }
        return parent::checkAccess ($request);
        }

    protected function getAllAnnouncedMatches ($matchId = NULL, $includeOldMatches = false)
        {
        if (empty ($matchId) && NULL !== $this->announcedMatches)
            return $this->announcedMatches;

        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $criteria = NULL;
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        $joinCriterion = array ();
        $joinCriterion[] = new JoinColumnsCriterion (PredictorGameTable::COL_MATCH_ID, $matchesTable->getIdColumn ());

        if (!empty ($matchId))
            $joinCriterion[] = new EqCriterion ($matchesTable->getIdColumn (), $matchId);
        else if (!$includeOldMatches)
            $joinCriterion[] = new GtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d G:i:s", time ()-7*24*60*60));

        $params = array (OrderBy::create ("c_".Sports::COL_MATCH_DATE));
        $homeTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id");
        $awayTeamColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id");

        $joins[] = $matchesTable->createQuery (array ("c_".Sports::COL_MATCH_DATE, $homeTeamColumn, $awayTeamColumn),
                                               $joinCriterion, NULL, $params);

        $seasonTable = new PredictorSeasonTable ($this->context);
        $joinCriteria = array (new JoinColumnsCriterion (PredictorGameTable::COL_SEASON_ID, PredictorSeasonTable::COL_ID));
        $joins[] = $seasonTable->createQuery (array (), $joinCriteria);

        $rows = $this->dbtable->selectBy (array (PredictorGameTable::COL_ID, PredictorGameTable::COL_MATCH_ID, PredictorGameTable::COL_ANNOUNCEMENT_TEXT),
                                          $criteria, $joins);

        if (empty ($rows))
            return array ();
        
        $teamIds = array ();
        foreach ($rows as $row)
            {
            $teamIds[] = $row[$homeTeamColumn];
            $teamIds[] = $row[$awayTeamColumn];
            }

        $lng = Language::getInstance ($this->context);
        $teamLabels = SportsHelper::getTeamLabels ($this->context, $teamIds);
        foreach ($rows as &$row)
            {
            $row["home"] = $lng->beautifyTeamLabel ($teamLabels[$row[$homeTeamColumn]]);
            $row["away"] = $lng->beautifyTeamLabel ($teamLabels[$row[$awayTeamColumn]]);
            }

        if (empty ($matchId))
            $this->announcedMatches = $rows;
        return $rows;
        }

    protected function getSeasonsList ()
        {
        $seasonsTable = new PredictorSeasonTable ($this->context);
        $criteria = array ();
        $criteria[] = new LtCriterion (PredictorSeasonTable::COL_START_DATE, date ("Y-m-d G:i:s", time ()));
        $criteria[] = new LogicalOperatorOr (new GtEqCriterion (PredictorSeasonTable::COL_END_DATE, date ("Y-m-d 00:00:00", time ())),
                                             new IsNullCriterion (PredictorSeasonTable::COL_END_DATE));
        $seasonRows = $seasonsTable->selectBy (array (PredictorSeasonTable::COL_ID, PredictorSeasonTable::COL_LABEL, PredictorSeasonTable::COL_SEASON),
                                               $criteria);
        return $seasonRows;
        }

    public function getFields ()
        {
        if ($this->submitScores)
            {
            $usersTable = new UsersTable ($this->context);
            $rows = $usersTable->selectBy (array (UsersTable::COL_ID, UsersTable::COL_NAME, UsersTable::COL_EMAIL), NULL);
            $users = array ();
            foreach ($rows as $row)
                $users[$row[UsersTable::COL_ID]] = $row[UsersTable::COL_NAME]." (".$row[UsersTable::COL_EMAIL].")";

            $arr[] = new DropDownFieldTemplate ("", "user", $this->getText ("User:"), $this->getText ("User which did the guessing."), $users);

            foreach ($this->getAllAnnouncedMatches () as $row)
                {
                $label = $row["c_".Sports::COL_MATCH_DATE]." {$row["home"]}-{$row["away"]}";
                $arr[] = new TextFieldTemplate ("", "result".$row[PredictorGameTable::COL_ID], $label, $this->getText ("Guessed result."), 5);
                }

            return $arr;
            }

        $seasonRows = $this->getSeasonsList ();
        $seasons = array ();
        if (!empty ($seasonRows))
            {
            foreach ($seasonRows as $row)
                {
                $seasons[$row[PredictorSeasonTable::COL_ID]] = $row[PredictorSeasonTable::COL_LABEL];
                }
            }

        $arr[] = new DropDownFieldTemplate ("", "season", $this->getText ("Predictor season:"), $this->getText ("Select predictor season to create announcements in."), $seasons);
        $arr[] = new LongTextFieldTemplate ("", "text", $this->getText ("Announcement text:"), $this->getText ("Text to show in the predictor announcements."));
        return $arr;
        }

    public function collectInputData ($context, &$request)
        {
        if ($this->submitScores)
            {
            if (empty ($request["user"]))
                return array ("user" => NULL, "results" => NULL);

            $arr = array ("user" => $request["user"]);
            $results = array ();

            foreach ($this->getAllAnnouncedMatches () as $row)
                {
                $key = "result".$row[PredictorGameTable::COL_ID];
                if (empty ($request[$key]))
                    continue;
                $parts = preg_split ("/[-:]/", $request[$key]);
                if (2 != count ($parts) || !is_numeric ($parts[0]) || !is_numeric ($parts[1]))
                    {
                    $this->logError ("Incorrect result ({$request[$key]})");
                    continue;
                    }
                $results[$row[PredictorGameTable::COL_ID]] = $parts;
                }

            $arr["results"] = $results;
            return $arr;
            }

        if (empty ($request["id"]))
            return NULL;
        $matchId = $this->matchId = $request["id"];
        $rows = $this->dbtable->selectBy (array (PredictorGameTable::COL_ID, PredictorGameTable::COL_ANNOUNCEMENT_TEXT),
                                          array (new EqCriterion (PredictorGameTable::COL_MATCH_ID, $matchId)));
        $this->existing = empty ($rows) ? false : $rows[0][PredictorGameTable::COL_ID];

        if (empty ($request['text']))
            {
            if (empty ($rows))
                {
                $processor = new GenerateMatchAnnouncement ($context, $request);
                $processor->generateAnnouncementForMatch ($context, $matchId, false, false, false);
                $request['text'] = str_replace ("\n<br>\n", "\n", $processor->getResultOutput (true));
                }
            else
                $request['text'] = $rows[0][PredictorGameTable::COL_ANNOUNCEMENT_TEXT];
            }

        if (empty ($request['season']))
            {
            $matchesTable = ContentTable::createInstanceByName ($context, "match");
            $seasonColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
            $row = $matchesTable->selectSingleBy (array ($seasonColumn), array (new EqCriterion ($matchesTable->getIdColumn (), $matchId)));

            if (!empty ($row) && !empty ($row[$seasonColumn]))
                {
                $availableSeasons = $this->getSeasonsList ();
                foreach ($availableSeasons as $season)
                    {
                    if ($season[PredictorSeasonTable::COL_SEASON] == $row[$seasonColumn])
                        {
                        $request["season"] = $season[PredictorSeasonTable::COL_ID];
                        break;
                        }
                    }
                }
            }
        $seasonId = empty ($request["season"]) ? NULL : $request["season"];
        return array ("match" => $matchId, "text" => $request['text'], "season" => $seasonId);
        }

    public function validateInput ($context, &$input)
        {
        return !empty ($input);
        }

    public function saveInput ($context, &$request, &$input)
        {
        if ($this->submitScores)
            {
            if (empty ($input["user"]))
                return $this->logError ("Invalid parameters");
            
            if (empty ($input["results"]))
                return true;
            $userId = $input["user"];
            $predictionsTable = new PredictorGuessTable ($context);
            foreach ($input["results"] as $id => $result)
                {
                $namesToValues = array (PredictorGuessTable::COL_GAME_ID => $id,
                                        PredictorGuessTable::COL_USER_ID => $userId,
                                        PredictorGuessTable::COL_GOALS_HOME => $result[0],
                                        PredictorGuessTable::COL_GOALS_AWAY => $result[1],
                                        );
                $success = $predictionsTable->insertRecord ($namesToValues);
                if (false === $success)
                    $this->logError ("Error recording the result");
                }

            $this->output = $this->getText ("Guess entries recorded ([_0])", count ($input["results"]));
            return true;
            }

        if (empty ($input["match"]) || empty ($input["text"]) || empty ($input["season"]))
            return $this->logError ("Invalid parameters");

        $namesToValues = array ();
        $namesToValues[PredictorGameTable::COL_ANNOUNCEMENT_TEXT] = $input["text"];
        if (!$this->existing)
            {
            $namesToValues[PredictorGameTable::COL_SEASON_ID] = $input["season"];
            $namesToValues[PredictorGameTable::COL_MATCH_ID] = $input["match"];
            if (false === $this->dbtable->insertRecord ($namesToValues))
                return false;
            $this->output = $this->getText ("Announcement was created");
            }
        else
            {
            $criteria[] = new EqCriterion (PredictorGameTable::COL_ID, $this->existing);
            if (false === $this->dbtable->updateRecord ($criteria, $namesToValues))
                return false;
            $this->output = $this->getText ("Announcement was updated");
            }

        return true;
        }

    public function getResultOutput ()
        {
        $output = "";
        if ($this->submitScores)
            {
            $predictionsTable = new PredictorGuessTable ($this->context);
            $columns = array (PredictorGuessTable::COL_USER_ID, PredictorGuessTable::COL_GAME_ID, PredictorGuessTable::COL_GOALS_HOME, PredictorGuessTable::COL_GOALS_AWAY);
            $rows = $predictionsTable->selectBy ($columns, NULL);
            $guessesByGame = array ();
            $userIndexes = array ();
            foreach ($rows as $row)
                {
                $gameId = $row[PredictorGuessTable::COL_GAME_ID];
                $userId = $row[PredictorGuessTable::COL_USER_ID];
                if (!array_key_exists ($gameId, $guessesByGame))
                    $guessesByGame[$gameId] = array ();

                $guessesByGame[$gameId][$userId] = array ($row[PredictorGuessTable::COL_GOALS_HOME], $row[PredictorGuessTable::COL_GOALS_AWAY]);
                if (!array_key_exists ($userId, $userIndexes))
                    $userIndexes[$userId] = count ($userIndexes) + 1;
                }

            $users = array ();
            if (!empty ($userIndexes))
                {
                $usersTable = new UsersTable ($this->context);
            
                $rows = $usersTable->selectBy (array (UsersTable::COL_ID, UsersTable::COL_NAME, UsersTable::COL_EMAIL), array (new InCriterion (UsersTable::COL_ID, array_keys ($userIndexes))));
                foreach ($rows as $row)
                    $users[$row[UsersTable::COL_ID]] = $row[UsersTable::COL_NAME]."<br/>(".$row[UsersTable::COL_EMAIL].")";
                }

            $output .= "<table border=\"1\" class=\"manage_predictions\"><thead><th>&nbsp;</th>";
            foreach ($userIndexes as $userId => $index)
                $output .= "<th>".$users[$userId]."</th>";
            $output .= "</thead>";
            
            foreach ($this->getAllAnnouncedMatches () as $row)
                {
                $output .= "<tr>";
                $label = $row["c_".Sports::COL_MATCH_DATE]." {$row["home"]}-{$row["away"]}";
                $output .= "<td>".$label."</td>";
                $gameId = $row[PredictorGameTable::COL_ID];

                foreach ($userIndexes as $userId => $index)
                    {
                    $output .= "<td>".(empty ($guessesByGame[$gameId]) || !array_key_exists ($userId, $guessesByGame[$gameId]) ? "&nbsp;" : implode (":", $guessesByGame[$gameId][$userId]))."</td>";
                    }
                $output .= "</tr>";
                }
            $output .= "</table>";
            }
        else if ($this->existing)
            {
            $url = $this->context->getAdjustedUrl (array ("scores" => 1));
            $output .= $this->getText ("Match announcement is already created. You can <a href=\"[_0]\">enter the scores</a> of other users.", $url);

            $predictionsTable = new PredictorGuessTable ($this->context);

            $matchCriteria[] = new EqCriterion (PredictorGameTable::COL_MATCH_ID, $this->matchId);
            $matchCriteria[] = new JoinColumnsCriterion (PredictorGuessTable::COL_GAME_ID, PredictorGameTable::COL_ID);
            $joins[] = $this->dbtable->createQuery (array (), $matchCriteria);

            $columns = array (PredictorGuessTable::COL_USER_ID, PredictorGuessTable::COL_GAME_ID, PredictorGuessTable::COL_GOALS_HOME, PredictorGuessTable::COL_GOALS_AWAY);
            $rows = $predictionsTable->selectBy ($columns, array (), $joins);
            $guessesByUser = array ();
            foreach (empty ($rows) ? array () : $rows as $row)
                {
                $guessesByUser[$row[PredictorGuessTable::COL_USER_ID]] = array ($row[PredictorGuessTable::COL_GOALS_HOME], $row[PredictorGuessTable::COL_GOALS_AWAY]);
                }

            $users = array ();
            if (!empty ($guessesByUser))
                {
                $usersTable = new UsersTable ($this->context);
                $rows = $usersTable->selectBy (array (UsersTable::COL_ID, UsersTable::COL_NAME, UsersTable::COL_EMAIL), array (new InCriterion (UsersTable::COL_ID, array_keys ($guessesByUser))));
                foreach (!empty ($rows) ? $rows : array () as $row)
                    $users[$row[UsersTable::COL_ID]] = $row[UsersTable::COL_NAME];
                }

            $output .= "<table border=\"1\" class=\"manage_predictions\">";
            
            foreach ($this->getAllAnnouncedMatches ($this->matchId) as $row)
                {
                $label = $row["c_".Sports::COL_MATCH_DATE]." {$row["home"]}-{$row["away"]}";
                $output .= "<caption>".$label."</caption><thead><th>User</th><th>Guess</th></thead>";

                foreach ($guessesByUser as $userId => $guess)
                    {
                    $output .= "<tr>";
                    $output .= "<td>{$users[$userId]}</td>";
                    $guessLabel = $guess[0] > $guess[1] ? "<b>$guess[0]</b>:$guess[1]" : ($guess[1] > $guess[0] ? "$guess[0]:<b>$guess[1]</b>" : implode (":", $guess));
                    $output .= "<td>$guessLabel</td>";
                    $output .= "</tr>";
                    }
                }
            $output .= "</table>";
            }

        if (!empty ($this->output))
            $output .= (empty ($output) ? "" : "<br/><br/>").$this->output;

        return $output;
        }

    }

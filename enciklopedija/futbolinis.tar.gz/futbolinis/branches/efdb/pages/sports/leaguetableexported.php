<?php
require_once (PATH.'pages/sports/lightweightleaguetable.php');

class LeagueTableExported extends Page
    {
    protected $containedComponent;
    protected $inline = false;

    public function processInput ($context, &$request)
        {
        $this->inline = !empty ($request["inline"]);
        return true;
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function ensureChildren ($context, $request)
        {
        if (!empty ($this->containedComponent))
            return true;
        if (empty ($request["lid"]))
            return new ErrorComponent ("err", $context, $context->getText ("League not specified"));
        $this->inline = !empty ($request["inline"]);
        $mode = !empty ($request["mode"]) ? $request["mode"] : NULL;
        $leagueId = $request["lid"];
        $this->containedComponent = $this->createComponent ($context, $request, "c", $leagueId, $mode);
        if (!empty ($this->containedComponent))
            $this->addComponent ($request, "component", $this->containedComponent);

        return true;
        }

    protected function createComponent ($context, $request, $prefix, $leagueId, $mode)
        {
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);

        switch ($mode)
            {
            case "vertical":
            case "horizontal":
                require_once (PATH.'pages/sports/matchannouncement.php');
                $params = array (MatchAnnouncement::PARAM_COMPETITION => $leagueId,
                                 MatchAnnouncement::PARAM_VERTICAL => "vertical" == $mode,
                                 MatchAnnouncement::PARAM_MAX_ITEMS => !empty ($request["max"]) ? $request["max"] : 10,
                                 MatchAnnouncement::PARAM_MODE => !empty ($request["show"]) ? $request["show"] : NULL);
                return new MatchAnnouncement ($context, "mm", $dbtable, NULL, NULL, $params);

            default:
                $criteria = array (new EqCriterion ($dbtable->getIdColumn (), $leagueId));
                $columns = array ($dbtable->getIdColumn (), Sports::COL_COMPETITION_SYSTEM);
                $rows = $dbtable->selectBy ($columns, $criteria);
                if (empty ($rows))
                    return new ErrorComponent ($prefix, $context,
                                               $context->getText ("Competition was not found"));
                $class = $this->inline ? "LightweightLeagueTable" : "LeagueTableComponent";
                return new $class ($context, $dbtable, $leagueId, $rows[0]["c_".Sports::COL_COMPETITION_SYSTEM],
                                   NULL, false, true);
            }
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return $this->inline ? "simplecontainer" : "simplepage";
        }

    public function ensureTitle ($context, &$request)
        {
        parent::ensureTitle ($context, $request);
        $context->setTitle ($this->getText ("League table"));
        return true;
        }

    }

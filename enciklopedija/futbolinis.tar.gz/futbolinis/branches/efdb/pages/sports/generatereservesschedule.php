<?php
require_once (PATH.'pages/sports/submitgame.php');

class GenerateReservesSchedule extends SubmitGame
    {
    protected $teamIds = array ();
    protected $reserveTeams = array ();

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ("Create simple competition schedule");
        return true;
        }

    public function collectInputData ($context, &$request)
        {
        $this->createSourceFields ();
        $this->source = $this->sourcesField->getValueForDB ($context, $request);
        $this->sourceDate = $this->sourcesDateField->getValueForDB ($context, $request);

        $matches = $this->createSchedule ($request);
        return $matches;
        }
        
    public function validateInput ($context, &$input)
        {
        if (false === parent::validateInput ($context, $input))
            return false;
        }

    protected function createSchedule ($request)
        {
        $matches = array ();
        $targetCompetition = $request[Sports::COL_MATCH_COMPETITION];
        $templateCompetition = $request["templateCompetition"];
        if (empty ($templateCompetition))
            return $matches;

        $competitionIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $homeTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id");
        $awayTeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id");
        $criteria = array ();
        $criteria[] = new EqCriterion ($competitionIdColumn, $templateCompetition);
        $columns = array ($homeTeamIdColumn, new FunctionCount ("*","cnt"));

        $params = array ();
        $params[] = new GroupByAll ();
        $rows = $this->dbtable->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rows))
            return $matches;

        $allTeamsSet = true;
        foreach ($rows as $row)
            {
            $teamId = $row[$homeTeamIdColumn];
            $this->teamIds[] = $teamId;
            if (empty ($this->reserveTeams[$teamId]))
                $allTeamsSet = false;
            }

        if (!$allTeamsSet)
            return $matches;

        $roundIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_STAGE, Sports::TABLE_ROUND."_id");
        $columns = array ($homeTeamIdColumn, $awayTeamIdColumn, Sports::COL_MATCH_DATE, Sports::COL_MATCH_MATCHDAY, $roundIdColumn);

        $rows = $this->dbtable->selectBy ($columns, $criteria);
        if (empty ($rows))
            return $matches;

        foreach ($rows as $row)
            {
            $match = array ();
            $match[SubmitGame::MATCH_DATE] = date ("Y-m-d", strtotime("+1 day", strtotime ($row["c_".Sports::COL_MATCH_DATE])));
            $match["homeTeamId"] = $this->reserveTeams[$row[$awayTeamIdColumn]];
            $match["awayTeamId"] = $this->reserveTeams[$row[$homeTeamIdColumn]];
            $match["roundId"] = $row[$roundIdColumn];
            $match["round"] = $row["c_".Sports::COL_MATCH_MATCHDAY];

            $matches[] = $match;
            }

        return $matches;
        }

    protected function onInputFieldCollected ($context, &$request, $type, $key, $val)
        {
        if (!empty ($val))
            {
            switch ($type)
                {
                case "team":
                    $this->reserveTeams[$key] = $val;
                    break;
                }
            }
        }

    public function createSourceFields ()
        {
        if (empty ($this->competitionField))
            {
            $seasonColumn = clone $this->dbtable->findColumn (Sports::COL_MATCH_COMPETITION);
            $this->competitionField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $seasonColumn);
            $seasonColumn = clone $seasonColumn;
            $seasonColumn->label = "Cloned competition:";
            $seasonColumn->name = "templateCompetition";
            $this->templateCompetitionField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $seasonColumn);
            }

        parent::createSourceFields ();
        }

    protected function processInputFields ($context, &$request)
        {
        parent::processInputFields ($context, $request);
        $this->templateCompetitionField->processInput ($context, $request);
        $this->competitionField->processInput ($context, $request);
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();
        $arr = array
            (
            $this->competitionField,
            $this->templateCompetitionField,
            );

        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $labels = SportsHelper::getTeamLabels ($this->context, $this->teamIds);
        foreach ($this->teamIds as $teamId)
            {
            $field = $this->createField ("team", "hometeam", $teamId);
            $field->label = $labels[$teamId];
            $arr[] = $field;
            }

        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }
    }

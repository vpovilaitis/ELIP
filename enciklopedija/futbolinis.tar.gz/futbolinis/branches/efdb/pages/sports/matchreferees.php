<?php
require_once (PATH."pages/contentpreview.php");
require_once (PATH."inc/morelinkfieldtemplate.php");
require_once (PATH."inc/sports/constants.php");

class MatchReferees extends ContentPreview
    {
    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $context->addStyleSheet ("sports");
        }

    public function getTemplateName ()
        {
        return "sports/matchreferees";
        }

    public function getPageSize ()
        {
        return -1;
        }

    public function getFields ()
        {
        return parent::getTemplate ();
        }

    protected function isFieldVisible ($col, &$hiddenFields)
        {
        if ($col instanceof ValueColumn && $col->name == Sports::COL_REFEREE_CATEGORY)
            return true;

        return parent::isFieldVisible ($col, $hiddenFields);
        }

    protected function addMoreLink ($idColumns, $hiddenFields)
        {
        return new TinyMoreLinkFieldTemplate ($this->context, $this->dbtable->getId (),
                                          $idColumns, $hiddenFields, "i");
        }

    public function select ($context, $criteria = NULL)
        {
        $rows = parent::select ($context, $criteria);
        if (empty ($rows))
            return $rows;

        $personsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_PERSON);
        $refereeTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCHREFEREE);
        if (empty ($personsTable) || empty ($refereeTable))
            var_dump ("Error");

        $categoryColumn = $refereeTable->findColumn (Sports::COL_REFEREE_CATEGORY);
        $result = array ();
        foreach ($rows as $row)
            {
            $entry = array ();
            $typeId = $row[Sports::COL_REFEREE_TYPE];
            switch ($typeId[0])
                {
                case MatchConstants::REFEREE_PRIMARY:
                    $entry["type"] = $context->getText ("Referee:");
                    break;
                case MatchConstants::REFEREE_ASSISTANT1:
                case MatchConstants::REFEREE_ASSISTANT2:
                case MatchConstants::REFEREE_ASSISTANT_UNSPECIFIED:
                    $entry["type"] = $context->getText ("Assistant:");
                    break;
                case MatchConstants::REFEREE_RESERVE:
                    $entry["type"] = $context->getText ("4th referee:");
                    break;
                case MatchConstants::REFEREE_INSPECTOR:
                    $entry["type"] = $context->getText ("Inspector:");
                    break;
                case MatchConstants::REFEREE_DELEGATE:
                    $entry["type"] = $context->getText ("Delegate:");
                    break;
                default:
                    $entry["type"] = $row[Sports::COL_REFEREE_TYPE.".".ContentTable::COL_DISPLAY_NAME];
                    break;
                }

            $id = array ($row[Sports::TABLE_MATCH."_id"], $row[Sports::TABLE_MATCHREFEREE."_id"]);
            $entry["url"] = LabelContentLinkFieldTemplate::createContentViewLink ($context, $this->dbtable,
                                                                     $this->dbtable->getId (), $id);

            $refereeId = $row["f_".Sports::COL_MATCH_REFEREE."_".Sports::TABLE_PERSON."_id"];
            if (!empty ($personsTable))
                $refereeUrl = LabelContentLinkFieldTemplate::createContentViewLink ($context, $personsTable,
                                                                         $personsTable->getId (), $refereeId);

            if (empty ($row[Sports::COL_MATCH_REFEREE.".c_".Sports::COL_PERSON_FIRST_NAME]) && empty ($row[Sports::COL_MATCH_REFEREE.".c_".Sports::COL_PERSON_SURNAME]))
                $label = $row[Sports::COL_MATCH_REFEREE.".".ContentTable::COL_DISPLAY_NAME];
            else
                $label = $row[Sports::COL_MATCH_REFEREE.".c_".Sports::COL_PERSON_FIRST_NAME]." ".$row[Sports::COL_MATCH_REFEREE.".c_".Sports::COL_PERSON_SURNAME];

            $refereeLabel = "<a href=\"$refereeUrl\">$label</a>";
            $additional = array ();
            if (!empty ($row["c_".Sports::COL_REFEREE_FROM]))
                $additional[] = $row["c_".Sports::COL_REFEREE_FROM];
            if (!empty ($row["c_".Sports::COL_REFEREE_CATEGORY]))
                $additional[] = NamedIntColumn::getItem ($categoryColumn, $row["c_".Sports::COL_REFEREE_CATEGORY]);

            if (!empty ($additional))
                $refereeLabel .= " (".implode ("; ", $additional).")";
            $entry["referee"] = $refereeLabel;
            $result[] = $entry;
            }
        return $result;
        }

    public function getAdditionalActions ()
        {
        $ret = array ();
        if (NULL != $this->dbtable && ($this->dbtable->canCreate () || $this->dbtable->canEdit ()) && NULL != $this->parentId)
            {
            $idparam = "&id=".implode ("_", $this->parentId);

            $url = "index.php?c=ContentPage&action=".Constants::MODE_EDIT."&tid={$this->dbtable->getParentTable()->getId()}$idparam&parts=".MatchEditorMode::REFEREES;
            $ret[] = new AdditionalURLIcon ($this, "edit", $this->_("Edit referees"), $url);
            }

        return $ret;
        }
    }

<?php
require_once (PATH.'pages/submit.php');
require_once (PATH.'pages/contenteditor.php');
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/relationfields.php');
require_once (PATH.'inc/sports/constants.php');

class SubmitLeagueScores extends Submit
    {
    protected $readyForInput = false;

    const FORMAT_FULL = "full";
    const FORMAT_EXTENDED = "ext";
    const FORMAT_SIMPLE = "simple";
    const FORMAT_MINI = "mini";

    public function __construct ($context, $request)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMLEAGUESEASON);

        if (!$this->dbtable)
            {
            $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        $context->addScriptFile ("autosuggest");
        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ("Lygos rezultatų suvedimas");
        return true;
        }

    public function collectInputData ($context, &$request)
        {
        if (empty ($request["format"]) || empty ($request["parse"]))
            return array ();

        return $this->processResults ($request["format"], $request["parse"]);
        }

    public function validateInput ($context, &$input)
        {
        return true;
        }

    public function saveInput ($context, &$request, &$results)
        {
        $this->readyForInput = true;
        $context->setFormActionUrl ($context->processUrl ("index.php?c=ContentPage&tn=teamleagueseasons&action=new", true));

        /*
        Simulate POST request by setting
            e_source                - 
            e_sourcedate            - 
            e_instances, e_count    - Number of generated instances

        And for each created instance:
            e_e0___parent___label   - Name of the team
            e_e0_season             - League season id
            e_e0_inform             - 1
            e_e0_action             - new
            e_e0_c_place, e_e0_c_win, e_e0_c_draw, e_e0_c_lost, e_e0_c_scored, e_e0_c_conceded, e_e0_c_pts, 
        */
        $parentPrefix = "e_";
        $newRequest = array ();
        $newRequest[$parentPrefix."source"] = $request["source"];
        $newRequest[$parentPrefix."sourcedate"] = $request["sourcedate"];
        $newRequest[$parentPrefix."instances"] = count ($results);
        $newRequest[$parentPrefix."count"] = count ($results);
        
        if (!empty ($request["year"]))
            $postfix = " ".$request["year"];
        else
            $postfix = "";

        if (!empty ($_GET["season"]))
            {
            $dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
            $seasonRow = $dbtable->selectSingleBy (array (ContentTable::COL_DISPLAY_NAME), array (new EqCriterion ($dbtable->getIdColumn (), $request["season"])));
            if (!empty ($seasonRow))
                $seasonLabel = $seasonRow[ContentTable::PREFIX.ContentTable::COL_DISPLAY_NAME];
            else
                $seasonLabel = "ERR";
            }
        else
            {
            $seasonLabel = $request["season_label"];
            }

        for ($i = 0; $i < count ($results); $i++)
            {
            $prefix = $parentPrefix."e{$i}_";
            $row = $results[$i];
            $newRequest[$prefix."season"] = $request["season"];
            $newRequest[$prefix."season_label"] = $seasonLabel;
            $newRequest[$prefix."season_c"] = $seasonLabel;
            $newRequest[$prefix."inform"] = 1;
            $newRequest[$prefix."action"] = "new";

            foreach ($row as $key => $value)
                {
                if ("label" == $key)
                    $newRequest[$prefix.Constants::PARENT."_label"] = trim ($value).$postfix;
                else
                    $newRequest[$prefix."c_".$key] = $value;
                }
            }

        $this->component = new ContentEditor ($context, $this->dbtable);
        $this->component->setMode (true, NULL);
        $this->addComponent ($newRequest, "", $this->component);
        return true;
        }

    public function processResults ($format, $plainResults)
        {
        $containsErrors = false;
        $parsed = array ();
        $lines = preg_split("#[\n\r]+#", $plainResults);
        foreach ($lines as $line)
            {
            $line = trim ($line);
            if (empty ($line))
                continue;
                
            if (self::FORMAT_FULL == $format || self::FORMAT_EXTENDED == $format || self::FORMAT_SIMPLE == $format)
                {
                $row = preg_split ("#[\t \-\-\:]+#u", $line);
                if (count ($row) < 8)
                    {
                    $msg = "Row $line not suitable";
                    $this->addMessage ($msg);
                    $containsErrors = true;
                    continue;
                    }

                $correctFormat = true;

                $record = array ();
                $record["place"] = $row[0];
                $c = count ($row) - 1; // games played
                $record["pts"] = $row[$c--];
                if (self::FORMAT_FULL == $format)
                    $correctFormat = $correctFormat && is_numeric ($row[$c--]); // scoring diff
                $record["conceded"] = $row[$c--];
                $record["scored"] = $row[$c--];
                $record["lost"] = $row[$c--];
                $record["draw"] = $row[$c--];
                $record["win"] = $row[$c--];
                if (self::FORMAT_SIMPLE != $format)
                    $correctFormat = $correctFormat && is_numeric ($row[$c--]); // total games

                $label = array ();
                for ($i = 1; $i <= $c; $i++)
                    $label[] = $row[$i];
                $record["label"] = implode (" ", $label);

                if (!$correctFormat || !is_numeric ($record["place"]) || !is_numeric ($record["pts"]) ||
                    !is_numeric ($record["conceded"]) || !is_numeric ($record["scored"]) || !is_numeric ($record["lost"]) ||
                    !is_numeric ($record["draw"]) || !is_numeric ($record["win"]) || empty ($record["label"]))
                    {
                    $this->writeLine ($record);
                    $msg = "Row $line not suitable";
                    $this->addMessage ($msg);
                    $containsErrors = true;
                    continue;
                    }

                $parsed[] = $record;
                }
            else if (self::FORMAT_MINI == $format)
                {
                foreach (array ("N. Name G %d: ?%d Pts",
                                "N. Name G %d\- ?%d Pts") as $pattern)
                    {
                    $pattern = str_replace (" ?", "\s*", $pattern);
                    $pattern = str_replace (" ", "\s+", $pattern);
                    $pattern = str_replace ("Name", "(.+)", $pattern);
                    $pattern = str_replace ("N.", "([0-9]+)\.?", $pattern);
                    $pattern = str_replace ("Pts", "([0-9]+)", $pattern);
                    $pattern = str_replace ("G", "([0-9]+)", $pattern);
                    $pattern = str_replace ("%d", "([0-9]+)", $pattern);
                    preg_match ("/^$pattern$/", trim ($line), $matches);
                    if (7 == count ($matches))
                        break;
                    }

                if (7 != count ($matches))
                    {
                    $msg = "Row $line not suitable";
                    $this->addMessage ($msg);
                    $containsErrors = true;
                    continue;
                    }

                $record = array ();
                $record["place"] = $matches[1];
                $record["label"] = $matches[2];
                $record["scored"] = $matches[4];
                $record["conceded"] = $matches[5];
                $record["pts"] = $matches[6];
                $parsed[] = $record;
                }
            }

        if ($containsErrors)
            return false;
        return $parsed;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function getTemplateName ()
        {
        if ($this->readyForInput)
            return "simpleform";
        return "sports/submitscores";
        }

    public function createCommonFields ()
        {
        $this->sourcesField = new TextFieldTemplate ($this->getPrefix (), DBTable::COL_SOURCE,
                                        $this->getText ("Source(s):"),
                                        $this->getText ("Source and comments"), 64);
        $this->sourcesDateField = new DateFieldTemplate ($this->getPrefix (), DBTable::COL_SOURCEDATE,
                                        $this->getText ("Updated on:"),
                                        $this->getText ("Sources updated on"));

        $column = clone $this->dbtable->findColumn ("season");
        $column->inputType = MetaDataColumns::INPUT_AUTOCOMPLETE;
        if (!empty ($_GET["season"]))
            $this->competitionField = new HiddenFieldTemplate ("", "season");
        else
            $this->competitionField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;

        $this->createCommonFields ();
        $format = new DropDownFieldTemplate ("", "format", "Format:", "How lines should be parsed",
                                             array (self::FORMAT_FULL => "Full. Example - 1 Zalgiris Vilnius 20 17 2 1 101- 12 89 53",
                                                    self::FORMAT_EXTENDED => "Extended. Example - 1 Zalgiris Vilnius 20 17 2 1 101-12 53",
                                                    self::FORMAT_SIMPLE => "Simple. Example - 1 Zalgiris Vilnius 17 2 1 101:12 53",
                                                    self::FORMAT_MINI => "Mini. Example - 1 Minija Kretinga  20  81:16  36",
                                                    )
                                            );

        return array
            (
            !empty ($_GET["season"]) ? new HiddenFieldTemplate ("", "year") : new IntFieldTemplate ("", "year", "Year:", "Competition year"),
            $this->competitionField,
            $format,
            new LongTextFieldTemplate ("", "parse", "Results:", "Enter results"),
            $this->sourcesField,
            $this->sourcesDateField
            );
        }
    }

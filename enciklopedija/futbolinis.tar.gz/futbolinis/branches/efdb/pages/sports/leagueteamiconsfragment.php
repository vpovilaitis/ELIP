<?php
require_once (PATH.'pages/sports/baseleaguefragment.php');
require_once (PATH.'pages/sports/lightweightleaguetable.php');

class LeagueTeamIconsFragment extends BaseLeagueFragment
    {
    protected function createLeagueDependentComponent ($context, $prefix, $dbtable, $leagueId)
        {
        $criteria = array (new EqCriterion ($dbtable->getIdColumn (), $leagueId));
        $columns = array ($dbtable->getIdColumn (), Sports::COL_COMPETITION_SYSTEM);

        return new LeagueTeamIconList ($context, $dbtable, $leagueId);
        }
    }

class LeagueTeamIconList extends Component
    {
    protected $leagueId;

    public function __construct ($context, $table, $leagueId)
        {
        $this->leagueId = $leagueId;
        parent::__construct ("icn", $context);

        $context->addStyleSheet ("sports");
        }

    public function isVisible ()
        {
        return true;
        }

    public function getTemplateName ()
        {
        return "sports/teamicons";
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getTeams ()
        {
        $teamSeasons = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAMLEAGUESEASON);
        $teams = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $criteria[] = new EqCriterion (Sports::COL_TEAMLEAGUESEASON_COMPETITION, $this->leagueId);
        $fixedStats = $teamSeasons->selectBy (array ($teams->getIdColumn ()), $criteria);
        if (empty ($fixedStats))
            return NULL;

        $teamIds = array ();
        foreach ($fixedStats as $row)
            $teamIds[] = $row[$teams->getIdColumn ()];

        $teamsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_TEAM);
        $logos = SportsHelper::getTeamLogos ($this->context, $teamIds, date ("Y-m-d"));
        $labels = SportsHelper::getTeamLabels ($this->context, $teamIds);

        $images = array ();
        foreach ($teamIds as $id)
            {
            if (empty ($logos[$id]) || empty ($labels[$id]))
                continue;

            $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $teamsTable,
                                                                         $teamsTable->getId (),
                                                                         $id);
            $images[] = array ("name" => $labels[$id],
                               "icon" => $logos[$id],
                               'url' => $url);
            }

        return $images;
        }

    }

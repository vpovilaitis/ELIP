<?php

/* Composite field which allows to enter game score (after half time, penalties, etc) */
class RelatedRecordField extends FieldTemplate
    {
    protected $notes;
    protected $columns = array ();
    protected $dbtable = NULL;
    protected $tableName = NULL;
    protected $fields = NULL;
    public $error = NULL;

    const KEY_TICKET = "ticket";
    const TICKET_SEPARATOR = "_";

    const FAILED_TO_UPDATE = 1;
    const FAILED_TO_CREATE = 2;
    const FAILED_TO_DELETE = 3;

    public function __construct ($context, $prefix, $key, $tableName, $label, $tooltip, $notes = NULL)
        {
        parent::__construct ($prefix, $key, NULL, $label, $tooltip);
        $this->notes = $notes;
        $this->dbtable = ContentTable::createInstanceByName ($context, $tableName);
        }
    
    public function getTemplateName ()
        {
        return "sports/relatedrecord";
        }

    public function getFields ()
        {
        if (NULL === $this->fields)
            {
            $this->fields = $this->createFields ();
            
            $prefix = $this->getPrefix().$this->key;
            $this->fields[] = new HiddenFieldTemplate ($prefix, self::KEY_TICKET);
            }
            
        return $this->fields;
        }

    protected function retrieveRecords ($context, $criteria)
        {
        return self::selectRecords ($context, $this->dbtable, $this->columns, $this->tableName, $criteria);
        }

    protected static function selectRecords ($context, $dbtable, $columns, $tableName, $criteria)
        {
        if (empty ($dbtable))
            {
            $context->addError ("[_0] table not found.", $tableName);
            return;
            }

        $columns = array_merge ($columns, array (DBTable::COL_UPDATEDON));
        $rows = $dbtable->selectBy ($columns, $criteria);
        return $rows;
        }

    public function getLabel ($format = true)
        {
        return trim (formatForHtml ($this->label));
        }

    public function getNotes ()
        {
        return $this->notes;
        }

    protected function isEmptyRecord ($context, $request)
        {
        foreach ($this->columns as $col)
            {
            if (isset ($request[$col]))
                return false;
            }

        return true;
        }

    public function getValueForDB ($context, $request, $index = NULL)
        {
        $key = $this->key;
        return $request[$this->key];
        }

    public function getValueForDisplay ($context, $row)
        {
        $resultRow = $row[$this->key];
        return $resultRow;
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        }

    public function getValueForEditing ($context, $row)
        {
        return $this->getValueForDisplay ($context, $row);
        }


    public function processInput ($context, &$request)
        {
        $innerRequest = Component::getInnerRequest ($request, $this->key."_");
        $request[$this->key] = $innerRequest;

        foreach ($this->getFields () as $field)
            {
            if (false === $field->processInput ($context, $innerRequest))
                {
                return false;
                }
            }

        foreach ($innerRequest as $key => $param)
            {
            $request[$this->key."_".$key] = $param;
            }

        $request[$this->key] = $innerRequest;
        return true;
        }

    public function preprocessLoadedValue (&$request, $existingRecord, $index = NULL)
        {
        parent::preprocessLoadedValue ($request, $existingRecord, $index);

        foreach ($this->getFields () as $field)
            {
            if (false === $field->preprocessLoadedValue ($request[$this->key], $existingRecord))
                return false;
            }
        }

    protected function findColumn ($column)
        {
        return $this->dbtable->findColumn ($column);
        }

    public function prepareRow ($row, $additional = NULL)
        {
        if (empty ($this->dbtable))
            return false;

        $ticketArray = array ();
        foreach ($this->columns as $col)
            {
            $column = $this->findColumn ($col);
            if (empty ($column))
                $columnName = $col;
            else if ($column instanceof ValueColumn)
                $columnName = $column->columnDef->name;
            else
                $columnName = $column->name;

            if (is_array ($row[$columnName]))
                $inst[$col] = $row[$columnName][0];
            else
                $inst[$col] = $row[$columnName];
            }
        
        $inst[RelatedRecordField::KEY_TICKET] = implode (self::TICKET_SEPARATOR, $inst);
        return $inst;
        }

    public function updateCriteriaAndGetNewTicket ($values, &$criteria, $deleting = false)
        {
        $ticket = $values[self::KEY_TICKET];
        $parts = explode (self::TICKET_SEPARATOR, $ticket, count ($this->columns));
        if (count ($parts) != count ($this->columns))
            return false;

        $anyValidCriteria = false;
        $newTicket = array ();
        for ($i = 0; $i < count ($this->columns); $i++)
            {
            if ($this->addCriterionForUpdate ($criteria, $this->columns[$i], $parts[$i], $deleting))
                $anyValidCriteria = true;

            $newTicket[] = $values[$this->columns[$i]];
            }
        
        if (!$anyValidCriteria)
            return NULL;

        return implode (self::TICKET_SEPARATOR, $newTicket);
        }

    protected function addCriterionForUpdate (&$criteria, $column, $value, $deleting)
        {
        if (NULL === $value)
            $criteria[] = new IsNullCriterion ($column);
        else
            {
            $criteria[] = new EqCriterion ($column, $value);
            return true;
            }

        return false;
        }

    protected function updateTicket (&$request, $key, $newTicket)
        {
        $request[$this->key][self::KEY_TICKET] = $newTicket;
        }

    public function areValuesModified ($initialValue, $newValue)
        {
        $newScore = array ();
        $initialScore = array ();
        if (!empty ($newValue[self::KEY_TICKET]))
            $initialScore = explode (self::TICKET_SEPARATOR, $newValue[self::KEY_TICKET]);

        $empty = $this->isEmptyRecord ($this->dbtable->getContext(), $newValue);
        if ($empty != empty ($initialScore))
            return true;

        if (empty ($initialScore))
            return !$empty;
        if ($empty && !empty ($newValue[self::KEY_TICKET]))
            return true;

        $i = 0;
        foreach ($this->columns as $col)
            {
            if ($newValue[$col] != $initialScore[$i++])
                {
                return true;
                }
            }

        return false;
        }

    protected function validateRecord ($context, $values)
        {
        return true;
        }

    public function storePreparedRecord ($context, &$request, $id, &$prepared, $sourceValues, $parentRow)
        {
        $handler = new RelatedValueSaveHandler ($context, $id, $parentRow);
        $handler->start ();
        $ret = $this->savePreparedRecord ($handler, $request, $prepared, $sourceValues);
        $handler->stop (true);
        return $ret;
        }

    protected function getDBIdColumn ()
        {
        return $this->dbtable->getIdColumn ();
        }

    protected function getValues ($values, $sourceValues)
        {
        $namesToValues = $sourceValues;
        foreach ($this->columns as $col)
            {
            if ($this->getDBIdColumn () == $col)
                continue;
            $namesToValues[$col] = $values[$col];
            }

        return $namesToValues;
        }

    protected function removeEntry ($values, $criteria)
        {
        return $this->dbtable->removeEntry ($criteria);
        }

    protected function savePreparedRecord ($handler, &$request, &$prepared, $sourceValues)
        {
        if (empty ($prepared[$this->key]))
            return true;

        $context = $handler->getContext ();
        $id = $handler->id;

        if (empty ($this->dbtable))
            {
            $context->addError ("Related table [_0] not found.", $this->tableName);
            return false;
            }

        $idColumns = $this->dbtable->getPrimaryIndexColumns ();

        $values = $prepared[$this->key];
        if (false === $this->validateRecord ($context, $values))
            return;

        if ($this->isEmptyRecord ($context, $values))
            {
            $criteria = array (new EqCriterion ($idColumns[0]->name, $id[0]));
            $newTicket = $this->updateCriteriaAndGetNewTicket ($values, $criteria, true);
            if (false === $newTicket)
                {
                $context->addError ("Failed to retrieve update ticket.");
                return false;
                }
            if (false === $this->removeEntry ($values, $criteria))
                {
                return $this->handleFailure ($handler, $request, self::FAILED_TO_DELETE, $prepared, $values[self::KEY_TICKET]);
                }

            $this->updateTicket ($request, $this->key, $newTicket);
            return true;
            }

        $namesToValues = $this->getValues ($values, $sourceValues);

        if (empty ($values[RelatedRecordField::KEY_TICKET]))
            {
            $this->addParentIdValues ($namesToValues, $id);
            if (false === $this->dbtable->insertRecord ($namesToValues))
                {
                $criteria = array (new EqCriterion ($idColumns[0]->name, $id[0]));
                return $this->handleFailure ($handler, $request, self::FAILED_TO_CREATE, $prepared, NULL);
                }
            }
        else
            {
            $criteria = $this->getParentCriteria ($idColumns, $id);
            $newTicket = $this->updateCriteriaAndGetNewTicket ($values, $criteria);
            if (false === $newTicket)
                {
                $context->addError ("Failed to retrieve update ticket.");
                return false;
                }

            $affected = $this->dbtable->updateRecord ($criteria, $namesToValues, 1);
            if (false === $affected || $affected < 1)
                {
                return $this->handleFailure ($handler, $request, self::FAILED_TO_UPDATE, $prepared, $values[self::KEY_TICKET]);
                }

            $this->updateTicket ($request, $this->key, $newTicket);
            }

        return true;
        }

    protected function addParentIdValues (&$namesToValues, $id)
        {
        $namesToValues[$idColumns[0]->name] = $id[0];
        }

    public function getParentCriteria ($idColumns, $id)
        {
        return array (new EqCriterion ($idColumns[0]->name, $id[0]));
        }

    protected function handleFailure ($handler, &$request, $reason, &$prepared, $oldTicket)
        {
        $context = $handler->getContext ();
        $idColumns = $this->dbtable->getPrimaryIndexColumns ();
        $criteria = array (new EqCriterion ($idColumns[0]->name, $handler->id[0]));

        if (empty ($prepared["cache"]))
            $prepared["cache"] = array();
        $parentRow = $handler->parentRow;
        $this->retrieveRecord ($context, $criteria, $parentRow, $prepared["cache"]);
        $newTicket = !empty ($parentRow[$this->key]) ? $parentRow[$this->key]["ticket"] : NULL;
        $this->updateTicket ($request, $this->key, $newTicket);

        switch ($reason)
            {
            case self::FAILED_TO_UPDATE:
                $action = $context->getText ("modify|error");
                break;
            case self::FAILED_TO_CREATE:
                $action = $context->getText ("create|error");
                break;
            case self::FAILED_TO_DELETE:
                $action = $context->getText ("remove|error");
                break;
            default:
                $action = "?";
                break;
            }

        $dbErrors = $handler->stop (false);
        
        $error[] = trim ($context->getText ("Failed to [_0] entry", $action), ". ");
        if (!empty ($dbErrors))
            $error[0] .= " (".implode (", ", $dbErrors).")";

        if (self::FAILED_TO_UPDATE == $reason && empty ($newTicket))
            $error[] = trim ($context->getText ("Entry was removed by other user (click save to write it anyway)."), ". ");
        else if (!empty ($newTicket) && $oldTicket != $newTicket)
            $error[] = trim ($context->getText ("Entry was modified by other user, new value is '[_0]'. Click save to overwrite the value.", $this->getRecordLabel ($context, $newTicket)), ". ");

        if (!array_key_exists ("notified_about_error", $prepared))
            {
            $context->addError ("One or more errors occured. Please review errors below (next to fields). If conflict occurred, saving once more might succeed by overwriting changes made by other users.");
            $prepared["notified_about_error"] = true;
            }

        $this->error = implode (". ", $error);
        return false;
        }

    protected function findPlayer ($id, $isHome, $playerRows)
        {
        if (empty ($playerRows))
            $homePlayers = $homeSubstitutes = $awayPlayers = $awaySubstitutes = array ();
        else
            list ($homePlayers, $homeSubstitutes, $awayPlayers, $awaySubstitutes) = $playerRows;

        if ($isHome)
            $playerRows = !empty ($homeSubstitutes) ? array_merge ($homePlayers, $homeSubstitutes) : $homePlayers;
        else
            $playerRows = !empty ($awaySubstitutes) ? array_merge ($awayPlayers, $awaySubstitutes) : $homePlayers;

        if (empty ($playerRows))
            $playerRows = array ();
        foreach ($playerRows as $row)
            {
            if ($id == $row["f_".Sports::COL_PLAYER_PERSON."_".Sports::TABLE_PERSON."_id"])
                {
                $number = $row[ContentTable::prepareUserColumnName (Sports::COL_PLAYER_NO)];
                if (!empty ($number))
                    return array ($number, $id);
                break;
                }
            }

        return array (false, $id);
        }

    protected function processPlayerNumber ($context, &$record, $prepared, $numberKey, $isHome)
        {
        $number = $record[$numberKey];
        if (!empty ($number))
            {
            if ($number[0] == 'X')
                {
                $record[$numberKey] = substr ($number, 1);
                return true;
                }

            $key = $isHome ? "home" : "away";
            $key .= "_p_$number";

            if (!array_key_exists ($key, $prepared))
                {
                $context->addError ("Specified player [_0] does not exist in the list", $number);
                return false;
                }

            $scorerKey = $prepared[$key];
            $record[$numberKey] = $prepared[$scorerKey][Sports::COL_PLAYER_PERSON];
            }

        return true;
        }

    protected function getRecordLabel ($context, $ticket)
        {
        return $ticket;
        }

    static public function createIntField ($prefix, $key, $tooltip, $size = 2)
        {
        $numberField = new IntFieldTemplate ($prefix, $key, "", $tooltip);
        $numberField->cssClass = "playerno";
        $numberField->size = $size;
        return $numberField;
        }
    }

class RelatedValueSaveHandler extends BaseWithContext
    {
    public $id;
    public $parentRow;
    public $oldErrorTarget = false;
    protected $errors = array ();

    public function __construct ($context, $id, $parentRow)
        {
        parent::__construct ($context);
        $this->id = $id;
        $this->parentRow = $parentRow;
        }

    public function start ()
        {
        $this->oldErrorTarget = $this->context->setErrorTarget ($this);
        }

    public function stop ($flushUnhandledErrors)
        {
        if (false === $this->oldErrorTarget)
            return;

        $this->context->setErrorTarget ($this->oldErrorTarget);
        $this->oldErrorTarget = false;

        if ($flushUnhandledErrors && !empty ($this->errors))
            {
            foreach ($this->errors as $error)
                $this->context->addErrorPrepared ($error);
            }

        $errors = $this->errors;
        $this->errors = array ();
        return $errors;
        }

    public function addError ($msg, $param1 = NULL, $param2 = NULL)
        {
        $this->addErrorPrepared ($this->context->getText ($msg, $param1, $param2));
        }

    public function addErrorPrepared ($error)
        {
        $this->errors[] = $error;
        $this->log ($error);
        }
    }

class NumberAutocompleteField extends RelationAutocompleteField
    {
    const NUMBER_POSTFIX = "_no";
    
    public function __construct ($prefix, $dbtable, $key, $label, $tooltip, $required)
        {
        parent::__construct ($prefix, $dbtable, $key, $label, $tooltip, $required);
        $this->cssClass = "number";
        }

    public static function setId (&$request, $key, $id, $number, $label)
        {
        $request[$key] = $id;
        if ($number > 0)
            $request[$key.self::NUMBER_POSTFIX] = $number;

        self::cacheLabel ($id, $label);
        }

    public static function getIdOrNumber ($request, $key, &$isNumber)
        {
        $id = NULL;

        if ($request[$key.self::LABEL_POSTFIX] != $request[$key.self::OLDVALUE_POSTFIX])
            return false;

        if (!empty ($request[$key]) && $request[$key][0] != "#")
            {
            $id = $request[$key];
            $isNumber = false;
            }
        else if (is_numeric ($request[$key.self::LABEL_POSTFIX]))
            {
            $id = $request[$key.self::LABEL_POSTFIX];
            $isNumber = true;
            }

        return $id;
        }

    public function preprocessLoadedValue (&$request, $existingRecord, $index = NULL)
        {
        parent::preprocessLoadedValue ($request, $existingRecord, $index);

        if (!empty ($request[$this->key.self::NUMBER_POSTFIX]) && !empty ($request[$this->key.self::LABEL_POSTFIX]))
            {
            $number = $request[$this->key.self::NUMBER_POSTFIX];
            $request[$this->key.self::LABEL_POSTFIX] = $number." - ".$request[$this->key.self::LABEL_POSTFIX];
            $request[$this->initialLabelField->key] = $request[$this->key.self::LABEL_POSTFIX];
            }
        }

    public function canContainNumber ()
        {
        return true;
        }
    }

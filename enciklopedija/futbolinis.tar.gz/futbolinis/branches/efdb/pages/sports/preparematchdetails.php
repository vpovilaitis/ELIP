<?php
require_once (PATH.'pages/sports/submitgameresult.php');

class PrepareMatchDetails extends SubmitGameResult
    {
    public function __construct ($context, $request)
        {
        parent::__construct ($context, $request);
        $this->savePrepared = true;
        }

    protected function onSuccess ($match, $id, $fullLabel)
        {
        if (parent::onSuccess ($match, $id, $fullLabel))
            {
            $detailsTable = new SourcesDetailTable ($this->context);
            $criteria[] = new EqCriterion (SourcesDetailTable::COL_SCOPE, Constants::TABLES_USER."_".Sports::TABLE_MATCH);
            $criteria[] = new EqCriterion (SourcesDetailTable::COL_CONTEXTID, $id);
            $criteria[] = new EqCriterion (SourcesDetailTable::COL_STATE, SourcesDetailTable::STATE_PENDING);
            $rows = $detailsTable->selectBy (array (SourcesDetailTable::COL_ID), $criteria);
            if (empty ($rows))
                {
                $this->writeLine ($this->getText ("Source detail record not found for match [_0].", $fullLabel));
                return false;
                }
            if (count ($rows) > 1)
                {
                $this->writeLine ($this->getText ("More than one source detail record found for match [_0].", $fullLabel));
                return false;
                }

            $row = $rows[0];
            $sdId = $row[SourcesDetailTable::COL_ID];
            $this->redirect ($this->context->processUrl ("index.php?c=sports/SubmitPendingStats&skip=1&id=$sdId", true));
            }
        }
    }

<?php
require_once (PATH.'pages/submit.php');
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/relationfields.php');
require_once (PATH.'h/othernamestable.php');

class SubmitPersons extends Submit
    {
    const SKIP = 0;
    const CREATE = -2;

    public function __construct ($context, $request)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, "persons");

        if (empty ($this->dbtable))
            {
            $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            $this->allTablesLoaded = false;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        $context->addScriptFile ("autosuggest");
        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ($this->getText ("Batch creation of person records"));
        return true;
        }

    protected function onInputFieldCollected ($context, &$request, $type, $key, $val)
        {
        }

    public function collectInputData ($context, &$request)
        {
        $this->createSourceFields ();
        $this->source = $this->sourcesField->getValueForDB ($context, $request);
        $this->sourceDate = $this->sourcesDateField->getValueForDB ($context, $request);

        $country = $request["citizen"];
        $persons = $this->collectPersons ($country, $request["parse"]);
        return $persons;
        }
        
    public function validateInput ($context, &$input)
        {
        return $this->preparePersons ($input);
        }

    public function saveInput ($context, &$request, &$input)
        {
        if (empty ($input))
            return;
        $result = NULL;
        foreach ($input as $person)
            {
            if (false === $this->createPerson ($person))
                {
                if (NULL === $result)
                    return false;
                $result = false;
                }
            else if (NULL === $result)
                $result = true;
            }

        return $result;
        }

    public function createPerson ($person)
        {
        if (!empty ($person["skip"]))
            {
            $this->writeLine ("<hr>Skipping {$person["name"]}\n<br>");
            return true;
            }

        $values = array ("c_full" => $person["name"]);
        if (!empty ($person["height"]))
            $values["c_height"] = $person["height"];
        if (!empty ($person["weight"]))
            $values["c_weight"] = $person["weight"];
        if (!empty ($person["date"]))
            $values["c_birthday"] = $person["date"];
        if (!empty ($person["country"]))
            $values["citizen"] = $person["country"];
        if (!empty ($person["surname"]))
            $values["c_last"] = $person["surname"];
        if (!empty ($person["firstname"]))
            $values["c_first"] = $person["firstname"];
        if (isset ($person["woman"]))
            $values["c_woman"] = $person["woman"];

        $values[DBTable::COL_SOURCE] = $this->source;
        $values[DBTable::COL_SOURCEDATE] = $this->sourceDate;

        if (!empty ($person["id"]))
            {
            $action = "Modified";
            $id = $person["id"];
            $criteria = array (new EqCriterion ($this->dbtable->getIdColumn (), $id));

            if (false === $this->dbtable->updateRecord ($criteria, $values))
                return false;
            }
        else
            {
            $action = "Created";
            $id = $this->dbtable->insertRecord ($values);
            if (false === $id)
                return false;
            }

        $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                            $this->dbtable->getId (), $id);
        $this->writeLine ("<hr>$action <a href='$url'>{$person["name"]}</a>\n<br>");
        return true;
       }
        
    protected function preparseRawInput ($input)
        {
        $lcNameChars = 'a-ząčęėįšųūžàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþðşķ\\\'-';
        $ucNameChars = 'A-ZĄČĘĖĮŠŲŪŽÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞÐŞĶ';

        preg_match ("/(([$ucNameChars][$ucNameChars$lcNameChars]*(\.)?)[,]?(\s+([$ucNameChars][$ucNameChars$lcNameChars]+)){1,4})/", $input, $matches);
        if (count ($matches) < 2)
            return array (NULL, NULL, NULL);

        $pos = strpos ($input, $matches[1]);

        return array
                (
                substr ($input, 0, $pos),
                $matches[1],
                substr ($input, $pos + strlen ($matches[1])),
                );
        }

    protected function createPersonInstance ($name, $input)
        {
        $name = str_replace (array ("\t", ","), array (" ", ""), $name);
        $person = array ("name" => $this->beautifyName ($name));
        preg_match ('/((19[0-9]{2})(\.| |\-)([0-1][0-9])(\.| |\-)([0-9]{2}))/', $input, $matches);
        if (count ($matches) > 1)
            {
            $person["date"] = $matches[2]."-".$matches[4]."-".$matches[6];
            $input = str_replace ($matches[1], "?", $input);
            }
        else
            {
            preg_match ('/(19[0-9]{2})/', $input, $matches);
            if (count ($matches) > 1)
                {
                $person["date"] = $matches[1]."-00-00";
                $input = str_replace ($matches[1], "?", $input);
                }
            }

        preg_match ('/[^0-9](1(,|\.)?[6-9][0-9])[^0-9]/', $input, $matches);
        if (count ($matches) > 1)
            {
            $height = str_replace (",", "", $matches[1]);
            $height = str_replace (".", "", $height);
            $person["height"] = $height;
            $input = str_replace ($matches[1], "?", $input);
            }

        preg_match ('/[^0-9]((1[0-3]|[5-9])[0-9])[^0-9\'`]/', $input, $matches);
        if (count ($matches) > 1)
            {
            $person["weight"] = $matches[1];
            $input = str_replace ($matches[1], "?", $input);
            }
            
        return $person;
        }

    protected function collectPersons ($country, $input)
        {
        $lastName = NULL;
        $rawData = array ();
        $input = str_replace ("\n", ";\n", $input);

        while (true)
            {
            list ($start, $name, $end) = $this->preparseRawInput ($input);

            if (empty ($name))
                {
                if (!empty ($lastName))
                    $rawData[$lastName] = $input;
                break;
                }

            if (!empty ($lastName))
                $rawData[$lastName] = $start;
            $lastName = $name;
            $input = $end;
            }

        $persons = array ();

        foreach ($rawData as $name => $data)
            {
            $person = $this->createPersonInstance ($name, $data);
            if (false === $person)
                return false;
            if (!empty ($country))
                $person["country"] = $country;
            $persons[] = $person;
            }

        return $persons;
        }

    protected function preparePersons (&$persons)
        {
        if (empty ($persons))
            return;
        $inverse = !empty ($this->request["inverse"]);
        $woman = !empty ($this->request["woman"]);
        $skipIdentical = !empty ($this->request["skipSame"]);
        foreach ($persons as &$person)
            $this->preparePerson ($person, $inverse, $woman, $skipIdentical);
        }

    protected function similarName ($newName, $storedName)
        {
        $newName = trim ($newName);
        $storedName = trim ($storedName);
        if (0 == strcasecmp ($newName, $storedName) || empty ($storedName))
            return true;
        if (strlen ($storedName) == 2 && $storedName[1] == "." && $storedName[0] == $newName[0])
            return true;
        if (strlen ($newName) == 2 && $newName[1] == "." && $storedName[0] == $newName[0])
            return true;

        $lenStored = strlen ($storedName);
        $lenNew = strlen ($newName);
        $minLength = $lenNew > $lenStored ? $lenStored : $lenNew;

        if (0 == strncasecmp ($storedName, $newName, $minLength))
            return true;

        // check for similarities (only 1-2 characters different)
        return false;
        }

    protected function preparePerson (&$person, $inverse, $woman, $skipIdentical)
        {
        $name = $person["name"];
        if ($inverse)
            {
            $parts = explode (" ", $name);
            $name = implode (" ", array_reverse ($parts));
            $person["name"] = $name;
            }

        $attr = array ();
        if (!empty ($person["height"]))
            $attr[] = $person["height"]." cm";
        if (!empty ($person["weight"]))
            $attr[] = $person["weight"]." kg";
        if (!empty ($person["date"]))
            $attr[] = "born on ".$person["date"];

        $parts = explode (" ", $name);
        $surname = array_pop ($parts);
        $firstname = implode (" ", $parts);
        $currentLabel = $firstname." ".utf8_strtoupper ($surname);
        if (!empty ($attr))
            $currentLabel .= " (".implode (", ", $attr).")";

        $person["surname"] = $surname;
        $person["firstname"] = $firstname;
        $person["woman"] = $woman;
        $simplifiedSurname = OtherNamesTable::removeDiacritics ($surname);
        
        // ending trimming logic should be moved to removeDiacritics
        $surnameEnding = substr ($simplifiedSurname, -2);
        if ($surnameEnding == "as" || $surnameEnding == "is")
            $simplifiedSurname = substr ($simplifiedSurname, 0, -2);
        else if ($surnameEnding[1] == "y" || $surnameEnding[1] == "j" || $surnameEnding[1] == "i")
            $simplifiedSurname = substr ($simplifiedSurname, 0, -1);

        $namesTable = ContentTable::createInstanceByName ($this->context, "person_names");
        $similarIds = array ();
        if (!empty ($namesTable))
            {
            $namesColumns = array (OtherNamesTable::COL_PERSON);
            $namesCriteria[] = new LikeCriterion ("c_".OtherNamesTable::COL_SIMPLIFIEDLAST, $simplifiedSurname);
            $rows = $namesTable->selectBy ($namesColumns, $namesCriteria);
            if (!empty ($rows))
                {
                foreach ($rows as $row)
                    $similarIds[] = $row[OtherNamesTable::COL_PERSON][0];
                }
            }

        if (!empty ($similarIds))
            {
            $columns = array ($this->dbtable->getIdColumn (), "first", "last", "birthday", "height", "weight");
            $criteria[] = new InCriterion ($this->dbtable->getIdColumn (), $similarIds);
            $rows = $this->dbtable->selectBy ($columns, $criteria);
            }
        else
            $rows = NULL;

        if (!empty ($rows))
            {
            $similarRows = array ();
            $identicalIds = array ();
            foreach ($rows as $row)
                {
                $identical = false;
                if ($this->similarName ($firstname, $row["c_first"]))
                    {
                    if ($skipIdentical && $firstname == $row["c_first"])
                        {
                        $recognizedDate = trim ($person["date"], " 0-");
                        $storedDate = trim ($row["c_birthday"], " 0-");
                        if (strlen ($recognizedDate) <= strlen ($storedDate) && 0 === strncmp ($recognizedDate, $storedDate, strlen ($recognizedDate)))
                            return;
                        }
                    $identicalIds[] = $row[$columns[0]];
                    }

                $similarRows[] = $row;
                }

            $this->writeLine ($currentLabel);

            if (!empty ($similarRows))
                {
                $this->writeLine ("\n<br>\nSimilar entries found:<br/>");
                $labels = array ();
                $options = array (self::SKIP => "Do not create or modify", self::CREATE => "Create new");
                foreach ($similarRows as $row)
                    {
                    $id = $row[$columns[0]];
                    $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                        $this->dbtable->getId (), $id);
                    $label = "";
                    $attrs = array ();
                    $identical = false !== array_search ($id, $identicalIds);
                    if (!empty ($row["c_height"]))
                        {
                        $attrs[] = "{$row["c_height"]} cm";
                        if (!empty ($person["height"]) && $row["c_height"] != $person["height"])
                            $identical = false;
                        }
                    else if (!empty ($person["height"]))
                        $identical = false;

                    if (!empty ($row["c_weight"]))
                        {
                        $attrs[] = "{$row["c_weight"]} kg";
                        if (!empty ($person["weight"]) && $row["c_weight"] != $person["weight"])
                            $identical = false;
                        }
                    else if (!empty ($person["weight"]))
                        $identical = false;

                    if (!empty ($row["c_birthday"]))
                        {
                        $attrs[] = $row["c_birthday"];
                        if (!empty ($person["date"]) && $row["c_birthday"] != $person["date"])
                            $identical = false;
                        }
                    else if (!empty ($person["date"]))
                        $identical = false;

                    $label = ($identical ? "Identical - " : "").sprintf ("<a href='%s'>%s %s</a>", $url, $row["c_first"], $row["c_last"]);
                    $option = ($identical ? "Identical - " : "").$row["c_first"]." ".$row["c_last"];
                    if (!empty ($attrs))
                        {
                        $label .= " (".implode (", ", $attrs). ")";
                        $option .= " (".implode (", ", $attrs). ")";
                        }
                    $labels[] = $label;
                    $options[$id] = $option;
                    }
                $this->writeLine (implode (", ", $labels)."<br/>");
                $field = new DropDownFieldTemplate ("", "res_pl_".$this->encodeKey ($name), $name, $currentLabel, $options);
                $this->fields[] = $field;

                if (!isset ($this->request [$field->key]))
                    {
                    $this->logError ("Please resolve a conflict for ".$name);
                    $this->hasUnrecognizedItems = true;
                    }
                else
                    {
                    $resolution = $this->request [$field->key];
                    if (self::SKIP == $resolution)
                        {
                        $person["skip"] = true;
                        }
                    else if (self::CREATE != $resolution)
                        {
                        $person["id"] = $resolution;
                        }
                        
                    }
                }
            }
        else
            $this->writeLine ($currentLabel);
        
        $this->writeLine ("<hr/>");
        }

    public function createSourceFields ()
        {
        parent::createSourceFields ();
        if (empty ($this->countryField))
            {
            $countryColumn = $this->dbtable->findColumn ("citizen");
            $this->countryField = RelationDropDownFieldTemplate::createInstance ($this->context, "", $countryColumn);
            }
        }

    protected function processInputFields ($context, &$request)
        {
        $this->createSourceFields ();
        parent::processInputFields ($context, $request);
        $this->countryField->processInput ($context, $request);
        }

    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();


        $arr = array
            (
            new LabelTemplate ($this->getText ('Enter the list of person names to add to the database. Usually date of birth, weight and height will also be recognized (if list contains this date, for example, "Name Surname 1988-08-30, 198 cm, 80 kg")'), "", true),
            $this->countryField,
            new LongTextFieldTemplate ("", "parse", $this->getText ("Names:"), $this->getText ("Enter names to create records by")),
            new CheckBoxFieldTemplate ("", "inverse", $this->getText ("Surname first:"), $this->getText ("Names are enterred in inversed order (surname name)")),
            new CheckBoxFieldTemplate ("", "woman", $this->getText ("Woman:"), $this->getText ("Entered names belong to women footballers")),
            new CheckBoxFieldTemplate ("", "skipSame", $this->getText ("Skip identical:"), $this->getText ("Do not show entry if name and birth date matches")),
            );

        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));
        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }
    }

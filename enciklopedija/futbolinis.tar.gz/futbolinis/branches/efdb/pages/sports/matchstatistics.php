<?php
require_once (PATH."pages/contentpreview.php");

class MatchStatistics extends ContentPreview
    {
    protected $sources = array();

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $context->addStyleSheet ("sports");
        }

    public function getTemplateName ()
        {
        return "sports/matchstats";
        }

    public function getPageSize ()
        {
        return -1;
        }

    public function getHeaderTitles ()
        {
        return array
            (
            $this->getText (" |home team stats"),
            $this->getText (" |match stats"),
            $this->getText (" |away team stats"),
            );
        }

    public function getColumnKeys ()
        {
        return array
            (
            "home", "stat", "away",
            );
        }

    public function select ($context, $criteria = NULL)
        {
        $rows = parent::select ($context, $criteria);
        if (empty ($rows))
            return $rows;

        $statColumn = $this->dbtable->findColumn ("stat");
        $statsToValues = array ();
        foreach ($rows as $row)
            {
            $title = NamedIntColumn::getItem ($statColumn, $row[$statColumn->columnDef->name]);
            if (empty ($title))
                continue;

            if (!array_key_exists ($title, $statsToValues))
                $statsToValues[$title] = array (NULL, NULL);
            if ($row["c_ishome"])
                $statsToValues[$title][0] = $row["c_val"];
            else
                $statsToValues[$title][1] = $row["c_val"];

            if (!empty ($row[DBTable::COL_SOURCE]) && false === array_search ($row[DBTable::COL_SOURCE], $this->sources))
                $this->sources[] = $row[DBTable::COL_SOURCE];
            }

        $result = array ();
        foreach ($statsToValues as $title => $vals)
            {
            list ($homeVal, $awayVal) = $vals;
            $result[] = array ("stat" => $title, "home" => $homeVal, "away" => $awayVal);
            }

        return $result;
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        $resultColumns[] = DBTable::COL_SOURCE;
        }

    public function getSourcesText ()
        {
        if (empty ($this->sources))
            return NULL;

        $sourcesWithMarkup = array ();
        foreach ($this->sources as $source)
            {
            if (preg_match ("@^http://www\.(.+)/@U", $source, $matches) || preg_match ("@^http://(.+)/@U", $source, $matches))
                $sourcesWithMarkup[] = "<a href=\"$source\">{$matches[1]}</a>";
            else
                $sourcesWithMarkup[] = $source;
            }

        return $this->getText ("Statistics from [_0]", implode (", ", $sourcesWithMarkup));
        }

    }

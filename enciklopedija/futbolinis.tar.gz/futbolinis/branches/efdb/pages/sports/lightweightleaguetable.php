<?php
require_once (PATH."pages/sports/leaguetablecomponent.php");

class LightweightLeagueTable extends LeagueTableComponent
    {
    public function getTemplateName ()
        {
        return "sports/lightweightleaguetable";
        }

    public function getHeaderLabels ()
        {
        return LeagueTableRow::getHeaderLabels ($this->context, $this->teams, false, false, !$this->exportRequested());
        }

    public function getRows ($lightweight = false)
        {
        return parent::getRows ($this->exportRequested() ? LeagueTableComponent::MODE_EXPORT : LeagueTableComponent::MODE_COMPACT);
        }

    public function getDetailedLinkLabel ()
        {
        return $this->getText ("Detailed table");
        }

    public function getTitle ()
        {
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        $criteria[] = new EqCriterion ($dbtable->getIdColumn (), $this->leagueId);
        $rows = $dbtable->selectWithDisplayName (array (), $criteria);
        if (!empty ($rows))
            {
            foreach ($rows as $row)
                return $row[ContentTable::COL_DISPLAY_NAME];
            }
        return parent::getTitle ();
        }

    }

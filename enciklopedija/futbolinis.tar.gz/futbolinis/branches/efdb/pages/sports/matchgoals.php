<?php
require_once (PATH."inc/sports/constants.php");
require_once (PATH."pages/sports/matchplayers.php");

class MatchGoals extends MatchPlayersBase
    {
    protected function getIsHomeColumnName ()
        {
        return "ishome";
        }

    protected function isFieldVisible ($col, &$hiddenFields)
        {
        if (parent::isFieldVisible ($col, $hiddenFields))
            return true;
        if (Sports::COL_GOAL_ASSIST == $col->name)
            return true;
        return false;
        }

    protected function getAssistModifier ($assistedPlayer, $assistedPlayerUrl, $own, $penalty)
        {
        $player = "<a href='$assistedPlayerUrl'>$assistedPlayer</a>";
        if ($own)
            return $this->getText ("(own goal after the shot by [_0])", $player);
        if ($penalty)
            return $this->getText ("(penalty after a foul to [_0])", $player);
        return $this->getText ("(assisted by [_0])", $player);
        }

    protected function createEventRow ($row, $time, $player, $playerUrl, $playerField = null, $captain = false)
        {
        $goal = parent::createEventRow ($row, $time, $player, $playerUrl, $playerField, $captain);
        $own = $row["c_own"];
        $penalty = $row["c_penalty"];
        $goal["time"] = $row["c_time"];

        if (!empty ($goal["time"]))
            $goal["time"] = $this->formatText ($goal["link"], $goal["time"], "nounderline");

        if (!empty ($row[Sports::COL_GOAL_ASSIST]))
            {
            $assistedPlayer = $row[Sports::COL_GOAL_ASSIST.".c_last"];
            if (!empty ($row[Sports::COL_GOAL_ASSIST.".c_first"]))
                $assistedPlayer = utf8_substr ($row[Sports::COL_GOAL_ASSIST.".c_first"], 0, 1).". ".$assistedPlayer;

            $personsTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_PERSON);
            $assistedUrl = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $personsTable,
                                                                         $personsTable->getId (),
                                                                         $row[Sports::COL_GOAL_ASSIST],
                                                                         Constants::MODE_VIEW);
            $goal["modifier"] = $this->getAssistModifier ($assistedPlayer, $assistedUrl, $own, $penalty);
            }

        if ($own)
            {
            $eventLabel = $this->getText ("(og)|Own Goal");
            if (empty ($goal["modifier"]))
                $goal["modifier"] = $eventLabel;
            $img = "owngoal";
            }
        else if ($penalty)
            {
            $eventLabel = $this->getText ("(pen)|Penalty");
            if (empty ($goal["modifier"]))
                $goal["modifier"] = $eventLabel;
            $img = "penalty";
            }
        else
            {
            $eventLabel = $this->getText ("Goal");
            $img = "goal";
            }

        if ($img)
            {
            $img = $this->context->getSmallIconPath ($img);
            $goal["img"] = $this->formatText ($goal["link"], "<img src='$img' border='0' title='$eventLabel' alt='$eventLabel'>", "");
            }

        if (!empty ($row["c_min"]))
            $this->skippedCount++;

        return $goal;
        }

    protected function createEmptyEventRow (&$events, $row)
        {
        $this->skippedCount++;
        if (empty ($row["c_min"]))
            return;

        return parent::createEmptyEventRow ($events, $row);
        }

    protected function sort (&$rows)
        {
        uasort ($rows, array($this, "compare"));
        }

    static function compare ($a, $b)
        {
        if ($a["c_min"] != $b["c_min"])
            {
            if (NULL === $a["c_min"])
                return 1;
            if (NULL === $b["c_min"])
                return -1;
            return $a["c_min"] - $b["c_min"];
            }

        $extraColumn = "c_".Sports::COL_GOAL_TIME_EXTRA;
        return $a[$extraColumn] - $b[$extraColumn];
        }

    public function getAdditionalActions ()
        {
        $ret = parent::getAdditionalActions ();
        if (NULL != $this->dbtable && ($this->dbtable->canCreate () || $this->dbtable->canEdit ()) && NULL != $this->parentId)
            {
            $idparam = "&id=".implode ("_", $this->parentId);

            $url = "index.php?c=ContentPage&action=".Constants::MODE_EDIT."&tid={$this->dbtable->getParentTable()->getId()}$idparam&parts=".MatchEditorMode::GOALS;
            $ret[] = new AdditionalURLIcon ($this, "edit", $this->_("Edit goals"), $url);
            }

        return $ret;
        }
    }

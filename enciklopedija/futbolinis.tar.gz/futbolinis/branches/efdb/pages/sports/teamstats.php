<?php
require_once (PATH."pages/statisticsview.php");
require_once (PATH."inc/sports/constants.php");

class TeamStats extends StatisticsView
    {
    const COL_COMPETITION = "competition";
    const COL_GOALS = "goals";
    const COL_CONCEEDED = "conceed";
    const COL_GAMES = "games";
    const COL_WINS = "win";
    const COL_DRAWS = "draw";
    const COL_DEFEATS = "lost";

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        }


    protected function createComponents ($context, $request)
        {
        $id = $this->getIds ();

        $arr = array ();

        $rows = $this->selectYearStatistics ($id);
        if (!empty ($rows))
            {
            $arr[] = new StatisticsSection ($this, "a1", $this->getText ("Various"), $rows, $this->getYearStatsColumnNames ());
            }

        return $arr;
        }

    protected function getYearStatsColumnNames ()
        {
        return array
            (
            new StatisticsColumn (self::COL_COMPETITION, $this->getText ("Competition"), "row_label"),
            new StatisticsColumn (self::COL_GAMES, $this->getText ("Games"), "statsint"),
            new StatisticsColumn (self::COL_WINS, $this->getText ("W|Wins"), "statsint"),
            new StatisticsColumn (self::COL_DRAWS, $this->getText ("D|Draws"), "statsint"),
            new StatisticsColumn (self::COL_DEFEATS, $this->getText ("L|Defeats"), "statsint"),
            new StatisticsColumn (self::COL_GOALS, $this->getText ("Scored"), "statsint", "goal"),
            new StatisticsColumn (self::COL_CONCEEDED, $this->getText ("Conceeded"), "statsint", "owngoal"),
            );
        }

    protected function selectYearStatistics ($idArr)
        {
        $matchesTable = ContentTable::createInstanceByName ($this->context, "match");
        $competitionsTable = ContentTable::createInstanceByName ($this->context, "league");
        $competitionStageTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        if (empty ($matchesTable) || empty ($competitionsTable) || empty ($competitionStageTable))
            {
            return false;
            }

        $id = $idArr[0];

        /*
        SELECT YEAR(c_time) AS yr, `f_cstage_competitionstage_id`,
               SUM(case when f_hometeam_team_id = $id THEN c_homeresult ELSE c_awayresult END) scored,
               SUM(case when f_hometeam_team_id = $id THEN c_awayresult ELSE c_homeresult END) conceded,
               SUM(case when (f_hometeam_team_id = $id AND c_homeresult > c_awayresult) OR (f_awayteam_team_id = $id AND c_homeresult < c_awayresult) THEN 1 ELSE 0 END) wins,
               SUM(case when c_homeresult = c_awayresult THEN 1 ELSE 0 END) draws,
               COUNT(*)
          FROM `tx_match`
         WHERE (f_hometeam_team_id=$id OR f_awayteam_team_id=$id) AND (c_unofficial IS NULL OR c_unofficial = 0)
         GROUP BY yr, f_cstage_competitionstage_id
        */

        $yearColumn = "yr.y";
        $scoredColumn = "scor";
        $concededColumn = "conc";
        $gamesColumn = "cnt";
        $winColumn = "win";
        $drawColumn = "draw";
        $competitionIdColumn = "f_cstage_competitionstage_id";

        $columns = array();
        $columns[] = new AggregateFunction ("YEAR", ContentTable::prepareUserColumnName (Sports::COL_MATCH_DATE), $yearColumn);
        $columns[] = new FunctionCount ("*", $gamesColumn);
        $columns[] = $competitionIdColumn;
        $columns[] = new ConditionalSumColumn ($scoredColumn, "f_hometeam_team_id = $id", "c_homeresult", "c_awayresult");
        $columns[] = new ConditionalSumColumn ($concededColumn, "f_hometeam_team_id = $id", "c_awayresult", "c_homeresult");
        $columns[] = new ConditionalSumColumn ($winColumn, "(f_hometeam_team_id = $id AND c_homeresult > c_awayresult) OR (f_awayteam_team_id = $id AND c_homeresult < c_awayresult)", "1", "0");
        $columns[] = new ConditionalSumColumn ($drawColumn, "c_homeresult = c_awayresult", "1", "0");

        $criteria[] = new EqCriterion (Sports::COL_MATCH_UNOFFICIAL, 0);
        $criteria[] = new InCriterion (ContentTable::prepareUserColumnName (Sports::COL_MATCH_OUTCOME),
                                       array (MatchConstants::OUTCOME_FULL_TIME, MatchConstants::OUTCOME_EXTRA_TIME,
                                              MatchConstants::OUTCOME_PENALTIES, MatchConstants::OUTCOME_PENALTIES_AWAY,
                                              MatchConstants::OUTCOME_PENALTIES_HOME,
                                              MatchConstants::OUTCOME_HOME_WIN_LEAVE_RESULT, MatchConstants::OUTCOME_AWAY_WIN_LEAVE_RESULT));
        $criteria[] = new LogicalOperatorOr (new EqCriterion (Sports::COL_MATCH_HOMETEAM, $idArr),
                                             new EqCriterion (Sports::COL_MATCH_AWAYTEAM, $idArr));
        $criteria[] = new IsNotNullCriterion ("c_".Sports::COL_MATCH_HOMERESULT);
        $params = NULL;
        $params[] = new GroupBy (array ($yearColumn, $competitionIdColumn));

        $rows = $matchesTable->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rows))
            return NULL;

        $lng = Language::getInstance ($this->context);

        $decadeRows = array ();
        $decadesTotal = array (self::COL_LABEL => $this->getText ("Results by decade"),
                               self::COL_COMPETITION => $this->getText ("Total:"),
                               self::COL_GOALS => 0,
                               self::COL_CONCEEDED => 0,
                               self::COL_GAMES => 0,
                               self::COL_WINS => 0,
                               self::COL_DRAWS => 0,
                               self::COL_DEFEATS => 0,
                              );

        $competitionIds = array();
        foreach ($rows as $row)
            {
            if (!empty ($row[$competitionIdColumn]) && false === array_search ($row[$competitionIdColumn], $competitionIds))
                $competitionIds[] = $row[$competitionIdColumn];

            $decade = $lng->calculateYearDecade ($row[$yearColumn]);
            if (!isset ($decadeRows[$decade]))
                {
                $decadeRow = array (self::COL_COMPETITION => $lng->getDecadeLabel ($decade),
                                    self::COL_GOALS => $row[$scoredColumn],
                                    self::COL_CONCEEDED => $row[$concededColumn],
                                    self::COL_GAMES => $row[$gamesColumn],
                                    self::COL_WINS => $row[$winColumn],
                                    self::COL_DRAWS => $row[$drawColumn],
                                    self::COL_DEFEATS => $row[$gamesColumn]-$row[$winColumn]-$row[$drawColumn],
                                    );
                $decadeRows[$decade] = $decadeRow;
                }
            else
                {
                $decadeRows[$decade][self::COL_GOALS] += $row[$scoredColumn];
                $decadeRows[$decade][self::COL_CONCEEDED] += $row[$concededColumn];
                $decadeRows[$decade][self::COL_GAMES] += $row[$gamesColumn];
                $decadeRows[$decade][self::COL_WINS] += $row[$winColumn];
                $decadeRows[$decade][self::COL_DRAWS] += $row[$drawColumn];
                $decadeRows[$decade][self::COL_DEFEATS] += $row[$gamesColumn]-$row[$winColumn]-$row[$drawColumn];
                }

            $decadesTotal[self::COL_GOALS] += $row[$scoredColumn];
            $decadesTotal[self::COL_CONCEEDED] += $row[$concededColumn];
            $decadesTotal[self::COL_GAMES] += $row[$gamesColumn];
            $decadesTotal[self::COL_WINS] += $row[$winColumn];
            $decadesTotal[self::COL_DRAWS] += $row[$drawColumn];
            $decadesTotal[self::COL_DEFEATS] += $row[$gamesColumn]-$row[$winColumn]-$row[$drawColumn];
            }

        $decadesTotal[self::COL_INNER] = $decadeRows;
        $result = array ($decadesTotal);

        if (!empty ($competitionIds))
            {
            $criteria = array (new InCriterion ($competitionStageTable->getIdColumn (), $competitionIds),
                               new JoinColumnsCriterion ($competitionsTable->getIdColumn (), "f_competition_".$competitionsTable->getIdColumn ()));
            $joins = array ();
            $joins[] = $competitionStageTable->createQuery (array ($competitionStageTable->getIdColumn()), $criteria);
            $competitionRows = $competitionsTable->selectWithDisplayName (array ($competitionsTable->getIdColumn ()), NULL, $joins);
            }

        if (empty ($competitionRows))
            $competitionRows = array ();

        $competitionNames = array ();
        foreach ($competitionRows as $row)
            $competitionNames[$row[$competitionStageTable->getIdColumn ()]] = $row[ContentTable::COL_DISPLAY_NAME];

        $groupedCompetitions = array ();
        $competitionsTotal = array (self::COL_LABEL => $this->getText ("Results by competition"),
                                    self::COL_COMPETITION => $this->getText ("Total:"),
                               self::COL_GOALS => 0,
                               self::COL_CONCEEDED => 0,
                               self::COL_GAMES => 0,
                               self::COL_WINS => 0,
                               self::COL_DRAWS => 0,
                               self::COL_DEFEATS => 0,
                              );

        foreach ($rows as $row)
            {
            $competitionId = $row[$competitionIdColumn];
            if (empty ($competitionId) || !array_key_exists ($competitionId, $competitionNames))
                continue;

            $competition = $competitionNames[$competitionId];
            if (!isset ($groupedCompetitions[$competition]))
                {
                $newRow = array (self::COL_COMPETITION => $competitionNames[$competitionId],
                                self::COL_GOALS => $row[$scoredColumn],
                                self::COL_CONCEEDED => $row[$concededColumn],
                                self::COL_GAMES => $row[$gamesColumn],
                                self::COL_WINS => $row[$winColumn],
                                self::COL_DRAWS => $row[$drawColumn],
                                self::COL_DEFEATS => $row[$gamesColumn]-$row[$winColumn]-$row[$drawColumn],
                                );
                $groupedCompetitions[$competition] = $newRow;
                }
            else
                {
                $groupedCompetitions[$competition][self::COL_GOALS] += $row[$scoredColumn];
                $groupedCompetitions[$competition][self::COL_CONCEEDED] += $row[$concededColumn];
                $groupedCompetitions[$competition][self::COL_GAMES] += $row[$gamesColumn];
                $groupedCompetitions[$competition][self::COL_WINS] += $row[$winColumn];
                $groupedCompetitions[$competition][self::COL_DRAWS] += $row[$drawColumn];
                $groupedCompetitions[$competition][self::COL_DEFEATS] += $row[$gamesColumn]-$row[$winColumn]-$row[$drawColumn];
                }

            $competitionsTotal[self::COL_GOALS] += $row[$scoredColumn];
            $competitionsTotal[self::COL_CONCEEDED] += $row[$concededColumn];
            $competitionsTotal[self::COL_GAMES] += $row[$gamesColumn];
            $competitionsTotal[self::COL_WINS] += $row[$winColumn];
            $competitionsTotal[self::COL_DRAWS] += $row[$drawColumn];
            $competitionsTotal[self::COL_DEFEATS] += $row[$gamesColumn]-$row[$winColumn]-$row[$drawColumn];
            }

        if (!empty ($groupedCompetitions))
            {
            $competitionsTotal[self::COL_INNER] = $groupedCompetitions;
            $result[] = $competitionsTotal;
            }

        return $result;
        }

    }


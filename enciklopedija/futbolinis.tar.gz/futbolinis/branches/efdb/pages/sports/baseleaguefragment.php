<?php
require_once (PATH.'pages/componentfragment.php');
require_once (PATH.'inc/sports/constants.php');

abstract class BaseLeagueFragment extends ComponentFragment
    {
    const PARAM_COMPETITION_ID = "competition";

    protected function getAdditionalEditorFields ()
        {
        $arr = parent::getAdditionalEditorFields ();
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        $arr[] = new RelationAutocompleteField ("fld", $dbtable, BaseLeagueFragment::PARAM_COMPETITION_ID,
                                                $this->getText ("Competition"),
                                                $this->getText ("Enter the year and name of the competition"),
                                                false);

        return $arr;
        }

    protected function getShowDescription ()
        {
        return false;
        }

    protected function createComponent ($context, $prefix, $additionalParams)
        {
        $leagueId = !empty ($additionalParams[BaseLeagueFragment::PARAM_COMPETITION_ID]) ? $additionalParams[BaseLeagueFragment::PARAM_COMPETITION_ID] : NULL;
        if (empty ($leagueId))
            return new ErrorComponent ($prefix, $context,
                                       $context->getText ("Competition is not specified"));

        if (is_array ($leagueId))
            $leagueId = implode ("_", $leagueId);
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        return $this->createLeagueDependentComponent ($context, $prefix, $dbtable, $leagueId);
        }

    abstract protected function createLeagueDependentComponent ($context, $prefix, $dbtable, $leagueId);
        
    }

<?php
require_once (PATH.'inc/sports/matchcollector.php');
require_once (PATH.'pages/fragmenttemplate.php');

class MatchAnnouncement extends FragmentTemplate
    {
    protected $parts = NULL;
    public $showRssLinks = true;

    const PARAM_COMPETITION = "competition";
    const PARAM_VERTICAL = "vertical";
    const PARAM_MAX_ITEMS = "maxitems";
    const PARAM_MODE = "mode";

    public function __construct ($context, $prefix, $table, $title = NULL, $description = NULL, $params = NULL)
        {
        parent::__construct ($context, $prefix, $table, $title, $description, $params);
        $context->addStyleSheet ("sports");
        }

    public function getDisplayTemplateName ()
        {
        return $this->isVerticalLayout () ? "sports/matchannouncementv" : "sports/matchannouncementh";
        }

    protected function selectMatches ($now)
        {
        $collector = new MatchCollector ($this->context, true);
        if (!empty ($this->params[self::PARAM_COMPETITION]))
            {
            $maxItems = !empty ($this->params[self::PARAM_MAX_ITEMS]) ? $this->params[self::PARAM_MAX_ITEMS] : 10;
            $announcementsOnly = NULL;
            if (!empty ($this->params[self::PARAM_MODE]))
                $announcementsOnly = 0 === strncmp ($this->params[self::PARAM_MODE], "fut", 3);

            return $collector->selectCompetitionMatches ($now, $this->params[self::PARAM_COMPETITION], $maxItems, $announcementsOnly);
            }

        return $collector->selectMatches ($now, 1, 1, -1);
        }

    public function getDisplayableParts ()
        {
        if (NULL !== $this->parts)
            return $this->parts;

        if (!empty ($_REQUEST["today"]))
            $now = strtotime ($_REQUEST["today"]);
        if (empty ($now))
            $now = time ();
        
        $this->parts = $this->selectMatches ($now);

        foreach ($this->parts as $day => &$group)
            {
            $count = 0;
            $matchGroups = &$group['matches'];
            $keys = array_keys ($matchGroups);
            foreach ($keys as $label)
                {
                $competition = $matchGroups[$label];
                if (!isset ($competition["type"]))
                    continue;

                $type = $competition["type"];
                switch ($type)
                    {
                    case MatchConstants::ANNOUNCE_HIDE:
                        unset ($matchGroups[$label]);
                        break;

                    case MatchConstants::ANNOUNCE_SHORT:
                        $matchCount = count ($competition["rows"]);
                        if ($matchCount > 2)
                            {
                            $desc = array ("result" => $matchCount,
                                           "away" => $this->context->ngettext ("match", "matches", $matchCount));
                            $matchGroups[$label]["rows"] = array ($desc);
                            }
                        $count += 0.1 * $matchCount;
                        break;

                    case MatchConstants::ANNOUNCE_WITH_STADIUM:
                    case MatchConstants::ANNOUNCE_NORMALLY:
                    default:
                        $count += count ($competition["rows"]);
                    }
                }

            $group['count'] = $count;
            }

        return $this->parts;
        }

    public function getCreateLink ()
        {
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);
        if (!$dbtable->canCreate ())
            return NULL;
        return $this->context->processUrl ("index.php?c=ContentPage&tn={$dbtable->getName ()}&action=new", true);
        }

    public function getRssLink ($pastResults, $additionalQueryParams = NULL)
        {
        $feed = $pastResults ? "MatchResults" : "MatchAnnouncements";
        $rssUrl = $this->context->chooseUrl ("feed/$feed", "index.php?c=Rss&ch=$feed", $additionalQueryParams);
        return $rssUrl;
        }

    public function getRssLabel ($pastResults)
        {
        return $pastResults ? $this->context->getText ("Results") : $this->context->getText ("Announcements");
        }

    public function isVerticalLayout ()
        {
        return !empty ($this->params[self::PARAM_VERTICAL]);
        }

    public function getNavigationLink ($next)
        {
        if (!empty ($_REQUEST["today"]))
            $now = strtotime ($_REQUEST["today"]);
        if (empty ($now))
            $now = time ();
        $now = $next ? ($now + 3*24*60*60) : ($now - 3*24*60*60);
        $today = date ("Y-m-d", $now);
        return $this->context->getAdjustedUrl (array ("today" => $today));
        }

    protected function getAdditionalEditorFields ()
        {
        $arr = parent::getAdditionalEditorFields ();
        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        $arr[] = new RelationAutocompleteField ("fld", $dbtable, self::PARAM_COMPETITION,
                                                $this->getText ("Competition:"),
                                                $this->getText ("Enter the year and the name of the competition to filter by"),
                                                false);
        $arr[] = new IntFieldTemplate ("fld", self::PARAM_MAX_ITEMS,
                                            $this->getText ("Max items:"),
                                            $this->getText ("Number of items to show in results and announcement boxes"));
        $arr[] = new CheckBoxFieldTemplate ("fld", self::PARAM_VERTICAL,
                                            $this->getText ("Vertical layout:"),
                                            $this->getText ("Should the results and announcement tables flow vertically or horizontally?"));

        return $arr;
        }

    protected function getShowDescription ()
        {
        return false;
        }

    }

<?php
require_once (PATH."inc/sports/constants.php");
require_once (PATH."inc/sports/common.php");
require_once (PATH."inc/sports/scorecollector.php");
require_once (PATH."inc/sports/statistics.php");
require_once (PATH."pages/simpletext.php");

class LeagueStatisticsComponent extends SimpleText
    {
    protected $leagueId;
    protected $visible;
    protected $cachedText = NULL;
    protected $url;

    public function __construct ($context, $table, $leagueId, $url)
        {
        $this->leagueId = $leagueId;
        $this->visible = true;
        $this->url = $url;
        parent::__construct ($context, "a", $table->getName ());

        $context->addStyleSheet ("sports");

        $this->title = $this->getText ("Statistics|competition");
        $this->titleInline = true;
        }

    public function isVisible ()
        {
        $this->getDisplayedText ();
        return $this->visible;
        }

    public function getDisplayedText ()
        {
        if (NULL !== $this->cachedText)
            return $this->cachedText;

        /* some simple competition season statistics:
            - There were 256 games planned during the season, 10 results were anulled, 15 penalty shoot-outs, ....
            - first and last goal scored
        */

        $dbtable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_COMPETITIONSTAGE);
        $competitionIds = SportsHelper::selectCompetitionHierarchyIds ($this->context, $dbtable, array ($this->leagueId));
        $scoreCollector = new ScoreCollector ();
        $criteria = SportsHelper::createMatchTableCriterion ($this->context, $competitionIds, NULL, true);
        $result = $scoreCollector->selectStatistics ($this->context, $this->request, "competitionstats", $criteria, $this->leagueId."#");

        $statement = $this->getGenericStatistics ($result);
        if (empty ($statement))
            {
            $this->visible = false;
            return NULL;
            }

        $statement;

        $randomStatistics = $this->getRandomStatistics ($result);
        if (!empty ($randomStatistics))
            $statement .= "<br><br>".implode ("<br>", $randomStatistics);

        $this->cachedText = $statement;
        return $this->cachedText;
        }

    protected function getGenericStatistics ($statistics)
        {
        if (empty ($statistics[ScoreCollector::COL_GAME_COUNT]))
            return NULL;
        $parts[] = $this->ngettext ("Total [_0] game was played", "Total [_0] games were played", $statistics[ScoreCollector::COL_GAME_COUNT]);
        $parts[] = $this->ngettext ("[_0] goal was scored", "[_0] goals were scored", $statistics[ScoreCollector::COL_GOALS_COUNT]);
        
        return trim (implode (", ", $parts), ". ").".";
        }

    protected function getRandomStatistics ($statistics)
        {
        $possibleStatistics = array (
                                ScoreCollector::COL_HIGHEST_SCORE => $this->getText ("Highest score this season"),
                                ScoreCollector::COL_BIGGEST_DEFEAT => $this->getText ("Biggest defeat this season"),
                                ScoreCollector::COL_MOST_AWAY => $this->getText ("Most goals scored away"),
                                ScoreCollector::COL_MOST_HOME => $this->getText ("Most goals scored at home"),
                                ScoreCollector::COL_WIN_SEQUENCE => $this->getText ("Longest winning streak"),
                                ScoreCollector::COL_NOWIN_SEQUENCE => $this->getText ("Longest streak without winning"),
                                ScoreCollector::COL_SCORING_SEQUENCE => $this->getText ("Longest scoring streak"),
                                ScoreCollector::COL_SEQUENCE_WITHOUT_SCORING => $this->getText ("Longest streak without scoring"),
                                ScoreCollector::COL_LOST_SEQUENCE => $this->getText ("Longest loosing streak"),
                                ScoreCollector::COL_NODEFEAT_SEQUENCE => $this->getText ("Longest streak without loosing"),
                                );
        $arrayKeys = array_keys ($possibleStatistics);
        shuffle ($arrayKeys);
        $result = NULL;
        foreach ($arrayKeys as $key)
            {
            // if multiple entries or empty entry, just skip
            if (empty ($statistics[$key]) || preg_match_all ("#\(#", $statistics[$key], $matches) > 1)
                continue;
        
            $result[] = $this->getText ("[_1] - [_0].", $statistics[$key], $possibleStatistics[$key]);
            if (count ($result) >= 2)
                break;
            }

        return $result;
        }

    public function getMoreInformationUrl ()
        {
        return $this->url;
        }

    public function getTemplateName ()
        {
        return "sports/leaguestatistics";
        }

    protected static function prepareStatsArray ($arr, $label, $fill = false)
        {
        $options = array ('fill' => ($fill ? true : false));
        return FlotHelper::preparePlotSeries ($arr, $label, $options);
        }

    public function getGoalsAndCardsStatistics ()
        {
        return CompetitionStatistics::getGoalsAndCardsStatistics ($this->context, $this->leagueId);
        }

    public function getMatchStatisticsByRound ()
        {
        return CompetitionStatistics::getMatchStatisticsByRound ($this->context, $this->leagueId, NULL);
        }

    }

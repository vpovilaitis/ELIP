<?php

class SaffEvent extends RawEvent
    {
    public function __construct ($eventType, $player, $min)
        {
        switch ($eventType)
            {
            case "Raudona kortelė":
                $this->eventType = self::EVENT_RED;
                break;
            case "Geltona kortelė":
                $this->eventType = self::EVENT_YELLOW;
                break;
            case "Antra geltona kortelė":
                $this->eventType = self::EVENT_YELLOW_RED;
                break;
            case "Įvartis":
                $this->eventType = self::EVENT_GOAL;
                break;
            case "Įvartis (į savo vartus)":
                $this->eventType = self::EVENT_OWN_GOAL;
                break;
            case "11 m.":
            case "Įmuštas 11 m. baudinys":
                $this->eventType = self::EVENT_PENALTY;
                break;
            case "Neįmuštas 11 m. baudinys":
                $this->eventType = self::EVENT_PENALTY_MISS;
                break;
            default:
                $this->eventType = $eventType;
            }

        $this->player = trim ($player);
        if (NULL !== $min)
            $this->min = $min;
        }
    }

function dump_html ($html)
    {
    print "<pre>";
    foreach (split ("[\n\r]+", $html) as $line)
        {
        print htmlspecialchars (trim (str_replace ("><", ">\n  <", $line)))."\n";
        }

    print "</pre>";
    }

class PreprocessedMatchUrlContentSaff extends PreprocessedMatchUrlContent
    {
    protected function initialize ($content)
        {
        $content = cutTextPiece ($content, 'Rungtyniu statistika', 'omentarų');
        if (false === $content)
            return $this->logError ("Cannot parse given URL content");

        $date = cutTextPiece ($content, '<td class="teksto_blokas" width="30%"', '</td>', true);
        $pos = strpos ($date, ">");
        if (false === $date || false === $pos)
            return $this->logError ("Cannot parse the date");
        $this->date = substr ($date, $pos + 1);

        $stadium = cutTextPiece ($content, '<td class="teksto_blokas" width="70%"', '</td>', true);
        $pos = strpos ($stadium, ">");
        if (false === $stadium || false === $pos)
            return $this->logError ("Cannot parse the stadium");

        $this->stadium = substr ($stadium, $pos + 1);

        $content = cutTextPiece ($content, '<table width="100%" border="0" cellspacing="0" cellpadding="0" >');
        if (false === $content)
            return $this->logError ("Cannot parse given URL content (teams)");

        $homeTeam = cutTextPiece ($content, '<table width="100%" border="0" cellspacing="0" cellpadding="0" >', '</table>', true);
        if (false === $homeTeam)
            return $this->logError ("Cannot parse home team");

        $score = cutTextPiece ($content, '<span style="font-size:38pt;line-height:150px;">', '</span>', true);
        if (false === $score)
            return $this->logError ("Cannot parse the score");

        $awayTeam = cutTextPiece ($content, '<table width="100%" border="0" cellspacing="0" cellpadding="0" >', '</table>', true);
        if (false === $homeTeam)
            return $this->logError ("Cannot parse away team");

        $homeTeam = trim (strip_tags ($homeTeam));
        $awayTeam = trim (strip_tags ($awayTeam));
            
print "<pre>
$this->date    $this->stadium
$homeTeam $score $awayTeam\n</pre>";

        if (false === $this->setScore ($score))
            return false;

        $content = cutTextPiece ($content, '<table width="100%" border="0" cellspacing="0" cellpadding="1">');
        if (false === $content)
            return $this->logError ("Cannot parse given URL events");
//dump_html ($content);

        //$content = str_replace ("<tr >", "<//tr><tr >", $content);
        while (!empty ($content))
            {
            $eventLine = cutTextPiece ($content, '<tr >', '</tr>', true);
            if (false === $eventLine)
                return $this->logError ("Cannot parse given URL part");

            $stripped = trim (strip_tags ($eventLine));

            if (empty ($stripped))
                break;

            if (false === $this->setEvent ($eventLine))
                return false;
            }
        }

    public function setEvent ($goalLine)
        {
        $line = trim ($goalLine);
        $home = (0 === strpos ($line, '<td height="1"'));
        $eventTime = cutTextPiece ($goalLine, '<td width="15">', '</td>', true, true);
        if (false !== $eventTime)
            {
            $home = true;
            $eventType = cutTextPiece ($goalLine, 'title="', '"', true);
            $player = cutTextPiece ($goalLine, '<td width="150">', '</td>', true);
            }
        else
            {
            $home = false;
            $player = cutTextPiece ($goalLine, '<td width="150" align="right">', '</td>', true);
            $eventType = cutTextPiece ($goalLine, 'title="', '"', true);
            $eventTime = cutTextPiece ($goalLine, '<td width="15" align="right">', '</td>', true, true);
            }

        if (false === $eventTime || false === $eventType || false === $player)
            {
            return $this->logError ("Cannot parse event '".htmlspecialchars ($line)."'");
            }

        $eventTime = trim ($eventTime, " '");

        $player = trim (strip_tags ($player));

        $event = new SaffEvent (trim ($eventType), $player, $eventTime);

        if (RawEvent::EVENT_OWN_GOAL == $event->eventType)
            $home = !$home;

        if ($home)
            $this->homeEvents[] = $event;
        else
            $this->awayEvents[] = $event;
        }
    }

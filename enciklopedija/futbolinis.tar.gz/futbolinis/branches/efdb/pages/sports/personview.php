<?php
require_once (PATH."pages/contentview.php");

class PersonView extends ContentView
    {
    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        }

    public function addComponent ($request, $name, $component)
        {
        // filter teamleagueseason component
        if ($component instanceof ContentPreview &&
            "person_names" == $component->getTableName ())
            {
            return;
            }

        parent::addComponent ($request, $name, $component);
        }

    protected function createField ($request, $prefix, $col)
        {
        if ("displayname" == $col->name)
            {
            $col = clone $col;
            $col->category = MetaDataColumns::CATEGORY_ADDITIONAL;
            }
        else if ("full" == $col->name)
            {
            return new PersonNameField ($this->context, "i", $col->columnDef->name, $col->getLabel ());
            }

        return parent::createField ($request, $prefix, $col);
        }

    public function initiallyDisplayStatistics ($instance)
        {
        return true;
        }
    }

class PersonNameField extends LabelFieldTemplate
    {
    protected $context;
    protected $namesTable;
    protected $otherNames = NULL;

    public function __construct ($context, $prefix, $name, $label)
        {
        parent::__construct ($prefix, $name, $label, false);
        $this->context = $context;
        }

    protected function getNamesTable ()
        {
        if (NULL === $this->namesTable)
            {
            $this->namesTable = ContentTable::createInstanceByName ($this->context, "person_names");
            if (empty ($namesTable))
                $this->context->log ("Warning: Names table not found");
            }
        return $this->namesTable;
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        $resultColumns[] = "first";
        $resultColumns[] = "last";

        $namesTable = $this->getNamesTable ();
        if (empty ($namesTable))
            return;

        $joinCriteria = array (new JoinColumnsCriterion ("persons_id", "f_person_persons_id"));
        $joinCriteria[] = new JoinChildCriterion ("c_visible", 1);
        $cols = array (new FunctionCount ("f_person_persons_id", "cnt"));
        $namesJoin = $namesTable->createQuery ($cols, $joinCriteria);
        if (!empty ($namesJoin))
            {
            $namesJoin->joinType = Constants::JOIN_LEFT_OUTER;
            $joins[] = $namesJoin;
            $params[] = new GroupByAll ();
            }
        }

    public function selectNames ($id)
        {
        if (empty ($this->otherNames))
            {
            $namesTable = $this->getNamesTable ();
            if (!empty ($namesTable))
                {
                $criteria = array (new EqCriterion ("f_person_persons_id", $id));
                $criteria[] = new EqCriterion ("c_visible", 1);
                $cols = array ("name", "surname", "person_names_id");
                $this->otherNames = $namesTable->selectBy ($cols, $criteria);
                }
            else
                $this->otherNames = false;
            }

        return $this->otherNames;
        }

    public function getValueForDisplay ($context, $row)
        {
        $key = $this->key;
        $constructed = trim ($row["c_first"]." ".$row["c_last"]);

        if (!isset ($row[$key]))
            return $constructed;

        $stored = $row[$key];
        if ($constructed != $stored)
            $additional[] = $stored;

        if ($row["cnt"] > 0)
            {
            $names = $this->selectNames ($row["persons_id"]);
            if (!empty ($names))
                {
                foreach ($names as $nameRow)
                    {
                    $name = trim ($nameRow["c_name"]." ".$nameRow["c_surname"]);
                    if ($name != $constructed && $name != $constructed)
                        {
                        $nameId = $nameRow["person_names_id"];
                        $link = LabelContentLinkFieldTemplate::createContentViewLink ($context,
                                                 $this->namesTable, $this->namesTable->getId (),
                                                 $nameId, Constants::MODE_REVISIONS);
                        $title = $context->getText ("Revisions");
                        $additional[] = $name." <a href=\"$link\" title=\"$title\"><small>?</small></a>";
                        }
                    }
                }
            }

        if (!empty ($additional))
            return $context->getText ("[_0] ([_1])|full name (name surname)", $constructed, implode (", ", $additional));

        return $constructed;
        }

    public function isRichText ()
        {
        return true;
        }
    }


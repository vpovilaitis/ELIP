<?php
require_once (PATH.'pages/contentinstanceeditor.php');
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'pages/sports/relatedurlfield.php');

class LeagueSeasonEditor extends ContentInstanceEditor
    {
    protected $relatedDataFields;
    const LINK_COUNT = 3;
    protected $linkCount = NULL;
    protected $seasonRow = NULL;
    protected $childrenCache = array ();

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        /*
        $context->addScriptFile ("sports");
        $context->addStyleSheet ("sports_editor");
        $script = "attachMatchEditor ('".$this->getPrefix()."');";
        $this->addComponent ($context, "script", new StartupScript ($context, $script));
        */
        return true;
        }

    public function isComplexView ()
        {
        $template = parent::getTemplateName ();
        return !$this->flatTemplate;
        }

    protected function getTemplateParts ($request)
        {
        $fields = parent::getTemplateParts ($request);
        if ($this->isComplexView ())
            {
            if (!empty ($this->relatedDataFields))
                $fields = array_merge ($fields, $this->relatedDataFields);
            }
        return $fields;
        }

    protected function collectTemplateFields ($request, $isCreating)
        {
        $fields = parent::collectTemplateFields ($request, $isCreating);

        if ($this->isComplexView () && NULL === $this->relatedDataFields)
            {
            $this->relatedDataFields = false;
            $this->relatedDataFields = $this->createRelatedDataFields ($this->context);
            $fields = array_merge ($fields, $this->relatedDataFields);
            $this->template = $this->fields = $fields;
            }

        return $fields;
        }

    protected function createRelatedDataFields ()
        {
        $fields = array ();

        $linkCount = $this->getLinkCount ();
        for ($i = 0; $i < $linkCount; $i++)
            {
            $fields[] = new RelatedUrlField ($this->context, $this->getPrefix (), "x_".$this->dbtable->getName(),
                                             $this->getText ("External link:"),
                                             $this->getText ("External link."), $i);
            }
        $fields[] = new HiddenAdditionalFieldTemplate ($this->getPrefix (), "linkcount");

        return $fields;
        }

    protected function getLinkCount ()
        {
        if (NULL !== $this->linkCount   )
            return $this->linkCount;

        $id = $this->getIds ();
        $cnt = NULL;
        if (!empty ($this->request["linkcount"]))
            $cnt = $this->request["linkcount"];

        if (NULL === $cnt)
            $cnt = self::LINK_COUNT;

        /*
        $idColumns = $this->dbtable->getPrimaryIndexColumns ();
        $criteria = array (new EqCriterion ($idColumns[0]->name, $id[0]));
        $existingCount = MatchEventField::getCount ($this->context, $this->request, $criteria, $this->childrenCache);
        if ($existingCount > $cnt)
            $cnt = $existingCount;
        */

        $this->linkCount = $cnt;
        return $this->linkCount;
        }

    protected function loadDefaultOrInitialValues (&$request, $template)
        {
        $ret = parent::loadDefaultOrInitialValues ($request, $template);
        if ($this->isCreating () && !empty ($_REQUEST["templ"]))
            {
            $criteria[] = new EqCriterion ($this->dbtable->getIdColumn (), $_REQUEST["templ"]);
            $row = $this->dbtable->selectSingleBy (NULL, $criteria);
            
            if (empty ($row))
                return $ret;

            foreach (array (Sports::COL_COMPETITION_REGION => Sports::TABLE_COUNTRY, Sports::COL_COMPETITION_SEASON => Sports::TABLE_SEASON) as $col => $table)
                {
                $fullName = ContentTable::generateForeignKeyColumn ($col, $table."_id");
                $request[$col] = $row[$fullName];
                $request[$col."_label"] = $row[$col.".".ContentTable::COL_DISPLAY_NAME];

                if (Sports::COL_COMPETITION_SEASON == $col)
                    {
                    $seasonTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_SEASON);
                    $seasonRow = $seasonTable->selectSingleBy (NULL, array (new EqCriterion ($seasonTable->getIdColumn (), $request[$col])));
                    if (!empty ($seasonRow))
                        {
                        $seasonCriteria = array ();
                        $year = substr ($seasonRow[ContentTable::PREFIX.Sports::COL_SEASON_START], 0, 4) + 1;
                        $val = $year.substr ($seasonRow[ContentTable::PREFIX.Sports::COL_SEASON_START], 4);
                        $seasonCriteria[] = new EqCriterion (ContentTable::PREFIX.Sports::COL_SEASON_START, $val);
                        $year = substr ($seasonRow[ContentTable::PREFIX.Sports::COL_SEASON_END], 0, 4) + 1;
                        $val = $year.substr ($seasonRow[ContentTable::PREFIX.Sports::COL_SEASON_END], 4);
                        $seasonCriteria[] = new EqCriterion (ContentTable::PREFIX.Sports::COL_SEASON_END, $val);
                        $nextSeasonRow = $seasonTable->selectSingleBy (NULL, $seasonCriteria);
                        if (!empty ($nextSeasonRow))
                            {
                            $request[$col] = $nextSeasonRow[$seasonTable->getIdColumn ()];
                            $request[$col."_label"] = $nextSeasonRow[ContentTable::PREFIX.ContentTable::COL_DISPLAY_NAME];
                            }
                        }
                    }
                }
            foreach (array (Sports::COL_COMPETITION_STARTS, Sports::COL_COMPETITION_ENDS,
                            Sports::COL_COMPETITION_ISCUP, Sports::COL_COMPETITION_LEVEL, "zone", "progress") as $col)
                {
                $val = $row[ContentTable::PREFIX.$col];
                if (!empty ($val) && (Sports::COL_COMPETITION_STARTS == $col || Sports::COL_COMPETITION_ENDS == $col))
                    {
                    $year = substr ($val, 0, 4) + 1;
                    $val = $year.substr ($val, 4);
                    }

                $request[ContentTable::PREFIX.$col] = $val;
                }
            }

        return $ret;
        }

    protected function createRecord (&$request, $values)
        {
        if (!$this->isComplexView ())
            return parent::createRecord ($request, $values);

        $related = $this->prepareRelatedData ($request, $values);
        if (false === $related)
            return false;
        $ret = parent::createRecord ($request, $values);
        if (!$ret)
            return $ret;

        if (!$this->updateRelatedData ($this->getIds (), $related, $values, NULL))
            return false;
        return $ret;
        }

    protected function retrieveSeasonItem ($request, $id, $reset = false)
        {
        if ($reset || NULL === $this->seasonRow)
            $this->seasonRow = parent::retrieveExisting ($request, $id);

        return $this->seasonRow;
        }

    protected function modifyRecord ($request, $id, $values)
        {
        if (!$this->isComplexView ())
            return parent::modifyRecord ($request, $id, $values);

        $related = $this->prepareRelatedData ($request, $values);
        if (false === $related)
            return false;
        $ret = parent::modifyRecord ($request, $id, $values);
        if (!$ret)
            return $ret;

        // update cached instance
        $modifiedRow = $this->retrieveSeasonItem ($request, $id, true);
        $this->partiallyUpdateInitialValues ($modifiedRow);
        
        // modify related info
        if (false === $this->updateRelatedData ($id, $related, $values, $modifiedRow))
            {
            $this->log ("Failed to update related match data");
            return false;
            }
        return $ret;
        }

    protected function retrieveExisting ($request, $id)
        {
        $this->log ("Retrieving league season entry");
        $row = $this->retrieveSeasonItem ($request, $id);
        if (empty ($row) || !$this->isComplexView ())
            return $row;

        $idColumns = $this->dbtable->getPrimaryIndexColumns ();

        foreach ($this->relatedDataFields as $field)
            {
            if (!$field instanceof RelatedRecordField)
                continue;
            $field->retrieveRecord ($this->context, $field->getParentCriteria ($idColumns, $id), $row, $this->childrenCache);
            }

        $row["linkcount"] = $this->getLinkCount ();

        return $row;
        }

    protected function prepareRelatedData ($request, &$values)
        {
        $output = array ();
        $initialValues = $this->getInitialValues ();

        foreach ($this->relatedDataFields as $field)
            {
            if (!$field instanceof RelatedRecordField)
                {
                unset ($values[$field->key]);
                continue;
                }
            if (false === $field->prepareForStoring ($this->context, $values, $initialValues, $output))
                return false;
            }

        return $output;
        }

    protected function updateRelatedData ($id, $prepared, $values, $modifiedRow)
        {
        $sourceValues = array ();
        if (!empty ($values[DBTable::COL_SOURCE]))
            $sourceValues[DBTable::COL_SOURCE] = $values[DBTable::COL_SOURCE];
        if (!empty ($values[DBTable::COL_SOURCEDATE]))
            $sourceValues[DBTable::COL_SOURCEDATE] = $values[DBTable::COL_SOURCEDATE];

        $atLeastOneSucceeded = true; // if set to "false", saving will stop if first call fails
        $ret = true;
        foreach ($this->relatedDataFields as $field)
            {
            if (!$field instanceof RelatedRecordField)
                continue;

            if (false === $field->storePreparedRecord ($this->context, $this->request, $id, $prepared, $sourceValues, $modifiedRow))
                {
                if (!$atLeastOneSucceeded)
                    return false;
                $ret = false;
                }

            $atLeastOneSucceeded = true;
            }

        return $ret;
        }
    }

<?php
require_once (PATH.'pages/sports/baseleaguefragment.php');
require_once (PATH.'pages/sports/leaguecards.php');

class LeagueDisciplineFragment extends BaseLeagueFragment
    {
    const ITEMS_SHOWN = 5;

    protected function createLeagueDependentComponent ($context, $prefix, $dbtable, $leagueId)
        {
        return new LeagueCards ($context, $dbtable, $leagueId, self::ITEMS_SHOWN);
        }
    }

<?php
require_once (PATH."pages/sports/seasonresultsbase.php");
require_once (PATH."pages/sports/cupresultscomponent.php");
require_once (PATH."inc/urlicon.php");

class LeagueTableComponent extends SeasonResultsBase
    {
    protected $hasLeagueResults = false;
    public $dataInconsistencies = array ();
    private $newMatchUrl = NULL;
    static protected $nextId = 1;
    
    const MODE_FULL = 1;
    const MODE_COMPACT = 2;
    const MODE_EXPORT = 3;

    public function __construct ($context, $dbtable, $leagueId, $system, $rounds = NULL, $explicitlySpecified = false, $forExport = false)
        {
        parent::__construct ($context, $dbtable, $leagueId, $system, $rounds, $explicitlySpecified, $forExport);
        $context->addScriptFile ("sports");
        }

    public function getTitle ()
        {
        if (empty ($this->title))
            return $this->getText ("League table");
        else
            return $this->title;
        }

    public function isVisible ()
        {
        return !empty ($this->teams) || $this->hasLeagueResults || ($this->explicitlySpecified && $this->hasMatches);
        }

    public function processInput ($context, &$request)
        {
        if ($context->getCurrentUser () > 0 && !$context->renderInline ())
            {
            $context->addScriptFile ("competition");
            $context->addScriptFile ("editor");
            }

        $row = $this->getCompetitionRow ();
        $this->teams = LeagueTableCollector::retrieveLeagueTable ($context, $this->leagueId, $this->system, $this->rounds,
                                                                  $this->hasLeagueResults, $this->additionalMatches, $this->dataInconsistencies, $this->hasMatches, $row["c_".Sports::COL_COMPETITION_STARTS]);

        if (false === $this->teams)
            return false;

        if (isset ($request["saveinconsistency"]))
            {
            $id = $request["saveinconsistency"];
            $parts = explode ("_", $id);
            $creating = 1 == count ($parts);

            foreach ($this->teams as $team)
                {
                if ($team->getId ($creating) == $id)
                    {
                    if ($creating && $team->hasDBEntry ())
                        {
                        $this->addError ("Record already exists");
                        break;
                        }

                    $resultsTable = $this->getTeamLeagueSeasonsTable ($context);
                    $values = $team->getValuesForDB ();
                    $values[DBTable::COL_SOURCE] = $this->getText ("Calculated by match results");
                    $values[DBTable::COL_SOURCEDATE] = date ("Y-m-d");
                    if ($creating)
                        {
                        $values["team_id"] = $parts[0];
                        $values[ContentTable::generateForeignKeyColumn (Sports::COL_TEAMLEAGUESEASON_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id")] = $this->leagueId;
                        $id = $resultsTable->insertRecord ($values);
                        if (false === $id)
                            $this->addError ("Failed to create record");
                        else
                            $team->setStored ();
                        }
                    else
                        {
                        $criteria = array
                            (
                            new EqCriterion ("team_id", $parts[0]),
                            new EqCriterion ("teamleagueseasons_id", $parts[1]),
                            );
                        if (false === $resultsTable->updateRecord ($criteria, $values))
                            $this->addError ("Failed to update record");
                        else
                            $team->setStored ();
                        }
                    
                    break;
                    }
                }
            }

        return true;
        }

    public function getTemplateName ()
        {
        return "sports/leaguetable";
        }

    public function getRows ($mode = LeagueTableComponent::MODE_FULL)
        {
        $resultsTable = $this->getTeamLeagueSeasonsTable ($this->context);
        $matchesTable = $this->getMatchesTable ($context);
        $canEdit = $resultsTable->canEdit ();
        $canCreate = $resultsTable->canEdit ();

        $rows = array ();
        foreach ($this->teams as $team)
            {
            $tools = NULL;
            $url = $team->getResultsRowUrl ($this->context, $canEdit);
            if (!empty ($url))
                {
                $tools[] = new AdditionalURLIcon ($this, $canEdit ? "edit" : "browse",
                                                  $this->getText ("Details and sources"), $url);
                }

            if (!$team->hasDBEntry ())
                {
                if ($canCreate)
                    {
                    $url = $this->context->getAdjustedUrl (array ($this->getPrefix ()."_saveinconsistency" => $team->getId (true)));
                    $tools[] = new AdditionalURLIcon ($this, "accept",
                                                      $this->getText ("Create entry from calculated values"), $url);
                    }
                }
            else if ($canEdit && $team->hasInconsistencies ())
                {
                $url = $this->context->getAdjustedUrl (array ($this->getPrefix ()."_saveinconsistency" => $team->getId (false)));
                $tools[] = new AdditionalURLIcon ($this, "confirm",
                                                  $this->getText ("Adjust by calculated values"), $url);
                }

            $rows[] = $team->toArray ($this->context, $this->teams, $this->hasMatches && LeagueTableComponent::MODE_FULL == $mode, $tools, $matchesTable->canCreate (), LeagueTableComponent::MODE_COMPACT == $mode);
            }

        if (count ($rows) > 1 && $matchesTable->canCreate ())
            $this->newMatchUrl = $this->context->processUrl ("index.php?service=sports/CreateMatchPopup", true);
        return $rows;
        }

    public function getHeaderLabels ()
        {
        $resultsTable = $this->getTeamLeagueSeasonsTable ($this->context);
        $canEdit = $resultsTable->canEdit ();
        return LeagueTableRow::getHeaderLabels ($this->context, $this->teams, $this->hasMatches || !empty ($this->newMatchUrl), $canEdit);
        }
    
    public function getReferences ()
        {
        if (!empty ($_REQUEST["showerrors"]))
            return $this->dataInconsistencies;
        return NULL;
        }

    public function getRounds ()
        {
        if (empty ($this->additionalMatches))
            return NULL;
        $rounds = array ();
        foreach ($this->additionalMatches as $roundName => $matches)
            {
            $round = new CupRound ($this->context, $roundName, 0, false);
            $round->setLogos ($this->teams);

            foreach ($matches as $match)
                $round->addMatch ($match);

            $rounds[$roundName] = $round;
            }

        return array_reverse ($rounds);
        }

    public function getNewMatchParams ()
        {
        if (empty ($this->newMatchUrl))
            return NULL;
        return array ("elementId" => "l_i".self::$nextId++,
                      "url" => $this->newMatchUrl,
                      "competitionId" => $this->leagueId,
                      "imageUrl" => $this->context->getSmallIconPath ("new"),
                      "imageLabel" => $this->getText ("Add match"),
                      "rounds" => $this->rounds
                      );
        }

    public function getScheduleLinkLabel ()
        {
        return $this->getText ("Competition schedule");
        }

    public function getFilterLinkLabel ()
        {
        return $this->getText ("Filter by");
        }

    public function getFilterLabel ()
        {
        return $this->getText ("filter");
        }

    public function getFilterIconPath ()
        {
        return $this->context->getTinyIconPath ("newseparator");
        }

    public function getFilterUrls ()
        {
        $result = array ();

        $result[$this->context->getAdjustedUrl (array ('filter' => NULL, 'round' => NULL))] = $this->getText ("All games");
        $result[$this->context->getAdjustedUrl (array ('filter' => 'home', 'round' => NULL))] = $this->getText ("Home games only");
        $result[$this->context->getAdjustedUrl (array ('filter' => 'away', 'round' => NULL))] = $this->getText ("Away games only");
        return $result;
        }

    public function getScheduleUrl ()
        {
        return $this->context->processUrl ("index.php?c=sports/MatchList&leagueid=$this->leagueId");
        }
    }

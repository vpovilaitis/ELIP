<?php
require_once (PATH."pages/contentpreview.php");

abstract class MatchPlayersBase extends ContentPreview
    {
    protected $skippedCount = 0;

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $context->addStyleSheet ("sports");
        }

    protected abstract function getIsHomeColumnName ();
    
    protected function isFieldVisible ($col, &$hiddenFields)
        {
        if ($this->getIsHomeColumnName () == $col->name)
            return true;
        return parent::isFieldVisible ($col, $hiddenFields);
        }

    public function getTemplateName ()
        {
        return "sports/matchplayers";
        }

    public function getHomeGoals ($rows)
        {
        return $this->getEvents ($rows, true);
        }

    public function getAwayGoals ($rows)
        {
        return $this->getEvents ($rows, false);
        }

    protected function getEvents ($rows, $home)
        {
        if (empty ($rows))
            return NULL;
        $template = $this->getTemplate ();
        $isHomeColumn = $this->getIsHomeColumnName ();

        $events = array ();
        foreach ($template as $field)
            {
            switch ($field->key)
                {
                case "player":
                    $playerField = $field;
                    break;
                }
            }

        if (empty ($playerField))
            return array (array ("player" => $this->getText ("Invalid arguments")));

        $title = $this->getText ("Show sources");
        $context = $this->context;
        $this->sort ($rows);
        foreach ($rows as $row)
            {
            if ($home != $row["c_$isHomeColumn"])
                {
                $this->createEmptyEventRow ($events, $row);
                continue;
                }

            $player = $this->getPlayerName ($row, "player");
            $playerUrl = $playerField->getUri ($context, $row);
            $event = $this->createEventRow ($row, $time, $player, $playerUrl, $playerField, !empty ($row["c_captain"]));
            if (false === $event)
                continue;
            $events[] = $event;
            }

        for ($i = count ($events); $i < $this->skippedCount; $i++)
            $events[] = NULL;
        $this->skippedCount = 0;

        return $events;
        }

    protected function sort (&$rows)
        {
        }

    protected function getPlayerName ($row, $key)
        {
        if (empty ($row["$key.c_first"]) && empty ($row["$key.c_last"]))
            {
            if (!empty ($row["$key.c_full"]))
                return $row["$key.c_full"];
            else
                return $row["$key.".ContentTable::COL_DISPLAY_NAME];
            }
        else
            return $row["$key.c_first"]." ".$row["$key.c_last"];

        return NULL;
        }

    protected function createEmptyEventRow (&$events, $row)
        {
        $events[] = NULL;
        }

    protected function createEventRow ($row, $time, $player, $playerUrl, $playerField = null, $captain = false)
        {
        $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                     $this->dbtable->getId (),
                                                                     $this->getId ($row),
                                                                     Constants::MODE_VIEW);

        $playerEntry = "<a href='$playerUrl'>$player</a>";
        if ($captain)
            $playerEntry = $this->getText ("[_0] (c)|captain", $playerEntry);

        return array
                (
                "player" => $playerEntry,
                "link" => "<a class='[_1]' href='$url' title='$title'>[_0]</a>",
                );
        }

    public function getPageSize ()
        {
        return -1;
        }

    public function getDisplayableParts ($selectedRows)
        {
        $entry = array
                    (
                    "title" => NULL,
                    "home" => $this->getHomeGoals($selectedRows),
                    "away" => $this->getAwayGoals($selectedRows),
                    );
        return array ($entry);
        }
    }

class MatchPlayers extends MatchPlayersBase
    {
    protected $substitutes;

    protected function getIsHomeColumnName ()
        {
        return "hometeam";
        }

    public function select ($context, $criteria = NULL)
        {
        $rows = parent::select ($context, $criteria);
        if (empty ($rows))
            return $rows;

        $includedSubstitutes = array ();
        $playerSubstitutes = array ();
        $idToRow = array ();

        foreach ($rows as $row)
            {
            $id = $row["player"][0];
            }

        foreach ($rows as $row)
            {
            $id = $row["player"][0];
            $from = $row["c_entered"];
            if (!empty ($row["substitute"]))
                {
                $substituteId = $row["substitute"][0];
                $to = $row["c_left"];
                $playerSubstitutes[$id."_".$from] = $substituteId."_".$to;
                $includedSubstitutes[$substituteId."_".$to] = true;
                }

            $idToRow[$id."_".$from] = $row;
            }

        $result = array ();
        foreach ($rows as $row)
            {
            $id = $row["player"][0];
            $from = $row["c_entered"];
            if (array_key_exists ($id."_".$from, $includedSubstitutes) || !empty ($row["c_unused"]))
                {
                $this->substitutes[] = $row;
                continue;
                }

            $row = $this->addSubstitute ($idToRow, $playerSubstitutes, $id."_".$from);
            $result[] = $row;
            }

        return $result;
        }

    protected function addSubstitute ($idToRow, $playerSubstitutes, $id)
        {
        $row = $idToRow[$id];
        if (array_key_exists ($id, $playerSubstitutes))
            {
            $row["subst"] = $this->addSubstitute ($idToRow, $playerSubstitutes, $playerSubstitutes[$id]);
            }
            
        return $row;
        }

    protected function isFieldVisible ($col, &$hiddenFields)
        {
        if (parent::isFieldVisible ($col, $hiddenFields))
            return true;
        if ("extra" == $col->name || Sports::COL_PLAYER_CAPTAIN == $col->name || Sports::COL_PLAYER_UNUSED == $col->name)
            return true;
        return false;
        }

    protected function createEventRow ($row, $time, $player, $playerUrl, $playerField = null, $captain = false, $inner = false)
        {
        $player = parent::createEventRow ($row, $time, $player, $playerUrl, NULL, $captain);

        $player["time"] = $row["c_number"];
        $from = $row["c_entered"];
        if (!empty ($row["c_extra"]))
            $from .= "+".$row["c_extra"];
        $to = $row["c_left"];

        if (empty ($player["time"]))
            $player["time"] = $this->formatText ($player["link"], "...", "transparentlink");
        else
            $player["time"] = $this->formatText ($player["link"], $player["time"], "nounderline");

        if (!empty ($row["subst"]))
            {
            $substitute = $row["subst"];
            $substituteLabel = $this->getPlayerName ($substitute, "player");
            $substituteUrl = $playerField->getUri ($this->context, $substitute);
            $eventRow = $this->createEventRow ($substitute, $time, $substituteLabel, $substituteUrl, $playerField, false, true);
            $modifier = "";
            if ($inner)
                $modifier .= ", ";
            if (!empty ($to))
                {
                if (!empty ($substitute["c_entered"]))
                    {
                    $to = $substitute["c_entered"];
                    if (!empty ($substitute["c_extra"]))
                        $to .= "+".$substitute["c_extra"];
                    }

                $modifier .= $this->formatText ($eventRow["link"], $this->getText ("[_0]'|substitute", $to), "nounderline")." ";
                }
            $player["modifier"] = $modifier.$eventRow["player"].$eventRow["modifier"];
            if (!$inner)
                $player["modifier"] = "(".trim ($player["modifier"]).")";
            }
        else if ($inner)
            ;
        else if ($from > 0 && $to != 80 && $to != 90 && $to != 120)
            $player["modifier"] = $this->getText ("[_0]'-[_1]'", $from, $to);
        else if ($from > 0)
            $player["modifier"] = $this->getText ("on [_0]'|substitute", $from);
        else if (NULL !== $to && $to != 80 && $to != 90 && $to != 120)
            $player["modifier"] = $this->getText ("off [_0]'|substitute", $to);

        return $player;
        }

    protected function createEmptyEventRow (&$events, $row)
        {
        $this->skippedCount++;
        }

    public function getDisplayableParts ($selectedRows)
        {
        $ret = parent::getDisplayableParts ($selectedRows);
        if (!empty ($this->substitutes))
            {
            $entry = array
                        (
                        "title" => $this->getText ("Substitutes"),
                        "class" => "substitutes",
                        "home" => $this->getHomeGoals($this->substitutes),
                        "away" => $this->getAwayGoals($this->substitutes),
                        );
            $ret[] = $entry;
            }

        if (!empty ($this->parentComponent))
            {
            $parentInstance = $this->parentComponent->getInstance ();
            if (!empty ($parentInstance) && (!empty ($parentInstance[Sports::COL_MATCH_HOMECOACH]) || !empty ($parentInstance[Sports::COL_MATCH_AWAYCOACH])))
                {
                $personsTable = ContentTable::createInstanceByName ($context, Sports::TABLE_PERSON);
                if (empty ($personsTable))
                    var_dump ("Error");
                
                $coach = $this->getPlayerName ($parentInstance, Sports::COL_MATCH_HOMECOACH);
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $personsTable,
                                                                     $personsTable->getId (),
                                                                     $parentInstance[Sports::COL_MATCH_HOMECOACH]);
                $homeCoachEntry = array ("player" => "<a href='$url'>$coach</a>");

                $coach = $this->getPlayerName ($parentInstance, Sports::COL_MATCH_AWAYCOACH);
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $personsTable,
                                                                     $personsTable->getId (),
                                                                     $parentInstance[Sports::COL_MATCH_AWAYCOACH]);
                $awayCoachEntry = array ("player" => "<a href='$url'>$coach</a>");

                $entry = array
                            (
                            "title" => $this->getText ("Coaches"),
                            "class" => NULL,
                            "home" => array ($homeCoachEntry),
                            "away" => array ($awayCoachEntry),
                            );
                $ret[] = $entry;
                }
            }

        return $ret;
        }

    public function getAdditionalActions ()
        {
        $ret = parent::getAdditionalActions ();
        if (NULL != $this->dbtable && ($this->dbtable->canCreate () || $this->dbtable->canEdit ()) && NULL != $this->parentId)
            {
            $idparam = "&id=".implode ("_", $this->parentId);

            $url = "index.php?c=ContentPage&action=".Constants::MODE_EDIT."&tid={$this->dbtable->getParentTable()->getId()}$idparam&parts=".MatchEditorMode::PLAYERS;
            $ret[] = new AdditionalURLIcon ($this, "edit", $this->_("Edit goals"), $url);
            }

        return $ret;
        }
    }
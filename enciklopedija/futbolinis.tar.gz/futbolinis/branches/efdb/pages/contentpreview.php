<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'inc/preview.php');
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/relationfields.php');

class ContentPreview extends Preview
    {
    protected $parentId;
    protected $title;
    protected $criteria;
    protected $excludedColumns;
    protected $showParent = true;
    protected $searchCriteriaField = NULL;
    protected $appliedCriteriaField = NULL;
    protected $searchButtonField = NULL;
    protected $parentComponent = NULL;
    protected $orderByColumns = NULL;

    const FILTER_CRITERIA = "criteria";
    const APPLIED_CRITERIA = "applied";
    const SEARCH_BUTTON = "go";

    public function __construct ($context, $prefix, $table, $title = NULL, $description = NULL)
        {
        parent::__construct ($prefix, $context, null);
        $this->title = $title;

        if (NULL == $table)
            $this->displayErrorPage ($this->_("Invalid parameters passed (requested data table not set)"));
        else
            {
            if ($table instanceof ContentTable)
                $this->dbtable = $table;
            else if (is_numeric ($table))
                $this->dbtable = ContentTable::createInstanceById ($context, $table);
            else
                $this->dbtable = ContentTable::createInstanceByName ($context, $table);

            if (!$this->dbtable)
                $this->displayErrorPage ($this->_("Invalid parameters passed (requested data table not configured)"));
            }

        $context->addScriptFile ("autosuggest");
        }

    public function setParent ($parentId, $parentComponent = NULL)
        {
        $this->parentId = $parentId;
        $this->showParent = false;
        $this->parentComponent = $parentComponent;
        }

    public function setCriteria ($criteria)
        {
        $this->criteria = $criteria;
        }

    public function showParentField ($show)
        {
        $this->showParent = $show;
        }

    public function excludeColumns ($excludedColumns)
        {
        $this->excludedColumns = $excludedColumns;
        }

    public function getTable ()
        {
        return $this->dbtable;
        }

    public function getTableName ()
        {
        if (!$this->dbtable)
            return NULL;
        return $this->dbtable->getName();
        }

    public function getTitle ()
        {
        if (!empty ($this->title))
            return $this->title;
        return NULL;
        }

    public function setTitle ($title)
        {
        $this->title = $title;
        }

    public function getDescription ()
        {
        if (!$this->dbtable)
            return $this->_("Content Preview");
        return $this->dbtable->getDescription();
        }

    protected function getDisplayTemplate ()
        {
        if (!$this->dbtable)
            return false;

        $dbColumns = $this->dbtable->selectColumns ();
        $fields = array ();
        $displayNameColumn = $this->dbtable->getDisplayNameColumnName ();
        $displayColumnShown = false;

        if ($this->showParent)
            {
            $parentTable = $this->dbtable->getParentTable ();
            if (!empty ($parentTable))
                $fields[] = new LabelParentFieldTemplate ("i", $this->dbtable, $parentTable->getLabel ());
            }

        $hiddenFields = array ();

        for ($i = 0; $i < count ($dbColumns); $i++)
            {
            $col = $dbColumns[$i];
            $this->addFieldFromColumn ($col, $fields, $hiddenFields, $displayNameColumn, $displayColumnShown);
            }

        if (!$displayColumnShown)
            {
            $idColumns = $this->getIndexColumns ();
            $fields[] = $this->addMoreLink ($idColumns, $hiddenFields);
            }

        return $fields;
        }

    protected function addMoreLink ($idColumns, $hiddenFields)
        {
        return new MoreLinkFieldTemplate ($this->context, $this->dbtable->getId (),
                                          $idColumns, $hiddenFields, "i");
        }

    protected function addFieldFromColumn ($col, &$fields, &$hiddenFields, $displayNameColumn, &$displayColumnShown)
        {
        if (!$this->isFieldVisible ($col, $hiddenFields))
            return;

        if (!empty ($this->excludedColumns) && false !== array_search ($col->name, $this->excludedColumns))
            return;

        $field = $this->createFieldFromColumn ($col, $displayNameColumn, $displayColumnShown);
        if (empty ($field))
            return;

        if ($col instanceof ValueColumn && $displayNameColumn == $col->columnDef->name)
            array_unshift ($fields, $field);
        else
            $fields[] = $field;
        }

    protected function createFieldFromColumn ($col, $displayNameColumn, &$displayColumnShown)
        {
        if ($col instanceof ValueColumn)
            {
            if ($col->columnDef instanceof DateColumn || $col->columnDef instanceof DateTimeColumn)
                $field = new LabelDateFieldTemplate ("i", $col->columnDef->name, $col->getLabel ());
            else if ($col->columnDef instanceof BoolColumn)
                $field = new LabelBoolFieldTemplate ("i", $col->columnDef->name, $col->getLabel ());
            else if ($col->columnDef instanceof NamedIntColumn)
                $field = new LabelNamedIntFieldTemplate ("i", $col->columnDef->name, $col);
            else if ($col->columnDef instanceof WeightColumn)
                $field = new LabelWeightFieldTemplate ("i", $col->columnDef->name, $col->getLabel ());
            else if ($col->columnDef instanceof HeightColumn)
                $field = new LabelHeightFieldTemplate ("i", $col->columnDef->name, $col->getLabel ());
            else if ($col->columnDef instanceof DecimalColumn)
                $field = new LabelDecimalFieldTemplate ("i", $col->columnDef->name, $col->getLabel ());
            else if ($col->columnDef instanceof IntColumn)
                $field = new LabelIntFieldTemplate ("i", $col->columnDef->name, $col->getLabel ());
            else if ($displayNameColumn == $col->columnDef->name)
                {
                $idColumns = $this->getIndexColumns ();
                $field = new ViewUriFieldTemplate ($this->dbtable->getId (), $idColumns, "i", $col->columnDef->name, $col->getLabel ());
                $displayColumnShown = true;
                }
            else
                $field = new LabelFieldTemplate ("i", $col->columnDef->name, $col->getLabel ());

            return $field;
            }
        else // relation
            return new LabelRelationFieldTemplate ($this->context, "i", $col);
        }

    protected function isFieldVisible ($col, &$hiddenFields)
        {
        if (MetaDataColumns::CATEGORY_DETAILS == $col->category)
            {
            $hiddenFields[] = $col;
            return false;
            }

        if (MetaDataColumns::CATEGORY_PRIMARY != $col->category)
            return false;

        return true;
        }

    public function showCreateIcon ()
        {
        return NULL != $this->dbtable && $this->dbtable->canCreate ();
        }

    public function getAdditionalActions ()
        {
        $ret = parent::getAdditionalActions ();
        if ($this->showCreateIcon())
            {
            if (NULL != $this->parentId)
                $idparam = "&id=".implode ("_", $this->parentId);
            else
                $idparam = "";

            $ret = array_merge
                    (
                    $ret,
                    array
                        (
                        new AdditionalURLIcon ($this, "new", $this->_("Add new"),
                                               "index.php?c=ContentPage&tn={$this->getTableName ()}&action=new".$idparam),
                        )
                    );
            }

        if (!empty ($this->dbtable) && NULL == $this->dbtable->getParentTable ())
            {
            $url = $this->context->chooseUrl ("changes/{$this->getTableName ()}", "index.php?c=Rss&ch=Changes&tn={$this->getTableName ()}");
            $ret[] = new AdditionalURLIcon ($this, "rss", $this->_("Recent changes"), $url);
            }

        return $ret;
        }

    public function getActionList ()
        {
        $ret = parent::getActionList ();
        if (NULL != $this->dbtable && $this->dbtable->canEdit ())
            {
            array_push
                    (
                    $ret,
                    new SingleRowURLIcon ($this, "edit", $this->_("Edit"),
                                           "index.php?c=ContentPage&tn={$this->getTableName ()}&action=".Constants::MODE_EDIT)
                    );
            }

        return $ret;
        }

    protected function getIdColumns ()
        {
        if (NULL == $this->dbtable)
            return false;

        $cols = $this->dbtable->getPrimaryIndexColumns ();
        $names = array ();
        for ($c = 0; $c < count ($cols); $c++)
            {
            $names[] = $cols[$c]->name;
            }
        return $names;
        }

    protected function getFilterCriteria ()
        {
        if (!empty ($this->criteria))
            return $this->criteria;

        $parent = $this->dbtable->getParentTable ();
        $criteria = NULL;

        if (NULL != $parent && NULL != $this->parentId)
            {
            $criteria = array ();
            $cols = $parent->getPrimaryIndexColumns ();

            for ($c = 0; $c < count ($cols) && $c < count ($this->parentId); $c++)
                {
                $criteria[] = new EqCriterion ($cols[$c]->name, $this->parentId[$c]);
                }
            }

        return $criteria;
        }

    protected function prepareRowCountQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        parent::prepareRowCountQuery ($resultColumns, $criteria, $joins, $params);

        $filterCriteria = array ();
        $this->getSearchFields (); // make sure search fields are created if needed
        if (!empty ($this->appliedCriteriaField))
            {
            $filter = $this->appliedCriteriaField->getValueForDB ($this->context, $this->request);
            if (!empty ($filter))
                $params[] = new FilterCriterion ($filter);
            }
        }

    public function getSpecificPageUrl ($pageNo)
        {
        $this->getSearchFields (); // make sure search fields are created if needed
        $filter = NULL;
        if (!empty ($this->appliedCriteriaField))
            {
            $filter = $this->appliedCriteriaField->getValueForDB ($this->context, $this->request);
            if (empty ($filter))
                return parent::getSpecificPageUrl ($pageNo);
            }

        return $this->context->getAdjustedUrl (array ($this->getParam ("page") => $pageNo,
                                                      $this->getParam (self::APPLIED_CRITERIA) => $filter));
        }


    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        if (!empty ($this->orderByColumns))
            $params[] = $this->orderByColumns;
        }

    public function setOrderByCriterion ($orderBy)
        {
        $this->orderByColumns = $orderBy;
        }

    public function isVisible ()
        {
        if (($this->context->renderInline () || !$this->showCreateIcon()) && $this->getTotalCount () <= 0)
            return false;
        return true;
        }

    protected function getExecutedAction ($context, $request)
        {
        $actionStr = parent::getExecutedAction ($context, $request);
        if (!empty ($actionStr))
            return $actionStr;

        if (NULL !== $this->getSearchFields ())
            {
            // WORKAROUND for IE8:
            //   pressing 'Enter' in criteria field will not set "Go" button, so getExecutedAction does not recognize the action
            $criteria = $this->searchCriteriaField->getValueForDB ($this->context, $request);
            if (!empty ($criteria))
                return self::SEARCH_BUTTON;
            }

        return $actionStr;
        }

    public function getSearchFields ()
        {
        if (!empty ($this->criteria) || !empty ($this->parentId))
            return NULL;

        if (NULL === $this->searchCriteriaField)
            {
            $this->searchCriteriaField =
                new TextFieldTemplate ("fltr", self::FILTER_CRITERIA, "",
                                       $this->getText ("Enter criteria to filter rows by"), 10);
            $this->searchCriteriaField->setPrefix ($this->getPrefix ());
            $this->searchButtonField = new SearchButton ($this, self::SEARCH_BUTTON);
            $this->appliedCriteriaField = new HiddenFieldTemplate ("fltr", self::APPLIED_CRITERIA);
            $this->appliedCriteriaField->setPrefix ($this->getPrefix ());
            $this->context->registerInitializeScript ($this->getInitializeScript ($this->context, $this->prefix));
            }

        $arr = array ();
        $arr[] = new LabelTemplate ($this->getText ("Filter:"));
        $arr[] = $this->searchCriteriaField;
        $arr[] = $this->appliedCriteriaField;
        $arr[] = $this->searchButtonField;
        return $arr;
        }

    public function getInitializeScript ($context, $prefix)
        {
        $serviceName = "ContentService";
        $url = "index.php?service=$serviceName&id=".$this->dbtable->getId ();
        $url = $context->processUrl ($url, true);

        $mode = Constants::MODE_VIEW;
        $tableId = $this->dbtable->getId ();
        $templateUrl = $context->processUrl ("index.php?c=ContentPage&mode=$mode&tid=$tableId", true)."&id=";
        return "suggest_attachContentPreviewSearchField ('{$prefix}_".self::FILTER_CRITERIA."', '$url', '$templateUrl');";
        }

    protected function getAvailableActions ()
        {
        $arr = parent::getAvailableActions ();

        $this->getSearchFields (); // make sure search fields are created if needed

        if (!empty ($this->searchButtonField))
            $arr[] = $this->searchButtonField;
        return $arr;
        }

    public function applyFilterCriteria ($request)
        {
        $this->getSearchFields (); // make sure search fields are created
        if (empty ($this->searchButtonField))
            return;

        $criteria = $this->searchCriteriaField->getValueForDB ($this->context, $request);
        $this->request[$this->appliedCriteriaField->key] = $criteria;
        $this->onFilterCriteriaChanged ();
        }

    protected function getHintScope ()
        {
        if (empty ($this->dbtable))
            return NULL;
        return HintsTable::SCOPE_CONTENTTABLE.$this->dbtable->getName ();
        }

    protected function getHintContextMode ()
        {
        return HintsTable::CONTEXT_PREVIEW;
        }
    }

class SearchButton extends GenericButton
    {
    public function __construct ($component, $key)
        {
        parent::__construct ($component, $key, $component->getText ("Go"),
                             $component->getText ("Filter results by entered criteria"));
        }

    public function execute ($request, $ids)
        {
        $this->component->applyFilterCriteria ($request);
        return true;
        }
    }

<?php
require_once (PATH.'inc/instanceeditor.php');
require_once (PATH.'pages/editorpage.php');
require_once (PATH.'pages/discussionentry.php');

class Discussions extends EditorPage
    {
    protected $discussionsComponent = NULL;
    protected $targetTable;
    protected $entryId;

    public static function getTableFromScopeName ($context, $scope)
        {
        switch ($scope)
            {
            case "pages":
            case PageNamesTable::TABLE_SCOPE."_".PageNamesTable::TABLE_NAME:
                return new PageNamesTable ($context);

            case NewsTable::TABLE_NAME:
            case NewsTable::TABLE_SCOPE."_".NewsTable::TABLE_NAME:
                return new NewsTable ($context);

            default:
                if (0 == strncmp (Constants::TABLES_USER, $scope, strlen (Constants::TABLES_USER)))
                    $scope = substr ($scope, strlen (Constants::TABLES_USER));
                if ("_" == $scope[0])
                    return ContentTable::createInstanceByName ($context, substr ($scope, 1));
                break;
            }

        return NULL;
        }

    public function ensureChildren ($context, $request)
        {
        if (NULL === $this->discussionsComponent)
            {
            $this->discussionsComponent = false;
    
            if (empty ($request["sc"]) || empty ($request["id"]))
                {
                $this->addError ("Invalid parameters provided");
                return true;
                }
    
            $this->targetTable = self::getTableFromScopeName ($context, $request["sc"]);
    
            if (empty ($this->targetTable))
                {
                $this->addError ("Invalid parameters provided");
                return false;
                }

            $this->entryId = $request["id"];
            $this->discussionsComponent = new DiscussionsComponent ($context, $this->targetTable, $this->entryId);
    
            $this->addComponent ($request, "d", $this->discussionsComponent);
            }

        return parent::ensureChildren ($context, $request);
        }

    protected function createEditorComponent ($prefix, $context)
        {
        return new EditDiscussionComponent ($prefix, $context, $this->targetTable, $this->entryId);
        }

    public function getActionList ()
        {
        if (empty ($this->targetTable))
            return NULL;

        $url = $this->targetTable->getContentLink ($this->entryId);
        $label = $this->component->getEntryLabel ();
        if (empty ($label))
            $label = $this->getText ("Back to subject");

        $perspectivePostfix = NULL;
        if ("*" != SITE_PERSPECTIVE)
            $perspectivePostfix = "sp=".SITE_PERSPECTIVE;
        $rssUrl = $this->context->chooseUrl ("feed/Comments", "index.php?c=Rss&ch=Comments", $perspectivePostfix);
        $rssLink = new SimpleLinkAction ($this, "rss", $this->getText ("RSS"), $rssUrl, true);
        $rssLink->icon = "rss";

        return array (new SimpleLinkAction ($this, "back", $label, $url, true), $rssLink);
        }

    protected function checkAccess ($request)
        {
        $this->ensureChildren ($this->context, $request);
        $accessGranted = $this->component->checkAccess ($request) || $this->discussionsComponent->checkAccess ($request);

        if (NULL === $accessGranted)
            $accessGranted = false;

        if (false === $accessGranted)
            $this->log ("No access to show editor page (".get_class ($this->component).")");

        return $accessGranted;
        }

    public function getSubTitle ()
        {
        return NULL;
        }

    public function getTemplateName ()
        {
        return "dynamicpage";
        }
    }

class DiscussionsComponent extends Component
    {
    protected $dbtable;
    protected $scope;
    protected $entryId;
    protected $topicLabelsToIds = array ();

    public function __construct ($context, $targetTable, $entryId)
        {
        parent::__construct ("", $context);
        $this->dbtable = new DiscussionsTable ($context);
        $this->scope = is_string ($targetTable) ? $targetTable : $targetTable->getTableName ();
        $this->entryId = $entryId;
        }

    protected function getHintScope ()
        {
        return HintsTable::SCOPE_CONTENTTABLE.$this->scope;
        }

    protected function getHintContextMode ()
        {
        return HintsTable::CONTEXT_DISCUSSION;
        }

    protected function getHintContextId ()
        {
        return $this->entryId;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getTemplateName ()
        {
        return "discussions";
        }

    public function getTopics ()
        {
        $topicsTable = new DiscussionTopicTable ($this->context);
        $usersTable = new UsersTable ($this->context);

        $columns = array (DiscussionTopicTable::COL_TITLE);
        $criteria = NULL;
        $criteria[] = new EqCriterion (DiscussionTopicTable::COL_SCOPE, $this->scope);
        $criteria[] = new EqCriterion (DiscussionTopicTable::COL_CONTEXTID, $this->entryId);
        $criteria[] = new EqCriterion (DBTable::COL_LANG, $this->context->getLanguage ());
        $criteria[] = new JoinColumnsCriterion (DiscussionsTable::COL_TOPICID, DiscussionTopicTable::COL_ID);
        $joins[] = $topicsTable->createQuery ($columns, $criteria);

        $userJoin = $usersTable->createQuery (array (UsersTable::COL_NAME),
                                              array (new JoinColumnsCriterion (DBTable::COL_CREATEDBY, UsersTable::COL_ID)));

        $userJoin->joinType = Constants::JOIN_LEFT_OUTER;
        $joins[] = $userJoin;

        $columns = array (DiscussionsTable::COL_USER, DiscussionsTable::COL_TEXT,
                          DBTable::COL_CREATEDON, DBTable::COL_UPDATEDON, DBTable::COL_CREATEDBY,
                          DiscussionsTable::COL_TOPICID);
        $criteria = NULL;
        $params[] = OrderBy::create (DBTable::COL_CREATEDON, true);
        $rows = $this->dbtable->selectBy ($columns, $criteria, $joins, $params);
        if (empty ($rows))
            {
            $noDiscussion = $this->getText ("Discussion not started");
            return array ($noDiscussion => NULL);
            }

        $lng = Language::getInstance ($this->context);
        $userId = $this->context->getCurrentUser ();
        foreach ($rows as $row)
            {
            $entry = array ();
            $entry["text"] = $this->context->applyFormat ($row[DiscussionsTable::COL_TEXT], true);
            $user = "<span class=\"discussionuser\">".$this->escapeHtmlChars ($row[DiscussionsTable::COL_USER])."</span>";
            $date = strtotime ($row[DBTable::COL_CREATEDON]);
            $ageInSec = time () - $date;
            $entry["author"] = $user;
            if ($ageInSec < 60)
                $entry["date"] = $this->ngettext ("[_0] second ago", "[_0] seconds ago", $ageInSec);
            else if ($ageInSec < 60*60)
                $entry["date"] = $this->ngettext ("[_0] minute ago", "[_0] minutes ago", round ($ageInSec / 60));
            else if ($ageInSec < 60*60*24)
                $entry["date"] = $this->ngettext ("[_0] hour ago", "[_0] hours ago", round ($ageInSec / (60*60)));
            else if ($ageInSec < 60*60*24*7)
                $entry["date"] = $this->ngettext ("[_0] day ago", "[_0] days ago", round ($ageInSec / (60*60*24)));
            else if ($ageInSec < 60*60*24*50)
                $entry["date"] = $this->ngettext ("[_0] week ago", "[_0] weeks ago", round ($ageInSec / (60*60*24*7)));
            else if ($ageInSec < 60*60*24*360)
                $entry["date"] = $this->ngettext ("[_0] month ago", "[_0] months ago", round ($ageInSec / (60*60*24*30)));
            else
                $entry["date"] = $this->ngettext ("[_0] year ago", "[_0] years ago", round ($ageInSec / (60*60*24*365)));

            if ($userId > 0 && ($userId == $row[DBTable::COL_CREATEDBY] || $this->dbtable->canEdit ()))
                {
                // add edit url
                /*$newTopicUrl = $this->context->processUrl ("index.php?service=EditDiscussionItemPopup&action=new&sc=$this->scope&cid=$this->entryId", true);
                $entry["url"] = $this->getText ("(added by [_0] on [_1])", $user, $date);
                */
                }

            $topic = $this->escapeHtmlChars ($this->getText ("Topic: [_0]", $row[DiscussionTopicTable::COL_TITLE]));
            $topics[$topic][] = $entry;

            if (!array_key_exists ($topic, $this->topicLabelsToIds))
                $this->topicLabelsToIds[$topic] = $row[DiscussionsTable::COL_TOPICID];
            }

        return $topics;
        }

    public function getInitializeScript ($fieldId, $entriesContainer)
        {
        $newTopicUrl = $this->context->processUrl ("index.php?service=EditDiscussionItemPopup&action=new&sc=$this->scope&cid=$this->entryId", true);
        $newTopicLabel = $this->getText ("New Topic");
        $replyLabel = $this->getText ("Reply");
        $img = $this->context->getResourcePath ("img", "metro-note.png");
        $title = $this->getText ("New comment");
        return <<<EOT
comments_attach ('#$fieldId', '#$entriesContainer', '$newTopicUrl', '$newTopicLabel', '$replyLabel', '$title', '$img');
EOT;
        }

    public function getCountText ($items)
        {
        return $this->ngettext ("[_0] comment", "[_0] comments", count ($items));
        }

    public function getTopicReplyUrl ($title)
        {
        if (!array_key_exists ($title, $this->topicLabelsToIds))
            return NULL;

        $topicId = $this->topicLabelsToIds[$title];
        return $this->context->processUrl ("index.php?service=EditDiscussionItemPopup&action=reply&sc=$this->scope&cid=$this->entryId&tid=$topicId", true);
        }

    public function checkAccess ()
        {
        return $this->dbtable->canRead ();
        }
    }

<?php

class HintEditor extends InstanceEditor
    {
    protected $dbtable = NULL;
    protected $contextField;
    protected $titleColumn;
    protected $detailsColumn;
    protected $targetColumn;

    const COL_CONTEXT = "context";
    const CONTEXT_SCOPE = "scope";
    const CONTEXT_MODE = "mode";
    const CONTEXT_ENTRY = "id";
    const SEP = ":";

    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new HintsTable ($context);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        $this->initializeTemplateParts ($request);
        $arr = array ();
        if ($this->isCreating ())
            $arr[] = $this->contextField;
        array_push ($arr, $this->targetColumn,
                          $this->titleColumn,
                          $this->detailsColumn);
        return $arr;
        }

    public function processInput ($context, &$request)
        {
        if (!isset ($request[HintsTable::COL_TARGETAUDIENCE]) && !empty ($request["grp"]))
            $request[HintsTable::COL_TARGETAUDIENCE] = $request["grp"];
        if (!isset ($request[HintsTable::COL_CONTEXT]) && !empty ($request["sc"]) && !empty ($request["id"]))
            $request[HintsTable::COL_CONTEXT] = $this->createContextString ($request["sc"], $request["cmode"], $request["id"]);

        parent::processInput ($context, $request);
        }

    protected function createContextString ($scope, $contextMode = NULL, $id = NULL)
        {
        $parts = array ($scope);
        if (NULL !== $contextMode || !empty ($id))
            $parts[] = empty ($contextMode) ? HintsTable::CONTEXT_ANY : $contextMode;
        if (!empty ($id))
            $parts[] = $id;

        return implode (self::SEP, $parts);
        }

    protected function initializeTemplateParts ($request)
        {
        if (NULL != $this->contextField)
            return;

        $texts = $this->texts;
        $prefix = "g";

        if ($this->isCreating ())
            {
            $scope = !empty ($request["sc"]) ? $request["sc"] : NULL; 
            $contextMode = !empty ($request["cmode"]) ? $request["cmode"] : NULL; 
            $group = !empty ($request["grp"]) ? $request["grp"] : NULL; 
            $id = !empty ($request["eid"]) ? $request["eid"] : NULL; 

            $modeLabel = NULL;
            switch ($contextMode)
                {
                case HintsTable::CONTEXT_VIEW:
                    $modeLabel = $this->getText ("view");
                    break;
                case HintsTable::CONTEXT_PREVIEW:
                    $modeLabel = $this->getText ("list");
                    break;
                case HintsTable::CONTEXT_EDIT:
                    $modeLabel = $this->getText ("in edit mode");
                    break;
                case HintsTable::CONTEXT_HISTORY:
                    $modeLabel = $this->getText ("revision list");
                    break;
                case HintsTable::CONTEXT_DISCUSSION:
                    $modeLabel = $this->getText ("discussion");
                    break;
                }

            $availableContext = array ();
            if (HintsTable::SCOPE_PAGES == $scope)
                {
                $key = $this->createContextString ($scope);
                $availableContext[$key] = $this->getText ("Any page, any mode");
                if (HintsTable::CONTEXT_ANY != $contextMode)
                    {
                    $key = $this->createContextString ($scope, $contextMode);
                    $availableContext[$key] = $this->getText ("Any page [_0]", $modeLabel);
                    }

                $key = $this->createContextString ($scope, $contextMode, $id);
                $availableContext[$key] = $this->getText ("This page");
                }
            else
                {
    var_dump ($scope);
    var_dump ($contextMode);
    var_dump ($group);
    var_dump ($id);
                }

            $this->contextField = new DropDownFieldTemplate ($prefix, self::COL_CONTEXT,
                                                       _("Display context:"),
                                                       _("Context in which hint will be displayed."), $availableContext);
            }

        $this->titleColumn = new TextFieldTemplate ($prefix, HintsTable::COL_TITLE,
                                                    _("Hint title:"),
                                                    _("Short description of the hint."), 32);
        $this->detailsColumn = new LongTextFieldTemplate ($prefix, HintsTable::COL_DETAILS,
                                                   _("Hint text:"),
                                                   _("Full hint text."));

        $availableTargets = array (HintsTable::TARGET_ANY => $this->getText ("All users"),
                                   HintsTable::TARGET_VIEWER => $this->getText ("Readers"),
                                   HintsTable::TARGET_EDITOR => $this->getText ("Editors"));
        $this->targetColumn = new DropDownFieldTemplate ($prefix, HintsTable::COL_TARGETAUDIENCE,
                                        $this->getText ("Show for:"),
                                        $this->getText ("Users to show hint for."), $availableTargets);
        }

    public function getPageTitle ($isCreating = false)
        {
        return $isCreating
                    ? $this->getText ("Creating a new hint")
                    : $this->getText ("Editing a hint");
        }

    protected function createRecord ($request, $values)
        {
        $parts = explode (self::SEP, $values[self::COL_CONTEXT]);
        unset ($values[self::COL_CONTEXT]);
        if (0 == count ($parts))
            {
            $this->addError ("Incorrect arguments");
            return false;
            }
        if (1 == count ($parts))
            $parts[] = HintsTable::CONTEXT_ANY;

        $values[HintsTable::COL_SCOPE] = $parts[0];
        $values[HintsTable::COL_CONTEXT] = $parts[1];
        $values[HintsTable::COL_CONTEXTID] = count ($parts) > 2 ? $parts[2] : Constants::ANY;

        return parent::createRecord ($request, $values);
        }

    protected function showSuccessPage ($request)
        {
        $scope = !empty ($request["sc"]) ? $request["sc"] : NULL; 
        $contextMode = !empty ($request["cmode"]) ? $request["cmode"] : NULL; 
        $group = !empty ($request["grp"]) ? $request["grp"] : NULL; 
        $id = !empty ($request["id"]) ? $request["id"] : NULL; 

        $url = "index.php?c=HintList&sc=$scope&cmode=$contextMode&grp=$group&id=$id";
        $friendlyUrl = $url;
        $this->context->redirect ($this->context->chooseUrl ($friendlyUrl, $url));
        return false;
        }

    public function showCancel ()
        {
        return true;
        }

    }

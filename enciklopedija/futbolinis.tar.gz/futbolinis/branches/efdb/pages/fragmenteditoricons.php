<?php
require_once (PATH.'inc/urlicon.php');

class ChangeFragmentOrderIcon extends ChangeOrderIcon
    {
    public function __construct ($component, $up)
        {
        parent::__construct ($component, ($up ? "up" : "down"), $up);
        }

    public function execute ($request, $id)
        {
        $handler = new FragmentsTable ($this->context);
        $ret = $handler->changeOrder ($this->component->getParentFragmentId (), $id, $this->up);
        if (false === $ret)
            $this->component->log ("Error changing fragment order");
        else
            {
            $this->context->redirect ($this->context->getAdjustedUrl (array()));
            return false;
            }

        return true;
        }

    public function isVisible ($component = NULL)
        {
        return true;
        }

    }

class ShowFragmentIcon extends IconAction
    {
    protected $publish;

    public function __construct ($component, $publish)
        {
        $tooltip = $publish ? $component->getText ("Publish fragment") : $component->getText ("Hide fragment");
        parent::__construct ($component, $publish ? "publish" : "unpublish", $tooltip);
        $this->publish = $publish;
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function isVisible ($row = NULL)
        {
        return true;
        }

    public function requiresId ()
        {
        return true;
        }

    public function getKey ()
        {
        return $this->publish ? "publish" : "unpublish";
        }

    public function execute ($request, $id)
        {
        $handler = new FragmentsTable ($this->context);
        $ret = $handler->publishFragment ($id, $this->publish);
        if (false === $ret)
            $this->component->log ("Error changing fragment visibility");
        else
            {
            $this->component->setPublished ($this->publish);
            $this->publish = !$this->publish;
            $this->icon = $this->publish ? "publish" : "unpublish";
            }

        return true;
        }
    }

class WrapFragmentIcon extends IconAction
    {
    protected $publish;

    public function __construct ($component)
        {
        $tooltip = $component->getText ("Wrap fragment");
        parent::__construct ($component, "wrap", $tooltip);
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function isVisible ($row = NULL)
        {
        return true;
        }

    public function requiresId ()
        {
        return true;
        }

    public function getKey ()
        {
        return "wrap";
        }

    public function execute ($request, $id)
        {
        $handler = new FragmentsTable ($this->context);
        $ret = $handler->wrapFragment ($id);
        if (false === $ret)
            $this->component->log ("Error wrapping the fragment");
        else
            {
            $this->context->redirect ($this->context->getAdjustedUrl (array()));
            return false;
            }

        return true;
        }
    }

class DeleteFragmentIcon extends IconAction
    {
    protected $publish;

    public function __construct ($component)
        {
        $tooltip = $component->getText ("Delete fragment");
        parent::__construct ($component, "delete", $tooltip);
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function isVisible ($row = NULL)
        {
        return true;
        }

    public function requiresId ()
        {
        return true;
        }

    public function getKey ()
        {
        return "delete";
        }

    public function execute ($request, $id)
        {
        $handler = new FragmentsTable ($this->context);
        $idCriteria[] = new EqCriterion (FragmentsTable::COL_ID, $id);
        $ret = $handler->deleteById ($idCriteria);
        if (false === $ret)
            {
            $this->component->addError ("Error deleting the fragment");
            }
        else
            {
            $this->context->redirect ($this->context->getAdjustedUrl (array()));
            return false;
            }

        return true;
        }
    }

class AddFragmentIcon extends IconAction
    {
    protected $dir;
    const DIR_UP = "addup";
    const DIR_DOWN = "adddown";
    const DIR_RIGHT = "addright";

    public function __construct ($component, $direction)
        {
        switch ($direction)
            {
            case self::DIR_UP:
                $tooltip = $component->getText ("Add fragment above");
                break;
            case self::DIR_DOWN:
                $tooltip = $component->getText ("Add fragment below");
                break;
            case self::DIR_RIGHT:
                $tooltip = $component->getText ("Add fragment to the right");
                break;
            }

        parent::__construct ($component, $direction, $tooltip);
        $this->dir = $direction;
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function isVisible ($row = NULL)
        {
        return true;
        }

    public function requiresId ()
        {
        return true;
        }

    protected function createFragment ($parentId, $addToEnd)
        {
        $handler = new FragmentsTable ($this->context);
        $ret = $handler->addNewFragment ($parentId, $addToEnd);
        if (false === $ret)
            $this->component->log ("Error creating fragment");
        else
            {
            $this->context->redirect ($this->context->getAdjustedUrl (array()));
            return false;
            }

        return true;
        }

    public function execute ($request, $id)
        {
        return $this->createFragment ($this->component->getParentFragmentId (), self::DIR_DOWN == $this->dir);
        }
    }

class AddFragmentIntoNewGroupIcon extends AddFragmentIcon
    {
    public function execute ($request, $id)
        {
        $handler = new FragmentsTable ($this->context);
        $parentId = $handler->createGroup ($id);
        if ($parentId <= 0)
            $this->component->log ("Error creating fragment");
        else
            return $this->createFragment ($parentId, self::DIR_DOWN == $this->dir);

        return true;
        }
    }

class EditFragmentIcon extends IconAction
    {
    public function __construct ($component)
        {
        $tooltip = $component->getText ("Edit the fragment");
        parent::__construct ($component, "edit", $tooltip);
        }

    public function canExecute ($request, $singleItemId = NULL)
        {
        return true;
        }

    public function isVisible ($row = NULL)
        {
        return true;
        }

    public function requiresId ()
        {
        return true;
        }

    public function execute ($request, $id)
        {
        $this->component->toggleEditMode ($id);
        return true;
        }
    }

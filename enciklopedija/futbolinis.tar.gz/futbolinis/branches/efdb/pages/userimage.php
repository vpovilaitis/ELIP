<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'inc/imagestable.php');

class UserImage extends Page
    {
    public function __construct ($context, $request)
        {
        parent::__construct ($context, NULL, ImagesTable::TABLE_SCOPE, ImagesTable::TABLE_NAME);
        }

    public function ensureTitle ($context, &$request)
        {
        return true;
        }

    protected function checkAccess ($request)
        {
        $dbtable = new ImagesTable ($this->context);
        return $dbtable->canRead ();
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    protected function getTemplateName ()
        {
        return "";
        }

    protected function renderComponent ($context, $request)
        {
        $filePath = NULL;
        $image = false;
        $dbtable = new ImagesTable ($this->context);
        $width = !empty ($request ["w"]) ? $request ["w"] : 0;
        $height = !empty ($request ["h"]) ? $request ["h"] : 0;

        if (array_key_exists ("id", $request))
            {
            $id = $request["id"];
            $fileName = false;

            if ($id > 0)
                {
                $columns = array (ImagesTable::COL_FILENAME, DBTable::COL_CREATEDON);
                $criteria[] = new EqCriterion (ImagesTable::COL_ID, $id);
                $row = $dbtable->selectSingleBy ($columns, $criteria);
                if (!empty ($row))
                    {
                    $fileName = $row[ImagesTable::COL_FILENAME];
                    header ("Last-Modified: " . gmdate("D, d M Y H:i:s", strtotime($row[DBTable::COL_CREATEDON])) . " GMT");
                    }
                }
            else
                $fileName = "noimage.png";

            if (false !== $fileName)
                {
                if (!empty ($width) || !empty ($height))
                    {
                    $filePath = $dbtable->resizeImage ($fileName, $width, $height, !empty ($_REQUEST["_purge"]));
                    }
                else
                    $filePath = USER_UPLOAD_DIR."/".$fileName;
                }
            }

        $image = new Image ();
        $error = !$image->readFile ($context, $filePath);
        if (!$error)
            {
            $mimeType = $image->getMimeType ($context);
            }

        if ($error)
            {
            $mimeType = "image/png";
            $cachedErrorImagePath = "error.png";
            if ($width > 0 || $height > 0)
                $filePath = $dbtable->resizeImage ($cachedErrorImagePath, $width, $height, !empty ($_REQUEST["_purge"]));
            else
                $filePath = USER_UPLOAD_DIR."/error.png";
            }

        $newFileName = pathinfo ($filePath, PATHINFO_BASENAME);

        if (empty ($_REQUEST["noheaders"]))
            {
            header("Content-type: $mimeType");
            header('Content-Description: Image Transfer');
            header('Content-Transfer-Encoding: binary');
            header("Content-Disposition: inline; filename=$newFileName");
            // control content expiration
            $offset = 60 * 60 * 24 * 90; // 3 months
            header ("Expires: " . gmdate("D, d M Y H:i:s", time() + $offset) . " GMT");
            header ("Cache-Control: maxage=$offset");
            header ("Pragma: private");
            }

        // send file
        $image->outputImage ($context, $filePath);
        }

    }

<?php

require_once (PATH.'inc/page.php');

class BadSetup extends ReaderPage
    {
    public function __construct ($context)
        {
        parent::__construct ($context, _("Under construction"), Constants::TABLES_USER);
        }

    public function getTemplateName ()
        {
        return "badsetup";
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    protected function checkAccess ($request)
        {
        // no access is required to see an error
        return true;
        }
    }

?>

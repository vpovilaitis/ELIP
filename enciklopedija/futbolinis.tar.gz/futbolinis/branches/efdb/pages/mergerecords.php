<?php
require_once (PATH.'pages/submit.php');
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'inc/relationfields.php');

abstract class MergeRecords extends Submit
    {
    protected $conflictFields = array ();

    public function __construct ($context, $request, $tableName)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, "persons");

        if (empty ($this->dbtable))
            {
            $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            $this->allTablesLoaded = false;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        $context->addScriptFile ("autosuggest");
        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ($this->getText ("Merge duplicate [_0] entries", !empty ($this->dbtable) ? $this->dbtable->getTableName () : "?"));
        return true;
        }

    public function collectInputData ($context, &$request)
        {
        if (empty ($request["src"]) || empty ($request["target"]))
            return array ();
        $this->source = $this->sourcesField->getValueForDB ($context, $request);
        $this->sourceDate = $this->sourcesDateField->getValueForDB ($context, $request);
        return $request;
        }
        
    public function validateInput ($context, &$input)
        {
        if (empty ($input))
            return $this->logError ("Please enter the primary and duplicate record.");

        $sourceId = $input["src"];
        $targetId = $input["target"];
        $columns = array ();
        $includedColumns = array ();
        foreach ($this->dbtable->selectDisplayableColumns () as $column)
            {
            if (!$this->isColumnIncluded ($column))
                continue;

            $includedColumns[] = $column;
            $columns[] = $column->name;
            }

        $source = $this->dbtable->selectSingleBy ($columns, array (new EqCriterion ($this->dbtable->getIdColumn (), $sourceId)));
        $target = $this->dbtable->selectSingleBy ($columns, array (new EqCriterion ($this->dbtable->getIdColumn (), $targetId)));

        if (empty ($source) || empty ($target))
            return $this->logError ("Primary or duplicate record was not found.");

        $overwrite = array ();
        foreach ($includedColumns as $column)
            {
            $idx = $column->name;
            if ($column instanceof ValueColumn)
                $idx = $column->columnDef->name;

            // skip empty or identical values
            if (NULL === $source[$idx] || $source[$idx] === $target[$idx])
                continue;

            if (NULL === $target[$idx])
                {
                $overwrite[$idx] = $source[$idx];
                }
            else
                {
                $options = array (0 => $this->getText ("Leave as is ([_0])", $target[$idx]),
                                  1 => $this->getText ("Overwrite ([_0])", $source[$idx])
                                  );
                $key = "cfl_$sourceId".$this->encodeKey ($idx);
                $this->conflictFields[] = new DropDownFieldTemplate ("", $key, $column->label, $column->description, $options);
                if (!empty ($input[$key]))
                    $overwrite[$idx] = $source[$idx];
                }
            }

        $input["overwrite"] = $overwrite;

        return true;
        }

    protected function isColumnIncluded ($column)
        {
        if (ContentTable::COL_SOURCE == $column->name || ContentTable::COL_SOURCEDATE == $column->name)
            return false;
        if ($column instanceof ValueColumn && $column->columnDef instanceof CompositeColumn)
            return false;
        return true;
        }

    public function saveInput ($context, &$request, &$input)
        {
        $sourceId = $input["src"];
        $targetId = $input["target"];

        $this->writeLine ("<pre>");

        $relatedtables = $this->dbtable->getRelatedTables ();
        if (!empty ($relatedtables))
            {
            foreach ($relatedtables as $pair)
                {
                list ($table, $columns) = $pair;
                
                $criteria = array ();
                foreach ($columns as $col)
                    {
                    $criteria = array (new EqCriterion ($col->name, $sourceId));
                    $nameToValue = array ($col->name => $targetId);
                    $nameToValue[DBTable::COL_SOURCE] = $this->source;
                    $nameToValue[DBTable::COL_SOURCEDATE] = $this->sourceDate;
                    $affected = $this->moveRelatedColumnData ($input, $table, $col, $criteria, $nameToValue);
                    if (false === $affected)
                        {
                        $this->writeLine ($this->getText ("Error updating [_0]:[_1] related records", $table->getName (), $col->name));
                        return false;
                        }
                    else
                        $this->writeLine ($this->ngettext ("Updated [_0] record ([_1]:[_2])", "Updated [_0] records ([_1]:[_2])", 
                                              $affected, $table->getName (), $col->name));
                    $this->writeLine ("\n");
                    }
                }
            }

        if (!empty ($input["overwrite"]))
            {
            $criteria = array (new EqCriterion ($this->dbtable->getIdColumn (), $targetId));
            $affected = $this->dbtable->updateRecord ($criteria, $input["overwrite"], 1);
            if (false === $affected)
                $this->writeLine ($this->getText ("Error merging the record"));
            else
                $this->writeLine ($this->ngettext ("Merged [_0] field value", "Merged [_0] field values", 
                                      count ($input["overwrite"])));
            $this->writeLine ("\n");
            }

        $delete = !empty ($input["delete"]);
        if ($delete)
            {
            $criteria = array (new EqCriterion ($this->dbtable->getIdColumn (), $sourceId));
            $affected = $this->dbtable->deleteById ($criteria);
            if (false === $affected)
                $this->writeLine ($this->getText ("Error deleting the record"));
            else
                $this->writeLine ($this->getText ("Deleted the duplicate record"));
            $this->writeLine ("\n");
            }

        $this->writeLine ("</pre>");
        }

    protected function moveRelatedColumnData ($input, $table, $column, $criteria, $nameToValue)
        {
        return $table->updateRecord ($criteria, $nameToValue, NULL);
        }

    abstract protected function getTemplateRecordField ();
    
    public function getFields ()
        {
        if (empty ($this->dbtable))
            return NULL;
            
        $this->createSourceFields ();

        $templateColumn = $this->getTemplateRecordField ();

        $sourcePersonColumn = clone $templateColumn;
        $sourcePersonColumn->label = $this->getText ("Duplicate entry:");
        $sourcePersonColumn->name = "src";

        $targetPersonColumn = clone $templateColumn;
        $targetPersonColumn->label = $this->getText ("Primary entry:");
        $targetPersonColumn->name = "target";
        
        $arr = array
            (
            new LabelTemplate ($this->getText ('Enter the primary record and the duplicate entry to merge into the primary'), "", true),
            RelationDropDownFieldTemplate::createInstance ($this->context, "", $sourcePersonColumn),
            RelationDropDownFieldTemplate::createInstance ($this->context, "", $targetPersonColumn),
            );

        if ($this->dbtable->canDelete () || $this->dbtable->ownerCanDelete ())
            $arr[] = new CheckBoxFieldTemplate ("", "delete", $this->getText ("Delete after merge:"), $this->getText ("Remove duplicate entry after the merge is complete"));

        $additional = $this->getAdditionalFields ();
        if (!empty ($additional))
            $arr = array_merge ($arr, $additional);
        if (!empty ($this->fields))
            $arr = array_merge ($arr, array_values ($this->fields));
            
        if (!empty ($this->conflictFields))
            {
            $arr[] = new LabelTemplate ($this->getText ('Values in one or more fields conflict. Please resolve.'), "", true);
            $arr = array_merge ($arr, $this->conflictFields);
            }

        $arr[] = $this->sourcesField;
        $arr[] = $this->sourcesDateField;
        return $arr;
        }
    }

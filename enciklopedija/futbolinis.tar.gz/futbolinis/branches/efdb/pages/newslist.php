<?php

require_once (PATH.'inc/labelfieldtemplate.php');

class NewsList extends Preview
    {
    public function __construct ($context)
        {
        $scope = !empty ($_REQUEST["sp"]) ? $_REQUEST["sp"] : false;
        parent::__construct ("nlist", $context, new NewsTable ($context, $scope));
        $this->defaultPageSize = DEFAULT_PAGESIZE * 2;
        }

    protected function getDisplayTemplate ()
        {
        $list = array
            (
            new NewsTitleTemplate ("col", NewsTable::COL_TITLE, $this->context->getText ('Title')),
            new NewEntryDateTemplate ("col", NewsTable::RESULTCOL_DATE, $this->context->getText ('Date')),
            );
        if ($this->dbtable->canEdit ())
            $list[] = new LabelBoolFieldTemplate ("col", NewsTable::COL_HIDDEN, $this->context->getText ('Hidden'));
        return $list;
        }

    public function getTitle ()
        {
        return $this->getText ("News archive");
        }

    public function getIcon ()
        {
        return NULL;
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if (empty ($editorLink))
            $editorLink = "pages/NewsEditor";
        if (empty ($title))
            $title = $new ? $this->getText ("Add news item") : $this->getText ("Modify news item");
        return parent::getEditorAction ($new, $title, $editorLink, $params);
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        $params[] = OrderBy::createByAlias (NewsTable::RESULTCOL_DATE, false);
        }

    public function getTemplateName ()
        {
        return "news";
        }

    public function getUniqueId ()
        {
        return "";
        }

    public function getDescriptor ()
        {
        if (empty ($this->desc))
            $this->desc = new NewsLinkDescriptor ($this->context, $this->dbtable, $this->getUniqueId ());
        return $this->desc;
        }
    }

class NewEntryDateTemplate extends LabelDateFieldTemplate
    {
    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        $resultColumns[] = new ConditionalResultColumn ($this->key, NewsTable::COL_ENTRY_DATE." IS NULL", DBTable::COL_CREATEDON, NewsTable::COL_ENTRY_DATE);
        }
    }

class NewsTitleTemplate extends LabelFieldTemplate
    {
    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        $resultColumns[] = NewsTable::COL_ID;
        }

    public function getUri ($context, $row)
        {
        $scope = !empty ($_REQUEST["sp"]) ? $_REQUEST["sp"] : false;
        $dbtable = new NewsTable ($context, $scope);
        return NewsLinkDescriptor::getItemLink ($dbtable, $row);
        }

    }

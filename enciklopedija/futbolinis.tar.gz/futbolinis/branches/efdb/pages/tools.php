<?php
require_once (PATH.'pages/simpletext.php');

class Tools extends ReaderPage
    {
    protected $title;

    public function __construct ($context, $request)
        {
        $this->title = $context->getText ("Various utilities");
        parent::__construct ($context, $this->title, Constants::TABLES_USER);
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ($this->title);
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "simplepage";
        }

    public function ensureChildren ($context, $request)
        {
        if (!empty ($this->component))
            return true;

        $parts = ComponentFactory::getRegisteredTools ($context);
        $i = 0;
        foreach ($parts as $title => $urlList)
            {
            $list = array ();
            foreach ($urlList as $url)
                $list[] = "* $url";
            $this->component = new SimpleText ($context, "p".(++$i), NULL, $title,
                                               implode ("\n", $list));
            $this->addComponent ($request, "p$i", $this->component);
            }

        return true;
        }
    }

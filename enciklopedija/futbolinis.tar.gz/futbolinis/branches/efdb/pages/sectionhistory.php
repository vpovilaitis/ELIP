<?php

require_once (PATH.'pages/contenthistory.php');

class SectionHistory extends ContentHistory
    {
    public function getDescription ()
        {
        if (!$this->dbtable)
            return $this->_("History");
        return $this->dbtable->getDescription();
        }

    public function getSearchFields ()
        {
        if (empty ($this->dbtable) || empty ($this->id))
            return NULL;

        $id = $this->id;
        if (is_array ($id))
            $id = implode ("_", $id);

        $url = $this->dbtable->getContainerLink ($id);
        $label = $this->getText ("Back to page"); 
        return array (new SingleRowURL ($this, "back", $label, $url));
        }

    }


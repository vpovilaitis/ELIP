<?php

class ImageGalery extends ReaderPage
    {
    protected $targetTable = NULL;
    protected $entryScope;
    protected $entryId;
    const MIN_HEIGHT = 100;

    public function __construct ($context)
        {
        parent::__construct ($context, "@", ImagesTable::TABLE_SCOPE, ImagesTable::TABLE_NAME);
        }

    public function ensureTitle ($context, &$request)
        {
        return $this->context->setTitle ($this->getText ("Image galery"));
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "imagegalery";
        }

    public function selectImages ($context, $height, $highlightedHeight)
        {
        $highlightedImage = !empty ($context->request["highlight"]) ? $context->request["highlight"] : "";
       
        $imagesTable = new ImagesTable ($this->context);
        $imageUseTable = new ImageUseTable ($this->context);
        $licenseTable = new ImageLicenseTable ($this->context);
        
        $columns = array (new Column (ImageLicenseTable::COL_NAME, "licname"), new Column (ImageLicenseTable::COL_DESCRIPTION, "licdescr"));
        $criteria[] = new JoinColumnsCriterion (ImagesTable::COL_LICENSE_ID, ImageLicenseTable::COL_ID);
        $licensesJoin = $licenseTable->createQuery ($columns, $criteria);
        
        $columns = array (ImagesTable::COL_WIDTH, ImagesTable::COL_HEIGHT, ImagesTable::COL_DESCRIPTION, ImagesTable::COL_AUTHOR, DBTable::COL_UPDATEDON);
        $criteria = array (new JoinColumnsCriterion (ImageUseTable::COL_IMAGEID, ImagesTable::COL_ID));
        $imagesJoin = $imagesTable->createQuery ($columns, $criteria, array ($licensesJoin));

        $columns = array (ImageUseTable::COL_IMAGEID, ImageUseTable::COL_TITLE, ImageUseTable::COL_ZONE);
        $criteria = array ();
        $criteria[] = new EqCriterion (ImageUseTable::COL_SCOPE, $this->entryScope);
        $criteria[] = new EqCriterion (ImageUseTable::COL_CONTEXTID, $this->entryId);
        $rows = $imageUseTable->selectBy ($columns, $criteria, array ($imagesJoin));

        if (empty ($rows))
            $rows = array (array (ImageUseTable::COL_IMAGEID => 0, ImageUseTable::COL_TITLE => $this->getText ("No images"),
                           ImagesTable::COL_WIDTH => 0, ImagesTable::COL_HEIGHT => $height,
                           ImagesTable::COL_DESCRIPTION => NULL));

        $imageList = array ();
        if (1 == count ($rows))
            $imageList[] = $this->createImageInformation ($rows[0], $this->entryScope, $this->entryId, $highlightedHeight, true);
        else
            {
            foreach ($rows as $row)
                {
                $imageList[] = $this->createImageInformation ($row, $this->entryScope, $this->entryId, $height, false);
                if ($highlightedImage == $row[ImageUseTable::COL_IMAGEID])
                    $imageList[] = $this->createImageInformation ($row, $this->entryScope, $this->entryId, $highlightedHeight, true);
                }
            }

        usort ($imageList, array ($this, "compare"));
        return $imageList;
        }
    
    protected function createImageInformation ($row, $scope, $id, $height, $highlight)
        {
        $imageId = $row[ImageUseTable::COL_IMAGEID];
        $title = $row[ImageUseTable::COL_TITLE];

        if ($highlight && $row[ImagesTable::COL_HEIGHT] < $height)
            {
            $height = $row[ImagesTable::COL_HEIGHT];
            if ($height < self::MIN_HEIGHT)
                $height = self::MIN_HEIGHT;
            }

        $imgHeight = $height;
        $width = round ($row[ImagesTable::COL_WIDTH] * $imgHeight / $row[ImagesTable::COL_HEIGHT]);

        $timestamp = strtotime ($row[DBTable::COL_UPDATEDON]);
        $url = $this->context->chooseUrl ("image/$imageId/{$width}x{$imgHeight}t{$timestamp}",
                                          "index.php?c=UserImage&id=$imageId&w=$width&h=$imgHeight&t=$timestamp");
        if ($imageId > 0)
            $galeryUrl = $this->context->chooseUrl ("galery/$scope/$id/$imageId",
                                                    "index.php?c=ImageGalery&sc=$scope&id=$id&highlight=$imageId");
        else
            $galeryUrl = NULL;

        $descr = array ("url" => $url, "width" => $width, "height" => $imgHeight, "title" => $title, "galeryUrl" => $galeryUrl);

        if ($highlight)
            {
            $imagesTable = new ImagesTable ($this->context);
            $imageUseTable = new ImageUseTable ($this->context);
            $this->alterImageContext ($imagesTable, $imageUseTable, $scope, $id, $row[ImageUseTable::COL_ZONE], $imageId, $descr, false);
            }

        $descr["highlight"] = $highlight;
        if ($highlight)
            {
            $descr["description"] = $row[ImagesTable::COL_DESCRIPTION];
            if (!empty ($row[ImagesTable::COL_AUTHOR]))
                {
                if (preg_match ("@^http://(.+)/@U", $row[ImagesTable::COL_AUTHOR], $matches))
                    $descr["author"] = $this->getText ("Source: <a href=\"[_0]\">[_1]</a>|image", $row[ImagesTable::COL_AUTHOR], $matches[1]);
                else
                    $descr["author"] = $this->getText ("Created by: [_0]|image", $row[ImagesTable::COL_AUTHOR]);
                }
            }

        $descr["license"] = $row["licname"];
        $descr["licenseTitle"] = $row["licdescr"];
        return $descr;
        }

    public function ensureChildren ($context, $request)
        {
        if (NULL === $this->targetTable)
            {
            if (empty ($request["sc"]) || empty ($request["id"]))
                {
                $this->addError ("Invalid parameters provided");
                return true;
                }
    
            $this->entryScope = $request["sc"];
            switch ($request["sc"])
                {
                case NewsTable::TABLE_NAME:
                    $this->targetTable = new NewsTable ($context);
                    break;
                default:
                    if ("_" == $request["sc"][1])
                        $this->targetTable = ContentTable::createInstanceByName ($context, substr ($request["sc"], 2));
                    break;
                }
    
            if (empty ($this->targetTable))
                {
                $this->addError ("Invalid parameters provided");
                return false;
                }

            $this->entryId = $request["id"];
            }

        return parent::ensureChildren ($context, $request);
        }

    protected function compare ($a, $b)
        {
        if ($a["highlight"] != $b["highlight"])
            return $b["highlight"] - $a["highlight"];
        return strcasecmp ($a[ImageUseTable::COL_TITLE], $b[ImageUseTable::COL_TITLE]);
        }

    public function getActionList ()
        {
        if (empty ($this->targetTable) || empty ($this->entryId))
            return NULL;

        $url = $this->targetTable->getContentLink ($this->entryId);
        $label = $this->getText ("Back to [_0]", $this->targetTable->getDisplayNameById ($this->entryId));

        if (empty ($label))
            $label = $this->getText ("Back to subject");

        $actions[] = new SimpleLinkAction ($this, "back", $label, $url, true);

        $rssUrl = $this->context->chooseUrl ("feed/ImagesFeed", "index.php?c=Rss&ch=ImagesFeed");
        $rssLink = new SimpleLinkAction ($this, "rss", $this->getText ("RSS"), $rssUrl, true);
        $rssLink->icon = "rss";
        $actions[] = $rssLink;
        return $actions;
        }
    }

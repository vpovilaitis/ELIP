<?php
require_once (PATH.'h/facebookservice.php');

class SearchResults extends ReaderPage
    {
    public function __construct ($context)
        {
        parent::__construct ($context, "", Constants::TABLES_USER);
        $context->addScriptFile ("autosuggest");
        $this->prefix = "searchField";
        $context->registerInitializeScript ($this->getInitializeScript ($context, $this->prefix));
        }

    public function getTemplateName ()
        {
        return "pages/searchresults";
        }

    public function getInitializeScript ($context, $id)
        {
        $url = $context->processUrl ("index.php?service=FullTextSearch", true);
        return "suggest_attachSearchField ('$id', '$url');";
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ($this->getText ("Search results"));
        }

    public function getNoResultsText ()
        {
        $searchString = $this->getSearchString ();
        if (empty ($searchString))
            return NULL;

        return $this->getText ("Your query '[_0]' did not match any entries", "<b>$searchString</b>");
        }

    public function executeSearch ()
        {
        $searchString = $this->getSearchString ();
        if (empty ($searchString))
            return NULL;

        $results = ExtractedContentTable::executeSearch ($this->context, $searchString);
        if (empty ($results))
            return NULL;

        foreach ($results as &$row)
            {
            if (0 == strncmp (HintsTable::SCOPE_CONTENTTABLE, $row[ExtractedContentTable::COL_SCOPE], 2))
                {
                $tableName = substr ($row[ExtractedContentTable::COL_SCOPE], strlen (HintsTable::SCOPE_CONTENTTABLE));
                $dbtable = ContentTable::createInstanceByName ($this->context, $tableName);
                $url = LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $dbtable,
                                                                             $dbtable->getId (),
                                                                             $row[ExtractedContentTable::COL_ENTRYID]);
                $row['url'] = $url;

                if (empty ($row[ExtractedContentTable::COL_IMAGEID]))
                    {
                    $image = $this->context->getResourcePath ("img", "metro-$tableName.png");
                    if (empty ($image))
                        $image = $this->context->getResourcePath ("img", "metro-history.png");
                    $row['image'] = $image;
                    }
                else
                    {
                    $imageId = $row[ExtractedContentTable::COL_IMAGEID];
                    $size = 64;
                    $row['image'] = $this->context->chooseUrl ("image/$imageId/{$size}x{$size}",
                                                         "index.php?c=UserImage&id=$imageId&w=$size&h=$size");
                    }
                }
            }

        return $results;
        }

    public function getSearchString ()
        {
        return empty ($this->request["s"]) ? NULL : $this->request["s"];
        }
    public function getDisplayType ()
        {
        return "search-normal";
        }
    public function getIcon ()
        {
        return NULL;
        }
    public function getTitle ()
        {
        return NULL;
        }
    public function getSearchLabel ()
        {
        return $this->getText ("Go");
        }
    public function getSearchUrl ()
        {
        return $this->context->processUrl ("search.php", true);
        }
    }

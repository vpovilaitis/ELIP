<?php
require_once (PATH.'pages/componentfragment.php');
require_once (PATH.'pages/discussions.php');

class DiscussionsFragment extends ComponentFragment
    {
    protected function createComponent ($context, $prefix, $additionalParams)
        {
        $context->getPageScope ($scope, $id);
        return new DiscussionsComponent ($context, $scope, $id);
        }
    }


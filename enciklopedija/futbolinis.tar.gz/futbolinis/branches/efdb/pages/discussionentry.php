<?php

class EditDiscussionComponent extends InstanceEditor
    {
    protected $nameColumn;
    protected $topicColumn;
    protected $textColumn;
    protected $targetTable;
    protected $scope;
    protected $entryId;
    protected $entryLabel = 0;

    public function __construct ($prefix, $context, $targetTable, $entryId)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new DiscussionsTable ($context);
        $this->targetTable = $targetTable;
        if (!empty ($targetTable))
            $this->scope = $targetTable->getTableName ();
        $this->entryId = $entryId;
        $context->addScriptFile ("common");
        }

    public function setMode ($creating, $id)
        {
        // always create (later it will be possible to edit own discussions)
        parent::setMode (true, NULL);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        $this->initializeTemplateParts ($request);
        return array
            (
            $this->topicColumn,
            $this->nameColumn,
            $this->textColumn,
            );
        }

    protected function initializeTemplateParts ($request)
        {
        if (NULL != $this->nameColumn)
            return;

        $prefix = "g";

        $this->topicColumn = new TextFieldTemplate ($prefix, DiscussionTopicTable::COL_TITLE, _("Topic:"), _("If entering a reply, choose a topic."), 64, 256);
        $this->nameColumn = new UserNameField ($this->context, $prefix);
        $this->textColumn = new LongTextFieldTemplate ($prefix, DiscussionsTable::COL_TEXT, _("Text:"), _("Please describe a topic or enter a reply."));
        }

    protected function createRecord (&$request, $values)
        {
        $this->initializeTemplateParts ($request);
        $topic = trim ($values[$this->topicColumn->key]);
        $name = trim ($values[$this->nameColumn->key]);
        $text = trim ($values[$this->textColumn->key]);
        if (empty ($topic) || empty ($name) || empty ($text) ||
            (defined ("BLACLIST_FILTER") && (preg_match (BLACLIST_FILTER, $topic, $matches) > 0 || preg_match (BLACLIST_FILTER, $text, $matches) > 0)))
            {
            $this->addError ("Please enter a valid topic name, your nickname and the discussion text.");
            return false;
            }

        $topicsTable = new DiscussionTopicTable ($this->context);

        $columns = array (DiscussionTopicTable::COL_ID);
        $criteria = NULL;
        $criteria[] = new EqCriterion (DiscussionTopicTable::COL_SCOPE, $this->scope);
        $criteria[] = new EqCriterion (DiscussionTopicTable::COL_CONTEXTID, $this->entryId);
        $criteria[] = new EqCriterion (DiscussionTopicTable::COL_TITLE, $topic);
        $rows = $topicsTable->selectBy (array (DiscussionTopicTable::COL_ID), $criteria);

        if (!empty ($rows))
            $topicId = $rows[0][DiscussionTopicTable::COL_ID];
        else
            $topicId = $topicsTable->create ($this->scope, $this->entryId, $topic);

        if (false === $topicId)
            {
            $this->addError ("Error creating a new topic");
            return false;
            }

        $id = $this->dbtable->create ($topicId, $name, $text);
        if (false === $id)
            {
            $this->addError ("Error writing a new entry");
            return false;
            }

        unset ($request[$this->textColumn->key]);
        return true;
        }

    public function getEntryLabel ()
        {
        if (0 === $this->entryLabel && !empty ($this->targetTable))
            {
            $id = $this->entryId;
            if (!is_numeric ($id))
                $id = explode ("_", $id);

            $this->entryLabel = $this->targetTable->getDisplayNameById ($id);
            }
        return $this->entryLabel;
        }

    public function getPageTitle ()
        {
        $label = $this->getEntryLabel ();
        if (empty ($label) && !empty ($this->targetTable))
            return $this->getText ("Discussions ([_0])", $this->targetTable->getDescription ());
        return $this->getText ("Discussion of the page \"[_0]\"", $label);
        }

    public function getEntryTitle ()
        {
        return $this->getText ("Enter your comments, suggestions, questions");
        }

    protected function showSuccessPage ($request)
        {
        return true;
        }

    public function isVisible ()
        {
        if (empty ($this->targetTable))
            return false;
        return $this->checkAccess ($this->request);
        }


    public function getEditorTemplateName ()
        {
        return parent::getTemplateName ();
        }

    public function getTemplateName ()
        {
        return "discussionentry";
        }
    }

class UserNameField extends TextFieldTemplate
    {
    public function __construct ($context, $prefix)
        {
        parent::__construct ($prefix, DiscussionsTable::COL_USER, _("Your name:"), _("Please enter your name or a nickname."), 64);
        $this->initialValue = $context->getCurrentUserName ();
        }
    }

<?php
require_once (PATH.'pages/componentfragment.php');
require_once (PATH.'pages/discussions.php');

class CustomFragment extends ComponentFragment
    {
    const PARAM_TEMPLATE = "template";

    protected function getAdditionalEditorFields ()
        {
        $arr = parent::getAdditionalEditorFields ();
        $arr[] = new FieldTemplate ("fld1", self::PARAM_TEMPLATE, "text",
                                    $this->getText ("Template"), $this->getText ("Template path"));

        return $arr;
        }

    protected function createComponent ($context, $prefix, $additionalParams)
        {
        if (empty ($additionalParams[self::PARAM_TEMPLATE]))
            return NULL;
        return new CustomTemplate ($prefix, $context, $additionalParams[self::PARAM_TEMPLATE]);
        }
    }

class CustomTemplate extends Component
    {
    protected $templatename;

    public function __construct ($prefix, $context, $templatename)
        {
        parent::__construct ($prefix, $context);
        $this->templatename = $templatename;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getTemplateName ()
        {
        return $this->templatename;
        }
    }

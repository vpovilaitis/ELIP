<?php

require_once (PATH.'inc/page.php');

class Rss extends ReaderPage
    {
    protected $errCount = 1;
    protected $channel;

    public function __construct ($context)
        {
        parent::__construct ($context, _("Rss feed"), Constants::TABLES_USER);
        $context->setErrorTarget ($this);
        }

    public function getTemplateName ()
        {
        return "rss";
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function ensureTitle ($context, &$request)
        {
        $this->ensureChildren ($context, $request);
        $this->context->setTitle ($this->getChannelTitle (false));
        return true;
        }

    protected function setContentType ($request)
        {
        header ('Content-type: application/xml; charset=utf-8');
        }

    protected function getDisplayParams ($request)
        {
        $this->setContentType ($request);

        return parent::getDisplayParams ($request);
        }

    public function getChannelProperties ()
        {
        $ret = array
            (
            "title" => htmlspecialchars ($this->getChannelTitle ()),
            "link" => htmlspecialchars ($this->getChannelUrl ()),
            "description" => $this->context->getValue (SiteSettings::SITE_DESCRIPTION),
            "language" => $this->context->getLanguage (),
            // "copyright" => "(c) ...",
            "managingEditor" => $this->getChannelCreator (),
            "webMaster" => $this->getChannelCreator (),
            // "lastBuildDate" => date("r", time()),
            "generator" => "Futbolinis",
            );
        return $ret;
        }

    protected function getChannelTitle ($full = true)
        {
        if (empty ($this->channel))
            return _("Rss feed");

        $title = $this->channel->getTitle ();
        if (!$full)
            return $title;

        $siteTitle = $this->context->getValue (SiteSettings::SITE_TITLE);

        if (!empty ($title))
            {
            if (!empty ($siteTitle))
                $title = $this->context->getText ("[_0] - [_1]", $siteTitle, $title);
            }
        else
            $title = $this->context->getValue (SiteSettings::SITE_TITLE);

        return $title;
        }

    protected function getChannelUrl ()
        {
        $url = BASE_URL;
        if (!empty ($url))
            return $url;
        return $this->context->processUrl ("http://".$_SERVER["HTTP_HOST"]."/index.php?c=Feed&ch=".$this->context->request["ch"]);
        }

    protected function getChannelCreator ()
        {
        $author = $this->context->getValue (SiteSettings::SITE_AUTHOR);
        $authorEmail = $this->context->getValue (SiteSettings::SITE_AUTHOR_EMAIL);
        if (empty ($authorEmail))
            return $author;

        return "$authorEmail ($author)";
        }

    public function getErrorProperties ($error)
        {
        $url = BASE_URL;
        if (!empty ($url))
            $url .= "/Error";
        else
            $url = "http://".$_SERVER["HTTP_HOST"]."/index.php?c=Error";

        return array
            (
            "title" => $this->getText ("Error"),
            "description" => $error,
            "pubDate" => date("r", time()),
            "guid" => "$url#item".($this->errCount++),
            );
        }

    protected function preprocessItem (&$item)
        {
        $item["title"] = htmlspecialchars ($item["title"]);
        $item["description"] = htmlspecialchars ($item["description"]);
        }

    public function getItems ()
        {
        if (empty ($this->channel))
            return NULL;

        $items = $this->channel->getItems ();
        if (empty ($items))
            return $items;
        foreach ($items as &$item)
            {
            $this->preprocessItem ($item);
            }

        return $items;
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if (!empty ($this->channel))
            return true;

        $perspective = isset ($context->request["sp"]) ? $context->request["sp"] : NULL;
        $class = isset ($context->request["ch"]) ? $context->request["ch"] : NULL;

        if (empty ($class))
            {
            $this->addError ($this->getText ("Feed channel not found"));
            return true;
            }

        $class = $context->parseCustomClass ($class, "h/rss");
        if (!empty ($class))
            {
            if ($perspective)
                $this->context->setPerspective ($perspective);

            $this->channel = new $class ($context, $request);
            }

        if (empty ($this->channel))
            {
            $this->addError ($this->getText ("Incorrect feed channel"));
            return true;
            }
        return true;
        }
    }

/*
Put following line in header.tpl to point to sitewide feed (if any)
<link href="rss.xml" type="application/rss+xml" rel="alternate" title="Sitewide RSS Feed" />
*/

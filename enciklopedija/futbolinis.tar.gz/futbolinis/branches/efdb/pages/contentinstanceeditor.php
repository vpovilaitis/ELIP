<?php
require_once (PATH.'inc/relationfields.php');
require_once (PATH.'pages/contentpreview.php');

class ContentInstanceEditor extends InstanceEditor
    {
    protected $fields;
    protected $hasSourceColumns = false;
    protected $displayNameColumn;
    protected $viewContentUrl = NULL;
    protected $flatTemplate = false;
    protected $templateComponent;
    protected $showParent = true;

    public function __construct ($context, $prefix, $dbtable)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = $dbtable;
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        if (!$this->dbtable)
            return false;

        $this->initializeTemplateParts ($request);
        return $this->fields;
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if (empty ($this->dbtable))
            return true;

        if (!$this->isCreating ())
            {
            $id = $this->getIds ();
            $childtables = $this->dbtable->getChildTables ();
            if (!empty ($childtables))
                {
                foreach ($childtables as $table)
                    {
                    $component = $this->createChildPreview ($context, $request, $id, $table);
                    if (!empty ($component))
                        $this->addComponent ($request, "child_{$table->getName()}", $component);
                    }
                }
            }

        return true;
        }

    protected function createChildPreview ($context, $request, $id, $table)
        {
        $component = ComponentFactory::createPreview ($context, "preview{$table->getId()}", $table, DefaultFactory::PREVIEW_CHILD, $this->dbtable);
        if (empty ($component))
            return NULL;
        $component->setParent ($id, $this);
        $component->setTitle ($table->getDescription ());
        return $component;
        }

    protected function initializeTemplateParts ($request)
        {
        if (NULL != $this->fields)
            return;

        $this->fields = $this->getTemplateParts ($request);
        }

    protected function getTemplateParts ($request)
        {
        $dbColumns = $this->dbtable->selectDisplayableColumns ();
        $idColumns = $this->getIdColumns ();
        $fields = array ();
        $prefix = $this->getPrefix ();

        if ($this->showParent)
            {
            $parentField = $this->createParentField ();
            if (!empty ($parentField))
                $fields[] = $parentField;
            }

        foreach ($dbColumns as $col)
            {
            if (false !== array_search ($col->name, $idColumns))
                continue;

            $field = $this->createField ($request, $prefix, $col);
            if (empty ($field))
                continue;

            if ($col instanceof ValueColumn && ContentTable::COL_DISPLAY_NAME == $col->name)
                {
                $this->displayNameColumn = $col->columnDef->name;
                array_unshift ($fields, $field);
                }
            else
                $fields[] = $field;
            }

        return $fields;
        }

    protected function canEditParent ()
        {
        return false;
        }

    protected function createParentField ()
        {
        $parentTable = $this->dbtable->getParentTable ();
        if (empty ($parentTable))
            return NULL;

        $field = NULL;
        if (!$this->isCreating () && !$this->canEditParent ())
            {
            $field = new LabelFixedParentFieldTemplate ("i", $this->dbtable,
                                                        $parentTable->getLabel (),
                                                        $this->getParentId ());
            }
        else
            {
            $field = new EditableParentFieldTemplate ("i", $this->dbtable,
                                                      $parentTable->getLabel (),
                                                      $this->getText ("Select a parent"),
                                                      $this->getParentId ());
            }

        return $field;
        }

    public function tracksSource ()
        {
        return $this->hasSourceColumns;
        }

    protected function createField ($request, $prefix, $col)
        {
        if (MetaDataColumns::CATEGORY_GENERATED == $col->category)
            return NULL;

        if ($col instanceof ValueColumn)
            {
            $columnDef = $col->columnDef;
            if ($columnDef->name == DBTable::COL_SOURCE || $columnDef->name == DBTable::COL_SOURCEDATE)
                {
                $this->hasSourceColumns = true;
                return NULL;
                }
            else if ($columnDef instanceof DateColumn || $columnDef instanceof DateTimeColumn)
                $field = new DateFieldTemplate ($prefix, $columnDef->name, $col->getLabel (), $col->description);
            else if ($columnDef instanceof NamedIntColumn)
                $field = new DropDownFieldTemplate ($prefix, $columnDef->name, $col->getLabel (), $col->description, NamedIntColumn::getItems ($col));
            else if ($columnDef instanceof BoolColumn)
                $field = new CheckBoxFieldTemplate ($prefix, $columnDef->name, $col->getLabel (), $col->description);
            else if ($columnDef instanceof LongTextColumn)
                $field = new LongTextFieldTemplate ($prefix, $columnDef->name, $col->getLabel (), $col->description);
            else
                $field = new TextFieldTemplate ($prefix, $columnDef->name, $col->getLabel (), $col->description, $columnDef->size < 64 ? $columnDef->size : 64);

            if (!empty ($columnDef->triggeredBy) || $columnDef instanceof GhostColumn)
                {
                if ($this->isCreating ())
                    return NULL;
                $field->readonly = true;
                }
            }
        else
            {
            $field = RelationDropDownFieldTemplate::createInstance ($this->context, $prefix, $col);
            }

        return $field;
        }

    public function setTemplate ($templateComponent)
        {
        $this->templateComponent = $templateComponent;
        }

    public function getInstance ()
        {
        if (!empty ($this->templateComponent))
            {
            return $this->templateComponent->getInstance ();
            }

        return parent::getInstance ();
        }

    protected function loadDefaultOrInitialValues (&$request, $template)
        {
        $ret = parent::loadDefaultOrInitialValues ($request, $template);

        $cookieName = "lastsrc_".$this->dbtable->getName ();
        if (!empty ($_COOKIE[$cookieName]))
            {
            if (!$this->isCreating ())
                $this->instance[DBTable::COL_SOURCE] = $_COOKIE[$cookieName];
            else
                $request[DBTable::COL_SOURCE] = $_COOKIE[$cookieName];
            }

        return $ret;
        }

    public function redirectOnCancel ($request)
        {
        if ($this->isCreating ())
            {
            $url = "index.php?c=ContentPreviewPage&tn={$this->dbtable->getName()}";
            $this->context->redirect ($this->context->processUrl ($url, true));
            return false;
            }

        return $this->redirectOnSuccess ();
        }

    protected function showSuccessPage ($request)
        {
        // in bulk editing mode we will just show a link to successfully created instance
        $this->viewContentUrl =  LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                     $this->dbtable->getId (), $this->getIds ());

        $this->hiddenFields[InstanceEditor::COMPONENT_HIDDEN] = 1;
        return true;
        }

    public function redirectOnSuccess ()
        {
        $this->viewContentUrl =  LabelContentLinkFieldTemplate::createContentViewLink ($this->context, $this->dbtable,
                                                                     $this->dbtable->getId (), $this->getIds ());
        $this->context->redirect ($this->viewContentUrl);
        return false;
        }

    public function useFlatTemplate ($flatTemplate)
        {
        $this->flatTemplate = $flatTemplate;
        }

    protected function getPageTemplateDir ()
        {
        if (!empty ($this->viewContentUrl) || $this->flatTemplate)
            return "pages";
        return parent::getPageTemplateDir ();
        }

    public function getTemplateName ()
        {
        if (!empty ($this->viewContentUrl))
            return "contentlink";

        if ($this->flatTemplate)
            return "flateditor";

        return parent::getTemplateName ();
        }

    public function getLink ()
        {
        return array ($this->viewContentUrl => $this->getTitle ());
        }

    public function getMetaDescription ()
        {
        return NULL;
        }

    public function showCancel ()
        {
        return !$this->isCreating ();
        }

    protected function getIdColumns ()
        {
        if (NULL == $this->dbtable)
            return false;

        $cols = $this->dbtable->getPrimaryIndexColumns ();
        $names = array ();
        for ($c = 0; $c < count ($cols); $c++)
            {
            $names[] = $cols[$c]->name;
            }
        return $names;
        }

    protected function createRecord (&$request, $values)
        {
        if (isset ($values[Constants::PARENT]))
            {
            $parentId = $values[Constants::PARENT];
            unset ($values[Constants::PARENT]);
            }
        else
            $parentId = $this->getParentId ();

        $this->initializeTemplateParts ($request);
        $newValues = $values;

        $parent = $this->dbtable->getParentTable ();
        if (NULL != $parent && NULL != $parentId)
            {
            $cols = $parent->getPrimaryIndexColumns ();

            for ($c = 0; $c < count ($cols) && $c < count ($parentId); $c++)
                {
                $newValues[$cols[$c]->name] = $parentId[$c];
                }
            }

        $id = $this->dbtable->insertRecord ($newValues);
        if (false === $id)
            {
            $this->addError ("Error creating a record");
            return false;
            }

        $this->setMode (false, $id);
        return true;
        }

    protected function modifyRecord ($request, $id, $values)
        {
        if (isset ($values[Constants::PARENT]))
            {
            $parentId = $values[Constants::PARENT];
            unset ($values[Constants::PARENT]);
            }
        else
            $parentId = $this->getParentId ();

        $ret = parent::modifyRecord ($request, $id, $values);
        if (!$ret)
            return $ret;

        if (!empty ($parentId) && $this->canEditParent ())
            {
            $originalParentId = $id;
            array_pop ($originalParentId);

            if ($originalParentId != $parentId)
                {
                $newIds = $this->dbtable->moveRecord ($id, $parentId);
                if (false === $newIds)
                    return false;
                    
                $this->setIds ($newIds);
                }
            }

        return $ret;
        }

    public function getPageTitle ($isCreating = false)
        {
        $description = $this->dbtable->getDescription ();
        if (empty ($description))
            $description = $this->dbtable->getName ();

        if ($isCreating)
            return $this->formatText ("[_0] (creating)", $description);
        else
            {
            $label = NULL;
            $instance = $this->getInstance ();
            if (!empty ($instance))
                $label = $this->dbtable->getDisplayName ($instance);

            if (!empty ($label))
                return $this->formatText ("[_0] (editing)", $label);
            else
                return $this->formatText ("[_0] (editing)", $description);
            }
        }

    protected function valueChanged ($initialValues, $key, $newValue)
        {
        if (!array_key_exists ($key, $initialValues))
            {
            $this->addError ("Field [_0] is out of date", $key);
            return false;
            }

        $column = $this->dbtable->findColumn ($key);
        if (empty ($column))
            {
            $this->addError ("Field [_0] not found", $key);
            return NULL;
            }

        $initialValue = $initialValues[$key];
        if (0 == $column->compare ($initialValue, $newValue)) // unchanged
            return false;

        return true;
        }

    protected function getHintTargetGroup ()
        {
        if (!empty ($this->dbtable) && $this->dbtable->canEdit ())
            return HintsTable::TARGET_EDITOR;
        return parent::getHintTargetGroup ();
        }

    protected function getHintScope ()
        {
        if (empty ($this->dbtable))
            return HintsTable::SCOPE_CONTENTTABLE;
        return HintsTable::SCOPE_CONTENTTABLE.$this->dbtable->getName ();
        }

    protected function getHintContextMode ()
        {
        return HintsTable::CONTEXT_EDIT;
        }

    protected function getHintContextId ()
        {
        if ($this->isCreating ())
            return parent::getHintContextId ();
        return implode ("_", $this->getIds ());
        }
    }
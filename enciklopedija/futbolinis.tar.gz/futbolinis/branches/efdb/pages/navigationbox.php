<?php

abstract class NavigationBox extends Component
    {
    protected $dbtable;
    protected $currentItemId;
    protected $items;
    protected $idColumns;

    const LABEL = "label";

    public function __construct ($context, $dbtable, $currentItemId, $idColumns)
        {
        parent::__construct ("club", $context);
        $this->dbtable = $dbtable;
        $this->currentItemId = $currentItemId;
        $this->idColumns = $idColumns;
        }

    public abstract function selectNeighbours ($context, &$request);

    public function processInput ($context, &$request)
        {
        $rows = $this->selectNeighbours ($context, $request);
        
        if (empty ($rows))
            $this->items = NULL;
        else
            {
            $this->items = array ();

            foreach ($rows as $row)
                {
                $id = NULL;
                foreach ($this->idColumns as $col)
                    $id[] = empty ($row[$col]) ? NULL : $row[$col];

                $this->items[] = $this->constructDisplayRow ($row, $id);
                }
            }

        return true;
        }

    protected function constructDisplayRow ($row, $id)
        {
        $labels = $this->createItem ($row, $id);
        $deleteUrl = NULL;
        if (!empty ($labels['deleteUrl']))
            {
            $deleteUrl = $labels['deleteUrl'];
            unset ($labels['deleteUrl']);
            }

        $item = array ("id" => $id, "labels" => $labels, "deleteUrl" => $deleteUrl);

        if ($id == $this->currentItemId)
            $item["current"] = true;
        else
            {
            $url = $this->getItemUrl ($this->context, $this->dbtable, $id);
            $item["link"] = $url;
            }

        return $item;
        }


    protected function getItemUrl ($context, $dbtable, $id)
        {
        return LabelContentLinkFieldTemplate::createContentViewLink ($context,
                                                    $dbtable, $dbtable->getId (),
                                                    $id);
        }

    public function getCreateUrl ()
        {
        return NULL;
        }

    public function getCreateLabel ()
        {
        return $this->getText ("Add new item");
        }

    public function getTemplateName ()
        {
        return "navbox";
        }

    public abstract function getCssClass ();

    public function getRows ()
        {
        return $this->items;
        }

    public function isVisible ($inline = false)
        {
        return $inline && !empty ($this->items) && count ($this->items) > 1;
        }
    }

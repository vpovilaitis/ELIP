<?php

require_once (PATH.'pages/contentpreview.php');

class ContentLocator extends ContentPreview
    {
    protected $cachedResult = NULL;

    public function __construct ($context, $table)
        {
        parent::__construct ($context, "", $table);
        }

    protected function prepareRowCountQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        $this->getSearchFields (); // make sure search fields are created

        if (!isset ($this->request[$this->searchCriteriaField->key]))
            {
            $this->request[$this->searchCriteriaField->key] = $this->request["cri"];
            $this->request[$this->appliedCriteriaField->key] = $this->request["cri"];
            }

        return parent::prepareRowCountQuery ($resultColumns, $criteria, $joins, $params);
        }

    public function getSearchFields ()
        {
        parent::getSearchFields (); // make sure search fields are created
        return NULL;
        }

    public function select ($context, $criteria = NULL)
        {
        if (NULL !== $this->cachedResult)
            return $this->cachedResult;

        $this->cachedResult = parent::select ($context, $criteria);
        if (empty ($this->cachedResult))
            return $this->cachedResult;

        if (1 == count ($this->cachedResult))
            {
            $url = $this->dbtable->getContentLink ($this->dbtable->getRowIds ($this->cachedResult[0]));
            $this->redirect ($url);
            exit ();
            }

        return $this->cachedResult;
        }

    public function setMode ($creating, $id)
        {
        }

    public function ensureChildren ($context, $request)
        {
        $this->select ($context);
        }

    public function getTitle ()
        {
        return $this->getText ("Locating [_0]", $this->request["cri"]);
        }

    public function getMetaDescription ()
        {
        return $this->getText ("Locating item [_0]", $this->request["cri"]);
        }
    }

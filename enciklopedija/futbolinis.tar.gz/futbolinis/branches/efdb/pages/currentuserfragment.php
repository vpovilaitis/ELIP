<?php
require_once (PATH.'pages/componentfragment.php');
require_once (PATH.'pages/currentuser.php');

class CurrentUserFragment extends ComponentFragment
    {
    const PARAM_INFO = "additional_i";
    const PARAM_RELOAD = "reload";
    const INFO_DEFAULT = 1;
    const INFO_EMAIL = 2;

    protected function getAdditionalEditorFields ()
        {
        $arr = parent::getAdditionalEditorFields ();
        $types = array
                (
                self::INFO_DEFAULT => $this->getText ("Default|current user information"),
                self::INFO_EMAIL => $this->getText ("Require e-mail|current user information"),
                );
        $arr[] = new DropDownFieldTemplate (self::PARAM_INFO, self::PARAM_INFO,
                                    $this->getText ("Purpose:|current user information"), $this->getText ("That additional information might be needed"), $types);
        $arr[] = new CheckBoxFieldTemplate (self::PARAM_RELOAD, self::PARAM_RELOAD,
                                    $this->getText ("Reload after login"), $this->getText ("Force page reload after sucessful login"));
        return $arr;
        }

    protected function getShowDescription ()
        {
        return false;
        }

    public function showHeader ()
        {
        return true;
        }

    protected function createComponent ($context, $prefix, $additionalParams)
        {
        return new CurrentUserAsync ($context, $prefix, $additionalParams);
        }

    }

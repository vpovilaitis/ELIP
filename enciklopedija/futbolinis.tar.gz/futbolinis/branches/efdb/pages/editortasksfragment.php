<?php
require_once (PATH.'pages/componentfragment.php');

class EditorTasksFragment extends ComponentFragment
    {
    protected function getAdditionalEditorFields ()
        {
        return parent::getAdditionalEditorFields ();
        }

    protected function getShowDescription ()
        {
        return false;
        }

    public function showHeader ()
        {
        return true;
        }

    protected function createComponent ($context, $prefix, $additionalParams)
        {
        return new EditorTasksAsync ($context, $prefix);
        }

    }

class EditorTasksAsync extends AsyncComponent
    {
    public function getNoScriptText ()
        {
        return $this->getText ("You need to enable scripts in your browser to view editor task list.");
        }

    protected function getUrl ()
        {
        return $this->context->getInlineContentUrl ("index.php?c=EditorTasks", true);
        }
    }

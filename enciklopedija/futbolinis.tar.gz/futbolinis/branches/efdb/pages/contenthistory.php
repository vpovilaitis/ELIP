<?php

require_once (PATH.'inc/page.php');
require_once (PATH.'inc/preview.php');
require_once (PATH.'inc/contenttable.php');

class ContentHistory extends Preview
    {
    protected $id;
    protected $label;

    public function __construct ($context, $dbtable)
        {
        parent::__construct ("rev", $context, $dbtable);
        $context->setMetaParam ("ROBOTS", "noindex, nofollow");
        }

    public function getTitle ()
        {
        if (!empty ($this->dbtable))
            $desc = $this->dbtable->getDisplayNameById ($this->id, false);
        if (empty ($desc))
            $desc = $this->getDescription();
        else
            $this->label = $desc;

        return $this->getText ("[_0] (history)", $desc);
        }

    public function getDescription ()
        {
        if (!$this->dbtable)
            return $this->_("History");
        return $this->dbtable->getDescription();
        }

    protected function getDisplayTemplate ()
        {
        if (!$this->dbtable)
            return false;

        $fields = array ();

        $fields[] = new RevisionNameFieldTemplate ($this->dbtable, "r", DBTable::COL_UPDATEDON, $this->getText ("Revision"), $this->id);
        if ($this->dbtable->areSourcesTracked ())
            {
            $fields[] = new SourceFieldTemplate ("r", DBTable::COL_SOURCE,
                                                 $this->getText ("Sources/comments"));
            $fields[] = new LabelDateFieldTemplate ("r", DBTable::COL_SOURCEDATE,
                                                    $this->getText ("Source date"));
            }

        $fields[] = new AuthorFieldTemplate ($this->context, "r", $this->getText ("Author"));

        return $fields;
        }

    protected function getIdColumns ()
        {
        if (NULL == $this->dbtable)
            return false;

        return array (DBTable::COL_REVISIONID);
        }

    public function getTotalCount ()
        {
        if (NULL === $this->totalCount)
            {
            $params[] = new SelectRevisions ();
            $rows = $this->dbtable->selectBy (array (new FunctionCount ("*", "cnt")),
                                              $this->getFilterCriteria (), NULL, $params);
            if (NULL != $rows)
                $this->totalCount = $rows[0]["cnt"];
            else
                $this->totalCount = 0;
            }

        return $this->totalCount;
        }

    public function getMetaDescription ()
        {
        return NULL;
        }

    public function isVisible ()
        {
        return true;
        }

    public function getActionList ()
        {
        return parent::getActionList (true);
        }

    public function setMode ($creating, $id)
        {
        if (is_numeric ($id))
            $id = array ($id);
        else if (is_string ($id))
            $id = explode ("_", $id);

        $this->id = $id;
        }

    protected function getFilterCriteria ()
        {
        $criteria = array ();

        $cols = $this->dbtable->getPrimaryIndexColumns ();
        $i = 0;

        for ($c = 0; $c < count ($cols); $c++)
            {
            $criteria[] = new EqCriterion ($cols[$c]->name, $this->id[$c]);
            }

        return $criteria;
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        $params[] = new SelectRevisions ();
        $params[] = new OrderBy (array (new OrderByColumn (DBTable::COL_UPDATEDON, false, 1)));
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        }

    public function getSearchFields ()
        {
        if (empty ($this->dbtable) || empty ($this->id))
            return NULL;

        $label = $this->label;
        if (empty ($label))
            $label = $this->getText ("Navigate to revisioned item"); 
        return array (new ContentViewLink ($this, $this->dbtable, $this->id, $label));
        }

    public function checkAccess ($request)
        {
        if (false === $this->dbtable->canRead ())
            return false;
        return true;
        }

    protected function getHintScope ()
        {
        return HintsTable::SCOPE_CONTENTTABLE.$this->dbtable->getName ();
        }

    protected function getHintContextMode ()
        {
        return HintsTable::CONTEXT_HISTORY;
        }

    protected function getHintContextId ()
        {
        return $this->id;
        }
    }

class ContentViewLink extends AdditionalURLIcon
    {
    protected $dbtable;
    protected $id;

    public function __construct ($component, $dbtable, $id, $label)
        {
        parent::__construct ($component, $label, $component->getText ("Navigate to revisioned item"), NULL);
        $this->dbtable = $dbtable;
        $this->id = $id;
        $this->image = false;
        }

    public function getUrl ($request, $id)
        {
        return LabelContentLinkFieldTemplate::createContentViewLink ($this->component->getContext(),
                                                                     $this->dbtable, $this->dbtable->getId (),
                                                                     $this->id, Constants::MODE_VIEW);
        }

    public function isVisible ($row = NULL)
        {
        return true;
        }
    }

class RevisionNameFieldTemplate extends LabelFieldTemplate
    {
    protected $id;
    protected $dbtable;

    public function __construct ($dbtable, $prefix, $key, $label, $id)
        {
        parent::__construct ($prefix, $key, $label, false);
        $this->id = $id;
        $this->dbtable = $dbtable;
        }

    public function getUri ($context, $row)
        {
        $revId = $row[DBTable::COL_REVISIONID];
        $id = implode ("_", $this->id);
        $url = "index.php?c=ContentPage&mode=".Constants::MODE_VIEW."&tid={$this->dbtable->getId()}&id=$id&diff=$revId";
        return $context->processUrl ($url, true);
        }
    }

class SourceFieldTemplate extends LabelFieldTemplate
    {
    public function getValueForDisplay ($context, $row)
        {
        $text = parent::getValueForDisplay ($context, $row);
        return $context->createLinksFromText ($text);
        }

    public function isRichText ()
        {
        return true;
        }
    }

class AuthorFieldTemplate extends LabelFieldTemplate
    {
    protected $context;

    public function __construct ($context, $prefix, $label)
        {
        parent::__construct ($prefix, UsersTable::COL_NAME, $label, false);
        $this->context = $context;
        }

    public function getUri ($context, $row)
        {
        return NULL;
        }

    public function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        $usersTable = new UsersTable ($this->context);
        $userJoin = $usersTable->createQuery (array (UsersTable::COL_NAME),
                                              array (new JoinColumnsCriterion (DBTable::COL_UPDATEDBY, UsersTable::COL_ID)));

        $userJoin->joinType = Constants::JOIN_LEFT_OUTER;
        $joins[] = $userJoin;
        }
    }


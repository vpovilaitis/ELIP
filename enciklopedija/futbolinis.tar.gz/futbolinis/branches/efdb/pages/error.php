<?php

require_once (PATH.'inc/page.php');

class Error extends ReaderPage
    {
    public function __construct ($context)
        {
        parent::__construct ($context, _("Error"), Constants::TABLES_USER);
        }

    public function getTemplateName ()
        {
        return "error";
        }

    public function processInput ($context, &$request)
        {
        header ('Status: 500 Error');
        $err = empty ($request["error"]) ? $this->getText ("Error occured") : $request["error"];
        $this->addError ($err);
        return true;
        }

    protected function checkAccess ($request)
        {
        // no access is required to see an error
        return true;
        }
    }

?>

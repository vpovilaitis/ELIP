<?php

require_once (PATH.'pages/contentpreview.php');
require_once (PATH.'pages/contentview.php');

class IntegratedView extends ContentView
    {
    protected $row;

    public function __construct ($context, $prefix, $dbtable, $row = NULL)
        {
        parent::__construct ($context, $prefix, $dbtable);
        $this->initializeByRow ($row);
        $this->showParent = false;
        }

    public function initializeByRow ($row)
        {
        $this->row = $row;
        $idColumns = $this->dbtable->getPrimaryIndexColumns ();
        $id = array ();
        foreach ($idColumns as $col)
            $id[] = $row[$col->name];
        $this->setMode (false, $id);
        }

    public function selectByCriteria ($criteria)
        {
        $this->collectTemplateFields ($request, $this->isCreating ());

        $idColumns = $this->dbtable->getPrimaryIndexColumns ();
        $resultColumns = array ();
        foreach ($idColumns as $col)
            $resultColumns[] = $col->name;

        $joins = NULL;
        $this->prepareQuery ($resultColumns, $criteria, $joins);

        $rows = $this->dbtable->selectBy ($resultColumns, $criteria, $joins);
        return $rows;
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params = NULL)
        {
        parent::prepareQuery ($resultColumns, $criteria, $joins, $params);
        $resultColumns[] = ContentTable::COL_SECTION;
        }

    protected function retrieveExisting ($request, $id)
        {
        return $this->row;
        }

    public function getSectionName ()
        {
        return $this->row[ContentTable::COL_SECTION];
        }

    protected function collectTemplateFields ($request, $isCreating)
        {
        $fields = parent::collectTemplateFields ($request, $isCreating);
        foreach ($fields as $key => $field)
            {
            if ($field->key == $this->displayNameColumn)
                {
                unset ($fields[$key]);
                break;
                }
            }

        return $fields;
        }
    }

class ContentIntegratedPreview extends Component
    {
    protected $dbtable;
    protected $parentId;

    public function __construct ($context, $prefix, $dbtable, $parentId)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = $dbtable;
        $this->parentId = $parentId;
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if (empty ($this->dbtable))
            return true;

        $parent = $this->dbtable->getParentTable ();
        $criteria = array ();
        $cols = $parent->getPrimaryIndexColumns ();

        for ($c = 0; $c < count ($cols) && $c < count ($this->parentId); $c++)
            $criteria[] = new EqCriterion ($cols[$c]->name, $this->parentId[$c]);

        $controlComponent = new IntegratedView ($context, "", $this->dbtable);
        $rows = $controlComponent->selectByCriteria ($criteria);

        if (empty ($rows))
            return true;

        $i = 0;
        foreach ($rows as $row)
            {
            $name = "c".(++$i);
            $component = new IntegratedView ($context, $name, $this->dbtable, $row);
            $this->addComponent ($request, $name, $component);
            }

        return true;
        }

    public function isVisible ()
        {
        return count ($this->components) > 0;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "integratedcontent";
        }

    public function processInput ($context, &$request)
        {
        return true;
        }
    }

?>

<?php
require_once (PATH."inc/component.php");
require_once (PATH."pages/simpletext.php");

class Welcome extends ReaderPage
    {
    protected $title;

    public function __construct ($context, $request)
        {
        $this->title = $context->getText ("Welcome");
        parent::__construct ($context, $this->title, Constants::TABLES_USER);
        }

    public function ensureTitle ($context, &$request)
        {
        $this->context->setTitle ($this->title);
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "simplepage";
        }

    public function ensureChildren ($context, $request)
        {
        if (!empty ($this->component))
            return true;

        $this->component = new SimpleText ($context, "p", NULL, $this->title,
                                           $this->context->getValue (SiteSettings::SITE_WELCOME));
        $this->addComponent ($request, "component", $this->component);

        return true;
        }
    }


<?php
require_once (PATH.'inc/instanceview.php');

class StatisticsSection extends Component
    {
    protected $parent;
    protected $title;
    protected $columnDefinitions;
    protected $rows;
    public $id;

    public function __construct ($parent, $id, $title, $rows, $columnDefinitions)
        {
        parent::__construct ("", $parent->getContext ());
        $this->parent = $parent;
        $this->title = $title;
        $this->id = $id;
        $this->rows = $rows;
        $this->columnDefinitions = $columnDefinitions;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function getTemplateName ()
        {
        return "groupedstats";
        }

    public function getTitle ()
        {
        return $this->title;
        }

    public function getData ()
        {
        return $this->rows;
        }

    public function getRowCount ()
        {
        return count ($this->rows);
        }

    public function getColumns ()
        {
        return $this->columnDefinitions;
        }

    public function hasAdditionalActions ()
        {
        return false;
        }

    public function singleRowArray ($row)
        {
        return array ($row);
        }

    public function getColumnCount ($fields)
        {
        return count ($fields);
        }
    }

class StatisticsEnumeratorComponent extends StatisticsSection
    {
    public function getTemplateName ()
        {
        return "enumeratedstats";
        }

    public function getFields ()
        {
        return $this->getColumns ();
        }

    public function getStatisticsLink ($instance)
        {
        return NULL;
        }
    }

class StatisticsColumn extends LabelFieldTemplate
    {
    public $icon;
    public $key;

    public function __construct ($key, $title, $css = NULL, $icon = NULL)
        {
        parent::__construct ("", $key, $title);
        $this->icon = $icon;
        $this->cssClass = $css;
        }

    public function isRichText ()
        {
        return true;
        }

    public function getIcon ($context)
        {
        if (!empty ($this->icon))
            {
            return $context->getSmallIconPath ($this->icon);
            }

        return NULL;
        }

    public function showValue ($fieldValue)
        {
        return NULL !== $fieldValue;
        }
    }

class StatisticsRowsComponent extends StatisticsSection
    {
    protected $showCount;

    public function __construct ($parent, $id, $title, $rows, $columnDefinitions, $showCount = false)
        {
        parent::__construct ($parent, $id, $title, $rows, $columnDefinitions);
        $this->showCount = $showCount;
        }

    public function getTemplateName ()
        {
        return "statisticsrows";
        }

    public function getTitle ()
        {
        if ($this->showCount)
            return $this->parent->ngettext ("[_1] ([_0] record)", "[_1] ([_0] records)", $this->getRowCount (), parent::getTitle ());
        return parent::getTitle ();
        }

    public function getRowCountText ()
        {
        }
    }

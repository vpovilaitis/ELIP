<?php

require_once (PATH.'pages/contentpreview.php');
require_once (PATH.'inc/componentfactory.php');

class ContentPreviewPage extends ReaderPage
    {
    protected $preview;

    public function __construct ($context, $request)
        {
        $table = 0;
        if (!isset ($request["tn"]) && isset ($request["id"]))
            sscanf ($request["id"], "%d", $table);

        if ($table <= 0)
            $table = isset ($request["tn"]) ? $request["tn"] : NULL;

        if (is_numeric ($table))
            $dbtable = ContentTable::createInstanceById ($context, $table);
        else
            $dbtable = ContentTable::createInstanceByName ($context, $table);
        $this->preview = ComponentFactory::createPreview ($context, "preview", $dbtable, DefaultFactory::PREVIEW_ALL);
        if (false === $this->preview)
            {
            echo $this->getText ("Unexpected error");
            exit;
            }

        $description = !empty ($this->preview) ? $this->preview->getDescription() : NULL;
        if (empty ($description))
            $description = _("Content preview");
        parent::__construct ($context, $description, Constants::TABLES_USER, !empty ($this->preview) ? $this->preview->getTableName () : NULL);
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "contentpreview";
        }

    public function processInput ($context, &$request)
        {
        $this->addComponent ($request, "preview", $this->preview);
        return true;
        }

    }

?>

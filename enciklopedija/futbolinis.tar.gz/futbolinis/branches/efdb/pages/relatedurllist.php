<?php
require_once (PATH."pages/navigationbox.php");

class RelatedUrlList extends NavigationBox
    {
    protected $scopeId;
    protected $contextId;
    protected $lng;

    public function __construct ($context, $dbtable, $currentItemId)
        {
        parent::__construct ($context, $dbtable, $currentItemId, array ("league_id"));
        $this->lng = Language::getInstance ($context);
        }

    public function getScope ()
        {
        return "x_".$this->dbtable->getName();
        }

    public function selectNeighbours ($context, &$request)
        {
        $dbtable = new RelatedUrlTable ($context);
        $id = implode ("_", $this->currentItemId);
        $criteria[] = new EqCriterion (RelatedUrlTable::COL_SCOPE, $this->getScope ());
        $criteria[] = new EqCriterion (RelatedUrlTable::COL_CONTEXTID, $id);
        $params[] = OrderBy::create (RelatedUrlTable::COL_PRIORITY);
        $names = $dbtable->selectBy (NULL, $criteria, null, $params);
        return $names;
        }

    public function ensureChildren ($context, $request)
        {
        $dbtable = new RelatedUrlTable ($context);
        if ($dbtable->canEdit ())
            {
            $context->addScriptFile ("editor");
            $script = "attachRelatedUrlEditor ();";
            $this->addComponent ($context, "script", new StartupScript ($context, $script));
            }
        return true;
        }

    public function createItem ($row, $id)
        {
        $editLink = $deleteLink = NULL;
        $dbtable = new RelatedUrlTable ($this->context);
        if ($dbtable->canEdit ())
            $editLink = $this->context->processUrl ("index.php?service=EditRelatedUrlPopup&action=edit&id=".$row[RelatedUrlTable::COL_ID], true);
        if ($dbtable->canDelete ())
            $deleteLink = $this->context->processUrl ("index.php?service=EditRelatedUrlPopup&mode=delete&id=".$row[RelatedUrlTable::COL_ID], true);

        return array
                (
                self::LABEL => $row[RelatedUrlTable::COL_LABEL],
                "url" => $row[RelatedUrlTable::COL_URL],
                "editUrl" => $editLink,
                "deleteUrl" => $deleteLink,
                );
        }

    public function getTitle ()
        {
        return $this->getText ("Related links");
        }

    public function getCssClass ()
        {
        return "related-urls";
        }

    public function getTemplateName ()
        {
        return "relatedurls";
        }

    public function isVisible ($inline = false)
        {
        return count ($this->items) > 0 || $this->context->getCurrentUser() > 0;
        }

    public function getCreateUrl ()
        {
        $dbtable = new RelatedUrlTable ($this->context);
        if ($dbtable->canCreate ())
            {
            $scope = $this->getScope ();
            $id = implode ("_", $this->currentItemId);
            return $this->context->processUrl ("index.php?service=EditRelatedUrlPopup&action=new&scope=$scope&rid=$id", true);
            }
        return NULL;
        }
    }

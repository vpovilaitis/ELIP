<?php
require_once (PATH.'pages/fragmenttemplate.php');

abstract class ComponentFragment extends FragmentTemplate
    {
    protected $containedComponent = NULL;

    public function __construct ($context, $prefix, $table, $title = NULL, $description = NULL, $params = NULL)
        {
        parent::__construct ($context, $prefix, $table, $title, $description, $params);
        }

    public function getTemplateName ()
        {
        if ($this->inEditorMode ())
            return parent::getTemplateName ();

        return "componentfragment";
        }

    public function showHeader ()
        {
        return false;
        }

    protected function createComponents ($context, $request)
        {
        if (NULL === $this->containedComponent)
            {
            $this->containedComponent = $this->createComponent ($context, "c", $this->params);
            if (!empty ($this->containedComponent))
                $this->addComponent ($request, "component", $this->containedComponent);
            }

        return true;
        }

    protected function createComponent ($context, $prefix, $additionalParams)
        {
        }
    }

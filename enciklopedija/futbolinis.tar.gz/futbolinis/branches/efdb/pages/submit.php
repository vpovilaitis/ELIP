<?php
require_once (PATH.'inc/page.php');

abstract class Submit extends Page
    {
    protected $source;
    protected $sourceDate;

    protected $allTablesLoaded = true;
    protected $hasUnrecognizedItems = false;
    protected $fieldsNotReady = array ();
    protected $fields = array ();
    protected $columns = array ();

    protected function checkAccess ($request)
        {
        if (!empty ($this->dbtable))
            return $this->dbtable->canCreate ();
        return true;
        }

    protected function collectInputFields ($context, &$request)
        {
        foreach ($request as $requestKey => $val)
            {
            if (0 === strncmp ("res_", $requestKey, 4))
                {
                $modifier = trim (strrchr ($requestKey, "_"), "_");
                if ("label" == $modifier || "c" == $modifier || "new" == $modifier)
                    continue;

                list ($t, $type, $key) = explode ("_", $requestKey, 3);
                $this->onInputFieldCollected ($context, $request, $type, $key, $val);

                $label = $key;
                //$this->updateField ($type, $type, $key, $label);
                }
            }

        $this->createSourceFields ();
        $source = $this->sourcesField->getValueForDB ($context, $request);
        if (!empty ($source))
            $this->source = $source;
        $source = $this->sourcesDateField->getValueForDB ($context, $request);
        if (!empty ($source))
            $this->sourceDate = $source;
        }

    protected function onInputFieldCollected ($context, &$request, $type, $key, $val)
        {
        return true;
        }

    protected function processInputFields ($context, &$request)
        {
        ksort ($this->fields);
        foreach ($this->fields as $key => $field)
            $field->processInput ($context, $request);
        }

    protected function processInputFieldLabel ($context, $field)
        {
        return $field->label;
        }

    protected function isButtonPressed ($context, &$request)
        {
        return isset ($request["save"]) || isset ($request["skip"]);
        }

    public function processInput ($context, &$request)
        {
        if (!$this->isButtonPressed ($context, $request))
            return true;

        $this->processInputFields ($context, $request);
        $this->collectInputFields ($context, $request);

        $input = $this->collectInputData ($context, $request);
        if (false === $input)
            $this->logError ("Error parsing the results");
        else if (false === $this->validateInput ($context, $input))
            $this->logError ("Error preparing the input data");
        else
            {
            if ($this->allTablesLoaded && !$this->hasUnrecognizedItems)
                {
                $title = isset ($request["save"]) ? $this->_("Saving") : $this->_("Checking");
                $this->writeLine ("<h1>$title</h1><pre>", false);

                if (isset ($request["save"]) && false === $this->saveInput ($context, $request, $input))
                    {
                    $this->logError ("Error saving the matches");
                    }
                $this->writeLine ("</pre>", false);
                }
            }

        $this->processInputFields ($context, $request);
        return true;
        }

    public abstract function collectInputData ($context, &$request);
    public abstract function validateInput ($context, &$input);
    public abstract function saveInput ($context, &$request, &$input);

    public function encodeKey ($key)
        {
        return preg_replace_callback ("/(\s|[^a-zA-Z0-9])/U",
                                       array ($this, "replaceUnicodeChar"), $key);
        }
    public function replaceUnicodeChar ($match)
        {
        return "u".ord($match[1]);
        }

    protected function updateField ($type, $columnName, $key, $label)
        {
        $fieldKey = $type."_".$key;
        if (!isset ($this->fields[$fieldKey]))
            {
            $field = $this->createField ($type, $columnName, $key);
            $field->label = $label;

            if (empty ($this->request[$field->key]) && empty ($this->request[$field->key."_label"]))
                {
                $label = $this->processInputFieldLabel ($this->context, $field);
                $this->request[$field->key."_label"] = $label;
                }
            $this->fields[$fieldKey] = $field;
            }

        $field = $this->fields[$fieldKey];
        $field->label = $label;

        $val = $field->getValueForDisplay ($this->context, $this->request);
        if (empty ($val))
            {
            $field->forceValue ($this->request, NULL, $label);
            $field->processInput ($this->context, $this->request);
            }

        return $field->getValueForDB ($this->context, $this->request);
        }

    protected function beautifyName ($name)
        {
        foreach (array ("-", " ", ".") as $separator)
            {
            $parts = explode ($separator, $name);
            if (count ($parts) > 1)
                {
                $prepared = array ();
                foreach ($parts as $part)
                    $prepared[] = $this->beautifyName ($part);
                return implode ($separator, $prepared);
                }
            }

        if (empty ($name))
            return $name;

        return substr ($name, 0, 1).utf8_strtolower (substr ($name, 1));
        }

    protected function logError ($err, $returnValue = false)
        {
        $this->addError ($err);
        return $returnValue;
        }
        
    protected function createField ($type, $columnName, $key)
        {
        if (!array_key_exists ($columnName, $this->columns))
            {
            $col = $this->findDBTableColumn ($type, $columnName);
            $this->columns[$columnName] = $col;
            }
        else
            $col = $this->columns[$columnName];

        $column = clone $col;
        $column->name = "res_{$type}_".$key;
        return RelationDropDownFieldTemplate::createInstance ($this->context, "", $column);
        }

    protected function findDBTableColumn ($type, $columnName)
        {
        return $this->dbtable->findColumn ($columnName);
        }
        
    public function createSourceFields ()
        {
        $this->sourcesField = new TextFieldTemplate ($this->getPrefix (), DBTable::COL_SOURCE,
                                        $this->getText ("Source(s):"),
                                        $this->getText ("Source and comments"), 64);
        $this->sourcesDateField = new DateFieldTemplate ($this->getPrefix (), DBTable::COL_SOURCEDATE,
                                        $this->getText ("Updated on:"),
                                        $this->getText ("Sources updated on"));
        }

    public abstract function getFields ();
    
    protected $generatedOutput = NULL;
    public function getResultOutput ()
        {
        if (!empty ($this->generatedOutput))
            return implode ("\n", $this->generatedOutput);
        return NULL;
        }
    public function writeLine ($line, $plainText = true)
        {
        if (!is_string ($line))
            $line = var_export ($line, true);
        $this->generatedOutput[] = $line.($plainText ? "<br>" : "");
        }

    public function getButtons ()
        {
        return array (
                    array("name" => "save", "label" => $this->getSaveButtonLabel ()),
                    array("name" => "skip", "label" => $this->getCheckButtonLabel ()),
                    );
        }

    public function getSaveButtonLabel ()
        {
        return $this->getText ("Save");
        }

    public function getCheckButtonLabel ()
        {
        return $this->getText ("Check");
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function getTemplateName ()
        {
        return "sports/submitscores";
        }

    public function getStartupScript ()
        {
        return NULL;
        }
    }

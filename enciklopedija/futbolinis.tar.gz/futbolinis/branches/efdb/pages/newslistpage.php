<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'inc/newstable.php');
require_once (PATH.'pages/newslist.php');
require_once (PATH.'pages/newsitem.php');
require_once (PATH.'pages/newsfragment.php');
require_once (PATH.'pages/discussions.php');

class NewsListPage extends Page
    {
    protected $component;
    protected $dbtable;
    protected $id;

    public function __construct ($context, $request)
        {
        parent::__construct ($context, NULL, NewsTable::TABLE_SCOPE, NewsTable::TABLE_NAME);
        $scope = !empty ($_REQUEST["sp"]) ? $_REQUEST["sp"] : false;
        $this->dbtable = new NewsTable ($context, $scope);
        $this->id = !empty ($request["id"]) && is_numeric ($request["id"]) ? $request["id"] : NULL;
        }

    public function ensureTitle ($context, &$request)
        {
        parent::ensureTitle ($context, $request);
        $this->ensureChildren ($context, $request);
        $context->setTitle ($this->getTitle ());
        return true;
        }

    protected function checkAccess ($request)
        {
        return $this->dbtable->canRead ();
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if (!empty ($this->component))
            return true;

        $viewItem = !empty ($this->id);
        if ($viewItem)
            $this->component = new NewsItem ($context);
        else
            $this->component = new NewsList ($context);

        if (empty ($this->component))
            return true;

        if (!empty ($this->id))
            $this->component->setIds ($this->id);

        $this->addComponent ($request, "main", $this->component);

        if ($viewItem)
            {
            $this->addComponent ($request, "discuss", new DiscussionsComponent ($this->context, $this->dbtable, $this->id));
            $params = array (NewsFragment::PARAM_MAXOVERVIEW => 0, NewsFragment::PARAM_MAXITEMS => 5, NewsFragment::PARAM_SCOPE => $this->dbtable->getPerspective());
            $this->addComponent ($request, "list", new NewsFragment ($context, "list", NULL, $this->getText ("Other news"), NULL, $params));
            }

        return true;
        }

    public function getTitle ()
        {
        if (!empty ($this->id))
            return $this->component->getTitle ();
        else
            return $this->getText ("News archive");
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function getTemplateName ()
        {
        return "simplepage";
        }
    }

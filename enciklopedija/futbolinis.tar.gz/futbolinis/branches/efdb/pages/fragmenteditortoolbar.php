<?php
require_once (PATH.'pages/fragmenteditoricons.php');
require_once (PATH.'inc/interactivecomponent.php');

class FragmentEditorToolbar extends InteractiveComponent
    {
    protected $component;
    protected $hierarchyNode;
    protected $isFirst;
    protected $isLast;
    protected $parentId;

    public function __construct ($component, $hierarchyNode, $parentHierarchy)
        {
        parent::__construct ($component->prefix, $component->getContext());
        $this->component = $component;
        $this->hierarchyNode = $hierarchyNode;

        $idxFirst = NULL;
        $idxLast = NULL;
        $idx = NULL;
        if (!empty ($parentHierarchy))
            {
            foreach ($parentHierarchy->children as $key => $node)
                {
                if ($node == $hierarchyNode)
                    $idx = $key;
                if (NULL === $idxFirst)
                    $idxFirst = $key;
    
                $idxLast = $key;
                }

            $this->parentId = $parentHierarchy->id;
            }

        $this->isFirst = $idxFirst == $idx;
        $this->isLast = $idxLast == $idx;
        }

    public function getTemplateName ()
        {
        return "fragmenteditor";
        }

    public function processInput ($context, &$request)
        {
        if (false === parent::processInput ($context, $request))
            return false;

        return true;
        }

    public function toggleEditMode ($id)
        {
        $this->component->toggleEditMode ($id, $this->hierarchyNode->row[FragmentsTable::COL_ID]);
        }

    public function inEditorMode ()
        {
        return $this->component->inEditorMode ();
        }

    public function getHiddenFields ()
        {
        $this->hiddenFields["editing"] = $this->inEditorMode ();
        return parent::getHiddenFields ();
        }

    public function setPublished ($published)
        {
        $this->hierarchyNode->row[FragmentsTable::COL_PUBLISHED] = $published;
        }

    public function getActionList ()
        {
        $actions = array ();

        $id = $this->hierarchyNode->id;

        $actions[] = new EditFragmentIcon ($this);
        $actions[] = new ShowFragmentIcon ($this, !$this->hierarchyNode->row[FragmentsTable::COL_PUBLISHED]);

        if (empty ($this->parentId) && $this->isFirst && $this->isLast)
            {
            $actions[] = new AddFragmentIntoNewGroupIcon ($this, AddFragmentIcon::DIR_UP);
            $actions[] = new AddFragmentIntoNewGroupIcon ($this, AddFragmentIcon::DIR_DOWN);
            }
        else
            {
            if (!$this->isFirst)
                $actions[] = new ChangeFragmentOrderIcon ($this, true);
            else
                $actions[] = new AddFragmentIcon ($this, AddFragmentIcon::DIR_UP);
    
            if (!$this->isLast)
                $actions[] = new ChangeFragmentOrderIcon ($this, false);
            else
                $actions[] = new AddFragmentIcon ($this, AddFragmentIcon::DIR_DOWN);
            }

        $actions[] = new WrapFragmentIcon ($this);
        $actions[] = new DeleteFragmentIcon ($this);

        return $actions;
        }

    public function ensureChildren ($context, $request)
        {
        $this->addComponent ($request, "a", $this->component);
        if (!empty ($request["editing"]))
            {
            $this->toggleEditMode ($this->hierarchyNode->id);
            }

        return parent::ensureChildren ($context, $request);
        }

    protected function parseActionString ($request, $actionStr)
        {
        return array ($actionStr, $this->hierarchyNode->id);
        }

    public function getParentFragmentId ()
        {
        return $this->parentId;
        }
    }

<?php
require_once (PATH.'h/facebookservice.php');

class CurrentUser extends ReaderPage
    {
    public function __construct ($context)
        {
        parent::__construct ($context, "", Constants::TABLES_USER);
        }

    public function getTemplateName ()
        {
        return "pages/currentuser";
        }

    public function getLogoutText ()
        {
        return $this->getText ("Logout");
        }

    public function getLogoutLink ()
        {
        $fbApp = FacebookService::getInstance ();
        if ($fbApp->getUser())
            return $fbApp->getLogoutUrl(array ('next' => $this->context->processUrl ("logout.php?".Constants::PARAM_RETURN_TO."=".rawurlencode($this->context->processUrl ("loginSuccess.html", true)), true)));

        return $this->context->getInlineContentUrl ('logout.php');
        }

    public function getAssociateLink ()
        {
        $fbApp = FacebookService::getInstance ();
        $returnUrl = rawurlencode($this->context->processUrl ("loginSuccess.html", true));
        return $fbApp->getLoginUrl(array ('display' => 'popup',
                                          'redirect_uri' => $this->context->processUrl ("login.php?associate=1&".Constants::PARAM_RETURN_TO."=".$returnUrl, true)));
        }

    public function getFacebookId ()
        {
        $fbApp = FacebookService::getInstance ();
        return $fbApp->getUser();
        }

    public function getAssociateFacebookEncouragement ()
        {
        return $this->getText ("Wish to automatically sign in using Facebook account?");
        }

    public function getOptoutInfoAndEmail ()
        {
        $table = new UsersTable ($this->context);
        $criteria = array (new EqCriterion (UsersTable::COL_ID, $this->context->getCurrentUser()));
        $user = $table->selectSingleBy (array (UsersTable::COL_EMAIL, UsersTable::COL_OPTIN), $criteria);

        if (empty ($user) || empty ($user[UsersTable::COL_EMAIL]))
            return NULL;
        return array ('email' => $user[UsersTable::COL_EMAIL], 'optout' => 0 == $user[UsersTable::COL_OPTIN],
                      'link' => $this->context->processUrl ("index.php?service=UserService&action=optin", true));
        }

    public function getOptoutText ($info)
        {
        return $this->getText ("Do not contact me by email ([_0]).", $info['email']);
        }

    public function getAssociateFacebookText ()
        {
        return $this->getText ("Associate");
        }

    public function getWelcomeText ()
        {
        $context = $this->context;
        $user = $context->getCurrentUser();
        if ($user <= 0)
            return $this->getText ("You are not logged in");

        $dbtable = new UsersTable ($context);
        $row = $dbtable->selectSingleBy (array (UsersTable::COL_NAME, UsersTable::COL_DESCRIPTION, UsersTable::COL_EMAIL), array (new EqCriterion (UsersTable::COL_ID, $user)));
        if (empty ($row))
            $name = $this->getText ("Error");
        else
            $name = $row[UsersTable::COL_NAME];
        return $this->getText ("Welcome, [_0]. You are successfully logged into the system", "<span class=\"currentusername\">".$name."</span>");
        }
    }

class CurrentUserAsync extends AsyncComponent
    {
    protected $additionalParams;

    public function __construct ($context, $prefix, $additionalParams)
        {
        parent::__construct ($context, $prefix."currentuser");
        $this->additionalParams = $additionalParams;
        }

    public function getNoScriptText ()
        {
        return $this->getText ("You need to enable scripts in your browser to log into the site.");
        }

    public function generateStartupScript ($function, $elementId, $url)
        {
        $reload = "null";
        if (!empty ($this->additionalParams[CurrentUserFragment::PARAM_RELOAD]))
            $reload = 'function () { window.location.reload(); }';
        return "showCurrentUserInfo (\$('#$elementId'), '$url', $reload, $reload);";
        }

    protected function getUrl ()
        {
        $requestEmail = !empty ($this->additionalParams[CurrentUserFragment::PARAM_INFO]) && CurrentUserFragment::INFO_EMAIL == $this->additionalParams[CurrentUserFragment::PARAM_INFO]; 
        $params = array ();
        if ($requestEmail)
            $params[] = "perm=email&";
        $params = implode ("", $params);
        return $this->context->getInlineContentUrl ("login.php?$params".Constants::PARAM_RETURN_TO."=".rawurlencode($this->context->processUrl ("loginSuccess.html", true)), true);
        }
    }

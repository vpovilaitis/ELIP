<?php
require_once (PATH.'pages/fragmenttemplate.php');
require_once (PATH.'inc/newstable.php');

class NewsFragment extends FragmentTemplate
    {
    protected $maxItems;
    protected $rows;
    protected $desc;

    const PARAM_MAXITEMS = "maxitems";
    const PARAM_MAXOVERVIEW = "maxoverview";
    const PARAM_SCOPE = "scope";

    public function __construct ($context, $prefix, $table, $title = NULL, $description = NULL, $params = NULL)
        {
        parent::__construct ($context, $prefix, $table, $title, $description, $params);
        $this->dbtable = new NewsTable ($this->context, !empty ($params[self::PARAM_SCOPE]) ? $params[self::PARAM_SCOPE] : false);
        $this->maxItems = !empty ($params) && !empty ($params[self::PARAM_MAXITEMS]) ? $params[self::PARAM_MAXITEMS] : NewsTable::DEFAULT_ITEMS;
        $this->maxItemsWithOverview = !empty ($params) && isset ($params[self::PARAM_MAXOVERVIEW]) ? $params[self::PARAM_MAXOVERVIEW] : NULL;
        if (!(0 === $this->maxItemsWithOverview || $this->maxItemsWithOverview > 0))
            $this->maxItemsWithOverview = NewsTable::DEFAULT_ITEMS_WITH_OVERVIEW;

        $context->addStyleSheet ("editor");
        }

    protected function getAdditionalEditorFields ()
        {
        $arr = parent::getAdditionalEditorFields ();
        $arr[] = new FieldTemplate (self::PARAM_MAXITEMS, self::PARAM_MAXITEMS, "text",
                                    $this->getText ("Max items:"), $this->getText ("Max items to show in the list"));
        $arr[] = new FieldTemplate (self::PARAM_MAXOVERVIEW, self::PARAM_MAXOVERVIEW, "text",
                                    $this->getText ("Highlighted items:"), $this->getText ("Number of expanded news items"));
        $arr[] = new FieldTemplate (self::PARAM_SCOPE, self::PARAM_SCOPE, "text",
                                    $this->getText ("News scope:"), $this->getText ("Optional scope (if not given - site news will be displayed)"));
        return $arr;
        }

    public function getTemplateName ()
        {
        if ($this->inEditorMode ())
            return parent::getTemplateName ();

        return "news";
        }

    public function isVisible ()
        {
        $rows = $this->select ();
        return !empty ($rows) || $this->dbtable->canCreate ();
        }

    protected function getShowDescription ()
        {
        return false;
        }

    public function select ()
        {
        if (NULL === $this->rows)
            $this->rows = $this->dbtable->selectNews ($this->maxItems, $this->maxItemsWithOverview, $this->dbtable->canEdit ());
        return $this->rows;
        }

    protected static $nextUniqueId = 1;
    protected $uniqueId;
    public function getUniqueId ()
        {
        if (empty ($this->uniqueId))
            $this->uniqueId = get_class ($this).self::$nextUniqueId++;
        return $this->uniqueId;
        }

    public function getDescriptor ()
        {
        if (empty ($this->desc))
            $this->desc = new NewsLinkDescriptor ($this->context, $this->dbtable, $this->getUniqueId ());
        return $this->desc;
        }

    }

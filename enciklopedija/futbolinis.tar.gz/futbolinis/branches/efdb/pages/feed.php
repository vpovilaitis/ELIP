<?php

require_once (PATH.'pages/rss.php');

class Feed extends Rss
    {
    public function getTemplateName ()
        {
        return "feed";
        }

    protected function setContentType ($request)
        {
        }
        
    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function preprocessItem (&$item)
        {
        }

    }

<?php
require_once (PATH.'inc/componentfactory.php');

class ContentEditor extends Component
    {
    protected $dbtable = NULL;
    protected $sourcesField = NULL;
    protected $sourcesDateField = NULL;
    protected $bulkInstanceCountField = NULL;
    protected $ids;
    protected $isCreating;

    public function __construct ($context, $dbtable)
        {
        parent::__construct ("e", $context);
        $this->dbtable = $dbtable;
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if (empty ($this->components))
            {
            $count = isset ($request["count"]) ? $request["count"] : 1;
            $potentialCount = $count;
            if (isset ($request["multiply"]))
                $potentialCount = min ($request["newinst"], 100);
            for ($i = 0; $i < $count; $i++)
                $this->createComponent ($context, $request, $i, $potentialCount);
            }

        return true;
        }

    public function flatDisplay ()
        {
        return count ($this->components) > 1;
        }

    public function createComponent ($context, $request, $i, $instanceCount, $template = NULL)
        {
        $component = ComponentFactory::createEditor ($context, "e$i", $this->dbtable);
        if (false === $component)
            {
            return;
            }

        $component->inline = true;

        if (method_exists ($component, "setMode"))
            $component->setMode ($this->isCreating, $this->ids);
        else
            echo "No setMode() method in " . get_class ($component)."<br>";

        if (method_exists ($component, "useFlatTemplate"))
            $component->useFlatTemplate ($instanceCount > 1);
        else
            echo "No useFlatTemplate() method in " . get_class ($component)."<br>";

        if (!empty ($template))
            $component->setTemplate ($template);
        $this->addComponent ($request, "e$i", $component);
        }

    public function getCommonFields ()
        {
        $arr = array ();
        // in bulk editing case we assume that all components are similar
        foreach ($this->components as $component)
            {
            if ($component->tracksSource ())
                {
                $this->sourcesField = new TextFieldTemplate ($this->getPrefix (), DBTable::COL_SOURCE,
                                                $this->getText ("Source(s):"),
                                                $this->getText ("Source and comments"), 64);
                $arr[] = $this->sourcesField;
                $this->sourcesDateField = new DateFieldTemplate ($this->getPrefix (), DBTable::COL_SOURCEDATE,
                                                $this->getText ("Updated on:"),
                                                $this->getText ("Sources updated on"));
                $arr[] = $this->sourcesDateField;
                }
            break;
            }

        return $arr;
        }

    public function getCommonInstance ()
        {
        $inst = $this->getRequest ();
        if (1 != count ($this->components))
            return $inst;

        foreach ($this->components as $component)
            {
            $inst = array_merge ($component->getInstance(), $inst);
            }

        return $inst;
        }

    public function getMultiplyField ()
        {
        if (empty ($this->bulkInstanceCountField))
            return NULL;
        return $this->bulkInstanceCountField;
        }

    public function processInput ($context, &$request)
        {
        $this->hiddenFields["instances"] = 1;

        if (isset ($request["cancel"]))
            {
            foreach ($this->components as $component)
                {
                $component->redirectOnCancel ($request);
                break;
                }
            return false;
            }

        $instanceCount = 1;
        if (isset ($request["multiply"]))
            {
            $oldCount = $request["count"];
            $instanceCount = min ($request["newinst"], 100);
            $componentCount = count ($this->components);

            if ($componentCount < $instanceCount)
                {
                $template = $this->components["e".($componentCount-1)];

                // add new instances as requested
                for ($i = $componentCount; $i < $instanceCount; $i++)
                    $this->createComponent ($context, $request, $i, $instanceCount, $template);
                }
            else
                {
                // remove unneded instances
                for ($i = $instanceCount; $i < $componentCount; $i++)
                    unset ($this->components["e$i"]);
                }
            }
        else if (isset ($request["count"]))
            {
            $instanceCount = $request["count"];
            }

        if ($instanceCount < 1)
            $instanceCount = 1;
        $request["newinst"] = $instanceCount;
        $this->hiddenFields["count"] = $instanceCount;

        if ($this->isCreating)
            {
            $this->bulkInstanceCountField = new IntFieldTemplate ($this->getPrefix (), "newinst",
                                     $this->getText ("Instance count:"),
                                     $this->getText ("Simultaneously create several similar instances (based on the current values)"));
            }

        if (isset ($request["save"]))
            {
            $values = NULL;
            foreach ($this->getCommonFields () as $field)
                $values[$field->key] = $field->getValueForDB ($context, $request);

            foreach ($this->components as $component)
                {
                if (!$component->canSave ())
                    return true;
                }

            $ret = NULL;
            $count = count ($this->components);
            foreach ($this->components as $component)
                {
                $request = $component->getRequest ();
                $ret = $component->saveItem ($request, $values);
                if (1 == $count && NULL !== $ret)
                    {
                    return $component->redirectOnSuccess ();
                    }
                }
            }

        return true;
        }

    public function getMetaDescription ()
        {
        return NULL;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "bulkeditor";
        }

    public function getTitle ()
        {
        $title = NULL;
        foreach ($this->components as $component)
            {
            $newTitle = $component->getTitle ();
            if (NULL !== $title && $newTitle != $title)
                {
                $title = $this->getText ("Editing multiple instances ([_0], [_1], ...)", $title, $newTitle);
                break;
                }
            else
                $title = $newTitle;
            }

        return $title;
        }

    public function checkAccess ($request)
        {
        foreach ($this->components as $component)
            {
            if (false === $component->checkAccess ($request))
                return false;
            }
        return true;
        }

    public function setMode ($creating, $id)
        {
        foreach ($this->components as $component)
            {
            if (!method_exists ($component, "setMode"))
                {
                var_dump (get_class ($component));
                continue;
                }
            $component->setMode ($creating, $id);
            }

        $this->isCreating = $creating;
        $this->ids = $id;
        }
    }

<?php
require_once (PATH.'pages/componentfragment.php');
require_once (PATH.'pages/discussions.php');

class SearchFragment extends FragmentTemplate
    {
    const PARAM_TYPE = "normal";
    const TYPE_NORMAL = 0;
    const TYPE_COMPACT = 1;

    public function __construct ($context, $prefix, $table, $title = NULL, $description = NULL, $params = NULL)
        {
        parent::__construct ($context, $prefix, $table, $title, $description, $params);
        $context->addScriptFile ("autosuggest");
        $context->registerInitializeScript ($this->getInitializeScript ($context, $prefix));
        }

    public function getDisplayTemplateName ()
        {
        return "searchfragment";
        }

    public function getInitializeScript ($context, $id)
        {
        $url = $context->processUrl ("index.php?service=FullTextSearch", true);
        return "suggest_attachSearchField ('$id', '$url');";
        }

    protected function getAdditionalEditorFields ()
        {
        $arr = parent::getAdditionalEditorFields ();
        $types = array
                (
                self::TYPE_NORMAL => $this->getText ("Normal|search display"),
                self::TYPE_COMPACT => $this->getText ("Compact|search display"),
                );
        $arr[] = new DropDownFieldTemplate (self::PARAM_TYPE, self::PARAM_TYPE,
                                    $this->getText ("Display:|search fragment"), $this->getText ("How to display the fragment"), $types);

        return $arr;
        }

    public function getDisplayType ()
        {
        $param = empty ($this->params[self::PARAM_TYPE]) ? SearchFragment::TYPE_NORMAL : $this->params[self::PARAM_TYPE];
        
        switch ($param)
            {
            case SearchFragment::TYPE_COMPACT:
                return "search-compact";
            default:
                return "search-normal";
            }
        }
    public function getSearchLabel ()
        {
        return $this->getText ("Search");
        }
    public function getSearchString ()
        {
        return empty ($this->request["s"]) ? NULL : $this->request["s"];
        }

    public function getSearchUrl ()
        {
        return $this->context->processUrl ("search.php", true);
        }
    }


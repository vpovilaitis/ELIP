<?php
require_once (PATH.'inc/instanceeditor.php');
require_once (PATH.'admin/dropdown.php');
require_once (PATH.'inc/componentfactory.php');

class FragmentEditor extends InstanceEditor
    {
    protected $successCallback;
    protected $titleColumn;
    protected $descColumn;
    protected $typeColumn;
    protected $additionalFields;
    protected $showDescription;

    public function __construct ($prefix, $context, $showDescription = true, $additionalFields = NULL)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new FragmentsTable ($context);
        $this->additionalFields = $additionalFields;
        $this->showDescription = $showDescription;
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        if (!$this->initializeTemplateParts ($request, $isCreating))
            return NULL;
        $arr = array ($this->titleColumn, $this->typeColumn);
        if ($this->showDescription)
            $arr[] = $this->descColumn;
        if (!empty ($this->additionalFields))
            $arr = array_merge ($arr, $this->additionalFields);
        return $arr;
        }

    protected function prepareQuery (&$resultColumns, &$criteria, &$joins, &$params)
        {
        // skip $this->additionalFields - those fields have no corresponding column in the DB table
        $templateFields = array ($this->titleColumn, $this->typeColumn, $this->descColumn);
        foreach ($templateFields as &$field)
            {
            $field->prepareQuery ($resultColumns, $criteria, $joins, $params);
            }
        $resultColumns[] = FragmentsTable::COL_PARAMS;
        }

    protected function initializeTemplateParts ($request, $isCreating)
        {
        $prefix  = "mpcm";
        $this->titleColumn = new TextFieldTemplate ($prefix, FragmentsTable::COL_TITLE,
                                              $this->getText ("Title:"),
                                              $this->getText ("Page title."),
                                              32);
        $this->descColumn = new LongTextFieldTemplate ($prefix, FragmentsTable::COL_DESCRIPTION,
                                             $this->getText ("Description:"),
                                             $this->getText ("Brief page description."));

        $availableTypes = ComponentFactory::getRegisteredComponents ($this->context);
        $this->typeColumn = new DropDownFieldTemplate ($prefix, FragmentsTable::COL_TYPE,
                                             $this->getText ("Handler class:"),
                                             $this->getText ("Component handler class. Handler file should reside in pages directory, enter just file name (no path or extension)"),
                                             $availableTypes);

        return true;
        }

    protected function createRecord (&$request, $values)
        {
        $pageId = $this->getParentId (true);
        $adjustedValues = $values;
        $adjustedValues[FragmentsTable::COL_PAGEID] = $pageId;
        return parent::createRecord ($request, $adjustedValues);
        }

    protected function modifyRecord ($request, $id, $values)
        {
        // skip $this->additionalFields - those fields have no corresponding column in the DB table
        $params = array ();
        if (!empty ($this->additionalFields))
            {
            foreach ($this->additionalFields as $field)
                {
                if (array_key_exists ($field->key, $values))
                    {
                    $params[$field->key] = $values[$field->key];
                    unset ($values[$field->key]);
                    }
                }
            }

        $values[FragmentsTable::COL_PARAMS] = $params;

        return parent::modifyRecord ($request, $id, $values);
        }

    protected function addSafeguardCriterion (&$criteria, $initialValues, $key)
        {
        if ($key == FragmentsTable::COL_PARAMS)
            return true;
        return parent::addSafeguardCriterion ($criteria, $initialValues, $key);
        }

    protected function retrieveExisting ($request, $id)
        {
        $row = parent::retrieveExisting ($request, $id);
        if (empty ($row) || empty ($this->additionalFields))
            return $row;

        $params = $row[FragmentsTable::COL_PARAMS];
        foreach ($this->additionalFields as $field)
            {
            $row[$field->key] = empty ($params[$field->key]) ? NULL : $params[$field->key];
            }

        return $row;
        }

    public function getPageTitle ($isCreating = false)
        {
        return $isCreating ? $this->getText ("Adding a page component") : $this->getText ("Modify the page component");
        }

    public function registerSuccessCallback ($callback)
        {
        $this->successCallback = $callback;
        }

    protected function showSuccessPage ($request)
        {
        if (!empty ($this->successCallback))
            {
            $this->addMessage ("Fragment saved successfuly");
            call_user_func ($this->successCallback);
            return true;
            }

        return parent::showSuccessPage ($request);
        }
    }

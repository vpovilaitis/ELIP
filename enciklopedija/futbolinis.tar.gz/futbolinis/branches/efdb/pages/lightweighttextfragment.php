<?php
require_once (PATH.'pages/textfragment.php');

class LightWeightTextFragment extends TextFragment
    {
    public function getTemplateName ()
        {
        if ($this->inEditorMode ())
            return parent::getTemplateName ();
        return "justtext";
        }

    public function getCssClass ()
        {
        return "justtext";
        }
    }

<?php

class EditorTasks extends ReaderPage
    {
    public function __construct ($context)
        {
        parent::__construct ($context, "", Constants::TABLES_USER);
        }

    public function getTemplateName ()
        {
        return "pages/editortasks";
        }

    public function getWelcomeText ()
        {
        return $this->getText ("There are pending tasks for the editors:");
        }

    public function getNoTasksText ()
        {
        return $this->getText ("There are no pending tasks for the editors.");
        }

    public function getTaskGroups ()
        {
        $taskClassNames = ComponentFactory::getEditorTaskHandlers ($this->context);
        $context = $this->context;
        $result = array ();
        foreach ($taskClassNames as $className)
            {
            $class = $context->parseCustomClass ($className, "h");
            $instance = NULL;
            if (!empty ($class))
                $instance = new $class ($context, $className);
            if (empty ($instance))
                {
                $result[] = array ("name" => $this->getText ("Error"), "complexity" => $this->getText ("none"), "time" => NULL);
                continue;
                }

            $result[] = array ("name" => $instance->getName (),
                               "nameWithCount" => $instance->getNameWithCount (),
                               "complexity" => $this->getText ("Complexity: [_0]", $instance->getComplexityLabel ()),
                               "time" => $instance->getTimeLabel (),
                               "url" => $instance->getUrl (),
                               "image" => $instance->getImage (),
                               "title" => $instance->getTitle (),
                               "description" => $instance->getDetailedDescription (),
                               "count" => $instance->getCountLabel ());
            }
        return $result;
        }
    }
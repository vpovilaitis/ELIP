<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'inc/instanceeditor.php');

class EditorPage extends Page
    {
    protected $component;

    public function __construct ($context, $request)
        {
        parent::__construct ($context, NULL);
        }

    protected function createEditorComponent ($prefix, $context)
        {
        return new InstanceEditor ($prefix, $context);
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if (!empty ($this->component))
            return true;

        if (isset ($request["i"]))
            {
            $class = $context->parseCustomClass ($request["i"], NULL);
            if (empty ($class))
                {
                $this->displayErrorPage ($context->getText ("Display handler not found"));
                return false;
                }
                
            $this->component = new $class (NULL, $context);
            }
        else
            $this->component = $this->createEditorComponent (NULL, $context);

        $creating = isset ($request["action"]) ? "new" == $request["action"] : false;
        $id = isset ($request["id"]) ? $request["id"] : NULL;

        if (method_exists ($this->component, "setMode"))
            $this->component->setMode ($creating, $id);

        $this->addComponent ($request, "", $this->component);
        return true;
        }

    public function ensureTitle ($context, &$request)
        {
        parent::ensureTitle ($context, $request);

        if (!$this->ensureChildren ($context, $request))
            return false;

        $title = $this->component->getTitle ();

        if (!empty ($title))
            $this->context->setTitle ($title);

        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    protected function checkAccess ($request)
        {
        $this->ensureChildren ($this->context, $request);
        $accessGranted = $this->component->checkAccess ($request);

        if (NULL === $accessGranted)
            $accessGranted = false;

        if (false === $accessGranted)
            $this->log ("No access to show editor page (".get_class ($this->component).")");

        return $accessGranted;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function getTemplateName ()
        {
        return "simplepage";
        }
    }

<?php

require_once (PATH.'inc/preview.php');

class HintList extends ReaderPage
    {
    public function __construct ($context, $request)
        {
        parent::__construct ($context, NULL, HintsTable::TABLE_SCOPE, HintsTable::TABLE_NAME);
        }

    public function ensureTitle ($context, &$request)
        {
        $this->ensureChildren ($context, $request);
        $context->setTitle ($this->getText ("List of the hints"));
        return true;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function getTemplateName ()
        {
        return "dynamicpage";
        }

    public function getActionList ()
        {
        return NULL;
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if (!empty ($this->component))
            return true;
        
        $scope = !empty ($request["sc"]) ? $request["sc"] : NULL; 
        $contextMode = !empty ($request["cmode"]) ? $request["cmode"] : NULL; 
        $group = !empty ($request["grp"]) ? $request["grp"] : NULL; 
        $id = !empty ($request["id"]) ? $request["id"] : NULL; 
        $this->component = new HintsPreview ($context, $scope, $contextMode,
                                             $group, $id);
        $this->addComponent ($request, "p", $this->component);
        return true;
        }
    }

class HintsPreview extends Preview
    {
    protected $scope;
    protected $contextMode;
    protected $group;
    protected $entryId;

    public function __construct ($context, $scope, $contextMode, $group, $id)
        {
        parent::__construct ("hintlist", $context, new HintsTable ($context));
        $this->scope = $scope;
        $this->contextMode = $contextMode;
        $this->group = $group;
        $this->entryId = $id;
        }

    protected function getDisplayTemplate ()
        {
        if ($this->context->getCurrentUser() <= 0)
            return array
            (
            new LabelFieldTemplate ("col", HintsTable::COL_TITLE, $this->context->getText ('Title')),
            new LabelFieldTemplate ("col", HintsTable::COL_DETAILS, $this->context->getText ('Hint body')),
            );

        return array
            (
            new LabelFieldTemplate ("col", HintsTable::COL_SCOPE, $this->context->getText ('Scope')),
            new LabelFieldTemplate ("col", HintsTable::COL_CONTEXT, $this->context->getText ('Context')),
            new LabelFieldTemplate ("col", HintsTable::COL_CONTEXTID, $this->context->getText ('Entry')),
            new LabelFieldTemplate ("col", HintsTable::COL_TARGETAUDIENCE, $this->context->getText ('Target user')),
            new LabelFieldTemplate ("col", HintsTable::COL_TITLE, $this->context->getText ('Title')),
            new LabelFieldTemplate ("col", HintsTable::COL_DETAILS, $this->context->getText ('Hint body')),
            );
        }

    public function getTitle ()
        {
        return $this->getText ("List of the hints");
        }

    public function processInput ($context, &$request)
        {
        if (!parent::processInput ($context, $request))
            return false;

        return true;
        }

    protected function getFilterCriteria ()
        {
        $criteria = NULL;
        if (!empty ($this->scope))
            $criteria[] = new LogicalOperatorOr (new EqCriterion (HintsTable::COL_SCOPE, $this->scope),
                                                 new EqCriterion (HintsTable::COL_SCOPE, Constants::ANY));
        if (!empty ($this->contextMode))
            $criteria[] = new LogicalOperatorOr (new EqCriterion (HintsTable::COL_CONTEXT, $this->contextMode),
                                                 new EqCriterion (HintsTable::COL_CONTEXT, HintsTable::CONTEXT_ANY));

        if ($this->context->getCurrentUser() <= 0 &&  !empty ($this->group))
            $criteria[] = new LogicalOperatorOr (new EqCriterion (HintsTable::COL_TARGETAUDIENCE, $this->group),
                                                 new EqCriterion (HintsTable::COL_TARGETAUDIENCE, HintsTable::TARGET_ANY));

        if (!empty ($this->id))
            $criteria[] = new LogicalOperatorOr (new EqCriterion (HintsTable::COL_CONTEXTID, $this->id),
                                                 new EqCriterion (HintsTable::COL_CONTEXTID, Constants::ANY));
        $criteria[] = new LikeCriterion (DBTable::COL_LANG, $this->context->getLanguage ());
        return $criteria;
        }

    public function select ($context, $criteria = NULL)
        {
        return parent::select ($context, $criteria);
        }

    protected function getEditorAction ($new, $title = NULL, $editorLink = NULL, $params = NULL)
        {
        if (empty ($editorLink))
            $editorLink = "pages/HintEditor";
        if (empty ($title))
            $title = $new ? $this->getText ("Add new hint") : $this->getText ("Modify hint");

        $params = array ();
        if (!empty ($this->scope))
            $params[] = "sc={$this->scope}";
        if (!empty ($this->contextMode))
            $params[] = "cmode={$this->contextMode}";
        if (!empty ($this->group))
            $params[] = "grp={$this->group}";
        if (!empty ($this->entryId))
            $params[] = "eid={$this->entryId}";

        return parent::getEditorAction ($new, $title, $editorLink, $new ? implode ("&", $params) : NULL);
        }

    }

?>

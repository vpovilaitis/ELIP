<?php
require_once (PATH.'pages/fragmenttemplate.php');

class TextFragment extends FragmentTemplate
    {
    protected function getAdditionalEditorFields ()
        {
        $arr = parent::getAdditionalEditorFields ();
        $arr[] = new FieldTemplate (self::PARAM_LINK, self::PARAM_LINK, "text",
                                    $this->getText ("Url:"), $this->getText ("Url to use in header"));
        $arr[] = new FieldTemplate (self::PARAM_ICONMORE, self::PARAM_ICONMORE, "text",
                                    $this->getText ("Icon (more):"), $this->getText ("Icon to use in 'more...' link"));
        $arr[] = new FieldTemplate (self::PARAM_HEIGHT, self::PARAM_HEIGHT, "text",
                                    $this->getText ("Height:"), $this->getText ("Optional height of the content"));

        return $arr;
        }

    public function getDisplayTemplateName ()
        {
        return "textfragment";
        }

    }

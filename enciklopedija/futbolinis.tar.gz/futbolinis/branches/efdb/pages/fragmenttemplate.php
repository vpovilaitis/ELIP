<?php
require_once (PATH.'pages/simpletext.php');
require_once (PATH.'pages/fragmenteditor.php');

class FragmentTemplate extends SimpleText
    {
    protected $fragmentsTable;
    protected $id;
    protected $component;
    public $inline = false;
    public $editMode = false;
    protected $parentPath;
    protected $params;

    const PARAM_ICON = "icon";
    const PARAM_LINK = "link";
    const PARAM_ICONMORE = "iconMore";
    const PARAM_HEIGHT = "height";

    public function __construct ($context, $prefix, $table, $title = NULL, $description = NULL, $params = NULL)
        {
        $this->fragmentsTable = new FragmentsTable ($context);
        parent::__construct ($context, $prefix, $this->fragmentsTable, $title, $description);
        $this->params = $params;
        }

    public function getTemplateName ()
        {
        if ($this->inEditorMode ())
            return "editfragment";
        return $this->getDisplayTemplateName ();
        }

    public function getDisplayTemplateName ()
        {
        return "simpletext";
        }

    public function ensureChildren ($context, $request)
        {
        if (!empty ($this->component))
            return true;
        if ($this->inEditorMode ())
            {
            $this->component = new FragmentEditor ("c", $this->context, $this->getShowDescription (), $this->getAdditionalEditorFields ());
            $this->component->setMode (false, $this->id);
            $this->component->registerSuccessCallback (array ($this, "onSave"));
            $this->addComponent ($request, "component", $this->component);
            }
        else
            $this->createComponents ($context, $request);

        return true;
        }

    protected function getAdditionalEditorFields ()
        {
        $arr[] = new FieldTemplate (self::PARAM_ICON, self::PARAM_ICON, "text",
                                    $this->getText ("Icon:"), $this->getText ("Icon to use in header"));
        return $arr;
        }

    public function getIcon ()
        {
        if (empty ($this->params[self::PARAM_ICON]))
            return NULL;
        return $this->context->getResourcePath ("img", $this->params[self::PARAM_ICON]);
        }

    public function getMoreIcon ()
        {
        if (empty ($this->params[self::PARAM_ICONMORE]))
            return $this->getIcon ();
        return $this->context->getResourcePath ("img", $this->params[self::PARAM_ICONMORE]);
        }

    public function getUrl ()
        {
        if (empty ($this->params[self::PARAM_LINK]))
            return NULL;
        return $this->params[self::PARAM_LINK];
        }

    public function getHeight ()
        {
        if (empty ($this->params[self::PARAM_HEIGHT]))
            return NULL;
        return $this->params[self::PARAM_HEIGHT];
        }

    protected function getShowDescription ()
        {
        return true;
        }

    protected function createComponents ($context, $request)
        {
        return true;
        }

    public function toggleEditMode ($id, $parentPath)
        {
        $this->editMode = true;
        $this->id = $id;
        $this->parentPath = $parentPath;
        $this->ensureChildren ($this->context, $this->request);
        }

    public function onSave ()
        {
        $this->editMode = false;
        unset ($this->components["component"]);
        $hierarchy = $this->fragmentsTable->selectFragmentHierarchyByPath ($this->id, $this->parentPath, true);
        $this->title = $hierarchy->row[FragmentsTable::COL_TITLE];
        $this->description = $hierarchy->row[FragmentsTable::COL_DESCRIPTION];
        }

    public function inEditorMode ()
        {
        if (!$this->editMode)
            return false;
        if (!$this->fragmentsTable->canEdit ())
            return false;
        return true;
        }

    }


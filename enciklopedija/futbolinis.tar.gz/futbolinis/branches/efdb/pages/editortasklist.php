<?php
require_once (PATH.'pages/editorpage.php');

class EditorTaskList extends EditorPage
    {
    protected function createEditorComponent ($prefix, $context)
        {
        $className = empty ($this->context->request["task"]) ? NULL : $this->context->request["task"];
        if (empty ($className))
            return new ErrorComponent ($prefix, $context, $this->getText ("Task name missing"));

        $class = $context->parseCustomClass ($className, "h");
        $instance = NULL;
        if (!empty ($class))
            $instance = new $class ($context, $className);
            
        if (empty ($instance))
            return new ErrorComponent ($prefix, $context, $this->getText ("Task unrecognized"));

        return $instance->createListComponent ($prefix, $context);
        }

    public function getActionList ()
        {
        return NULL;
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function getSubTitle ()
        {
        return NULL;
        }

    public function getTemplateName ()
        {
        return "dynamicpage";
        }
    }

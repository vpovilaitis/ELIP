<?php

require_once (PATH.'inc/instanceview.php');
require_once (PATH.'inc/newstable.php');

class NewsItem extends InstanceView
    {
    protected $dbtable;

    public function __construct ($context)
        {
        parent::__construct ("nitem", $context);
        $scope = !empty ($_REQUEST["sp"]) ? $_REQUEST["sp"] : false;
        $this->dbtable = new NewsTable ($context, $scope);
        }

    public function selectInstance ()
        {
        if (!empty ($this->instance))
            return $this->instance;

        $ids = $this->getIds ();
        if (empty ($ids))
            return NULL;

        $columns = array (NewsTable::COL_ID, NewsTable::COL_TITLE, NewsTable::COL_OVERVIEW, NewsTable::COL_DETAILS, DBTable::COL_CREATEDON, NewsTable::COL_HIDDEN);
        $columns[] = new ConditionalResultColumn (NewsTable::RESULTCOL_DATE, NewsTable::COL_ENTRY_DATE." IS NULL", DBTable::COL_CREATEDON, NewsTable::COL_ENTRY_DATE);
        $criteria = array (new EqCriterion (NewsTable::COL_ID, $ids[0]));
        $this->instance = $this->dbtable->selectSingleBy ($columns, $criteria);
        if (!empty ($this->instance))
            {
            $lng = Language::getInstance ($this->context);
            $this->instance[NewsTable::COL_TITLE] = NewsTable::getEntryTitle ($this->context, $lng, $this->instance, NewsTable::RESULTCOL_DATE);
            $this->instance[NewsTable::RESULTCOL_DATE] = $lng->dateToLongString ($this->instance[NewsTable::RESULTCOL_DATE]);
            if (empty ($this->instance[NewsTable::COL_DETAILS]))
                $this->instance[NewsTable::COL_DETAILS] = $this->instance[NewsTable::COL_OVERVIEW];

            $description = $this->instance[NewsTable::COL_DETAILS];
            if (!empty ($description))
                $this->context->setMetaParam ("Description", $this->context->removeFormat ($description, 300));
            }

        return $this->instance;
        }

    public function getPageTitle ()
        {
        $instance = $this->selectInstance ();
        return empty ($instance) ? $this->getText ("News item not found") : $instance[NewsTable::COL_TITLE];
        }

    public function getActionList ()
        {
        $actions = array ();
        if ($this->dbtable->canEdit())
            $actions[] = new SingleRowURL ($this, "edit", $this->context->getText ("Edit"), "index.php?c=EditorPage&i=pages/NewsEditor&action=edit");

        // add "Discussions" link
        $discussionstable = new DiscussionsTable ($this->context);
        if ($discussionstable->canRead ())
            {
            $table = NewsTable::TABLE_NAME;
            $instance = $this->selectInstance ();
            $id = $this-> getId ($instance);
            $url = $this->context->chooseUrl ("talk/$table/$id",
                                              "index.php?c=Discussions&sc=$table&id=$id");
            $title = $this->getText ("Discussions");
            $actions[] = new SimpleLinkAction ($this, "discuss", $title, $url, true);
            }
        
        $actions[] = new DeleteIcon ($this, $this->dbtable);
        return $actions;
        }

    public function getId ($entry)
        {
        return $entry[NewsTable::COL_ID];
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "newsitem";
        }

    public function retrieveImageContext ($instance, $zone, $width, $height, $canRotate = true)
        {
        $scope = NewsTable::TABLE_NAME;
        $id = $this->getId ($instance);
        return parent::getImageContext ($scope, $id, $zone, $width, $height, $canRotate);
        }

    }

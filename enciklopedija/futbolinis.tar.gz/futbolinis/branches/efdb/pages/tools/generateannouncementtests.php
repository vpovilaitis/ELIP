<?php
require_once (PATH.'inc/dbtabletestcollection.php');
require_once (PATH.'inc/compositetestcollection.php');
require_once (PATH.'pages/sports/generatematchannouncement.php');

class GenerateAnnouncementTests extends CompositeTestCollection
    {
    protected $createdInstanceTracker;

    public function __construct ($prefix, $context, $parent)
        {
        parent::__construct ($prefix, $context, $parent);
        $this->createdInstanceTracker = new CreatedTestInstances ();
        }
    
    public function run ($context, $diagnoseTest = NULL, $atomic = false)
        {
        return parent::run ($context, $diagnoseTest, true);
        }

    public function enumerateTests ($context)
        {
        $tests = parent::enumerateTests ($context);

        foreach ($this->getTestCases () as $match => $expectedOutput)
            {
            $test = $this->createMatchAnnouncementTest ($match, $expectedOutput);
            $test->setInstanceTracker ($this->createdInstanceTracker);
            $tests[] = $test;
            }

        return $tests;
        }

    public function matchAnnouncement ($context, $input)
        {
        $generatePreseason = false;
        if (preg_match ("/^(.+) \(PRE\)$/", $input, $match) > 0)
            {
            $generatePreseason = true;
            $input = $match[1];
            }

        $matchId = $this->createdInstanceTracker->getId ($input);
        if (!$matchId)
            {
            $context->addError ("Instance '$input' was not created");
            return false;
            }

        $processor = new GenerateMatchAnnouncement ($context, NULL);
        $processor->generateAnnouncementForMatch ($this->context, $matchId, 0, $generatePreseason, false);
        return $processor->getResultOutput (true);
        }

    protected function skipWhiteSpace ($text)
        {
        return trim (preg_replace ("#[\r\n ]+#m", " ", $text));
        }

    public function validateMatchAnnouncement ($context, $actualOutput, $expectedOutput)
        {
        foreach ($this->createdInstanceTracker->getCollected () as $id => $label)
            {
            $expectedOutput = str_replace ("@$label@", $id, $expectedOutput);
            }

        return $this->skipWhiteSpace ($actualOutput) == $this->skipWhiteSpace ($expectedOutput);
        }
        
    protected function createMatchAnnouncementTest ($match, $expectedResults)
        {
        return parent::createTest ("Announcement: $match", $match, array ($this, "matchAnnouncement"), $expectedResults, array ($this, "validateMatchAnnouncement"), "MatchAnnouncementTest");
        }

    public function enumerateDependencies ($context, $parent)
        {
        return array
            (
            new AnnouncementSeasonTests ("dep_seas", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new AnnouncementStadiumTests ("dep_stad", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new AnnouncementLeagueTests ("dep_leag", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new AnnouncementCompetitionSeasonsTests ("dep_cs", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new AnnouncementClubTests ("dep_club", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new AnnouncementTeamTests ("dep_team", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new AnnouncementMatchTests ("dep_match", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            );
        }
    
    protected function getTestCases ()
        {
        return array
        (
        "2006-01-01 Zalgiris-Panerys" =>
"2006 m. sausio 1 d. 19.00 val. draugiškose rungtynėse [[stadium:@Zalgiris stadium@|Vilniaus „Žalgirio“ stadione]]
 susitinka [[team:@Zalgiris@|Vilniaus „Žalgiris“]] ir [[team:@Panerys@|Nemenčinės „Panerys“]].",

        "2006-02-02 Panerys-Zalgiris" =>
<<<EOT
2006 m. vasario 2 d. 19.00 val. draugiškose rungtynėse [[stadium:@Nemencine stadium@|Nemenčinės miesto stadione]]
susitinka [[team:@Panerys@|Nemenčinės „Panerys“]] ir [[team:@Zalgiris@|Vilniaus „Žalgiris“]].
Vieninteles tarpusavio rungtynes 2006 m. sausio 1 d. [[stadium:@Zalgiris stadium@|Vilniaus „Žalgirio“ stadione]] rezultatu 3:1 laimėjo [[team:@Zalgiris@|Vilniaus „Žalgiris“]].
EOT
,

        "2005-02-02 Pakruojis-Panerys" =>
<<<EOT
2005 m. vasario 2 d. 19.00 val. [[competitionstage:@2005 A lyga@|A lygos]] rungtynėse
[[stadium:@Pakruojis stadium@|Pakruojo stadione]]
susitinka [[team:@Pakruojis@|Pakruojo FK]] ir [[team:@Panerys@|Nemenčinės „Panerys“]].
Vienintelės tarpusavio rungtynės 2005 m. sausio 1 d. [[stadium:@Pakruojis stadium@|Pakruojo stadione]] baigėsi lygiosiomis rezultatu 1:1.
EOT
,
        "2005-04-04 Pakruojis-Panerys" =>
<<<EOT
2005 m. balandžio 4 d. 19.00 val. [[competitionstage:@2005 A lyga@|A lygos]] rungtynėse
[[stadium:@Pakruojis stadium@|Pakruojo stadione]]
susitinka [[team:@Pakruojis@|Pakruojo FK]] ir [[team:@Panerys@|Nemenčinės „Panerys“]].
Paskutines tarpusavio rungtynes 2005 m. kovo 3 d. [[stadium:@Pakruojis stadium@|Pakruojo stadione]] rezultatu 1:0 laimėjo [[team:@Pakruojis@|Pakruojo FK]].
Iš viso nuo 2005 m. komandos tarpusavyje sužaidė 3 rungtynės, [[team:@Pakruojis@|Pakruojo FK]] laimėjo 1 kartą, 2 rungtynės baigėsi lygiosiomis, įvarčių santykis - 2:1 Pakruojo FK naudai.
EOT
,
        "2006-06-06 Pakruojis-Panerys" =>
<<<EOT
2006 m. birželio 6 d. 12.00 val. [[competitionstage:@2006 A lyga@|A lygos]] rungtynėse
[[stadium:@Nemencine stadium@|Nemenčinės miesto stadione]]
susitinka [[team:@Panerys@|Nemenčinės „Panerys“]] ir [[team:@Pakruojis@|Pakruojo FK]].
Paskutinės tarpusavio rungtynės 2006 m. gegužės 5 d. [[stadium:@Pakruojis stadium@|Pakruojo stadione]] baigėsi lygiosiomis rezultatu 1:1.
Iš viso nuo 2005 m. komandos tarpusavyje sužaidė 6 rungtynės, [[team:@Pakruojis@|Pakruojo FK]] laimėjo 3 kartus, 3 rungtynės baigėsi lygiosiomis, įvarčių santykis - 7:3 Pakruojo FK naudai.

A lygos tarpusavio runtynių statistika: 
Paskutinės tarpusavio rungtynės 2006 m. gegužės 5 d. [[stadium:@Pakruojis stadium@|Pakruojo stadione]] baigėsi lygiosiomis rezultatu 1:1.
Iš viso nuo 2005 m. komandos tarpusavyje sužaidė 5 rungtynės, [[team:@Pakruojis@|Pakruojo FK]] laimėjo 2 kartus, 3 rungtynės baigėsi lygiosiomis, įvarčių santykis - 4:2 Pakruojo FK naudai.

Tarpusavio runtynių statistika Nemenčinės miesto stadione: Vieninteles tarpusavio rungtynes 2006 m. balandžio 1 d.
[[stadium:@Nemencine stadium@|Nemenčinės miesto stadione]] rezultatu 3:1 laimėjo [[team:@Pakruojis@|Pakruojo FK]].
EOT
,
        "2010-02-18 Suduva-Klaipeda (PRE)" =>
<<<EOT
2010 m. vasario 18 d. 19.00 val. draugiškose rungtynėse [[stadium:@Marijampole@|Marijampolės manieže]]
susitinka [[team:@Suduva@|Marijampolės „Sūduva“]] ir [[team:@FK Klaipeda@|Klaipėdos FK]].

Šiemet [[team:@Suduva@|Marijampolės „Sūduva“]] vienintelėse rungtynėse 2010 m. vasario 13 d.
[[stadium:@Marijampole@|Marijampolės manieže]] laimėjo prieš Nemenčinės „Panerio“ komandą rezultatu 1:0.

Šiemet [[team:@FK Klaipeda@|Klaipėdos FK]] žaidė vieninteles ikisezonines rungtynes 2010 m. vasario 13 d.
[[stadium:@Marijampole@|Marijampolės manieže]] prieš Pakruojo FK komandą, su kuria sužaidė lygiosiomis 1:1.

EOT
,
        );
        }
    }

class AnnouncementMatchTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_MATCH_HOMETEAM => NULL,
                                Sports::COL_MATCH_AWAYTEAM => NULL,
                                Sports::COL_MATCH_HOMERESULT => NULL,
                                Sports::COL_MATCH_AWAYRESULT => NULL,
                                Sports::COL_MATCH_DATE => NULL,
                                Sports::COL_MATCH_COMPETITION => NULL,
                                Sports::COL_MATCH_STADIUM => NULL,
                                Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                );
        $list[] = $this->createInsertTest ("2006-01-01 Zalgiris-Panerys",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Zalgiris"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_HOMERESULT => 3,
                                               Sports::COL_MATCH_AWAYRESULT => 1,
                                               Sports::COL_MATCH_DATE => "2006-01-01 19:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Zalgiris stadium"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2006-02-02 Panerys-Zalgiris",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Zalgiris"),
                                               Sports::COL_MATCH_HOMERESULT => 1,
                                               Sports::COL_MATCH_AWAYRESULT => 1,
                                               Sports::COL_MATCH_DATE => "2006-02-02 19:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Nemencine stadium"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009-05-05 VMFD Zalgiris-Panerys",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("VMFD"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_HOMERESULT => 2,
                                               Sports::COL_MATCH_AWAYRESULT => 1,
                                               Sports::COL_MATCH_DATE => "2009-05-05 19:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Vingis stadium"),
                                               ),
                                        $defaultValues, $createdInstances);

                                        
        $list[] = $this->createInsertTest ("2005-01-01 Pakruojis-Panerys",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Pakruojis"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_HOMERESULT => 1,
                                               Sports::COL_MATCH_AWAYRESULT => 1,
                                               Sports::COL_MATCH_DATE => "2005-01-01 19:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Pakruojis stadium"),
                                               Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2005 A lyga"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2005-02-02 Pakruojis-Panerys",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Pakruojis"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_HOMERESULT => 0,
                                               Sports::COL_MATCH_AWAYRESULT => 0,
                                               Sports::COL_MATCH_DATE => "2005-02-02 19:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Pakruojis stadium"),
                                               Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2005 A lyga"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2005-03-03 Pakruojis-Panerys",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Pakruojis"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_HOMERESULT => 1,
                                               Sports::COL_MATCH_AWAYRESULT => 0,
                                               Sports::COL_MATCH_DATE => "2005-03-03 19:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Pakruojis stadium"),
                                               Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2005 A lyga"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2005-04-04 Pakruojis-Panerys",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Pakruojis"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_HOMERESULT => 1,
                                               Sports::COL_MATCH_AWAYRESULT => 0,
                                               Sports::COL_MATCH_DATE => "2005-04-04 19:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Pakruojis stadium"),
                                               Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2005 A lyga"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2006-05-05 Pakruojis-Panerys",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Pakruojis"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_HOMERESULT => 1,
                                               Sports::COL_MATCH_AWAYRESULT => 1,
                                               Sports::COL_MATCH_DATE => "2006-05-05 17:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Pakruojis stadium"),
                                               Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2006 A lyga"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2006-04-01 Pakruojis-Panerys",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Pakruojis"),
                                               Sports::COL_MATCH_HOMERESULT => 1,
                                               Sports::COL_MATCH_AWAYRESULT => 3,
                                               Sports::COL_MATCH_DATE => "2006-04-01 17:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Nemencine stadium"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2006-06-06 Pakruojis-Panerys",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Pakruojis"),
                                               Sports::COL_MATCH_HOMERESULT => 3,
                                               Sports::COL_MATCH_AWAYRESULT => 1,
                                               Sports::COL_MATCH_DATE => "2006-06-06 12:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Nemencine stadium"),
                                               Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2006 A lyga"),
                                               ),
                                        $defaultValues, $createdInstances);





        $list[] = $this->createInsertTest ("2010-02-13 Klaipeda-Pakruojis",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("FK Klaipeda"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Pakruojis"),
                                               Sports::COL_MATCH_HOMERESULT => 1,
                                               Sports::COL_MATCH_AWAYRESULT => 1,
                                               Sports::COL_MATCH_DATE => "2010-02-13 17:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Marijampole"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2010-02-13 Suduva-Panerys",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Suduva"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Panerys"),
                                               Sports::COL_MATCH_HOMERESULT => 1,
                                               Sports::COL_MATCH_AWAYRESULT => 0,
                                               Sports::COL_MATCH_DATE => "2010-02-13 15:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Marijampole"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2010-02-18 Suduva-Klaipeda",
                                        array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Suduva"),
                                               Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("FK Klaipeda"),
                                               Sports::COL_MATCH_HOMERESULT => 5,
                                               Sports::COL_MATCH_AWAYRESULT => 2,
                                               Sports::COL_MATCH_DATE => "2010-02-18 19:00:00",
                                               Sports::COL_MATCH_OUTCOME => MatchConstants::OUTCOME_FULL_TIME,
                                               Sports::COL_MATCH_STADIUM => new InstanceIdPlaceholder ("Marijampole"),
                                               ),
                                        $defaultValues, $createdInstances);
        return $list;
        }
    }

class MatchAnnouncementTest extends CallbackTest
    {
    protected function prepareOutputForDisplay ($context, $output)
        {
        $output = preg_replace_callback ("/@([^@]+)@/mu", array ($this, "replaceIdentifiers"), $output);
        $output = preg_replace ("/([\\r\\n]|\s)+/mu", " ", $output);
        $output = preg_replace ("/\. ([\[A-ZŽĄČŠ])/u", ".\n$1", $output);
        return $output;
        }

    public function replaceIdentifiers ($matches)
        {
        $id = $this->createdInstanceTracker->getId ($matches[1]);
        if (false !== $id)
            return $id;
        return $matches[1];
        }

    public function setInstanceTracker ($createdInstanceTracker)
        {
        $this->createdInstanceTracker = $createdInstanceTracker;
        }
    }

class AnnouncementTeamTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_TEAM_CLUB => NULL,
                                Sports::COL_TEAM_TYPE => NULL,
                                "c_".Sports::COL_TEAM_PREFIX => NULL,
                                "c_".Sports::COL_TEAM_NAME => NULL,
                                "c_".Sports::COL_TEAM_CITY => NULL,
                                Sports::COL_TEAM_DECLINE => NULL,
                                Sports::COL_TEAM_SHOWPREFIX => NULL,
                                );
        $list[] = $this->createInsertTest ("VMFD",
                                        array (Sports::COL_TEAM_CLUB => new InstanceIdPlaceholder ("FC Zalgiris"),
                                               Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "VMFD",
                                               "c_".Sports::COL_TEAM_NAME => "Žalgiris",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               Sports::COL_TEAM_DECLINE => true,
                                               Sports::COL_TEAM_SHOWPREFIX => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Zalgiris",
                                        array (Sports::COL_TEAM_CLUB => new InstanceIdPlaceholder ("FC Zalgiris"),
                                               Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Žalgiris",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Panerys",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Panerys",
                                               "c_".Sports::COL_TEAM_CITY => "Nemenčinė",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Pakruojis",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "",
                                               "c_".Sports::COL_TEAM_CITY => "Pakruojis",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("FK Klaipeda",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "",
                                               "c_".Sports::COL_TEAM_CITY => "Klaipėda",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Suduva",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Sūduva",
                                               "c_".Sports::COL_TEAM_CITY => "Marijampolė",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);

        return $list;
        }
    }

class AnnouncementClubTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_CLUB);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_CLUB_CITY => NULL,
                                Sports::COL_CLUB_NAME => NULL,
                                Sports::COL_CLUB_PREFIX => NULL,
                                );
        $list[] = $this->createInsertTest ("FC Zalgiris",
                                        array (Sports::COL_CLUB_CITY => "Vilnius",
                                               Sports::COL_CLUB_NAME => "Žalgiris",
                                               Sports::COL_CLUB_PREFIX => NULL,
                                               ),
                                        $defaultValues, $createdInstances);

        return $list;
        }
    }

class AnnouncementStadiumTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_STADIUM);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_STADIUM_CITY => NULL,
                                Sports::COL_STADIUM_NAME => NULL,
                                );
        $list[] = $this->createInsertTest ("Zalgiris stadium",
                                        array (Sports::COL_STADIUM_CITY => "Vilnius",
                                               Sports::COL_STADIUM_NAME => "„Žalgirio“ stadionas",
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Nemencine stadium",
                                        array (Sports::COL_STADIUM_CITY => "Nemenčinė",
                                               Sports::COL_STADIUM_NAME => "miesto stadionas",
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Vingis stadium",
                                        array (Sports::COL_STADIUM_CITY => "Vilnius",
                                               Sports::COL_STADIUM_NAME => "Vingio parko stadionas",
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Pakruojis stadium",
                                        array (Sports::COL_STADIUM_CITY => "Pakruojis",
                                               Sports::COL_STADIUM_NAME => "stadionas",
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Marijampole",
                                        array (Sports::COL_STADIUM_CITY => "Marijampolė",
                                               Sports::COL_STADIUM_NAME => "maniežas",
                                               ),
                                        $defaultValues, $createdInstances);

        return $list;
        }
    }

class AnnouncementLeagueTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_LEAGUE);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_LEAGUE_NAME => NULL,
                                );
        $list[] = $this->createInsertTest ("A lyga",
                                        array (Sports::COL_LEAGUE_NAME => "A lyga",
                                               ),
                                        $defaultValues, $createdInstances);
        return $list;
        }
    }

class AnnouncementSeasonTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_SEASON);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_SEASON_NAME => NULL,
                                Sports::COL_SEASON_START => NULL,
                                Sports::COL_SEASON_END => NULL,
                                );
        $list[] = $this->createInsertTest ("2005 m.",
                                        array (Sports::COL_SEASON_NAME => "1901 m.",
                                               Sports::COL_SEASON_START => 1901,
                                               Sports::COL_SEASON_END => 1901),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2006 m.",
                                        array (Sports::COL_SEASON_NAME => "1902 m.",
                                               Sports::COL_SEASON_START => 1902,
                                               Sports::COL_SEASON_END => 1902),
                                        $defaultValues, $createdInstances);
        return $list;
        }
    }

class AnnouncementCompetitionSeasonsTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_COMPETITION_NAME => NULL,
                                Sports::COL_COMPETITION_LEVEL => NULL,
                                Sports::COL_COMPETITION_LEAGUE => NULL,
                                );
        $list[] = $this->createInsertTest ("2005 A lyga",
                                        array (Sports::COL_COMPETITION_NAME => "A lyga",
                                               Sports::COL_COMPETITION_LEVEL => 1,
                                               Sports::COL_COMPETITION_LEAGUE => new InstanceIdPlaceholder ("A lyga"),
                                               Sports::COL_COMPETITION_SEASON => "2005 m.",
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2006 A lyga",
                                        array (Sports::COL_COMPETITION_NAME => "A lyga",
                                               Sports::COL_COMPETITION_LEVEL => 1,
                                               Sports::COL_COMPETITION_LEAGUE => new InstanceIdPlaceholder ("A lyga"),
                                               Sports::COL_COMPETITION_SEASON => "2006 m.",
                                               ),
                                        $defaultValues, $createdInstances);
        return $list;
        }
    }

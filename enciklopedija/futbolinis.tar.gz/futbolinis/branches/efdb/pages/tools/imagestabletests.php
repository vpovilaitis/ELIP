<?php
require_once (PATH.'inc/dbtabletestcollection.php');
require_once (PATH.'inc/imagestable.php');

class ImagesTableTests extends DbTableTestCollection
    {
    private $defaultValues = array (ImagesTable::COL_FILENAME => NULL,
                                    ImagesTable::COL_LABEL => NULL,
                                    ImagesTable::COL_DESCRIPTION => NULL,
                                    ImagesTable::COL_KEYWORDS => NULL,
                                    ImagesTable::COL_LICENSE_ID => 1,
                                    );

    public function __construct ($prefix, $context, $parent)
        {
        parent::__construct ($prefix, $context, $parent);
        $this->dbtable = new ImagesTable ($context);
        }

    protected function createSelectAllTest ($expectedRecords, $fields)
        {
        foreach ($expectedRecords as &$expected)
            {
            if (empty ($expected[ImagesTable::COL_FILENAME]))
                $expected[ImagesTable::COL_FILENAME] = pathinfo ($expected[ImagesTable::COL_FILEPATH], PATHINFO_BASENAME);
            unset ($expected[ImagesTable::COL_FILEPATH]);
            }

        return parent::createSelectAllTest ($expectedRecords, $fields);
        }

    public function validateSelectedRecords ($context, $actualOutput, $expectedOutput)
        {
        if (false === $actualOutput)
            return false;

        if (empty ($actualOutput))
            return empty ($expectedOutput);
        foreach ($actualOutput as &$actual)
            {
            list ($tstamp, $actual[ImagesTable::COL_FILENAME]) = explode (".", $actual[ImagesTable::COL_FILENAME], 2);
            }

        usort ($actualOutput, array ($this, "compareRecords"));
        usort ($expectedOutput, array ($this, "compareRecords"));
        return parent::validateSelectedRecords ($context, $actualOutput, $expectedOutput);
        }

    public function compareRecords ($a, $b)
        {
        return strcmp ($a[ImagesTable::COL_FILENAME], $b[ImagesTable::COL_FILENAME]);
        }

    public function findImages ($context, $input)
        {
        if (!$this->isTableValid ($this->dbtable))
            return false;

        $rows = $this->dbtable->findImages ($input, array_keys ($this->defaultValues));
        if (empty ($rows))
            return $rows;

        return $rows;
        }

    public function validateFileSize ($context, $fileSize, $expectedFileSize)
        {
        if (false === $fileSize)
            return false;

        return $expectedFileSize == $fileSize;
        }

    public function resizeImage ($context, $input)
        {
        if (!$this->isTableValid ($this->dbtable))
            return false;

        list ($imageName, $width) = $input;
        $rows = $this->dbtable->findImages ($imageName, array (ImagesTable::COL_FILENAME));
        if (empty ($rows))
            return false;

        $row = $rows[0];
        $newPath = $this->dbtable->resizeImage ($row[ImagesTable::COL_FILENAME], $width, $width);
        if (false === $newPath)
            return false;
        return filesize ($newPath);
        }

    protected function findImagesTest ($keyword, $expectedResults)
        {
        foreach ($expectedResults as &$expected)
            {
            $expected[ImagesTable::COL_FILENAME] = pathinfo ($expected[ImagesTable::COL_FILEPATH], PATHINFO_BASENAME);
            unset ($expected[ImagesTable::COL_FILEPATH]);
            }

        return parent::createTest ("findImages", $keyword, array ($this, "findImages"), $expectedResults, array ($this, "validateSelectedRecords"));
        }

    protected function resizeImagesTest ($input, $expectedSize)
        {
        return parent::createTest ("resizeImage", $input, array ($this, "resizeImage"), $expectedSize, array ($this, "validateFileSize"));
        }

    public function enumerateTests ($context)
        {
        $tests = array ();

        if (!$this->dbtable->canDelete () && !$this->dbtable->ownerCanDelete ())
            {
            $this->context->addError ("Cannot run all the tests. Consider granting the delete access for the current user");
            return array ();
            }

        $createdInstances = array ();

        // "upload" few images
        $path = realpath (PATH."res/default/img/cc-by-sa-3.0.png");
        $tests[] = $this->createInsertTest ($path,
                                            array (ImagesTable::COL_FILEPATH => $path,
                                                   ImagesTable::COL_LABEL => "very interesting title",
                                                   ImagesTable::COL_KEYWORDS => "key1, image",
                                                   ImagesTable::COL_LICENSE_ID => 1,
                                                   ),
                                            $this->defaultValues, $createdInstances);
        $path = realpath (PATH."res/default/img/cc-by-3.0.png");
        $tests[] = $this->createInsertTest ($path,
                                            array (ImagesTable::COL_FILEPATH => $path,
                                                   ImagesTable::COL_LABEL => "some second image",
                                                   ImagesTable::COL_KEYWORDS => "image, second",
                                                   ImagesTable::COL_LICENSE_ID => 1,
                                                   ),
                                            $this->defaultValues, $createdInstances);
        $path = realpath (PATH."res/default/img/GFDL.png");
        $tests[] = $this->createInsertTest ($path,
                                            array (ImagesTable::COL_FILEPATH => $path,
                                                   ImagesTable::COL_LABEL => "GFDL logo",
                                                   ImagesTable::COL_KEYWORDS => "GFDL, logo",
                                                   ImagesTable::COL_LICENSE_ID => 1,
                                                   ),
                                            $this->defaultValues, $createdInstances);
        $path = realpath (PATH."res/default/img/PD-self.png");
        $tests[] = $this->createInsertTest ($path,
                                            array (ImagesTable::COL_FILEPATH => $path,
                                                   ImagesTable::COL_FILENAME => "HH 3568 15-15.png",
                                                   ImagesTable::COL_LABEL => "Public domain logotype",
                                                   ImagesTable::COL_KEYWORDS => "public, domain",
                                                   ImagesTable::COL_LICENSE_ID => 1,
                                                   ),
                                            $this->defaultValues, $createdInstances);
        $path = realpath (PATH."res/default/img/import16.png");
        $tests[] = $this->createInsertTest ($path,
                                            array (ImagesTable::COL_FILEPATH => $path,
                                                   ImagesTable::COL_FILENAME => "HH 3568 15-17.png",
                                                   ImagesTable::COL_LABEL => "import icon",
                                                   ImagesTable::COL_KEYWORDS => "import",
                                                   ImagesTable::COL_LICENSE_ID => 1,
                                                   ),
                                            $this->defaultValues, $createdInstances);

        $tests[] = $this->createSelectAllTest ($createdInstances, array_keys ($this->defaultValues));

        // try to search for the image by using the full text (querying by the word in the middle of the description)
        $tests[] = $this->findImagesTest ("+Interesting", array ($createdInstances[0],));
        $tests[] = $this->findImagesTest ("image", array ($createdInstances[0], $createdInstances[1]));
        $tests[] = $this->findImagesTest ("GFDL", array ($createdInstances[2]));
        
        // try to resize the image for compact display
        $tests[] = $this->resizeImagesTest (array ("very +interesting +title", 40), 1492);
        return $tests;
        }
    }

<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'h/othernamestable.php');

class UpdateOtherNames extends Page
    {
    protected $dbtable;
    
    public function __construct ($context, $request)
        {
        $this->dbtable = ContentTable::createInstanceByName ($context, "person_names");
        parent::__construct ($context, NULL, Constants::TABLES_USER, "person_names");
        }

    protected function checkAccess ($request)
        {
        if (!empty ($this->dbtable))
            return $this->dbtable->canCreate ();
        return true;
        }

    public function processInput ($context, &$request)
        {
        $maxRecords = empty ($request["maxrecords"]) ? 50 : $request["maxrecords"];
        $totalAffected = false;
        switch (!empty ($request["fix"]) ? $request["fix"] : "")
            {
            case "alternate";
                $totalAffected = $this->fixAlternateNamesAfterUpdate ($context, $request, $maxRecords);
                break;
            case "outdated";
                $totalAffected = $this->generateNamesAfterUpdate ($context, $request, $maxRecords, true);
                break;
            case "normal";
                $totalAffected = $this->generateNamesAfterUpdate ($context, $request, $maxRecords, false);
                break;
            default:
                echo $this->getText ("Please provide page parameters ([_0])", "fix=alternate;fix=outdated;fix=normal");
                return true;
            }

        if ($totalAffected == $maxRecords && !empty ($request["nonstop"]))
            {
            $context->setMetaParam ("refresh", $request["nonstop"]);
            }
        return true;
        }

    protected function fixAlternateNamesAfterUpdate ($context, $request, $maxRecords)
        {
        $columns = array ($this->dbtable->getIdColumn (), OtherNamesTable::COL_FIRSTNAME, OtherNamesTable::COL_SURNAME, OtherNamesTable::COL_PERSON,
                          OtherNamesTable::COL_FULL_NAME, OtherNamesTable::COL_SIMPLIFIEDFIRST, OtherNamesTable::COL_SIMPLIFIEDLAST);
        $criteria = array ();
        $params = array (new LimitByPage (0, $maxRecords));
        $criteria[] = new EqCriterion ("c_".OtherNamesTable::COL_SOURCETYPE, OtherNamesTable::SRCTYPE_ALTERNATE);
        //$criteria[] = new IsNullCriterion ("c_".OtherNamesTable::COL_FULL_NAME);
        $rows = $this->dbtable->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rows))
            {
            echo false === $rows ? "Error" : $this->getText ("Nothing to update");
            return false;
            }
        $totalAffected = 0;
        foreach ($rows as $row)
            {
            $criteria = array (new EqCriterion ($this->dbtable->getIdColumn (), $row[$this->dbtable->getIdColumn ()]));
            $namesToValues = array ();
            $namesToValues["c_".OtherNamesTable::COL_FULL_NAME] = $row[OtherNamesTable::COL_PERSON.".".ContentTable::COL_DISPLAY_NAME];
            $namesToValues["c_".OtherNamesTable::COL_SIMPLIFIEDFIRST] = OtherNamesTable::removeDiacritics ($row["c_".OtherNamesTable::COL_FIRSTNAME]);
            $namesToValues["c_".OtherNamesTable::COL_SIMPLIFIEDLAST] = OtherNamesTable::removeDiacritics ($row["c_".OtherNamesTable::COL_SURNAME]);

            $changed = false;
            foreach (array (OtherNamesTable::COL_FULL_NAME, OtherNamesTable::COL_SIMPLIFIEDFIRST, OtherNamesTable::COL_SIMPLIFIEDLAST) as $key)
                {
                if ($namesToValues["c_$key"] != $row["c_$key"])
                    {
                    $changed = true;
                    break;
                    }
                }

            if (!$changed)
                {
                echo $this->getText ("Skip ([_0])", $namesToValues["c_".OtherNamesTable::COL_FULL_NAME]);
                echo "<br>";
                continue;
                }

            $affected = $this->dbtable->updateRecord ($criteria, $namesToValues, 1);
            if (1 != $affected)
                {
                echo $this->getText ("Update failed ([_0])", $namesToValues["c_".OtherNamesTable::COL_FULL_NAME]);
                echo "<br>";
                }
            else
                {
                echo $this->getText ("Updated [_0]", $namesToValues["c_".OtherNamesTable::COL_FULL_NAME]);
                echo "<br>";
                $totalAffected += $affected;
                }
            }

        echo $this->ngettext ("Updated [_0] record", "Updated [_0] records", $totalAffected);
        return $totalAffected;
        }

    protected function generateNamesAfterUpdate ($context, $request, $maxRecords, $onlyOutdated)
        {
        $personsTable = ContentTable::createInstanceByName ($context, "persons");
        $updateTime = date ("Y-m-d H:i:s", time ());

        $columns = array ($personsTable->getIdColumn (), "first", "last", ContentTable::COL_DISPLAY_NAME);
        $criteria = array ();
        $params = array (new LimitByPage (0, $maxRecords));

        if ($onlyOutdated)
            $criteria[] = new LogicalOperatorOr (new IsNullCriterion ("c_othernamesupdated"), new EqCriterion ("c_othernamesupdated", '0000-00-00 00:00:00'));
        else
            $params[] = OrderBy::create ("c_othernamesupdated");

        $rows = $personsTable->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rows))
            {
            echo false === $rows ? "Error" : $this->getText ("Nothing to update");
            return false;
            }

        $totalAffected = 0;
        $columns = array ($this->dbtable->getIdColumn (), "c_".OtherNamesTable::COL_SOURCETYPE,
                          "c_".OtherNamesTable::COL_SIMPLIFIEDFIRST, "c_".OtherNamesTable::COL_SIMPLIFIEDLAST,
                          "c_".OtherNamesTable::COL_FULL_NAME);
        $updatedColumn = $personsTable->findColumn ("othernamesupdated");

        foreach ($rows as $row)
            {
            $nameCriteria = array ();
            $nameCriteria[] = new InCriterion ("c_".OtherNamesTable::COL_SOURCETYPE, array (OtherNamesTable::SRCTYPE_GENERATED, OtherNamesTable::SRCTYPE_MULTIPLE_NAMES));
            $nameCriteria[] = new EqCriterion (OtherNamesTable::COL_PERSON, $row[$personsTable->getIdColumn ()]);
            $existingRows = $this->dbtable->selectBy ($columns, $nameCriteria);
            $directUpToDate = false;
            $storedAlternativeIds = array ();
            $generatedAlternatives = OtherNamesTable::createAlternativeNamePairs ($row["c_first"], $row["c_last"]);
            $numberOfDirectRecords = 0;

            if (!empty ($existingRows))
                {
                $first = OtherNamesTable::removeDiacritics ($row["c_first"]);
                $last = OtherNamesTable::removeDiacritics ($row["c_last"]);
                $storedAlternatives = array ();
                foreach ($existingRows as $existingRow)
                    {
                    if (OtherNamesTable::SRCTYPE_GENERATED == $existingRow["c_".OtherNamesTable::COL_SOURCETYPE])
                        {
                        if ($first == $existingRow["c_".OtherNamesTable::COL_SIMPLIFIEDFIRST] && $last == $existingRow["c_".OtherNamesTable::COL_SIMPLIFIEDLAST] &&
                            $row["c_".ContentTable::COL_DISPLAY_NAME] == $existingRow["c_".OtherNamesTable::COL_FULL_NAME])
                            {
                            $directUpToDate = true;
                            }
                        $numberOfDirectRecords++;
                        }
                    else
                        {
                        $storedAlternatives[] = array ($existingRow["c_".OtherNamesTable::COL_SIMPLIFIEDFIRST], $existingRow["c_".OtherNamesTable::COL_SIMPLIFIEDLAST]);
                        $storedAlternativeIds[] = $existingRow[$this->dbtable->getIdColumn ()];
                        }
                    }

                if (!empty ($storedAlternatives))
                    {
                    if ($this->checkIfAlternativesMatch ($generatedAlternatives, $storedAlternatives))
                        {
                        $generatedAlternatives = array ();
                        $storedAlternativeIds = array ();
                        }
                    else
                        {
                        if (false === $this->dbtable->deleteRecords ($storedAlternativeIds))
                            echo $this->getText ("delete failed ([_0])", $row["c_".ContentTable::COL_DISPLAY_NAME])."\n";
                        }
                    }
                }

            $namesToValues = array ();
            $namesToValues["c_".OtherNamesTable::COL_FULL_NAME] = $row["c_".ContentTable::COL_DISPLAY_NAME];
            $namesToValues["c_".OtherNamesTable::COL_FIRSTNAME] = $row["c_first"];
            $namesToValues["c_".OtherNamesTable::COL_SURNAME] = $row["c_last"];
            if (!$directUpToDate)
                {
                if ($numberOfDirectRecords > 1)
                    {
                    $nameCriteria = array ();
                    $nameCriteria[] = new EqCriterion ("c_".OtherNamesTable::COL_SOURCETYPE, OtherNamesTable::SRCTYPE_GENERATED);
                    $nameCriteria[] = new EqCriterion (OtherNamesTable::COL_PERSON, $row[$personsTable->getIdColumn ()]);
                    $namesToValues2 = array ("c_".OtherNamesTable::COL_SOURCETYPE => OtherNamesTable::SRCTYPE_ORPHANS);
                    $affected = $this->dbtable->updateRecord ($nameCriteria, $namesToValues2, NULL);
                    $existingRow = NULL;
                    }

                if (empty ($existingRow))
                    {
                    $namesToValues["c_".OtherNamesTable::COL_SOURCETYPE] = OtherNamesTable::SRCTYPE_GENERATED;
                    $namesToValues[OtherNamesTable::COL_PERSON] = array ($row[$personsTable->getIdColumn ()]);
                    $affected = $this->dbtable->insertRecord ($namesToValues);
                    }
                else
                    {
                    $nameCriteria = array ();
                    $nameCriteria[] = new EqCriterion ("c_".OtherNamesTable::COL_SOURCETYPE, OtherNamesTable::SRCTYPE_GENERATED);
                    $nameCriteria[] = new EqCriterion (OtherNamesTable::COL_PERSON, $row[$personsTable->getIdColumn ()]);
                    $affected = $this->dbtable->updateRecord ($nameCriteria, $namesToValues, 1);
                    }

                if (false === $affected)
                    {
                    echo $this->getText ("Insert failed ([_0])", $namesToValues["c_".OtherNamesTable::COL_FULL_NAME]);
                    echo "<br>";
                    continue;
                    }
                }

            foreach ($generatedAlternatives as $alternative)
                {
                $namesToValues = array ();
                $namesToValues["c_".OtherNamesTable::COL_FULL_NAME] = $row["c_".ContentTable::COL_DISPLAY_NAME];
                $namesToValues["c_".OtherNamesTable::COL_FIRSTNAME] = $alternative[2];
                $namesToValues["c_".OtherNamesTable::COL_SURNAME] = $alternative[3];
                $namesToValues["c_".OtherNamesTable::COL_SIMPLIFIEDFIRST] = $alternative[0];
                $namesToValues["c_".OtherNamesTable::COL_SIMPLIFIEDLAST] = $alternative[1];
                $namesToValues["c_".OtherNamesTable::COL_SOURCETYPE] = OtherNamesTable::SRCTYPE_MULTIPLE_NAMES;
                $namesToValues[OtherNamesTable::COL_PERSON] = array ($row[$personsTable->getIdColumn ()]);
                $affected = $this->dbtable->insertRecord ($namesToValues);
                if (false === $affected)
                    {
                    echo $this->getText ("Insert failed ([_0] - [_2], [_1])", $namesToValues["c_".OtherNamesTable::COL_FULL_NAME], $alternative[2], $alternative[3]);
                    echo "<br>";
                    continue;
                    }
                }

            echo $this->getText ("Generated record for [_0]", $namesToValues["c_".OtherNamesTable::COL_FULL_NAME]);
            if (!$directUpToDate)
                echo "+";
            if (!empty ($storedAlternativeIds))
                echo " -".count ($storedAlternativeIds);
            if (!empty ($generatedAlternatives))
                echo " +".count ($generatedAlternatives);

            $criteria = array (new EqCriterion ($personsTable->getIdColumn (), $row[$personsTable->getIdColumn ()]));
            $namesToValues = array ();
            $namesToValues[$updatedColumn->columnDef->name] = $updateTime;
            $affected = $personsTable->updateRecord ($criteria, $namesToValues, 1);
            if (false === $affected)
                echo "... Error!";
            else
                $totalAffected++;
            echo "<br>";
            }

        echo $this->ngettext ("Updated [_0] record", "Updated [_0] records", $totalAffected);
        return $totalAffected;
        }

    protected function checkIfAlternativesMatch ($generatedAlternatives, $storedAlternatives)
        {
        if (count ($generatedAlternatives) != count ($storedAlternatives))
            return false;

        $arr1 = $arr2 = array ();
        foreach ($generatedAlternatives as $alternative)
            $arr1[] = $alternative[0]."#".$alternative[1];
        foreach ($storedAlternatives as $alternative)
            $arr2[] = $alternative[0]."#".$alternative[1];
        sort ($arr1);
        sort ($arr2);
        $diff = array_diff ($arr1, $arr2);
        return empty ($diff);
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "dynamicpage";
        }

    public function getActionList ()
        {
        return NULL;
        }

	public function getSubTitle ()
        {
        return NULL;
        }

    }

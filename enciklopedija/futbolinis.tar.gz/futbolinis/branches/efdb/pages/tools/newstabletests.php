<?php
require_once (PATH.'inc/testcollection.php');
require_once (PATH.'inc/newstable.php');

class NewsTableTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent)
        {
        parent::__construct ($prefix, $context, $parent);
        $this->dbtable = new NewsTable ($context);
        }

    public function enumerateTests ($context)
        {
        // create some news in current language, some news in other and check if language is correctly set and filtered

        $tests = array ();

        if (!$this->dbtable->canDelete () && !$this->dbtable->ownerCanDelete ())
            {
            $this->context->addError ("Cannot run all the tests. Consider granting the delete access for the current user");
            return array ();
            }
        $defaultValues = array (NewsTable::COL_TITLE => NULL,
                                NewsTable::COL_OVERVIEW => NULL,
                                NewsTable::COL_DETAILS => NULL,
                                NewsTable::COL_HIDDEN => false,
                                NewsTable::COL_LANG => $context->getLanguage (),
                                NewsTable::COL_PERSPECTIVE => $context->getPerspective (),
                                );

        $createdInstances = array ();
        $createdOtherLanguageInstances = array ();

        foreach (array ("oldest news item", "news item", "newest news item") as $title)
            {
            $tests[] = $this->createInsertTest ($title,
                                                array (NewsTable::COL_TITLE => $title,
                                                       NewsTable::COL_OVERVIEW => "some news ($title)",
                                                       ),
                                                $defaultValues, $createdInstances);
            }

        $tests[] = $this->createSelectAllTest ($createdInstances, array_keys ($defaultValues));

        $tests[] = $this->createInsertTest ("News item in Lithuanian",
                                            array (NewsTable::COL_TITLE => "News in Lithuanian",
                                                   NewsTable::COL_OVERVIEW => "lietuviškos naujienos",
                                                   NewsTable::COL_DETAILS => "lietuviškos naujienos",
                                                   NewsTable::COL_LANG => "un-un",
                                                   ),
                                            $defaultValues, $createdInstances);

        // array_reverse ($createdInstances);
        $tests[] = $this->createSelectAllTest ($createdInstances, array_keys ($defaultValues));

        return $tests;
        }
    }

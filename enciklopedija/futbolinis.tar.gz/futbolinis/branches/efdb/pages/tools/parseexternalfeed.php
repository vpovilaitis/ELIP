<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'h/othernamestable.php');
require_once(PATH.'PHPMailer/class.phpmailer.php');

class ParseExternalFeed extends Page
    {
    protected $dbtable;
    protected $feed = NULL;

    public function __construct ($context, $request)
        {
        $this->dbtable = new FeedSyncTable ($context);
        parent::__construct ($context, NULL, FeedSyncTable::TABLE_SCOPE, FeedSyncTable::TABLE_NAME);
        }

    protected function checkAccess ($request)
        {
        if (!empty ($this->dbtable))
            return $this->dbtable->canCreate ();
        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function ensureChildren ($context, $request)
        {
        if (empty ($request["parser"]))
            {
            $this->addError ("No feed parser found");
            return true;
            }

        $class = $context->parseCustomClass ($request["parser"], "h");
        $instance = NULL;
        if (!empty ($class))
            $instance = new $class ($context);
            
        if (empty ($instance))
            {
            $this->addError ("No feed parser found");
            return true;
            }

        $this->feed = $instance;

        $count = 0;
        $text = $this->updateFeed ($this->feed, $count);

        if (!empty ($text) && 0 !== $count && !empty ($request["mailto"]))
            {
            $emailAddress = $request["mailto"];
            $mail = new PHPMailer();
            $mail->CharSet = 'UTF-8';
            $mail->SetFrom ('info@futbolinis.lt', PROJECT_NAME);
            $mail->AddAddress($emailAddress, "");

            $mail->Subject = "[RSSSync] Feed update status (".$this->feed->getUrl().")";
            
            $mail->MsgHTML (
"<HTML>
 <HEAD>
  <TITLE>Update</TITLE>
  <STYLE TYPE=\"text/css\">
   .ui-state-error { color: red; }
   .ui-state-highlight { color: blue; }
   body { line-height: 1.5em; }
  </STYLE>
 </HEAD>
 <BODY>
 ".$context->applyFormat ($text)."
 </BODY>
</HTML>");
            $mail->AltBody = strip_tags ($text);

            if (!$mail->Send())
                $text .= "<div class=\"ui-state-error\">Unable to send update to $emailAddress - {$mail->ErrorInfo}</div>";
            else
                $text .= "<div class=\"ui-state-highlight\">Sent update to $emailAddress</div>";
            }

        if (!empty ($text))
            $this->addComponent ($request, "component", new TextComponent ("component", $context, $text));

        return true;
        }

    protected function updateFeed ($feed, &$count)
        {
        $count = false; /* lets inform user if something fails and we do not get into processEntries */
        if (empty ($feed))
            return NULL;

        $log = array ();
        $url = $feed->getUrl ();
        $log[] = "Sync with the $url";
        $content = $this->retrieveFeedContent ($url);
        if (false === $content)
            $log[] = "<div class=\"ui-state-error\"><b>Error retrieving feed content</b></div>";
        else if (empty ($content))
            $log[] = "<div class=\"ui-state-highlight\"><i>Empty feed content</i></div>";
        else
            {
            $log[] = count($content->item)." entries retrieved from feed \"{$content->title}\" at {$content->pubDate}";
            $log = array_merge ($log, $this->processEntries ($feed, $content->item, $count));
            }

        return implode ("<br>\n", $log);
        }

    protected function processEntries ($feed, $items, &$count)
        {
        $fetchEveryItem = $feed->retrieveEveryItem ();
        $log = array ();
        $feedName = $feed->getShortName ();
        
        // check which items are already processed (in FeedSyncTable)
        $idsToSkip = $idsToRetrieve = array ();
        foreach ($items as $entry)
            $idsToRetrieve[] = empty ($entry->guid) ? $entry->link : $entry->guid;

        $criteria[] = new EqCriterion (FeedSyncTable::COL_FEED, $feedName);
        $criteria[] = new InCriterion (FeedSyncTable::COL_GUID, $idsToRetrieve);
        $rows = $this->dbtable->selectBy (array (FeedSyncTable::COL_GUID), $criteria);
        if (!empty ($rows))
            {
            foreach ($rows as $row)
                $idsToSkip[] = $row[FeedSyncTable::COL_GUID];
            }

        $count = count ($items) - count ($idsToSkip);

        // process new/changed items
        foreach ($items as $entry)
            {
            $id = empty ($entry->guid) ? $entry->link : $entry->guid;
            $entryTitle = "* {$entry->pubDate}: Entry <a href=\"{$entry->link}\">{$entry->title}</a>";
            if (false !== array_search ($id, $idsToSkip))
                {
                $log[] = "* $entryTitle was <b class=\"ui-state-highlight\">skipped</b> (already processed)";
                continue;
                }

            $description = $entry->description;
            if ($fetchEveryItem)
                {
                $description = $this->retrieveExternalContent ($entry->link);
                if (empty ($description))
                    {
                    $log[] = "* $entryTitle was <b class=\"ui-state-highlight\">not updated</b> as linked content was not retrieved";
                    continue;
                    }
                }

            $entryMessages = array ();
            $date = preg_replace ("#[T]#", " ", $entry->pubDate);
            $error = $feed->processEntry ($entry->title, $description, $entry->link, $date, $entryMessages);
            if (true !== $error)
                {
                $log[] = "* $entryTitle was <b class=\"ui-state-highlight\">not updated</b> - $error";
                foreach ($entryMessages as $msg)
                    $log[] = "** $msg";
                continue;
                }

            if (empty ($_REQUEST["test"]))
                {
                // update FeedSyncTable
                if (false === $this->dbtable->insertRecord (array (FeedSyncTable::COL_FEED => $feedName, FeedSyncTable::COL_GUID => $id, FeedSyncTable::COL_DATE => $date)))
                    $entryMessages[] = "<b class=\"ui-state-highlight\">Error updating sync table</b>";
                }

            // add log line
            $log[] = "* $entryTitle was <i class=\"ui-state-highlight\">successfully retrieved</i>";
            foreach ($entryMessages as $msg)
                $log[] = "** $msg";
            }
        return $log;
        }

    public static function retrieveExternalContent ($url)
        {
        $h = @fopen ($url, "r");
        if (empty ($h))
            return false;

        $response = "";
        while (!feof ($h))
            $response .= fread ($h, 32*1024);

        fclose ($h);
        return $response;
        }

    protected function retrieveFeedContent ($url)
        {
        $content = $this->retrieveExternalContent ($url);
        if (empty ($content))
            return $content;

        $xmlObj = simplexml_load_string ($content);
        return $xmlObj->channel;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "dynamicpage";
        }

    public function getActionList ()
        {
        return NULL;
        }

    public function getSubTitle ()
        {
        return NULL;
        }

    }

abstract class SyncFeed extends BaseWithContext
    {
    abstract public function getUrl ();

    public function getShortName ()
        {
        return $this->getUrl ();
        }

    public function retrieveEveryItem ()
        {
        return false;
        }

    abstract public function processEntry ($title, $content, $url, $pubDate, &$log);

    }

<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'h/othernamestable.php');
require_once (PATH.'pages/tools/predictormaintenance.php');
require_once(PATH.'PHPMailer/class.phpmailer.php');

class PredictorAnnounce extends Page
    {
    public function __construct ($context, $request)
        {
        parent::__construct ($context, $context->getText ("Pinging predictor users"), PredictorGameTable::TABLE_SCOPE, PredictorGameTable::TABLE_NAME);
        
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        $competitions = empty ($request["competitions"]) ? NULL : $request["competitions"];
        $days = empty ($request["days"]) ? 3 : $request["days"];
        $testEmail = empty ($request["test"]) ? NULL : $request["test"];
        
        if (empty ($competitions))
            {
            $this->addError ("Did not find 'competitions' query string");
            return true;
            }

        $statusText = array ();

        $competitionIds = explode (",", $competitions);
        $gamesTable = new PredictorGameTable ($context);
        $gameIds = $this->findMatches ($gamesTable, $days, $competitionIds, $matches, $statusText);

        if (empty ($gameIds))
            return true;

        $userIds = $this->findUsers ($gamesTable, $gameIds, $competitionIds, $matches, $statusText);
        if (empty ($userIds))
            return true;

        // select all users by id having email non-null
        $usersTable = new UsersTable ($context);
        $criteria = array (new InCriterion (UsersTable::COL_ID, $userIds));
        $criteria[] = new IsNotNullCriterion (UsersTable::COL_EMAIL);
        $criteria[] = new EqCriterion (UsersTable::COL_OPTIN, 1);
        $userRows = $usersTable->selectBy (array (UsersTable::COL_ID, UsersTable::COL_EMAIL, UsersTable::COL_NAME), $criteria);

        if (empty ($userRows))
            {
            $statusText[] = "Found no users with email entered";
            return true;
            }

        $statusText[] = "Found ".count ($userRows)." users with email entered";
        foreach ($userRows as $row)
            {
            $emailAddress = !empty ($testEmail) ? $testEmail : $row[UsersTable::COL_EMAIL];
            $mail = new PHPMailer();
            $mail->CharSet = 'UTF-8';
            $mail->SetFrom ('info@futboloenciklopedija.lt', PROJECT_NAME);
            $mail->AddAddress($emailAddress, $row[UsersTable::COL_NAME]);

            $mail->Subject = "[LFE Totalizatorius] Priminimas apie totalizatoriaus susitikimus";
            
            $text = "
 <p>Sveiki, {$row[UsersTable::COL_NAME]},</p>
 <p>
 Primename, kad esate prisiregistravęs Lietuvos futbolo enciklopedijos totalizatoriuje
 (<a href=\"http://www.futbolinis.lt/page/toto/lt\">http://www.futbolinis.lt/page/toto/lt</a>).
 Neužmirškite, kad jau galima spėti artėjančio turo rungtynių rezultatus.
 </p>
 <p>Pagarbiai,<br>Lietuvos futbolo enciklopedijos komanda</p>
 <br>
 <p>
  <small>
   P.S.: Jei nenorite gauti priminimų, užeikite aukščiau pateiktu totalizatoriaus adresu, prisijunkite ir pažymėkite varnelę „nesiųsti priminimų el. paštu“. Taip pat galite palaukti 2 mėnesius nuo paskutinio spėjimo ir priminimai jums nebebus siunčiami.
  </small>
 </p>
";
            $html =
"<HTML>
 <HEAD>
  <TITLE>Update</TITLE>
  <META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">
  <STYLE TYPE=\"text/css\">
   body { line-height: 1.5em; }
  </STYLE>
 </HEAD>
 <BODY>
    $text
 </BODY>
</HTML>";
            $mail->MsgHTML ($text);
            $mail->AltBody = strip_tags ($text);
            if (!$mail->Send())
                $statusText[] = "<div class=\"ui-state-error\">Unable to send update to $emailAddress - {$mail->ErrorInfo}</div>";
            else
                $statusText[] = "<div class=\"ui-state-highlight\">Sent update to $emailAddress</div>";
            }

        $mail = new PHPMailer();
        $mail->CharSet = 'UTF-8';
        $mail->SetFrom ('info@futboloenciklopedija.lt', PROJECT_NAME);
        $mail->AddAddress('info@futboloenciklopedija.lt');
        $mail->Subject = "[LFE Totalizatorius] Ataskaita apie priminimus";
        $mail->MsgHTML (implode ("<br>", $statusText));
        $mail->Send();

        $this->addComponent ($request, "", new TextComponent ("", $context, implode ("<br>", $statusText)));
        return true;
        }

    protected function findMatches ($gamesTable, $days, $competitionIds, &$matches, &$statusText)
        {
        $matches = PredictorMaintenance::collectNearestGames ($this->context, $days, $competitionIds);
        if (empty ($matches))
            return NULL;

        $statusText[] = "Found ".count ($matches)." upcomming matches.";

        $criteria[] = new InCriterion (PredictorGameTable::COL_MATCH_ID, array_keys ($matches));
        $rows = $gamesTable->selectBy (array (PredictorGameTable::COL_ID), $criteria);
        if (empty ($rows))
            return NULL;

        $ids = array ();
        foreach ($rows as $row)
            $ids[] = $row[PredictorGameTable::COL_ID];

        $statusText[] = "Found ".count ($ids)." upcomming predictor matches.";
        return $ids;
        }

    protected function findUsers ($gamesTable, $gameIds, $competitionIds, $matches, &$statusText)
        {
        $seasonsTable = new PredictorSeasonTable ($this->context);
        $guessTable = new PredictorGuessTable ($this->context);
        
        $matchesTable = ContentTable::createInstanceByName ($this->context, Sports::TABLE_MATCH);

        $criteria = array (new InCriterion (PredictorSeasonTable::COL_SEASON, $competitionIds));
        $criteria[] = new JoinColumnsCriterion (PredictorGameTable::COL_SEASON_ID, PredictorSeasonTable::COL_ID);
        $seasonsJoin = $seasonsTable->createQuery (array (), $criteria);
        
        $criteria = array (new JoinColumnsCriterion (PredictorGuessTable::COL_GAME_ID, PredictorGameTable::COL_ID));
        $gamesJoin = $gamesTable->createQuery (array (), $criteria, array ($seasonsJoin));

        $columns = array (PredictorGuessTable::COL_USER_ID);
        $criteria = array (new GtCriterion (PredictorGuessTable::COL_CREATEDON, date ("Y-m-d H:i", strtotime ("-2 months"))));
        $userRows = $guessTable->selectBy ($columns, $criteria, array ($gamesJoin), array (new Distinct()));
        if (empty ($userRows))
            return NULL;

        $statusText[] = "Found ".count ($userRows)." active users.";
        $userIds = array ();
        foreach ($userRows as $row)
            $userIds[] = $row[PredictorGuessTable::COL_USER_ID];

        $criteria = array (new JoinColumnsCriterion (PredictorGuessTable::COL_GAME_ID, PredictorGameTable::COL_ID));
        $criteria[] = new InCriterion (PredictorGameTable::COL_MATCH_ID, array_keys ($matches));
        $gamesJoin = $gamesTable->createQuery (array (), $criteria);

        $criteria = NULL;
        $criteria[] = new InCriterion (PredictorGuessTable::COL_USER_ID, $userIds);
        $columns = array (PredictorGuessTable::COL_USER_ID, new FunctionCount ("*", "cnt"));
        $params[] = new HavingCriteria ("cnt=".count($matches));
        $params[] = new GroupBy (array (PredictorGuessTable::COL_USER_ID));
        $rows = $guessTable->selectBy ($columns, $criteria, array ($gamesJoin), $params);
        $skipUsers = array ();

        if (!empty ($rows))
            {
            $statusText[] = "Found ".count ($rows)." users with all results already entered.";
            foreach ($rows as $row)
                $skipUsers[] = $row[PredictorGuessTable::COL_USER_ID];
            }

        $users = array_diff ($userIds, $skipUsers);
        $statusText[] = "Found ".count ($users)." users needing a remainder.";
        return $users;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "dynamicpage";
        }

    public function getActionList ()
        {
        return NULL;
        }

    public function getSubTitle ()
        {
        return NULL;
        }

    }

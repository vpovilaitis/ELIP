<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'inc/testcollection.php');

class AutomatedTests extends Page
    {
    protected $registeredTests = array
                (
                "NameHashTests",

                // sports
                "SubmitGameTests",
                );
    protected $registeredInvasiveTests = array
                (
                "GenerateAnnouncementTests",
                "ImagesTableTests",
                "QuickLinkTests",
                "NewsTableTests",

                "TeamOverviewTests",
                "LffFeedTests",
                );
    protected $loadedTests;

    public function __construct ($context, $request)
        {
        parent::__construct ($context, NULL);
        $context->addStyleSheet ("tests");
        }

    public function ensureTitle ($context, &$request)
        {
        $context->setTitle ("Automated tests");
        return true;
        }

    protected function checkAccess ($request)
        {
        return true;
        }

    public function ensureChildren ($context, $request)
        {
        $this->loadedTests = array ();
        $allTests = $this->registeredTests;
        if (ALLOW_INVASIVE_ATP)
            $allTests = array_merge ($allTests, $this->registeredInvasiveTests);

        foreach ($allTests as $testHandler)
            {
            $class = $context->parseCustomClass ($testHandler, "pages/tools");
            if (empty ($class))
                $this->addError ("Automated test [_0] was not loaded", $testHandler);
            else 
                {
                $instance = new $class ($testHandler, $context, $this);
                if (!($instance instanceof TestCollection))
                    {
                    $this->addError ("Incorrect automated test class [_0] was loaded", $testHandler);
                    continue;
                    }

                $this->loadedTests[$testHandler] = $instance;
                }
            }

        return true;
        }

    public function processInput ($context, &$request)
        {
        $executeAll = !empty ($request["fulltest"]);
        $testToRun = !empty ($request["test"]) ? $request["test"] : "";
        $testToDiagnose = !empty ($testToRun) && !empty ($request["diagnose"]) ? $request["diagnose"] : "";
        $actionToExecute = !empty ($request["action"]) ? $request["action"] : "";

        if ($executeAll)
            $testsToRun = $this->loadedTests;
        else if (array_key_exists ($testToRun, $this->loadedTests))
            {
            if (!empty ($testToDiagnose))
                {
                $this->loadedTests[$testToRun]->diagnose ($context, $testToDiagnose);
                return true;
                }
            else if (!empty ($actionToExecute))
                {
                $this->loadedTests[$testToRun]->executeAction ($context, $actionToExecute);
                return true;
                }

            $testsToRun = array ($this->loadedTests[$testToRun]);
            }
        else
            $testsToRun = array ();

        foreach ($testsToRun as $test)
            {
            $test->run ($context);
            }

        return true;
        }

    public function getTestList ()
        {
        return $this->loadedTests;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "automatedtests";
        }

    public function getExecuteTestUrl ($testCollection)
        {
        return $this->context->processUrl ("index.php?c=tools/AutomatedTests&test=$testCollection", true);
        }

    public function getDiagnoseTestUrl ($testCollection, $test)
        {
        return $this->context->processUrl ("index.php?c=tools/AutomatedTests&test=$testCollection&diagnose=$test", true);
        }

    public function getTestActionUrl ($testCollection, $action)
        {
        return $this->context->processUrl ("index.php?c=tools/AutomatedTests&test=$testCollection&action=$action", true);
        }

    public function getActionList ()
        {
        $url = $this->context->processUrl ("index.php?c=tools/AutomatedTests", true)."&fulltest=1";
        $runLink = new SimpleLinkAction ($this, "runall", $this->getText ("Run All"), $url, true);

        return array ($runLink);
        }

    }
   

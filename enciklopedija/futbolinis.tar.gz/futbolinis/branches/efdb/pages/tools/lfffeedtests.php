<?php
require_once (PATH.'inc/dbtabletestcollection.php');
require_once (PATH.'inc/compositetestcollection.php');
require_once (PATH.'h/sports/syncwithlfffeed.php');

class LffFeedTests extends CompositeTestCollection
    {
    protected $createdInstanceTracker;

    public function __construct ($prefix, $context, $parent)
        {
        parent::__construct ($prefix, $context, $parent);
        $this->createdInstanceTracker = new CreatedTestInstances ();
        }
    
    public function run ($context, $diagnoseTest = NULL, $atomic = false)
        {
        return parent::run ($context, $diagnoseTest, true);
        }

    public function enumerateTests ($context)
        {
        $tests = parent::enumerateTests ($context);

        foreach ($this->getTestCases () as $article => $expectedOutput)
            {
            $test = $this->createArticleTest ($article, $expectedOutput);
            $test->setInstanceTracker ($this->createdInstanceTracker);
            $tests[] = $test;
            }

        return $tests;
        }

    public function parseArticle ($context, $input)
        {
        $content = ParseExternalFeed::retrieveExternalContent ($input);
        if (empty ($content))
            {
            $context->addError ("Empty content");
            return false;
            }

        $feed = new SyncWithLffFeed ($context);

        $log = array ();
        $result = $feed->extractMatchesFromHtml ($content, $log);

        foreach ($log as $line)
            {
            //if (false !== strpos ($line, "ui-state-error"))
                {
                $context->addError ($line);
                }
            }

        return $result;
        }

       
    protected function createArticleTest ($article, $expectedResults)
        {
        $expected = array ();
        foreach ($expectedResults as $matchId => $encoded)
            {
            $expected[$matchId] = json_decode ($encoded);
            }

        return parent::createTest ("Parsing LFF article $article", $article, array ($this, "parseArticle"), $expected, NULL, "LffFeedTest");
        }

    public function enumerateDependencies ($context, $parent)
        {
        return array
            (
            new LffFeedTestSeasons ("dep_season", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new LffFeedTestCompetitionSeasons ("dep_cs", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new LffFeedTestTeams ("dep_team", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new LffFeedTestMatches ("dep_match", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new LffFeedTestLeagueTeams ("dep_ach", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            );
        }
    
    protected function getTestCases ()
        {
        return array
        (
        PATH."pages/tools/resources/lff-rss001.html" => array
                (
                '2009-01-06 Vilniaus kolegija-Ozas' => '{"treatnames":1,"date":"2009-01-06",
                                                              "homeTeam":"Vilniaus kolegija","awayTeam":"Ozas","result":["8","3"],"resultHalfTime":["3","2"],"referee":"J.Pa\u0161kovskis","refereeA1":"R.Valikonis","goal":[{"name":"T.Statkevi\u010dius","home":true},{"name":"T.Statkevi\u010dius","home":true},{"name":"T.Statkevi\u010dius","home":true},{"name":"T.Statkevi\u010dius","home":true},{"name":"M.Makutunovi\u010dius","home":true},{"name":"M.Makutunovi\u010dius","home":true},{"name":"M.Makutunovi\u010dius","home":true},{"name":"R.Jankovskij","home":true},{"name":"R.\u010cebatorius","home":false},{"name":"G.Mala\u0161auskas","home":false},{"name":"J.Nasevi\u010d","home":false}],"book":[{"name":"K.Ge\u010das","home":false}],"sourceDetails":"\"Vilniaus kolegija\" - \"Ozas\" 8:3 (3:2)\nTeis\u0117jai - J.Pa\u0161kovskis, R.Valikonis\n\u012evar\u010diai: T.Statkevi\u010dius (4), M.Makutunovi\u010dius (3), R.Jankovskij (\"Vilniaus kolegija\"); R.\u010cebatorius, G.Mala\u0161auskas, J.Nasevi\u010d (\"Ozas\").\n\u012esp\u0117tas: K.Ge\u010das (\"Ozas\")."}',
                '2009-01-09 Snoras-Navigatoriai' => '{"treatnames":1,"date":"2009-01-09","homeTeam":"Snoras-2","awayTeam":"Navigatoriai","result":["2","8"],"resultHalfTime":["0","4"],"referee":"R.Cviklinskis","refereeA1":"J.Pa\u0161kovskis","goal":[{"name":"D.\u0160ablinskij","home":true},{"name":"D.\u0160ablinskij","home":true},{"name":"M.Bajori\u016bnas","home":false},{"name":"M.Bajori\u016bnas","home":false},{"name":"M.Bajori\u016bnas","home":false},{"name":"M.Bajori\u016bnas","home":false},{"name":"M.Litvinas","home":false},{"name":"M.Litvinas","home":false},{"name":"J.Lasickas","home":false},{"name":"M.Marcinkevi\u010dius","home":false}],"sourceDetails":"\"Snoras-2\" - \"Navigatoriai\" 2:8 (0:4)\nTeis\u0117jai - R.Cviklinskis, J.Pa\u0161kovskis\n\u012evar\u010diai: D.\u0160ablinskij (2) (\"Snoras-2\"); M.Bajori\u016bnas (4), M.Litvinas (2), J.Lasickas, M.Marcinkevi\u010dius (\"Navigatoriai\")."}',
                ),
        PATH."pages/tools/resources/lff-rss001-1.html" => array
                (
                '2009-01-09 Snoras-Navigatoriai' => '{"treatnames":1,"date":"2009-01-09","homeTeam":"Snoras (Vilnius)","awayTeam":"Navigatoriai (Vilnius)","result":["2","8"],"resultHalfTime":["0","4"],"stadium":"Gargždų miesto stadionas","number":3,"referee":"J.Pa\u0161kovskis","refereeCity":"Vilnius","spectators":300,"goal":[{"name":"D.\u0160ablinskij","home":true},{"name":"D.\u0160ablinskij","home":true},{"name":"M.Bajori\u016bnas","home":false},{"name":"M.Bajori\u016bnas","home":false},{"name":"M.Bajori\u016bnas","home":false},{"name":"M.Bajori\u016bnas","home":false},{"name":"M.Litvinas","home":false},{"name":"M.Litvinas","home":false},{"name":"J.Lasickas","home":false},{"name":"M.Marcinkevi\u010dius","home":false}],"sourceDetails":"3. Snoras (Vilnius) - Navigatoriai (Vilnius) 2:8 (0:4)\nGarg\u017ed\u0173 miesto stadionas\nTeis\u0117jas: J.Pa\u0161kovskis (Vilnius), 300 \u017ei\u016brovų\n\u012evar\u010diai: D.\u0160ablinskij (2) (\"Snoras-2\"); M.Bajori\u016bnas (4), M.Litvinas (2), J.Lasickas, M.Marcinkevi\u010dius (\"Navigatoriai\")."}',
                ),
        PATH."pages/tools/resources/lff-rss002.html" => array
                (
                ),
        PATH."pages/tools/resources/lff-rss003.html" => array
                (
                '2009-01-07 Oniksas-Aleksotas' => '{"treatnames":1,"date":"2009-01-07","homeTeam":"FK Oniksas (Kaunas)","awayTeam":"FK Aleksotas (Kaunas)","result":["2","10"],"resultHalfTime":["1","5"],"referee":"I.Kovalenko","spectators":"50","goal":[{"min":"15","name":"V.Bagdonas","home":true},{"min":"55","name":"L.Turauskas","home":true},{"min":"5","name":"K.Vasilkovas","home":false},{"min":"6","name":"M.Tamulis","pk":true,"home":false},{"min":"12","name":"T.Pape\u010dkys","home":false},{"min":"20","name":"T.Pape\u010dkys","home":false},{"min":"16","name":"M.Tamulis","home":false},{"min":"44","name":"M.Tamulis","home":false},{"min":"29","name":"A.Sanajevas","home":false},{"min":"39","name":"A.Sanajevas","home":false},{"min":"42","name":"H.Grigas","home":false},{"min":"59","name":"H.Grigas","home":false}],"book":[{"min":"6","name":"A.Petra\u0161ka","home":true},{"min":"15","name":"T.Pape\u010dkys","home":false}],"sent":[{"min":"17","name":"L.Stankevi\u010dius","home":true}],"sourceDetails":"FK \"Oniksas\" (Kaunas) 2:10 (1:5) FK \"Aleksotas\" (Kaunas)\nTeis\u0117jas: I.Kovalenko\n\u017di\u016brovai: 50.\n\u012evar\u010diai: 15 min. V.Bagdonas, 55 min. L.Turauskas (\u201eOniksas\")\n5 min. K.Vasilkovas, 6 min. M.Tamulis - i\u0161 11 m.b., 12,20 min.  T.Pape\u010dkys, 16,44 min. M.Tamulis, 29,39 min. A.Sanajevas, 42,59 min.  H.Grigas (\u201eAleksotas\")\n\u012esp\u0117ti: 6 min. A.Petra\u0161ka (\u201eOniksas\")\n15 min. T.Pape\u010dkys (\u201eAleksotas\")\nPa\u0161alintas: 17 min. L.Stankevi\u010dius (\u201eOniksas\")"}',
                '2009-01-07 Galinta-Gaschema' =>
                    '{"treatnames":1,"date":"2009-01-07","homeTeam":"Galinta (Kaunas)","awayTeam":"Gaschema (Jonava)",
                      "result":["2","3"],"resultHalfTime":["0","1"],"referee":"G.Ma\u017eeika","spectators":"70",
                      "goal":[{"min":"45","name":"B.Biskys","home":true},{"min":"46","name":"Vyt.Katasanovas","home":true},
                              {"min":"16","name":"A.Mockus","home":false},{"min":"36","name":"A.Mockus","home":false},
                              {"min":"40","name":"R.Fiodorovas","home":false}],
                      "book":[{"min":"42","name":"Aud.Ra\u010dkus","home":true},{"min":"28","name":"M.Stankevi\u010dius","home":false},
                              {"min":"55","name":"R.Fiodorovas","home":false}],
                      "sourceDetails":"\"Galinta\" (Kaunas) 2:3 (0:1) \"Gaschema\" (Jonava)\nTeis\u0117jas: G.Ma\u017eeika\n\u017di\u016brovai: 70.\n\u012evar\u010diai: 45 min. B.Biskys, 46 min. Vyt.Katasanovas (\u201eGalinta\")\n16,36 min. A.Mockus, 40 min. R.Fiodorovas (\u201eGaschema\")\n\u012esp\u0117ti: 42 min. Aud.Ra\u010dkus (\u201eGalinta\")\n28 min. M.Stankevi\u010dius, 55 min. R.Fiodorovas (\u201eGaschema\")"}',
                '2009-01-07 Fotofabrikas-Tauras' => '{"treatnames":1,"date":"2009-01-07","homeTeam":"FK Fotofabrikas (Kaunas)","awayTeam":"FM Tauras (Kaunas)","result":["5","4"],"resultHalfTime":["5","3"],"referee":"I.Kovalenko","spectators":"60","goal":[{"min":"15","name":"R.Mace\u017einskas","home":true},{"min":"20","name":"D.Barkauskas","home":true},{"min":"23","name":"I.\u0160eleika","home":true},{"min":"24","name":"A.Raginis","pk":true,"home":true},{"min":"25","name":"A.Raginis","home":true},{"min":"2","name":"B.Olencevi\u010dius","home":false},{"min":"6","name":"E.Skripkinas","home":false},{"min":"31","name":"E.Skripkinas","home":false},{"min":"14","name":"R.Kru\u0161nauskas","home":false}],"book":[{"min":"41","name":"A.Raginis","home":true},{"min":"27","name":"E.Skripkinas","home":false}],"sent":[{"min":"47","name":"D.Barkauskas","home":true}],"sourceDetails":"FK \"Fotofabrikas\" (Kaunas) 5:4 (5:3) FM \"Tauras\" (Kaunas)\nTeis\u0117jas: I.Kovalenko\n\u017di\u016brovai: 60.\n\u012evar\u010diai: 15 min. R.Mace\u017einskas, 20 min. D.Barkauskas, 23 min.  I.\u0160eleika, 24 min. A.Raginis - \u012fvartis i\u0161 11 m.b., 25 min. A.Raginis  (\u201eFotofabrikas\")\n2 min. B.Olencevi\u010dius, 6,31 min. E.Skripkinas, 14 min. R.Kru\u0161nauskas (\u201eTauras\")\n\u012esp\u0117ti: 41 min. A.Raginis (\u201eFotofabrikas\")\n27 min. E.Skripkinas (\u201eTauras\")\nPa\u0161alintas: 47 min. D.Barkauskas (\u201eFotofabrikas\")"}',
                '2009-01-07 Hegelmann Litauen-Celsis' => '{"treatnames":1,"date":"2009-01-07","homeTeam":"FC Hegelmann Litauen (Kaunas)","awayTeam":"Celsis (Kaunas)","result":["4","1"],"resultHalfTime":["2","1"],"referee":"G.Ma\u017eeika","spectators":"40","goal":[{"min":"5","name":"A.Alekna","home":true},{"min":"17","name":"R.Lubys","home":true},{"min":"51","name":"G.Gri\u0161kevi\u010dius","home":true},{"min":"54","name":"K.Gedgaudas","home":true},{"min":"19","name":"T.Maziliauskas","home":false}],"book":[{"min":"42","name":"E.Citavi\u010dius","home":true},{"min":"43","name":"A.Alekna","home":true}],"sourceDetails":"FC \u201eHegelmann Litauen\" (Kaunas) 4:1 (2:1) \"Celsis\" (Kaunas)\nTeis\u0117jas: G.Ma\u017eeika\n\u017di\u016brovai: 40.\n\u012evar\u010diai: 5 min. A.Alekna,  17 min. R.Lubys, 51 min. G.Gri\u0161kevi\u010dius, 54 min. K.Gedgaudas (\u201eHegelmann Litauen\")\n19 min. T.Maziliauskas (\u201eCelsis\")\n\u012esp\u0117ti: 42 min. E.Citavi\u010dius, 43 min. A.Alekna (\u201eHegelmann Litauen\")"}',
                '2009-01-08 Spyris-KTU' => '{"treatnames":1,"date":"2009-01-08","homeTeam":"FK Spyris (Kaunas)","awayTeam":"KTU (Kaunas)","result":["3","1"],"resultHalfTime":["0","0"],"referee":"Vyt.Kazlauskas","spectators":"35","goal":[{"min":"39","name":"R.Gumbrys","home":true},{"min":"45","name":"R.Gumbrys","home":true},{"min":"60","name":"R.Gumbrys","home":true},{"min":"54","name":"J.Orantas","home":false}],"book":[{"min":"23","name":"G.Grabauskas","home":true}],"sourceDetails":"FK \"Spyris\" (Kaunas) 3:1 (0:0) KTU (Kaunas)\nTeis\u0117jas: Vyt.Kazlauskas\n\u017di\u016brovai: 35.\n\u012evar\u010diai: 39,45,60 min. R.Gumbrys (\u201eSpyris\")\n54 min. J.Orantas (KTU)\n\u012esp\u0117tas: 23 min. G.Grabauskas (\u201eSpyris\")"}',
                '2009-01-08 Fortas-VDU' => '{"treatnames":1,"date":"2009-01-08","homeTeam":"FK Fortas (Kaunas)","awayTeam":"VDU (Kaunas)","result":["3","1"],"resultHalfTime":["2","0"],"referee":"Vyt.Kazlauskas","spectators":"40","goal":[{"min":"5","name":"V.Urnie\u017eius","home":true},{"min":"8","name":"R.Jakaitis","home":true,"pk":true},{"min":"42","name":"D.Karlauskas","home":true},{"min":"48","name":"D.Martinavi\u010dius","home":false}],"book":[{"min":"34","name":"M.Bielskis","home":true},{"min":"48","name":"R.Jakaitis","home":true},{"min":"7","name":"E.Gabalis","home":false},{"min":"40","name":"L.Babravi\u010dius","home":false},{"min":"58","name":"E.Pa\u0161ukevi\u010dius","home":false}],"sourceDetails":"FK \"Fortas\" (Kaunas) 3:1 (2:0) VDU (Kaunas)\nTeis\u0117jas: Vyt.Kazlauskas\n\u017di\u016brovai: 40.\n\u012evar\u010diai: 5 min. V.Urnie\u017eius, 8 min. R.Jakaitis - i\u0161 11 m.b., 42 min. D.Karlauskas (\u201eFortas\")\n48 min. D.Martinavi\u010dius (VDU)\n\u012esp\u0117ti: 34 min. M.Bielskis, 48 min. R.Jakaitis (\u201eFortas\")\n7 min. E.Gabalis, 40 min. L.Babravi\u010dius, 58 min. E.Pa\u0161ukevi\u010dius (VDU)"}',
                ),
        PATH."pages/tools/resources/lff-rss004.html" => array
                (
                ),
        PATH."pages/tools/resources/lff-rss005.html" => array
                (
                ),
        PATH."pages/tools/resources/lff-rss006.html" => array
                (
                '2009-01-15 SC-STIHL-Vici' =>
                '{"treatnames":1,"date":"2009-01-15",
  "homeTeam":"Kazl\u0173 R\u016bdos SC-STIHL","awayTeam":"Kauno Vi\u010di",
  "result":["6","2"],"resultHalfTime":["1","1"],
  "referee":"Vyt. Kazlauskas","refereeCity":"Kaunas","refereeA1":"Vit. Kazlauskas","refereeA1City":"Kaunas",
  "goal":[{"min":"3","name":"K.Vasilkovas","home":false},
          {"min":"6","name":"A.Juozaitis","home":true},
          {"min":"22","name":"N.Ma\u010diulis","home":true},
          {"min":"26","name":"R.Bakus","home":true},
          {"min":"27","name":"A.Iva\u0161kevi\u010dius","home":false},
          {"min":"33","name":"N.Ma\u010diulis","home":true},
          {"min":"36","name":"D.Liutkus","home":true},
          {"min":"39","name":"A.Rimkevi\u010dius","home":true}],
  "book":[{"min":"19","name":"S.Juozaitis","home":true},
          {"min":"29","name":"G.Gurjevas","home":false},{"min":"37","name":"M.Kersnauskas","home":false}],
  "sent":[{"min":"150","name":"M.Kersnauskas","home":false}],
  "sourceDetails":"Kazl\u0173 R\u016bdos \u201eSC-STIHL\" - Kauno \u201eVi\u010di\" 6:2 (1:1)\nTeis\u0117jai - Vyt. Kazlauskas, Vit. Kazlauskas (Kaunas)\n\u012evar\u010diai: 3 min. K.Vasilkovas (0:1), 6 min. A.Juozaitis (1:1), 22 min. N.Ma\u010diulis (2:1), 26 min. R.Bakus (3:1), 27 min. A.Iva\u0161kevi\u010dius (3:2), 33 min. N.Ma\u010diulis (4:2), 36 min. D.Liutkus (5:2), 39 min. A.Rimkevi\u010dius (6:2).\n\u012esp\u0117ti: 19 min. S.Juozaitis (\u201eSC-STIHL\"), 29 min. G.Gurjevas, 37 min. M.Kersnauskas (\u201eVi\u010di\").\nPa\u0161alintas: M.Kersnauskas (\u201eVi\u010di\") - po rungtyni\u0173 u\u017e teis\u0117jo \u012f\u017eeidim\u0105"}',

                '2009-01-15 Penalty.lt-Nautara' =>
                '{"treatnames":1,"date":"2009-01-15",
  "homeTeam":"Vilniaus Penalty.lt","awayTeam":"Kauno Nautara",
  "result":["1","11"],"resultHalfTime":["1","5"],
  "referee":"N.Biriukovas","refereeCity":"Vilnius","refereeA1":"J.Pa\u0161kovskis","refereeA1City":"Vilnius",
  "goal":[{"min":"2","name":"P.Sakalis","og":true,"home":false},{"min":"4","name":"V.Gar\u0161vinskas","home":true},
          {"min":"10","name":"T.Nemanis","home":false},{"min":"12","name":"M.Bezykornovas","home":false},
          {"min":"12","name":"V.Adomaitis","home":false},{"min":"16","name":"A.\u0160teinas","home":false},
          {"min":"22","name":"V.Leme\u017eis","home":false},{"min":"25","name":"M.Bezykornovas","home":false},
          {"min":"26","name":"M.Bezykornovas","home":false},{"min":"28","name":"T.Nemanis","home":false},
          {"min":"30","name":"A.Bulo\u0161as","home":false},{"min":"37","name":"A.Bulo\u0161as","home":false}],
  "book":[{"min":"8","name":"A.\u0160teinas","home":false},
          {"min":"28","name":"T.Mockevi\u010dius","home":false},
          {"min":"28","name":"V.Gar\u0161vinskas","home":true}],
  "sourceDetails":"Vilniaus \u201ePenalty.lt\" - Kauno \u201eNautara\" 1:11 (1:5)\nTeis\u0117jai - N.Biriukovas, J.Pa\u0161kovskis (Vilnius)\n\u012evar\u010diai: 2 min. P.Sakalis (\u012f savo vartus, 0:1), 4 min. V.Gar\u0161vinskas (1:1), 10 min. T.Nemanis (1:2), 12 min. M.Bezykornovas (1:3), 12 min. V.Adomaitis (1:4),  16 min. A.\u0160teinas (1:5), 22 min. V.Leme\u017eis (1:6), 25 min. M.Bezykornovas (1:7), 26 min. M.Bezykornovas (1:8), 28 min. T.Nemanis (1:9), 30 min. A.Bulo\u0161as (1:10), 37 min. A.Bulo\u0161as (1:11).\n\u012esp\u0117ti: 8 min. A.\u0160teinas, 28 min. T.Mockevi\u010dius (\u201eNautara\"); 28 min. V.Gar\u0161vinskas (\u201ePenalty.lt\")."}',
                ),
        );
        }
    }

class LffFeedTest extends CallbackTest
    {
    protected function validateOutput ($context, $actualOutput, $expectedOutput)
        {
        $expected = array();
        foreach ($expectedOutput as $matchLabel => $match)
            {
            $id = $this->createdInstanceTracker->getId ($matchLabel);
            $expected[$id] = $match;
            }
        return parent::validateOutput ($context, $actualOutput, $expected);
        }

    protected function generateDiagnosticsMessage ($context, $input, $actualOutput, $expectedOutput)
        {
        $expected = array();
        foreach ($expectedOutput as $matchLabel => $match)
            {
            $id = $this->createdInstanceTracker->getId ($matchLabel);
            $expected[$id] = $match;
            }
        return parent::generateDiagnosticsMessage ($context, $input, $actualOutput, $expected);
        }

    public function setInstanceTracker ($createdInstanceTracker)
        {
        $this->createdInstanceTracker = $createdInstanceTracker;
        }
    }

class LffFeedTestTeams extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_TEAM_CLUB => NULL,
                                Sports::COL_TEAM_TYPE => NULL,
                                "c_".Sports::COL_TEAM_PREFIX => NULL,
                                "c_".Sports::COL_TEAM_NAME => NULL,
                                "c_".Sports::COL_TEAM_CITY => NULL,
                                Sports::COL_TEAM_DECLINE => NULL,
                                Sports::COL_TEAM_SHOWPREFIX => NULL,
                                );
        $list[] = $this->createInsertTest ("Vilniaus kolegija",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Vilniaus kolegija",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               "c_from" => "2008-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               Sports::COL_TEAM_SHOWPREFIX => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Ozas (mens)",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Ozas",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               "c_from" => "2001-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Ozas",
                                        array (Sports::COL_TEAM_TYPE => 2,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Ozas",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               "c_from" => "2008-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Snoras-2",
                                        array (Sports::COL_TEAM_TYPE => 2,
                                               "c_".Sports::COL_TEAM_PREFIX => "",
                                               "c_".Sports::COL_TEAM_NAME => "Snoras",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               "c_from" => "2008-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               Sports::COL_TEAM_POSTFIX => "2",
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Navigatoriai",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FC",
                                               "c_".Sports::COL_TEAM_NAME => "Navigatoriai",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               "c_from" => "2009-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Oniksas",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "",
                                               "c_".Sports::COL_TEAM_NAME => "Oniksas",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2009-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Aleksotas",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Aleksotas",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2009-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Galinta",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "",
                                               "c_".Sports::COL_TEAM_NAME => "Galinta",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2009-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Gaschema",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Gaschema",
                                               "c_".Sports::COL_TEAM_CITY => "Jonava",
                                               "c_from" => "2009-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Fotofabrikas",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "",
                                               "c_".Sports::COL_TEAM_NAME => "Fotofabrikas",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2009-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Tauras",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FM",
                                               "c_".Sports::COL_TEAM_NAME => "Tauras",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2001-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Hegelmann Litauen",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "",
                                               "c_".Sports::COL_TEAM_NAME => "Hegelmann Litauen",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2009-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Celsis",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Celsis",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2001-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Spyris",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "",
                                               "c_".Sports::COL_TEAM_NAME => "Spyris",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2009-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("KTU",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "KTU",
                                               "c_".Sports::COL_TEAM_NAME => "",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2001-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Fortas",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Fortas",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2009-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("VDU",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "VDU",
                                               "c_".Sports::COL_TEAM_NAME => "",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2001-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("SC-STIHL",
                                        array (Sports::COL_TEAM_TYPE => 4,
                                               "c_".Sports::COL_TEAM_PREFIX => "SC",
                                               "c_".Sports::COL_TEAM_NAME => "STIHL",
                                               "c_".Sports::COL_TEAM_CITY => "Kazlų Rūda",
                                               "c_from" => "2000-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => false,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Vici",
                                        array (Sports::COL_TEAM_TYPE => 4,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Viči",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2000-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Penalty.lt",
                                        array (Sports::COL_TEAM_TYPE => 4,
                                               "c_".Sports::COL_TEAM_PREFIX => "",
                                               "c_".Sports::COL_TEAM_NAME => "Penalty.lt",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               "c_from" => "2000-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => false,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Nautara",
                                        array (Sports::COL_TEAM_TYPE => 4,
                                               "c_".Sports::COL_TEAM_PREFIX => "",
                                               "c_".Sports::COL_TEAM_NAME => "Nautara",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2000-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);

        return $list;
        }
    }

class LffFeedTestSeasons extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_SEASON);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_SEASON_NAME => NULL,
                                Sports::COL_SEASON_START => NULL,
                                Sports::COL_SEASON_END => NULL,
                                );
        $i = 2009;
        $list[] = $this->createInsertTest ("$i m.",
                                        array (Sports::COL_SEASON_NAME => "{$i} m",
                                               Sports::COL_SEASON_START => "$i-01-13",
                                               Sports::COL_SEASON_END => "$i-12-13"),
                                        $defaultValues, $createdInstances);

        return $list;
        }
    }

class LffFeedTestCompetitionSeasons extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_COMPETITION_NAME => NULL,
                                Sports::COL_COMPETITION_LEVEL => NULL,
                                Sports::COL_COMPETITION_LEAGUE => NULL,
                                );

        $list[] = $this->createInsertTest ("2009 Salės A lyga",
                                    array (Sports::COL_COMPETITION_NAME => "Salės A lyga",
                                           Sports::COL_COMPETITION_LEVEL => 1,
                                           Sports::COL_COMPETITION_STARTS => "2008-09-14",
                                           Sports::COL_COMPETITION_ENDS => "2009-04-14",
                                           Sports::COL_COMPETITION_SEASON => new InstanceIdPlaceholder ("2009 m."),
                                           Sports::COL_COMPETITION_FINALSTAGE => true,
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009 Other league",
                                    array (Sports::COL_COMPETITION_NAME => "Other league",
                                           Sports::COL_COMPETITION_LEVEL => 1,
                                           Sports::COL_COMPETITION_STARTS => "2008-03-14",
                                           Sports::COL_COMPETITION_ENDS => "2009-06-14",
                                           Sports::COL_COMPETITION_SEASON => new InstanceIdPlaceholder ("2009 m."),
                                           Sports::COL_COMPETITION_FINALSTAGE => true,
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009 KAFF",
                                    array (Sports::COL_COMPETITION_NAME => "Other league",
                                           Sports::COL_COMPETITION_LEVEL => 1,
                                           Sports::COL_COMPETITION_STARTS => "2008-11-14",
                                           Sports::COL_COMPETITION_ENDS => "2009-02-14",
                                           Sports::COL_COMPETITION_SEASON => new InstanceIdPlaceholder ("2009 m."),
                                           Sports::COL_COMPETITION_FINALSTAGE => true,
                                           ),
                                    $defaultValues, $createdInstances);
        return $list;
        }
    }

class LffFeedTestMatches extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_MATCH_HOMETEAM => NULL,
                                Sports::COL_MATCH_AWAYTEAM => NULL,
                                Sports::COL_MATCH_DATE => NULL,
                                Sports::COL_MATCH_COMPETITION => NULL,
                                );

        $list[] = $this->createInsertTest ("2009-01-06 Vilniaus kolegija-Ozas",
                                    array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Vilniaus kolegija"),
                                           Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Ozas"),
                                           Sports::COL_MATCH_DATE => "2009-01-06 19:00",
                                           Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2009 Salės A lyga"),
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009-01-09 Snoras-Navigatoriai",
                                    array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Snoras-2"),
                                           Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Navigatoriai"),
                                           Sports::COL_MATCH_DATE => "2009-01-09 15:15",
                                           Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2009 Salės A lyga"),
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009-01-07 Oniksas-Aleksotas",
                                    array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Oniksas"),
                                           Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Aleksotas"),
                                           Sports::COL_MATCH_DATE => "2009-01-07 19:00",
                                           Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2009 KAFF"),
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009-01-07 Galinta-Gaschema",
                                    array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Galinta"),
                                           Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Gaschema"),
                                           Sports::COL_MATCH_DATE => "2009-01-07 19:00",
                                           Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2009 KAFF"),
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009-01-07 Fotofabrikas-Tauras",
                                    array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Fotofabrikas"),
                                           Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Tauras"),
                                           Sports::COL_MATCH_DATE => "2009-01-07 19:00",
                                           Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2009 KAFF"),
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009-01-07 Hegelmann Litauen-Celsis",
                                    array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Hegelmann Litauen"),
                                           Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Celsis"),
                                           Sports::COL_MATCH_DATE => "2009-01-07 19:00",
                                           Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2009 KAFF"),
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009-01-08 Spyris-KTU",
                                    array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Spyris"),
                                           Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("KTU"),
                                           Sports::COL_MATCH_DATE => "2009-01-08 19:00",
                                           Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2009 KAFF"),
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009-01-08 Fortas-VDU",
                                    array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Fortas"),
                                           Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("VDU"),
                                           Sports::COL_MATCH_DATE => "2009-01-08 19:00",
                                           Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2009 KAFF"),
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009-01-15 SC-STIHL-Vici",
                                    array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("SC-STIHL"),
                                           Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Vici"),
                                           Sports::COL_MATCH_DATE => "2009-01-15 17:10",
                                           Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2009 Salės A lyga"),
                                           ),
                                    $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2009-01-15 Penalty.lt-Nautara",
                                    array (Sports::COL_MATCH_HOMETEAM => new InstanceIdPlaceholder ("Penalty.lt"),
                                           Sports::COL_MATCH_AWAYTEAM => new InstanceIdPlaceholder ("Nautara"),
                                           Sports::COL_MATCH_DATE => "2009-01-15 19:00",
                                           Sports::COL_MATCH_COMPETITION => new InstanceIdPlaceholder ("2009 Salės A lyga"),
                                           ),
                                    $defaultValues, $createdInstances);
        return $list;
        }
    }

class LffFeedTestLeagueTeams extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMLEAGUESEASON);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => NULL,
                                Sports::TABLE_TEAM."_id" => NULL,
                                "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => NULL,
                                );
        $list[] = $this->createInsertTest ("Ozas (mens)2009",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2009 Other league"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("Ozas (mens)"),
                                               ),
                                        $defaultValues, $createdInstances);
        foreach (array ("SC-STIHL", "Vici", "Penalty.lt", "Nautara", "Navigatoriai", "Snoras-2", "Ozas", "Vilniaus kolegija") as $team)
            {
            $list[] = $this->createInsertTest ("$team 2009",
                                            array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2009 Salės A lyga"),
                                                   Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ($team),
                                                   ),
                                            $defaultValues, $createdInstances);
            }
        foreach (array ("Oniksas", "Aleksotas", "Galinta", "Gaschema", "Fotofabrikas", "Tauras",
                        "Hegelmann Litauen", "Celsis", "Spyris", "KTU", "Fortas", "VDU") as $team)
            {
            $list[] = $this->createInsertTest ("$team 2009",
                                            array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2009 KAFF"),
                                                   Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ($team),
                                                   ),
                                            $defaultValues, $createdInstances);
            }
        return $list;
        }
    }

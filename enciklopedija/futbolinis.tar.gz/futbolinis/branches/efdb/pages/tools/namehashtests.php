<?php
require_once (PATH.'inc/testcollection.php');
require_once (PATH.'h/othernamestable.php');

class NameHashTests extends TestCollection
    {
    public function removeDiacritics ($context, $input)
        {
        return OtherNamesTable::removeDiacritics ($input);
        }

    public function validate ($context, $actualOutput, $expectedOutput)
        {
        return $actualOutput == OtherNamesTable::removeDiacritics ($expectedOutput);
        }

    protected function newHashTest ($input, $expectedOutput)
        {
        $expected = OtherNamesTable::removeDiacritics ($expectedOutput);
        if ("." == $input[strlen (trim ($input)) - 1])
            $expected = substr ($expected, 0, 1);

        return $this->createTest ("$input => $expectedOutput", $input, array ($this, "removeDiacritics"), $expected);
        }

    public function validateAlternatives ($context, $actualOutput, $expectedOutput)
        {
        $alternativePairs = $actualOutput;
        list ($expectedName, $expectedSurname) = $expectedOutput;

        $found = false;
        foreach ($alternativePairs as $alternative)
            {
            if ($alternative[0] == $expectedName && $alternative[1] == $expectedSurname)
                {
                $found = true;
                break;
                }
            }

        return $found;
        }

    public function createAlternatives ($context, $input)
        {
        list ($originalName, $originalSurname) = $input;
        return OtherNamesTable::createAlternativeNamePairs ($originalName, $originalSurname);
        }

    protected function newAlternativesTest ($descriptor)
        {
        list ($originalName, $originalSurname, $expectedName, $expectedSurname) = $descriptor;
        $expectedName = OtherNamesTable::removeDiacritics ($expectedName);
        $expectedSurname = OtherNamesTable::removeDiacritics ($expectedSurname);

        return $this->createTest ("$originalSurname, $originalName => {$descriptor[3]}, {$descriptor[2]}", 
                                  array ($originalName, $originalSurname),
                                  array ($this, "createAlternatives"),
                                  array ($expectedName, $expectedSurname),
                                  array ($this, "validateAlternatives"));
        }

    public function enumerateTests ($context)
        {
        $pairs = array
            (
            "Europa" => "europa",
            "Africa" => "Afrika",
            "Šaržas" => "sarzas",
            "Sharzhas" => "Šaržas",
            "ĄČĘŠĖŽĮČŲČŪ" => "acesezicucu",
            "Þoður" => "Thodur",
            "Wiłeň" => "Vilen",
            "Aleksej" => "Alexei",
            "Slesarcuk" => "Slesarčuks",
            "Vyacheslav" => "Viačaslav",
            "Heraščenko" => "Gerashchenko",
            "Yevgeni" => "Jevgenij",
            "Aleksandr" => "Aliaksandar",
            "Aliaksandar" => "Alexandr",
            "Kšivickas" => "Ksivickas",
            "Oleksandr" => "Alexander",
            "Kulčyj" => "Kulchyi",
            "Luchvič" => "Lukhvitch",
            "Lukhvich" => "Luchvič",
            "Jurgelevič" => "Jurgelevičius",
            "Jurgelėvič" => "Jurgelevicius",
            "Djidic" => "Ðidić",
            "Ðidić" => "Dzidic",
            "Hristo" => "Christo",
            "Stančaitis" => "stancaitis",
            "Giorgi" => "George",
            "Bjhalava" => "Bzhalava",
            "Mrđa" => "Mrda",
            "MacDonald" => "McDonald",
            "Mackus" => "Mačkus",
            "Kamčatka" => "kamcatka",
            "Jean-Marc" => "Jean Marc",
            "Jeanmarc" => "Jean Marc",
            "Vasileios" => "Vasilios",
            "Mpoukouvalas" => "Boukouvalas", // greek 'μπ' is transliterated as 'b' at the beginning or end of a word
            "Mpokouvalas" => "Bokouvalas", // greek 'μπ' is transliterated as 'b' at the beginning or end of a word
            "Mpampaniotis" => "babaniotis",
            "karamp" => "karab",
            "Koutsianikuolis" => "Koutsianikoulis",
            "Aristides" => "Aristeidis",
            "Dimitris" => "Dimitrios",
            "Vitaliy" => "Vitalii",
            "Kosovskiy" => "Kossovskyi",
            "Kosovskij" => "Kossovskyi",
            "Tamašauskas" => "Tomašauskas",
            "Kavoliovas" => "Kavaliovas",
            "Zagurskis" => "Zagurskas",
            "Bracas" => "Bračas",
            "Naudziunas" => "Naudžiūnas",
            "Cesnulis" => "Česnulis",
            "Paweł Brożek" => "Pawel Brozek",
            "Zilvinas" => "Žilvinas",
            "Kvaratskhelia" => "Kvaracchelija",
            "Šuhanav" => "Shuhanau",
            "Šukanav" => "Šukanov",
            "Denis" => "Dennis",
            "Rodnenok " => "Rodnionok",
            "Jacobsen " => "Jakobson",
            "Jacobssen " => "Jakobsen",
            "Siakas" => "Siakkas",
            "Andrei" => "Andrej",
            "Eugeni" => "Evgeny",
            "Kirill" => "Kiril",
            "Fjodorov" => "Fyodorov",
            "Serguei" => "Sergey",
            "Serguei van" => "Sergey van",
            "Zagurskis Petras" => "Zagurskas Petras",
            "Kirsis" => "Kiršis",
            "Latusenko" => "Latušenka",
            "Visnakovs" => "Višņakovs",
            "Jurgenson" => "Jürgenson",
            "Jura" => "Jūra",
            "Laizāns" => "Laizans",
            "Kristiāns" => "Kristian",
            "Ivanov" => "Ivanovas",
            "Ivanovs" => "Ivanovas",
            "Zagurskas" => "Zagurskyi",
            "Matovič" => "Matovic",
            "Miezis" => "Miežys",
            "Kristian" => "Christian",
            "Ščerbin" => "Shcherbin",
            "samsonik" => "Samsonikas",
            "Jevgēņijs" => "Jevgenijs",
            "Moroz" => "Morozas",
            "Maroz" => "Morozas",
            "maroz" => "Moroz",
            "Kağan" => "Kagan",
            "Kılıç" => "Kilic",
            "Miķelsons" => "Mikelsons",
            "Răzvan Raţ" => "Razvan Rat",
            "Sergejus" => "Sergėj",
            "Genadiy" => "Genadijus",
            "Genadij" => "Genadyi",
            "Marijus " => "Marius",
            "Petru Ţurcaş " => "Petru Turcas",
            "Farhad Velijev" => "Farkhad Veliyev",
            "Joonas T" => "Joonas Tamm",
            "Mossoro" => "Mossoró",
            "Mosoro" => "Mossoró",
            "J." => "Julius",
            "j." => "Jevgenijus",
            "J. " => "Yury",
            "J.  " => "Jonas",
            "I." => "Yury",
            "Z." => "Žilvinas",
            "Ž." => "Žemaitis",
            "z." => "Zigmantas",
            "K." => "Kęstutis",
            "Ch." => "Christian",
            "H." => "Hristo",
            );

        $expectedAlternatives = array
            (
            array ("Jean", "De Sollin", "Jean De", "Sollin"),
            array ("Peter Van", "De Kuper", "Peter", "Van De Kuper"),
            array ("Peter Van", "De Kuper", "Peter Van De", "Kuper"),
            array ("Peter Van De", "Kuper", "Peter", "Van De Kuper"),
            array ("Peter Van De", "Kuper", "Peter Van", "De Kuper"),
            array ("Peter", "Van De Kuper", "Peter Van", "De Kuper"),
            array ("Louis-Marc", "Poulan", "Louis", "Mark-Poulan"),
            array ("Marco", "Antonio Mendes De Almeida", "Marco Antonio Méndez de", "Almeida"),
            );

        $list = array ();
        foreach ($pairs as $first => $second)
            {
            $list[] = $this->newHashTest ($first, $second);
            }
        foreach ($expectedAlternatives as $descriptor)
            {
            $list[] = $this->newAlternativesTest ($descriptor);
            }
        return $list;
        }

    }

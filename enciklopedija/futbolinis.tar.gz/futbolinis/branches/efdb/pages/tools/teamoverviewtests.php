<?php
require_once (PATH.'inc/dbtabletestcollection.php');
require_once (PATH.'inc/compositetestcollection.php');
require_once (PATH.'pages/sports/leagueprojectioncomponent.php');
require_once (PATH."pages/sports/teampreseasonchanges.php");

class TeamOverviewTests extends CompositeTestCollection
    {
    protected $createdInstanceTracker;

    public function __construct ($prefix, $context, $parent)
        {
        parent::__construct ($prefix, $context, $parent);
        $this->createdInstanceTracker = new CreatedTestInstances ();
        }
    
    public function run ($context, $diagnoseTest = NULL, $atomic = false)
        {
        return parent::run ($context, $diagnoseTest, true);
        }

    public function enumerateTests ($context)
        {
        $tests = parent::enumerateTests ($context);

        foreach ($this->getTestCases () as $match => $expectedOutput)
            {
            $test = $this->createOverviewTest ($match, $expectedOutput);
            $test->setInstanceTracker ($this->createdInstanceTracker);
            $tests[] = $test;
            }

        return $tests;
        }

    public function teamOverview ($context, $input)
        {
        $leagueId = $this->createdInstanceTracker->getId ($input);
        if (!$leagueId)
            {
            $context->addError ("Instance '$input' was not created");
            return false;
            }

        $competitiontable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $parentColumn = ContentTable::generateForeignKeyColumn (Sports::COL_COMPETITION_LEAGUE, Sports::TABLE_LEAGUE."_id");
        $columns = array ($parentColumn, Sports::COL_COMPETITION_STARTS, Sports::COL_COMPETITION_ENDS);
        $leagueRow = $competitiontable->selectSingleBy ($columns, array (new EqCriterion ($competitiontable->getIdColumn (), $leagueId)));
        $changesComponent = new LeagueProjectionComponent ($context, $competitiontable, $leagueId, $leagueRow);
        if ($changesComponent->initialize ($this->context->request, $this))
            $components = $changesComponent->getComponents ();

        if (empty ($components))
            return NULL;
        $result = array ();
        foreach ($components as $c)
            {
            $componentId = $c->id;
            if (preg_match ('/([0-9]+)/', $componentId, $match) > 0)
                $teamId = $match[0];
            else
                $teamId = false;

            $statistics = CompetitionStatistics::getTeamGeneralStatistics ($context, $teamId, $leagueId);

            $changesComponent = new TeamPreseasonChanges ($this, "cid$teamId", "title", $leagueId, $teamId);
            if (!$changesComponent->initialize ($this->context->request, $this))
                continue;
            
            $playerChanges = $changesComponent->getData ();

            $changesComponent = new TeamNameChanges ($this, "nid$teamId", "title", $leagueId, $teamId);
            if (!$changesComponent->initialize ($this->context->request, $this))
                continue;
            
            $nameChanges = $changesComponent->getData ();
            $result[$c->getTitle ()] = array ("players" => $playerChanges, "names" => $nameChanges, "stats" => $statistics);
            }

        ksort ($result);

        return $result;
        }

    protected function skipWhiteSpace ($text)
        {
        return trim (preg_replace ("#[\r\n ]+#m", " ", $text));
        }

    public function validateTeamOverview ($context, $actualOutput, $expectedOutput)
        {
        $expectedList = array ();
        foreach ($expectedOutput as $name => $output)
            {
            $players = &$output['players'];
            foreach ($players as &$type)
                foreach ($type as &$position)
                    {
                    usort ($position, array ("TeamOverviewTests", "compareByLabel"));

                    foreach ($position as &$p)
                        {
                        $p['url'] = preg_replace_callback ("/@([^@]+)@/mu", array ($this, "replaceIdentifiers"), $p['url']);
                        }
                    }

            $expectedList[$name] = $output;
            }

        return $expectedList == $actualOutput;
        }

    public static function compareByLabel ($a, $b)
        {
        return $b["label"] > $a["label"] ? 1 : ($b["label"] < $a["label"] ? -1 : 0);
        }

    public function replaceIdentifiers ($matches)
        {
        $id = $this->createdInstanceTracker->getId ($matches[1]);
        if (false !== $id)
            return $id;
        return $matches[1];
        }
        
    protected function createOverviewTest ($match, $expectedResults)
        {
        return parent::createTest ("Team overview: $match", $match, array ($this, "teamOverview"), $expectedResults, array ($this, "validateTeamOverview"), "TeamOverviewTest");
        }

    public function enumerateDependencies ($context, $parent)
        {
        return array
            (
            new OverviewCountryTests ("dep_country", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new OverviewPositionTests ("dep_pos", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new OverviewSeasonTests ("dep_seas", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new OverviewLeagueTests ("dep_leag", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new OverviewCompetitionSeasonsTests ("dep_cs", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new OverviewClubTests ("dep_club", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new OverviewTeamTests ("dep_team", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new OverviewAchievementTests ("dep_ach", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new OverviewCupAchievementTests ("dep_cach", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new OverviewPersonTests ("dep_pers", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            new OverviewTeamPlayers ("dep_tmpl", $context, $parent, $this->rootTest, $this->createdInstanceTracker),
            );
        }
    
    protected function getTestCases ()
        {
        return array
        (
        "2013 A lyga" => array
            (
                'Ekranas' => array
                                (
                                'players' =>
                                    array
                                        (
                                        'Iš komandos pasitraukė:' => 
                                        array (
                                            'Vairininkas' => 
                                                array (
                                                    array (
                                                        'label' => 'Petras Petrauskas',
                                                        'url' => 'http://localhost/content/persons/@Petras Petrauskas@/lt',
                                                        'position' => 'Vairininkas',
                                                        'additional' => 'perėjo į Vilniaus VMFD „Žalgirį“',
                                                    ),
                                                ),
                                            ),
                                        'Prie komandos prisijungė:' => 
                                        array
                                            (
                                            'Sargai' => 
                                                array
                                                    (
                                                    array ('label' => 'Jonas Jonaitis',
                                                           'url' => 'http://localhost/content/persons/@Jonas Jonaitis@/lt',
                                                           'position' => 'Sargas', 'additional' => "iš Vilniaus VMFD „Žalgirio“",
                                                           ),
                                                    array ('label' => 'Stasys Stasaitis',
                                                           'url' => 'http://localhost/content/persons/@Stasys Stasaitis@/lt',
                                                           'position' => 'Sargas', 'additional' => NULL,
                                                           ),
                                                    ),
                                            ),
                                        ),
                                'names' => array (0 => 'Statybininkas', 1 => 'Ekranas'),
                                'stats' =>
                                    array
                                        (
                                        'seasons' => '13-as sezonas (be pertraukų)',
                                        'firstseason' => '2001m.',
                                        'maxplace' => '1 vieta (3 kartus)',
                                        'seasons1st' => '3 kartus - 2010m., 2011m., 2012m.',
                                        'seasons2nd' => NULL,
                                        'seasons3rd' => '1 kartą - 2009m.',
                                        'team' => 'Panevezio „Ekranas“',
                                        ),
                                ),
                "REO" => array
                                (
                                "names" => array (), "players" => array (),
                                "stats" =>
                                    array
                                        (
                                        'seasons' => 'Debiutinis sezonas',
                                        'team' => 'Vilniaus REO'
                                        )
                                ),
                "Žalgiris" => array
                                (
                                'players' =>
                                    array
                                        (
                                        'Iš komandos pasitraukė:' => 
                                        array (
                                            'Sargas' => 
                                                array (
                                                    array (
                                                        'label' => 'Jonas Jonaitis',
                                                        'url' => 'http://localhost/content/persons/@Jonas Jonaitis@/lt',
                                                        'position' => 'Sargas',
                                                        'additional' => 'perėjo į Panevezio „Ekraną“',
                                                    ),
                                                ),
                                            ),
                                        'Prie komandos prisijungė:' => 
                                        array
                                            (
                                            'Vairininkas' => 
                                                array
                                                    (
                                                    array ('label' => 'Petras Petrauskas',
                                                           'url' => 'http://localhost/content/persons/@Petras Petrauskas@/lt',
                                                           'position' => 'Vairininkas', 'additional' => "iš Panevezio „Ekrano“",
                                                           ),
                                                    ),
                                            ),
                                        ),
                                "names" => array ('Spartakas', 'Žalgiris'),
                                "stats" =>
                                    array
                                        (
                                        'seasons' => '8-as sezonas',
                                        'seasonsstraight' => '4-as sezonas (nuo 2010m.)',
                                        'firstseason' => '1945m.',
                                        'maxplace' => "2 vieta (2 kartus)",
                                        'seasons1st' => NULL,
                                        'seasons2nd' => '2 kartus - 2001m., 2011m.',
                                        'seasons3rd' => '2 kartus - 1960-1961m., 2010m.',
                                        'team' => 'Vilniaus VMFD „Žalgiris“'
                                        )
                                ),
            ),
        );
        }
    }

class TeamOverviewTest extends CallbackTest
    {
    protected function generateDiagnosticsMessage ($context, $input, $actualOutput, $expectedOutput)
        {
        if (!is_array ($expectedOutput))
            return parent::generateDiagnosticsMessage ($context, $input, $actualOutput, $expectedOutput);

        $prepared = array ();
        foreach ($expectedOutput as $key => $result)
            {
            $players = &$result['players'];
            foreach ($players as &$type)
                foreach ($type as &$position)
                    {
                    usort ($position, array ("TeamOverviewTests", "compareByLabel"));

                    foreach ($position as &$p)
                        {
                        $p['url'] = preg_replace_callback ("/@([^@]+)@/mu", array ($this, "replaceIdentifiers"), $p['url']);
                        }
                    }

            $prepared[$key] = $result;
            }

        return parent::generateDiagnosticsMessage ($context, $input, $actualOutput, $prepared);
        }

    public function replaceIdentifiers ($matches)
        {
        $id = $this->createdInstanceTracker->getId ($matches[1]);
        if (false !== $id)
            return $id;
        return $matches[1];
        }

    public function setInstanceTracker ($createdInstanceTracker)
        {
        $this->createdInstanceTracker = $createdInstanceTracker;
        }
    }

class OverviewTeamTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAM);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_TEAM_CLUB => NULL,
                                Sports::COL_TEAM_TYPE => NULL,
                                "c_".Sports::COL_TEAM_PREFIX => NULL,
                                "c_".Sports::COL_TEAM_NAME => NULL,
                                "c_".Sports::COL_TEAM_CITY => NULL,
                                Sports::COL_TEAM_DECLINE => NULL,
                                Sports::COL_TEAM_SHOWPREFIX => NULL,
                                );
        $list[] = $this->createInsertTest ("VMFD",
                                        array (Sports::COL_TEAM_CLUB => new InstanceIdPlaceholder ("FC Zalgiris"),
                                               Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "VMFD",
                                               "c_".Sports::COL_TEAM_NAME => "Žalgiris",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               "c_from" => "2001-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               Sports::COL_TEAM_SHOWPREFIX => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Zalgiris",
                                        array (Sports::COL_TEAM_CLUB => new InstanceIdPlaceholder ("FC Zalgiris"),
                                               Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Žalgiris",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               "c_from" => "1991-00-00 00:00:00",
                                               "c_to" => "2000-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Spartakas",
                                        array (Sports::COL_TEAM_CLUB => new InstanceIdPlaceholder ("FC Zalgiris"),
                                               Sports::COL_TEAM_TYPE => 1,
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Spartakas",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               "c_from" => "1945-00-00 00:00:00",
                                               "c_to" => "1955-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Statybininkas",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               Sports::COL_TEAM_CLUB => new InstanceIdPlaceholder ("FK Ekranas"),
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Statybininkas",
                                               "c_".Sports::COL_TEAM_CITY => "Panevezys",
                                               "c_from" => "1991-00-00 00:00:00",
                                               "c_to" => "2000-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Ekranas",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               Sports::COL_TEAM_CLUB => new InstanceIdPlaceholder ("FK Ekranas"),
                                               "c_".Sports::COL_TEAM_PREFIX => "FK",
                                               "c_".Sports::COL_TEAM_NAME => "Ekranas",
                                               "c_".Sports::COL_TEAM_CITY => "Panevezys",
                                               "c_from" => "2001-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("REO",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               Sports::COL_TEAM_CLUB => NULL,
                                               "c_".Sports::COL_TEAM_PREFIX => "REO",
                                               "c_".Sports::COL_TEAM_NAME => "",
                                               "c_".Sports::COL_TEAM_CITY => "Vilnius",
                                               "c_from" => "2007-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Just",
                                        array (Sports::COL_TEAM_TYPE => 1,
                                               Sports::COL_TEAM_CLUB => NULL,
                                               "c_".Sports::COL_TEAM_PREFIX => "Just",
                                               "c_".Sports::COL_TEAM_NAME => "",
                                               "c_".Sports::COL_TEAM_CITY => "Kaunas",
                                               "c_from" => "2000-00-00 00:00:00",
                                               Sports::COL_TEAM_DECLINE => true,
                                               ),
                                        $defaultValues, $createdInstances);

        return $list;
        }
    }

class OverviewAchievementTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMLEAGUESEASON);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => NULL,
                                Sports::TABLE_TEAM."_id" => NULL,
                                "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => NULL,
                                );
        $list[] = $this->createInsertTest ("REO2013",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2013 A lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("REO"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("VMFD2013",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2013 A lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("VMFD"),
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Ekranas2013",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2013 A lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("Ekranas"),
                                               ),
                                        $defaultValues, $createdInstances);

        $list[] = $this->createInsertTest ("VMFD2012",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2012 A lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("VMFD"),
                                               "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => 4
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("VMFD2011",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2011 A lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("VMFD"),
                                               "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => 2
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("VMFD2010",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2010 A lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("VMFD"),
                                               "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => 3
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Spart1945",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("1945 LFF lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("Spartakas"),
                                               "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => 8
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Spart1946",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("1946 LFF lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("Spartakas"),
                                               "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => 4
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Spart1960-61",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("1960-1961 LFF lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("Spartakas"),
                                               "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => 3
                                               ),
                                        $defaultValues, $createdInstances);

        $list[] = $this->createInsertTest ("Statybininkas2001",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2001 A lyga 1"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("Statybininkas"),
                                               "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => 1
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Statybininkas2002",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("2002 A lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("Statybininkas"),
                                               "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => 12
                                               ),
                                        $defaultValues, $createdInstances);
        for ($i = 2003; $i < 2013; $i++)
            $list[] = $this->createInsertTest ("Ekranas$i",
                                        array (Sports::COL_TEAMLEAGUESEASON_COMPETITION => new InstanceIdPlaceholder ("$i A lyga"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("Ekranas"),
                                               "c_".Sports::COL_TEAMLEAGUESEASON_PLACE => $i > 2009 ? 1 : 2012-$i
                                               ),
                                        $defaultValues, $createdInstances);
        return $list;
        }
    }

class OverviewCupAchievementTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMCUPSEASON);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $achievementColumn = ContentTable::generateForeignKeyColumn (Sports::COL_TEAMCUPSEASON_ACHIEVEMENT, Sports::TABLE_ROUND."_id");
        $defaultValues = array (Sports::COL_TEAMCUPSEASON_COMPETITION => NULL,
                                Sports::TABLE_TEAM."_id" => NULL,
                                $achievementColumn => NULL,
                                );
        $list[] = $this->createInsertTest ("VMFD2013",
                                        array (Sports::COL_TEAMCUPSEASON_COMPETITION => new InstanceIdPlaceholder ("2001 A lyga 2"),
                                               Sports::TABLE_TEAM."_id" => new InstanceIdPlaceholder ("VMFD"),
                                               $achievementColumn => 2
                                               ),
                                        $defaultValues, $createdInstances);

        return $list;
        }
    }

class OverviewClubTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_CLUB);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_CLUB_CITY => NULL,
                                Sports::COL_CLUB_NAME => NULL,
                                Sports::COL_CLUB_PREFIX => NULL,
                                );
        $list[] = $this->createInsertTest ("FC Zalgiris",
                                        array (Sports::COL_CLUB_CITY => "Vilnius",
                                               Sports::COL_CLUB_NAME => "Zalgiris",
                                               Sports::COL_CLUB_PREFIX => NULL,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("FK Ekranas",
                                        array (Sports::COL_CLUB_CITY => "Panevezys",
                                               Sports::COL_CLUB_NAME => "Ekranas",
                                               Sports::COL_CLUB_PREFIX => NULL,
                                               ),
                                        $defaultValues, $createdInstances);

        return $list;
        }
    }

class OverviewLeagueTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_LEAGUE);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_LEAGUE_NAME => NULL,
                                );
        $list[] = $this->createInsertTest ("LFF lyga",
                                        array (Sports::COL_LEAGUE_NAME => "LFF lyga",
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("A lyga",
                                        array (Sports::COL_LEAGUE_NAME => "A-lyga",
                                               Sports::COL_LEAGUE_PREDECESSOR => new InstanceIdPlaceholder ("LFF lyga"),
                                               ),
                                        $defaultValues, $createdInstances);
        return $list;
        }
    }

class OverviewSeasonTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_SEASON);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_SEASON_NAME => NULL,
                                Sports::COL_SEASON_START => NULL,
                                Sports::COL_SEASON_END => NULL,
                                );
        $i = 1945;
        for (; $i < 1950; ++$i)
            $list[] = $this->createInsertTest ("$i m.",
                                            array (Sports::COL_SEASON_NAME => "{$i}m.",
                                                   Sports::COL_SEASON_START => "$i-01-11",
                                                   Sports::COL_SEASON_END => "$i-12-11"),
                                            $defaultValues, $createdInstances);

        $list[] = $this->createInsertTest ("1960-1961 m.",
                                        array (Sports::COL_SEASON_NAME => "1960-1961m.",
                                               Sports::COL_SEASON_START => "1960-09-00",
                                               Sports::COL_SEASON_END => "1961-06-00"),
                                        $defaultValues, $createdInstances);

        $i = 2001;
        for (; $i < 2014; ++$i)
            $list[] = $this->createInsertTest ("$i m.",
                                            array (Sports::COL_SEASON_NAME => "{$i}m.",
                                                   Sports::COL_SEASON_START => "$i-01-11",
                                                   Sports::COL_SEASON_END => "$i-12-11"),
                                            $defaultValues, $createdInstances);

        return $list;
        }
    }

class OverviewCountryTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_COUNTRY);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_COUNTRY_NAME => NULL,
                                );
        $list[] = $this->createInsertTest ("Dalmatija",
                                            array (Sports::COL_COUNTRY_NAME => "Dalmatija"),
                                            $defaultValues, $createdInstances);
        return $list;
        }
    }

class OverviewPositionTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, "position");
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array ("c_name" => NULL,
                                );
        $list[] = $this->createInsertTest ("Saugas",
                                            array ("c_name" => "Sargas"),
                                            $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Vartininkas",
                                            array ("c_name" => "Vairininkas"),
                                            $defaultValues, $createdInstances);
        return $list;
        }
    }

class OverviewCompetitionSeasonsTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_COMPETITIONSTAGE);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_COMPETITION_NAME => NULL,
                                Sports::COL_COMPETITION_LEVEL => NULL,
                                Sports::COL_COMPETITION_LEAGUE => NULL,
                                );

        $i = 1945;
        for (; $i < 1950; ++$i)
            {
            $list[] = $this->createInsertTest ("$i LFF lyga",
                                        array (Sports::COL_COMPETITION_NAME => "LFF lyga",
                                               Sports::COL_COMPETITION_LEVEL => 1,
                                               Sports::COL_COMPETITION_STARTS => "$i-03-14",
                                               Sports::COL_COMPETITION_ENDS => "$i-11-14",
                                               Sports::COL_COMPETITION_LEAGUE => new InstanceIdPlaceholder ("LFF lyga"),
                                               Sports::COL_COMPETITION_SEASON => new InstanceIdPlaceholder ("$i m."),
                                               Sports::COL_COMPETITION_FINALSTAGE => true,
                                               ),
                                        $defaultValues, $createdInstances);
            }

        $list[] = $this->createInsertTest ("1960-1961 LFF lyga",
                                        array (Sports::COL_COMPETITION_NAME => "LFF lyga",
                                               Sports::COL_COMPETITION_LEVEL => 1,
                                               Sports::COL_COMPETITION_STARTS => "1960-08-14",
                                               Sports::COL_COMPETITION_ENDS => "1961-05-23",
                                               Sports::COL_COMPETITION_LEAGUE => new InstanceIdPlaceholder ("LFF lyga"),
                                               Sports::COL_COMPETITION_SEASON => new InstanceIdPlaceholder ("1960-1961 m."),
                                               Sports::COL_COMPETITION_FINALSTAGE => true,
                                               ),
                                        $defaultValues, $createdInstances);

        $i = 2002;
        for (; $i < 2014; ++$i)
            {
            $list[] = $this->createInsertTest ("$i A lyga",
                                        array (Sports::COL_COMPETITION_NAME => "A lyga",
                                               Sports::COL_COMPETITION_LEVEL => 1,
                                               Sports::COL_COMPETITION_STARTS => "$i-03-14",
                                               Sports::COL_COMPETITION_ENDS => "$i-11-14",
                                               Sports::COL_COMPETITION_LEAGUE => new InstanceIdPlaceholder ("A lyga"),
                                               Sports::COL_COMPETITION_SEASON => new InstanceIdPlaceholder ("$i m."),
                                               Sports::COL_COMPETITION_FINALSTAGE => true,
                                               ),
                                        $defaultValues, $createdInstances);
            }

        $list[] = $this->createInsertTest ("2001 A lyga",
                                        array (Sports::COL_COMPETITION_NAME => "A lyga",
                                               Sports::COL_COMPETITION_LEVEL => 1,
                                               Sports::COL_COMPETITION_STARTS => "2001-03-14",
                                               Sports::COL_COMPETITION_ENDS => "2001-10-23",
                                               Sports::COL_COMPETITION_LEAGUE => new InstanceIdPlaceholder ("A lyga"),
                                               Sports::COL_COMPETITION_SEASON => new InstanceIdPlaceholder ("2001 m."),
                                               Sports::COL_COMPETITION_FINALSTAGE => false,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2001 A lyga 1",
                                        array (Sports::COL_COMPETITION_NAME => "A lyga",
                                               Sports::COL_COMPETITION_LEVEL => 1,
                                               Sports::COL_COMPETITION_STARTS => "2001-03-14",
                                               Sports::COL_COMPETITION_ENDS => "2001-06-23",
                                               Sports::COL_COMPETITION_PARENT => new InstanceIdPlaceholder ("2001 A lyga"),
                                               Sports::COL_COMPETITION_LEAGUE => new InstanceIdPlaceholder ("A lyga"),
                                               Sports::COL_COMPETITION_SEASON => new InstanceIdPlaceholder ("2001 m."),
                                               Sports::COL_COMPETITION_FINALSTAGE => false,
                                               ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("2001 A lyga 2",
                                        array (Sports::COL_COMPETITION_NAME => "A lyga",
                                               Sports::COL_COMPETITION_LEVEL => 1,
                                               Sports::COL_COMPETITION_STARTS => "2001-07-14",
                                               Sports::COL_COMPETITION_ENDS => "2001-10-23",
                                               Sports::COL_COMPETITION_PARENT => new InstanceIdPlaceholder ("2001 A lyga"),
                                               Sports::COL_COMPETITION_LEAGUE => new InstanceIdPlaceholder ("A lyga"),
                                               Sports::COL_COMPETITION_SEASON => new InstanceIdPlaceholder ("2001 m."),
                                               Sports::COL_COMPETITION_FINALSTAGE => true,
                                               ),
                                        $defaultValues, $createdInstances);
        return $list;
        }
    }

class OverviewPersonTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_PERSON);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array ("c_".Sports::COL_PERSON_FULL_NAME => NULL,
                                "c_".Sports::COL_PERSON_BIRTHDATE => NULL,
                                );
        foreach (array ("Petras Petrauskas" => "1982-02-02",
                        "Jonas Jonaitis" => "1983-03-03",
                        "Stasys Stasaitis" => "1988-08-08",
                        "Pranas Pranaitis" => "1980-01-01",
                        ) as $name => $date)
            {
            $list[] = $this->createInsertTest ($name,
                                               array ("c_".Sports::COL_PERSON_FULL_NAME => $name,
                                                      "c_".Sports::COL_PERSON_BIRTHDATE => $date),
                                        $defaultValues, $createdInstances);
            }

        return $list;
        }
    }

class OverviewTeamPlayers extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent, $rootTest, $createdInstances)
        {
        parent::__construct ($prefix, $context, $parent, $rootTest);
        $this->dbtable = ContentTable::createInstanceByName ($context, Sports::TABLE_TEAMPLAYER);
        $this->createdInstanceTracker = $createdInstances;
        }

    public function enumerateTests ($context)
        {
        $createdInstances = array ();
        $list = array ();
        $defaultValues = array (Sports::COL_TEAMPLAYER_TEAM => NULL,
                                Sports::COL_TEAMPLAYER_PLAYER => NULL,
                                "c_".Sports::COL_TEAMPLAYER_STARTED => NULL,
                                "c_".Sports::COL_TEAMPLAYER_ENDED => NULL,
                                Sports::COL_TEAMPLAYER_POSITION => NULL,
                                );
        $list[] = $this->createInsertTest ("Petras Petrauskas2011",
                                           array (Sports::COL_TEAMPLAYER_TEAM => new InstanceIdPlaceholder ("Ekranas"),
                                                  Sports::COL_TEAMPLAYER_PLAYER => new InstanceIdPlaceholder ("Petras Petrauskas"),
                                                  "c_".Sports::COL_TEAMPLAYER_STARTED => "2011-01-12",
                                                  "c_".Sports::COL_TEAMPLAYER_ENDED => "2012-10-00",
                                                  Sports::COL_TEAMPLAYER_POSITION => new InstanceIdPlaceholder ("Vartininkas"),
                                                  ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Petras Petrauskas 2013",
                                           array (Sports::COL_TEAMPLAYER_TEAM => new InstanceIdPlaceholder ("VMFD"),
                                                  Sports::COL_TEAMPLAYER_PLAYER => new InstanceIdPlaceholder ("Petras Petrauskas"),
                                                  "c_".Sports::COL_TEAMPLAYER_STARTED => "2013-00-00",
                                                  "c_".Sports::COL_TEAMPLAYER_ENDED => NULL,
                                                  Sports::COL_TEAMPLAYER_POSITION => new InstanceIdPlaceholder ("Vartininkas"),
                                                  ),
                                        $defaultValues, $createdInstances);

        $list[] = $this->createInsertTest ("Pranas Pranaitis 2014",
                                           array (Sports::COL_TEAMPLAYER_TEAM => new InstanceIdPlaceholder ("REO"),
                                                  Sports::COL_TEAMPLAYER_PLAYER => new InstanceIdPlaceholder ("Pranas Pranaitis"),
                                                  "c_".Sports::COL_TEAMPLAYER_STARTED => "2014-00-00",
                                                  "c_".Sports::COL_TEAMPLAYER_ENDED => "2014-00-00",
                                                  Sports::COL_TEAMPLAYER_POSITION => new InstanceIdPlaceholder ("Vartininkas"),
                                                  ),
                                        $defaultValues, $createdInstances);

        $list[] = $this->createInsertTest ("Jonas Jonaitis2010",
                                           array (Sports::COL_TEAMPLAYER_TEAM => new InstanceIdPlaceholder ("VMFD"),
                                                  Sports::COL_TEAMPLAYER_PLAYER => new InstanceIdPlaceholder ("Jonas Jonaitis"),
                                                  "c_".Sports::COL_TEAMPLAYER_STARTED => "2010-00-00",
                                                  "c_".Sports::COL_TEAMPLAYER_ENDED => "2012-00-00",
                                                  Sports::COL_TEAMPLAYER_POSITION => new InstanceIdPlaceholder ("Saugas"),
                                                  ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Jonas Jonaitis 2009",
                                           array (Sports::COL_TEAMPLAYER_TEAM => new InstanceIdPlaceholder ("REO"),
                                                  Sports::COL_TEAMPLAYER_PLAYER => new InstanceIdPlaceholder ("Jonas Jonaitis"),
                                                  "c_".Sports::COL_TEAMPLAYER_STARTED => "2009-12-00",
                                                  "c_".Sports::COL_TEAMPLAYER_ENDED => "2011-00-00",
                                                  Sports::COL_TEAMPLAYER_POSITION => new InstanceIdPlaceholder ("Saugas"),
                                                  ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Jonas Jonaitis 2013",
                                           array (Sports::COL_TEAMPLAYER_TEAM => new InstanceIdPlaceholder ("Ekranas"),
                                                  Sports::COL_TEAMPLAYER_PLAYER => new InstanceIdPlaceholder ("Jonas Jonaitis"),
                                                  "c_".Sports::COL_TEAMPLAYER_STARTED => "2013-03-10",
                                                  "c_".Sports::COL_TEAMPLAYER_ENDED => NULL,
                                                  Sports::COL_TEAMPLAYER_POSITION => new InstanceIdPlaceholder ("Saugas"),
                                                  ),
                                        $defaultValues, $createdInstances);

        $list[] = $this->createInsertTest ("Stasys Stasaitis 2011",
                                           array (Sports::COL_TEAMPLAYER_TEAM => new InstanceIdPlaceholder ("REO"),
                                                  Sports::COL_TEAMPLAYER_PLAYER => new InstanceIdPlaceholder ("Stasys Stasaitis"),
                                                  "c_".Sports::COL_TEAMPLAYER_STARTED => "2013-06-00",
                                                  "c_".Sports::COL_TEAMPLAYER_ENDED => "2013-00-00",
                                                  Sports::COL_TEAMPLAYER_POSITION => new InstanceIdPlaceholder ("Saugas"),
                                                  ),
                                        $defaultValues, $createdInstances);
        $list[] = $this->createInsertTest ("Stasys Stasaitis 2013",
                                           array (Sports::COL_TEAMPLAYER_TEAM => new InstanceIdPlaceholder ("Ekranas"),
                                                  Sports::COL_TEAMPLAYER_PLAYER => new InstanceIdPlaceholder ("Stasys Stasaitis"),
                                                  "c_".Sports::COL_TEAMPLAYER_STARTED => "2012-12-00",
                                                  "c_".Sports::COL_TEAMPLAYER_ENDED => "2013-06-00",
                                                  Sports::COL_TEAMPLAYER_POSITION => new InstanceIdPlaceholder ("Saugas"),
                                                  ),
                                        $defaultValues, $createdInstances);

        return $list;
        }
    }

<?php
require_once (PATH.'inc/dbtabletestcollection.php');
require_once (PATH.'inc/quicklinkstable.php');

class QuickLinkTests extends DbTableTestCollection
    {
    public function __construct ($prefix, $context, $parent)
        {
        parent::__construct ($prefix, $context, $parent);
        $this->dbtable = new QuickLinksTable ($context);
        }

    public function enumerateTests ($context)
        {
        $tests = array ();

        if (!$this->dbtable->canDelete () && !$this->dbtable->ownerCanDelete ())
            {
            $this->context->addError ("Cannot run all the tests. Consider granting the delete access for the current user");
            return array ();
            }

        $defaultValues = array (QuickLinksTable::COL_TYPE => NULL,
                                QuickLinksTable::COL_LABEL => NULL,
                                DBTable::COL_ORDER => 1, QuickLinksTable::COL_TOOLTIP => NULL,
                                QuickLinksTable::COL_INDENT => 1, QuickLinksTable::COL_HIDDEN => false,
                                QuickLinksTable::COL_PARAM_INT => NULL,
                                QuickLinksTable::COL_PARAM_STR => NULL,
                                QuickLinksTable::COL_PERSPECTIVE => $context->getPerspective (),
                                );

        $createdInstances = array ();

        $defaultValues[DBTable::COL_ORDER] = count ($createdInstances) + 1;
        $tests[] = $this->createInsertTest ("page - home",
                                            array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_PAGE,
                                                   QuickLinksTable::COL_LABEL => "page link",
                                                   QuickLinksTable::COL_PARAM_STR => "home",
                                                   ),
                                            $defaultValues, $createdInstances);

        $defaultValues[DBTable::COL_ORDER] = count ($createdInstances) + 1;
        $tests[] = $this->createInsertTest ("image",
                                            array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_IMAGE,
                                                   QuickLinksTable::COL_INDENT => 0,
                                                   QuickLinksTable::COL_LABEL => NULL,
                                                   QuickLinksTable::COL_PARAM_STR => "http://www.futbolinis.lt/img/Fo.png",
                                                   ),
                                            $defaultValues, $createdInstances);

        $tests[] = $this->createSelectAllTest ($createdInstances, array_keys ($defaultValues));
        $tests[] = $this->createSelectLinksTest (array (
                               array ('indent' => 0, 'id' => NULL, 'order' => NULL,
                                      'items' => array (
                                                    array ('indent' => 1, 'label' => 'page link',
                                                           'tooltip' => NULL, 'url' => 'page/home/lt',
                                                           'id' => Test::ID_PLACEHOLDER, 'order' => '1'
                                                           ),
                                                       ),
                                      ),
                               array ('indent' => 0, 'label' => NULL, 'tooltip' => NULL,
                                      'img' => 'http://www.futbolinis.lt/img/Fo.png',
                                      'size' => NULL,
                                      'id' => Test::ID_PLACEHOLDER, 'order' => '2'),
                              ));

        $tests[] = $this->createDeleteAllTest ($createdInstances);
        $tests[] = $this->createSelectAllTest ($createdInstances, array_keys ($defaultValues));

        $defaultValues[DBTable::COL_ORDER] = count ($createdInstances) + 1 /* will be moved */ + 1;
        $tests[] = $this->createInsertTest ("page - home",
                                            array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_PAGE,
                                                   QuickLinksTable::COL_LABEL => "page link moved down",
                                                   QuickLinksTable::COL_PARAM_STR => "home1",
                                                   ),
                                            $defaultValues, $createdInstances);

        $defaultValues[DBTable::COL_ORDER] = count ($createdInstances) + 1 /* will be moved */ - 1;
        $tests[] = $this->createInsertTest ("page - home",
                                            array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_PAGE,
                                                   QuickLinksTable::COL_LABEL => "page link moved up",
                                                   QuickLinksTable::COL_PARAM_STR => "home2",
                                                   ),
                                            $defaultValues, $createdInstances);

        $tests[] = $this->createMoveUpTest (count ($createdInstances) - 1, true);
        $tests[] = $this->createMoveUpTest (count ($createdInstances) - 1, false);
        $tests[] = $this->createSelectAllTest (array_reverse ($createdInstances), array_keys ($defaultValues));
        // cleanup
        $tests[] = $this->createDeleteAllTest ($createdInstances);

        // create several items, delete the one in the middle and try reordering
        $defaultValues[DBTable::COL_ORDER] = count ($createdInstances) + 1 /* will be moved */ + 1;
        $tests[] = $this->createInsertTest ("page - home",
                                            array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_PAGE,
                                                   QuickLinksTable::COL_LABEL => "page home link moved down",
                                                   QuickLinksTable::COL_PARAM_STR => "home3",
                                                   ),
                                            $defaultValues, $createdInstances);

        $deletedInstance = array ();
        $defaultValues[DBTable::COL_ORDER] = count ($createdInstances) + 1;
        $tests[] = $this->createInsertTest ("img - deleted",
                                            array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_IMAGE,
                                                   QuickLinksTable::COL_LABEL => "image (deleted)",
                                                   QuickLinksTable::COL_PARAM_STR => "http://www.futbolinis.lt/img/Fo.png",
                                                   ),
                                            $defaultValues, $deletedInstance);

        $defaultValues[DBTable::COL_ORDER] = count ($createdInstances) + 1 /* will be moved */ - 1;
        $tests[] = $this->createInsertTest ("page - home",
                                            array (QuickLinksTable::COL_TYPE => QuickLinksTable::TYPE_PAGE,
                                                   QuickLinksTable::COL_LABEL => "page home link moved up",
                                                   QuickLinksTable::COL_PARAM_STR => "home4",
                                                   ),
                                            $defaultValues, $createdInstances);
        $tests[] = $this->createDeleteItemTest (1, true);
        $tests[] = $this->createMoveDownTest (0, true);
        $tests[] = $this->createDeleteItemTest (1, false);
        
        $tests[] = $this->createSelectAllTest (array_reverse ($createdInstances), array_keys ($defaultValues));

        return $tests;
        }

    public function selectLinks ($context, $input)
        {
        if (!$this->isTableValid ($this->dbtable))
            return false;

        $rows = QuickLinksTable::getAllLinks ($context);
        if (empty ($rows))
            return $rows;

        return $rows;
        }

    protected function createSelectLinksTest ($expectedRecords)
        {
        return parent::createTest ("selectLinks", NULL, array ($this, "selectLinks"), $expectedRecords);
        }

    protected function createMoveUpTest ($index, $expectedResult)
        {
        return parent::createTest ("moveRecordUp - expected to ".($expectedResult ? "succeed" : "fail"), $index, array ($this, "moveRecordUp"), $expectedResult);
        }

    protected function createMoveDownTest ($index, $expectedResult)
        {
        return parent::createTest ("moveRecordDown - expected to ".($expectedResult ? "succeed" : "fail"), $index, array ($this, "moveRecordDown"), $expectedResult);
        }

    public function moveRecordUp ($context, $index)
        {
        if (!$this->isTableValid ($this->dbtable) || !array_key_exists ($index, $this->createdRecords))
            return false;

        return $this->dbtable->moveRecordUp ($this->createdRecords[$index]);
        }

    public function moveRecordDown ($context, $index)
        {
        if (!$this->isTableValid ($this->dbtable) || !array_key_exists ($index, $this->createdRecords))
            return false;

        return $this->dbtable->moveRecordDown ($this->createdRecords[$index]);
        }
    }

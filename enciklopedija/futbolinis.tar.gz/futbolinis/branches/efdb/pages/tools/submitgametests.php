<?php
require_once (PATH.'inc/testcollection.php');
require_once (PATH.'pages/sports/submitgame.php');

class SubmitGameTests extends TestCollection
    {
    public function enumerateTests ($context)
        {
        $processor = new SubmitGameWrapper ($context, NULL);
        $tests = array (
            "1' V.Pavardeni" => array ('min' => '1', 'name' => 'V.Pavardeni'),
            "69 (og) V.Pavardenis" => array ('min' => '69', 'name' => 'V.Pavardenis', 'og' => true),
            "69 min. (og) V.Pavardenis" => array ('min' => '69', 'name' => 'V.Pavardenis', 'og' => true),
            "69 V.Pavardenis (pk)" => array ('min' => '69', 'name' => 'V.Pavardenis', 'pk' => true),
            "V.Pavardenis (og)" => array ('name' => 'V.Pavardenis', 'og' => true),
            "70 min. V.Pavardenis (og)" => array ('min' => '70', 'name' => 'V.Pavardenis', 'og' => true),
            "70 min. V.Pavardenis (11 m.)" => array ('min' => '70', 'name' => 'V.Pavardenis', 'pk' => true),
            );

        $list = array ();
        foreach ($tests as $line => $expectedOutput)
            {
            $list[] = $this->createTest ("\"$line\"", $line, array ($processor, "testParsePlayer"), $expectedOutput);
            }

        $tests = array (
            "69 V.Pavardenis" => "69  min.  V.Pavardenis (Lie)",
            "69' V.Pavardenis" => "69  min.  V.Pavardenis",
            "69` V.Pavardenis" => "69 V.Pavardenis",
            );
        foreach ($tests as $line1 => $line2)
            {
            $expectedOutput = $processor->testParsePlayer ($context, $line2);
            $list[] = $this->createTest ("\"$line1\" => \"$line2\"", $line1, array ($processor, "testParsePlayer"), $expectedOutput);
            }

        foreach ($this->getSimplifiedParserTestCases () as $line => $expectedOutput)
            {
            $parts = preg_split ("/[\n\r]{2}/", $line);
            $label = NULL;
            $i = 1;
            while (empty ($label) && count ($parts) > $i)
                $label = $parts[$i++];

            if (empty ($expectedOutput["sourceDetails"]))
                $expectedOutput["sourceDetails"] = $line;
            $expectedOutput["sourceDetails"] = trim (preg_replace ("/[\n\r]+/", "\n", $expectedOutput["sourceDetails"]));
            $list[] = $this->createTest ("\"{$label}\"", $line, array ($processor, "testSimpleMatch"), $expectedOutput);
            }

        foreach ($this->getExtendedParserTestCases () as $line => $expectedOutput)
            {
            $parts = preg_split ("/[\n\r]{2}/", $line);
            $label = NULL;
            $i = 1;
            while (empty ($label) && count ($parts) > $i)
                $label = $parts[$i++];
            if (empty ($expectedOutput["sourceDetails"]))
                $expectedOutput["sourceDetails"] = $line;
            $expectedOutput["sourceDetails"] = trim (preg_replace ("/[\n\r]+/", "\n", $expectedOutput["sourceDetails"]));
            $list[] = $this->createTest ("\"{$label}\"", $line, array ($processor, "testExtendedMatch"), $expectedOutput);
            }

        foreach ($this->getNationalParserTestCases () as $line => $expectedOutput)
            {
            $parts = preg_split ("/[\n\r]{2}/", $line);
            $list[] = $this->createTest ("\"{$parts[1]} ({$parts[0]})\"", $line, array ($processor, "testNationalMatch"), $expectedOutput);
            }

        return $list;
        }

    public function getSimplifiedParserTestCases ()
        {
        $tests = array (
"08.05
Lietuvos Makabi Vilnius - Mastis Telsiai 6:1. g. K.Klisauskas-3, V.Urbonas, G.Kalvaitis; K.Kvedaras (pk)."
                        =>
                            array ('date' => '1992-08-05',
                                   'homeTeam' => 'Lietuvos Makabi Vilnius',   'awayTeam' => 'Mastis Telsiai',
                                   'result' => array ('6', '1'),
                                   'goal' => array (
                                                array ('name' => 'K.Klisauskas', 'home' => true),
                                                array ('name' => 'K.Klisauskas', 'home' => true),
                                                array ('name' => 'K.Klisauskas', 'home' => true),
                                                array ('name' => 'V.Urbonas', 'home' => true),
                                                array ('name' => 'G.Kalvaitis', 'home' => true),
                                                array ('name' => 'K.Kvedaras', 'home' => false, 'pk' => true),
                                                ),
                                   ),

"08.05
Zalgiris Vilnius - FBK Kaunas 1:0 (0:0). g. K.Klisauskas (Zal)."
                        =>
                            array ('date' => '1992-08-05',
                                   'homeTeam' => 'Zalgiris Vilnius',   'awayTeam' => 'FBK Kaunas',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array (0, 0),
                                   'goal' => array (
                                                array ('name' => 'K.Klisauskas', 'home' => true),
                                                ),
                                   ),

"08.05
Zalgiris Vilnius - FBK Kaunas 0:0."
                        =>
                            array ('date' => '1992-08-05',
                                   'homeTeam' => 'Zalgiris Vilnius',   'awayTeam' => 'FBK Kaunas',
                                   'result' => array ('0', '0'),
                                   ),

"7-Sep
13.00   Atletas          - Lietava             1 - 0"
                        =>
                            array ('date' => '1992-09-07 13:00',
                                   'homeTeam' => 'Atletas',   'awayTeam' => 'Lietava',
                                   'result' => array ('1', '0'),
                                   ),

"09.02
Jovaras Mazeikiai - Panerys Vilnius 1:1 Aggregate 2:2. g. S.Vertelis; P.Malzinskas."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Jovaras Mazeikiai',   'awayTeam' => 'Panerys Vilnius',
                                   'result' => array ('1', '1'),
                                   'goal' => array (
                                                array ('name' => 'S.Vertelis', 'home' => true),
                                                array ('name' => 'P.Malzinskas', 'home' => false),
                                                ),
                                   ),

"09.02
Jovaras Mazeikiai - Panerys Vilnius 1:1 (1:1). Vilnius. Panerys. 100. G.Zakas (Kaunas). Aggregate - 2:2. g. S.Vertelis; P.Malzinskas."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Jovaras Mazeikiai',   'awayTeam' => 'Panerys Vilnius',
                                   'result' => array ('1', '1'), 'resultHalfTime' => array ('1', '1'),
                                   'stadium' => "Vilnius. Panerys",
                                   'spectators' => "100",
                                   'referee' => "G.Zakas",
                                   'refereeCity' => "Kaunas",
                                   'goal' => array (
                                                array ('name' => 'S.Vertelis', 'home' => true),
                                                array ('name' => 'P.Malzinskas', 'home' => false),
                                                ),
                                   ),

"09.02
Banga Gargzdai - Zerutis Radviliskis 1:0 (1:0). Gargzdai. 300. A.Fokinas (Klaipeda).  Aggregate - 3:0. g. 32 G.Kniuksta. Booket: G.Samsonikas (Banga), E.Folertas, S.Lesnickas (Zerutis)."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Banga Gargzdai',   'awayTeam' => 'Zerutis Radviliskis',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array ('1', '0'),
                                   'stadium' => "Gargzdai",
                                   'spectators' => "300",
                                   'referee' => "A.Fokinas",
                                   'refereeCity' => "Klaipeda",
                                   'goal' => array (
                                                array ('min' => 32, 'name' => 'G.Kniuksta', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('name' => 'G.Samsonikas', 'home' => true),
                                                array ('name' => 'E.Folertas', 'home' => false),
                                                array ('name' => 'S.Lesnickas', 'home' => false),
                                                ),
                                   ),

"09.02
Banga Gargzdai - Zerutis Radviliskis 1:0 (1:0). Gargzdai. 300. A.Fokinas (Klaipeda).  Aggregate - 3:0. g. 32 G.Kniuksta. b: G.Samsonikas (Banga), E.Folertas, S.Lesnickas (Zerutis)."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Banga Gargzdai',   'awayTeam' => 'Zerutis Radviliskis',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array ('1', '0'),
                                   'stadium' => "Gargzdai",
                                   'spectators' => "300",
                                   'referee' => "A.Fokinas",
                                   'refereeCity' => "Klaipeda",
                                   'goal' => array (
                                                array ('min' => 32, 'name' => 'G.Kniuksta', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('name' => 'G.Samsonikas', 'home' => true),
                                                array ('name' => 'E.Folertas', 'home' => false),
                                                array ('name' => 'S.Lesnickas', 'home' => false),
                                                ),
                                   ),

"09.02
Vilniaus \"Bekentas\" - Kazlų Rūdos \"SC-STIHL\" 5:2 (4:2)
Teisėjai - R.Cviklinskis (Vilnius), Vit. Kazlauskas (Kaunas)
Įvarčiai: 1 min. J.Mežonis (1:0), 7 min. R.Bakus (2:0, į savo vartus), 12 min. A.Sokolovas (3:0), 14 min. A.Sokolovas (4:0), 15 min. E.Rūškys (4:1), 18 min. N.Mačiulis (4:2), 39 min. V.Novičkovas (5:2).
Įspėtas: 19 min. D.Liutkus (\"SC-STIHL\")."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Vilniaus Bekentas',   'awayTeam' => 'Kazlų Rūdos SC-STIHL',
                                   'result' => array ('5', '2'), 'resultHalfTime' => array ('4', '2'),
                                   'referee' => "R.Cviklinskis",
                                   'refereeCity' => "Vilnius",
                                   'refereeA1' => "Vit. Kazlauskas",
                                   'refereeA1City' => "Kaunas",
                                   'goal' => array (
                                                array ('min' => 1, 'name' => 'J.Mežonis', 'home' => true),
                                                array ('min' => 7, 'name' => 'R.Bakus', 'home' => true, 'og' => true),
                                                array ('min' => 12, 'name' => 'A.Sokolovas', 'home' => true),
                                                array ('min' => 14, 'name' => 'A.Sokolovas', 'home' => true),
                                                array ('min' => 15, 'name' => 'E.Rūškys', 'home' => false),
                                                array ('min' => 18, 'name' => 'N.Mačiulis', 'home' => false),
                                                array ('min' => 39, 'name' => 'V.Novičkovas', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('min' => 19, 'name' => 'D.Liutkus', 'home' => false),
                                                ),
                                   ),

"09.02
Kauno \"Viči\" - Kauno \"Nautara\" 1:4 (1:1) 
Teisėjai - A.Makarevičius, A.Kontvainas (Kaunas)
Įvarčiai: 14 min. D.Kudrešovas (1:0), 18 min. A.Šteinas (1:1, iš 6 m.), 25 min. T.Nemanis (1:2), 31 min. A.Šteinas (1:3), 33 min. T.Nemanis (1:4)."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Kauno Viči',   'awayTeam' => 'Kauno Nautara',
                                   'result' => array ('1', '4'), 'resultHalfTime' => array ('1', '1'),
                                   'referee' => "A.Makarevičius",
                                   'refereeCity' => "Kaunas",
                                   'refereeA1' => "A.Kontvainas",
                                   'refereeA1City' => "Kaunas",
                                   'goal' => array (
                                                array ('min' => 14, 'name' => 'D.Kudrešovas', 'home' => true),
                                                array ('min' => 18, 'name' => 'A.Šteinas', 'home' => false, 'pk' => true),
                                                array ('min' => 25, 'name' => 'T.Nemanis', 'home' => false),
                                                array ('min' => 31, 'name' => 'A.Šteinas', 'home' => false),
                                                array ('min' => 33, 'name' => 'T.Nemanis', 'home' => false),
                                                ),
                                   ),

"09.02
Ekranas Panevezys - Nevezis-Lifosa Kedainiai 3:0 (2:0).
Rf. A.Rezepovas (Vilnius). Panevezys Aukstaitija st. Att. 1500."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Ekranas Panevezys',   'awayTeam' => 'Nevezis-Lifosa Kedainiai',
                                   'result' => array (3, '0'), 'resultHalfTime' => array (2, '0'),
                                   'stadium' => "Panevezys Aukstaitija st",
                                   'spectators' => "1500",
                                   'referee' => "A.Rezepovas",
                                   'refereeCity' => "Vilnius",
                                   ),

"09.02
Jovaras Mazeikiai - Panerys Vilnius 1:1 (0:1). (I - 0:8). g. S.Vertelis; P.Malzinskas."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Jovaras Mazeikiai',   'awayTeam' => 'Panerys Vilnius',
                                   'result' => array ('1', '1'), 'resultHalfTime' => array (0, 1),
                                   'goal' => array (
                                                array ('name' => 'S.Vertelis', 'home' => true),
                                                array ('name' => 'P.Malzinskas', 'home' => false),
                                                ),
                                   ),

"09.02
Jovaras Mazeikiai - Panerys Vilnius 1:1 (0:1).
g. S.Vertelis; P.Malzinskas."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Jovaras Mazeikiai',   'awayTeam' => 'Panerys Vilnius',
                                   'result' => array ('1', '1'), 'resultHalfTime' => array (0, 1),
                                   'goal' => array (
                                                array ('name' => 'S.Vertelis', 'home' => true),
                                                array ('name' => 'P.Malzinskas', 'home' => false),
                                                ),
                                   ),

"09.02
Lietuvos Makabi Vilnius - Mastis Telsiai 2:2. Aggregate 7:1. g. 69, 78 K.Klisauskas; 12, 15 (pk) K.Kvedaras."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Lietuvos Makabi Vilnius',   'awayTeam' => 'Mastis Telsiai',
                                   'result' => array ('2', '2'),
                                   'goal' => array (
                                                array ('min' => 69, 'name' => 'K.Klisauskas', 'home' => true, ),
                                                array ('min' => 78, 'name' => 'K.Klisauskas', 'home' => true),
                                                array ('min' => 12, 'name' => 'K.Kvedaras', 'home' => false),
                                                array ('min' => 15, 'name' => 'K.Kvedaras', 'home' => false, 'pk' => true),
                                                ),
                                   ),

"09.02
Jovaras Mazeikiai - Panerys Vilnius 1:1 Aggregate 2:2. (3-0 pk). g. S.Vertelis; P.Malzinskas."
                        =>
                            array ('date' => '1992-09-02',
                                   'homeTeam' => 'Jovaras Mazeikiai',   'awayTeam' => 'Panerys Vilnius',
                                   'result' => array ('1', '1'), 'resultPenalty' => array ('3', '0'),
                                   'c_outcome' => MatchConstants::OUTCOME_PENALTIES_HOME,
                                   'goal' => array (
                                                array ('name' => 'S.Vertelis', 'home' => true),
                                                array ('name' => 'P.Malzinskas', 'home' => false),
                                                ),
                                   ),

"03.21
Jovaras Mazeikiai - Makabi Vilnius 0:2. g. 8 K.Klisauskas, 55 V.Urbonas. Rf. R.Cekauskas (Kaunas)."
                        =>
                            array ('date' => '1992-03-21',
                                   'homeTeam' => 'Jovaras Mazeikiai',   'awayTeam' => 'Makabi Vilnius',
                                   'result' => array ('0', '2'),
                                   'referee' => 'R.Cekauskas',
                                   'refereeCity' => 'Kaunas',
                                   'goal' => array (
                                                array ('min' => 8, 'name' => 'K.Klisauskas', 'home' => false),
                                                array ('min' => 55, 'name' => 'V.Urbonas', 'home' => false),
                                                ),
                                   ),

"03.21
Ekranas Panevezys - Granitas Klaipeda 0:0. Sent off 82 O.Mozuraitis (Ekranas). Rf. J.Miliauskas (Alytus)."
                        =>
                            array ('date' => '1992-03-21',
                                   'homeTeam' => 'Ekranas Panevezys',   'awayTeam' => 'Granitas Klaipeda',
                                   'result' => array ('0', '0'),
                                   'referee' => 'J.Miliauskas',
                                   'refereeCity' => 'Alytus',
                                   'goal' => array (),
                                   'sent' => array (
                                                array ('min' => 82, 'name' => 'O.Mozuraitis', 'home' => true),
                                                ),
                                   ),
"05 10
9. „Baltai“ (Kaišiadorys) 3:3 (1:2)  „Rūdupis“ (Prienai) 
Teisėjas T. Čeliauskas (Kaunas), 120 žiūrovų
Įvarčiai: 10,71,90  min. A. Grubliauskas („Baltai“);
67 min. į savo vartus S. Jankauskas („Baltai“)
7 min. M. Eiza, 14 min. S. Čepkauskas („Rūdupis“)
Įspėjimai: 26 min. A. Markevičius, 61 min. K. Deltuva („Rūdupis“)
Pašalinimai: 13 min. A. Jankauskas („Baltai“)"
                        =>
                            $this->jsonEncodedToArray ('{
                                "date":"1992-05-10","number":"9",
                                "homeTeam":"Baltai (Kai\u0161iadorys)",
                                "awayTeam":"R\u016bdupis (Prienai)",
                                "result":["3","3"],
                                "resultHalfTime":["1","2"],
                                "spectators":"120",
                                "referee":"T. \u010celiauskas","refereeCity":"Kaunas",
                                "goal":[{"min":"10","name":"A. Grubliauskas","home":true},
                                        {"min":"71","name":"A. Grubliauskas","home":true},
                                        {"min":"90","name":"A. Grubliauskas","home":true},
                                        {"min":"67","name":"S. Jankauskas","og":true,"home":false},
                                        {"min":"7","name":"M. Eiza","home":false},
                                        {"min":"14","name":"S. \u010cepkauskas","home":false}],
                                "book":[{"min":"26","name":"A. Markevi\u010dius","home":false},
                                        {"min":"61","name":"K. Deltuva","home":false}],
                                "sent":[{"min":"13","name":"A. Jankauskas","home":true}]}'),

"2011 08 28
143. Kaunas (Kaunas) - Sūduva (Marijampolė) 2:1 (1:1)
Teisėjas: A.Kancleris (Klaipėda), 800 žiūrovų
Įvarčiai: 29 min. (iš 11m.) ir 68 min. (iš 11m.) C.Thomson („Kaunas\"); 31 min. P.Leimonas („Sūduva\")
Įspėjimai: 30 min. M.Miškinis, 53 min. S.Paulius, 87 min. D.Bartkus („Kaunas\"); 17 min. Gu Bin,  25 min. K.Chvedukas, 28 min. S.Loginov, 39 min. V.Slavickas, 67 min. N.Radžius, 90+4 min. P.Leimonas („Sūduva\").
"
                        =>
                            $this->jsonEncodedToArray ('{
                                "date":"2011-08-28","number":"143",
                                "homeTeam":"Kaunas (Kaunas)",
                                "awayTeam":"S\u016bduva (Marijampol\u0117)",
                                "result":["2","1"],
                                "resultHalfTime":["1","1"],
                                "spectators":"800",
                                "referee":"A.Kancleris","refereeCity":"Klaip\u0117da",
                                "goal":[{"min":"29","name":"C.Thomson","home":true,"pk":true},
                                        {"min":"68","name":"C.Thomson","home":true,"pk":true},
                                        {"min":"31","name":"P.Leimonas","home":false}],
                                "book":[{"min":"30","name":"M.Mi\u0161kinis","home":true},
                                        {"min":"53","name":"S.Paulius","home":true},
                                        {"min":"87","name":"D.Bartkus","home":true},
                                        {"min":"17","name":"Gu Bin","home":false},
                                        {"min":"25","name":"K.Chvedukas","home":false},
                                        {"min":"28","name":"S.Loginov","home":false},
                                        {"min":"39","name":"V.Slavickas","home":false},
                                        {"min":"67","name":"N.Radžius","home":false},
                                        {"min":"90","name":"P.Leimonas","home":false,"extra":4}]
                                }'),

"05 07
PJK Akmenys - FK Rinkuškiai 2-1 (0-0). Teisėjas: Tomas Gutauskas. Teisėjo asistentai: Romas Šteinas ir Marius Ligeika. Žiūrovų: 60. Įvarčiai: 56 min. Svajūnas Rauckis (Akmenys), 63 min. Lauras Januševičius (Akmenys); 90+2 Gailius Lansbergis (Rinkuškiai). 83 min Rokas Statulevičius (Rinkuškiai) nerealizavo 11 m. baudinio. Įspėjimai: Andrius Grinkus (Akmenys), Irmantas Jaškūnas (Akmenys)."
                        =>
                            $this->jsonEncodedToArray ('{
                                "date":"1992-05-07",
                                "homeTeam":"PJK Akmenys 2011",
                                "awayTeam":"FK Rinku\u0161kiai 2011",
                                "result":["2","1"],"resultHalfTime":["0","0"],
                                "referee":"Tomas Gutauskas","refereeA1":"Romas \u0160teinas","refereeA2":"Marius Ligeika",
                                "spectators":"60",
                                "goal":[{"min":"56","name":"Svaj\u016bnas Rauckis","home":true},{"min":"63","name":"Lauras Janu\u0161evi\u010dius","home":true},{"min":"90","name":"Gailius Lansbergis","extra":"2","home":false}],
                                "miss":[{"min":"83","name":"Rokas Statulevi\u010dius","home":false}],
                                "book":[{"name":"Andrius Grinkus","home":true},{"name":"Irmantas Ja\u0161k\u016bnas","home":true}]} '),

"Birželio 17 d. (penktadienis)

35. FK „Kaslita“ (Kelmė) – „Mastis“ (Telšiai)

0 – 5   (0-2)

Žiūrovų  – 50

Teisėjas – V. Bernatonis (Panevėžys), asistentai – J. Misevičius (Panevėžys), A.Strolė (Panevėžys).

Įvarčiai: 29 ir 85 min. N. Kumža („Mastis“), 36, 70 ir 73 min. V. Paulauskas („Mastis“).

Įspėjimai: 28 min. G. Macevičius („Mastis“), 77 min. N. Kumža („Mastis“)."
                        =>
                            array (
                                'date' => '1992-06-17',
                                'number' => '35',
                                'homeTeam' => 'FK Kaslita (Kelmė)',
                                'awayTeam' => 'Mastis (Telšiai),',
                                'result' => array ('0', '5'), 'resultHalfTime' => array ('0', '2'),
                                'spectators' => '50',
                                'referee' => 'V. Bernatonis', 'refereeCity' => 'Panevėžys',
                                'refereeA1' => 'J. Misevičius', 'refereeA1City' => 'Panevėžys',
                                'refereeA2' => 'A.Strolė', 'refereeA2City' => 'Panevėžys',
                                'goal' => array (
                                        0 => array ('min' => '29', 'name' => 'N. Kumža', 'home' => false),
                                        1 => array ('min' => '85','name' => 'N. Kumža','home' => false,),
                                        2 => array ('min' => '36','name' => 'V. Paulauskas','home' => false,),
                                        3 => array ('min' => '70', 'name' => 'V. Paulauskas', 'home' => false),
                                        4 => array ('min' => '73', 'name' => 'V. Paulauskas', 'home' => false),
                                        ),
                                'book' => array (
                                        0 => array ('min' => '28','name' => 'G.Macevičius','home' => false,),
                                        1 => array ('min' => '77','name' => 'N. Kumža','home' => false,),
                                        ),
                                ),

"09.15
VILIJA VILNIUS - VILNIUS 15:0 (8:0). Vilnius. VPU. R.Juska (Vilnius). g. A.Dedelaite-6, N.Kazlauskaite-4."
                        =>
                            array ('date' => '1992-09-15',
                                   'homeTeam' => 'VILIJA VILNIUS',   'awayTeam' => 'VILNIUS',
                                   'result' => array ('15', '0'), 'resultHalfTime' => array (8, 0),
                                   'referee' => 'R.Juska',
                                   'refereeCity' => 'Vilnius',
                                   'stadium' => 'Vilnius. VPU',
                                   'goal' => array (
                                                array ('name' => 'A.Dedelaite', 'home' => true),
                                                array ('name' => 'A.Dedelaite', 'home' => true),
                                                array ('name' => 'A.Dedelaite', 'home' => true),
                                                array ('name' => 'A.Dedelaite', 'home' => true),
                                                array ('name' => 'A.Dedelaite', 'home' => true),
                                                array ('name' => 'A.Dedelaite', 'home' => true),
                                                array ('name' => 'N.Kazlauskaite', 'home' => true),
                                                array ('name' => 'N.Kazlauskaite', 'home' => true),
                                                array ('name' => 'N.Kazlauskaite', 'home' => true),
                                                array ('name' => 'N.Kazlauskaite', 'home' => true),
                                                ),
                                   ),

"Liepos mėn. 3 d.
VILIJA VILNIUS - VILNIUS 5:0 (2:0). Vilnius. VPU. R.Juska (Vilnius). g. A. Balandis, N.Liepa-4."
                        =>
                            array ('date' => '1992-07-03',
                                   'homeTeam' => 'VILIJA VILNIUS',   'awayTeam' => 'VILNIUS',
                                   'result' => array ('5', '0'), 'resultHalfTime' => array (2, 0),
                                   'referee' => 'R.Juska',
                                   'refereeCity' => 'Vilnius',
                                   'stadium' => 'Vilnius. VPU',
                                   'goal' => array (
                                                array ('name' => 'A. Balandis', 'home' => true),
                                                array ('name' => 'N.Liepa', 'home' => true),
                                                array ('name' => 'N.Liepa', 'home' => true),
                                                array ('name' => 'N.Liepa', 'home' => true),
                                                array ('name' => 'N.Liepa', 'home' => true),
                                                ),
                                   ),

"2008.11.16 12:00 val.-Vievis
\"Vievio žiedas\" - Šalčininkėliai\"Šalčia\"
                   9:5 (4:2)
Teisėjai: V.Chileckis,Vyt.Kazlauskas(Kaunas)
Įvarčiai:V.Apanavičius(3),D.Jankauskas(2),M.Postnovas(2),N.Dambrauskas,V.Ratiukas(\"Vievio Žiedas\");
R.Milos(2),A.Kislovskij,V.Dubrovskij,V.Frizel(\"Šalčia\")."
                        =>
                            array ('date' => '2008-11-16 12:00:00',
                                   'homeTeam' => 'Vievio žiedas',   'awayTeam' => 'ŠalčininkėliaiŠalčia',
                                   'result' => array ('9', '5'), 'resultHalfTime' => array (4, 2),
                                   'referee' => 'V.Chileckis',
                                   'refereeA1' => 'Vyt.Kazlauskas',
                                   'refereeCity' => 'Kaunas',
                                   'refereeA1City' => 'Kaunas',
                                   'stadium' => 'Vievis',
                                   'goal' => array (
                                                array ('name' => 'V.Apanavičius', 'home' => true),
                                                array ('name' => 'V.Apanavičius', 'home' => true),
                                                array ('name' => 'V.Apanavičius', 'home' => true),
                                                array ('name' => 'D.Jankauskas', 'home' => true),
                                                array ('name' => 'D.Jankauskas', 'home' => true),
                                                array ('name' => 'M.Postnovas', 'home' => true),
                                                array ('name' => 'M.Postnovas', 'home' => true),
                                                array ('name' => 'N.Dambrauskas', 'home' => true),
                                                array ('name' => 'V.Ratiukas', 'home' => true),
                                                array ('name' => 'R.Milos', 'home' => false),
                                                array ('name' => 'R.Milos', 'home' => false),
                                                array ('name' => 'A.Kislovskij', 'home' => false),
                                                array ('name' => 'V.Dubrovskij', 'home' => false),
                                                array ('name' => 'V.Frizel', 'home' => false),
                                                ),
                                   ),

"09.21
16.00 GABIJA-POLITECHNIKA KAUNAS - ZEMAITIJA TELSIAI 0:0. Kaunas. KTU. 50. V.Meidus (K)."
                        =>
                            array ('date' => '1992-09-21 16:00',
                                   'homeTeam' => 'GABIJA-POLITECHNIKA KAUNAS',   'awayTeam' => 'ZEMAITIJA TELSIAI',
                                   'result' => array ('0', '0'),
                                   'spectators' => '50',
                                   'referee' => 'V.Meidus',
                                   'refereeCity' => 'K',
                                   'stadium' => 'Kaunas. KTU',
                                   ),

"09.21
Gariunai Vilnius - Fortuna Vilnius  3:2 aet."
                        =>
                            array ('date' => '1992-09-21',
                                   'homeTeam' => 'Gariunai Vilnius',   'awayTeam' => 'Fortuna Vilnius',
                                   'resultET' => array ('3', '2'),
                                   ),

"09.21
Ozas vilnius - Svyturys Marijampole  1:1 3-5 pk."
                        =>
                            array ('date' => '1992-09-21',
                                   'homeTeam' => 'Ozas vilnius',   'awayTeam' => 'Svyturys Marijampole',
                                   'result' => array ('1', '1'),
                                   'resultPenalty' => array ('3', '5'),
                                   'c_outcome' => MatchConstants::OUTCOME_PENALTIES_AWAY,
                                   ),

"09.21
18.30  Zalgiris Vilnius - FK Silute  2:2 (1:1) aet. pk 0-3. S.Slyva (Kaunas). Vilnius. Zalgiris. 410."
                        =>
                            array ('date' => '1992-09-21 18:30',
                                   'homeTeam' => 'Zalgiris Vilnius',   'awayTeam' => 'FK Silute',
                                   'result' => array ('2', '2'),
                                   'resultET' => array ('2', '2'),
                                   'resultHalfTime' => array ('1', '1'),
                                   'resultPenalty' => array ('0', '3'),
                                   'referee' => 'S.Slyva',
                                   'refereeCity' => 'Kaunas',
                                   'stadium' => 'Vilnius. Zalgiris',
                                   'spectators' => '410',
                                   'c_outcome' => MatchConstants::OUTCOME_PENALTIES_AWAY,
                                   ),

"09.21
18.30  Zalgiris Vilnius - FK Silute  4:2 aet (2:2, 1:1). S.Slyva (Kaunas). Vilnius. Zalgiris. 410."
                        =>
                            array ('date' => '1992-09-21 18:30',
                                   'homeTeam' => 'Zalgiris Vilnius',   'awayTeam' => 'FK Silute',
                                   'result' => array ('2', '2'),
                                   'resultET' => array ('4', '2'),
                                   'resultHalfTime' => array ('1', '1'),
                                   'referee' => 'S.Slyva',
                                   'refereeCity' => 'Kaunas',
                                   'stadium' => 'Vilnius. Zalgiris',
                                   'spectators' => '410',
                                   ),

"[Nov 13]
KFK Siauliai - Atlantas Klaipeda  3:2 (0:0, 1:1) aet. G.Mazeika (Kaunas). Vilnius. Sportima. 200. g. 49 V.Silenas, 98 (pk) V.Lapeikis, 104 V.Viktoravicius; 70 D.Ramonas, 109 J.Delic. Booket: 70 V.Lapeikis (Sia)."
                        =>
                            array ('date' => '1992-11-13',
                                   'homeTeam' => 'KFK Siauliai',   'awayTeam' => 'Atlantas Klaipeda',
                                   'result' => array ('1', '1'),
                                   'resultET' => array ('3', '2'),
                                   'resultHalfTime' => array ('0', '0'),
                                   'referee' => 'G.Mazeika',
                                   'refereeCity' => 'Kaunas',
                                   'stadium' => 'Vilnius. Sportima',
                                   'spectators' => '200',
                                   'goal' => array (
                                                array ('min' => 49, 'name' => 'V.Silenas', 'home' => true),
                                                array ('min' => 98, 'name' => 'V.Lapeikis', 'home' => true, 'pk' => true),
                                                array ('min' => 104, 'name' => 'V.Viktoravicius', 'home' => true),
                                                array ('min' => 70, 'name' => 'D.Ramonas', 'home' => false),
                                                array ('min' => 109, 'name' => 'J.Delic', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('min' => 70, 'name' => 'V.Lapeikis', 'home' => true),
                                                ),
                                   ),

"[Apr 21]
17.00  Vidzgiris         1-2  Savinge"
                        =>
                            array ('date' => '1992-04-21 17:00',
                                   'homeTeam' => 'Vidzgiris',   'awayTeam' => 'Savinge',
                                   'result' => array ('1', '2'),
                                   ),

"[Apr 21]
18.00  Nevezis-2         3-0  Sviesa           *w/o game"
                        =>
                            array ('date' => '1992-04-21 18:00',
                                   'homeTeam' => 'Nevezis-2',   'awayTeam' => 'Sviesa',
                                   'result' => array ('3', '0'),
                                   'c_outcome' => MatchConstants::OUTCOME_TECHNICAL_WIN,
                                   ),

"05.03

14.00 GABIJA-POLITECHNIKA KAUNAS - JOGINTA KELME 12:0 (7:0). Kaunas. KTU. 50. V.Meidus (K). g. I.Gorbunoviene-7, J.Valanciene-2, S.Motuzaite.

14.00 KRISTINA VILNIUS - ZEMAITIJA TELSIAI 2:0 (2:0). Vilnius. Zalgiris. 40. Vyg.Suziedelis (V). g. 30 E.Vascilko, 39 I.Podagelyte.
"
                        =>
                            array ('date' => '1992-05-03 14:00',
                                   'homeTeam' => 'GABIJA-POLITECHNIKA KAUNAS',   'awayTeam' => 'JOGINTA KELME',
                                   'result' => array ('12', '0'), 'resultHalfTime' => array (7, 0),
                                   'spectators' => '50',
                                   'referee' => 'V.Meidus',
                                   'refereeCity' => 'K',
                                   'stadium' => 'Kaunas. KTU',
                                   'goal' => array (
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'J.Valanciene', 'home' => true),
                                                array ('name' => 'J.Valanciene', 'home' => true),
                                                array ('name' => 'S.Motuzaite', 'home' => true),
                                                ),
                                   'sourceDetails' => "05.03
14.00 GABIJA-POLITECHNIKA KAUNAS - JOGINTA KELME 12:0 (7:0). Kaunas. KTU. 50. V.Meidus (K). g. I.Gorbunoviene-7, J.Valanciene-2, S.Motuzaite."
                                   ),

            );

        return $tests;
        }

    public function getExtendedParserTestCases ()
        {
        $tests = array (

"[Mar 29, Sat]
Lietuvos Makabi Vilnius - Mastis Telsiai 3:1. A.Paulauskas (Neringa). Kaunas. S.Darius ir S.Girenas SK. 660.
LM: K.Klisauskas, V.Urbonas (80′ G.Kalvaitis)
MAS: K.Kvedaras, F.Kvedaras
Goals: K.Klisauskas, V.Urbonas, G.Kalvaitis; K.Kvedaras (pk).
Missed pk K.Likas (Lie)"
                        =>
                            array ('date' => '1992-03-29',
                                   'homeTeam' => 'Lietuvos Makabi Vilnius',   'awayTeam' => 'Mastis Telsiai',
                                   'result' => array ('3', '1'),
                                   'referee' => 'A.Paulauskas',
                                   'refereeCity' => 'Neringa',
                                   'spectators' => '660',
                                   'stadium' => 'Kaunas. S.Darius ir S.Girenas SK',
                                   'goal' => array (
                                                array ('name' => 'K.Klisauskas', 'home' => true),
                                                array ('name' => 'V.Urbonas', 'home' => true),
                                                array ('name' => 'G.Kalvaitis', 'home' => true),
                                                array ('name' => 'K.Kvedaras', 'home' => false, 'pk' => true),
                                                ),
                                   'miss' => array (
                                                array ('name' => 'K.Likas', 'home' => true),
                                                ),
                                   'homePlayers' => array (
                                                array ('name' => 'K.Klisauskas', 'from' => 0, 'to' => 90),
                                                array ('name' => 'V.Urbonas', 'from' => 0, 'to' => 80,
                                                       'substitute' =>
                                                            array ('name' => 'G.Kalvaitis', 'from' => 80, 'to' => 90)),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'K.Kvedaras', 'from' => 0, 'to' => 90),
                                                array ('name' => 'F.Kvedaras', 'from' => 0, 'to' => 90),
                                                ),
                                   ),

"[Mar 29, Sat]
Klevas Siauliai - Zalgiris Vilnius 0:16 (0:8). D.Semberas (2, 39), A.Stesko (3, 28, 42), T.Ramelis (4, 31), A.Pukelevicius (25), D.Suliauskas (52, 54), A.Briaunys (55), I.Stesko (63), D.Saulenas (65, 66), I.Morinas (71), N.Vasiliauskas (84). 55 A.Briaunys (Zalgiris) missed p.k.. Rf. S.Slyva (Kaunas). Att. 50."
                        =>
                            array ('date' => '1992-03-29',
                                   'homeTeam' => 'Klevas Siauliai',   'awayTeam' => 'Zalgiris Vilnius',
                                   'result' => array (0, 16), 'resultHalfTime' => array (0, 8),
                                   'referee' => 'S.Slyva',
                                   'refereeCity' => 'Kaunas',
                                   'spectators' => '50',
                                   'goal' => array (
                                                array ('min' => 2, 'name' => 'D.Semberas', 'home' => false),
                                                array ('min' => 39, 'name' => 'D.Semberas', 'home' => false),
                                                array ('min' => 3, 'name' => 'A.Stesko', 'home' => false),
                                                array ('min' => 28, 'name' => 'A.Stesko', 'home' => false),
                                                array ('min' => 42, 'name' => 'A.Stesko', 'home' => false),
                                                array ('min' => 4, 'name' => 'T.Ramelis', 'home' => false),
                                                array ('min' => 31, 'name' => 'T.Ramelis', 'home' => false),
                                                array ('min' => 25, 'name' => 'A.Pukelevicius', 'home' => false),
                                                array ('min' => 52, 'name' => 'D.Suliauskas', 'home' => false),
                                                array ('min' => 54, 'name' => 'D.Suliauskas', 'home' => false),
                                                array ('min' => 55, 'name' => 'A.Briaunys', 'home' => false),
                                                array ('min' => 63, 'name' => 'I.Stesko', 'home' => false),
                                                array ('min' => 65, 'name' => 'D.Saulenas', 'home' => false),
                                                array ('min' => 66, 'name' => 'D.Saulenas', 'home' => false),
                                                array ('min' => 71, 'name' => 'I.Morinas', 'home' => false),
                                                array ('min' => 84, 'name' => 'N.Vasiliauskas', 'home' => false),
                                                ),
                                   'miss' => array (
                                                array ('min' => 55, 'name' => 'A.Briaunys', 'home' => false),
                                                ),
                                   ),

"[Mar 29, Sat]
Klevas Siauliai - Zalgiris Vilnius 0:1 (0:1). D.Semberas (2). 55 A.Briaunys (Zalgiris Vilnius) missed p.k.. Rf. S.Slyva (Kaunas). Att. 50."
                        =>
                            array ('date' => '1992-03-29',
                                   'homeTeam' => 'Klevas Siauliai',   'awayTeam' => 'Zalgiris Vilnius',
                                   'result' => array (0, 1), 'resultHalfTime' => array (0, 1),
                                   'referee' => 'S.Slyva',
                                   'refereeCity' => 'Kaunas',
                                   'spectators' => '50',
                                   'goal' => array (
                                                array ('min' => 2, 'name' => 'D.Semberas', 'home' => false),
                                                ),
                                   'miss' => array (
                                                array ('min' => 55, 'name' => 'A.Briaunys', 'home' => false),
                                                ),
                                   ),

"[Mar 29, Sat]
Dainava Alytus - Banga Gargzdai 2:2 (2:1). g. A.Kalimavicius (20), A.Miknevicius (36); A.Mickevicius (8), P.Rauktys (90 p.k.). Rf. O.Borisovskis (Vilnius). Att. 200."
                        =>
                            array ('date' => '1992-03-29',
                                   'homeTeam' => 'Dainava Alytus',   'awayTeam' => 'Banga Gargzdai',
                                   'result' => array (2, 2), 'resultHalfTime' => array (2, 1),
                                   'referee' => 'O.Borisovskis',
                                   'refereeCity' => 'Vilnius',
                                   'spectators' => '200',
                                   'goal' => array (
                                                array ('min' => 20, 'name' => 'A.Kalimavicius', 'home' => true),
                                                array ('min' => 36, 'name' => 'A.Miknevicius', 'home' => true),
                                                array ('min' => 8, 'name' => 'A.Mickevicius', 'home' => false),
                                                array ('min' => 90, 'name' => 'P.Rauktys', 'home' => false, 'pk' => true),
                                                ),
                                   ),

"[Mar 29, Sat]
Atletas Kaunas - Utenis Utena 1:2 (0:0). A.Ruzevskis-Bzelegas (87 p.k.); R.Datkunas (48), T.Keraitis (85). Rf. V.Kundrotas (Vilnius). Att. 50."
                        =>
                            array ('date' => '1992-03-29',
                                   'homeTeam' => 'Atletas Kaunas',   'awayTeam' => 'Utenis Utena',
                                   'result' => array (1, 2), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'V.Kundrotas',
                                   'refereeCity' => 'Vilnius',
                                   'spectators' => '50',
                                   'goal' => array (
                                                array ('min' => 87, 'name' => 'A.Ruzevskis-Bzelegas', 'home' => true, 'pk' => true),
                                                array ('min' => 48, 'name' => 'R.Datkunas', 'home' => false),
                                                array ('min' => 85, 'name' => 'T.Keraitis', 'home' => false),
                                                ),
                                   ),

"03.29
Lietuvos Makabi Vilnius - Mastis Telsiai 3:1. A.Paulauskas (Alytus). Kaunas. 660.
LM: K.Klisauskas
MAS: K.Kvedaras"
                        =>
                            array ('date' => '1992-03-29',
                                   'homeTeam' => 'Lietuvos Makabi Vilnius',   'awayTeam' => 'Mastis Telsiai',
                                   'result' => array ('3', '1'),
                                   'referee' => 'A.Paulauskas',
                                   'refereeCity' => 'Alytus',
                                   'spectators' => '660',
                                   'stadium' => 'Kaunas',
                                   'homePlayers' => array (
                                                array ('name' => 'K.Klisauskas', 'from' => 0, 'to' => 90),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'K.Kvedaras', 'from' => 0, 'to' => 90),
                                                ),
                                   ),

"03.29
FSK „Anykščiai“ – Švenčionių FK „Kūna“ 4:1 (0:1)
g. `62 ir `84 min K.Šimkus (Nr.24), `67 min R.Bugailiškis (Nr.23), `81 min T.Bereišis (Nr.17); `5 min D.Gruodis (Nr.10)
Įspėjimai: `37 min V.Komar, `86 min K.Cibulskas (abu FK „Kūna“); `85 min A.Parachonka (FSK „Anykščiai“)
Žiūrovų sk.: 60"
                        =>
                            array ('date' => '1992-03-29',
                                   'homeTeam' => 'FSK Anykščiai',   'awayTeam' => 'Švenčionių FK Kūna',
                                   'result' => array ('4', '1'),
                                   'resultHalfTime' => array ('0', '1'),
                                   'spectators' => '60',
                                   'goal' => array (
                                                array ('min' => 62, 'name' => 'K.Šimkus', 'home' => true),
                                                array ('min' => 84, 'name' => 'K.Šimkus', 'home' => true),
                                                array ('min' => 67, 'name' => 'R.Bugailiškis', 'home' => true),
                                                array ('min' => 81, 'name' => 'T.Bereišis', 'home' => true),
                                                array ('min' => 5, 'name' => 'D.Gruodis', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('min' => 37, 'name' => 'V.Komar', 'home' => false),
                                                array ('min' => 86, 'name' => 'K.Cibulskas', 'home' => false),
                                                array ('min' => 85, 'name' => 'A.Parachonka', 'home' => true),
                                                ),
                                   ),

"[Mar 29, Sat]
LIETUVOS MAKABI VILNIUS - BANGA KAUNAS 1:0 (0:0). Vilnius Vingis st. Att. 300. G.Dilda (Siauliai). g. 54 S.Vitkovskis. Booket: I.Pankratjevas.
LIM: G.Juodelis, S.Vitkovskis, I.Pankratjevas
BAN: A.Ramoska"
                        =>
                            array ('date' => '1992-03-29',
                                   'homeTeam' => 'LIETUVOS MAKABI VILNIUS',   'awayTeam' => 'BANGA KAUNAS',
                                   'result' => array ('1', '0'),
                                   'resultHalfTime' => array ('0', '0'),
                                   'referee' => 'G.Dilda',
                                   'refereeCity' => 'Siauliai',
                                   'spectators' => '300',
                                   'stadium' => 'Vilnius Vingis st',
                                   'goal' => array (
                                                array ('min' => 54, 'name' => 'S.Vitkovskis', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('name' => 'I.Pankratjevas', 'home' => true),
                                                ),
                                   'homePlayers' => array (
                                                array ('name' => 'G.Juodelis', 'from' => 0, 'to' => 90),
                                                array ('name' => 'S.Vitkovskis', 'from' => 0, 'to' => 90),
                                                array ('name' => 'I.Pankratjevas', 'from' => 0, 'to' => 90),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'A.Ramoska', 'from' => 0, 'to' => 90),
                                                ),
                                   ),

"[Mar 29, Sat]
LIETUVOS MAKABI VILNIUS - BANGA KAUNAS 1:0 (0:0). Vilnius Vingis st. Att. 300. G.Dilda (Siauliai). g. 54 S.Vitkovskis. Booket: I.Pankratjevas (Ban)."
                        =>
                            array ('date' => '1992-03-29',
                                   'homeTeam' => 'LIETUVOS MAKABI VILNIUS',   'awayTeam' => 'BANGA KAUNAS',
                                   'result' => array ('1', '0'),
                                   'resultHalfTime' => array ('0', '0'),
                                   'referee' => 'G.Dilda',
                                   'refereeCity' => 'Siauliai',
                                   'spectators' => '300',
                                   'stadium' => 'Vilnius Vingis st',
                                   'goal' => array (
                                                array ('min' => 54, 'name' => 'S.Vitkovskis', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('name' => 'I.Pankratjevas', 'home' => false),
                                                ),
                                   ),

"[Mar 29, Sat]
18.00  Gelezinis Vilkas Vilnius - Interas Visaginas  2:0 (0:0). Vilnius. 100. J.Miliauskas (Alytus). Goals: 15 (pk) M.Tamulis, 77 (pk) M.Tamulis. Booket: K.Deveika (GV). Sent Off: 28 R.Kirsanovas (GV)."
                        =>
                            array ('date' => '1992-03-29 18:00',
                                   'homeTeam' => 'Gelezinis Vilkas Vilnius',   'awayTeam' => 'Interas Visaginas',
                                   'result' => array ('2', '0'),
                                   'resultHalfTime' => array ('0', '0'),
                                   'referee' => 'J.Miliauskas',
                                   'refereeCity' => 'Alytus',
                                   'spectators' => '100',
                                   'stadium' => 'Vilnius',
                                   'goal' => array (
                                                array ('min' => 15, 'name' => 'M.Tamulis', 'pk' => true, 'home' => true),
                                                array ('min' => 77, 'name' => 'M.Tamulis', 'pk' => true, 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('name' => 'K.Deveika', 'home' => true),
                                                ),
                                   'sent' => array (
                                                array ('min' => 28, 'name' => 'R.Kirsanovas', 'home' => true),
                                                ),
                                   ),

"05.13
BANGA KAUNAS - LIETUVOS MAKABI VILNIUS 0:1 (0:1). Kaunas Politechnika st. Att. 500. G.Dilda (Siauliai). g. 21 R.Kuncevicius."
                        =>
                            array ('date' => '1992-05-13',
                                   'homeTeam' => 'BANGA KAUNAS',   'awayTeam' => 'LIETUVOS MAKABI VILNIUS',
                                   'result' => array ('0', '1'),
                                   'resultHalfTime' => array ('0', '1'),
                                   'referee' => 'G.Dilda',
                                   'refereeCity' => 'Siauliai',
                                   'spectators' => '500',
                                   'stadium' => 'Kaunas Politechnika st',
                                   'goal' => array (
                                                array ('min' => 21, 'name' => 'R.Kuncevicius', 'home' => false),
                                                ),
                                   ),

"05.13
ZALGIRIS VILNIUS - EKRANAS PANEVEZYS 0:0 (5-3 pk). Vilnius Zalgiris st. Att. 1300. R.Elsneris (Alytus)."
                        =>
                            array ('date' => '1992-05-13',
                                   'homeTeam' => 'ZALGIRIS VILNIUS',   'awayTeam' => 'EKRANAS PANEVEZYS',
                                   'result' => array ('0', '0'),
                                   'resultPenalty' => array ('5', '3'),
                                   'c_outcome' => MatchConstants::OUTCOME_PENALTIES_HOME,
                                   'referee' => 'R.Elsneris',
                                   'refereeCity' => 'Alytus',
                                   'spectators' => '1300',
                                   'stadium' => 'Vilnius Zalgiris st',
                                   ),

"1998.07.05
Kareda Siauliai - Ekranas Panevezys  0:3 (0:2). A.Dubinskas (Vilnius). Kedainiai. 600."
                        =>
                            array ('date' => '1998-07-05',
                                   'homeTeam' => 'Kareda Siauliai',   'awayTeam' => 'Ekranas Panevezys',
                                   'result' => array ('0', '3'),
                                   'resultHalfTime' => array ('0', '2'),
                                   'referee' => 'A.Dubinskas',
                                   'refereeCity' => 'Vilnius',
                                   'spectators' => '600',
                                   'stadium' => 'Kedainiai',
                                   ),

"09.14
14.00 JOGINTA KELME - ZEMAITIJA TELSIAI 0:1 (0:1). Kelme. 50. V.Titiskis (S). g. 13 N.Aleksejeva. Missed pk 70 R.Petrulyte (Zem)."
                        =>
                            array ('date' => '1992-09-14 14:00',
                                   'homeTeam' => 'JOGINTA KELME',   'awayTeam' => 'ZEMAITIJA TELSIAI',
                                   'result' => array ('0', '1'), 'resultHalfTime' => array (0, 1),
                                   'spectators' => '50',
                                   'referee' => 'V.Titiskis',
                                   'refereeCity' => 'S',
                                   'stadium' => 'Kelme',
                                   'goal' => array (
                                                array ('min' => 13, 'name' => 'N.Aleksejeva', 'home' => false),
                                                ),
                                   'miss' => array (
                                                array ('min' => 70, 'name' => 'R.Petrulyte', 'home' => false),
                                                ),
                                   ),

"[Aug 29]
Politechnika-Sika Kaunas - Ruta Nemencine 11:0 (3:0). E.Meidus (Kaunas). Kaunas. g. I.Gorbunoviene - 4, R.Pozelaite - 2, G.Nekrasova."
                        =>
                            array ('date' => '1992-08-29',
                                   'homeTeam' => 'Politechnika-Sika Kaunas',   'awayTeam' => 'Ruta Nemencine',
                                   'result' => array ('11', '0'), 'resultHalfTime' => array (3, 0),
                                   'referee' => 'E.Meidus',
                                   'refereeCity' => 'Kaunas',
                                   'stadium' => 'Kaunas',
                                   'goal' => array (
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'I.Gorbunoviene', 'home' => true),
                                                array ('name' => 'R.Pozelaite', 'home' => true),
                                                array ('name' => 'R.Pozelaite', 'home' => true),
                                                array ('name' => 'G.Nekrasova', 'home' => true),
                                                ),
                                   ),

"[Aug 29]
Ruta Nemencine - Politechnika-Sika Kaunas  0:4 (0:2). Vyg.Suziedelis (Vilnius). Nemencine. g. 1, 31, 60, 73 R.Kudyte."
                        =>
                            array ('date' => '1992-08-29',
                                   'homeTeam' => 'Ruta Nemencine',   'awayTeam' => 'Politechnika-Sika Kaunas',
                                   'result' => array ('0', '4'), 'resultHalfTime' => array (0, 2),
                                   'referee' => 'Vyg.Suziedelis',
                                   'refereeCity' => 'Vilnius',
                                   'stadium' => 'Nemencine',
                                   'goal' => array (
                                                array ('min' => 1, 'name' => 'R.Kudyte', 'home' => false, ),
                                                array ('min' => 31, 'name' => 'R.Kudyte', 'home' => false, ),
                                                array ('min' => 60, 'name' => 'R.Kudyte', 'home' => false, ),
                                                array ('min' => 73, 'name' => 'R.Kudyte', 'home' => false),
                                                ),
                                   ),

"[Aug 29]
Ruta Nemencine - Politechnika-Sika Kaunas  0:4 (0:2). Vyg.Suziedelis (Vilnius). Nemencine. g. 1 min., 31 min., 60 min. ir 73 min. R.Kudyte."
                        =>
                            array ('date' => '1992-08-29',
                                   'homeTeam' => 'Ruta Nemencine',   'awayTeam' => 'Politechnika-Sika Kaunas',
                                   'result' => array ('0', '4'), 'resultHalfTime' => array (0, 2),
                                   'referee' => 'Vyg.Suziedelis',
                                   'refereeCity' => 'Vilnius',
                                   'stadium' => 'Nemencine',
                                   'goal' => array (
                                                array ('min' => 1, 'name' => 'R.Kudyte', 'home' => false, ),
                                                array ('min' => 31, 'name' => 'R.Kudyte', 'home' => false, ),
                                                array ('min' => 60, 'name' => 'R.Kudyte', 'home' => false, ),
                                                array ('min' => 73, 'name' => 'R.Kudyte', 'home' => false),
                                                ),
                                   ),

"[Sep 6]
Politechnika-Sika Kaunas - Kristina Vilnius 0:0. K.Birieta (Kaunas). Kaunas. KTU."
                        =>
                            array ('date' => '1992-09-06',
                                   'homeTeam' => 'Politechnika-Sika Kaunas',   'awayTeam' => 'Kristina Vilnius',
                                   'result' => array ('0', '0'),
                                   'referee' => 'K.Birieta',
                                   'refereeCity' => 'Kaunas',
                                   'stadium' => 'Kaunas. KTU',
                                   ),

"Round 14
[Sep 6]
Politechnika-Sika Kaunas - Kristina Vilnius 0:0. K.Birieta (Kaunas). Kaunas. KTU."
                        =>
                            array ('date' => '1992-09-06',
                                   'homeTeam' => 'Politechnika-Sika Kaunas',   'awayTeam' => 'Kristina Vilnius',
                                   'result' => array ('0', '0'),
                                   'referee' => 'K.Birieta',
                                   'refereeCity' => 'Kaunas',
                                   'stadium' => 'Kaunas. KTU',
                                   'round' => '14',
                                   ),

"[Sep 25]
14.00  Gintra Siauliai - Sventupe Ukmerge  3:0 (2:0). Siauliai. 100. D.Kancelskis (Siauliai). Goals: 32 A.Busmiene, 40 A.Kubilinskiene.
14.00  SM-Zemaitija Telsiai - Ruta Nemencine  4:0 (2:0). Telsiai. 50. S.Tiskus (Telsiai). Goals: 15 S.Mickute, 27 I.Bielskyte, 60 I.Bielsjyte, 84 J.Macikonyte."
                        =>
                            array ('date' => '1992-09-25 14:00',
                                   'homeTeam' => 'Gintra Siauliai',   'awayTeam' => 'Sventupe Ukmerge',
                                   'result' => array ('3', '0'), 'resultHalfTime' => array (2, 0),
                                   'referee' => 'D.Kancelskis',
                                   'refereeCity' => 'Siauliai',
                                   'stadium' => 'Siauliai',
                                   'spectators' => '100',
                                   'goal' => array (
                                                array ('min' => 32, 'name' => 'A.Busmiene', 'home' => true),
                                                array ('min' => 40, 'name' => 'A.Kubilinskiene', 'home' => true),
                                                ),
                                   'sourceDetails' => "[Sep 25]
14.00  Gintra Siauliai - Sventupe Ukmerge  3:0 (2:0). Siauliai. 100. D.Kancelskis (Siauliai). Goals: 32 A.Busmiene, 40 A.Kubilinskiene."
                                   ),

"[Sep 25]
15.00  Zemaitija Telsiai - Tauras Vilnius  3:0*. (without game)."
                        =>
                            array ('date' => '1992-09-25 15:00',
                                   'homeTeam' => 'Zemaitija Telsiai',   'awayTeam' => 'Tauras Vilnius',
                                   'result' => array ('3', '0'),
                                   'c_outcome' => MatchConstants::OUTCOME_TECHNICAL_WIN,
                                   ),

"[Sep 25]
13.00  Ruta Nemencine - FM Vilnius  0:4  P.Svidras (Vilnius)"
                        =>
                            array ('date' => '1992-09-25 13:00',
                                   'homeTeam' => 'Ruta Nemencine',   'awayTeam' => 'FM Vilnius',
                                   'result' => array ('0', '4'),
                                   'referee' => 'P.Svidras',
                                   'refereeCity' => 'Vilnius',
                                   ),

"[Jun 15]
14.00  Gintra-Universitetas Siauliai - Elena Vilnius  13-0 (4:0). R.Butkus (Siauliai)."
                        =>
                            array ('date' => '1992-06-15 14:00',
                                   'homeTeam' => 'Gintra-Universitetas Siauliai',   'awayTeam' => 'Elena Vilnius',
                                   'result' => array ('13', '0'), 'resultHalfTime' => array (4, 0),
                                   'referee' => 'R.Butkus',
                                   'refereeCity' => 'Siauliai',
                                   ),

"[Jun 15]
Greece – Italy 0:0
800 spectators
Yellow cards: Ioannidis (65); Allegra (32), Rugani (68)"
                        =>
                            array ('date' => '1992-06-15',
                                   'homeTeam' => 'Greece',   'awayTeam' => 'Italy',
                                   'result' => array ('0', '0'),
                                   'spectators' => 800,
                                   'book' => array (
                                                array ('min' => 65, 'name' => 'Ioannidis', 'home' => true, ),
                                                array ('min' => 32, 'name' => 'Allegra', 'home' => false, ),
                                                array ('min' => 68, 'name' => 'Rugani', 'home' => false, ),
                                                ),
                                   ),
"[Jun 15]
Russia - Belarus 0:0
3000 spectators
Goals: Ioannidis (65); Allegra (32), Rugani (68) - penalty"
                        =>
                            array ('date' => '1992-06-15',
                                   'homeTeam' => 'Russia',   'awayTeam' => 'Belarus',
                                   'result' => array ('0', '0'),
                                   'spectators' => 3000,
                                   'goal' => array (
                                                array ('min' => 65, 'name' => 'Ioannidis', 'home' => true, ),
                                                array ('min' => 32, 'name' => 'Allegra', 'home' => false, ),
                                                array ('min' => 68, 'name' => 'Rugani', 'home' => false, 'pk' => true ),
                                                ),
                                   ),

"[Apr 28]
17.00  Kreontas-FM Vilnius - Elena Vilnius  16:0 (5:0). A.Melnikovas (Vilnius). Goals: R.Mazukelyte (8, 16, 55, 60, 66, 75), J.Lavrenovaite (19, 70, 89), N.Rucinskaite (48), G.Varvara (80-og)."
                        =>
                            array ('date' => '1992-04-28 17:00',
                                   'homeTeam' => 'Kreontas-FM Vilnius',   'awayTeam' => 'Elena Vilnius',
                                   'result' => array ('16', '0'), 'resultHalfTime' => array (5, 0),
                                   'referee' => 'A.Melnikovas',
                                   'refereeCity' => 'Vilnius',
                                   'goal' => array (
                                                array ('min' => 8, 'name' => 'R.Mazukelyte', 'home' => true, ),
                                                array ('min' => 16, 'name' => 'R.Mazukelyte', 'home' => true, ),
                                                array ('min' => 55, 'name' => 'R.Mazukelyte', 'home' => true, ),
                                                array ('min' => 60, 'name' => 'R.Mazukelyte', 'home' => true, ),
                                                array ('min' => 66, 'name' => 'R.Mazukelyte', 'home' => true, ),
                                                array ('min' => 75, 'name' => 'R.Mazukelyte', 'home' => true,),
                                                array ('min' => 19, 'name' => 'J.Lavrenovaite', 'home' => true, ),
                                                array ('min' => 70, 'name' => 'J.Lavrenovaite', 'home' => true, ),
                                                array ('min' => 89, 'name' => 'J.Lavrenovaite', 'home' => true,),
                                                array ('min' => 48, 'name' => 'N.Rucinskaite', 'home' => true,),
                                                array ('min' => 80, 'name' => 'G.Varvara', 'home' => true, 'og' => true),
                                                ),
                                   ),
"[Apr 28]
17.00  Kreontas-FM Vilnius - Elena Vilnius  1:0 (1:0). A.Melnikovas (Vilnius). Goals: G.Varvara (80pk)."
                        =>
                            array ('date' => '1992-04-28 17:00',
                                   'homeTeam' => 'Kreontas-FM Vilnius',   'awayTeam' => 'Elena Vilnius',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array (1, 0),
                                   'referee' => 'A.Melnikovas',
                                   'refereeCity' => 'Vilnius',
                                   'goal' => array (
                                                array ('min' => 80, 'name' => 'G.Varvara', 'home' => true, 'pk' => true),
                                                ),
                                   ),

"[Apr 28]
Suduva Marijampole - Polonia Vilnius 1:0 (0:0). Z.Marciulionis (79). Rf. V.Chileckis (Kaunas). Booket A.Kalinauskas (Suduva). Att. 500."
                        =>
                            array ('date' => '1992-04-28',
                                   'homeTeam' => 'Suduva Marijampole',   'awayTeam' => 'Polonia Vilnius',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'V.Chileckis',
                                   'refereeCity' => 'Kaunas',
                                   'spectators' => '500',
                                   'goal' => array (
                                                array ('min' => 79, 'name' => 'Z.Marciulionis', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('name' => 'A.Kalinauskas', 'home' => true),
                                                ),
                                   ),

"[Apr 28]
Tauras Taurage - Inkaras Kaunas 0:5 (0:3). E.Karciauskas (12), A.Mika (14, 31, 85), N.Dunauskas (78). Rf. R.Celiauskas (Silute). 58 sent off N.Astrauskas, 79 - I.Koganas. Booket V.Smirnovas (all Tauras). Att. 200."
                        =>
                            array ('date' => '1992-04-28',
                                   'homeTeam' => 'Tauras Taurage',   'awayTeam' => 'Inkaras Kaunas',
                                   'result' => array (0, 5), 'resultHalfTime' => array (0, 3),
                                   'referee' => 'R.Celiauskas',
                                   'refereeCity' => 'Silute',
                                   'spectators' => '200',
                                   'goal' => array (
                                                array ('min' => 12, 'name' => 'E.Karciauskas', 'home' => false),
                                                array ('min' => 14, 'name' => 'A.Mika', 'home' => false),
                                                array ('min' => 31, 'name' => 'A.Mika', 'home' => false),
                                                array ('min' => 85, 'name' => 'A.Mika', 'home' => false),
                                                array ('min' => 78, 'name' => 'N.Dunauskas', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('name' => 'V.Smirnovas', 'home' => true),
                                                ),
                                   'sent' => array (
                                                array ('min' => 58, 'name' => 'N.Astrauskas', 'home' => true),
                                                array ('min' => 79, 'name' => 'I.Koganas', 'home' => true),
                                                ),
                                   ),

"[Apr 28]
Ruta-Consena Nemencine  – SC Kaisiadorys  4:2 (3:1). Suziedelis (Vilnius). Goals: I Kolpak (15, 19, 61). A.Stefanovic (26); A.Sabonyte (32), J.Savickaja (73)."
                        =>
                            array ('date' => '1992-04-28',
                                   'homeTeam' => 'Ruta-Consena Nemencine',   'awayTeam' => 'SC Kaisiadorys',
                                   'result' => array ('4', '2'), 'resultHalfTime' => array (3, 1),
                                   'referee' => 'Suziedelis',
                                   'refereeCity' => 'Vilnius',
                                   'goal' => array (
                                                array ('min' => 15, 'name' => 'I. Kolpak', 'home' => true, ),
                                                array ('min' => 19, 'name' => 'I. Kolpak', 'home' => true, ),
                                                array ('min' => 61, 'name' => 'I. Kolpak', 'home' => true,),
                                                array ('min' => 26, 'name' => 'A.Stefanovic', 'home' => true,),
                                                array ('min' => 32, 'name' => 'A.Sabonyte', 'home' => false,),
                                                array ('min' => 73, 'name' => 'J.Savickaja', 'home' => false,),
                                                ),
                                   ),

"[Apr 28]
14.00  SC Kaisiadorys - Ruta-Consena Nemencine  0:4 (0:2). K.Dranginis (Kaisiadorys). Goals: I.Kolpak (25, 45-pk, 71, 87-pk)."
                        =>
                            array ('date' => '1992-04-28 14:00',
                                   'homeTeam' => 'SC Kaisiadorys',   'awayTeam' => 'Ruta-Consena Nemencine',
                                   'result' => array ('0', '4'), 'resultHalfTime' => array (0, 2),
                                   'referee' => 'K.Dranginis',
                                   'refereeCity' => 'Kaisiadorys',
                                   'goal' => array (
                                                array ('min' => 25, 'name' => 'I.Kolpak', 'home' => false),
                                                array ('min' => 45, 'name' => 'I.Kolpak', 'home' => false, 'pk' => true),
                                                array ('min' => 71, 'name' => 'I.Kolpak', 'home' => false),
                                                array ('min' => 87, 'name' => 'I.Kolpak', 'home' => false, 'pk' => true),
                                                ),
                                   ),

"[Apr 28]
Elena Vilnius - Kreontas-FM Vilnius  0:9 (0:6). V.Jevicius (Vilnius). Goals: R.Mazukelyte (11, 24); E.Ramelyte (16, 31)."
                        =>
                            array ('date' => '1992-04-28',
                                   'homeTeam' => 'Elena Vilnius',   'awayTeam' => 'Kreontas-FM Vilnius',
                                   'result' => array ('0', '9'), 'resultHalfTime' => array (0, 6),
                                   'referee' => 'V.Jevicius',
                                   'refereeCity' => 'Vilnius',
                                   'goal' => array (
                                                array ('min' => 11, 'name' => 'R.Mazukelyte', 'home' => false),
                                                array ('min' => 24, 'name' => 'R.Mazukelyte', 'home' => false),
                                                array ('min' => 16, 'name' => 'E.Ramelyte', 'home' => false),
                                                array ('min' => 31, 'name' => 'E.Ramelyte', 'home' => false),
                                                ),
                                   ),

"[Apr 28]
SC Kaisiadorys - FM Kaunas FM  2:3 (1:1). K.Dranginis (Kaisiadorys). Goals: A.Sabonyte (5); I.Bielskyte (24); M.Latockaite (45); G.Mineikaite (59); J.Smailiene (79)."
                        =>
                            array ('date' => '1992-04-28',
                                   'homeTeam' => 'SC Kaisiadorys',   'awayTeam' => 'FM Kaunas FM',
                                   'result' => array ('2', '3'), 'resultHalfTime' => array (1, 1),
                                   'referee' => 'K.Dranginis',
                                   'refereeCity' => 'Kaisiadorys',
                                   'goal' => array (
                                                array ('min' => 5, 'name' => 'A.Sabonyte', 'home' => true),
                                                array ('min' => 24, 'name' => 'I.Bielskyte', 'home' => true),
                                                array ('min' => 45, 'name' => 'M.Latockaite', 'home' => false),
                                                array ('min' => 59, 'name' => 'G.Mineikaite', 'home' => false),
                                                array ('min' => 79, 'name' => 'J.Smailiene', 'home' => false),
                                                ),
                                   ),
"[Apr 28}
SC Kaisiadorys - FM Kaunas FM  2:3 (1:1). K.Dranginis (Kaisiadorys). Goals: A.Sabonyte (5); I.Bielskyte (24); M.Latockaite (45); G.Mineikaite (59); J.Smailiene (79)."
                        =>
                            array ('date' => '1992-04-28',
                                   'homeTeam' => 'SC Kaisiadorys',   'awayTeam' => 'FM Kaunas FM',
                                   'result' => array ('2', '3'), 'resultHalfTime' => array (1, 1),
                                   'referee' => 'K.Dranginis',
                                   'refereeCity' => 'Kaisiadorys',
                                   'goal' => array (
                                                array ('min' => 5, 'name' => 'A.Sabonyte', 'home' => true),
                                                array ('min' => 24, 'name' => 'I.Bielskyte', 'home' => true),
                                                array ('min' => 45, 'name' => 'M.Latockaite', 'home' => false),
                                                array ('min' => 59, 'name' => 'G.Mineikaite', 'home' => false),
                                                array ('min' => 79, 'name' => 'J.Smailiene', 'home' => false),
                                                ),
                                   ),

"[Sep 3]
“TexTiliTe” – Alytaus SRC 1:4 (1:1)
Teisėjai - D.Petraška, J.Butkus, V.Lisevičius
Įvarčiai: 16 min. I.Siliūnienė 0:1; 26 min. M.Latočkaitė 1:1; 60 min. J.Lavrenovaitė 1:2; 69 min. R.Mažukėlytė 1:3; 72 min. E.Ramelytė 1:4."
                        =>
                            array ('date' => '1992-09-03',
                                   'homeTeam' => 'TexTiliTe',   'awayTeam' => 'Alytaus SRC',
                                   'result' => array ('1', '4'), 'resultHalfTime' => array (1, 1),
                                   'referee' => 'D.Petraška',
                                   'refereeA1' => 'J.Butkus',
                                   'refereeA2' => 'V.Lisevičius',
                                   'goal' => array (
                                                array ('min' => 16, 'name' => 'I.Siliūnienė', 'home' => false),
                                                array ('min' => 26, 'name' => 'M.Latočkaitė', 'home' => true),
                                                array ('min' => 60, 'name' => 'J.Lavrenovaitė', 'home' => false),
                                                array ('min' => 69, 'name' => 'R.Mažukėlytė', 'home' => false),
                                                array ('min' => 72, 'name' => 'E.Ramelytė', 'home' => false),
                                                ),
                                   ),
"[Sep 4]
1. Kaišiadorių SC - Visagino SC 2:1 (2:1)
Teisėjas – J.Butkus
Įvarčiai: I. Kostkevičiūtė – 2; A. Metlickaja – 1."
                        =>
                            array ('date' => '1992-09-04',
                                   'homeTeam' => 'Kaišiadorių SC',   'awayTeam' => 'Visagino SC',
                                   'result' => array ('2', '1'), 'resultHalfTime' => array (2, 1),
                                   'referee' => 'J.Butkus',
                                   'number' => 1,
                                   'goal' => array (
                                                array ('name' => 'I. Kostkevičiūtė', 'home' => true),
                                                array ('name' => 'I. Kostkevičiūtė', 'home' => true),
                                                array ('name' => 'A. Metlickaja', 'home' => false),
                                                ),
                                   ),
"[Sep 4]
1. Kaišiadorių SC - Visagino SC 2:1 (2:1)
Teisėjas – J.Butkus
Įvarčiai: I. Kostkevičiūtė (2); A. Metlickaja (1)."
                        =>
                            array ('date' => '1992-09-04',
                                   'homeTeam' => 'Kaišiadorių SC',   'awayTeam' => 'Visagino SC',
                                   'result' => array ('2', '1'), 'resultHalfTime' => array (2, 1),
                                   'referee' => 'J.Butkus',
                                   'number' => 1,
                                   'goal' => array (
                                                array ('name' => 'I. Kostkevičiūtė', 'home' => true),
                                                array ('name' => 'I. Kostkevičiūtė', 'home' => true),
                                                array ('name' => 'A. Metlickaja', 'home' => false),
                                                ),
                                   ),
"[Sep 4]
12. Kaišiadorių SC - Visagino SC 1:0 (0:0)
Teisėjas – J.Butkus
Įvarčiai – A.Naomčiuk – 1"
                        =>
                            array ('date' => '1992-09-04',
                                   'homeTeam' => 'Kaišiadorių SC',   'awayTeam' => 'Visagino SC',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'J.Butkus',
                                   'number' => 12,
                                   'goal' => array (
                                                array ('name' => 'A.Naomčiuk', 'home' => true),
                                                ),
                                   ),
"[Sep 12]
12. “Izobara” - Akmenės SC 4:0 (1:0)
Teisėjas – V.Lisevičius
Įvarčiai: I.Garnytė – 3; K.Grikavičiūtė – 1."
                        =>
                            array ('date' => '1992-09-12',
                                   'homeTeam' => 'Izobara',   'awayTeam' => 'Akmenės SC',
                                   'result' => array ('4', '0'), 'resultHalfTime' => array (1, 0),
                                   'referee' => 'V.Lisevičius',
                                   'number' => 12,
                                   'goal' => array (
                                                array ('name' => 'I.Garnytė', 'home' => true),
                                                array ('name' => 'I.Garnytė', 'home' => true),
                                                array ('name' => 'I.Garnytė', 'home' => true),
                                                array ('name' => 'K.Grikavičiūtė', 'home' => true),
                                                ),
                                   ),
"[Sep 12]
7. “Izobara” - Kauno FM 7:0 (6:0)
Teisėjas – D.Petraška
Įvarčiai: R.Šablevičiūtė, I.Garnytė – po 2; R.Kunickaitė, K.Grikavičiūtė, J.Rutkauskaitė – po 1."
                        =>
                            array ('date' => '1992-09-12',
                                   'homeTeam' => 'Izobara',   'awayTeam' => 'Kauno FM',
                                   'result' => array ('7', '0'), 'resultHalfTime' => array (6, 0),
                                   'referee' => 'D.Petraška',
                                   'number' => 7,
                                   'goal' => array (
                                                array ('name' => 'R.Šablevičiūtė', 'home' => true),
                                                array ('name' => 'R.Šablevičiūtė', 'home' => true),
                                                array ('name' => 'I.Garnytė', 'home' => true),
                                                array ('name' => 'I.Garnytė', 'home' => true),
                                                array ('name' => 'R.Kunickaitė', 'home' => true),
                                                array ('name' => 'K.Grikavičiūtė', 'home' => true),
                                                array ('name' => 'J.Rutkauskaitė', 'home' => true),
                                                ),
                                   ),

"[Sep 12]
7. “Rūta-Consena” – “Elena” 8:0 (3:0)
Teisėjai – A.Melnikovas, A.Bagdonas, A.Radžius
Įvarčiai: 31, 35, 45 min. I.Kolpak 3:0; 46, 49, 61 min. A.Semaško 6:0; 73, 88 min. E.Vaškienė 8:0."
                        =>
                            array ('date' => '1992-09-12',
                                   'homeTeam' => 'Rūta-Consena',   'awayTeam' => 'Elena',
                                   'result' => array ('8', '0'), 'resultHalfTime' => array (3, 0),
                                   'referee' => 'A.Melnikovas',
                                   'refereeA1' => 'A.Bagdonas',
                                   'refereeA2' => 'A.Radžius',
                                   'number' => 7,
                                   'goal' => array (
                                                array ('min' => 31, 'name' => 'I.Kolpak', 'home' => true),
                                                array ('min' => 35, 'name' => 'I.Kolpak', 'home' => true),
                                                array ('min' => 45, 'name' => 'I.Kolpak', 'home' => true),
                                                array ('min' => 46, 'name' => 'A.Semaško', 'home' => true),
                                                array ('min' => 49, 'name' => 'A.Semaško', 'home' => true),
                                                array ('min' => 61, 'name' => 'A.Semaško', 'home' => true),
                                                array ('min' => 73, 'name' => 'E.Vaškienė', 'home' => true),
                                                array ('min' => 88, 'name' => 'E.Vaškienė', 'home' => true),
                                                ),
                                   ),

"[Sep 07]
9.“Gintra-Universitetas” - “Vėtra” 4:0 (1:0)
Teisėjai – J.Lukjančukas, D.Skaparas, M.Lukjančukas
Įvarčiai: 5 min. R.Kudytė 1:0; 49 min. O. Švaikevič (11 m.) 2:0; 68 min. R.Kudytė (11 m.) 3:0; 82 min. J.Pleškytė 4:0"
                        =>
                            array ('date' => '1992-09-07',
                                   'homeTeam' => 'Gintra-Universitetas',   'awayTeam' => 'Vėtra',
                                   'result' => array ('4', '0'), 'resultHalfTime' => array (1, 0),
                                   'referee' => 'J.Lukjančukas',
                                   'refereeA1' => 'D.Skaparas',
                                   'refereeA2' => 'M.Lukjančukas',
                                   'number' => 9,
                                   'goal' => array (
                                                array ('min' => 5, 'name' => 'R.Kudytė', 'home' => true),
                                                array ('min' => 49, 'name' => 'O. Švaikevič', 'home' => true, 'pk' => true),
                                                array ('min' => 68, 'name' => 'R.Kudytė', 'home' => true, 'pk' => true),
                                                array ('min' => 82, 'name' => 'J.Pleškytė', 'home' => true),
                                                ),
                                   ),

"[Oct 23]
14.00  Gintra-Universitetas Siauliai - TexTilite Ukmerge   1:3 (0:1). G.Ratkevicius (Kaunas). Pakruojas. Sporto Centras. 170.
Goals: J.Macikunyte (74); S.Railaite (16, 70), E.Liseviciute (46).
GIN: R.Pozelaite (71 I.Gelzinyte), J.Macikunyte.
TEX: A.Ratkeviciute.
Booket: J.Macikunyte (Gin)."
                        =>
                            array ('date' => '1992-10-23 14:00',
                                   'homeTeam' => 'Gintra-Universitetas Siauliai',   'awayTeam' => 'TexTilite Ukmerge',
                                   'result' => array ('1', '3'), 'resultHalfTime' => array (0, 1),
                                   'referee' => 'G.Ratkevicius',
                                   'refereeCity' => 'Kaunas',
                                   'stadium' => 'Pakruojas. Sporto Centras',
                                   'spectators' => '170',
                                   'goal' => array (
                                                array ('min' => 74, 'name' => 'J.Macikunyte', 'home' => true),
                                                array ('min' => 16, 'name' => 'S.Railaite', 'home' => false),
                                                array ('min' => 70, 'name' => 'S.Railaite', 'home' => false),
                                                array ('min' => 46, 'name' => 'E.Liseviciute', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('name' => 'J.Macikunyte', 'home' => true),
                                                ),
                                   'homePlayers' => array (
                                                array ('name' => 'R.Pozelaite',
                                                       'from' => 0, 'to' => '71',
                                                       'substitute' => array ('name' => 'I.Gelzinyte','from' => '71', 'to' => 90, ),
                                                       ),
                                                array ('name' => 'J.Macikunyte',
                                                       'from' => 0, 'to' => '90',
                                                       ),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'A.Ratkeviciute',
                                                       'from' => 0, 'to' => '90',
                                                       ),
                                                ),
                                   ),

"[Apr 14, Sun]
13.00  Kauno Jegeriai - Tauras ir Erra Taurage  3:1 (1:1). D.Bisigirskas (Jonava). 100.
Goals: 6 V.Griskevicius, 73 A.Garska, 90+2 D.Liutkus; 21 S.Taroza.
Booket: 55 V.Dragunevicius, 67 E.Taroza, 88 A.Bendikas (Tau)."
                        =>
                            array ('date' => '1992-04-14 13:00',
                                   'homeTeam' => 'Kauno Jegeriai',   'awayTeam' => 'Tauras ir Erra Taurage',
                                   'result' => array ('3', '1'), 'resultHalfTime' => array (1, 1),
                                   'referee' => 'D.Bisigirskas',
                                   'refereeCity' => 'Jonava',
                                   'spectators' => '100',
                                   'goal' => array (
                                                array ('min' => 6, 'name' => 'V.Griskevicius', 'home' => true),
                                                array ('min' => 73, 'name' => 'A.Garska', 'home' => true),
                                                array ('min' => 90, 'extra' => 2, 'name' => 'D.Liutkus', 'home' => true),
                                                array ('min' => 21, 'name' => 'S.Taroza', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('min' => 55, 'name' => 'V.Dragunevicius', 'home' => false),
                                                array ('min' => 67, 'name' => 'E.Taroza', 'home' => false),
                                                array ('min' => 88, 'name' => 'A.Bendikas', 'home' => false),
                                                ),
                                   ),

"[Apr 14, Sun]
  Banga Gargzdai - Kauno Jegeriai  1:0 (0:0). J.Lukjancukas (Siauliai). 400.
Goal: 84 G.Ratkus.
Booket: 90+2 M.Kazlauskas (Ban)."
                        =>
                            array ('date' => '1992-04-14',
                                   'homeTeam' => 'Banga Gargzdai',   'awayTeam' => 'Kauno Jegeriai',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'J.Lukjancukas',
                                   'refereeCity' => 'Siauliai',
                                   'spectators' => '400',
                                   'goal' => array (
                                                array ('min' => 84, 'name' => 'G.Ratkus', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('min' => 90, 'extra' => 2, 'name' => 'M.Kazlauskas', 'home' => true),
                                                ),
                                   ),

"14 Apr
  Banga Gargzdai - Kauno Jegeriai  1:0 (0:0). J.Lukjancukas (Siauliai). 400.
Goal: 84 G.Ratkus.
Booket: 90+2 M.Kazlauskas (Ban)."
                        =>
                            array ('date' => '1992-04-14',
                                   'homeTeam' => 'Banga Gargzdai',   'awayTeam' => 'Kauno Jegeriai',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'J.Lukjancukas',
                                   'refereeCity' => 'Siauliai',
                                   'spectators' => '400',
                                   'goal' => array (
                                                array ('min' => 84, 'name' => 'G.Ratkus', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('min' => 90, 'extra' => 2, 'name' => 'M.Kazlauskas', 'home' => true),
                                                ),
                                   ),

"[Apr 14, Sun]
  Kruoja Pakruojis - Banga Gargzdai  1:0 (0:0). J.Lukjancukas (Siauliai). 400.
Goal: 84 G.Ratkus.
Booket: 18 A.Steinas (Kru); 10 A.Anisimenko (Ban)."
                        =>
                            array ('date' => '1992-04-14',
                                   'homeTeam' => 'Kruoja Pakruojis',   'awayTeam' => 'Banga Gargzdai',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'J.Lukjancukas',
                                   'refereeCity' => 'Siauliai',
                                   'spectators' => '400',
                                   'goal' => array (
                                                array ('min' => 84, 'name' => 'G.Ratkus', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('min' => 18, 'name' => 'A.Steinas', 'home' => true),
                                                array ('min' => 10, 'name' => 'A.Anisimenko', 'home' => false),
                                                ),
                                   ),

"[Apr 14, Sun]
  Alytis Alytus - Banga Gargzdai  1:1 (0:0). D.Bisigirskas (Jonava). 400.
Goals: 58 M.Sarkelis; 72 A.Staponka.
Booket: 17 A.Miniauskas (Aly); 59 A.Staponka, 66 M.Gudauskas, 78 A.Anisimenko (Ban);
Sent Off: 53 S.Slusnys (Ban)."
                        =>
                            array ('date' => '1992-04-14',
                                   'homeTeam' => 'Alytis Alytus',   'awayTeam' => 'Banga Gargzdai',
                                   'result' => array ('1', '1'), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'D.Bisigirskas',
                                   'refereeCity' => 'Jonava',
                                   'spectators' => '400',
                                   'goal' => array (
                                                array ('min' => 58, 'name' => 'M.Sarkelis', 'home' => true),
                                                array ('min' => 72, 'name' => 'A.Staponka', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('min' => 17, 'name' => 'A.Miniauskas', 'home' => true),
                                                array ('min' => 59, 'name' => 'A.Staponka', 'home' => false),
                                                array ('min' => 66, 'name' => 'M.Gudauskas', 'home' => false),
                                                array ('min' => 78, 'name' => 'A.Anisimenko', 'home' => false),
                                                ),
                                   'sent' => array (
                                                array ('min' => 53, 'name' => 'S.Slusnys', 'home' => false),
                                                )
                                   ),

"[Apr 14, Sun]
11 . „Mastis“ – LICS-Žygis“ 5:1 (0:1)
Teisėjas – A. Mazalas (Klaipėda), asistentai – V. Gerasimovas (Meksika) ir L. Jakas (Klaipėda)
Žiūrovų: 80
Įvarčiai: 35 min. K. Daškus (0:1), 54 min. V. Vasiliauskas (1:1), 62 min. V. Barkevičius (2:1), 75 min. V. Barkevičius (3:1), 79 min. K. Jankauskas (4:1), 85 min. V. Barkevičius (5:1).
Įspėjimai: 31 min. M. Šliogeris („Mastis“), 65 min. M. Sabas („LICS-Žygis“), 68 min. K. Jankauskas („Mastis“).
Pašalinimai: 50 min. J. Valančiauskas („LICS-Žygis“)."
                        =>
                            array ('date' => '1992-04-14',
                                   'homeTeam' => 'Mastis',   'awayTeam' => 'LICS-Žygis',
                                   'result' => array ('5', '1'), 'resultHalfTime' => array (0, 1),
                                   'referee' => 'A. Mazalas',
                                   'refereeCity' => 'Klaipėda',
                                   'refereeA1' => 'V. Gerasimovas',
                                   'refereeA1City' => 'Meksika',
                                   'refereeA2' => 'L. Jakas',
                                   'refereeA2City' => 'Klaipėda',
                                   'spectators' => '80',
                                   'number' => 11,
                                   'goal' => array (
                                                array ('min' => 35, 'name' => 'K. Daškus', 'home' => false),
                                                array ('min' => 54, 'name' => 'V. Vasiliauskas', 'home' => true),
                                                array ('min' => 62, 'name' => 'V. Barkevičius', 'home' => true),
                                                array ('min' => 75, 'name' => 'V. Barkevičius', 'home' => true),
                                                array ('min' => 79, 'name' => 'K. Jankauskas', 'home' => true),
                                                array ('min' => 85, 'name' => 'V. Barkevičius', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('min' => 31, 'name' => 'M. Šliogeris', 'home' => true),
                                                array ('min' => 65, 'name' => 'M. Sabas', 'home' => false),
                                                array ('min' => 68, 'name' => 'K. Jankauskas', 'home' => true),
                                                ),
                                   'sent' => array (
                                                array ('min' => 50, 'name' => 'J. Valančiauskas', 'home' => false),
                                                )
                                   ),

"[Apr 14, Sun]
31. „Sakuona-Klarksonas“ – „Bangelė“ 5:2 (3:0)
Teisėjas – A. Arakelian (Palanga), asistentai – M.Viluckas (Kretinga) ir G. Arakelian (Palanga)
Įvarčiai: 21 min.  M.Šimkus (1:0), 24 min. M.Stoukus (2:0), 29 min. R. Stonys (3:0), 64 min. A.Marcinkevičius (3:1),  69 min. M.Stoukus (4:1), 76 min. A.Marcinkevičius (4:2), 80 min. T. Karinauskas (11 m.) (5:2).
Įspėjimai: 16 min. Tadas Vitkauskas (“Bangelė“), 72 min. N.Jurkaitis („Sakuona-K.“)."
                        =>
                            array ('date' => '1992-04-14',
                                   'homeTeam' => 'Sakuona-Klarksonas',   'awayTeam' => 'Bangelė',
                                   'result' => array ('5', '2'), 'resultHalfTime' => array (3, 0),
                                   'referee' => 'A. Arakelian',
                                   'refereeCity' => 'Palanga',
                                   'refereeA1' => 'M.Viluckas',
                                   'refereeA1City' => 'Kretinga',
                                   'refereeA2' => 'G.Arakelian',
                                   'refereeA2City' => 'Palanga',
                                   'number' => 31,
                                   'goal' => array (
                                                array ('min' => 21, 'name' => 'M.Šimkus', 'home' => true),
                                                array ('min' => 24, 'name' => 'M.Stoukus', 'home' => true),
                                                array ('min' => 29, 'name' => 'R. Stonys', 'home' => true),
                                                array ('min' => 64, 'name' => 'A.Marcinkevičius', 'home' => false),
                                                array ('min' => 69, 'name' => 'M.Stoukus', 'home' => true),
                                                array ('min' => 76, 'name' => 'A.Marcinkevičius', 'home' => false),
                                                array ('min' => 80, 'name' => 'T. Karinauskas', 'home' => true, 'pk' => true),
                                                ),
                                   'book' => array (
                                                array ('min' => 16, 'name' => 'Tadas Vitkauskas', 'home' => false),
                                                array ('min' => 72, 'name' => 'N.Jurkaitis', 'home' => true),
                                                ),
                                   ),

"[Apr 14, Sun]
  Alytis Alytus - Banga Gargzdai  1:1 (0:0). D.Bisigirskas (Jonava). 400.
Goals: 58 M.Sarkelis; 72 A.Staponka.
Sent Off: 53 S.Slusnys (Ban). Booket: 17 A.Miniauskas (Aly); 59 A.Staponka, 66 M.Gudauskas, 78 A.Anisimenko (Ban)"
                        =>
                            array ('date' => '1992-04-14',
                                   'homeTeam' => 'Alytis Alytus',   'awayTeam' => 'Banga Gargzdai',
                                   'result' => array ('1', '1'), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'D.Bisigirskas',
                                   'refereeCity' => 'Jonava',
                                   'spectators' => '400',
                                   'goal' => array (
                                                array ('min' => 58, 'name' => 'M.Sarkelis', 'home' => true),
                                                array ('min' => 72, 'name' => 'A.Staponka', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('min' => 17, 'name' => 'A.Miniauskas', 'home' => true),
                                                array ('min' => 59, 'name' => 'A.Staponka', 'home' => false),
                                                array ('min' => 66, 'name' => 'M.Gudauskas', 'home' => false),
                                                array ('min' => 78, 'name' => 'A.Anisimenko', 'home' => false),
                                                ),
                                   'sent' => array (
                                                array ('min' => 53, 'name' => 'S.Slusnys', 'home' => false),
                                                )
                                   ),

"[Apr 14, Sun]
  Alytis Alytus - Banga Gargzdai  1:1 (0:0). D.Bisigirskas (Jonava). 400.
Goals: 58 M.Sarkelis; 72 A.Staponka.
Sent Off: 53 S.Slusnys (Ban). Booket 17 A.Miniauskas (Aly); 59 A.Staponka, 66 M.Gudauskas, 78 A.Anisimenko (Ban)"
                        =>
                            array ('date' => '1992-04-14',
                                   'homeTeam' => 'Alytis Alytus',   'awayTeam' => 'Banga Gargzdai',
                                   'result' => array ('1', '1'), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'D.Bisigirskas',
                                   'refereeCity' => 'Jonava',
                                   'spectators' => '400',
                                   'goal' => array (
                                                array ('min' => 58, 'name' => 'M.Sarkelis', 'home' => true),
                                                array ('min' => 72, 'name' => 'A.Staponka', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('min' => 17, 'name' => 'A.Miniauskas', 'home' => true),
                                                array ('min' => 59, 'name' => 'A.Staponka', 'home' => false),
                                                array ('min' => 66, 'name' => 'M.Gudauskas', 'home' => false),
                                                array ('min' => 78, 'name' => 'A.Anisimenko', 'home' => false),
                                                ),
                                   'sent' => array (
                                                array ('min' => 53, 'name' => 'S.Slusnys', 'home' => false),
                                                )
                                   ),

"[Apr 14, Sun]
16.00  FBK Kaunas - FC Vilnius  6:0 (0:0). Kaunas SDarius ir SGirenas SK. 2100."
                        =>
                            array ('date' => '1992-04-14 16:00',
                                   'homeTeam' => 'FBK Kaunas',   'awayTeam' => 'FC Vilnius',
                                   'result' => array ('6', '0'), 'resultHalfTime' => array (0, 0),
                                   'stadium' => 'Kaunas SDarius ir SGirenas SK',
                                   'spectators' => '2100',
                                   ),

"[Apr 14, Sun]
16.00  FBK Kaunas - FC Vilnius  6:0 (0:0). Kaunas. S.Darius ir S.Girenas SK. 2100."
                        =>
                            array ('date' => '1992-04-14 16:00',
                                   'homeTeam' => 'FBK Kaunas',   'awayTeam' => 'FC Vilnius',
                                   'result' => array ('6', '0'), 'resultHalfTime' => array (0, 0),
                                   'stadium' => 'Kaunas. S.Darius ir S.Girenas SK',
                                   'spectators' => '2100',
                                   ),

"[Apr 14, Sun]
14.00  Ekranas Panevezys - FK Silute  5:0 (1:0). Panevezys. Aukstaitija"
                        =>
                            array ('date' => '1992-04-14 14:00',
                                   'homeTeam' => 'Ekranas Panevezys',   'awayTeam' => 'FK Silute',
                                   'result' => array ('5', '0'), 'resultHalfTime' => array (1, 0),
                                   'stadium' => 'Panevezys. Aukstaitija',
                                   ),

"[Apr 14, Sun]
14.00  Ekranas Panevezys - FK Silute  5:0 (1:0). Silute. 0"
                        =>
                            array ('date' => '1992-04-14 14:00',
                                   'homeTeam' => 'Ekranas Panevezys',   'awayTeam' => 'FK Silute',
                                   'result' => array ('5', '0'), 'resultHalfTime' => array (1, 0),
                                   'stadium' => 'Silute',
                                   ),

"[Mar 04]
18.00  Ekranas Panevezys - TVMK Tallinn  1:0 (0:0). A.Golubevs (Latvia). Vilnius. Sportima.
Goal: 80 G.Tomkevicius.
EKR: B.Stefanovic, A.Arlauskas (57 L.Rimavicius).
Substitutes: T.Kauneckas, Z.Banys, N.Sasnauskas.
Booket: 16 P.Janusuaskas, 56 A.Arlauskas; 32 A.Borissov, 86 O.Konsa."
                        =>
                            array ('date' => '1992-03-04 18:00',
                                   'homeTeam' => 'Ekranas Panevezys',   'awayTeam' => 'TVMK Tallinn',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array (0, 0),
                                   'stadium' => 'Vilnius. Sportima',
                                   'referee' => 'A.Golubevs',
                                   'refereeCity' => 'Latvia',
                                   'goal' => array (
                                                array ('min' => 80, 'name' => 'G.Tomkevicius', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('min' => 16, 'name' => 'P.Janusuaskas', 'home' => true),
                                                array ('min' => 56, 'name' => 'A.Arlauskas', 'home' => true),
                                                array ('min' => 32, 'name' => 'A.Borissov', 'home' => false),
                                                array ('min' => 86, 'name' => 'O.Konsa', 'home' => false),
                                                ),
                                   'homePlayers' => array (
                                                array ('name' => 'B.Stefanovic', 'from' => 0, 'to' => '90'),
                                                array ('name' => 'A.Arlauskas', 
                                                       'from' => 0, 'to' => '57',
                                                       'substitute' => array ('name' => 'L.Rimavicius','from' => '57', 'to' => 90, )),
                                                array ('name' => 'T.Kauneckas', 'unused' => true,
                                                       'from' => NULL, 'to' => NULL, 'substitute' => NULL),
                                                array ('name' => 'Z.Banys', 'unused' => true,
                                                       'from' => NULL, 'to' => NULL, 'substitute' => NULL),
                                                array ('name' => 'N.Sasnauskas', 'unused' => true,
                                                       'from' => NULL, 'to' => NULL, 'substitute' => NULL),
                                                ),
                                   ),

"[Mar 04]
Leczna - Žalgiris 7:0 (4:0)
g. 7, 26 Nildo
Žal: Marius Rapalis, Algis Jankauskas"
                        =>
                            array ('date' => '1992-03-04',
                                   'homeTeam' => 'Leczna',   'awayTeam' => 'Žalgiris',
                                   'result' => array ('7', '0'), 'resultHalfTime' => array (4, 0),
                                   'goal' => array (
                                                array ('min' => 7, 'name' => 'Nildo', 'home' => true),
                                                array ('min' => 26, 'name' => 'Nildo', 'home' => true),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'Marius Rapalis', 'from' => 0, 'to' => 90),
                                                array ('name' => 'Algis Jankauskas', 'from' => 0, 'to' => 90),
                                                ),
                                   ),

"[Mar 04]
18.00  TVMK Tallinn - Ekranas Panevezys  1:0 (0:0). A.Golubevs (Latvia). Vilnius. Sportima.
Goal: 80 G.Tomkevicius.
EKR: B.Stefanovic, A.Arlauskas (57 L.Rimavicius).
Substitutes: T.Kauneckas, Z.Banys, N.Sasnauskas.
Booket: 16 P.Janusuaskas, 56 A.Arlauskas; 32 A.Borissov, 86 O.Konsa."
                        =>
                            array ('date' => '1992-03-04 18:00',
                                   'homeTeam' => 'TVMK Tallinn',   'awayTeam' => 'Ekranas Panevezys',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array (0, 0),
                                   'stadium' => 'Vilnius. Sportima',
                                   'referee' => 'A.Golubevs',
                                   'refereeCity' => 'Latvia',
                                   'goal' => array (
                                                array ('min' => 80, 'name' => 'G.Tomkevicius', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('min' => 16, 'name' => 'P.Janusuaskas', 'home' => true),
                                                array ('min' => 56, 'name' => 'A.Arlauskas', 'home' => true),
                                                array ('min' => 32, 'name' => 'A.Borissov', 'home' => false),
                                                array ('min' => 86, 'name' => 'O.Konsa', 'home' => false),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'B.Stefanovic', 'from' => 0, 'to' => '90'),
                                                array ('name' => 'A.Arlauskas', 
                                                       'from' => 0, 'to' => '57',
                                                       'substitute' => array ('name' => 'L.Rimavicius','from' => '57', 'to' => 90, )),
                                                array ('name' => 'T.Kauneckas', 'unused' => true,
                                                       'from' => NULL, 'to' => NULL, 'substitute' => NULL),
                                                array ('name' => 'Z.Banys', 'unused' => true,
                                                       'from' => NULL, 'to' => NULL, 'substitute' => NULL),
                                                array ('name' => 'N.Sasnauskas', 'unused' => true,
                                                       'from' => NULL, 'to' => NULL, 'substitute' => NULL),
                                                ),
                                   ),

"[Mar 04]
18.30  Atlantas Klaipeda - Ranga-Politechnika Kaunas 3:1 (1:1). J.Miliauskas (Alytus). Klaipeda Zalgiris. 500.
Atlantas: R.Steckis, R.Maciulevicius, G.Juodeikis, V.Petrenka, M.Zvilauskas.
Ranga-Politechnika: A.Korsakovas, S.Cerniauskas.
Goals: M.Zvilauskas (35), A.Korsakovas (41 p.k.), V.Petrenka (46 p.k.), G.Juodeikis (87).
Booket: R.Steckis, S.Cerniauskas, R.Maciulevicius. "
                        =>
                            array ('date' => '1992-03-04 18:30',
                                   'homeTeam' => 'Atlantas Klaipeda',   'awayTeam' => 'Ranga-Politechnika Kaunas',
                                   'result' => array (3, 1), 'resultHalfTime' => array (1, 1),
                                   'stadium' => 'Klaipeda Zalgiris',
                                   'spectators' => '500',
                                   'referee' => 'J.Miliauskas',
                                   'refereeCity' => 'Alytus',
                                   'goal' => array (
                                                array ('min' => 35, 'name' => 'M.Zvilauskas', 'home' => true),
                                                array ('min' => 41, 'name' => 'A.Korsakovas', 'home' => false, 'pk' => true),
                                                array ('min' => 46, 'name' => 'V.Petrenka', 'home' => true, 'pk' => true),
                                                array ('min' => 87, 'name' => 'G.Juodeikis', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('name' => 'R.Steckis', 'home' => true),
                                                array ('name' => 'S.Cerniauskas', 'home' => false),
                                                array ('name' => 'R.Maciulevicius', 'home' => true),
                                                ),
                                   'homePlayers' => array (
                                                array ('name' => 'R.Steckis', 'from' => 0, 'to' => '90'),
                                                array ('name' => 'R.Maciulevicius', 'from' => 0, 'to' => '90'),
                                                array ('name' => 'G.Juodeikis', 'from' => 0, 'to' => '90'),
                                                array ('name' => 'V.Petrenka', 'from' => 0, 'to' => '90'),
                                                array ('name' => 'M.Zvilauskas', 'from' => 0, 'to' => '90'),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'A.Korsakovas', 'from' => 0, 'to' => '90'),
                                                array ('name' => 'S.Cerniauskas', 'from' => 0, 'to' => '90'),
                                                ),
                                   ),

"[May 4]
Nr. 13 „”Nevėžis-2” (Kėdainiai) – “Lifosa” (Kėdainiai) 1:0 (0:0)
Teisėjas D Vilutis (Kaunas)
Įvarčiai: 65 min. M. Vaitkus
Įspėjimai: N. Malinauskas, A. Lyberis (”Lifosa”)"
                        =>
                            array ('date' => '1992-05-04',
                                   'homeTeam' => 'Nevėžis-2 (Kėdainiai)',   'awayTeam' => 'Lifosa (Kėdainiai)',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'D. Vilutis',
                                   'refereeCity' => 'Kaunas',
                                   'number' => 13,
                                   'goal' => array (
                                                array ('min' => 65, 'name' => 'M. Vaitkus', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('name' => 'N. Malinauskas', 'home' => false),
                                                array ('name' => 'A. Lyberis', 'home' => false),
                                                ),
                                   ),

"[May 4]
Nr. 16 FM-„Spyris“ (Kaunas) – FM-“Granitas” (Vilnius) 1:2 (1:2)
Teisėjas J. Butkus (Ukmergė)
Įvarčiai: 7 min. D. Navičkovas (FM- ”Spyris”);
20, 44 min. R. Tamarinas (FM- ”Granitas”)
Įspėjimai: J. Kurauskas, A. Labanauskas (FM- “Spyris”);
M. Makutinovičius, R. Šuškevič (FM- ”Granitas”)
Pašalinimai: 89 min. už 2-ą įspėjimą A. Labanauskas (FM- ”Spyris”)"
                        =>
                            array ('date' => '1992-05-04',
                                   'homeTeam' => 'FM-Spyris (Kaunas)',   'awayTeam' => 'FM-Granitas (Vilnius)',
                                   'result' => array ('1', '2'), 'resultHalfTime' => array (1, 2),
                                   'referee' => 'J. Butkus',
                                   'refereeCity' => 'Ukmergė',
                                   'number' => 16,
                                   'goal' => array (
                                                array ('min' => 7, 'name' => 'D. Navičkovas', 'home' => true),
                                                array ('min' => 20, 'name' => 'R. Tamarinas', 'home' => false),
                                                array ('min' => 44, 'name' => 'R. Tamarinas', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('name' => 'J. Kurauskas', 'home' => true),
                                                array ('name' => 'A. Labanauskas', 'home' => true),
                                                array ('name' => 'M. Makutinovičius', 'home' => false),
                                                array ('name' => 'R. Šuškevič', 'home' => false),
                                                ),
                                   'sent' => array (
                                                array ('min' => 89, 'name' => 'A. Labanauskas', 'home' => true, "yellow" => true),
                                                ),
                                   ),

"[May 4]
Nr. 21 SC-„Savingė“(Kaišiadorys) – FK-„Prienai“ (Prienai) 5:0 (3:0)
Teisėjas E. Butkievič (Vilnius)
Įvarčiai: 16,37A. Rekus, 23 min. D. Aleknavičius, 54 min.G. Stankevičius,
60 min. neįmušė 11 m. baudinio M. Žigutis, 86 min. J. Dranginis
Įspėjimai: M. Žigutis (SC- „Savingė“);
J. Abraitis (FK- „Prienai“)
Pašalinimai: už 2-ą įspėjimą M. Makštutis (FK- „Prienai“)"
                        =>
                            array ('date' => '1992-05-04',
                                   'homeTeam' => 'SC-Savingė(Kaišiadorys)',   'awayTeam' => 'FK-Prienai (Prienai)',
                                   'result' => array ('5', '0'), 'resultHalfTime' => array (3, 0),
                                   'referee' => 'E. Butkievič',
                                   'refereeCity' => 'Vilnius',
                                   'number' => 21,
                                   'goal' => array (
                                                array ('min' => 16, 'name' => 'A. Rekus', 'home' => true),
                                                array ('min' => 37, 'name' => 'A. Rekus', 'home' => true),
                                                array ('min' => 23, 'name' => 'D. Aleknavičius', 'home' => true),
                                                array ('min' => 54, 'name' => 'G.Stankevičius', 'home' => true),
                                                array ('min' => 86, 'name' => 'J. Dranginis', 'home' => true),
                                                ),
                                   'book' => array (
                                                array ('name' => 'M. Žigutis', 'home' => true),
                                                array ('name' => 'J. Abraitis', 'home' => false),
                                                ),
                                   'miss' => array (
                                                array ('min' => 60, 'name' => 'M. Žigutis', 'home' => true),
                                                ),
                                   'sent' => array (
                                                array ('name' => 'M. Makštutis', 'home' => false, "yellow" => true),
                                                ),
                                   ),

"[May 4]
Nr. 23 „Vidzgiris“ (Alytus) – „Visas Labas“ (Kaunas) 1:2 (1:1)
Teisėjas I. Kovalenko (Jonava)
Įvarčiai: 31 min. S. Neciunskas;
28, 82 min. J. Januševskis, 59 min. neįmušė 11 m. baudinio A. Mančas
Įspėjimai: P. Rimša (FM- „Spyris“)"
                        =>
                            array ('date' => '1992-05-04',
                                   'homeTeam' => 'Vidzgiris (Alytus)',   'awayTeam' => 'Visas Labas (Kaunas)',
                                   'result' => array ('1', '2'), 'resultHalfTime' => array (1, 1),
                                   'referee' => 'I. Kovalenko',
                                   'refereeCity' => 'Jonava',
                                   'number' => 23,
                                   'goal' => array (
                                                array ('min' => 31, 'name' => 'S. Neciunskas', 'home' => true),
                                                array ('min' => 28, 'name' => 'J. Januševskis', 'home' => false),
                                                array ('min' => 82, 'name' => 'J. Januševskis', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('name' => 'P. Rimša'),
                                                ),
                                   'miss' => array (
                                                array ('min' => 59, 'name' => 'A. Mančas', 'home' => false),
                                                ),
                                   ),

"[May 4]

Nr.6 SC-„BALTAI“ (Kaišiadorys) - SC- „SAVINGĖ“ (Kaišiadorys) 0:2 (0:2)
Teisėjas A. Žimaila (Marijampolė)
Įvarčiai: 1 min. J. Dranginis, 45 min. A. Rekus
Įspėjimai: E. Kruglovas ( SC- „Baltai“), A. Ratkevičius (SC- „Savingė“)"
                        =>
                            array ('date' => '1992-05-04',
                                   'homeTeam' => 'SC-BALTAI (Kaišiadorys)',   'awayTeam' => 'SC-SAVINGĖ (Kaišiadorys)',
                                   'result' => array ('0', '2'), 'resultHalfTime' => array (0, 2),
                                   'referee' => 'A. Žimaila',
                                   'refereeCity' => 'Marijampolė',
                                   'number' => 6,
                                   'goal' => array (
                                                array ('min' => 1, 'name' => 'J. Dranginis', 'home' => false),
                                                array ('min' => 45, 'name' => 'A. Rekus', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('name' => 'E. Kruglovas', 'home' => true),
                                                array ('name' => 'A. Ratkevičius', 'home' => false),
                                                ),
                                   ),

"[May 4]

Nr.6 SC-„BALTAI“ (Kaišiadorys) - SC- „SAVINGĖ“ (Kaišiadorys) 0:2 (0:2)
Teisėjas A. Žimaila (Marijampolė)
Įvarčiai: J. Dranginis (1 p.k.), 45 min. A. Rekus
Įspėjimai: E. Kruglovas ( SC- „Baltai“), A. Ratkevičius (SC- „Savingė“)"
                        =>
                            array ('date' => '1992-05-04',
                                   'homeTeam' => 'SC-BALTAI (Kaišiadorys)',   'awayTeam' => 'SC-SAVINGĖ (Kaišiadorys)',
                                   'result' => array ('0', '2'), 'resultHalfTime' => array (0, 2),
                                   'referee' => 'A. Žimaila',
                                   'refereeCity' => 'Marijampolė',
                                   'number' => 6,
                                   'goal' => array (
                                                array ('min' => 1, 'name' => 'J. Dranginis', 'home' => false, "pk" => true),
                                                array ('min' => 45, 'name' => 'A. Rekus', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('name' => 'E. Kruglovas', 'home' => true),
                                                array ('name' => 'A. Ratkevičius', 'home' => false),
                                                ),
                                   ),

"[May 4]
110. „SVEIKATA“(Kybartai) - SC-„BALTAI“(Kaišiadorys) 8:0 (3:0)
Teisėja A. Kancė (Kaunas)
Įvarčiai: 26,28 min. L. Savickas, 42 min. M. Matulaitis, 52 min. G. Čibirka, 55 min. D. Kereiša, 74 min. E. Bernota, 80 min. T. Bielskus („Sveikata“);
61 min. į savo vartus R. Leščius („SC- Baltai“)
Įspėjimai: M. Melsbakas („Sveikata“)"
                        =>
                            array ('date' => '1992-05-04',
                                   'homeTeam' => 'SVEIKATA(Kybartai)',   'awayTeam' => 'SC-BALTAI(Kaišiadorys)',
                                   'result' => array ('8', '0'), 'resultHalfTime' => array (3, 0),
                                   'referee' => 'A. Kancė',
                                   'refereeCity' => 'Kaunas',
                                   'number' => 110,
                                   'goal' => array (
                                                array ('min' => 26, 'name' => 'L. Savickas', 'home' => true),
                                                array ('min' => 28, 'name' => 'L. Savickas', 'home' => true),
                                                array ('min' => 42, 'name' => 'M. Matulaitis', 'home' => true),
                                                array ('min' => 52, 'name' => 'G.Čibirka', 'home' => true),
                                                array ('min' => 55, 'name' => 'D. Kereiša', 'home' => true),
                                                array ('min' => 74, 'name' => 'E. Bernota', 'home' => true),
                                                array ('min' => 80, 'name' => 'T. Bielskus', 'home' => true),
                                                array ('min' => 61, 'name' => 'R. Leščius', 'home' => true, 'og' => true),
                                                ),
                                   'book' => array (
                                                array ('name' => 'M. Melsbakas', 'home' => true),
                                                ),
                                   ),

"[May 4]
39. „LICS-Žygis“ - „Juventa-99“ 1:5 (0:2)
Teisėjas – G. Kuzavas (Plungė), asistentai – D. Norvaišas (Telšiai) ir M. Kasparavičius (Telšiai)
Įvarčiai: 18 min. N. Stonys (0:1), 34 min. G. Čeponkus (0:2), 72 min. M. Dėlkus (0:3), 77 min. P. Bieliauskas (0:4), 88 min. K. Daškus (1:4), 90 min. G. Čeponkus (1:5).
Įspėjimai: T. Budrys („LICS-Žygis“)."
                        =>
                            array ('date' => '1992-05-04',
                                   'homeTeam' => 'LICS-Žygis',   'awayTeam' => 'Juventa-99',
                                   'result' => array ('1', '5'), 'resultHalfTime' => array (0, 2),
                                   'referee' => 'G.Kuzavas',
                                   'refereeCity' => 'Plungė',
                                   'refereeA1' => 'D. Norvaišas',
                                   'refereeA1City' => 'Telšiai',
                                   'refereeA2' => 'M. Kasparavičius',
                                   'refereeA2City' => 'Telšiai',
                                   'number' => 39,
                                   'goal' => array (
                                                array ('min' => 18, 'name' => 'N. Stonys', 'home' => false),
                                                array ('min' => 34, 'name' => 'G.Čeponkus', 'home' => false),
                                                array ('min' => 72, 'name' => 'M. Dėlkus', 'home' => false),
                                                array ('min' => 77, 'name' => 'P. Bieliauskas', 'home' => false),
                                                array ('min' => 88, 'name' => 'K. Daškus', 'home' => true),
                                                array ('min' => 90, 'name' => 'G.Čeponkus', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('name' => 'T. Budrys', 'home' => true),
                                                ),
                                   ),

"[Apr 18]
17.00  Vetra Vilnius - Suduva Marijampole  1:1 (0:0). D.Kancelskis (Siauliai). Vilnius. Zalgiris. 1500.
Goals: 87 S.Litvinas; 90 (pk) T.Radzinevicius.
Vetra: M.Poskus, N.Sasnauskas.
Suduva: A.Ramonas, D.Chigladze.
Booket: 23 Z.Zudys, 32 N.Sasnauskas (Vetra); 27 N.Bestalanniy, 32 G.Slavickas (Suduva)."
                        =>
                            array ('date' => '1992-04-18 17:00',
                                   'homeTeam' => 'Vetra Vilnius',   'awayTeam' => 'Suduva Marijampole',
                                   'result' => array ('1', '1'), 'resultHalfTime' => array (0, 0),
                                   'referee' => 'D.Kancelskis',
                                   'refereeCity' => 'Siauliai',
                                   'stadium' => 'Vilnius. Zalgiris',
                                   'spectators' => '1500',
                                   'goal' => array (
                                                array ('min' => 87, 'name' => 'S.Litvinas', 'home' => true),
                                                array ('min' => 90, 'name' => 'T.Radzinevicius', 'home' => false, 'pk' => true),
                                                ),
                                   'book' => array (
                                                array ('min' => 23, 'name' => 'Z.Zudys', 'home' => true),
                                                array ('min' => 32, 'name' => 'N.Sasnauskas', 'home' => true),
                                                array ('min' => 27, 'name' => 'N.Bestalanniy', 'home' => false),
                                                array ('min' => 32, 'name' => 'G.Slavickas', 'home' => false),
                                                ),
                                   'homePlayers' => array (
                                                array ('name' => 'M.Poskus', 'from' => 0, 'to' => 90),
                                                array ('name' => 'N.Sasnauskas', 'from' => 0, 'to' => 90),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'A.Ramonas', 'from' => 0, 'to' => 90),
                                                array ('name' => 'D.Chigladze', 'from' => 0, 'to' => 90),
                                                ),
                                   ),

"[May 04]
15.00  Atlantas Klaipeda - Zalgiris Vilnius  1:3 (0:1). V.Kazlauskas (Kaunas). Klaipeda. Zalgiris. 3000.
Goals: 38 V.Afanasenko, 55 V.Dancenka, 69 G.Barevicius, 88 G.Barevicius.
Atlantas: V.Dancenka, M.Cepas.
Zalgiris: V.Afanasenko, G.Barevicius.
"
                        =>
                            array ('date' => '1992-05-04 15:00',
                                   'homeTeam' => 'Atlantas Klaipeda',   'awayTeam' => 'Zalgiris Vilnius',
                                   'result' => array ('1', '3'), 'resultHalfTime' => array (0, 1),
                                   'referee' => 'V.Kazlauskas',
                                   'refereeCity' => 'Kaunas',
                                   'stadium' => 'Klaipeda. Zalgiris',
                                   'spectators' => '3000',
                                   'goal' => array (
                                                array ('min' => 38, 'name' => 'V.Afanasenko', 'home' => false),
                                                array ('min' => 55, 'name' => 'V.Dancenka', 'home' => true),
                                                array ('min' => 69, 'name' => 'G.Barevicius', 'home' => false),
                                                array ('min' => 88, 'name' => 'G.Barevicius', 'home' => false),
                                                ),
                                   'homePlayers' => array (
                                                array ('name' => 'V.Dancenka', 'from' => 0, 'to' => 90),
                                                array ('name' => 'M.Cepas', 'from' => 0, 'to' => 90),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'V.Afanasenko', 'from' => 0, 'to' => 90),
                                                array ('name' => 'G.Barevicius', 'from' => 0, 'to' => 90),
                                                ),
                                   ),

"05 Jun 2004
18.00  Gelezinis Vilkas Vilnius - Zalgiris Vilnius  2:1 (1:1). P.Malzinskas (Vilnius). 80. Goals: 4 D.Vasilkovas, 47 V.Miknevicius; 25 V.Kauspadas. Booket: 51 A.Joksas (Zal). 1st game - 0:3.
"
                        =>
                            array ('date' => '2004-06-05 18:00',
                                   'homeTeam' => 'Gelezinis Vilkas Vilnius',   'awayTeam' => 'Zalgiris Vilnius',
                                   'result' => array ('2', '1'), 'resultHalfTime' => array (1, 1),
                                   'referee' => 'P.Malzinskas',
                                   'refereeCity' => 'Vilnius',
                                   'spectators' => '80',
                                   'goal' => array (
                                                array ('min' => 4, 'name' => 'D.Vasilkovas', 'home' => true),
                                                array ('min' => 47, 'name' => 'V.Miknevicius', 'home' => true),
                                                array ('min' => 25, 'name' => 'V.Kauspadas', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('min' => 51, 'name' => 'A.Joksas', 'home' => false),
                                                ),
                                   ),

"05 Jun 2001
18.00  Kratonas Kalvarija - Senjorai Vilnius  0:0. Kalvarija. 150. L.Svetkauskas (Alytus).
Booket: G.Geraldauskas (Kro); V.Rudzianecas, I.Pankratjevas, G.Paberzis (Sen)."
                        =>
                            array ('date' => '2001-06-05 18:00',
                                   'homeTeam' => 'Kratonas Kalvarija',   'awayTeam' => 'Senjorai Vilnius',
                                   'result' => array ('0', '0'),
                                   'referee' => 'L.Svetkauskas',
                                   'refereeCity' => 'Alytus',
                                   'stadium' => 'Kalvarija',
                                   'spectators' => '150',
                                   'book' => array (
                                                array ('name' => 'G.Geraldauskas', 'home' => true),
                                                array ('name' => 'V.Rudzianecas', 'home' => false),
                                                array ('name' => 'I.Pankratjevas', 'home' => false),
                                                array ('name' => 'G.Paberzis', 'home' => false),
                                                ),
                                   ),

"05 Jun 2001
17.00  Sirvena Birzai - Delintra Lentvaris  2:2 (0:0) aet. 2:4 (pk). Birzai. 100. S.Vilniskis (Panevezys)."
                        =>
                            array ('date' => '2001-06-05 17:00',
                                   'homeTeam' => 'Sirvena Birzai',   'awayTeam' => 'Delintra Lentvaris',
                                   'result' => array (2, 2), 'resultHalfTime' => array (0, 0),
                                   'resultET' => array (2, 2), 'resultPenalty' => array ('2', '4'),
                                   'c_outcome' => MatchConstants::OUTCOME_PENALTIES_AWAY,
                                   'referee' => 'S.Vilniskis',
                                   'refereeCity' => 'Panevezys',
                                   'stadium' => 'Birzai',
                                   'spectators' => '100',
                                   ),

"18 Mar 2000
13.00  Interas Visaginas - Atletas-Inkaras Kaunas  2:4 (0:0, 0:0). Visaginas. II ground. 300. D.Miezelis (Vilnius)
b. G.Sukstulis, A.Margevicius, A.Daraskevicius (Int); Z.Rasinskas, T.Rimas (Ink).
so: 44 A.Daraskevicius (Int)."
                        =>
                            array ('date' => '2000-03-18 13:00',
                                   'homeTeam' => 'Interas Visaginas',   'awayTeam' => 'Atletas-Inkaras Kaunas',
                                   'resultET' => array (2, 4), 'resultHalfTime' => array (0, 0),
                                   'result' => array (0, 0),
                                   'referee' => 'D.Miezelis',
                                   'refereeCity' => 'Vilnius',
                                   'stadium' => 'Visaginas. II ground',
                                   'spectators' => '300',
                                   'book' => array (
                                                array ('name' => 'G.Sukstulis', 'home' => true),
                                                array ('name' => 'A.Margevicius', 'home' => true),
                                                array ('name' => 'A.Daraskevicius', 'home' => true),
                                                array ('name' => 'Z.Rasinskas', 'home' => false),
                                                array ('name' => 'T.Rimas', 'home' => false),
                                                ),
                                   'sent' => array (
                                                array ('min' => 44, 'name' => 'A.Daraskevicius', 'home' => true),
                                                ),
                                   ),

"1. Kruoja (Pakruojis) – Šiauliai (Šiauliai) 0:2 (0:1)
Teisėjas: D.Rumšas (Palanga), 80 žiūrovų
Įvarčiai: 44 min. J.Kuizinas, 56 min. D.Tomašauskas („Kruoja“ į savo vartus) („Šiauliai“)
Įspėjimai: 39 min. R.Kliukoitis („Kruoja“); 47 min. R.Urbelis („Šiauliai“)"
                        =>
                            array ('date' => '1992',
                                   'homeTeam' => 'Kruoja (Pakruojis)',   'awayTeam' => 'Šiauliai (Šiauliai)',
                                   'resultHalfTime' => array (0, 1),
                                   'result' => array (0, 2),
                                   'referee' => 'D.Rumšas',
                                   'refereeCity' => 'Palanga',
                                   'spectators' => '80',
                                   'number' => 1,
                                   'goal' => array (
                                                array ('min' => 44, 'name' => 'J.Kuizinas', 'home' => false),
                                                array ('min' => 56, 'name' => 'D.Tomašauskas', 'home' => false, 'og' => true),
                                                ),
                                   'book' => array (
                                                array ('min' => 39, 'name' => 'R.Kliukoitis', 'home' => true),
                                                array ('min' => 47, 'name' => 'R.Urbelis', 'home' => false),
                                                ),
                                   ),

"56. Minija (Kretinga) - U-19 rinktinė 2:1 (1:1)
Teisėjas: A.Mazalas (Klaipėda), 400 žiūrovų
Įvarčiai: 36 min. ir 63 min. N.Kosmakovas („Minija“); 16 min. T.Dapkus (U-19)
Įspėjimai: 19 min. A.Piekus, 42 min. Mantas Mažionis („Minija“); 48 min. T.Dapkus, 56 min. E.Razonas, 79 min. K.Laukžemis (U-19)
Pašalinimai: 45+1 min. Mantas Mažionis (už 2-ą geltoną) („Minija“); 87 min. T.Dapkus (už 2-ą geltoną) (U-19)"
                        =>
                            array ('date' => '1992',
                                   'homeTeam' => 'Minija (Kretinga)',   'awayTeam' => 'U-19 rinktinė',
                                   'resultHalfTime' => array (1, 1),
                                   'result' => array (2, 1),
                                   'referee' => 'A.Mazalas',
                                   'refereeCity' => 'Klaipėda',
                                   'spectators' => '400',
                                   'number' => 56,
                                   'goal' => array (
                                                array ('min' => 36, 'name' => 'N.Kosmakovas', 'home' => true),
                                                array ('min' => 63, 'name' => 'N.Kosmakovas', 'home' => true),
                                                array ('min' => 16, 'name' => 'T.Dapkus', 'home' => false),
                                                ),
                                   'book' => array (
                                                array ('min' => 19, 'name' => 'A.Piekus', 'home' => true),
                                                array ('min' => 42, 'name' => 'Mantas Mažionis', 'home' => true),
                                                array ('min' => 48, 'name' => 'T.Dapkus', 'home' => false),
                                                array ('min' => 56, 'name' => 'E.Razonas', 'home' => false),
                                                array ('min' => 79, 'name' => 'K.Laukžemis', 'home' => false),
                                                ),
                                   'sent' => array (
                                                array ('min' => 45, 'name' => 'Mantas Mažionis', 'home' => true, 'extra' => 1, 'yellow' => true),
                                                array ('min' => 87, 'name' => 'T.Dapkus', 'home' => false, 'yellow' => true),
                                                ),
                                   ),

"18 Mar 2000
13.00  Tauras Taurage - Kareda Kaunas  1:4 (0:1).  100. A.Rubys (Telsiai)."
                        =>
                            array ('date' => '2000-03-18 13:00',
                                   'homeTeam' => 'Tauras Taurage',   'awayTeam' => 'Kareda Kaunas',
                                   'result' => array (1, 4), 'resultHalfTime' => array (0, 1),
                                   'referee' => 'A.Rubys',
                                   'refereeCity' => 'Telsiai',
                                   'spectators' => '100',
                                   ),

"18 Mar 2000
13.30  Kauno Jegeriai - Laisve Silute  3:0. A.Jakubovskis (Vilnius). 20. w/o game."
                        =>
                            array ('date' => '2000-03-18 13:30',
                                   'homeTeam' => 'Kauno Jegeriai',   'awayTeam' => 'Laisve Silute',
                                   'result' => array (3, 0),
                                   'referee' => 'A.Jakubovskis',
                                   'refereeCity' => 'Vilnius',
                                   'spectators' => '20',
                                   'c_outcome' => MatchConstants::OUTCOME_TECHNICAL_WIN,
                                   ),

"18 Mar 2000
17.30  Nevezis-2 Kedainiai - Interas Visaginas  3:0.   (Result 1-2 annuled)"
                        =>
                            array ('date' => '2000-03-18 17:30',
                                   'homeTeam' => 'Nevezis-2 Kedainiai',   'awayTeam' => 'Interas Visaginas',
                                   'result' => array (3, 0),
                                   'c_outcome' => MatchConstants::OUTCOME_TECHNICAL_WIN,
                                   ),

"18 Mar 2000
16.00  Atletas Kaunas - Vetra Rudiskes  0:1 (0:0). 20."
                        =>
                            array ('date' => '2000-03-18 16:00',
                                   'homeTeam' => 'Atletas Kaunas',   'awayTeam' => 'Vetra Rudiskes',
                                   'result' => array (0, 1), 'resultHalfTime' => array (0, 0),
                                   'spectators' => '20',
                                   ),

"18 Mar 2000
16.00  Vetra Rudiskes - Babrungas Plunge  3:0.  (w/o game)."
                        =>
                            array ('date' => '2000-03-18 16:00',
                                   'homeTeam' => 'Vetra Rudiskes',   'awayTeam' => 'Babrungas Plunge',
                                   'result' => array (3, 0),
                                   'c_outcome' => MatchConstants::OUTCOME_TECHNICAL_WIN,
                                   ),

"SOOME – EESTI 6:0

Peakohtunik: Kaarlo Soinio (Soome)
Pealtvaatajaid: 3000
Väravad: 5. Öhman, 10., 68. Eklöf, 15. Österholm, 42., 80. Tanner
 
Eesti koondis:
Rudolf Paal
Karl Ree (46. Raimond Põder)
Oskar Üpraus

Treener: puudus
 
Soome koondis:
Jari Österholm
Lauri Tanner
Verner Eklöf
Gunnar Öhman

Treener: puudus"
                        =>
                            array ('date' => '1992',
                                   'homeTeam' => 'SOOME',   'awayTeam' => 'EESTI',
                                   'result' => array ('6', '0'),
                                   'referee' => 'Kaarlo Soinio',
                                   'refereeCity' => 'Soome',
                                   'spectators' => '3000',
                                   'goal' => array (
                                                array ('min' => 5, 'name' => 'Öhman', 'home' => true),
                                                array ('min' => 10, 'name' => 'Eklöf', 'home' => true),
                                                array ('min' => 68, 'name' => 'Eklöf', 'home' => true),
                                                array ('min' => 15, 'name' => 'Österholm', 'home' => true),
                                                array ('min' => 42, 'name' => 'Tanner', 'home' => true),
                                                array ('min' => 80, 'name' => 'Tanner', 'home' => true),
                                                ),
                                   'homePlayers' => array (
                                                array ('name' => 'Jari Österholm', 'from' => 0, 'to' => 90),
                                                array ('name' => 'Lauri Tanner', 'from' => 0, 'to' => 90),
                                                array ('name' => 'Verner Eklöf', 'from' => 0, 'to' => 90),
                                                array ('name' => 'Gunnar Öhman', 'from' => 0, 'to' => 90),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'Rudolf Paal', 'from' => 0, 'to' => 90),
                                                array ('name' => 'Karl Ree', 'from' => 0, 'to' => 46, 'substitute' =>
                                                    array ('name' => 'Raimond Põder','from' => 46, 'to' => 90, )),
                                                array ('name' => 'Oskar Üpraus', 'from' => 0, 'to' => 90),
                                                ),
                                   ),

"EESTI – ROOTSI 6:0

Peakohtunik: Kaarlo Soinio (Soome)
Pealtvaatajaid: 5000
Väravad: -
 
Eesti koondis:
Rudolf Paal
Eduard Ellman-Eelma

Treener: puudus
 
Rootsi koondis:
John Björkström
Ísidor Carlsson

Treener: puudus"
                        =>
                            array ('date' => '1992',
                                   'homeTeam' => 'EESTI',   'awayTeam' => 'ROOTSI',
                                   'result' => array ('6', '0'),
                                   'referee' => 'Kaarlo Soinio',
                                   'refereeCity' => 'Soome',
                                   'spectators' => '5000',
                                   'homePlayers' => array (
                                                array ('name' => 'Rudolf Paal', 'from' => 0, 'to' => 90),
                                                array ('name' => 'Eduard Ellman-Eelma', 'from' => 0, 'to' => 90),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'John Björkström', 'from' => 0, 'to' => 90),
                                                array ('name' => 'Ísidor Carlsson', 'from' => 0, 'to' => 90),
                                                ),
                                   ),

            );

        return $tests;
        }

        
        
        
        
        
        
    public function getNationalParserTestCases ()
        {
        $tests = array (
"26.09.2001. 14:00. Kaunas. S.Darius ir S.Girenas SC. Att. 0. Rf. Sokol JARECI (Albania).
LITHUANIA - RUSSIA  1:0 (1:0).
Goal: 90' (pk) Vitalijus KAVALIAUSKAS."
                        =>
                            array ('date' => '2001-09-26 14:00',
                                   'homeTeam' => 'LITHUANIA',   'awayTeam' => 'RUSSIA',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array ('1', '0'),
                                   'referee' => 'Sokol JARECI',
                                   'refereeCity' => 'Albania',
                                   'spectators' => '0',
                                   'stadium' => 'Kaunas. S.Darius ir S.Girenas SC',
                                   'goal' => array (
                                                array ('min' => 90, 'name' => 'Vitalijus KAVALIAUSKAS', 'home' => true, 'pk' => true),
                                                ),
                                   ),

"26 September 2001, 14:00. Kaunas. S.Darius ir S.Girenas SC. Rf. Sokol JARECI (Albania).
LITHUANIA - RUSSIA  1:0 (1:0).
Goal: 90' (pk) Vitalijus KAVALIAUSKAS."
                        =>
                            array ('date' => '2001-09-26 14:00',
                                   'homeTeam' => 'LITHUANIA',   'awayTeam' => 'RUSSIA',
                                   'result' => array ('1', '0'), 'resultHalfTime' => array ('1', '0'),
                                   'referee' => 'Sokol JARECI',
                                   'refereeCity' => 'Albania',
                                   'stadium' => 'Kaunas. S.Darius ir S.Girenas SC',
                                   'goal' => array (
                                                array ('min' => 90, 'name' => 'Vitalijus KAVALIAUSKAS', 'home' => true, 'pk' => true),
                                                ),
                                   ),

"12 October 2002, 14:00. Vilnius. Zalgiris. David MALCOLM (N.Ireland).
LITHUANIA - SLOVAKIA  1:3 (0:2).
Goals: ?"
                        =>
                            array ('date' => '2002-10-12 14:00',
                                   'homeTeam' => 'LITHUANIA',   'awayTeam' => 'SLOVAKIA',
                                   'result' => array ('1', '3'), 'resultHalfTime' => array ('0', '2'),
                                   'referee' => 'David MALCOLM',
                                   'refereeCity' => 'N.Ireland',
                                   'stadium' => 'Vilnius. Zalgiris',
                                   'goal' => array (
                                                ),
                                   ),

"18 September 2003, 18:30. Fiorentino. Adrian D. CASHA (Malta).
LITHUANIA - SAN MARINO  1:1 (1:0).
Goals: ?"
                        =>
                            array ('date' => '2003-09-18 18:30',
                                   'homeTeam' => 'LITHUANIA',   'awayTeam' => 'SAN MARINO',
                                   'result' => array ('1', '1'), 'resultHalfTime' => array ('1', '0'),
                                   'referee' => 'Adrian D. CASHA',
                                   'refereeCity' => 'Malta',
                                   'stadium' => 'Fiorentino',
                                   'goal' => array (
                                                ),
                                   ),

"15 July 2008, Tuesday, 20:30. Andorra La Vella. Estadi Comunal. Att. ?. Rf. Panayiotis KAILIS (Cyprus).
DON PERNIL SANTA COLOMA (Andorra) - FBK KAUNAS (Lithuania)  1:4 (0:3).
Goals: 58' (pk) Jose ALVAREZ; 12' Linas PILIBAITIS, 28' Rafael LEDESMA, 41' (pk) Linas PILIBAITIS, 79' Rafael LEDESMA.
Missed pk 33' Julia FERNANDEZ.
SANTA COLOMA: 1-Ricardo Fernandez LIZARTE, 2-Julia FERNANDEZ, 3-Jose ALVAREZ.
Coach: Vicens MARQUES. Substitutes: 25-Salim TAA, 14-Narc CALULL.
KAUNAS:  3-Adrian MROWIEC, 7-Linas PILIBAITIS, 11-Rafael Rodrigues LEDESMA.
Coach: Arturas RAMOSKA. Substitutes: 12-Esteban Javier DREER.
Booket: 56' Mariano URBANI; 58' Adrian MROWIEC."
                        =>
                            array ('date' => '2008-07-15 20:30',
                                   'homeTeam' => 'DON PERNIL SANTA COLOMA (Andorra)',   'awayTeam' => 'FBK KAUNAS (Lithuania)',
                                   'result' => array ('1', '4'), 'resultHalfTime' => array ('0', '3'),
                                   'referee' => 'Panayiotis KAILIS',
                                   'refereeCity' => 'Cyprus',
                                   'stadium' => 'Andorra La Vella. Estadi Comunal',
                                   'goal' => array (
                                                array ('min' => 58, 'name' => 'Jose ALVAREZ', 'home' => true, 'pk' => true),
                                                array ('min' => 12, 'name' => 'Linas PILIBAITIS', 'home' => false),
                                                array ('min' => 28, 'name' => 'Rafael LEDESMA', 'home' =>  false),
                                                array ('min' => 41, 'name' => 'Linas PILIBAITIS', 'home' => false, 'pk' => true),
                                                array ('min' => 79, 'name' => 'Rafael LEDESMA', 'home' =>  false),
                                                ),
                                   'homeCoach' => 'Vicens MARQUES',
                                   'awayCoach' => 'Arturas RAMOSKA',
                                   'book' => array (
                                                array ('min' => 56, 'name' => 'Mariano URBANI', 'home' => true),
                                                array ('min' => 58, 'name' => 'Adrian MROWIEC', 'home' => false),
                                                ),
                                   'miss' => array (
                                                array ('min' => 33, 'name' => 'Julia FERNANDEZ', 'home' => true),
                                                ),
                                   'homePlayers' => array (
                                                array ('name' => 'Ricardo Fernandez LIZARTE', 'from' => 0, 'to' => 90, 'no' => 1),
                                                array ('name' => 'Julia FERNANDEZ', 'from' => 0, 'to' => 90, 'no' => 2),
                                                array ('name' => 'Jose ALVAREZ', 'from' => 0, 'to' => 90, 'no' => 3),
                                                array ('name' => 'Salim TAA', 'unused' => true, 'no' => 25, 'from' => NULL, 'to' => NULL, 'substitute' => NULL),
                                                array ('name' => 'Narc CALULL', 'unused' => true, 'no' => 14, 'from' => NULL, 'to' => NULL, 'substitute' => NULL),
                                                ),
                                   'awayPlayers' => array (
                                                array ('name' => 'Adrian MROWIEC', 'from' => 0, 'to' => 90, 'no' => 3),
                                                array ('name' => 'Linas PILIBAITIS', 'from' => 0, 'to' => 90, 'no' => 7),
                                                array ('name' => 'Rafael Rodrigues LEDESMA', 'from' => 0, 'to' => 90, 'no' => 11),
                                                array ('name' => 'Esteban Javier DREER', 'unused' => true, 'no' => 12, 'from' => NULL, 'to' => NULL, 'substitute' => NULL),
                                                ),
                                   ),
            );

        return $tests;
        }

    function jsonEncodedToArray ($d)
        {
        $d = json_decode ($d);
        return $this->objectToArray ($d);
        }

    function objectToArray ($obj)
        {
        if (is_object($obj))
            $obj = get_object_vars($obj);

        if (is_array ($obj))
            {
            $ret = array ();
            foreach ($obj as $key => $val)
                {
                $ret[$key] = $this->objectToArray ($val);
                }

            return $ret;
            }
        else
            {
            // Return array
            return $obj;
            }
        }

    }

class SubmitGameWrapper extends SubmitGame
    {
    public function testParsePlayer ($context, $input)
        {
        return $this->parsePlayer ($input, NULL);
        }

    public function testSimpleMatch ($context, $input)
        {
        return $this->testExtendedMatch ($context, $input);
        }

    public function testExtendedMatch ($context, $input)
        {
        $matches = $this->collectMatches (1992, $input, NULL);
        if (empty ($matches))
            return $matches;
        $match = array_shift ($matches);
        return $match;
        }

    public function testNationalMatch ($context, $input)
        {
        $matches = $this->collectNational1940Matches (1992, $input);
        if (false === $matches)
            return false;
        $match = array_pop ($matches);
        return $match;
        }
    }

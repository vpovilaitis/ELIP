<?php
require_once (PATH.'inc/sports/constants.php');
require_once (PATH.'inc/sports/predictortable.php');
require_once (PATH.'pages/sports/generatematchannouncement.php');

class PredictorMaintenance extends Page
    {
    protected $dbtable;
    
    public function __construct ($context, $request)
        {
        $this->dbtable = new PredictorGameTable ($context);
        parent::__construct ($context, NULL, PredictorGameTable::TABLE_SCOPE, PredictorGameTable::TABLE_NAME);
        }

    protected function checkAccess ($request)
        {
        if (!empty ($this->dbtable))
            return $this->dbtable->canCreate ();
        return true;
        }

    public function getSubTitle ()
        {
        return NULL;
        }

    public function processInput ($context, &$request)
        {
        $maxRecords = empty ($request["maxrecords"]) ? 2 : $request["maxrecords"];
        $totalAffected = false;
        switch (!empty ($request["action"]) ? $request["action"] : "")
            {
            default:
                $maxDays = empty ($request["days"]) ? 3 : $request["days"];
                $totalAffected = $this->createForUpcommingMatches ($context, $request, $maxRecords, $maxDays);
                break;
            }

        if ($totalAffected == $maxRecords && !empty ($request["nonstop"]))
            {
            $context->setMetaParam ("refresh", $request["nonstop"]);
            }
        return true;
        }

    // this function is used by sports/PredictorAnnounce (with competitions param)
    public static function collectNearestGames ($context, $maxDays, $competitionIds = NULL)
        {
        $seasonsTable = new PredictorSeasonTable ($context);
        $matchesTable = ContentTable::createInstanceByName ($context, Sports::TABLE_MATCH);

        $columns = array (PredictorSeasonTable::COL_ID, PredictorSeasonTable::COL_SEASON);
        if (empty ($competitionIds))
            {
            $criteria[] = new GtCriterion (PredictorSeasonTable::COL_END_DATE, date ("Y-m-d G:i:s"));
            }
        else
            {
            $criteria[] = new InCriterion (PredictorSeasonTable::COL_SEASON, $competitionIds);
            }

        $params = NULL;
        $rows = $seasonsTable->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rows))
            return $rows;
        $seasons = array ();
        foreach ($rows as $row)
            {
            $seasons[$row[PredictorSeasonTable::COL_SEASON]] = $row[PredictorSeasonTable::COL_ID];
            }

        $seasonIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_COMPETITION, Sports::TABLE_COMPETITIONSTAGE."_id");
        $hometeamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_HOMETEAM, Sports::TABLE_TEAM."_id");
        $awayteamIdColumn = ContentTable::generateForeignKeyColumn (Sports::COL_MATCH_AWAYTEAM, Sports::TABLE_TEAM."_id");
        $columns = array ($matchesTable->getIdColumn (), $seasonIdColumn, $hometeamIdColumn, $awayteamIdColumn, Sports::COL_MATCH_HOMERESULT);
        $criteria = array (new InCriterion ($seasonIdColumn, array_keys ($seasons)));
        $criteria[] = new GtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d G:i:s", time() - 20 * 60 * 60 /* create announcement next day after the last team match*/));
        $criteria[] = new LtCriterion ("c_".Sports::COL_MATCH_DATE, date ("Y-m-d G:i:s", time() + $maxDays * 24 * 60 * 60));
        $params = array (OrderBy::createByAlias ("c_".Sports::COL_MATCH_DATE));
        $rows = $matchesTable->selectBy ($columns, $criteria, NULL, $params);
        if (empty ($rows))
            return $rows;

        $includedTeams = array ();
        $upcommimgMatches = array ();
        foreach ($rows as $row)
            {
            if (NULL !== $row["c_".Sports::COL_MATCH_HOMERESULT])
                continue; // result already entered, skip this

            // make sure we create announcements only for the single match of any given team
            $skip = in_array ($row[$hometeamIdColumn], $includedTeams) || in_array ($row[$awayteamIdColumn], $includedTeams);

            $includedTeams[] = $row[$hometeamIdColumn];
            $includedTeams[] = $row[$awayteamIdColumn];

            if ($skip)
                continue;

            $season = $seasons[$row[$seasonIdColumn]];
            $upcommimgMatches[$row[$matchesTable->getIdColumn ()]] = $season;
            }

        return $upcommimgMatches;
        }

    protected function collectGamesNotInPredictor ($context, $upcommimgMatches)
        {
        $columns = array (PredictorGameTable::COL_ID, PredictorGameTable::COL_MATCH_ID);
        $criteria[] = new InCriterion (PredictorGameTable::COL_MATCH_ID, $upcommimgMatches);
        $rows = $this->dbtable->selectBy ($columns, $criteria);
        if (false === $rows)
            return false;

        if (empty ($rows))
            return $upcommimgMatches;
        
        $includedMatches = array ();
        foreach ($rows as $row)
            $includedMatches[] = $row[PredictorGameTable::COL_MATCH_ID];
        return array_diff ($upcommimgMatches, $includedMatches);
        }

    protected function createForUpcommingMatches ($context, $request, $maxRecords, $maxDays)
        {
        $upcommimgMatches = $this->collectNearestGames ($context, $maxDays);
        if (empty ($upcommimgMatches))
            {
            echo false === $upcommimgMatches ? "Error" : $this->getText ("Nothing to update");
            return false;
            }

        $matchesToUpdate = $this->collectGamesNotInPredictor ($context, array_keys ($upcommimgMatches));
        if (empty ($matchesToUpdate))
            {
            echo false === $matchesToUpdate ? "Error" : $this->getText ("Nothing to update");
            return false;
            }

        echo "Found ".count ($matchesToUpdate)." upcomming games to update (in next $maxDays days)";
        $totalAffected = 0;

        for ($i = 0; $i < $maxRecords && !empty ($matchesToUpdate); $i++)
            {
            $matchId = array_shift ($matchesToUpdate);
            $processor = new GenerateMatchAnnouncement ($context, $request);
            $processor->generateAnnouncementForMatch ($context, $matchId, false, false, false, 20, false);
            $text = $processor->getResultOutput (false);

            $namesToValues = array ();
            $namesToValues[PredictorGameTable::COL_ANNOUNCEMENT_TEXT] = $text;
            $namesToValues[PredictorGameTable::COL_SEASON_ID] = $upcommimgMatches[$matchId];
            $namesToValues[PredictorGameTable::COL_MATCH_ID] = $matchId;

            echo "<br>Updating next match announcement";
            if (false === $this->dbtable->insertRecord ($namesToValues))
                return false;

            $totalAffected++;
            }

        echo "<br>";
        echo $this->ngettext ("Updated [_0] record", "Updated [_0] records", $totalAffected);
        return $totalAffected;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "dynamicpage";
        }

    public function getActionList ()
        {
        return NULL;
        }
    }

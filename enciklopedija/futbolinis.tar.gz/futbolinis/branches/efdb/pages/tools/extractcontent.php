<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'h/othernamestable.php');

class ExtractContent extends Page
    {
    protected $extractedTable;
    
    public function __construct ($context, $request)
        {
        $this->extractedTable = new ExtractedContentTable ($context);
        $this->statusTable = new ExtractionStatusTable ($context);
        parent::__construct ($context, $context->getText ("Extracting content for search index"), ExtractedContentTable::TABLE_SCOPE, ExtractedContentTable::TABLE_NAME);
        
        }

    protected function checkAccess ($request)
        {
        return $this->extractedTable->canEdit () && $this->statusTable->canEdit ();
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        $scope = empty ($request["scope"]) ? NULL : $request["scope"];
        $limit = empty ($request["max"]) ? 50 : $request["max"];
        $statusText = array ();

        switch ($scope)
            {
            case "pages";
                break;
            case "news";
                break;

            default:
                $dbtable = ContentTable::createInstanceByName ($context, $scope);
                if (empty ($dbtable))
                    {
                    $this->addError ("Specified table '[_0]' does not exist", empty ($scope) ? "" : $scope);
                    return true;
                    }

                $this->extractFromContentTable ($dbtable, $limit, $statusText);
                break;
            }

        if (empty ($statusText))
            return true;

        $this->addComponent ($request, "", new TextComponent ("", $context, implode ("<br>", $statusText)));
        return true;
        }

    protected function extractFromContentTable ($dbtable, $limit, &$statusText)
        {
        $scope = HintsTable::SCOPE_CONTENTTABLE.$dbtable->getName ();
        $lastChecked = $this->statusTable->selectLastSyncTime ($scope);
        if (false === $lastChecked)
            return false;

        if (!empty ($lastChecked))
            list ($lastChecked, $nextChunk) = $lastChecked;
        else
            $nextChunk = 0;

        $statusText[] = "Preparing table for extraction - ".($lastChecked ? "resuming from $lastChecked : $nextChunk" : "first run");
        $rows = $dbtable->selectChangedRowsForIndexing ($lastChecked, $nextChunk, $limit);
        if (empty ($rows))
            return false !== $rows;

        $ids = array ();
        $lastUpdated = $lastChecked;
        $indexColumns = $dbtable->getPrimaryIndexColumns ();
        foreach ($rows as $row)
            {
            $id = array ();
            foreach ($indexColumns as $col)
                $id[] = $row[$col->name];
            $id = 1 == count ($id) ? $id[0] : $id;
            $ids[] = $id;
            if ($lastUpdated == $row[DBTable::COL_UPDATEDON])
                $nextChunk++;
            else
                {
                $lastUpdated = $row[DBTable::COL_UPDATEDON];
                $nextChunk = 1;
                }
            }

        $texts = $dbtable->extractTextsForIndex ($ids);
        if (false === $texts)
            return false;

        if (!$this->statusTable->updateLastSyncTime ($scope, $lastUpdated, $nextChunk))
            {
            $this->addError ("could not update last sync time");
            return false;
            }

        if (!empty ($texts))
            {
            foreach ($texts as $id => $row)
                {
                $description = empty ($row['description']) ? NULL : $row['description'];
                $entryLastUpdated = empty ($row['date']) ? NULL : $row['date'];
                $indexedLabel = empty ($row['indexedLabel']) ? NULL : $row['indexedLabel'];
                $extractedText = empty ($row['chunks']) ? NULL : implode (" ", $row['chunks']);
                $imageid = empty ($row['image']) ? NULL : $row['image'];
                
                if (!$this->extractedTable->updateEntry ($scope, $id, $row['label'], $description, $entryLastUpdated, $indexedLabel, $extractedText, $imageid))
                    {
                    $statusText[] = "Error updating entry $id";
                    $this->addError ("Could not update entry [_1] from table [_0]", $scope, $id);
                    }
                else
                    $statusText[] = "Updated entry $id ({$row['label']} - $description)";
                }

            $deleted = array_diff ($ids, array_keys ($texts));
            }
        else
            $deleted = $ids;

        if (!empty ($deleted))
            {
            $criteria = array (new EqCriterion (ExtractedContentTable::COL_SCOPE, $scope));
            $criteria[] = new InCriterion (ExtractedContentTable::COL_ENTRYID, $deleted);
            $rows = $this->extractedTable->selectBy (array (ExtractedContentTable::COL_ENTRYID, ExtractedContentTable::COL_LABEL), $criteria);
            if (!empty ($rows))
                {
                foreach ($rows as $row)
                    {
                    $id = $row[ExtractedContentTable::COL_ENTRYID];
                    if (!$this->extractedTable->deleteEntry ($scope, $id))
                        {
                        $statusText[] = "Error deleting entry $id";
                        $this->addError ("Could not delete entry [_1] from table [_0]", $scope, $id);
                        }
                    else
                        $statusText[] = "Deleted entry $id (".$row[ExtractedContentTable::COL_LABEL].")";
                    }
                }
            }

        return true;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "dynamicpage";
        }

    public function getActionList ()
        {
        return NULL;
        }

    public function getSubTitle ()
        {
        return NULL;
        }

    }

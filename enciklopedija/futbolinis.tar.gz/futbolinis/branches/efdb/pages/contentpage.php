<?php
require_once (PATH.'inc/page.php');
require_once (PATH.'inc/contenttable.php');
require_once (PATH.'pages/contenteditor.php');
require_once (PATH.'pages/contentview.php');
require_once (PATH.'pages/contenthistory.php');
require_once (PATH.'pages/sectionhistory.php');
require_once (PATH.'pages/contentlocator.php');

class ContentPage extends Page
    {
    protected $mode;
    protected $component;

    public function __construct ($context, $request)
        {
        $table = 0;
        if (isset ($request["tid"]))
            sscanf ($request["tid"], "%d", $table);

        $this->mode = isset ($request["mode"]) ? $request["mode"] : Constants::MODE_EDIT;

        if (Constants::MODE_EDIT == $this->mode)
            {
            $context->setMenuHidden (true);
            }

        if ($table > 0)
            {
            $context->log ("Displaying table $table record ($this->mode)");
            $this->dbtable = ContentTable::createInstanceById ($context, $table);
            }
        else
            {
            $table = isset ($request["tn"]) ? $request["tn"] : NULL;
            
            if (NULL != $table)
                {
                $context->log ("Displaying table '$table' record ($this->mode)");
                $this->dbtable = ContentTable::createInstanceByName ($context, $table);
                }
            }

        if (empty ($this->dbtable))
            {
            if (Constants::MODE_SECTION_REVISIONS != $this->mode)
                $this->addError ($this->_("Invalid parameters passed (requested data table not configured)"));
            $tableName = Constants::ANY;
            }
        else
            $tableName = $this->dbtable->getTableName ();

        parent::__construct ($context, NULL, Constants::TABLES_META, $tableName);
        }

    public function ensureTitle ($context, &$request)
        {
        parent::ensureTitle ($context, $request);
        $this->ensureChildren ($context, $request);
        $context->setTitle ($this->getTitle ());
        return true;
        }

    public function isEditorMode ()
        {
        return Constants::MODE_EDIT == $this->mode;
        }

    protected function checkAccess ($request)
        {
        if (Constants::MODE_EDIT != $this->mode && !empty ($this->dbtable))
            return $this->dbtable->canRead ();

        $this->ensureChildren ($this->context, $request);

        if (empty ($this->component))
            return false;
        return $this->component->checkAccess ($request);
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if (!empty ($this->component))
            return true;

        $creating = isset ($request["action"]) ? "new" == $request["action"] : false;
        $id = isset ($request["id"]) ? $request["id"] : NULL;

        switch ($this->mode)
            {
            case Constants::MODE_VIEW:
                $this->component = ComponentFactory::createViewer ($context, "", $this->dbtable);
                if (!empty ($this->component))
                    $context->setTitleHidden ($this->component->getTitleHidden ());
                break;
            case Constants::MODE_EDIT:
                $this->component = new ContentEditor ($context, $this->dbtable);
                break;
            case Constants::MODE_REVISIONS:
                $this->component = new ContentHistory ($context, $this->dbtable);
                break;
            case Constants::MODE_SECTION_REVISIONS:
                $this->component = new SectionHistory ($context, new SectionsTable ($context));
                break;
            case Constants::MODE_LOCATE:
                $this->component = new ContentLocator ($context, $this->dbtable);
                break;
            case Constants::MODE_STATISTICS:
                $this->component = ComponentFactory::createStatisticsView ($context, "", $this->dbtable);
                $this->addComponent ($request, "", new TextComponent ("", $context, $this->getText ("No statistics can be generated for selected record")));
                break;
            }

        if (empty ($this->component))
            return true;

        $this->component->setMode ($creating, $id);
        $this->addComponent ($request, "", $this->component);
        $description = $this->component->getMetaDescription ();
        if (!empty ($description))
            $context->setMetaParam ("Description", $description);

        return true;
        }

    public function getTitle ()
        {
        if (empty ($this->dbtable))
            {
            if (Constants::MODE_EDIT != $this->mode)
                return $this->getText ("Viewing an item");
            else
                return $this->getText ("Editing an item");
            }
        else if (!empty ($this->component))
            {
            return $this->component->getTitle ();
            }

        return $this->getText ("Error");
        }

    public function processInput ($context, &$request)
        {
        return true;
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    protected function getTemplateName ()
        {
        return "contentpage";
        }

    public function webServiceRequest ()
        {
        return $this->context->renderInline ();
        }
    }

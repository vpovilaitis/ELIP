<?php
require_once (PATH.'inc/instanceeditor.php');
require_once (PATH.'pages/editorpage.php');

class CreateUserForm extends InstanceEditor
    {
    protected $userNameColumn;
    protected $nameColumn;
    protected $descColumn;
    protected $passwordColumn;
    protected $password2Column;

    public function __construct ($prefix, $context)
        {
        parent::__construct ($prefix, $context);
        $this->dbtable = new UsersTable ($context);
        $this->dbtable->skipAccessChecks = true;
        }

    public function setMode ($creating, $id)
        {
        // always create
        parent::setMode (true, NULL);
        }

    protected function getTemplateFields ($request, $isCreating)
        {
        $this->initializeTemplateParts ($request);
        return array
            (
            $this->userNameColumn,
            $this->descColumn,
            $this->emailColumn,
            $this->passwordColumn,
            $this->password2Column,
            );
        }

    protected function initializeTemplateParts ($request)
        {
        if (NULL != $this->nameColumn)
            return;

        $prefix = "g";

        $this->userNameColumn = new TextFieldTemplate ($prefix, UsersTable::COL_NAME, $this->getText ("Login name:"), $this->getText ("Please choose the login name."), 32);
        $this->descColumn = new TextFieldTemplate ($prefix, UsersTable::COL_DESCRIPTION, $this->getText ("Your name (optional):"), $this->getText ("You real name or any description."), 64);
        $this->emailColumn = new TextFieldTemplate ($prefix, UsersTable::COL_EMAIL, $this->getText ("E-mail (optional):"), $this->getText ("E-mail of the user."), 32);
        $this->passwordColumn = new PasswordFieldTemplate ($prefix, UsersTable::COL_PASSWORD, $this->getText ("Password:"), $this->getText ("Password used to login into a site."), 32);
        $this->password2Column = new PasswordFieldTemplate ($prefix, "pwd2", $this->getText ("Confirm password:"), $this->getText ("Please enter a password once more to confirm."), 32);
        }

    protected function createRecord (&$request, $values)
        {
        unset ($request[$this->passwordColumn->key]);
        unset ($request[$this->password2Column->key]);
        $this->initializeTemplateParts ($request);

        $user = trim ($values[$this->userNameColumn->key]);
        $pwd = $values[$this->passwordColumn->key];
        if (empty ($user))
            {
            $this->addError ("Please enter a value for the \"Login name\" field.");
            return false;
            }

        if (strlen ($pwd) < MIN_PASSWORD_LEN)
            {
            $this->addError ("Please enter a password which will be at least [_0] characters length.", MIN_PASSWORD_LEN);
            return false;
            }

        if ($values[$this->password2Column->key] != $pwd)
            {
            $this->addError ("Passwords entered do not match.");
            return false;
            }

        $id = $this->dbtable->create ($user,
                                      $values[$this->descColumn->key],
                                      $values[$this->emailColumn->key],
                                      $pwd);
        if (false === $id)
            {
            $this->addError ("Error creating a new user");
            return false;
            }

        $this->context->login ($user, $pwd);

        $url = $this->context->processUrl ("index.php?c=Welcome", true);
        $this->redirect ($url);
        return true;
        }

    protected function showSuccessPage ($request)
        {
        $url = $this->context->processUrl ("index.php?c=Welcome", true);
        $this->redirect ($url);
        return false;
        }


    public function getPageTitle ($isCreating = false)
        {
        return $this->getText ("Adding a new user");
        }
    }

class CreateUser extends EditorPage
    {

    protected function createEditorComponent ($prefix, $context)
        {
        return new CreateUserForm ($prefix, $context);
        }
    }
<?php
require_once (PATH.'inc/instanceview.php');
require_once (PATH.'pages/statisticssection.php');

abstract class StatisticsView extends InstanceView
    {
    const COL_INNER = "inner";
    const COL_LABEL = "grouplabel";

    public function __construct ($context, $prefix, $dbtable)
        {
        $this->dbtable = $dbtable;
        parent::__construct ($prefix, $context);
        }

    public function ensureChildren ($context, $request)
        {
        if (false === parent::ensureChildren ($context, $request))
            return false;

        if (empty ($this->dbtable))
            return true;

        $components = $this->createComponents ($context, $request);
        if (!empty ($components))
            {
            foreach ($components as $component)
                $this->addComponent ($request, $component->id, $component);
            }
        else
            $this->addComponent ($request, "nostats", new TextComponent ("nostats", $context, $this->getText ("No statistics available for this record.")));

        return true;
        }

    public function getInstance ()
        {
        if (NULL === $this->instance)
            {
            $indexColumns = $this->dbtable->getPrimaryIndexColumns ();
            $criteria = array ();
            $id = $this->getIds ();
            for ($i = 0; $i < count ($indexColumns) && $i < count ($id); $i++)
                $criteria[] = new EqCriterion ($indexColumns[$i]->name, $id[$i]);

            $rows = $this->dbtable->selectWithDisplayName (array (), $criteria);
            if (empty ($rows))
                $this->instance = false;
            else
                $this->instance = $rows[0];
            }

        return $this->instance;
        }

    protected abstract function createComponents ($context, $request);

    public function getPageTitle ()
        {
        $label = $this->dbtable->getDisplayName ($this->getInstance ());

        if (empty ($label))
            {
            $label = $this->dbtable->getDescription ();
            if (empty ($label))
                $label = $this->dbtable->getName ();
            }

        return $this->formatText ("[_0] (statistics)", $label);
        }

    protected function getPageTemplateDir ()
        {
        return "pages";
        }

    public function getTemplateName ()
        {
        return "statisticsview";
        }

    public function getMoreStatisticsText ()
        {
        return $this->getText ("More statistics:");
        }

    protected function getAlternativeStatisticsLinks ()
        {
        return array ();
        }

    protected function getQueryStringParts ()
        {
        return array ("stats");
        }

    public function getSingleControlContentLinks ($controlId)
        {
        $table = $this->dbtable->getName();
        $id = implode ("_", $this->getIds ());
        $type = empty ($this->request["stats"]) ? NULL : $this->request["stats"];
        $params = array ("el=$controlId");
        foreach ($this->getQueryStringParts () as $key)
            {
            $val = empty ($this->request[$key]) ? NULL : $this->request[$key];
            if (!empty ($val))
                $params[] = "$key=$val";
            }

        $url = $this->context->chooseUrl ("stats/$table/$id",
                                          "index.php?c=ContentPage&mode=stats&tn=$table&id=$id", implode ("&", $params));
        return $url;
        }

    public function getDisplayedComponentId ()
        {
        if (empty ($this->request['el']))
            return NULL;
        return $this->request['el'];
        }

    public function getAlternateLinks ()
        {
        $actions = array ();
        $ids = $this->getIds ();
        if (empty ($ids))
            return $actions;

        foreach ($this->getAlternativeStatisticsLinks () as $key => $label)
            {
            $table = $this->dbtable->getName();
            $id = implode ("_", $this->getIds ());
            $parts = explode ("|", $key);
            if (2 == count ($parts))
                list ($key, $additionalParams) = $parts;
            else
                $additionalParams = "";

            if (empty ($additionalParams))
                $additionalParams = "stats=$key";
            else
                $additionalParams = "stats=$key&".$additionalParams;

            if (empty ($key))
                {
                $action = new SimpleLinkAction ($this, "sep", "<br><span class=\"linkaction\">$label</span>", NULL, true);
                $action->disable ();
                $actions[] = $action;
                continue;
                }

            $url = $this->context->chooseUrl ("stats/$table/$id",
                                              "index.php?c=ContentPage&mode=stats&tn=$table&id=$id", $additionalParams);

            $actions[] = new SimpleLinkAction ($this, $key, $label, $url, true);
            }

        return $actions;
        }

    public function setMode ($creating, $id)
        {
        $this->createNew = $creating;
        $this->setIds ($id);
        }

    public function getId ($row)
        {
        return implode ("_", $this->getIds ());
        }

    public function getActionList ()
        {
        if (empty ($this->dbtable) || $this->context->renderInline ())
            return NULL;

        $arr = array ();

        $discussionstable = new DiscussionsTable ($this->context);
        $ids = $this->getIds ();
        if ($discussionstable->canRead () && !empty ($ids))
            {
            $table = $this->dbtable->getName();
            $id = implode ("_", $ids);
            $url = $this->context->chooseUrl ("talk/_$table/$id",
                                              "index.php?c=Discussions&sc=_$table&id=$id");
            $title = $this->getText ("Discussions");
            $arr[] = new SimpleLinkAction ($this, "discuss", $title, $url, true);
            }

        return $arr;
        }

    public function getMetaDescription ()
        {
        if (NULL == $this->dbtable)
            return NULL;
        $description = $this->dbtable->getInstanceDescription ($this->getInstance ());
        if (empty ($description))
            return NULL;
        return $this->trimSentence ($description, 150);
        }

    }

<?php
define ("PATH", "./");
require_once (PATH.'inc/load.php');
$class = isset ($context->request["c"]) ? $context->request["c"] : NULL;
$ret = false;
$serviceCall = false;
$cachedOutput = NULL;

if (strlen ($class) > 0)
    {
    if (($context->renderInline () || "sports/LeagueTableExported" == $class) && empty ($_REQUEST["_purge"]))
        {
        $cachedOutput = Cache::getInstance ("match", 6*60*60, true);
        $key = preg_replace ("$[/:*<>\|\?\#\\\\]$", "_", $_SERVER['QUERY_STRING']);
        $hasCachedCopy = empty ($_REQUEST["_purge"]) ? $cachedOutput->start ($key) : false;
        if ($hasCachedCopy)
            {
            // log to the DB
            flush ();
            $usageLogger->logFinish (200);
            exit;
            }
        }

    $class = $context->parseCustomClass ($class, "pages");
    if (empty ($class))
        {
        header ("Status: 404 Not Found");
        header ("HTTP/1.0 404 Not Found");
        print $context->getText ("Page not found");

        flush ();
        // log to the DB
        $usageLogger->logFinish (404);
        exit ();
        }
    }
else if (isset ($context->request["service"]))
    {
    $class = $context->parseCustomClass ($context->request["service"], "h");
    if (empty ($class))
        $context->log ("Service class not found");
    $context->setTitle ($class);
    $serviceCall = true;
    }
else
    {
    if (0 == $context->getCurrentUser () && empty ($_REQUEST["_purge"]) && empty ($_REQUEST["today"]))
        {
        $cachedOutput = Cache::getInstance ("pages", 15*60, true);
        $key = preg_replace ("$[/:*<>\|\?\#\\\\]$", "_", $_SERVER['QUERY_STRING']);

        if ($cachedOutput->start ($key))
            {
            // log to the DB
            flush ();
            $usageLogger->logFinish (200);
            exit;
            }
        }

    $page = isset ($context->request[PageFragment::PARAM_PAGE]) ? $context->request[PageFragment::PARAM_PAGE] : NULL;

    if (empty ($page))
        {
        if (!empty ($_COOKIE["homepage_initial"]))
            $page = $_COOKIE["homepage_initial"];
        else if (!empty ($_COOKIE["homepage"]))
            $page = $_COOKIE["homepage"];
        }

    if (empty ($page))
        {
        // check if starting page is configured in the database
        $instance = PageFragment::getHomePage ($context);
        if (empty ($instance))
            $context->log ("Home page not found");
        }
    else
        {
        if (!empty ($GLOBALS["PersistedPages"]) && false !== array_search ($page, $GLOBALS["PersistedPages"]))
            {
            if (empty ($_COOKIE["homepage_initial"]))
                $context->setCookie ("homepage_initial", !empty ($_COOKIE["homepage"]) ? $_COOKIE["homepage"] : HOME_PAGE, 0);
            $context->setCookie ("homepage", $page, 60*60*24*60);
            }

        // check if starting page is configured in the database
        $instance = PageFragment::getPage ($context, $page, true);
        if (empty ($instance))
            $context->log ("Page not found");
        }
    }

if (empty ($instance) && !empty ($class))
    $instance = new $class ($context, $context->request);

if (empty ($instance))
    {
    require (PATH."pages/badsetup.php");
    $instance = new BadSetup ($context, $context->request);
    }

if (!$serviceCall)
    {
    $instance->ensureTitle ($context, $context->request);

    // include custom page load scripts (if any)
    @include PATH.'inc/pageloaded.php';
    }

$instance->process ($context->request);

if (!empty ($cachedOutput))
    $cachedOutput->end ();

// log to the DB
flush ();
$usageLogger->logFinish (200);

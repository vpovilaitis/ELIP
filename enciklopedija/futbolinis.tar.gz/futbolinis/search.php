<?php
$_REQUEST["c"] = "SearchResults";
include ("index.php");
